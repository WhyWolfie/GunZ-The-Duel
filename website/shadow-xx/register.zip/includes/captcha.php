<?php
require 'config.php';
header('Content-type: image/png'); 
session_start();
$string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$strlen = strlen($string);
for($i;$i<=5;$i++) {
	$char = mt_rand(1,$strlen);
	$end = $char - $strlen + 1;
	$code = $code.substr($string,$char,$end);
}
$_SESSION['captcha'] = md5(md5($code).sha1($captcha_salt.$_SERVER['REMOTE_ADDR'].$_COOKIE['secured_string']));
$bg_images_raw = scandir('bg-images/',1);
$i = 0;
foreach ($bg_images_raw as $clean) {
	if (preg_match('/captcha\d.png/',$clean)) {
		$bg_images_clean[$i] = $clean;
	}
	$i++;
}
$image = imagecreatefrompng('bg-images/'.$bg_images_clean[mt_rand(0,(sizeof($bg_images_clean) - 1))]);
$color_text = imagecolorallocate($image,255,255,255);
$color_line = imagecolorallocate($image,50,50,50);
$loops = rand(1,5);
for($i=0;$i<$loops;$i++){
	imageline($image,mt_rand(1,89),mt_rand(1,29),mt_rand(1,89),mt_rand(1,29),$color_line);
}
imagestring($image,5,20,7,$code,$color_text);
imagepng($image);
?>