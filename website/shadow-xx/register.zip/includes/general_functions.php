<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------

# general_functions.php 
# - cstring_gen()
# - required(<rfield>)
# - error_img(<error>,<data>,<rfield>)
	
#---------------------------------------------------------------------------
function cstring_gen() {
	$string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()_+=_';
	$strlen = strlen($string);
	for($i=0;$i<=12;$i++) {
		$char = mt_rand(1,$strlen);
		$end = $char - $strlen + 1;
		$cookie_code = $cookie_code.substr($string,$char,$end);
	}
	return($cookie_code);
}
function required($string) {
	if ($string == 1) {
		return('<span class="req">*</span>');
	}
}
function error_img($string1,$string2,$string3) {
	if (isset($_GET['register'])) {
		if (isset($string1) || !isset($string2) && $string3 == 1) {
			return('<img width="16" height="16" src="images/error.png" />');	
		}
		elseif ($string2 != '' && !isset($string1)) {
			return('<img width="16" height="16" src="images/check.png" />');
		}
	}
}
?>