<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------
	
# register_form.php

#---------------------------------------------------------------------------
if (isset($error['user']) || isset($error['user_dupe'])) {
	$error['user_fin'] = 1;
}
if (isset($error['mail']) || isset($error['mail_dupe'])) {
	$error['mail_fin'] = 1;
}
?>
<form action="?register=1" method="post">
	<table align="center">
		<tr>	
			<td class="line">Important Information</td>
			<td class="line">:</td>
		</tr>
		<tr>
			<td><span class="req">*</span>Username</td>
			<td><input type="text" name="user" id="user" maxlength="20" value="<? echo return_browser($_POST['user']); ?>" /><? echo error_img($error['user_fin'],$_POST['user'],1) ?></td>
		</tr>
		<?
			if (isset($error['user'])) {
				?>
					<tr>
						<td></td>
						<td><? echo $error['user']; ?></td>
					</tr>
				<?
			}
			if (isset($error['user_dupe'])) {
				?>
					<tr>
						<td></td>
						<td>Username In Use.</td>
					</tr>
				<?
			}
		?>
		<tr>
			<td><span class="req">*</span>Password</td>
			<td><input type="password" name="pass1" id="pass1" maxlength="20" value="<? echo return_browser($_POST['pass1']); ?>" /><? echo error_img($error['pass'],$_POST['pass1'],1) ?></td>
		</tr>
		<tr>
			<td><span class="req">*</span>Password Match</td>
			<td><input type="password" name="pass2" id="pass2" maxlength="20" /><? echo error_img($error['pass_match'],$_POST['pass2'],1) ?></td>
		</tr>
		<?
			if (isset($error['pass'])) {
				?>
					<tr>
						<td></td>
						<td><? echo $error['pass']; ?></td>
					</tr>
				<?
			}
			if (isset($error['pass_match'])) {
				?>
					<tr>
						<td></td>
						<td>Passwords Dont Match.</td>
					</tr>
				<?
			}
			if ($field_mail == 1) {
				?>
					<tr>
						<td><? echo required($rfield_mail); ?>E-Mail</td>
						<td><input type="text" name="mail" id="mail" maxlength="64" value="<? echo return_browser($_POST['mail']); ?>" /><? echo error_img($error['mail_fin'],$_POST['mail'],$rfield_mail) ?></td>
					</tr>
				<?
				if (isset($error['mail'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['mail']; ?></td>
						</tr>
					<?
				}
				if (isset($error['mail_dupe'])) {
					?>
						<tr>
							<td></td>
							<td>Mail Already In Use.</td>
						</tr>
					<?
				}
			}
			if ($field_name == 1) {
				?>
					<tr>
						<td><? echo required($rfield_name); ?>Name</td>
						<td><input type="text" name="name" id="name" maxlength="20" value="<? echo return_browser($_POST['name']); ?>" /><? echo error_img($error['name'],$_POST['name'],$rfield_name) ?></td>
					</tr>
				<?
				if (isset($error['name'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['name']; ?></td>
						</tr>
					<?
				}
			}
			if ($field_sex + $field_age + $field_country + $field_address + $field_zip > 0) {	
				?>
					<tr>	
						<td class="line"><br /><br />Additional Information</td>
						<td class="line"><br /><br />:</td>
					</tr>
				<?
			}
			if ($field_sex == 1) {
				if ($_POST['sex'] == 1 || !isset($_POST['sex'])) {	
					?>
						<tr>
							<td><? echo required($rfield_sex); ?>Sex</td>
							<td>Male:<input type="radio" name="sex" id="sex" value="1" checked="checked" />Female:<input type="radio" name="sex" id="sex" value="0" value="0" /><? echo error_img($error['sex'],$_POST['sex'],$rfield_sex) ?></td>
						</tr>
					<?
				}
				else {
					?>
						<tr>
							<td><? echo required($rfield_sex); ?>Sex</td>
							<td>Male:<input type="radio" name="sex" id="sex" value="1"  />Female:<input type="radio" name="sex" id="sex" value="0" value="0" checked="checked" /><? echo error_img($error['sex'],$_POST['sex'],$rfield_sex) ?></td>
						</tr>
					<?
				}
				if (isset($error['sex'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['sex']; ?></td>
						</tr>
					<?
				}
			}
			if ($field_age == 1) {
				?>
					<tr>
						<td><? echo required($rfield_age); ?>Age</td>
						<td>
							Day:
							<select name="age1" id="age1">
							<?
							for($i=01;$i<=31;$i++) {
								if (return_browser($_POST['age1']) == $i) {
									?>
										<option selected="yes" value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
								else {
									?>
										<option value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
							}
							?>
							</select>
							Month:
							<select name="age2" id="age2">
							<?
							for($i=01;$i<=12;$i++) {
								if (return_browser($_POST['age2']) == $i) {
									?>
										<option selected="yes" value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
								else {
									?>
										<option value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
							}
							?>
							</select>
							Year:
							<select name="age3" id="age3">
							<?
							for($i=date(Y);$i>=1901;$i--) {
								if (return_browser($_POST['age3']) == $i) {
									?>
										<option selected="yes" value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
								else {
									?>
										<option value="<? echo $i; ?>"><? echo $i; ?></option>
									<?
								}
							}
							?>
							</select>
							<? echo error_img($error['age'],$_POST['age1'],$rfield_age) ?>
						</td>
					</tr>
			<?
				if (isset($error['age'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['age']; ?></td>
						</tr>
					<?
				}
			}
			if ($field_country == 1) {
				?>
					<tr>
						<td><? echo required($rfield_country); ?>Country</td>
						<td>
							<select name="country" id="country" style="width:150px;">
								<?
								$countrys = file('includes/clist.txt');
									foreach ($countrys as $country) {
										if (preg_match('/^'.return_browser($_POST['country']).'/',$country)) {	
											?>
												<option selected="yes" value="<? echo $country; ?>"><? echo $country; ?></option>
											<?
										}
										else {
											?>
												<option value="<? echo $country; ?>"><? echo $country; ?></option>
											<?
										}
								}
								?>
							</select>
							<? echo error_img($error['country'],$_POST['country'],$rfield_country) ?>
						</td>
					</tr>
				<?
					if (isset($error['country'])) {
						?>
							<tr>
								<td></td>
								<td><? echo $error['country']; ?></td>
							</tr>
						<?
					}
			}
			if ($field_address == 1) {
				?>
					<tr>	
						<td><? echo required($rfield_address); ?>Address</td>
						<td><input type="text" name="address" id="address" maxlength="64" value="<? echo return_browser($_POST['address']); ?>" /><? echo error_img($error['address'],$_POST['address'],$rfield_address) ?></td>
					</tr>
				<?
				if (isset($error['address'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['address']; ?></td>
						</tr>
					<?
				}
			}
			if ($field_zip == 1) {
				?>
					<tr>
						<td><? echo required($rfield_zip); ?>Zip Code</td>
						<td><input type="text" name="zip" id="zip" maxlength="20" value="<? echo return_browser($_POST['zip']); ?>" /><? echo error_img($error['zip'],$_POST['zip'],$rfield_zip) ?></td>
					</tr>
				<?
				if (isset($error['zip'])) {
					?>
						<tr>
							<td></td>
							<td><? echo $error['zip']; ?></td>
						</tr>
					<?
				}
			}
			if ($captcha_status == 1) {
				?>
					<tr>	
						<td class="line"><br /><br />Security Code (captcha)</td>
						<td class="line"><br /><br />:</td>
					</tr>
				<?
			}
			?>
	</table>
	<div align="center">
		<?
			if ($captcha_status == 1) {
				?>
					<br />
					<img src="captcha/captcha.php"></img><br />
					<span class="req">*</span>Captcha <input type="text" name="captcha" id="captcha" maxlength="6" size="6"  /><? echo error_img($error['captcha'],$_POST['captcha'],1) ?><br />
				<?
				if (isset($error['captcha'])) {
					?>
						Invalid Captcha.<br />
					<?
				}
			}
			?>
		<br />		
		<input type="submit" value="Register" /><br />
		<br /><br />
		<span class="req">*</span> Required Field
		<br /><br />
		:: Made By Shadow-xx ::
	</div>
</form>