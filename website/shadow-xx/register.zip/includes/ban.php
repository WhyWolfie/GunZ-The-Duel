<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------
	
# ban.php

#---------------------------------------------------------------------------

include 'style/ban.css';
$images_raw = scandir('images/ban/');
foreach ($images_raw as $imgr) {
	$image_ext = explode('.',$imgr);
	if (preg_match('/(png|gif|jpg|jpeg)/',$image_ext[1])) {
		$images[] = $imgr;
	}
}
?>
<table align="center" height="100%">
	<tr>
		<td align="center">
			<table class="main" cellpadding="10" cellspacing="10">
				<tr>
					<td class="main" align="center">
						<img src="<? echo 'images/ban/'.$images[mt_rand(0,(sizeof($images) - 1))]; ?>" />
					</td>
				</tr>
				<tr>
					<td class="main" align="center">
					Your ip : <? echo $_SERVER['REMOTE_ADDR']; ?><br />
					Is banned from using the register page.
					</td>
				</tr>
			</table>
			<br />
			<br />
			:: Made By Shadow-xx ::
		</td>
	</tr>
</table>