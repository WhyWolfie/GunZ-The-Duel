<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------

# config.php 

#---------------------------------------------------------------------------

# Database Settings
$database_serv = '127.0.0.1'; // Database Server
$database_name = 'GunZDB'; // Database Name
$database_user = 'sa'; // Database Username
$database_pass = ''; // Database Password

# Database Connection
# 0 - mssql
# 1 - odbc
$connection_type = '1';

# Table Names
$table_account   = 'Account'; // Acount Table
$table_login	 = 'Login'; // Character Table

#Field Settings
# 0 - Off
# 1 - On
# fields to show
$field_name     = '1'; // Name Field
$field_zip		= '1'; // Zip Code Field
$field_address  = '1'; // Address Field
$field_mail     = '1'; // Mail Field
$field_sex		= '1'; // Sex Field
$field_country  = '1'; // Country Field
$field_age      = '1'; // Age Field
# Required fields
$rfield_name     = '1'; // Name Field
$rfield_zip		 = '0'; // Zip Code Field
$rfield_address  = '0'; // Address Field
$rfield_mail     = '1'; // Mail Field
$rfield_sex		 = '0'; // Sex Field
$rfield_country  = '0'; // Country Field
$rfield_age      = '0'; // Age Field

# Captcha
# 0 - Off
# 1 - On
$captcha_status = '1'; // Captcha on/off
# Used to secure the hashed sessions
$captcha_salt   = '*3a%s^,1'; // Salt 

# IP Ban
# 0 - Off
# 1 - On
$ipban_status = '1'; // Ip Ban on/off

# Escape Characters
# Leave This alone should be fine as it is
$new = "\r\n"; // New Line
$tab = "\t"; // Tab
?>