<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------
	
# security_functions.php
# - user_check(<data>)
# - pass_check(<data>)
# - name_check(<data>)
# - zip_check(<data>)
# - address_check(<data>)
# - mail_check(<data>)
# - age_check(<data>)
# - sex_check(<data>)
# - country_check(<data>)
# - clean(<data>)
# - return_browser(<data>)

#---------------------------------------------------------------------------

function user_check($string) {
	if (preg_match('/^[\w\-]{6,20}$/i',$string)) {
		return(1);
	}
}
function pass_check($string1,$string2) {
	if (preg_match('/^[\w\-]{6,20}$/i',$string1) && preg_match('/^[\w\-]{6,20}$/i',$string2)) {
		return(1);
	}
}
function name_check($string) {
	if (preg_match('/^[a-z\.\-]{2,20}$/i',$string)) {
		return(1);
	}
}	
function zip_check($string) {
	if (is_numeric($string) && strlen($string) >= 4 && $strlen <= 9) {
		return(1);
	}
}
function address_check($string) {
	if (preg_match('/^[\w\-]{4,256}$/',$string)) {
		return(1);
	}
}
function mail_check($string) {
	if (preg_match('/^[-_a-z0-9\'+*$^&%=~!?{}]++(?:\.[-_a-z0-9\'+*$^&%=~!?{}]+)*+@(?:(?![-.])[-a-z0-9.]+(?<![-.])\.[a-z]{2,6}|\d{1,3}(?:\.\d{1,3}){3})(?::\d++)?$/iD',$string)) {
		return(1);
	}
}
function age_check($string1,$string2,$string3) {
	if (is_numeric($string1) && is_numeric($string2) && is_numeric($string3)) {
		if (strlen($string1) <= 2 && strlen($string2) <= 2 && strlen($string3) == 4) {
			return(1);
		}
	}
}
function sex_check($string) {
	if ($string == 0|1) {
		return(1);
	}
}
function country_check($string) {
	$lines = file('includes/clist.txt');
	foreach($lines as $line) {
		$c_array[] = trim($line);
	}
	if (in_array($string,$c_array)) {
		return(1);
	}
}
function clean($string) {
	$string = trim($string);
	$string = strip_tags($string);
	$string = preg_replace('/(\'|\")/','',$string);
	$string = stripslashes($string);
	return($string);
}
function return_browser($string) {
	$string = strip_tags($string);
	$string = htmlentities($string);
	$string = stripslashes($string);
	return($string);
}
?>