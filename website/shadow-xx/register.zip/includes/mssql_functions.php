<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	
	
#---------------------------------------------------------------------------
	
# mssql_functions.php 
# - query(<connection link>,<query>)
# - fetch_array(query>)
# - num_rows(<querty>)
	
#---------------------------------------------------------------------------

$dbc = mssql_connect($database_serv,$database_user,$database_pass);
mssql_select_db($database_name,$dbc);

function query($dbc,$string) {
	return(mssql_query($string));
}

function fetch_array($string) {
	return(mssql_fetch_array($string));
}

function num_rows($string) {
	return(mssql_num_rows($string));	
}
?>