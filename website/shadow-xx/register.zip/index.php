<?php
# GunZ Register Page - Registretion system for the gunz database
# Copyright (C) 2008 Shadow-xx

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.	

#---------------------------------------------------------------------------
	
# index.php

#---------------------------------------------------------------------------

session_start();
require 'includes/config.php';
require 'includes/general_functions.php';
if (empty($_COOKIE['secured_string'])) {
	setcookie('secured_string',cstring_gen());
}
include 'style/style.css';
if ($connection_type == 1) {
	require 'includes/odbc_functions.php';
}
else {
	require 'includes/mssql_functions.php';
}
require 'includes/security_functions.php';
$ip = $_SERVER['REMOTE_ADDR'];
$ban_query = query($dbc,"SELECT * FROM Login a, Account b WHERE a.AID=b.AID AND a.LastIP='$ip' AND b.UGradeID='253' OR a.RegIP='$ip' AND b.UGradeID='253'");
$ban_num = num_rows($ban_query);
if ($ban_num <= 0 || $ipban_status == 0) {
	if (isset($_GET['register'])) {
		$sub = 1;
		$captcha = 0;
		if ($_POST['user'] != '') {
			if (user_check($_POST['user']) != 1) {
				$error['user'] = 'Invalid Username';
				$sub = 1;
				
			}
			$user = clean($_POST['user']);
			$user_dupe_query = query($dbc,"SELECT a.UserID,b.UserID FROM Login a, Account b WHERE a.AID=b.AID AND a.UserID='$user' OR b.UserID='$user'");
			$user_dupe_num = num_rows($user_dupe_query);
			if ($user_dupe_num != 0) {
				$error['user_dupe'] = 1;
				$sub = 1;
			}
		}
		else {
			$error['user'] = 'Username is Empty';
			$sub = 1;
		}
		if ($_POST['pass1'] != '' && $_POST['pass1'] != '') {
			if (pass_check($_POST['pass1'],$_POST['pass2']) != 1) {
				$error['pass'] = 'Invalid Password';
				$sub = 0;
			}
			if ($_POST['pass1'] != $_POST['pass2']) {
				$error['pass_match'] = 1;
				$sub = 0;
			}
		}
		else {
			$error['pass'] = 'Password(s)is Empty';
			$sub = 0;
		}
		if ($field_name == 1) {
			if ($_POST['name'] != '' && name_check($_POST['name']) != 1) {
				$error['name'] = 'Invalid Name';
				$sub = 0;
			}
			elseif ($rfield_name == 1 && $_POST['name'] == '' ) {
				$error['name'] = 'Name Is Empty';
				$sub = 0;	
			}
		}
		if ($field_mail == 1) {
			if ($_POST['mail'] != '') {	
				if (mail_check($_POST['mail']) != 1) {
					$error['mail'] = 'Invalid E-Mail';
					$sub = 0;
				}
				$mail = clean($_POST['mail']);
				$mail_dupe_query = query($dbc,"SELECT Email FROM Account WHERE Email='$mail'");
				$mail_dupe_num = num_rows($mail_dupe_query);
				if ($mail_dupe_num != 0) {
					$error['mail_dupe'] = 1;
					$sub = 0;
				}
			}
			elseif ($rfield_mail == 1 && $_POST['mail'] == '') {
				$error['mail'] = 'E-Mail is Empty';
				$sub = 0;
			}
		}
		if ($field_age == 1) {
			if ($_POST['age1'] != '' && $_POST['age2'] != '' && $_POST['age3'] != '' && age_check($_POST['age1'],$_POST['age2'],$_POST['age3']) != 1) {
				$error['age'] = 'Invalid Age';
				$sub = 0;
			}
			elseif ($rfield_age == 1 && $_POST['age1'] == '' || $_POST['age2'] == '' || $_POST['age3'] == '') {
				$error['age'] = 'Age Is Empty';
				$sub = 0;
			}
		}
		if ($field_sex == 1) {
			if ($_POST['sex'] != '' && sex_check($_POST['sex']) != 1) {
				$error['sex'] = 'Invalid Sex';
				$sub = 0;
			}
			elseif ($rfield_sex == 1 && $_POST['sex'] == '') {
				$error['sex'] = 'Sex Is Empty';
				$sub = 0;
			}
		}
		if (field_zip == 1) {
			if ($_POST['zip'] != '' && zip_check($_POST['zip']) != 1) {
				$error['zip'] = 'Invalid Zip';
				$sub = 0;
			}
			elseif ($rfield_zip == 1 && $_POST['zip'] == '') {
				$error['zip'] = 'Zip Is Empty';
				$sub = 0;
			}
		}
		if ($field_address == 1) {
			if ($_POST['address'] != '' && address_check($_POST['address']) != 1) {
				$error['address'] = 'Invalid Address';
				$sub = 0;
			}
			elseif ($rfield_address == 1 && $_POST['address'] == '') {
				$error['address'] = 'Address Is Empty';
				$sub = 0;
			}
		}
		if ($field_country == 1) {
			if ($_POST['country'] != '' && country_check($_POST['country']) != 1) {
				$error['country'] = 'Invalid Country';
				$sub = 0;
			}
			elseif ($rfield_country == 1 && $_POST['country'] == '') {
				$error['country'] = 'Country is Empty';
				$sub = 0;
			}
		}
		$captcha_input = md5(md5($_POST['captcha']).sha1($captcha_salt.$_SERVER['REMOTE_ADDR'].$_COOKIE['secured_string']));
		if ($_SESSION['captcha'] == $captcha_input && isset($_POST['captcha']) || $captcha_status == 0) {
			$captcha = 1;
		}
		else {
			//echo $_SESSION['captcha'].'<br />';
			//echo $captcha_input.'<br />';
			$error['captcha'] = 1;
		}
		if ($sub == 1 && $captcha == 1) {
			$user = clean($_POST['user']);
			$pass = clean($_POST['pass1']);
			$date = date("Y-m-d H:i:s");
			$query_fields = 'UserID,UGradeID,PGradeID,RegDate';
			$query_values = "'$user','0','0','$date'";
			if ($_POST['name'] != '') {
				$query_fields = $query_fields.',Name';
				$query_values = $query_values.',\''.clean($_POST['name']).'\'';
			}
			else {
				$query_values = $query_values.',\'N/A\'';
			}
			if ($_POST['mail'] != '') {
				$query_fields = $query_fields.',Email';
				$query_values = $query_values.',\''.clean($_POST['mail']).'\'';
			}
			if ($_POST['age'] != '') {
				$query_fields = $query_fields.',Age';
				$query_values = $query_values.',\''.clean($_POST['age']).'\'';
			}
			if ($_POST['sex'] != '') {
				$query_fields = $query_fields.',Sex';
				$query_values = $query_values.',\''.clean($_POST['sex']).'\'';
			}
			if ($_POST['zip'] != '') {
				$query_fields = $query_fields.',ZipCode';
				$query_values = $query_values.',\''.clean($_POST['zip']).'\'';
			}
			if ($_POST['address'] != '') {
				$query_fields = $query_fields.',Address';
				$query_values = $query_values.',\''.clean($_POST['address']).'\'';
			}
			if ($_POST['country'] != '') {
				$query_fields = $query_fields.',Country';
				$query_values = $query_values.',\''.clean($_POST['country']).'\'';
			}
			//echo $query_fields.'<br />';
			//echo $query_values.'<br />';
			query($dbc,"INSERT INTO $table_account ($query_fields) VALUES($query_values);INSERT INTO $table_login (UserID,AID,Password,RegIP) SELECT '$user',AID,'$pass','$ip' FROM $table_account WHERE UserID='$user'");
			echo '<script>alert(\'Your account "'.return_browser($user).'" has been created.\')</script>';
		}
	}
	require 'includes/register_form.php';
}
else {
	include 'includes/ban.php';
}
?>