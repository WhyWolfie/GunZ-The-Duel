<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "CrafTGunz - Index", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>

<link rel="shortcut icon" type="image/x-icon" href="favicon.png" />
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>%TITLE%</title>
<script language="JavaScript">
<!--



function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->
</script>

<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>
<link rel="stylesheet" type="text/css" href="e_style.css">
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #373737 url('images/headbg.jpg') no-repeat center top">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="90%">
		<tr>
			<td>

<div id="" align="center">
<a href='http://www.facebook.com/pages/Arcade-Gunz/350016341710096' target='_blank' title='S�gueme en Facebook'><img src="images/fb.png" style="width:80px; display:scroll;position:fixed;bottom:450px;right:1178px" /></a>
<a href='https://twitter.com/#!/ArcadeGunz' target='_blank' title='S�gueme en Twitter'><img src="images/tw.png" style="width:64px; display:scroll;position:fixed;bottom:385px;right:1188px" /></a>
<a href='http://www.youtube.com/watch?v=sYrCxAx2564' target='_blank' title='S�gueme en YouTube'><img src="images/you.png" style="width:83px; display:scroll;position:fixed;bottom:300px;right:1180px" /></a>

<div id="" align="center">  

<a href="index.php?do=index" onmouseover="FP_swapImg(1,1,/*id*/'image0',/*url*/'images/nav-home_on.png')" onMouseOut="FP_swapImgRestore()"> <img name="image0" align="top" src="images/nav-home.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="114" width="121"></a>
<a href="index.php?do=register" onMouseOver="FP_swapImg(1,1,/*id*/'image1',/*url*/'images/nav-reg_on.png');" onMouseOut="FP_swapImgRestore()"><img name="image1" align="top" src="images/nav-reg.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="109" width="99" /></a> 
<a href="index.php?do=download" onMouseOver="FP_swapImg(1,1,/*id*/'image2',/*url*/'images/nav-down_on.png')" onMouseOut="FP_swapImgRestore()"><img name="image2" align="top" src="images/nav-down.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="94" width="98"></a> 
<a href="index.php?do=index" onMouseOver="FP_swapImg(1,1,/*id*/'image3',/*url*/'images/nav-logo_on.png')" onMouseOut="FP_swapImgRestore()"><img name="image3" align="top"  src="images/nav-logo.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="92" width="194"></a>
<a href="index.php?do=individualrank" onMouseOver="FP_swapImg(1,1,/*id*/'image4',/*url*/'images/nav-clan_on.png')" onMouseOut="FP_swapImgRestore()"><img name="image4" align="top" src="images/nav-clan.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="95" width="89"></a> 
<a href="index.php?do=shop" onMouseOver="FP_swapImg(1,1,/*id*/'image5',/*url*/'images/nav-mark_on.png')" onMouseOut="FP_swapImgRestore()"><img name="image5" align="top" src="images/nav-mark.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="106" width="94"></a> 
<a href="TU COMUNIDAD" onMouseOver="FP_swapImg(1,1,/*id*/'image6',/*url*/'images/nav-com_on.png')" onMouseOut="FP_swapImgRestore()"><img name="image6" align="top" src="images/nav-com.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="112" width="134"></img></a> 
</div> 

<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" id="obj1" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" border="0" width="791" height="359">
<param name="movie" value="images/2header1.png">
<param name="quality" value="High">
<param name="wmode" value="transparent">

<embed src="images/header.png" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj1" width="791" height="359" quality="High" wmode="transparent"></object>			</td>

		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>
		<div align="center">

		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3">&nbsp;
						</td>
          </tr>
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {
                SetMessage("", array("�CrafTGunZ es un servidor qu� es absolutamente gratuito!",
                "Haz click <a href=\"index.php?do=register\"><b>aqu�</b> para registrarte</a>"));
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("An error has ocurred", array("Module '$do' not found"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>
			</td>
            <td width="12">&nbsp;</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">&nbsp;
			</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">
			<p align="center">&nbsp;<map name="FPMap0"><area href="mailto:lambdacerro@gmail.com" shape="rect" coords="560, 17, 611, 84"></map><img border="0" src="images/top_bg.jpg" width="626" height="102" usemap="#000000"></td>
          </tr>
        </tbody></table>
          </div>
          	</td>
		</tr>
	</table>
</div>

</body>

</html>