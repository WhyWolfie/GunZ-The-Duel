<?
SetTitle("Arcade Gunz- Donar");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
	font-style: italic;
}
-->
</style>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar a BlasterGunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
													<p>BlasterGunz Les Da Las Gracias a las 
													donaciones que hacen 
												  nuestros usuarios. </p>
													<p>donaciones via mensaje </p>
													<p>Cambiar lo que dice tu mensaje </p>
													<p>x tu cuenta
													  <noscript>
                                                      </noscript>
													  </p>
													</p>
													<iframe src="http://display.recursosmoviles.com/display.php?id=13957" marginheight="0" marginwidth="0" frameborder="0" style="width: 400px; height: 50px; border: 0px none; overflow:hidden;" ></iframe>
<p>
<!-- End Allopass Checkout-Button Code --><br>
												    </p>
												  <p>para las donaciones usted deve tener un correo electronico y agregar el siguiente correo:</p>
													<p align="center">  <span class="Estilo1">blastergunz@hotmail.com</span><br>
													  <br>
													  tambien pueden hacerlo enviando por el banco bcp</p>
													<p align="center">click en la siguiente imagen</p>
													<p align="center"><img src="images/index.png" width="183" height="198" border="0" usemap="#Map" /></p>
												  <center>
												  </center>
												  <p>&nbsp;</p>
                                                </div>
                                                <p>
                                                <br />

                                                </p>
                                                </div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<map name="Map" id="Map">
  <area shape="rect" coords="0,4,181,205" href="/includesbg/index.php" />
</map>