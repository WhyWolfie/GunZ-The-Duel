<?php
header ("Location:index.php?do=buynamecolor");
?>