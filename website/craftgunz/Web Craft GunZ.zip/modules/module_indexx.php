<?
    $res = mssql_query("SELECT TOP 4 * FROM ShopEvents WHERE Opened = 1 ORDER BY CSSID DESC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $i[$count][ID]          = $a->CSSID;
        $i[$count][Name]        = $a->Name;
        $i[$count][ImageURL]    = $a->ImageURL;
        $i[$count][Slot]        = GetTypeByID($a->Slot);
        $i[$count][Sex]         = GetSexByID($a->Sex);
        $i[$count][Level]       = $a->Level;
        $i[$count][Price]       = $a->Price;

        $count++;
    }


    $res = mssql_query("SELECT TOP 4 * FROM ShopDonator(nolock) ORDER BY CSSID DESC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $c[$count][ID]          = $a->CSSID;
        $c[$count][ImageURL]    = $a->ImageURL;
        $c[$count][Name]        = $a->Name;
        $c[$count][Slot]        = GetTypeByID($a->Slot);
        $c[$count][Sex]         = GetSexByID($a->Sex);
        $c[$count][Level]       = $a->Level;
        $c[$count][Price]       = $a->Price;

        $count++;
    }
?>
<style type="text/css">
<!--
.Estilo1 {color: #FF0000}
.Estilo3 {color: #33FF00}
.Estilo4 {color: #00FF00}
-->
</style>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center"><? include "blocks/block_login.php";
                        ?></div>
						  
						
					  </td>
						<td valign="top">
						<div align="center">

					

							<table border="0" style="background-position: center top; border-collapse: collapse; background-repeat:no-repeat" width="419" bgcolor="#313131">
								<tr>
                                
									<td background="images/mn_info.jpg" height="76" style="background-image: url(''); background-repeat: no-repeat; background-position: center top" width="417"><p>
									  <object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" name="obj2" width="417" height="76" border="0" id="obj2">
									    <param name="movie" value="images/srv_data.swf" />
									    <param name="quality" value="High" />
									    <param name="wmode" value="transparent" />
									    <param name="BGCOLOR" value="#E2E2E2" />
									    <embed src="images/srv_data.swf" width="417" height="76" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj2" quality="High" wmode="transparent" bgcolor="#E2E2E2"></embed>
								      </object>
									</p>
								    <p><img src="/images/extra/namecolor.gif" width="417" height="76" border="0" usemap="#Map2" /> </p></td>
							  </tr>
								<tr>
									<td height="4" width="417"></td>
								</tr>
								<tr>
									<td style="background-image: url('images/md_information.jpg'); background-repeat: no-repeat; background-position:  left top; text-align: center;" height="156" width="417" valign="top">
								  <div align="center">
								  <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="417" height="151">
                                    <tr>

                                      <td width="200" height="24">&nbsp;</td>
                                      <td width="7" height="24">&nbsp;</td>
                                      <td width="204" height="24">&nbsp;</td>
                                    </tr>

                                    <tr>			
                                      <td width="200" valign="top"><table border="0" style="border-collapse: collapse" width="200" height="92%">
                                          <tr>

                                            <td width="4">&nbsp;</td>
                                            <td width="192" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><font color="#FFFFFF"> <a href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"><?=$n['Title']?>
                                                  </a></font></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                      <td width="7">&nbsp;</td>
                                      <td width="204" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                          <tr>
                                            <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><a href="index.php?do=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                    <?=$n['Title']?>
                                                  </font></a></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                    </tr>
                                  </table>
<p><img src="/images/extra/info.gif" width="407" height="72" border="0" usemap="#Map" /></p>
<p>aki algunos ejemplos :</p>
<table width="395" border="1">
  <tr>
    <th width="112" height="23" scope="col"><span class="Estilo4">PAIS</span></th>
    <th width="248" scope="col"><span class="Estilo4">MENSAJE</span></th>
    <th width="73" scope="col"><span class="Estilo4">NUMERO</span></th>
  </tr>
</table>
<table width="392" border="1">
  <tr>
    <th width="96" scope="col">PERU</th>
    <th width="225" scope="col">PAL BLASTERGUNZ tucuenta</th>
    <th width="49" scope="col">7766</th>
  </tr>
  <tr>
    <th scope="row">VENEZUELA</th>
    <td><div align="center"><strong>REM BLASTERGUNZ tucuenta</strong></div></td>
    <td><div align="center"><strong>7557</strong></div></td>
  </tr>
  <tr>
    <th scope="row">ARGENTINA</th>
    <td><div align="center"><strong>REM BLASTERGUNZ tu cuenta</strong></div></td>
    <td><div align="center"><strong> 27777 </strong></div></td>
  </tr>
  <tr>
    <th scope="row">CHILE</th>
    <td> <div align="center"><strong> REM&nbsp;
          <label id="xalias">BLASTERGUNZ</label>
        tucuenta
    </strong></div>
      <label id="xalias"></label></td>
    <td> <div align="center"><strong>2777 </strong></div></td>
  </tr>
  <tr>
    <th scope="row">MEXICO</th>
    <td> <div align="center"><strong>RM&nbsp; BLASTERGUNZ tucuenta</strong></div>
      <label id="xalias">
      <div align="left"></div>
      </label></td>
    <td> <div align="center"><strong>28000 </strong></div></td>
  </tr>
</table>
<p>RAKING DE LAS ULTIMAS 20 CUENTAS QUE ACABAN DE MANDAR MENSAJE </p>
<p><iframe src="http://display.recursosmoviles.com/display.php?id=13957" marginheight="0" marginwidth="0" frameborder="0" style="width: 400px; height: 50px; border: 0px none; overflow:hidden;" ></iframe>�</p>
<p>___________________________________________________</p>
<p>Donaciones por deposito bancario bcp o agentes bcp &quot;<span class="Estilo3">solo peru</span>&quot; es mas .comodo que por mensaje. para saber mas agregar el msn blastergunz@hotmail.com</p>
<p>___________________________________________________</p></td>
								<tr>
									<td style="background-image: url('images/md_LI.jpg'); background-repeat: no-repeat; background-position: center top" height="305" width="417">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="417" height="100%">
											<tr>
												<td width="206" height="23">&nbsp;</td>
												<td width="207" height="23">&nbsp;</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$c[1][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$c[1][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Type:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[1][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sex:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[1][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Level:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[1][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span class="Estilo4" style="font-size: 7pt" align="center">
																		Price:</span></td>
																	  <td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[1][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=<?=$c[1][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1772" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1772'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyitem&itemid=<?=$c[1][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1773" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1773'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
                                                        <tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$c[2][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$c[2][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Type:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[2][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sex:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[2][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Level:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[2][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span class="Estilo4" style="font-size: 7pt" align="center">
																		Price:</span></td>
																	  <td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[2][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=<?=$c[2][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1774" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1774'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyitem&itemid=<?=$c[2][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1775" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1775'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$c[3][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$c[3][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Type:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[3][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sex:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[3][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Level:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[3][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span class="Estilo1" style="font-size: 7pt" align="center">
																		<span class="Estilo4">Price</span>:</span></td>
																	  <td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[3][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=<?=$c[3][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1776" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1776'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyitem&itemid=<?=$c[3][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1777" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1777'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$c[4][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$c[4][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Type:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[4][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sex:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[4][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Level:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[4][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span class="Estilo4" style="font-size: 7pt" align="center">
																		Price:</span></td>
																	  <td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$c[4][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=<?=$c[4][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1778" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1778'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyitem&itemid=<?=$c[4][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1779" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1779'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="16">												</td>
												<td width="207" height="16">												</td>
											</tr>
										</table>
										<iframe src="http://www.facebook.com/pages/Arcade-Gunz/350016341710096"></iframe>
                                    </div>									</td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
						  <div align="center">
						    <? include "blocks/block_rankingu.php" ?>
                          </div>
						  <p>&nbsp; </p>
						  <div align="center">
                            <p>
                              <? include "blocks/block_rankingc.php" ?>
                            </p>
						    <p>&nbsp; </p>
					      </div>
						  </div>
</td>
</tr>
				</table>
<map name="Map" id="Map"><area shape="rect" coords="0,-2,408,73" href="/index.php?do=donate" />
</map>
<map name="Map2" id="Map2"><area shape="rect" coords="0,3,428,81" href="/index.php?do=bgcolor" />
</map>