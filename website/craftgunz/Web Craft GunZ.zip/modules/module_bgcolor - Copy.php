<?
SetTitle("Arcade Gunz - Comprar Nombre a Color");


?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + "ACoins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
	font-style: italic;
}
.Estilo2 {color: #FFFFFF}
.Estilo3 {
	color: #999999;
	font-weight: bold;
}
.Estilo5 {
	color: #FF0000;
	font-size: 36px;
}
.Estilo8 {color: #FFFF00}
.Estilo9 {
	color: #33FF00;
	font-weight: bold;
	font-size: 24px;
}
.Estilo10 {
	font-size: 24px;
	color: #6600CC;
	font-weight: bold;
}
.Estilo11 {
	font-size: 24px;
	color: #0033FF;
	font-weight: bold;
}
.Estilo12 {
	color: #CC00FF;
	font-weight: bold;
	font-size: 24px;
}
.Estilo13 {
	color: #00CCFF;
	font-weight: bold;
	font-size: 24px;
}
.Estilo14 {
	color: #FFFF00;
	font-size: 24px;
	font-style: italic;
	font-weight: bold;
}
.Estilo15 {color: #FF0000}
-->
</style>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar a Arcade Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
													<p>Arcade Gunz Les Da Las Gracias a las 
													donaciones que hacen 
												  nuestros usuarios.												  </p>
													<p>&nbsp;</p>
												  <p><span class="Estilo3">BlasterGunz  Les Da Las Gracias a las donaciones que hacen nuestros usuarios.&nbsp;<br />
  Para mantener los gastos de BlasterGunZ, por lo que agradecemos su donaci&oacute;n</span><br />
												    <br />
											      <span class="Estilo2"><strong>DONACI&Oacute;N RAPIDA VIA SMS:</strong></span></p>
												  <p><span class="Estilo2">COMPRAR NOMBRE DE COLOR . </span></p>
												  <p><span class="Estilo2">ULTIMAS CUENTAS QUE AN COMPRADO </span></p>
												  <p><span class="Estilo2"><iframe src="http://display.recursosmoviles.com/display.php?id=14126" marginheight="0" marginwidth="0" frameborder="0" style="width: 400px; height: 50px; border: 0px none; overflow:hidden;" ></iframe>
												  </span></p>
												  <p class="Estilo14">colores :</p>
												  <p align="center"><span class="Estilo9">verde</span><br />
												    <span class="Estilo10">morado</span><br />
												    <span class="Estilo11">azul</span><br />
												    <span class="Estilo12">fucsia</span><br />
											        <span class="Estilo13">celeste </span></p>
												  <p><span class="Estilo2">PASOS PARA HACER UNA CORRECTA DONACION X MENSAJE CORRECTAMENTE </span></p>
												  <p><span class="Estilo2">1.- </span><span class="Estilo2">ESCRIBIR CORRECTAMENTE</span></p>
												  <p><span class="Estilo2">2.- EL MENSAJE SE ENVIA EN <span class="Estilo5">MAYUSCULA</span>y el mensaje sera el color que quiera ejemplo verde=&quot;nuestracuenta&quot;=1 sin comillas</span></p>
												  <p><span class="Estilo2">3.- envian el mensaje ejemplo peru : NOS DICE  Env&iacute;a&nbsp;<span id="highlight_text">PAL&nbsp;
												        <label id="xalias">BGCOLOR</label>
												  </span><br />
												  seguido de&nbsp;<span id="highlight_text2">&quot;TU AID&quot;</span>AL 7766</span></p>
												  <p><span class="Estilo2">agarramos nuestro celular le ponemos en enviar mensaje seleccionamos mayuscula todo Y escribimos PAl BGCOLOR verde=micuenta=1 <strong><span class="Estilo15">2veces tenemos que enviar esto para poder obtener el nombre de color deseado</span></strong> lo enviamos al numero 7766 . haci seria correctamente nuestra donacion . </span> luego otra ves enviamos pero ahora de esta forma : <span class="Estilo2"> PA BLASTERGUNZ verde=micuenta=2</span></p>
												  <p>al enviar los dos mensajes su nombre a color sera entregado al conectarse el due&ntilde;o </p>
												  <p><span class="Estilo2"><span class="Estilo8">ESO ES SOLO UN EJEMPLO PARA PERU</span><br />
											      </span></p>
												  <p>
  <!-- End Allopass Checkout-Button Code -->
												  <iframe src="http://iframes.recursosmoviles.com/index.php?wmid=3298&cid=14126" width="440" height="318" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" allowTransparency="true" ></iframe></p>
												  <p align="center">  <span class="Estilo1">blastergunz@hotmail.com</span></p>
										    <p align="center"><br>
													  _____________________________________________________________<br>
													  tambien pueden hacerlo enviando por el banco bcp</p>
										    <p align="center">solo peru la cual es mas comodo . </p>
											    <p align="center">click en la siguiente imagen</p>
													<p align="center"><img src="images/bcp/index.png" width="183" height="198" border="0" usemap="#Map" /></p>
													<p align="center">&nbsp;</p>
												  <center>
												    <table width="500" border="1">
                                                      <tr>
                                                        <th scope="col">www.blastergunz.com msn soporte : arcadegunz@hotmail.com</th>
                                                      </tr>
                                                    </table>
												  </center>
												  <p>&nbsp;</p>
                                                </div>
                                                <p>
                                                <br />
                                                </p>
                                                </div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<map name="Map" id="Map">
  <area shape="rect" coords="-3,3,178,204" href="" />
</map>