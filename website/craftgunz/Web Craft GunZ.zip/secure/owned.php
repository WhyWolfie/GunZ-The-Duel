<p><strong><font size="6">Baneado</font></strong><br>
  <br>
El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP.<br>
</p>
<hr>
<p> 
  <em>Has sido baneado temporalmente de Arcade Gunz por el equipo de staff de Arcade Gunz.</em></p>
