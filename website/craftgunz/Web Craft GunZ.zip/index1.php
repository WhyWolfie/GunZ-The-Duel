<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/shield.php";

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "CrafTGunzV2 - Index", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<meta name="verify-iw" content="IW877630" />
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
 <meta http-equiv="content-type" content="text/html; charset=windows-1252">
  <meta name="keywords" content="blastergunz,gunz,online,latinoamerica,nazca,nasca,ica,peru,america,espa�ol,gratis,gratuito,2010,online,server,games,server,dedicado,libre,abierto">
  <meta name="description" content="BlasterGunz es un servidor de GunZ Online en Espa�ol y completamente Gratis. Entra ya y Registrate!">
<title>%TITLE%</title>
<script language="JavaScript">
<!--

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->
</script>

<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>
<link rel="stylesheet" type="text/css" href="e_style.css">
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('') no-repeat center top">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="90%">
		<tr>
			<td><center>
		  <p align="center"><img src="images/header.png" alt="BlasterGunZ" width="795" height="268" border="0" usemap="#Map">
		  <p><script type="text/javascript" src="god/sc5wn4d.js"></script>
		  <table id="vista-buttons.com:id5wn4d" width=0 cellpadding=0 cellspacing=0 border=0><tr><td style="padding-right:0px" title ="INICIO">
<a href="index.php" onMouseOver='xpe("");' onMouseOut='xpe("5wn4dn");' onMouseDown='xpe("5wn4dc");'><img id="xpi_5wn4d" src="god/bt5wn4d_0.gif" name="vb5wn4d" width="125" height="25" border="0" alt="INICIO"/></a></td><td style="padding-right:0px" title ="REGISTRATE">
<a href="index.php?do=register" onMouseOver='xpe("awn4do");' onMouseOut='xpe("awn4dn");' onMouseDown='xpe("awn4dc");'><img id="xpi_awn4d" src="god/btawn4d_0.gif" name="vbawn4d" width="125" height="25" border="0" alt="REGISTRATE"/></a></td><td style="padding-right:0px" title ="DESCARGAS">
<a href="index.php?do=download" onMouseOver='xpe("swn4do");' onMouseOut='xpe("swn4dn");' onMouseDown='xpe("swn4dc");'><img id="xpi_swn4d" src="god/btswn4d_0.gif" name="vbswn4d" width="125" height="25" border="0" alt="DESCARGAS"/></a></td><td style="padding-right:0px" title ="FOROS">
<a href="http://blastergunz.forolatin.com/" onMouseOver='xpe("3wn4do");' onMouseOut='xpe("3wn4dn");' onMouseDown='xpe("3wn4dc");'><img id="xpi_3wn4d" src="god/bt3wn4d_0.gif" name="vb3wn4d" width="125" height="25" border="0" alt="FOROS"/></a></td>
<td style="padding-right:0px" title ="RANKING">
<a href="index.php?do=ranking" onMouseOver='xpe("rwn4do");' onMouseOut='xpe("rwn4dn");' onMouseDown='xpe("rwn4dc");'><img id="xpi_rwn4d" src="god/btrwn4d_0.gif" name="vbrwn4d" width="125" height="25" border="0" alt="RANKING"/></a></td><td style="padding-right:0px" title ="TIENDA VIRTUAL">
<a href="index.php?do=shop" onMouseOver='xpe("6wn4do");' onMouseOut='xpe("6wn4dn");' onMouseDown='xpe("6wn4dc");'><img id="xpi_6wn4d" src="god/bt6wn4d_0.gif" name="vb6wn4d" width="125" height="25" border="0" alt="TIENDA VIRTUAL"/></a></td></tr></table>
<noscript>></noscript></p></td>
		</tr></center>
		
		<tr>
			<td>
		<div align="center">
<script  language="javascript"  type="text/javascript">iwsrcplus="http://codenew.impresionesweb.com/r/banner_iw.php?idrotador=87763&tamano=728x90&lgid="+((new Date()).getTime() % 2147483648) + Math.random(); document.write("<scr"+"ipt language=javascript  type=text/javascript src="+iwsrcplus+"></scr"+"ipt>");</script><noscript><iframe src="http://alt.impresionesweb.com/noscript.php?tam=728x90&idp=87763&ref=87763&cod=179160" width="728" height="90" frameborder="0" marginheight="0" marginwidth="0" scrolling="no"></iframe></noscript>


		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3">&nbsp;
				</td>
          </tr>
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {
                SetMessage("", array("�CrafTGunZ es un servidor qu� es absolutamente gratuito!",
                "Haz click <a href=\"index.php?do=register\"><b>aqu�</b> para registrarte</a>"));
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("An error has ocurred", array("Module '$do' not found"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>
            <div align="center">
            <!-- BEGIN SMOWTION TAG - 468x60 - DO NOT MODIFY -->
<script type="text/javascript"><!--
smowtion_size = "468x60";
smowtion_section = "2623363";
//-->
</script>
<script type="text/javascript"
src="http://ads.smowtion.com/ad.js?s=2623363&z=468x60">
</script>
<!-- END SMOWTION TAG - 468x60 - DO NOT MODIFY -->
</div>
			</td>
            <td width="12">&nbsp;</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">&nbsp;
			</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">
			<p align="center">&nbsp;<map name="FPMap0"><area href="mailto:s4cker@hotmail.com" shape="rect" coords="560, 17, 611, 84"></map><img border="0" src="images/top_bg.jpg" width="626" height="102" usemap="#FPMap0"></td>
          </tr>
        </tbody></table>
          </div>
          	</td>
		</tr>
	</table>
</div>


</body>

</html>