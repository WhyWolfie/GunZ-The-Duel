<?php ("protecao/protect.php");?>
<?php
include "authadmin.php";
?>

<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<a href="nãodps.txt" target="_blank"><td background="images/adminpanel.gif" height="30" width="195">&nbsp;</td></a>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr><br>
										<td width="4">&nbsp;</td>
										<td width="171">
										
<b>
<p><a href="index.php?do=addindexcontent">(Adicionar Noticias)</a></p>
<p><a href="index.php?do=rzadditem">(Adicionar Donator)</a></p>
<p><a href="index.php?do=evadditem">(Adicionar Evento)</a></p>
<p><a href="index.php?do=enviar">(Enviar EVcoins)</a></p>
<p><a href="index.php?do=rzgift">(Enviar Coins)</a></p>
<p><a href="index.php?do=muteuser">(ChatBlock)</a></p>
<p><a href="index.php?do=banuser">(Banir Usuario)</a></p>
<p><a href="index.php?do=ipbanuser">(Banir IP)</a></p></b>


&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
																			<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
								</td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							
