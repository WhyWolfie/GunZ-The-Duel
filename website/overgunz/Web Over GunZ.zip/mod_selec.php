﻿<action="index.php?do=rzitemshop&sub=buyitem">
<?php ("protecao/protect.php");?>
<html>
<head>
<body>
<h1>Selecione Sua Opção</h1>
<ul>
<li class="selecione"><a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=2">donator</a></li>
<li class="selecione"><a href="index.php?do=evitemshop&sub=listallitems&expand=1&type=1">event</a></li>
</ul>
</body>
<head>
</html>
