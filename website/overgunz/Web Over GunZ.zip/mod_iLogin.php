<?php ("protecao/protect.php");?>
<?
if ($_SESSION['AID'] == ""){
?>

<table class="tablelogin" >
  <tbody>
    <tr>
   
    <td>
       	<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>



								<form method="POST" action="index.php?do=login&header=1" name="login"><br>
         						<input class="input" type="text" name="userid" ><br>
           						<input class="input" type="password" name="pasw"  ><br>
           						<input type="submit" class="logar" value="Logar" name="submit"><br>
         						<input type="checkbox" name="cookie" value="ON" checked>&nbsp;Manter-me logado<br>
          						<a href="index.php?do=register">Registre-se!</a><br>
								</form>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);

$busca1 = mssql_query_logged("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$busca2 = mssql_fetch_row($busca1);
?>





									        Bem Vindo, <?=$_SESSION['UserID']?> !<br>
											<a href="index.php?do=login&action=logout&header=1">Deseja deslogar ?</a><br>
                                                                                                                            <?
                                                                                if($busca2[0] == 255 OR $busca2[0] == 254){
                                                                                ?>


                                                                                <?
                                                                                 }
                                                                                 ?>
                                                        Última data de conexão<?=$d['LastConnDate']?><br>
														OZCoins:<?=$d['RZCoins']?><br>
														EVCoins:<?=$d['EVCoins']?><br>

    <?
}
?>
      </td>
 
    </tr>
  </tbody>
</table>

