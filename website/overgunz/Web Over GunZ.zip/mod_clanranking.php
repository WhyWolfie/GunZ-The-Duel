<?php ("protecao/protect.php");?>
<? include "inject.php" ?>
<?
$res = mssql_query("SELECT TOP 9 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
?>
<table border="0" id="table5">
							<tr>
								<td width="195" background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>Nenhum Clã Localizado.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4"><img src="<?=($clan['EmblemUrl'] == "") ? "http://img820.imageshack.us/img820/5031/noemblem.png" : $clan['EmblemUrl']?>" width="25" height="25"></td>
										<td width="142"><?=$clan['Name']?></td>
										<td width="41">
                                        <td height="20">
										<p align="center"><b><?=number_format($clan['Point'],0,'','.');?></b></td>
									</tr>
                                    <?}}?>
								</table><p align="center"><a href="index.php?do=ranking">Ver Mais</a></p>
								</td>
							</tr>
</table>
