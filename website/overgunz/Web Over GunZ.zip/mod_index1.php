<?php ("protecao/protect.php");?>
<h1>Temos disponivel as formas de pagamento abaixo.</h1>

<h2><b>Pagamento via Pague seguro</b></h2>
Para pagar via pague seguro, basta clikar no botao abaixo e você será redirecionado para a pagina do pague seguro onde você vai colocar o valor do produto que está comprando, ao clikar entrar, logo verá os dados do DCastro Suporte, o valor que digitou e opções de como você vai pagar esse valor. Como mostra imagem abaixo. Depois de pago basta entrar em contato para confirmar seu pagamento.

<div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/donation.html" method="post">
<input type="hidden" name="receiverEmail" value="dcastro-suport@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="image" src="img/imagens/pagseguroazul.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div>
<div align="center"><b>Formas de pagamento atraves do pague seguro</b>
<br><br><img src="img/imagens/formaspagamento.png" width="495" height="88"></div>
<h2><b>Pagamento via Deposito/Transferência</b></h2>
<p>Utilise umas das contas para fazer o deposito ou transfereência bancária. Feito o pagamento basta entrar em contato para confirmar seu pagamento.<br>
  <br>
  <br>
  <img class="img1" src="img/imagens/logobradesco.jpg" width="156" height="116">
  <br>
  <b>Banco:</b> Bradesco
  <br>
  <b>Tipo da conta:</b> Corrente
  <br>
  <b>Conta:</b> 0170906-2
  <br>
  <b>Agência:</b> 0288
  <br>
  <b>Favorecido:</b> ANDRE BARBOSA DE CASTRO<br>
  </p>
<p>&nbsp;</p>
<p><br>
  <br>
  <img class="img1" src="img/imagens/logobb.jpg" width="156" height="116">
  <br>
  <b>Banco:</b> Banco do Brasil (BB)
  <br>
  <b>Tipo da conta:</b> Poupança
  <br>
  <b>Conta:</b> 24.351-5
  <br>
  <b>Agência:</b> 3472-X
  <br>
  <b>Favorecido:</b> ANDRE B CASTRO</p></div>
