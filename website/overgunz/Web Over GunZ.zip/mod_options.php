<?php ("protecao/protect.php");?>
<ul id="ul">
<li><a href="index.php?do=mod_rank">Players</a></li>
<li><a href="index.php?do=mod_clansss">clans</a></li>
</ul>
