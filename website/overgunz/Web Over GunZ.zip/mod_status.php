<?php ("protecao/protect.php");?>
<h1>Informações do Servidor</h1>
<table style="text-align: left; width: 200px; height: 1px;">
  <tbody>
    <tr>
      <td><span class="stado"><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'Gunz Online';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font><br />";
        }
        else
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font><br />";
            fclose($fp);
        }
    }
    ?></span></td>
    </tr>
    <tr>
      <td><span class="stado"><?php
        $ip = '37.59.235.213,1433';
        $port = '7777';
        $name = 'Over Gunz';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font><br />";
        }
        else
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font><br />";
            fclose($fp);
        }
    ?></span></td>
    </tr>
    <tr>
      <td><span class="stado"><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo " Total Online: <strong>$servercount";
    ?></span></td>
    </tr>
    <tr>
      <td><span class="stado"><? //Total Accounts
$query = mssql_query("SELECT * FROM Account");
$num_rows = mssql_num_rows($query);
echo " Total de Contas: ".$num_rows."<n>";

?></span></td>
    </tr>
    <tr>
      <td><span class="stado"><?php

//Total Characters
$query = mssql_query("SELECT * FROM Character");
$num_rows = mssql_num_rows($query);
echo " Total Characters: ".$num_rows."<n>";

?></span></td>
    </tr>
    <tr>
      <td>
      <span class="stado"><?php

//Total Clans
$query = mssql_query("SELECT * FROM Clan");
$num_rows = mssql_num_rows($query);
echo " Total Clans: ".$num_rows."<n>";

?></td></span>
    </tr>
    <tr>
      <td><span class="stado"> Visitas Hoje:
    <?php
$file_count = fopen('counter/count.db', 'rb');
	$data = '';
	while (!feof($file_count)) $data .= fread($file_count, 4096);
	fclose($file_count);
	list($today, $yesterday, $total, $date, $days) = split("%", $data);
	echo $today;
?><span></td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td>

</td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <td></td>
    </tr>
  </tbody>
</table>
