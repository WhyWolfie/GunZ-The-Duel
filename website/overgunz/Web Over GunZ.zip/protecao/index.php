			<div class="contentBox">
              <ul class="rank">

                <h2 class="noMargin">Erro</h2>
<div class="box">A p&aacute;gina solicitada n&atilde;o foi encontrada.</div>
                <br style="clear: both;" />
            </div>
        <br style="clear: both" />