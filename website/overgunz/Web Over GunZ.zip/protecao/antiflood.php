<?
ob_start();
if( !isset( $_COOKIE[ 'LastTime' ] ) || !isset( $_COOKIE[ 'Visitas' ] ) ){
		if( !isset( $_COOKIE[ 'LastTime' ] ) ){
			setcookie( "LastTime", time() );
		}elseif( !isset( $_COOKIE[ 'Visitas' ] ) ){		
			setcookie( "Visitas", 1 );		
		}else{
		}
	}else{
		$nLastTime = $_COOKIE[ 'LastTime' ];
			
		if( time() <= ( $nLastTime + 2 ) ){
			if( $_COOKIE[ 'Visitas' ] > 10 ){
die("<script>alert('Navegue de vagar voc� est� navegando muito rapido.'); location='javascript:history.back()'</script>");
			}
				
			setcookie( "Visitas", ( $_COOKIE[ 'Visitas' ] + 1 ) );
			setcookie( "LastTime", time() );
		}else{
			setcookie( "LastTime", time() );
			setcookie( "Visitas", 1 );
		}
	}
?>