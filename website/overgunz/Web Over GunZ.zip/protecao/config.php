<?php ("protecao/protect.php");?>
<?php
$link = mssql_connect("ADVENTUR-3E5B85\SQLEXPRESS","sa","123456");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'ADVENTUR-3E5B85\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User
$DBPass = 'glaizan'; //Your DB Password
$DB = 'GunzDB'; //Your GunZ DB

//////CONFIGURAR BONUS AO CADASTRAR/////////
$evcoins = "40";// ganha EVCoins ao cadastrar
$rzcoins = "0"; // ganha RZCoins ao cadastrar
////////------------------/////////
$titulosite = "Over Gunz - O melhor server de gunz online"; // -- Titulo do site
$nomeserver = "Over Gunz"; // -- Nome do server
$ip="37.59.235.213"; // -- IP para verificar status
$portmg = "7777"; // -- Porta do master agent

//////CONFIGURAR DOWNLOADS/////////
// -- Download 1
$down1 = "Client Completo";  // Descricao
$down1link = "http://www.infodcastro.com"; // Link
$down1tam = "230 mb"; // Tamanho
// -- Download 2 ( Patch )
$patch = "Patch"; // Descricao
$patchlink = "http://www.infodcastro.com"; // Link
$patchtam = "15 mb"; // Tamanho


?>
