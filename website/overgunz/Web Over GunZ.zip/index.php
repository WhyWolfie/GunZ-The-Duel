﻿ee<?php ("protecao/protect.php");?>
<?php
include "config.php";
include "_functions.php";
include "banned.php";
include "banneduser.php";
//include "checkcookie.php";
include "title.php";
include 'antisql.php';
include 'inject.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>
<?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link href="estilo.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$titulosite?></title>
<link href="estilo.css" rel="stylesheet" type="text/css" />
</head>

<body>
<!-- essa div aqui que centraliza td macho-->
<div id="centro">
<!--topo-->
<div id="topo">
<div class="logo">
</div>
<!--status-->
<div id="status"><img class="status" src="img/icones/sq_br_next.png" />Servidor<?php
        $ip = '37.59.235.213';
        $port = '7777';
        $name = '';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font>";
        }
        else
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font>";
            fclose($fp);
        }
    ?>
  
<img class="status" src="img/icones/sq_br_next.png" />  <?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp&nbsp&nbsp&nbspJogadores On: <strong>$servercount";
    ?></div><!--status-->
<!--menu-->
<div id="menu">
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="index.php?do=register">Registro</a></li>
<li><a href="index.php?do=download">Download</a></li>
<li><a href="index.php?do=ranking">Rank</a></li>
<li><a href="index.php?do=selec">Loja</a></li>
<li><a href="index.php?do=donator">Doação</a></li>
<li><a href="index.php?do=status">Status</a></li>
<li><a href="http://dragongamerz.net/forum/board/upload/">Forum</a></li>

</ul>
</div><!--menu-->
</div><!--topo-->
<!--conteudo-->
<div id="conteudo">
<!--lateral-->
<div id="lateral">
    <div id="boxesq">
  <h1>login</h1>
  <img src="img/imagens/fita.png" />
  <?php include "mod_iLogin.php"?> 
      </div>
      <div id="boxesq">
  <h1>Ranking</h1>
  <img src="img/imagens/fita.png" />
  
<?
  include "top_rank.php"
  ?>
 
      </div>
      <div id="boxesq">
  <h1>Ranking Clan</h1>
  <img src="img/imagens/fita.png" /> 
<? include "mod_clanranking.php" ?>
      </div>
</div>
<!--lateral-->
<!--conteudodireita-->
<div id="conteudoright">

<!-- INICIO SCRIPT CONTEUDO -->
<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "mod_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
<!-- FIM SCRIPT CONTEUDO -->
</div>
<!--conteudodireita-->
</div>
<!--conteudo-->
<div id="clear">
<p class="bottom">Copyright © 2010 OverGunz.com. Todos Direitos Reservados
Gunz é uma marca registrada pela Maiet Entertainment
Over Gunz é um servidor totalmente gratuito, as doações são utilizadas para cobrir os gastos do servidor web site feito por marcos.<p>
</div>
</div>

<!--div centro fechada-->

</body>
</html>
