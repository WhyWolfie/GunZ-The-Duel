<?php ("protecao/protect.php");?>
<?
$res = mssql_query("SELECT TOP 10 *, EmblemUrl FROM Clan WHERE Deleteflag = 0 ORDER BY Point DESC");

while($item = mssql_fetch_assoc($res))
{


if($item['EmblemUrl'] == NULL){
?>

                            	<li class="border">
                                	<div class="li_left">
                                    	<span><img src="http://img820.imageshack.us/img820/5031/noemblem.png" width="20" height="20"></span>
                                    </div>
                                    <div class="li_middle">
                                    	<span><a href="?gz=infoclan&CLAN=<?=$item['Name']?>"><?=$item['Name'] ?></a></span>
                                    </div>
                                    <div class="li_right">
                                        <span class="li_right_mid_span"><?=$item['Point'] ?></span>
                                    </div>
                                </li>

<?
}else{
?>

                            	<li>
                                	<div class="li_left">
                                    	<span><img src="http://zxt.no-ip.org/Emblem/<?=($item['EmblemUrl'] == "") ? 'Img/no_emblem.jpg' : $item['EmblemUrl']?>" width="20" height="20"></span>
                                    </div>
                                    <div class="li_middle">
                                    	<span><a href="?kog=infoclan&CLAN=<?=$item['Name']?>"><?=$item['Name'] ?></a></span>
                                    </div>
                                    <div class="li_right">
                                        <span class="li_right_mid_span"><?=$item['Point'] ?></span>
                                    </div>
                                </li>

<?
}
}
?>
