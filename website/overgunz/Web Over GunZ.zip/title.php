<?php ("protecao/protect.php");?>
<?
switch ($_GET['do']){
        case "":
            $pagetitle = "Inicio";
    break;
        case "register":
            $pagetitle = "Registro";
    break;
        case "downloads":
            $pagetitle = "Downloads";
    break;
        case "userpanel":
            $pagetitle = "Painel de Clan";
    break;
        case "ranking":
            $pagetitle = "Ranking";
    break;
        case "rzitemshop":
            $pagetitle = "WebStore";
    break;
        case "evitemshop":
            $pagetitle = "EvStore";
    break;
	    case "donate":
            $pagetitle = "Donate";
    break;
	       case "gift";
            $pagetitle = "Gift RZ Coins";
    break;
	       case "rzgift";
            $pagetitle = "Gift RZ Coins";
    break;
	       case "evgift";
            $pagetitle = "Gift EV Coins";
    break;
        case "rzadditem";
            $pagetitle = "Add RZ Shop Item";
    break;
        case "evadditem";
            $pagetitle = "Add EV Shop Item";
    break;
        case "addindexcontent";
            $pagetitle = "Add Annoucements / Updates";
    break;
        case "login";
            $pagetitle = "Login";
    break;
        case "banuser";
            $pagetitle = "Ban user";
    break;
        case "muteuser";
            $pagetitle = "Mute user";
    break;
        case "ipbanuser";
            $pagetitle = "IP ban user";
        case "premiacao";
            $pagetitle = "Premia��o Rank Cl�s";
        case "regras";
            $pagetitle = "Regras";

}

//

switch ($_GET['sub']){
        case "individual":
            $pagetitle = "Player Ranking";
    break;
        case "clan":
            $pagetitle = "Clan Ranking";
    break;
        case "hof":
            $pagetitle = "Hall Of Fame";
    break;
        case "viewmyitems";
            $pagetitle = "View my Items";
    break;
        case "details";
            $pagetitle = "Details";
    break;
        case "buyitem";
            $pagetitle = "Buy item";
    break;
        case "announcement";
            $pagetitle = "Announcement";
    break;
        case "update";
            $pagetitle = "Update";
    break;

}

//

switch ($_GET['action']){
        case "resetpwd":
            $pagetitle = "Reset Password";
    break;

}

//

switch ($_GET['act']){
        case "editinfo";
            $pagetitle = "Edit Account";
    break;


}
?>
