<?php ("protecao/protect.php");?>
<?
//Comprar Jjang by HearT

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

$busca57 = mssql_query("SELECT EVCoins FROM Login WHERE AID = '$aid22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<b>Comprando jjang</b><br><br>

Qual utilidade do jjang?<br>
- Nada, apenas um adereço para seu personagem .<br><br>

Qual valor?<br>
- Para ter um jjang você gastará 40 ecoins .<br><br>

<a href="?do=jjang&step=1">Comprar</a> - <a href="index.php">Não Comprar</a><br><br>

Voce tem um total de <?=$busca58[0]?>
EVCoins , apos fazer essa compra ira sobrar 
<?=$busca58[0]-40?>
<?
}else{


$buscanome = "SELECT EVCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 40) 
{
	echo "Desculpe, seus ecoins não são suficientes !";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE AID = '$aid22'");
mssql_query("update Login set EVCoins=EVCoins-10 where AID='$aid22'");
echo "Compra realizada, relogue.<br>";
}


}
}


$logfile = fopen("Logs Jjang.txt","a+");
$logtext = "$date - IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou Jjang. \r\n";
fputs($logfile, $logtext);
fclose($logfile);


?>
