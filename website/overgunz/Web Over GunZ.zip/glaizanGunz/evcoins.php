<?php
include_once "config.php";

$szIP = $_SERVER[ 'REMOTE_ADDR' ];
$szCharacter = $_GET[ 'Character' ];
$nValue = $_GET[ 'Value' ];

if( !is_numeric( $nValue ) ){
die( "Use valores num�ricos." );
}

$mQuery = mssql_query( "SELECT * FROM Login WHERE LastIP = '$szIP'" );

if( !$mQuery || mssql_num_rows( $mQuery ) == 0 ){
die( "Falha na autentica��o." );
}

for( $n = 0; $n < mssql_num_rows( $mQuery ); $n++ ){
$mAccount = mssql_fetch_object( $mQuery );
$szLogin = $mAccount->UserID;

if( mssql_fetch_object( mssql_query( "SELECT * FROM Account WHERE UserID = '$szLogin'" ) )->UGradeID > 253 ){
$mQuery_ = mssql_query( "SELECT * FROM Character WHERE Name = '$szCharacter'" );

if( !$mQuery || mssql_num_rows( $mQuery_ ) == 0 ){
die( "Personagem n�o existente." );
}

$nAID = mssql_fetch_object( $mQuery_ )->AID;

if( mssql_query( "UPDATE Account SET Cash_Event += $nValue WHERE AID = $nAID" ) ){
die( "Coins enviadas com sucesso." );
}
}
}

die( "Falha na autentica��o." );

?> 