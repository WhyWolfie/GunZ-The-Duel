<?php
///////// CONFIGURA CONEXAO ////////////////////
$link = mssql_connect("37.59.235.213,1433","sa","123456");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

$DBHost = '37.59.235.213,1433'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = 'gabigabi'; //Your DB Password
$DB = 'GunzDB'; //Your GunZ DB
?>
