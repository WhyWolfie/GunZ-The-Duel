
<?
include "config.php";
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
?>
<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<html>
<head>
</head>
<body >
<p>&nbsp;</p>
<h1>Bem vindo ao Servidor <?=$nomeserver?></h1>
<div align="center"><?php include "slide/slide.html"?></div>
<div id="att"">


   
    <h1>Noticias e novidades</h1>
        <div id="noticias"><h2> &Uacute;ltimas
Not&iacute;cias </h2>


 
     <? $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
      while($n = mssql_fetch_assoc($res)){ ?>
      <a href="index.php?do=indexcontent&sub=announcement&id=<?=$n['ICID']?>">
      <span class="title"><?=$n['Title']?></span></a>
      <?}?>
   
   
   </div>
   
      <div id="noticias" style=" border-left:1px #333 dotted;"><h2>
&Uacute;ltimas Atualiza&ccedil;&otilde;es </h2>
   
      <? $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
      while($n = mssql_fetch_assoc($res)){?>
      <a href="index.php?do=indexcontent&sub=update&id=<?=$n['ICID']?> ">
	  <span class="title"><?=$n['Title']?></span></a>
      <?}?>
   </div></div>
    <div class="bgultimos">
    <h1>Itens novos no shop </h1>
<div id="inline"><? include "inject.php" ?>
<?
if(!function_exists("ListLatestItens")){
function ListLatestItens(){


    $res = mssql_query("SELECT TOP 4 * FROM RZCashShop WHERE Opened = '1'");

    ?>

      <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 0) {
                                                $count = 1;
                                                echo " ";
                                                ?>

            <span style="z-index:-1;"><img class="borda" id="borda" src="shop/<?=$item['WebImgName']?>"  width="80" height="80"></span>
            <p class="estilo"><?=$item['Name']?></p>
           <p class="estilo">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></p>
            <p class="estilo">Nível: <?=$item['ResLevel']?></p>
            <p class="estilo">Preço: <?=$item['CashPrice']?></p>
            <a class="comprar" href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>">comprar</a>
               <?
                                            }else{
                                                ?></div>
       <!--   Segunda div -->
          
           <div id="inline">
            <img  class="borda" id="borda" src="shop/<?=$item['WebImgName']?>"  width="80" height="80">
            <p class="estilo"><?=$item['Name']?></p>
         <p class="estilo">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></p>
            <p class="estilo">Nível: <?=$item['ResLevel']?></p>
           <p class="estilo">Preço: <?=$item['CashPrice']?></p>
            <a class="comprar" href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>">Comprar</a>
                    <?
                                                 $count++;
                                            }
                                        }   ?></div>
         
</div>
</body>
</html>
       <?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "";
        ListLatestItens();
    break;
}
}

?>



