﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sem título</title>
</head>

<body>
<p>
  <style>
#ctd { background:#000; color:#666; border:1px solid #666; float:left; width:500px;}
#ctddireito{ background:#CCC; float:left; width:500px;}
  </style>

<body>
<div id="ctd">tonteudo <ul><li><a href="?area=home.php">Home</a></li>
<li><a href="?area=test1">test1</a></li>
<div id="ctddireito">
  <?php

$area = $_GET["area"];

switch ($area)
{
    default:
        include "home.php";

        break;

    case"test1":
        include "test1.php";
        break;

    case"curiosidade":
        include "curiosidade.html";
        break;

    case"contato":
        include "formulario_email.php";
        break;

    case"localizacao":
        include "localizacao.html";
        break;
                
        case"noticias":
        include "noticias/listar-noticias.php";
        break;
                
                
                

}

?>
</div>
</ul>
</div>
</p>
</body>
</html>