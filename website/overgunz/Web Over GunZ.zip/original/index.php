<?
//Web Site Coded By Marcos

session_start();
include "kog/protect/config.php";
include "kog/protect/configs.php";


$pagina_site = $_GET['kog'];

if($pagina_site == ""){
$pagina_site = "Home";
}
?>

<html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html xmlns="http://www.w3.org/1999/xhtml">


</style>
<head>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/coin-slider.min.js"></script>
<script src="js/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="js/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<link href="estilo.css" rel="stylesheet" type="text/css" />
</head>
<title>King of Gunz</title>
<body >

<div id="menu"><div class="menu">
<ul>
<!--inicio-->

<li ><a href="index.php " class="home">home</a></li>

<li><a href="?kog=registro" >registro</a></li>

<!--fim-->

<!--inicio--><li><a href="?kog=download">downloads</a></li>
<!--começo-->
<li><a href="?kog=ranking">ranking</a></li>
<!--fim-->
<!--começo--><li><a href="?kog=shop">loja</a></li>

<!--começo-->
<li><a href="?kog=donator">doação</a></li><!--fim-->
<!--inicio-->
<li><a href="#">status</a></li>
<!--inicio-->
<li><a href="#">forum</a></li>
<!--fim-->
<!--inicio-->
<li><a href="#">regras</a></li>
<!--fim-->
</ul>
</div><!--fimmenu--></div>
<div id="banner"><div class="banner">
<div class="status">
  <?
$busca99 = mssql_query("SELECT CurrPlayer FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$playerson = mssql_fetch_row($busca99);
        
        $ip = 'zxt.no-ip.org';
        $port = '2350';
        $name = 'Servidor';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; $name: <font style='color: #FF3300'><B>Offline</B></font>";
        }
        else
        {
            echo "&nbsp; $name: <font style='color: #66F212'><B>Online</B></font>";
            fclose($fp);
        }
?>
&nbsp;&nbsp;Players Online:
<?=$playerson[0]?>
</div>
</div></div>
<div id="conteudo">
<div id="boxesq">
<!--abri--><div class="boxesq">
<h1>login</h1>
<!--abri--><div class="ctdlogin">
<?
include "kog/logar.php";
?>
</div>
<!--fecha ctdlogin-->
</div>
<!--inicio-->
<div class="boxesq">
<?
include "kog/rkg.php";
?>

</div>

<!--fecha box esq--></div>
<!--inicia--><div id="boxdireito">
<div class="boxdireito"><h1>king of gunz</h1>
<? include "kog/inc.php" ?>
</div><!--fecha--></div>
</div>
<div id="clear"></div>
</div>
<div id="rodape">
<div class="rodape">Copyright &copy; 2010 kingofgunz.com. Todos Direitos Reservados<br />
  Gunz &eacute; uma marca registrada pela Maiet Entertainment<br />
King of Gunz &eacute; um servidor totalmente gratuito, as doa&ccedil;&otilde;es s&atilde;o utilizadas para cobrir os gastos do servidor.</div></div>
  
</body>
</html>
