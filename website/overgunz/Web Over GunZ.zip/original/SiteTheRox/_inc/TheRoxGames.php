<br />
<b class="comodoar2"><font type="Verdana"  color="red">The Rox Games -  Xat <font type="Verdana"  color="white"> The Rox</b><br /> <br />

<embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="500" height="400" name="chat" FlashVars="id=133858153&rl=Brazilian" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" /><br><small><a target="_BLANK" href="http://xat.com/web_gear/?cb"></a> <a target="_BLANK" href="http://xat.com/web_gear/chat/go_large.php?id=133858153"></a></small><br>



<b class="comodoar2"><font type="Verdana"  color="white">Autor: Yakow</b><br /> <br />
<font color="white">Email: therox@hotmail.com.br - Skype: theroxgunz</font><br>
<font color="black"></b><br /> <br />

<b class="comodoar2"><font type="Verdana"  color="white"> Regras do Xat - The Rox Gunz  <font type="Verdana"  color="white"></b><br /> <br />
<b class="comodoar2"><font type="Verdana"  color="white">1 - Proibido Links na Casinha , e Divulgar Qual quer Tipo de coisa.</b><br /> 
<b class="comodoar2"><font type="Verdana"  color="white">2 - Nao xingar e nao falar palavrao no Xat. </b><br /> 
<b class="comodoar2"><font type="Verdana"  color="white">3 -  usar o mesmo NICK usado no forum. </b><br /> 
<b class="comodoar2"><font type="Verdana"  color="white">4 - Para quem Divulgar o Gunz e o Xat = Moderador. </b><br /> 
<b class="comodoar2"><font type="Verdana"  color="white">5 - Proibido Flodar Mensagens , Banned de 4 Horas. </b><br /> <br />

<h2><span><span></span>
TheRox GunZ - Equipe
</span>
</h2>
<br>


<a href="?gz=infoplayer&Yakow"><font color=#00FFFF>Yakow</font></a> - Fundador<br>
<a href="?gz=infoplayer&Gaspar"><font color=#00FFFF>Gaspar</font></a> - Administrador Geral / PHP Coder<br>
<a href="?gz=infoplayer&YgorReis"><font color=#00FFFF>Ygor</font></a> - Administrador Geral<br>
<br>
<a href="?gz=infoplayer&Lucas"><font color=darkorange>Lucas</font></a> - Game Master / Designer<br>
<a href="?gz=infoplayer&Allan"><font color=darkorange>Allan</font></a> - Game Master / Designer<br>
<a href="?gz=infoplayer&Lucas"><font color=darkorange>iFaary</font></a> - GM Custom Itens / Forum<br>
<br>
<a href="?gz=infoplayer&iFaary"><font color=lightblue>Caio</font></a> - MOD Event / Forum<br>
<a href="?gz=infoplayer&Xacau"><font color=lightblue>Xacau</font></a> - MOD Event / Forum<br>
