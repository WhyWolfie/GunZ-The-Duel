<?
//Informa��es do usu�rio. Coded By Gaspar

$AID = Filtrrar($_GET['aid']);

$query1 = mssql_query("SELECT Name, Age, RegDate, UGradeID FROM Account WHERE AID = '$AID'");
$query2 = mssql_fetch_row($query1);

echo "<center>";
echo "<b>Informa��es do usu�rio:</b><br><br>";
echo "Nome: $query2[0] <br>";
echo "Idade: $query2[1] <br>";
echo "Cadastrado em: $query2[2] <br>";

switch($query2[3]){
case 255: $rank = "<font color=#00FFFF>Administrador"; break;
case 254: $rank = "<font color=#00EE00>Game Master"; break;
case 253: $rank = "<font color=gray><strike>Banido"; break;
case 104: $rank = "<font color=gray>Chat Blocked"; break;
case 2: $rank = "<font color=yellow>Event Winner"; break;
case 0: $rank = "<font color=white>Player"; break;
}

echo "Ranking: $rank </font><br><br>";
echo "</center>";
?>