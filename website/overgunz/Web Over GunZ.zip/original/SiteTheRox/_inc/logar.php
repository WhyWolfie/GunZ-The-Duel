<?

if(isset($_POST[submit]))
{

//Anti SQL injection.
function antisql($value)
{
        $check = $value;

        $value = preg_replace(sql_regcase("/(from|select|update|account|login|clan|character|indexcontent|set|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);

        if( $check != $value )
        {
            $logf = fopen("sqllog.txt", "a+");
            fprintf($logf, "Date: %s - IP: %s - C�digo: %s, - Correto: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
        }

        return( $value );
}

    $user = antisql($_POST[userid]);
    $pass = antisql($_POST[pass]);

    $ip = $_SERVER['REMOTE_ADDR'];

    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
	
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
	alertbox("Voc� falhou 5 vezes para efetuar o login, aguarde 15 minutos e tente novamente.","index.php");
    die();
}
    $loginquery = mssql_query("SELECT UserID, AID, Password FROM Login WHERE UserID = '$user' AND Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $busca1 = mssql_query("SELECT UGradeID FROm Account WHERE USerID = '$user'");
        $busca2 = mssql_fetch_row($busca1);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION["login"] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];

        if(mssql_num_rows(mssql_query("SELECT * FROM LoggedUsers WHERE AID = '$logindata[1]'")) == 0)
        {
        mssql_query("INSERT INTO LoggedUsers (AID, UserID, UGradeID, Date, time) VALUES ('$logindata[1]', '$logindata[0]', '$busca2[0]', GETDATE(), '" . time() . "')");
        }

        echo "Obrigado, por se logar $user. Aguarde enquanto voc� � redirecionado...";
        echo '<meta HTTP-EQUIV = "Refresh" CONTENT = "3; URL = index.php">';

    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
    alertbox("Usuario ou senha incorretos.","index.php");
    die();
	}

}else{
echo "You fail O_O";
}
?>