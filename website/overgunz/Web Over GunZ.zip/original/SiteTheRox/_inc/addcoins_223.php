<?
//Script By:Gaspar ;D

if (!(isset($_POST['nick2'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=addcoins_223">
<input type="text" id="nick2" value="Nick Do Preto" class="log_field" size="16" name="nick2" value="" maxlength="20"><br>
<input type="text" id="coins" value="EVCoins" class="log_field" size="16" name="coins" value="" maxlength="20"><br><br>
<input type="submit" name="logar" value="Adicionar!" />
</form>
<?
}else{

$login22 = $_SESSION["login"];

$busca3 = mssql_query("SELECT UGradeID FROm Account WHERE UserID = '$login22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255 OR $busca4[0] == 254){

$nick11 = Filtrrar($_POST['nick2']);
$coins11 = Filtrrar($_POST['coins']);

$busca1 = mssql_query("SELECT AID FROM Character WHERE Name = '$nick11'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("O Char do preto que vc digitou n exite D:");
}else{
mssql_query("UPDATE Account SET EVCoins=EVCoins +$coins11 WHERE AID = '$busca2[0]'");
echo "$coins11 EVCoins foram adicionados para o usuario do Char $nick11";
}

}else{
echo "Voce nao tem permissao para acessar esta area";
}
}
?>