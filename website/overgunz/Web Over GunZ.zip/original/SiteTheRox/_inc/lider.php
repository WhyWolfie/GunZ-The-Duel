<?
//Script By Gaspar ;D

$login22 = Filtrrar($_SESSION["login"]);

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$query1 = mssql_query("SELECT TOP 1 CID, Name FROM Character ORDER BY XP DESC");
$query2 = mssql_fetch_row($query1);

$query3 = mssql_query("SELECT AID FROM Account WHERE UserID = '$login22'");
$query4 = mssql_fetch_row($query3);


$query5 = mssql_query("SELECT * FROM Character WHERE CID = '$query2[0]' AND AID = '$query4[0]'");
$query6 = mssql_fetch_row($query5);

if($query6[0] == 0)
{
echo "Desculpe, para ganhar a Coat Top 1 voc� prescisa ser o TOP 1 no ranking de players!";
}else{

//6500105 Male
//6500104 female

mssql_query("DELETE FROM CharacterItem WHERE ItemID = '6500105'");
mssql_query("DELETE FROM CharacterItem WHERE ItemID = '6500104'");

$busca89 = mssql_query("SELECT TOP 6 CID, Sex FROM Character WHERE AID = '$query4[0]' ORDER BY XP DESC");
while ($busca90 = mssql_fetch_row($busca89)){

if($busca90[1] == 1){
mssql_query("INSERT INTO CharacterItem (CID, ItemID) VALUES ('$busca90[0]', '6500104')");
}

if($busca90[1] == 0){
mssql_query("INSERT INTO CharacterItem (CID, ItemID) VALUES ('$busca90[0]', '6500105')");
}


} //Fim da While

echo "Obrigado, a Coat Lider do Ranking ja est� em seu equipamento de todos os seus characters!";

}
}
?>