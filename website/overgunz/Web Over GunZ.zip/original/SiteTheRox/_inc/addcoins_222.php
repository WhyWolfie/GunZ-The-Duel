<?
//Script By:Gaspar ;D

if (!(isset($_POST['login2'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=addcoins_222">
<input type="text" id="login2" value="Login" class="log_field" size="16" name="login2" value="" maxlength="20"><br>
<input type="text" id="coins" value="Coins" class="log_field" size="16" name="coins" value="" maxlength="20"><br><br>
<input type="submit" name="logar" value="Adicionar!" />
</form>
<?
}else{

$login22 = $_SESSION["login"];

$busca3 = mssql_query("SELECT UGradeID FROm Account WHERE UserID = '$login22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255){

$login11 = Filtrrar($_POST['login2']);
$coins11 = Filtrrar($_POST['coins']);

$busca1 = mssql_query("SELECT AID FROM Account WHERE UserID = '$login11'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("Esta Conta Nao Existe!");
}else{
mssql_query("UPDATE Account SET Coins=Coins +$coins11 WHERE AID = '$busca2[0]'");
echo "$coins11 Coins foram adicionados para o usuario $login11";
}

}else{
echo "Voce nao tem permissao para acessar esta area";
}
}
?>