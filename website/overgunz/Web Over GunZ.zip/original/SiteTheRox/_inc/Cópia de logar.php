<?

if(isset($_POST[submit]))
{
    $user = $_POST[userid];
    $pass = $_POST[pass];

    $ip = $_SERVER['REMOTE_ADDR'];

    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
	
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
	alertbox("Voc� falhou 5 vezes para efetuar o login, aguarde 15 minutos e tente novamente.","index.php");
    die();
}
    $loginquery = mssql_query("SELECT UserID, AID, Password FROM Login WHERE UserID = '$user' AND Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION["login"] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];
        echo "Obrigado, $user seja bem-vindo(a) ao Snow Gunz!";

    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
    alertbox("Usuario ou senha incorretos.","index.php");
    die();
	}

}else{
?>



<form name="login" method="POST" action="index.php?gz=logar"><table width="180" height="0" border="0" align="center" cellpadding="0" cellspacing="0">
<table width="150" height="150" border="0" cellpadding="0" cellspacing="0" align="center">
  <tr>
    </tr>
  <tr>
    <td height="40"><table width="50" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      </tr>
      <br>
      <tr>
        <td align="right" height="0"><input name="userid" type="text" value="Login" tabindex="1" value="" maxlength="14"></td>
      </tr>
      <tr>
        <td align="right" height="50"><input name="pass"  type="password" value="Senha" tabindex="2" maxlength="14"></td>
      </tr>
      <input type="hidden" name="submit" value="1">
    </table></td>
  </tr>
  <tr>
    <td align="right"><table width="150" border="0" align="right">
      <tr>
        <td align="right" height="1"></td>
      </tr>
      <tr>
        <td align="right"><a href="index.php?gz=cadastro">Cadastro</a></td>
        <td align="right"><a href="index.php?gz=recupera_senha&etapa=1">Esqueceu a senha?</a> </td>
      </tr>
      <tr>
        <td width="54" align="right" colspan="2"><input name="login" type="submit" id="login" align="right" value="Logar"></td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
<?
}
?>