<?
//Script Desenvolvido por Gaspar

$clan2 = Filtrrar($_GET['CLAN']);

$buscanome2222 = "SELECT Point, MasterCID, Wins, RegDate, Losses, Draws, Ranking, TotalPoint, EmblemUrl, CLID FROM Clan  WHERE Name = '$clan2'";
$resultado444 = mssql_query($buscanome2222);
$result222 = mssql_fetch_array($resultado444);

if (isset($result222[0])) {

$buscanome2223 = "SELECT Name from Character  WHERE CID = '$result222[1]'";
$resultado443 = mssql_query($buscanome2223);
$result255 = mssql_fetch_array($resultado443);

echo "<font color=white>";
echo "<font size=5>Informacoes Do Clan $clan2</font><br><br>";
echo "<br>";

if($result222[8] == NULL){
?>
<img src="http://img820.imageshack.us/img820/5031/noemblem.png">
<?
}else{
?>
<img src="http://zxt.no-ip.org/Emblem<?=$result222[8]?>">
<?
}
echo"<br>";

echo "Nome: $clan2 <br>";
echo "Votorias: $result222[2]<br>";
echo "Derrotas: $result222[4]<br>";
echo "Empates: $result222[5]<br>";
echo "Pontos: $result222[0]<br>";
echo "Pontos Totais: $result222[7]<br>";
echo "Ranking: $result222[6]<br>";
echo "Fundado Em: $result222[3]<br>";
echo "Lider: $result255[0]<br>";
echo "<br>";
echo "<br>";
echo "Ultimas Guerras De Clan:";
echo "<br>";

$clan_cw = mssql_query("SELECT TOP 7 RoundWins, RoundLosses, RegDate, WinnerClanName, LoserClanName  from ClanGameLog  WHERE (LoserClanName = '$clan2' OR WinnerClanName = '$clan2') ORDER BY RegDate DESC");
while($clan_cw2 = mssql_fetch_row($clan_cw)){

if($clan_cw2[3] == $clan2){ //Clan Winou
echo"O cla $clan2 derrotou o cla $clan_cw2[4] por $clan_cw2[0] a $clan_cw2[1] em $clan_cw2[2]";
echo "<br>";
}

if($clan_cw2[4] == $clan2){ //Clan Losou
echo"O cla $clan_cw2[3] derrutou o cla $clan2 por $clan_cw2[0] a $clan_cw2[1] em $clan_cw2[2]";
echo "<br>";
}

}

echo "<br>";
echo "Membros Do Clan:";
echo "<br>";

$membros = mssql_query("SELECT CID, Grade, RegDate, ContPoint FROM ClanMember WHERE CLID = '$result222[9]' ORDER BY Grade ASC");
while($membros2 = mssql_fetch_row($membros)){

$membros3 = mssql_query("SELECT Name FROM Character WHERE CID = '$membros2[0]'");
$nome = mssql_fetch_row($membros3);

switch($membros2[1]) {
	case 9: $autoridade = "Membro"; break;
	case 2: $autoridade = "<font color=red>Administrador"; break;
	case 1: $autoridade = "<font color=red>L�der"; break;
}

echo "Nome:$nome[0] - Autoridade:$autoridade</font> - PontosCW:$membros2[3] - Membro Desde:$membros2[2]";
echo "<br>";

}

} else {
echo "O clan $clan2 nao existe.";
}

?>