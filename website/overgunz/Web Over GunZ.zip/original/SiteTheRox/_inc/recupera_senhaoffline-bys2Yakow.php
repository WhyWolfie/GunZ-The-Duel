<?
//Script Desenvolvido por Gaspar ;D

$etapa = Filtrrar($_GET['etapa']);


if($etapa == NULL){
echo "You Fail xD Gaspar Owna";
}else{

if($etapa == 1)
{
?>
Etapa 1/4<br>
<form name="recupera_senha" method="POST" action="index.php?gz=recupera_senha&etapa=2">
<input name="login_22" type="text" value="Digite Seu Login" tabindex="1" value="" maxlength="14">
<input type="hidden" name="etapa1" value="1">
<input name="login_2" type="submit" id="login" align="right" value="Poxima ->">
</form>
<?
}

if($etapa == 2){
if(isset($_POST[etapa1]))
{

$login23 = Filtrrar($_POST['login_22']);

$busca1 = mssql_query("SELECT Sq, Sa FROM Account WHERE UserID = '$login23'");
if(mssql_num_rows($busca1) == 1){

$busca2 = mssql_fetch_row($busca1);
?>
Etapa 2/4<br>
Voce tera que responder a sua pergunta Secreta para recuperar sua senha<br><br>
Pergunta: <?=$busca2[0]?><br><br>
<form name="recupera_senha" method="POST" action="index.php?gz=recupera_senha&etapa=3">
<input name="resposta_22" type="text" value="Digite Sua Resposta" tabindex="1" value="" maxlength="14">
<input type="hidden" name="etapa2" value="1">
<input name="login_3" type="submit" id="login" align="right" value="Poxima ->">
</form>
<?
$_SESSION["login_recupera222"] = Filtrrar($login23);
}else{
echo "Desculpe, nao encontramos nenhum login chamado $login23 em nosso banco de dados";
}
}else{
echo "You Fail xD Gaspar Owna";
}
}

if($etapa == 3){
if(isset($_POST[etapa2]))
{

$resposta22 = Filtrrar($_POST['resposta_22']);
$login_recupera = Filtrrar($_SESSION["login_recupera222"]);

$busca3 = mssql_query("SELECT Sq, Sa FROM Account WHERE UserID = '$login_recupera' AND Sa = '$resposta22'");
if(mssql_num_rows($busca3) == 1){
?>
Etapa 3/4<br>
<form name="recupera_senha" method="POST" action="index.php?gz=recupera_senha&etapa=4">
<input name="newsenha" type="text" value="Digite Sua Nova Senha" tabindex="1" value="" maxlength="14">
<input type="hidden" name="etapa3" value="1">
<input name="login_4" type="submit" id="login" align="right" value="Poxima ->">
</form>
<?
}else{
echo "Resposta errada, tente novamente.";
}
}else{
echo "You Fail xD Gaspar Owna";
}
}

if($etapa == 4){
if(isset($_POST[etapa3]))
{
echo 'Etapa 4/4<br>';

$novasenha = Filtrrar($_POST['newsenha']);
$login_recupera = Filtrrar($_SESSION["login_recupera222"]);

$update = "UPDATE Login SET Password = '$novasenha' WHERE UserID = '$login_recupera'";
if(mssql_query($update) == 1){

echo "Senha alterada com sucesso!";


}else{
echo "Desculpe, Ocorreu algum erro";
}



}else{
echo "You Fail xD Gaspar Owna";
}
}



}
?>