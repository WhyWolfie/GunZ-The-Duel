<?
//Script De Continua��o Do Retorno Automatico Pag Seguro
//Copyright Gaspar�

//Verificando o Token!
$Token22 = Filtrrar($_GET['Token']);

$query1 = mssql_query("SELECT Utiliza��o FROM Tokens WHERE Token = '$Token22'");
$query2 = mssql_fetch_row($query1);

if($query2[0] == 22){

//Busca Sess�o login
$login22 = $_SESSION['login'];

//Verificando o ID!
$TransacaoID = Filtrrar($_GET['ID']);

if($TransacaoID == ""){
echo "n�o � possivel identificar o ID Da Transa��o";
die();
}

//Atualiza o Login na tabela da compra
$atualiza = mssql_query("UPDATE PagSeguro SET Login = '$login22' WHERE TransacaoID = '$TransacaoID'");

//Modifica o Token para ele n�o utilizar novamente
$update_token = mssql_query("UPDATE Tokens SET Utiliza��o ='0' WHERE Token = '$Token22'");

?>


Obrigado, sua compra foi concluida!<br>

Caso voc� tenha pagado com boleto banc�rio ou cart�o de cr�dito, n�s estamos aguardando a confirma��o do pagamento para deposito dos coins.<br><br>

Voc� pode acompanhar o status seu pagamento e da libera��o dos coins pelo painel do usu�rio-> Mais Op��es-> Meus Pagamentos<br><br>

TheRox agradece a sua colabora��o.

<?
}else{
echo "Desculpe este Token N�o � v�lido";
}
?>