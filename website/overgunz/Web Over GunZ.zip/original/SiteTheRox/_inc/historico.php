<font size=3>Hist�rico De Compras</font><br><br>
<?
//Historico de compras By Gaspar =P

$login89 = $_SESSION["login"];

$query1 = mssql_query("SELECT ID, Item, ItemID, Data, Coins, Presenteado, Tipo FROM Compras WHERE Login = '$login89'");

while($row2 = mssql_fetch_row($query1)){

switch($row2[5])
{
	case NULL: $tipo = ""; break;
	case true: $tipo = "(Presente)"; break;
}
?>

<a href="?gz=info_compra&ID=<?=$row2[0]?>"><?=$row2[1]?></a> <?=$tipo?> - <?=$row2[4]?> Coins <br>

<?
}
?>
