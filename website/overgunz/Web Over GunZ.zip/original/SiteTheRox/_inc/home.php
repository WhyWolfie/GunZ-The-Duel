Seja Bem-Vindo(a) ao site do TheRox, desfrute ao maximo de nosso servidor.<br><br>

<?
$busca99 = mssql_query("SELECT CurrPlayer FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$playerson = mssql_fetch_row($busca99);
        
        $ip = 'zxt.no-ip.org';
        $port = '2350';
        $name = 'Servidor';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; $name: <font style='color: #FF3300'><B>Offline</B></font><br />";
        }
        else
        {
            echo "&nbsp; $name: <font style='color: #66F212'><B>Online</B></font><br />";
            fclose($fp);
        }
?>

Players Online: <?=$playerson[0]?><br>

<?
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Total Clans: ".$num_rows."<n>";
echo '<br>';
?>
Banidos: <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='253'")); ?><br>
Mudos: <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='104'")); ?><br>

<? 
$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
?>
Record Online: <?=$b['PlayerCount']?><br><br>




                	<div class="center_col_header">
                    	<span>Ultimos Itens Adicionados:</span>
                    </div>
<br>
<?
$busca3 = mssql_query("SELECT TOP 3 ID, Nome, Tipo, Sexo, Level, Imagem, pre�o, dano, atraso, hp, ap FROM Shop ORDER By ID desc");
while($busca4 = mssql_fetch_row($busca3)){
?>
<center>
<font size=1><b><?=$busca4[1]?> - Tipo: <?=$busca4[2]?> - Sexo: <?=$busca4[3]?> - Level: <?=$busca4[4]?></font>
</center>

<center>
<?
if ($busca4[5] == NULL){
?>
<img src="_img/no_preview.png" width="100" height="100">
<?
}else{
?>
<img src="_img/<?=$busca4[5]?>">
<?
}
?>
<br>
Dano:<?=$busca4[7]?><br>
Atraso:<?=$busca4[8]?><br>
HP:<?=$busca4[9]?><br>
AP:<?=$busca4[10]?><br>
<a href="?gz=detalhes_item&ID=<?=$busca4[0]?>"><?=$busca4[6]?> Coins - Detalhes</a><br></b>
</center>
<?
}
?>