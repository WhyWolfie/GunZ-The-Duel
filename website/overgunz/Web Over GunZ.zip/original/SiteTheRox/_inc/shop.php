<center>
<br>
<a href="?gz=shop_donat"><img src="images/donate.jpg"></a> <br><br>
<a href="?gz=shop_event"><img src="images/Evento.jpg"></a> <br><br>
<a href="?gz=shop_raros"><img src="images/Raros.jpg"></a>
</center>