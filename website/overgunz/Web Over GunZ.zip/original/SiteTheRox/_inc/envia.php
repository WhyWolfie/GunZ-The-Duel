<?php
//Script By Gaspar =/

session_start();
$formnome = "TheRox GunZ - Recupera��o De Senha";
$formemail = "therox@hotmail.com.br"; //Email Do Remetente

$smtp_endereco = "localhost"; // Endere�o ou ip do servidor SMTP
$usuario_smtp = ""; // coloque aqui seu usu�rio SMTP em geral � o pr�prio email que envia.
$senha_smtp = ""; // Coloque aqui sua senha para o usu�rio SMTP acima.

require("_conf/smtp/class.phpmailer.php"); // envio de e-mail com autenticacao do provedor

$mail = new PHPMailer(); // envodo de email com autenticacao do provedor
$mail->SetLanguage("br", "language/");
$mail->IsSMTP();

//Cria PHPmailer class
$mail->From = $formemail;
$mail->FromName = $formnome;
$mail->Host = "$smtp_endereco";
$mail->Mailer = "smtp";
$mail->AddAddress("$seu_email");
$mail->Subject = "$assunto";

//Assunto do email
$mail->Body = $formdesc;

//SMTP
$mail->SMTPAuth = true;
$mail->Username = "$usuario_smtp"; 
$mail->Password = "$senha_smtp"; 

//Verifica se email sera enviado
if(!$mail->Send())
{
echo "Ocorreram erros ao enviar email, tente novamente mais tarde.";
exit; 
}
else
{
echo "Obrigado, Um email foi enviado para seu email confirmando a troca da senha.";
exit; 
}

?>