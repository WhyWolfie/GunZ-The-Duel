<?
//Pagina para os pretos banidos '-'

$login22 = $_SESSION['login'];

$busca1 = mssql_query("SELECT Motivo FROM Banidos WHERE Login = '$login22'");
$busca2 = mssql_fetch_row($busca1);
?>
Voc� esta banido!<br><br>

Login: <?=$login22?><br>
Motivo: <?=$busca2[0]?><br><br>

Obrigado.. N�o volte sempre!
