<b>Op��es Do usu�rio:</b><br><br>

<a href="?gz=minha_conta">Minha Conta</a><br>
<a href="?gz=alterar_senha">Alterar Senha</a><br>
<a href="?gz=editar_perfil">Editar Perfil</a><br>
<a href="?gz=meus_pag">Meus Pagamentos</a><br>
<a href="?gz=ev_coins">Trocar Pontos CW</a><br>
<a href="?gz=lider">TOP Ranking</a><br>
<a href="?gz=historico">Hist�rico De Compras</a><br>
<a href="?gz=sex">Alterar Sexo Do Personagem</a><br>
<a href="?gz=nick_name">Alterar NickName</a><br>
<a href="?gz=delet_clan">Deletar Clan</a><br>
<a href="?gz=deslogar">Sair</a><br><br>