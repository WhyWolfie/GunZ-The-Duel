<?
//Script By Gaspar

function sendMail($para,$de,$mensagem,$assunto)
{
	//DADOS SMTP
	$smtp = "127.0.0.1";
	$usuario = "";
	$senha = "";

	require_once '_conf/smtp/smtp.php';

	$mail = new SMTP;
	$mail->Delivery('relay');
	$mail->Relay($smtp, $usuario, $senha, 25, 'login', false);
	$mail->TimeOut(10);
	$mail->Priority('high');
	$mail->From($de);
	$mail->AddTo($para);
	$mail->Html($mensagem);
		
	if($mail->Send($assunto))
		return true;
	else
		return false;
		
} 


$para = "guilhermefgaspar@yahoo.com.br";

$de = "therox@hotmail.com.br";

$mensagem = "Mensagem de teste";

$assunto = "Email Teste";

sendMail($para,$de,$mensagem,$assunto);

echo "Enviado Com Sucesso!";
?>