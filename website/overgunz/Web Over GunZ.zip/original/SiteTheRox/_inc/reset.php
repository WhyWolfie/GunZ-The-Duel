<?
//Script By:Gaspar ;D

if (!(isset($_POST['nick2'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=reset">
<input type="text" id="nick2" value="Nick Do Preto" class="log_field" size="16" name="nick2" value="" maxlength="20"><br><br>
<input type="submit" name="logar" value="Resetar!" />
</form>
<?
}else{

$login22 = $_SESSION["login"];

$busca3 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255 OR $busca4[0] == 254){

$nick11 = Filtrrar($_POST['nick2']);

$busca1 = mssql_query("SELECT AID FROM Character WHERE Name = '$nick11'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("O Char do preto que vc digitou n exite D:");
}else{

$query1 = mssql_query("SELECT CID FROM Character WHERE Name = '$nick11'");
$query2 = mssql_fetch_row($query1);

mssql_query("UPDATE Character SET Level = '1', XP = '0', BP = '0' WHERE CID = '$query2[0]'");
echo "Personagem Resetado com Sucesso!";

}

}else{
echo "Voce nao tem permissao para acessar esta area";
}
}
?>