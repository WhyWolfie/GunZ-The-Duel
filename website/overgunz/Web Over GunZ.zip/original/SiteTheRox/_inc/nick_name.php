<?
//Mudan�a de NickName By Gaspar ;D

$login22 = $_SESSION['login'];

$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
echo "Voc� n�o tem personagens";
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=nick_name&etapa=1">
Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>

<input type="text" id="nick_new" value="Novo Nick" class="log_field" size="16" name="nick_new" value="" maxlength="12"><br><br>

<input type="submit" name="mudar" value="Alterar NickName!" />
</form>
<br><br>

<font color=red>Aten��o ir� ser cobrado 25 Coins pelo servi�o.</font>

<?
}

if($etapa == 1)
{

$cid22 = Filtrrar($_POST['cid22']);

$nicknew = Filtrrar($_POST['nick_new']);

$query22 = mssql_query("SELECT CID FROM Character WHERE Name = '$nicknew'");

if( mssql_num_rows($query22) < 1 )
{

$buscanome = "SELECT Coins FROM Account WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 25) 
{
	echo "Desculpe, nao foi possivel realizar sua compra.<br>";
	echo "Voce nao tem Coins sufuciente.<br>";
	echo "Adquira mais coins e volte novamente!<br>";
        echo "Obrigado.<br>";
?>
<a href="?gz=nick_name">Voltar</a>
<?
}else{

$pattern = "[^a-zA-Z0-9]";
if(ereg($pattern,$nicknew) == TRUE)
{
die('Caracters n�o permitidos');
}

$query1 = mssql_query("UPDATE Character SET Name = '$nicknew' WHERE CID = '$cid22'");
$query2 = mssql_query("UPDATE Account SET Coins=Coins -25 WHERE UserID='$login22'");

echo "Obrigado, seu nick name ja foi atualizado. Caso esteja no jogo, relogue.";

}

}else{
echo "Desculpe, Este NickName ja est� em uso. Por favor escolha outro.";
}

}
?>