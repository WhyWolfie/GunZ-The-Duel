<?
$login = $_SESSION['login'];

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
?>
<font color=white>
<b class="comodoar2"><font type="Verdana"  color="lime">Como Doar </b></font><br /> <br />
<font color="red">Para doar escolha um dos planos abaixo e clique no Bot�o do Pagseguro e depois siga as instru��es no site do pag seguro.
The Rox Moedas TR pelo PagSeguro. </font><br><br>
Pelo PagSeguro � poss�vel realizar a doa��o Via Boleto banc�rio que pode ser debitado em qualquer banco ou casa lot�rica e tamb�m por D�bito Online ou Cart�o de Cr�dito,onde sua compra � totalmente protegida.                 
<font color="lime">			<p class="comodoar2"><b>Tabela de pre�os:<br></b></p></font>
<table width="500" align="center" class="comodoar">
<tr>
	<td><strong><b><font color="white">Plano 1 (TR Coins):</b></strong> 12.500 ~&gt; Valor: R$10,00
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="12.500 Moedas TR - Usu�rio:<?=$login?>" />	  	
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="9.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
	<td><strong><b><font color="white">Plano 2 (TR Coins):</b></strong> 25.000 ~&gt; Valor: R$20,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="25.000 Moedas TR - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="20.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
	<td><strong><b><font color="white">Plano 3 (TR Coins):</b></strong> 35.000 ~&gt; Valor: R$30,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="35.000 Moedas TR - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="29.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
	<td><strong><b><font color="white">Plano 4 (TR Coins):</b></strong> 50.000 ~&gt; Valor: R$40,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="50.000 Moedas TR - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="39.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
	<td><strong><b><font color="white">Plano 5 (TR Coins):</b></strong> 75.000 ~&gt; Valor: R$60,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="75.000 Moedas TR - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="59.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
<tr>
	<td><strong><b><font color="white">Plano 6 (TR Coins):</b></strong> 100.000 ~&gt; Valor: R$120,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="100.000 Moedas TR - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="119.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
<tr>
	<td><strong><b><font color="white">Plano 7 (Colaborador):</b></strong> Gm por um m�s ~&gt; Valor: R$150,00<br 
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="therox@hotmail.com.br" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="GM POR UM MES  - Usu�rio:<?=$login?>" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="149.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="1.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/84x35-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>
<tr>
</table><br />
</tr>
<tr>
</table><br />
</table><br />
<font color="yellow"><p align="left" class="comodoar"><b class="comodoar2">Recebendo seus Coins </b><br />
Ap&oacute;s realizar a doa��o, voc� ter� que aguardar o Pag Seguro confirmar o pagamento isso leva entorno de 1 a 2 dias.<br>
Assim que o pagamento for confirmado voc� receber� um email e seus coins s�o depositados automaticamente.<br><br>
Caso voc� n�o deseje esperar o Pag Seguro confirmar o pagemento basta enviar um email para therox@hotmail.com.br, <br>
informando o dia e hora em que voc� pagou, seu login e o comprovante escaneado ou foto legivel em anexo.</p><br />


<?
}
?>

