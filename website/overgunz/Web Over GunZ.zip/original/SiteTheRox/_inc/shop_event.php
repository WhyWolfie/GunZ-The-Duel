<center>
<font size=1><b>jjang - Tipo: Custom - Sexo: Ambos - Level: 1</font></b>
</h2>
</center>
<br>
<center>
<img src="_img/wv4un8.jpg.gif">
<br>
<a href="?gz=jjang">40 EVCoins - Detalhes</a>
</center>
<?
//Script By: Gaspar
//Pagina��o By: Metalknuxx

$TotalPG = 3;
$Pg = Filtrrar(@$_GET['pag']);
if (empty($Pg)) { $Pg = 0; }$Busca = mssql_query("SELECT ID, Nome, Tipo, Sexo, Level, Imagem, pre�o, dano, atraso, hp, ap FROM Shop_EV ORDER By ID desc");
$pgs = ceil(@mssql_num_rows($Busca) / $TotalPG);
@mssql_data_seek($Busca , ($Pg * $TotalPG));
$i = 0;
while(($busca2 = @mssql_fetch_row($Busca)) && $i < $TotalPG){
?>
<center>
<font size=1><b><?=$busca2[1]?> - Tipo: <?=$busca2[2]?> - Sexo: <?=$busca2[3]?> - Level: <?=$busca2[4]?></font></b>
</h2>
</center>
<br>
<center>
<?
if ($busca2[5] == NULL){
?>
<img src="_img/no_preview.png">
<?
}else{
?>
<img src="_img/<?=$busca2[5]?>">
<?
}
?>
<br>
Dano:<?=$busca2[7]?><br>
Atraso:<?=$busca2[8]?><br>
HP:<?=$busca2[9]?><br>
AP:<?=$busca2[10]?><br>
<a href="?gz=detalhes_item_EV&ID=<?=$busca2[0]?>"><?=$busca2[6]?> EVCoins - Detalhes</a>
</center>
<?
$i++;
}if ($Pg > 0){$Menos = $Pg - 1;
echo "<a href='?gz=shop_event&pag=".$Menos."'>< Voltar</a><b>";
echo "<br>";
}if ($Pg < ($pgs-1)){$Mais = $Pg + 1;
echo "<a href='?gz=shop_event&pag=".$Mais."'>Proximo ></a>";
}
?>
