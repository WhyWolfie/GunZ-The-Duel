<?
//Retorno Automatico PagSeguro By Gaspar ;D

//Configura��es
$retorno_token = '57CB87B7DA5C463A8EC1999760AE1333'; // Token gerado pelo PagSeguro

$host = "MACHINE-107"; //Servidor do SQL Server (Exemplo:SEU-PC\SQLEXPRESS)
$user = "sa"; //Login do SQL Server (Padr�o:sa)
$pass = "penisduro"; //Senha do SQL Server
$dbname = "TheRox"; //Database do seu servidor (Padr�o:GunzDB)

//N�o alterar nada!
$msconnect=mssql_connect("$host","$user","$pass") or die ('N�o � possivel estabelecer uma conec��o com o SQL Server');
$msdb=mssql_select_db("$dbname",$msconnect);	

// Validando dados no PagSeguro
$PagSeguro = 'Comando=validar';
$PagSeguro .= '&Token=' . $retorno_token; 
$Cabecalho = "Retorno PagSeguro";

foreach ($_POST as $key => $value)
{
 $value = urlencode(stripslashes($value));
 $PagSeguro .= "&$key=$value";
}

if (function_exists('curl_exec'))
{
 $curl = true;
}
elseif ( (PHP_VERSION >= 4.3) && ($fp = @fsockopen ('ssl://pagseguro.uol.com.br', 443, $errno, $errstr, 30)) )
{
 $fsocket = true;
}
elseif ($fp = @fsockopen('pagseguro.uol.com.br', 80, $errno, $errstr, 30))
{
 $fsocket = true;
}

if ($curl == true)
{
 $ch = curl_init();

 curl_setopt($ch, CURLOPT_URL, 'https://pagseguro.uol.com.br/Security/NPI/Default.aspx');
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $PagSeguro);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_HEADER, false);
 curl_setopt($ch, CURLOPT_TIMEOUT, 30);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

  curl_setopt($ch, CURLOPT_URL, 'https://pagseguro.uol.com.br/Security/NPI/Default.aspx');
  $resp = curl_exec($ch);

 curl_close($ch);
 $confirma = (strcmp ($resp, "VERIFICADO") == 0);
}
elseif ($fsocket == true)
{
 $Cabecalho  = "POST /Security/NPI/Default.aspx HTTP/1.0\r\n";
 $Cabecalho .= "Content-Type: application/x-www-form-urlencoded\r\n";
 $Cabecalho .= "Content-Length: " . strlen($PagSeguro) . "\r\n\r\n";

 if ($fp || $errno>0)
 {
    fputs ($fp, $Cabecalho . $PagSeguro);
    $confirma = false;
    $resp = '';
    while (!feof($fp))
    {
       $res = @fgets ($fp, 1024);
       $resp .= $res;
       if (strcmp ($res, "VERIFICADO") == 0)
       {
          $confirma=true;
          break;
       }
    }
    fclose ($fp);
 }
 else
 {
    echo "$errstr ($errno)<br />\n";
 }
}


if ($confirma) {

 // Recebendo Dados
 $TransacaoID = $_POST['TransacaoID'];
 $VendedorEmail  = $_POST['VendedorEmail'];
 $Referencia = $_POST['Referencia'];
 $TipoFrete = $_POST['TipoFrete'];
 $ValorFrete = $_POST['ValorFrete'];
 $Extras = $_POST['Extras'];
 $Anotacao = $_POST['Anotacao'];
 $TipoPagamento = $_POST['TipoPagamento'];
 $StatusTransacao = $_POST['StatusTransacao'];
 $CliNome = $_POST['CliNome'];
 $CliEmail = $_POST['CliEmail'];
 $CliEndereco = $_POST['CliEndereco'];
 $CliNumero = $_POST['CliNumero'];
 $CliComplemento = $_POST['CliComplemento'];
 $CliBairro = $_POST['CliBairro'];
 $CliCidade = $_POST['CliCidade'];
 $CliEstado = $_POST['CliEstado'];
 $CliCEP = $_POST['CliCEP'];
 $CliTelefone = $_POST['CliTelefone'];
 $NumItens = $_POST['NumItens'];
 $Valor = $_POST['ProdValor_1'];

//Insere dados na DB
$insere1 = mssql_query("INSERT INTO PagSeguro (TransacaoID, TipoPagamento, StatusTransacao, CliNome, CliEmail, Valor) VALUES ('$TransacaoID', '$TipoPagamento', '$StatusTransacao', '$CliNome', '$CliEmail', '$Valor')");

}

$TransacaoID = $_POST['TransacaoID'];

//Gera Token!
function RandomPass($numchar){  
   $letras = "A,B,C,D,E,F,G,H,I,J,K,1,2,3,4,5,6,7,8,9,0";  
   $array = explode(",", $letras);  
   shuffle($array);  
   $senha = implode($array, "");  
   return substr($senha, 0, $numchar);  
} 
$token22 = RandomPass(5);

//Insere Token Gerado na DB
$insere2 = mssql_query("INSERT INTO Tokens (Token, Utiliza��o) VALUES ('$token22', '22')");
?>
<meta HTTP-EQUIV = "Refresh" CONTENT = "1; URL = ?gz=compra_concluida2&Token=<?=$token22?>&ID=<?=$TransacaoID?>">
<?


exit();
?>