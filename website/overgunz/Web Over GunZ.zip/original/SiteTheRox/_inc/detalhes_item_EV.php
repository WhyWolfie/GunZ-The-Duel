<?
//Script By:Gaspar ;D

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$login22 = Filtrrar($_SESSION["login"]);
$ID = $_GET['ID'];

if ($ID == NULL){
echo "Item Invalido";
}else{

$busca55 = mssql_query("SELECT ID, Nome, Tipo, Sexo, Level, Imagem, pre�o, ItemID FROM Shop_EV WHERE ID = '$ID'");
$busca56 = mssql_fetch_row($busca55);

$busca57 = mssql_query("SELECT EVCoins FROM Account WHERE USerID = '$login22'");
$busca58 = mssql_fetch_row($busca57);
?>

<b><Font size="2"><span><span></span>
<?=$busca56[1]?> - Tipo: <?=$busca56[2]?> - Sexo: <?=$busca56[3]?> - Level: <?=$busca56[4]?>
</span></font>
</b>
<li class="h">
<?
if ($busca56[5] == NULL){
?>
<img src="_img/no_preview.png">
<?
}else{
?>
<img src="_img/<?=$busca56[5]?>">
<?
}
?>
</li>
O que deseja fazer? - <a href="?gz=comprar_item_EV&ID=<?=$ID?>&presente=0">Comprar</a> - <a href="?gz=comprar_item_EV&ID=<?=$ID?>&presente=1">Presentear</a><br>
Voce tem um total de <?=$busca58[0]?> EVCoins , apos fazer essa compra ira sobrar <?=$busca58[0]-$busca56[6]?>

<?
}
}
?>