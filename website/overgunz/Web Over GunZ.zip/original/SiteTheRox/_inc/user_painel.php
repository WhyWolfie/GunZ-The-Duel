<font size=2>
<?
if($_SESSION[AID] == "")
{
?>
<center>
<form name="login" method="POST" action="index.php?gz=logar"><table width="180" height="0" border="0" align="center" cellpadding="0" cellspacing="0">
<table width="150" height="150" border="0" cellpadding="0" cellspacing="0" align="center">
  <tr>
    </tr>
  <tr>
    <td height="40"><table width="50" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
      </tr>
      <br>
      <tr>
        <td align="right" height="0"><input name="userid" type="text" value="Login" tabindex="1" value="" maxlength="19"></td>
      </tr>
      <tr>
        <td align="right" height="50"><input name="pass"  type="password" value="Senha" tabindex="2" maxlength="19"></td>
      </tr>
      <input type="hidden" name="submit" value="1">
    </table></td>
  </tr>
  <tr>
    <td align="right"><table width="150" border="0" align="right">
      <tr>
        <td align="right" height="1"></td>
      </tr>
      <tr>
        <a href="index.php?gz=recupera_senha&etapa=1"><font size=2>Recuperar senha</font></a></td>  
      </tr>
      <tr>
         <td width="50" align="right" colspan="2"><input type="image" src="./_img/Logar.jpg" border="0"> </td> 
      </tr>
    </table></td>
  </tr>
</table>
</form>
</center>

<?
}else{

$login = $_SESSION["login"];

echo "Bem Vindo(a) $login <br>";

$busca23 = mssql_query("SELECT Coins, EVCoins FROM Account WHERE UserID = '$login'");
$busca24 = mssql_fetch_row($busca23);

$busca25 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login'");
$busca26 = mssql_fetch_row($busca25);

if ($busca26[0] == 255 OR $busca26[0] == 254 OR $busca26[0] == 0 OR $busca26[0] == 4 OR $busca26[0] == 5 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 2 OR $busca26[0] == 252 OR $busca26[0] == 20){
echo "Voce possui $busca24[0] Coins ";
echo "e $busca24[1] EVCoins<br>";
?>
<a href="?gz=minha_conta">Minha Conta</a><br>
<a href="?gz=alterar_senha">Alterar Senha</a><br>
<a href="?gz=editar_perfil">Editar Perfil</a><br>
<a href="?gz=meus_pag">Meus Pagamentos</a><br>
<a href="?gz=ev_coins">Trocar Pontos CW</a><br>
<a href="?gz=lider">TOP Ranking</a><br>
<a href="?gz=historico">Hist�rico De Compras</a><br>
<a href="?gz=assinatura">Assinatura Din�mica <font color=red>(Novo)</font></a><br>
<a href="?gz=sex">Alterar Sexo Do Personagem</a><br>
<a href="?gz=nick_name">Alterar NickName</a><br>
<a href="?gz=delet_clan">Deletar Clan</a><br>
<a href="?gz=deslogar">Sair</a><br><br>
<?
}
if ($busca26[0] == 255){
?>

<font color=red>Painel Do Administrador:<br></font>
<a href="?gz=addnoticia_222">Adicionar Noticia</a><br>
<a href="?gz=addcoins_222">Adicionar Coins</a><br>
<a href="?gz=addcoins_223">Adicionar EVCoins</a><br>
<a href="?gz=banir_222">Banir Usuario</a><br>
<a href="?gz=chatblock_222">Chat Block</a><br>
<a href="?gz=Normal_222">Retirar ChatBlock</a><br>
<a href="?gz=reset">Resetar Personagem</a><br><br>
<?
}
if ($busca26[0] == 254){
?>
<br>
<b><Font color=Lime>Painel Do GameMaster:</b><br></font>
<a href="?gz=banir_222">Banir Usuario</a><br>
<a href="?gz=chatblock_222">Aplicar ChatBlock</a><br>
<a href="?gz=Normal_222">Retirar ChatBlock</a><br>
<a href="?gz=addcoins_223">Adicionar EVCoins</a><br>
<a href="?gz=reset">Resetar Personagem</a><br><br>
<?
}
if ($busca26[0] == 253){
?>
Esta conta est� banida!<br><br>
<a href="?gz=deslogar">Sair</a><br>
<meta HTTP-EQUIV = "Refresh" CONTENT = "0; URL = ?gz=banido">
<?
}
}
?>
</font>