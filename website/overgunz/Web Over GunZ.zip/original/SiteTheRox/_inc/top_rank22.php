<?
//Script De Ranking Desenvolvido Por Gaspar ;D

$omg51 = mssql_query("SELECT AID FROM Account WHERE UGradeID = '0'");
while($omg52 = mssql_fetch_row($omg51)){

$res = mssql_query("SELECT TOP 4 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL OR AID = '$omg52[0]') ORDER BY XP DESC");

}

while($item = mssql_fetch_assoc($res))
{

//Color Nicks By:Gaspar

$buscanome2229 = "select UGradeID from Account WHERE AID = '$item[AID]'";
$resultado4449 = mssql_query($buscanome2229);
$result229 = mssql_fetch_array($resultado4449);

switch($result229[0]) {
	case 255: $color = "<font color=#00FFFF>"; break;
	case 254: $color = "<font color=#00EE00>"; break;
        case 253: $color = "<font color=gray>"; break;
        case 0: $color = "<font color=white>"; break;
        case 2: $color = "<font color=Yellow>"; break;
        case 4: $color = "<font color=#8A2BE2>"; break;
        case 5: $color = "<font color=#0000FF>"; break;
        case 6: $color = "<font color=#FF4040>"; break;
        case 7: $color = "<font color=#EE1289>"; break;
        case 20: $color = "<font color=#AB82FF>"; break;
	case 104: $color = "<font color =red>(Chat Block)</font>"; break;
}

?>

                            	<li>
                                	<div class="li_left">
                                    	<span>�</span>
                                    </div>
                                    <div class="li_middle">
                                    	<span><a href="?gz=infoplayer&NICK=<?=$item['Name']?>"><?=$color?><?=$item['Name'] ?></font></a></span>
                                    </div>
                                    <div class="li_right">
                                    	<span class="li_right_left_span"><?=$item['Level'] ?></span>

                                    </div>
                                </li>

<?
}
?>