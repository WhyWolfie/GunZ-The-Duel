<?
//Script By Gaspar ;D

$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
echo "Voc� n�o tem personagens ou est� deslogado";
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=delet_clan&etapa=1">
Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>
<input type="submit" name="proximo" value="Proximo ->" />
</form>

<?
}

if($etapa == 1)
{

$cid22 = Filtrrar($_POST['cid22']);

$query2 = mssql_query("SELECT CLID FROM ClanMember WHERE CID = '$cid22'");

if( mssql_num_rows($query2) < 1 )
{
echo "Desculpe, este personagem n�o pertence a nenhum clan";
die();
}

$query3 = mssql_fetch_row($query2);

$query4 = mssql_query("SELECT MasterCID FROM Clan WHERE CLID = '$query3[0]'");
$query5 = mssql_fetch_row($query4);

if($cid22 == $query5[0])
{
$query6 = mssql_query("SELECT Name FROM Clan WHERE CLID = '$query3[0]'");
$query7 = mssql_fetch_row($query6);

?>
<form id="site_Login" name="site_Login" method="post" action="?gz=delet_clan&etapa=2">
Tem certeza que deseja deletar o clan
<select name="CLID55" class="text">
<option value="<?=$query3[0]?>"><?=$query7[0]?></option>
</select>?<br><br>
<input type="submit" name="proximo" value="Sim" />
</form>
<br>
<form id="site_Login" name="site_Login" method="post" action="?gz=home">
<input type="submit" name="proximo" value="N�o" />
</form>
<?
}else{
echo "Voc� n�o � lider do seu clan";
}

}

if($etapa == 2)
{

$clid22 = $_POST['CLID55'];

$query8 = mssql_query("DELETE FROM ClanMember WHERE CLID = '$clid22'");
$query9 = mssql_query("DELETE FROM Clan WHERE CLID = '$clid22'");

echo "Clan Deletado Com Sucesso";

}
?>
