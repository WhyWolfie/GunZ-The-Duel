<?
//Script Desenvolvido Por Gaspar ;D

$busca999 = mssql_query("SELECT TOP 5 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
                               <li>
                                	<div class="li_left">
                                    	<span>�</span>
                                    </div>
                                    <div class="li_middle">
                                    	<font size=1><a href="?gz=infoclan&CLAN=<?=$item22[0]?>"><?=$item22[0]?></a>  vs  <a href="?gz=infoclan&CLAN=<?=$item22[1]?>"><?=$item22[1]?></a></font>
                                    </div>
                                    <div class="li_right">
                                        <span class="li_right_mid_span"><?=$item22[2]?> / <?=$item22[3]?></span>
                                    </div>
                                </li>
<?
}
?>


