Edite o link da sua pagina de clans em _inc/clans.php

<p align="center"><iframe src="clan/index.php" width="370" height="370" frameborder="0"></iframe></p>