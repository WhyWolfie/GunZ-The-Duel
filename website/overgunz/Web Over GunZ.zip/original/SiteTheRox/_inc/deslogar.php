<?
$usr = $_SESSION['login'];
mssql_query("DELETE FROM LoggedUsers WHERE UserID = '$usr'");
unset($_SESSION['UserID']);
unset($_SESSION['Login']);
unset($_SESSION['AID']);
unset($_SESSION['UGradeID']);
unset($_SESSION['Senha']);
session_unset();
$_SESSION = array();
echo "Obrigado por preferir o TheRox, voce esta deslogado!";
?>
<META HTTP-EQUIV="Refresh" CONTENT="2 ; URL=index.php">