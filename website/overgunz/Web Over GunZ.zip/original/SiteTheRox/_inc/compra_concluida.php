Obrigado, sua compra foi concluida!<br>

Caso voc� tenha pagado com boleto banc�rio ou cart�o de cr�dito, n�s estamos aguardando a confirma��o do pagamento para deposito dos coins.<br><br>

TheRox agradece a sua colabora��o.