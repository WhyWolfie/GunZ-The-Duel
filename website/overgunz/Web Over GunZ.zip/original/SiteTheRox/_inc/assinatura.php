<?
//Script De Gerar Assinatura By Gaspar ;D

if( $_SESSION[AID] == "" )
{
alertbox("Logue-se primeiro","index.php?do=login");
    die();
}

    $ronaldo1 = mssql_query("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION[AID]."'AND CharNum != '-1'");

    if( mssql_num_rows($ronaldo1) < 1 )
    {
	alertbox("Voc� n�o tem personagens","index.php?do=login");
    	die();
    }

?>
<head>
<script type="text/javascript">
    function AtualizarAssinatura()
    {
        var id = document.assinatura.idlist.value;
        var cid = document.assinatura.charlist.value;
        var sign = document.getElementById("sign");
        sign.innerHTML = '<img src="http://69.162.64.211/$sitepreview/snow-gunz.net/Sing/signature.php?CID='+ cid + '&ID='+ id + '" />';
        document.assinatura.codigoforum.value = '<img src="http://69.162.64.211/$sitepreview/snow-gunz.net/Sing/signature.php?CID=' + cid + '&ID='+ id + '">';
        document.assinatura.linkdireto.value = "http://69.162.64.211/$sitepreview/snow-gunz.net/Sing/signature.php?CID=" + cid + "&ID="+ id + "";
        document.assinatura.codigohtml.value = '<a href="http://www.snow-gunz.net/"><img src="http://69.162.64.211/$sitepreview/snow-gunz.net/Sing/signature.php?CID=' + cid + '&ID='+ id + '" border="0"></a>';
    }

</script>

<meta http-equiv="Content-Language" content="BR">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

<div align="center"><form name="assinatura">

Selecione um Personagem:<br>
<select size="1" name="charlist" onchange="AtualizarAssinatura()">

<?
while( $ronaldo2 = mssql_fetch_row($ronaldo1) )
{
?>
<option value="<?=$ronaldo2[0]?>"><?=$ronaldo2[1]?></option><br />';
<?
}
?>
</select>
<br><br>

Selecione a Sign:<br>
<select size="1" name="idlist" onchange="AtualizarAssinatura()">

<option value="1">Sign 1</option><br />';
<option value="2">Sign 2</option><br />';
<option value="3">Sign 3</option><br />';

</select>
<br><br>

Sign:<br>
<span id="sign"></span>
<br><br>

C�digo para F�rums:<br>
<input type="text" name="codigoforum" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/><br><br>

C�digo HTML:<br>
<input type="text" name="codigohtml" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/><br><br>

Link Direto:<br>
<input type="text" name="linkdireto" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/><br><br>

<script type="text/javascript">
AtualizarAssinatura();
</script>
</form>

</div>