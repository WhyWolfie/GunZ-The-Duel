<font size=3>Informa��es Do Item</font><br><br>
<?
//Hist�rico de compras by gaspar

$id89 = $_GET["ID"];

$query1 = mssql_query("SELECT Item, ItemID, Data, Coins, Presenteado, Tipo FROM Compras WHERE ID = '$id89'");

while($row = mssql_fetch_row($query1)){

switch($row[5])
{
	case 1: $tipo = "Donator"; break;
	case 2: $tipo = "Evento"; break;
}

if($row[4] == NULL){
?>

Item: <?=$row[0]?> <br>
ItemID: <?=$row[1]?> <br>
Data: <?=$row[2]?> <br>
Pre�o: <?=$row[3]?> <br>
Tipo: <?=$tipo?>

<?
}else{
?>

Item: <?=$row[0]?> <br>
ItemID: <?=$row[1]?> <br>
Data: <?=$row[2]?> <br>
Pre�o: <?=$row[3]?> <br>
Presenteado: <?=$row[4]?> <br>
Tipo: <?=$tipo?>

<?
}

}
?>