<?
//Script desenvolvido por Gaspar

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$nome22 = Filtrrar($_POST['presentear']);
$ID = Filtrrar($_GET['ID']);
$login22 = Filtrrar($_SESSION["login"]);

if (!(isset($_POST['presentear'])))
{
die ("Esta pagina nao pode ser acessada diretamente!");
}else{

$busca12 = mssql_query("SELECT Nome, Tipo, Sexo, Level, Imagem, pre�o, ItemID FROM Shop WHERE ID = '$ID'");
$busca13 = mssql_fetch_row($busca12);

$busca14 = mssql_query("SELECT AID FROM Account WHERE UserID = '$nome22'");
$busca15 = mssql_fetch_row($busca14);

if (!(isset($busca15[0])))
{
die ("Desculpe, este usuario nao existe!");
}else{

$buscanome = "SELECT Coins FROM Account WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < $busca13[5]) 
{
	echo "Desculpe, nao foi possivel realizar sua compra.<br>";
	echo "Voce nao tem Coins sufuciente.<br>";
	echo "Adquira mais coins e volte novamente!<br>";
        echo "Obrigado.<br>";
?>
<a href="?gz=shop_donat">Clique aqui para voltar para o Shop Donator</a>
<?
}else{
mssql_query("INSERT INTO AccountItem (AID,ItemID,RentDate) VALUES('$busca15[0]','$busca13[6]','00:00')");
mssql_query("update Account set Coins=Coins -$busca13[5] where UserID='$login22'");

//$busca11 = mssql_query("SELECT ID FROM Compras ORDER BY ID DESC");
//$busca12 = mssql_fetch_row($busca11);

//$Mais = $busca12[0] + 1;

//mssql_query("INSERT INTO Compras (ID, Item, ItemID, Data, Coins, Login, Presenteado, Tipo) VALUES ('$Mais', '$busca13[0]', '$busca13[6]', '00:00', '$busca13[5]', '$login22', '$nome22', 1)");
echo "Compra realizada com sucesso! O item $busca13[0] Ja esta no banco do presenteado<br>";
?>
<a href="?gz=shop_donat">Clique aqui para voltar para o Shop Donator</a>
<?
}
}
}
}
?>