<?
//Script By:Gaspar ;D

if (!(isset($_POST['nick'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=Chatblock_222">
<input type="text" id="nick" value="Nome do Personagem" class="log_field" size="16" name="nick" value="" maxlength="20"><br><br>
<input type="submit" name="logar" value="Block" />
</form>
<?
}else{

$login22 = $_SESSION["login"];

$busca3 = mssql_query("SELECT UGradeID FROm Account WHERE UserID = '$login22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255 OR $busca4[0] == 254){

$nick1 = Filtrrar($_POST['nick']);

$busca1 = mssql_query("SELECT AID FROM Character WHERE Name = '$nick1'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("Este personagem nao existe!");
}else{
mssql_query("UPDATE Account SET UGradeID = '104' WHERE AID = '$busca2[0]'");
echo "Usuario Foi Punido com Chatblock com sucesso!";
}

}else{
echo "Voce n�o tem permissao para acessar esta area";
}
}
?>