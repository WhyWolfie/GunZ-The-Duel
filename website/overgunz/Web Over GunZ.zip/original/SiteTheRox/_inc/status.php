<font size=2>
<?
function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$accsBan = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT WHERE UGRADEID=253"));
$accs = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT"));
$characters = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Character"));
$clans = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Clan"));
$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>

Total de contas: <strong><? echo $accs[0]; ?></strong> <br />
Total de personagens: <strong><? echo $characters[0]; ?></strong> <br />
Total de clas: <strong><? echo $clans[0]; ?></strong> <br />
Total de contas banidas: <strong><? echo $accsBan[0]; ?></strong><br>
Mais Matou: <strong><font color=lightgreen><?=$matou[0]?><br></font></strong>
Mais Morreu: <strong><font color=red><? echo $morreu[0]; ?></font></strong><br>

Players Online:<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
    $max = $srv['MaxPlayer'];
    $porcentagem = PorcentPlayers($srv['CurrPlayer'], $srv['MaxPlayer']);
}
?> <?=$servercount?>/<?=$max?> - <?=$porcentagem?><br>
Servidor: <font color=green>Online</font>
</font>           
