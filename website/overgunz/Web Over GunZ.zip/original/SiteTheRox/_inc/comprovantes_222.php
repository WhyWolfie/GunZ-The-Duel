<?
//Script By Gaspar ;D

$login22 = Filtrrar($_SESSION["login"]);

$busca3 = mssql_query("SELECT UGradeID FROm Account WHERE UserID = '$login22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255){

$completo = Filtrrar($_GET['completo']);
$link = Filtrrar($_GET['link']);

if ($completo == "")
{

$query1 = mssql_query("SELECT Login, Link FROM comprovantes WHERE status = '0'");
while($query2 = mssql_fetch_row($query1)){
?>

Login:<?=$query2[0]?><br>
Comprovante:<br><br>
<img src="http://sgz.no-ip.org/<?=$query2[1]?>"><br>
<a href="?gz=comprovantes_222&completo=1&link=<?=$query2[1]?>">Marcar Como Pedido Completo</a><br>
<a href="?gz=comprovantes_222&completo=2&link=<?=$query2[1]?>">Marcar Como Ilegivel</a><br>
=================<br><br>


<?
}
}else{
if ($completo == "1")
{
mssql_query("UPDATE comprovantes SET status = '1' WHERE Link = '$link'");
echo "Comprovante marcado como: Completo!";
}else{
if ($completo == "2")
{
mssql_query("UPDATE comprovantes SET status = '2' WHERE Link = '$link'");
echo "Comprovante marcado como: Ilegivel";
}
}
}
}else{
echo "Voc� n�o tem permiss�o para acessar esta area D:";
}
?>