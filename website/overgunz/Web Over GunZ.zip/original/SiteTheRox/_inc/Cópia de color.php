<?
//Name color By:Gaspar '-'

$login22 = Filtrrar($_SESSION["login"]);

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?gz=color&step=1">
Voc� ir� gastar <font color=red>50</font> Coins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="4">Color 1</option>
<option value="5">Color 2</option>
<option value="6">Color 3</option>
<option value="7">Color 4</option>
</select>
<br><br>
<font color="#8A2BE2">color 1</font><br>
<font color="#0000FF">Color 2</font><br>
<font color="#FF4040">Color 3</font><br>
<font color="#EE1289">Color 4</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

$buscanome = "SELECT Coins FROM Account WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 50) 
{
	echo "Desculpe, nao foi possivel realizar sua compra.<br>";
	echo "Voce nao tem Coins sufuciente.<br>";
	echo "Adquira mais Coins e volte novamente!<br>";
        echo "Obrigado.<br>";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE UserID = '$login22'");
mssql_query("update Account set Coins=Coins -50 where UserID='$login22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "You Fail xD Gaspar Owna";
}
}
}
?>