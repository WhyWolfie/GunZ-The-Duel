<h2><span><span></span>
TheRox GunZ - Equipe
</span>
</h2>
<br>



<a href="?gz=infoplayer&Gaspar"><font color=#00FFFF>Gaspar</font></a> - Fundador Geral / PHP Coder<br>
<a href="?gz=infoplayer&YgorReis"><font color=#00FFFF>Ygor</font></a> - Fundador/Rei<br>
<br>
<a href="?gz=infoplayer&Luucas"><font color=darkorange>Killer</font></a> - GM Custom Itens / GM Lider<br>
<a href="?gz=infoplayer&Allan"><font color=darkorange>Allan</font></a> - Game Master / Designer<br>
<br>
<a href="?gz=infoplayer&Xacau"><font color=lightblue>Leonan</font></a> - Moderador / Suporte / forum<br>
<a href="?gz=infoplayer&Xacau"><font color=lightblue>iBuddy</font></a> - Moderador / Suporte / forum<br>