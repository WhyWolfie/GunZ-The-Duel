<?
//By Gaspar =/

$step = Filtrrar($_GET['step']);

if($step == ""){

?>
Adicionar Item <br><br><br>
<form id="site_Login" name="site_Login" method="post" action="?gz=add55555&step=2">
Nome: <input type="text" id="nome" value="" class="log_field" size="20" name="nome" value="" maxlength="9999"><br><br>
Tipo: <input type="text" id="tipo" value="" class="log_field" size="20" name="tipo" value="" maxlength="9999"><br><br>
Sexo: <input type="text" id="sex" value="" class="log_field" size="20" name="sex" value="" maxlength="9999"><br><br>
Level Minimo: <input type="text" id="lvl" value="" class="log_field" size="20" name="lvl" value="" maxlength="9999"><br><br>
Link Da Imagem: <input type="text" id="img" value="" class="log_field" size="20" name="img" value="" maxlength="9999"><br><br>
Pre�o: <input type="text" id="preco" value="" class="log_field" size="20" name="preco" value="" maxlength="9999"><br><br>
ItemID: <input type="text" id="ID" value="" class="log_field" size="20" name="ID" value="" maxlength="9999"><br><br>
Dano: <input type="text" id="dano" value="" class="log_field" size="20" name="dano" value="" maxlength="9999"><br><br>
Atraso: <input type="text" id="atraso" value="" class="log_field" size="20" name="atraso" value="" maxlength="9999"><br><br>
HP: <input type="text" id="hp" value="" class="log_field" size="20" name="hp" value="" maxlength="9999"><br><br>
AP: <input type="text" id="ap" value="" class="log_field" size="20" name="ap" value="" maxlength="9999"><br><br>
<input type="submit" name="adicionar" value="Adicionar!" />
</form>
<?
}
if($step == "2"){
$nome = Filtrrar($_POST['nome']);
$tipo = Filtrrar($_POST['tipo']);
$sex = Filtrrar($_POST['sex']);
$lvl = Filtrrar($_POST['lvl']);
$img = Filtrrar($_POST['img']);
$preco = Filtrrar($_POST['preco']);
$ItemID = Filtrrar($_POST['ID']);
$dano = Filtrrar($_POST['dano']);
$atraso = Filtrrar($_POST['atraso']);
$hp = Filtrrar($_POST['hp']);
$ap = Filtrrar($_POST['ap']);

$busca = mssql_query("SELECT ItemID FROM Item WHERE ItemID = '$ItemID'");
if (mssql_num_rows($busca) == 0)
{
mssql_query("INSERT INTO Item (ItemID, Name) VALUES ('$ItemID', '1')");
}else{
}

$busca2 = mssql_query("SELECT ID FROM Shop ORDER BY ID DESC");
$busca3 = mssql_fetch_row($busca2);

$ID22 = $busca3+1;

mssql_query("INSERT INTO Shop (ID, Nome, Tipo, Sexo, Level, Imagem, pre�o, ItemID, dano, atraso, hp, ap) VALUES ('$ID22', '$nome', '$tipo', '$sex', '$lvl', '$img', '$preco', '$ItemID', '$dano', '$atraso', '$hp', '$ap')");

echo "Item Adicionado Com Sucesso!";

}
?>