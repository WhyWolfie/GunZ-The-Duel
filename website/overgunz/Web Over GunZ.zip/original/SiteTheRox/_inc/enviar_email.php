<?php include("_conf/class.phpmailer.php");
$mail = new PHPMailer();
$mail->SetLanguage("br", "libs/"); // Linguagem
$mail->SMTP_PORT  = "465"; // Porta do SMTP
$mail->SMTPSecure = "tls"; // Tipo de comunica��o segura
$body = "
<div align='center'>------------------------------------------------------------<br>
Recupera��o de Senha Snow Gunz.<br>
------------------------------------------------------------<br><br>
Ol� $login_recupera ,<br>

Conforme solicitado sua nova senha �:$password <br>

Para alterar senha senha basta logar no painel do site e clicar em Alterar Senha<br>

Obrigado por preferir o Snow Gunz!<br>

Este � um email autom�tico, favor n�o responder.</div>";
$mail->IsSMTP();
$mail->Host = "smtp.gmail.com"; // GMAIL's SMTP server
$mail->SMTPAuth   = True; // enable SMTP authentication
$mail->Username   = "guilhermefgaspar@gmail.com"; // GMAIL username
$mail->Password   = "gaspar86999296"; // GMAIL password
$mail->AddReplyTo("Gaspar@snow-gunz.net","Snow Games Network"); // Reply email address
$mail->From = "Gaspar@snow-gunz.net";
$mail->FromName = "Snow Games Network"; // Name to appear once the email is sent
$mail->Subject = "Recupera��o De Senha Snow Gunz"; // Email's subject
$mail->AltBody = "Habilite o suporte html do seu e-mail"; // optional, comment out and test
$mail->WordWrap = 50; // set word wrap
$mail->MsgHTML($body); // [optional] Send body email as HTML
$mail->AddAddress("$busca10[0]", "$busca10[0]");  // email address of recipient
$mail->IsHTML(true); // [optional] send as HTML
if(!$mail->Send()){
$message =  "Houve um erro com nosso servidor contratado. <br>Favor aguarde at&eacute; que nossos servidores contratados se reestabele&ccedil;a!";
}elseif($mail->Send()){
$message =  "Aten&ccedil;&atilde;o! foi enviado um email contendo uma nova senha para $busca10[0]";}?>