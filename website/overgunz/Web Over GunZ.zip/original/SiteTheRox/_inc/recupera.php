<?
//Script By Gaspar

session_start();

$etapa = Filtrrar($_GET['etapa']);


if($etapa == NULL){
echo "You Fail xD Gaspar Owna";
}else{

if($etapa == 1)
{
?>
Etapa 1/4<br>
<form name="recupera_senha" method="POST" action="index.php?gz=recupera&etapa=2">
<input name="login_22" type="text" value="Digite Seu Login" tabindex="1" value="" maxlength="14">
<input type="hidden" name="etapa1" value="1">
<input name="login_2" type="submit" id="login" align="right" value="Poxima ->">
</form>
<?
}

if($etapa == 2){
if(isset($_POST[etapa1]))
{

$login23 = Filtrrar($_POST['login_22']);

$query1 = mssql_query("SELECT Email FROM Account WHERE UserID = '$login23'");
if(mssql_num_rows($query1) == 1){

$query2 = mssql_fetch_row($query1);
?>

Um email ser� enviado para <?=$query2[0]?> com os detalhes e instru��es para troca da senha.
<br><br>
Para continuar <a href="?gz=recupera&etapa=3">Clique Aqui</a>

<?
$_SESSION["email_5as4as564as5as546"] = $query2[0];
$_SESSION["login_544a56ad47s56asda"] = $login23;

}else{
echo "Desculpe, nao encontramos nenhum login chamado $login23 em nosso banco de dados";
}
}else{
echo "You Fail xD Gaspar Owna";
}
}

if($etapa == 3){

$login66 = $_SESSION['login_544a56ad47s56asda'];
$email66 = $_SESSION['email_5as4as564as5as546'];

//Gera Token!
function RandomPass($numchar){  
   $letras = "A,B,C,D,E,F,G,H,I,J,K,1,2,3,4,5,6,7,8,9,0";  
   $array = explode(",", $letras);  
   shuffle($array);  
   $senha = implode($array, "");  
   return substr($senha, 0, $numchar);  
} 
$token22 = RandomPass(12);

$insert = mssql_query("INSERT INTO Tokens (Token, Utiliza��o, Login) VALUES ('$token22', '22', '$login66')");

$formdesc = "Ol� Clique no link a seguir para recuperar sua senha.<br><br>
http://www.theroxgames.com/index.php?gz=recuperar&token=".$token22."<br><br>
TheRox Games agradece a sua preferencia!";

$seu_email = $email66; // Email do Player que ira receber o email

//echo "mensagem: $formdesc <br><br>";
//echo "email: $seu_email <br><br>";
//echo "Login: $login66";


include "_inc/envia.php";

}
}
?>