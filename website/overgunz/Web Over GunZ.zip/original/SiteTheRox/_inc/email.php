<?php
//Script de email By;Gaspar ;D

//Nome do enviador
$name = "Code Asisst";

//Email do enviador
$email_from = "sensei@hotmail.com.br";

//Email para qeum sera enviado
$email_to = "guilhermefgaspar@yahoo.com.br";

//Email Body
$mail_body = "Hello Recipient!";

//Subject
$mail_subject = "Mail from".$name;

//Header
$mail_header = "From: ".$name." <".$mail_from.">\r\n";

//Enviar Email
$sendmail = mail($mail_to, $mail_subject, $mail_body, $mail_header);

if($sendmail == true){
echo 'Email enviado com sucesso!';
}else{
echo "Desculpe, ocorreu um erro";
}
?>