<?
$res = mssql_query("SELECT TOP 6 *, EmblemUrl FROM Clan WHERE Deleteflag = 0 ORDER BY Point DESC");

while($item = mssql_fetch_assoc($res))
{


if($item['EmblemUrl'] == NULL){
?>

                            	<li>
                                	<div class="lm_box_date">
                                    	<img src="http://img820.imageshack.us/img820/5031/noemblem.png" width="20" height="20">
                                    </div>
                                    <div class="lm_box_team">
                                    	<a href="?gz=infoclan&CLAN=<?=$item['Name']?>"><?=$item['Name'] ?></a>
                                    </div>
                                    <div class="lm_box_results">
                                    	<span class="win"><?=$item['Point'] ?></span>
                                    </div>
                                    <div class="right_col_box_devider"></div>
                                </li>

<?
}else{
?>

                            	<li>
                                	<div class="lm_box_date">
                                    	<img src="http://zxt.no-ip.org/Emblem<?=($item['EmblemUrl'] == "") ? 'Img/no_emblem.jpg' : $item['EmblemUrl']?>" width="20" height="20">
                                    </div>
                                    <div class="lm_box_team">
                                    	<a href="?gz=infoclan&CLAN=<?=$item['Name']?>"><?=$item['Name'] ?></a>
                                    </div>
                                    <div class="lm_box_results">
                                    	<span class="win"><?=$item['Point'] ?></span>
                                    </div>
                                    <div class="right_col_box_devider"></div>
                                </li>

<?
}
}
?>
