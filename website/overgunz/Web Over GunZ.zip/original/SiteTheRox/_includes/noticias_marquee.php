<?
//Script Desenvolvido por Gaspar ;D

$busca1 = mssql_query("SELECT TOP 3 ID, Titulo, Noticia, autor FROM Noticias ORDER BY ID DESC");
while ($busca2 = mssql_fetch_row($busca1)){
?>
<marquee behavior=�scroll� direction=�right� scrollamount = "2"  ><a href="?gz=noticias&ID=<?=$busca2[0]?>"><?=$busca2[1]?> - Autor:<?=$busca2[3]?></a></marquee> 
<?
}
?>