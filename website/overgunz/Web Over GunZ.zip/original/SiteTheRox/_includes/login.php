<?
if (!(isset($_SESSION["login"])))
{
?>

<img src="images/login.png" alt="Copyright Gaspar�" height="50" width="350" style="position:absolute; left:700px; top:0px" />

<form name="login" method="POST" action="?gz=logar">
<input name="userid" type="text" value="Login" tabindex="1" value="" maxlength="19" style="position:absolute; left:720px; top:5px" >
<input name="pass" type="password" value="Login" tabindex="1" value="" maxlength="19" style="position:absolute; left:870px; top:5px" >
<input type="image" src="./images/Logar.png" border="0" style="position:absolute; left:840px; top:25px ">
<input type="hidden" name="submit" value="1">
</form>

<?
}else{
?>
<img src="images/login.png" alt="Copyright Gaspar�" height="50" width="350" style="position:absolute; left:700px; top:0px" />


<a href="?gz=minha_conta"><img src="./images/minha_acc.png" border="0" width="100" height="20" style="position:absolute; left:705px; top:0px"></a>
<a href="?gz=alterar_senha"><img src="./images/alt_senha.png" border="0" width="110" height="20" style="position:absolute; left:815px; top:2px"></a>
<a href="?gz=alterar_senha"><img src="./images/ed_perfil.png" border="0" width="110" height="20" style="position:absolute; left:925px; top:2px"></a>
<a href="?gz=ev_coins"><img src="./images/pt_cw.png" border="0" width="120" height="20" style="position:absolute; left:705px; top:20px"></a>
<a href="?gz=op��es"><img src="./images/+_op��o.png" border="0" width="120" height="20" style="position:absolute; left:825px; top:20px"></a>

<?
$login22 = $_SESSION['login'];

$ugrade1 = mssql_query("SELECT UgradeID FROM Account WHERE UserID = '$login22'");
$ugrade2 = mssql_fetch_row($ugrade1);


if($ugrade2[0] == 255 OR $ugrade2[0] == 254)
{
?>
<a href="?gz=staff_cp"><img src="./images/staff_panel.png" border="0" width="120" height="20" style="position:absolute; left:930px; top:22px"></a>
<?
}
}
?>