<?php
//Coded by Demantor. Corre��o dos Bugs e otimiza��o By Gaspar

mssql_query("DELETE FROM LoggedUsers WHERE time < " . (time() - 1000) );

$number = mssql_query("SELECT AID, UserID, UGradeID FROM LoggedUsers");


if( mssql_num_rows($number) <> 0 )
{

while($users22 = mssql_fetch_row($number)){


switch($users22[2]) {
//case 255: $color11 = "<font color=#00FFFF>"; break;
case 254: $color11 = "<font color=#00EE00>"; break;
case 253: $color11 = "<font color=gray><strike>"; break;
case 0: $color11 = "<font color=white>"; break;
}

?>
<a href="?gz=info_user&aid=<?=$users22[0]?>"><?=$color11?><?=$users22[1]?></font></font></strike></a>,
<?

}
}else{

echo 'N�o h� usu�rios logados!';
}

?>