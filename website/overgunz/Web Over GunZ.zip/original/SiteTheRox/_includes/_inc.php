<br><br>
<?

$gz = Filtrrar($_GET['gz']);

if ($gz == NULL)
{
include("_inc/home.php");
}else{
if (isset($gz)) {$url = explode('/', $gz);
settype($argv,'array');
$url7 = $url[0];}$pagina = !isset($url7) ? $modi : $url7 ;
if (is_file("_inc/".$pagina.".php")) {
include("_inc/".$pagina.".php");
}else{
include("_inc/error.php");}
}
?>