<?
//Web Site Coded By Gaspar

session_start();
include "_conf/config.php";
include "_conf/configs.php";
include "_includes/login.php";

$pagina_site = $_GET['gz'];

if($pagina_site == ""){
$pagina_site = "Home";
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?=$site_nome?> - <?=$pagina_site?></title>
<link rel="stylesheet" type="text/css" href="style.css" />
<!--SlideShow Files -->
<link rel="stylesheet" type="text/css" href="slideshow.css" />
<script type="text/javascript" src="js/jq_1.4.4.js"></script>
<script type="text/javascript" src="js/jq_slideshow.js"></script>
<script type="text/javascript" src="js/aviso.js"></script>
<LINK REL="shortcut icon" HREF="images/favicon.ico">
</head>

<body>

<?
if (!(isset($_SESSION["login"])))
{
?>

<div class="con1">
	<div class="top_bar_con">
    	<div class="top_bar_con2">
            <div class="top_bar_text">
                Bem-Vindo(a) Visitante ao site do Ragezone Brasil, caso voc� tenha perdido sua senha <a href="?gz=recupera_senha&etapa=1">Clique Aqui</a>
            </div>
        </div>
    </div>
<?
}else{
?>
<div class="con1">
	<div class="top_bar_con">
    	<div class="top_bar_con2">
            <div class="top_bar_text">
<?
$login22 = $_SESSION['login'];

$busca0 = mssql_query("SELECT Coins, EvCoins FROM Account WHERE UserID = '$login22'");
$busca1 = mssql_fetch_row($busca0);
?>
                Bem-Vindo(a) <?=$login22?>, voc� possui <?=$busca1[0]?> Coins e <?=$busca1[1]?> EvCoins. <a href="?gz=deslogar">Clique Aqui</a> para sair
            </div>
        </div>
    </div>
<?
}
?>

    <div class="header_bar_con1">
    	<div class="header_bar_con2">
        	<div class="logo_con">
            	<a href="#"><img src="images/logo.png" alt="Copyright Gaspar �" /></a>
            </div>
            <div class="twitter_update_con">
            	<div class="twitter_title">Atualiza��es / Novidades</div>
                <div class="twitter_text_con">
                	<div class="twitter_text">
                    	<? include "_includes/noticias_marquee.php"; ?>
                    </div>
                </div>
            </div>
            <div class="clr"></div>
        </div>
    </div>
    <div class="con2">
    	<div class="con3">
        	<div class="menu_bar_con">
            	<ul class="top_menu">
                	<li><a href="?gz=home"><img src="icones/core.png"> Inicio</a></li>
                    <li><a href="?gz=downloads"><img src="icones/add.png"> Downloads</a></li>
                    <li><a href="?gz=ranking"><img src="icones/palette.png"> Ranking</a></li>
                    <li><a href="?gz=registro"><img src="icones/comment_edit.png"> Cadastro</a></li>
                    <li><a href="?gz=donator"><img src="icones/help.png"> Donator</a></li>
                    <li><a href="?gz=clan_painel"><img src="icones/brick.png"> Painel De Clans</a></li>
                    <li><a href="?gz=shop"><img src="icones/carrinho.png"> Loja</a></li>
                    <li><a target="meio" href="<?=$forum?>"><img src="icones/forums.png"> Forum</a></li>
                    <li><a href="?gz=equipe"><img src="icones/members.png"> Equipe</a></li>
                </ul>
            </div>
            <div class="menu_bar_border_bottom"></div>
            <div class="main_con">
            	<div class="left_col">
                	<div class="slideshow_con">
                        <div class="wrapper">
                            <div id="slidewrap">
                                <ul class="slideshow">
                                    <li class="show"><a href="<?=$link_slide1?>"><img src="<?=$slide1?>" title="<?=$title1?>" alt="<?=$description1?>"/></a></li>
                                    <li><a href="<?=$link_slide2?>"><img src="<?=$slide2?>" title="<?=$title2?>" alt="<?=$description2?>"/></a></li>
                                    <li><a href="<?=$link_slide3?>"><img src="<?=$slide3?>" title="<?=$title3?>" alt="<?=$description3?>"/></a></li>
                                </ul>
                            </div>    
                            <div class="clr" ></div>
                        </div>
                    </div>
                    <div class="main_news_con">
                                        <ul>
                                            <? include "_includes/_inc.php"; ?>
                                        </ul>

                   </div>

                </div>
                <div class="right_col">
                	<div class="right_col_latest_matches">
                    	<div class="right_col_header">
                        	<span>+ Ultimas <span>Guerras De Clan</span></span>
                        </div>
                        <div class="right_col_sub_header">
                        	<div class="right_col_sub_lm_date">
                            	Data
                            </div>
                            <div class="right_col_sub_lm_team">
                            	Clans
                            </div>
                            <div class="right_col_sub_lm_results">
                            	Resultado
                            </div>
                        </div>
                        <div class="right_col_latest_matches_box">
                        	<ul>

                                      <? include "_includes/top_cw.php"; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="right_col_latest_threads">
                    	<div class="right_col_header">
                        	<span>+ Ultimas <span>Do F�rum</span></span>
                        </div>
                        <div class="right_col_sub_header">
                        	<div class="right_col_sub_lt_topicthreads">
                            	T�pico
                            </div>
                            <div class="right_col_sub_lt_user">
                            	Autor
                            </div>
                        </div>
                        <div class="right_col_latest_matches_box">
                        	<ul>

                                    <? include "_includes/ultimas_forum.php"; ?>
                            </ul>
                        </div>
                        <div class="right_col_sponsors">
                        	<div class="right_col_header">
                            	<span>+ Ranking<span> Players</span></span>
                            </div>


                        <div class="right_col_sub_header">
                        	<div class="right_col_sub_lt_topicthreads">
                            	Personagem
                            </div>
                            <div class="right_col_sub_lt_user">
                            	Level
                            </div>
                        </div>
                        <div class="right_col_latest_matches_box">
                        	<ul>

                                    <? include "_includes/top_rank.php"; ?>
                            </ul>
                        </div>

                    	<div class="right_col_header">
                        	<span>+ Ranking <span>Clans</span></span>
                        </div>
                        <div class="right_col_sub_header">
                        	<div class="right_col_sub_lm_date">
                            	Emblema
                            </div>
                            <div class="right_col_sub_lm_team">
                            	Clan
                            </div>
                            <div class="right_col_sub_lm_results">
                            	Pontos
                            </div>
                        </div>
                        <div class="right_col_latest_matches_box">
                        	<ul>

                                      <? include "_includes/top_clans.php"; ?>
                            </ul>
                        </div>










                        </div>
                    </div>
                </div>
                <div class="clr"></div>
            </div>
            <div class="footer_con">
            	<div class="footer_left">
                	<div class="footer_my_accout">
                    	<div class="footer_list_title">
                        	Minha Conta
                        </div>
                        <div class="footer_list">
                        	<ul>
                            	<li><a href="?gz=alterar_senha">Alterar Senha</a></li>
                                <li><a href="?gz=minha_conta">Minha Conta</a></li>
                                <li><a href="?gz=editar_perfil">Editar Perfil</a></li>
                                <li><a href="?gz=nick_name">Alterar NickName</a></li>
                            </ul>
                            <div class="footer_list_divider"></div>
                        </div>
                    </div>
                    <div class="footer_social">
                    	<div class="footer_list_title">
                        	Links R�pidos
                        </div>
                        <div class="footer_list">
                        	<ul>
                            	<li><a href="?gz=ev_coins">Trocar Pontos CW</a></li>
                                <li><a href="?gz=lider">Resgatar Coat TOP Ranking</a></li>
                                <li><a href="?gz=historico">Hist�rico De Compras</a></li>
                                <li><a href="?gz=assinatura">Assinatura Din�mica</a></li>
                            </ul>
                            <div class="footer_list_divider"></div>
                        </div>
                    </div>
                    <div class="footer_team_members">
                    	<div class="footer_list_title">
                        	Rede Sociais
                        </div>
                        <div class="footer_list">
                        	<ul>
                            	<li><a target="meio2" href="/forum/">F�rum</a></li>
                                <li><a target="meio3" href="http://www.orkut.com">Orkut</a></li>
                                <li><a target="meio4" href="http://www.facebook.com">Facebook</a></li>
                                <li><a target="meio5" href="http://theroxgames.com/?gz=TheRoxGames">Xat The Rox</a></li>
                            </ul>
                            <div class="footer_list_divider"></div>
                        </div>
                    </div>
                </div>
                <div class="footer_right">
                	<div class="footer_right_content">
                    	<div class="fooer_right_copyright">
                        	Copyright � 2011 Ragezone Brasil. All Rights Reserved<br />
							Powered By <a href="mailto:guilherme_f_gaspar@hotmail.com">Gaspar�</a>
                        </div>
                        <div class="footer_sitemap">
                                <!-- Usu�rios Logados: <? include "_includes/logados.php"; ?><br><br> -->
                        	<ul>
                            	<li><a href="?gz=home">Home</a>&nbsp;</li>
                                <li>| <a href="?gz=minha_conta">Minha Conta</a>&nbsp;</li>
                                <li>| <a target="meio" href="/forum/">F�rum</a>&nbsp;</li>
                                <li>| <a href="?gz=equipe">Equipe</a>&nbsp;</li>
                                <li>| <a href="?gz=downloads">Downloads</a>&nbsp;</li>
                                <li><a href="?gz=shop">Loja</a>&nbsp;</li>
                                <li>| <a href="?gz=cadastro">Cadastro</a>&nbsp;</li>
                                <li>| <a href="?gz=info">About BR</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                <li><a href="http://www.dmca.com/Protection/Status.aspx?id=5700f563-6bce-4eb5-a151-303376f9179f" title="Website Content Protection"> <img src ="http://images.dmca.com/Badges/dmca_protected_sml_120g.png?id=5700f563-6bce-4eb5-a151-303376f9179f"  alt="Website Content Protection" /></a>&nbsp;</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="clr"></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>