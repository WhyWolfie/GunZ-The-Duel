﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sem título</title>
</head>
<?
$nome=$_POST["nome"];
$senha=$_POST["senha"];
$fusion=($nome+$senha);
$calc=$_POST["calc"];
$somar=($nome+senha);
$dividir=($nome/senha);
echo "resultado :$fusion<br>";
if($fusion<40)
{
echo "este numero e menor do que 40";	
}
else
{
echo "teu numero não e menor que 40";	
}
?>
<?
switch($fusion)
{
case "somar":
$sinal=("$somar");

break;

case "dividir":
$sinal=("$dividir");
	
}
?>

<body>
</body>
</html>