﻿    <?php
    // substitua pelo caminho para o arquivo que deseja limpar
    $file = "C:/appserv/www/index.php";
    print removeUTF8BOM($file) ? 'BOM removido!' : 'Não havia BOM a ser removido...';
     
    function removeUTF8BOM($fil) {
    $newcontent = '';
    $first = false;
    $fh = fopen($fil, 'r');
      while($part = fread($fh, 1024)) {
        if(!$first) {
          if(preg_match('/^\xEF\xBB\xBF/', $part)) {
          $newcontent = preg_replace('/^\xEF\xBB\xBF/', "", $part);
          } else {
          fclose($fh);
          return false;
          }
        $first = true;
        } else $newcontent .= $part;
      }
    fclose($fh);
    $fh = fopen($fil, 'w');
    fwrite($fh, $newcontent);
    fclose($fh);
    return true;
    }
    ?>

