    <?php
            $atual         = (isset($_GET['pg'])) ? $_GET['pg'] : 'home';
            $pasta     = 'arquivos';
            $permissao = array();

                    foreach(glob("$pasta/*.php") as $k){

                    $file = str_replace("$pasta/", '', $k);
                    $file = str_replace(".php", '',$file);

                        $permissao[] = $file;
                                }
           
                if (substr_count($atual, '/') > 0) {
                    $atual = explode('/', $atual);
                    $pagina = (file_exists("{$pasta}/".$atual[0].'.php') && in_array($atual[0], $permissao)) ? $atual[0] : 'erro';
                    }   
                        else {
                            $pagina = (file_exists("{$pasta}/".$atual.'.php') && in_array($atual, $permissao)) ? $atual : 'erro';
                            }
    ?>