<?
//Script Desenvolvido Por Gaspar ;D

$busca999 = mssql_query("SELECT TOP 6 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{
?>

                            	<li class="tamanho">
                                	
                                    <div class="lm_box_team">
                                    	<?=$item22[0]?> vs. <?=$item22[1]?>
                                    </div>
                                    <div class="lm_box_results">
                                    	<span class="win"><?=$item22[2]?></span> - <span class="loss"><?=$item22[3]?></span>
                                    </div>
                                    <div class="lm_box_date">
                                    	<? echo corta($item22[4], 11); ?>
                                    </div>
                                </li>
<?
}
?>


