<?

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$login22 = Filtrrar($_SESSION["login"]);

if (!(isset($_POST['senha1'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gz=alterar_senha">
<input type="password" id="senha1" value="Senha" class="log_field" size="25" name="senha1" value="" maxlength="20">  <-- Digite sua senha atual<br>
<input type="password" id="senha2" value="Senha" class="log_field" size="25" name="senha2" value="" maxlength="20">  <-- Digite sua nova senha<br><br>
<input type="submit" name="logar" value="Mudar!" />
</form>
<?
}else{

$senha1 = Filtrrar($_POST['senha1']);
$senha2 = Filtrrar($_POST['senha2']);

$busca22 = mssql_query("SELECT Password FROM Login WHERE UserID = '$login22'");
$busca23 = mssql_fetch_row($busca22);

if ($busca23[0] == $senha1){
mssql_query("UPDATE Login SET Password = '$senha2' WHERE UserID = '$login22'");
echo "Senha Alterada Com Sucesso!";
}else{
echo "A sua senha atual nao confere com a que temos em nosso sistema.";
}
}
}
?>