<center>
<br>
<a href="?kog=shop_donat"><img src="images/donate.jpg"></a> <br><br>
<a href="?kog=shop_event"><img src="images/Evento.jpg"></a> <br><br>
<a href="?kog=shop_raros"><img src="images/Raros.jpg"></a>
</center>