﻿<?php 
//Arquivo De Configuração.

$msconnect=mssql_connect("$host","$user","$pass") or die ('Não é possivel estabelecer uma conecção com o SQL Server');
$msdb=mssql_select_db("$dbname",$msconnect);

if(!function_exists("alertbox")){
function alertbox($text, $url)
{
    echo "<script>alert('$text');document.location = '$url'</script>";
    die("Javascript disabled");
} }


//Função muda banner By Gaspar ;D
$banners = array('banner.jpg', 'banner2.jpg');
$totalbanners = count($banners);
$totalbanners--;
$randombanners = rand(0,$totalbanners);
$link = array('?gz=home');

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables", "shutdown", "update");
	$blank = "";
return str_replace($caracters, $blank, $str);
}


//Função cortar a data e não mostrar a hora
function corta($texto, $limite) {
if (strlen($texto) > $limite)
$texto = substr($texto, 0, $limite) . '';
  return $texto;
}

?>