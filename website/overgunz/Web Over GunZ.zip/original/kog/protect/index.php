<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<title>403 - Access Denied</title>
</head><body>
<h1>403 - Sem permiss&atilde;o</h1>
<p>Voc&ecirc; n&atilde;o tem permiss&atilde;o para acessar esta p&aacute;gina.</p>

<hr>
<address>
www.connectgunz.net &copy; Todos direitos reservados
</address>
</body></html>