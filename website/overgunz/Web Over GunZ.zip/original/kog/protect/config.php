<?
//Configura��es Gerais
$site_nome = "Ragezone Brasil!"; //Titulo Do Site
$forum = "http://www.ragezone.com.br"; //Link do seu forum! (Menu)

//Configura��es Slide 1
$link_slide1 = "#"; //Link que ao clicar no Slide1 vai redirecionar
$slide1 = "images/slideshow_1.jpg"; //Link do Slide 1 que fica encima do Home
$title1 = "Ragezone Brasil"; //Titulo do Slide 1 que fica encima do Home
$description1 = "Chame Seus Amigos para Jogar The Rox Gunz !"; //Descri��o do Slide 1 que fica encima do Home

//Configura��es Slide 2
$link_slide2 = "#"; //Link que ao clicar no Slide1 vai redirecionar
$slide2 = "images/slideshow_2.jpg"; //Link do Slide 2 que fica encima do Home
$title2 = "Ragezone Brasil "; //Titulo do Slide 2 que fica encima do Home
$description2 = "Compre Donate e Recebar 25 % de Desconto em Suas Compras"; //Descri��o do Slide 2 que fica encima do Home

//Configura��es Slide 3
$link_slide3 = "#"; //Link que ao clicar no Slide1 vai redirecionar
$slide3 = "images/slideshow_3.jpg"; //Link do Slide 3 que fica encima do Home
$title3 = "Ragezone Brasil"; //Titulo do Slide 3 que fica encima do Home
$description3 = "Nova Atualizacao em Andamento Aguarde Coisas Especiais no The Rox"; //Descri��o do Slide 3 que fica encima do Home

//Configura��es Do Cadastro
$servername = "King of GunZ"; //Nome do servidor
$accounttable = "Account"; //Tabela das Contas (Padr�o:Account)
$logintable = "Login"; //Tabela da Login (Padr�o:Login)

//Configura��es Do SQL Server
$host = "MARCOS-PC\SQLEXPRESS"; //Servidor do SQL Server (Exemplo:SEU-PC\SQLEXPRESS)
$user = "sa"; //Login do SQL Server (Padr�o:sa)
$pass = "gabigabi"; //Senha do SQL Server
$dbname = "GunzDB"; //Database do seu servidor (Padr�o:GunzDB)

//Configura��es Do Servidor
$_host_name = '212.124.114.107'; //IP Do Servidor
$_servers = Array("Servidor:"=> 6000,);  //Altere o 6000 para a porta do seu MatchServer
$_servers2 = Array("NAT Agent:"=> 7777,); //Altere o 7777 para a porta do seu MatchAgent


//Configura��es "Ultimas Do F�rum"
$link25 = "http://www.theroxgames.com/forum/"; //Link do seu forum!
$server = "localhost"; //Nome do servidor do Mysql (Padr�o:localhost)
$dbnamef = "forum"; // Indique o nome do banco de dados (Database do f�rum)
$usuario = "root"; // Indique o nome do usu�rio que tem acesso
$password = "theroxgz37"; // Indique a senha do usu�rio
$mode = "off"; //Se o modo estiver "on" � porque esta ativado, se tiver "off" � porque esta desativado
?>