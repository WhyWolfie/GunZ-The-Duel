
<div id='coin-slider'>
	<a href="www.google.com.br" target="_blank">
		<img src='../imagens/img/img1.JPEG' >
		<span>
			Description for img1
		</span>
	</a>
	
	<a href="www.globo.com.br">
		<img src='imagens/img/img2.jpg' >
		<span>
			Description for imgN
		</span>
	</a>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('#coin-slider').coinslider({ width: 646, height:216, navigation:true, delay: 5000 });
	});
</script>
