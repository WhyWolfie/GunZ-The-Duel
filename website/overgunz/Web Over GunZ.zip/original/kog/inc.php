<br><br>
<?

$gz = Filtrrar($_GET['kog']);

if ($gz == NULL)
{
include("kog/inicio.php");
}else{
if (isset($gz)) {$url = explode('/', $gz);
settype($argv,'array');
$url7 = $url[0];}$pagina = !isset($url7) ? $modi : $url7 ;
if (is_file("kog/".$pagina.".php")) {
include("kog/".$pagina.".php");
}else{
include("kog/error.php");}
}
?>