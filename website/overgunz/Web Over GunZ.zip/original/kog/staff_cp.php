<?

$login = $_SESSION['login'];

$busca25 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login'");
$busca26 = mssql_fetch_row($busca25);

if ($busca26[0] == 255){
?>

<font color=red>Painel Do Administrador:<br></font>
<a href="?gz=addnoticia_222">Adicionar Noticia</a><br>
<a href="?gz=addcoins_222">Adicionar Coins</a><br>
<a href="?gz=addcoins_223">Adicionar EVCoins</a><br>
<a href="?gz=banir_222">Banir Usuario</a><br>
<a href="?gz=chatblock_222">Chat Block</a><br>
<a href="?gz=Normal_222">Retirar ChatBlock</a><br>
<a href="?gz=reset">Resetar Personagem</a><br><br>
<?
}
if ($busca26[0] == 254){
?>
<br>
<b><Font color=Lime>Painel Do GameMaster:</b><br></font>
<a href="?gz=banir_222">Banir Usuario</a><br>
<a href="?gz=chatblock_222">Aplicar ChatBlock</a><br>
<a href="?gz=Normal_222">Retirar ChatBlock</a><br>
<a href="?gz=addcoins_223">Adicionar EVCoins</a><br>
<a href="?gz=reset">Resetar Personagem</a><br><br>
<?
}
?>