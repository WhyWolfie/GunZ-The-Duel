﻿<form method="post" action="calc.php">
  <p>
    <input type="text" name="valor1">
    <br>
    <label>
      <input type="checkbox" name="option" value="somar" id="option_0">
      somar</label>
    <br>
    <label>
      <input type="checkbox" name="option" value="subtrair" id="option_1">
      subitrair</label>
    <br>
    <label>
      <input type="checkbox" name="option" value="dividir" id="option_2">
      dividir</label>
    <br>
    <label>
      <input type="checkbox" name="option" value="multiplicar" id="option_3">
      multiplicar</label>
    <br>
  </p>
  <p>
    <input type="text" name="valor2" id="textfield2">
  </p>
  <p>
    <input type="submit" name="button" id="button" value="Enviar">
    <input type="reset" name="button2" id="button2" value="Redefinir">
  </p>
</form>
<?
$valor1=$_POST['valor1'];
$valor2=$_POST['valor2'];
$option=$_POST['option'];
if($option=="somar")
{
$sinal=$valor1+$valor2;
echo"$valor1+$valor2=$sinal";	
};
if($option=="subtrair")
{
$sinal=$valor1-$valor2;
echo "$valor1-$valor2=$sinal";	
	};
if($option=="dividir")
{
$sinal=$valor1/$valor2;
echo"$valor1/$valor2=$sinal";	
};
if($option=="multiplicar")
{
$sinal=$valor1*$valor2;
echo"$valor1*$valor2=$sinal";
};
?>

