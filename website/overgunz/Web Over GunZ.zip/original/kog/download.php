<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<style>
#bg{ background: url(kog/download/download1.png);  height: 544px;
    width: 648px; 
}
#klinks{  background: none repeat scroll 0 0 ;
    height: 90px;
    position: relative;
    width: 580px;
    top: 416px;
    left: 36px; padding:5px;}
</style>

<div  id="bg">
<div id="klinks"> <ul>

<li><a href="#"> link1</a></li>
<li><a href="#"> link2</a></li>
<li><a href="#"> link3</a></li>
</ul></div>

</div>
<body>
</body>
</html>
