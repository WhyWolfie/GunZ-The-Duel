<b>Op��es Do usu�rio:</b><br><br>

<a href="?kog=minha_conta">Minha Conta</a><br>
<a href="?kog=alterar_senha">Alterar Senha</a><br>
<a href="?kog=editar_perfil">Editar Perfil</a><br>
<a href="?kog=meus_pag">Meus Pagamentos</a><br>
<a href="?kog=ev_coins">Trocar Pontos CW</a><br>
<a href="?kog=lider">TOP Ranking</a><br>
<a href="?kog=historico">Hist�rico De Compras</a><br>
<a href="?kog=sex">Alterar Sexo Do Personagem</a><br>
<a href="?kog=nick_name">Alterar NickName</a><br>
<a href="?kog=delet_clan">Deletar Clan</a><br>
<a href="?kog=deslogar">Sair</a><br><br>