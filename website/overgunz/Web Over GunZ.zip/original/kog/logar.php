﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Documento sem título</title>
</head>

<body>
<table width="252" border="0">
  <tr>
    <!--começo login-->
    <?
if (!(isset($_SESSION["login"])))
{
?>
    <td><form id="form1" name="login" method="post" action="?kog=validar">
     
        <label for="login"></label>
        <p> login
        <input type="text"  name="userid" id="login" />
      </p>
      <p>senha
        <input name="pass" type="password" id="senha" />
      </p>
      <p>
        <input type="submit" name="logar" id="logar" />
      </p>
      <div id="registro" onclick="window.location='?kog=registro'"></div>
      <div id="pass" onclick="window.location='?kog=senha'"><a href="#"></a></div>
      </p>
      <input type="hidden" name="submit" value="1" />
    </form></td>
  </tr>
  <?
}else{
?>
  <ul>
    <li class="options" onclick="window.location='?kog=minha_conta'">minha conta</li>
    <li class="options1" onclick="window.location='?kog=alterar_senha'">alterar senha</li>
    <li class="options2" onclick="window.location='?kog=alterar_senha'">edita perfil</li>
    <li class="options3" onclick="window.location='?kog=ev_coins'">pontos cw</li>
    <li class="options4" onclick="window.location='?kog=opções'">opções</li>
    <li id="deslogar" onclick="window.location='?kog=deslogar'"><p>deslogar<p></li>
  </ul>
  <?

$login22 = $_SESSION['login'];

$ugrade1 = mssql_query("SELECT UgradeID FROM Account WHERE UserID = '$login22'");
$ugrade2 = mssql_fetch_row($ugrade1);


if($ugrade2[0] == 255 OR $ugrade2[0] == 254)
{
?>
  <a href=""><img src="./images/staff_panel.png" border="0" width="120" height="20" style="position:absolute; left:930px; top:22px" /></a>
  <?
}
}

?>
  <!--fim login-->
</table>
</body>
</html>