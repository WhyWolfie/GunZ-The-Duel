<?
//Gaspar Owna =P

$login22 = Filtrrar($_SESSION["login"]);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

if($etapa22 == 0){
?>
<form id="ev_coins" name="ev_coins" method="post" action="?gz=ev_coins&etapa=1">
Personagem:
<select name="cid" class="text">
<?
$pegaLogin = mssql_fetch_row(mssql_query("SELECT AID FROM LOGIN WHERE UserID = '$login22'"));
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$pegaLogin[0]' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proximo" />
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("Este Personagem N�o Pertence a Nenhum Clan");
}else{

$_SESSION["CID"] = $cid22;
echo '
<font color=red>Aten��o:</font>A Cada 2 Pontos � o que vale a 1 EvCoin!<br><br>
<form id="ev_coins" name="ev_coins" method="post" action="?gz=ev_coins&etapa=2">';
echo "Ol� $login22 voc� tem $busca2[0] Pontos com o personagem selecionado para trocar em EvCoins.<br><br>";
echo "Quantos pontos deseja trocar?<br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="ev_coins" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

//BUG dos CID Corigido af
//$corrigi1 = mssql_query("SELECT AID FROM Account WHERE UserID = '$login22'");
//$corrigi2 = mssql_fetch_row($corrigi1);

//$corrigi3 = mssql_query("SELECT Name FROM Character WHERE AID = '$corrigi2' AND CID = '$cid23'");
//$corrigi4 = mssql_fetch_row($corrigi3);

//if (!(isset($corrigi4[0])))
//{
//die ("Este personagem n�o pertence a sua conta!");
//}else{

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "Voc� bebeu? Voc� tem $busca4[0] pontos e quer trocar por $pontos EvCoins -.-'";
}else{

if ( !is_numeric($cid23) )
{
echo "ID do personagem editado";
die();
}

if ( !is_numeric($pontos) )
{
echo "O N�mero de Coins precisa ser um n�mero";
die();
}

if ($pontos == 0)
{
echo "N�o h� necessidade de comprar 0 E Coins";
die();		
}

if($pontos < 1)
{
echo "Andou fumando maconha? Quer ficar com Coins negativos? O-O";
die();
}

$divisao = $pontos / 2;

mssql_query("update Account set EvCoins=EvCoins +$divisao where UserID='$login22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}

?>
