//ao carregar a pagina executa o codigo
$(function(){
    /**
     * Aqui pegamos o primeiro item e colocamos display bloc
     */         
    $(".conteudo:first").css({'display':'block'});
        /**
         * Agora é definido que ao clicar no link ele executa uma função
         */                 
         $("#nav a").click(function(){
          //pega o conteudo dentro do atributo href
          var div = $(this).attr('href');
         //esconde todos as divs
          $('.conteudo').css({'display': 'none'})
          /**
           *Agora com nome da div fazemos ela aparecer
           *e tbm vai sobrepor, tudo isso com o css           
           *           
           */
          $(div).css({
                    'display':'block', 
                    'z-index' : '99'
                    });
          
          //agora remove toda classe com nome ativo
          $('#nav a').removeClass('ativo');
          
          //agora adicona no link que for clicado a class ativo
          $(this).addClass('ativo');
           /**
            *  retornamos o link falso, q seja "anulado"
            *  e siga ação dele, de ir para mesma página ou para outra página
            */                                   
      
          return false;  
              })
          })