
<div class="span8">
	
          <div id="myCarousel" class="carousel slide">
		<ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
	
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>
            <div class="carousel-inner">

		<div class="item  active">
                <a href="index.php?skr=registro"><img src="img/p1.png" alt=""></a>
                <div class="carousel-caption">
                  <h4>Deseas Formar parte de nuestra Familia GhostGunz?</h4>
                  <p>Registrate Gratis y recibe premios automaticamente que te ayudaran a subir de nivel, UNETE YA!</p>
                </div>
              </div>

              <div class="item">
                <a href="index.php?do=evento3"><img src="img/p1.png" alt=""></a>
                <div class="carousel-caption">
                  <h4>Guerra de Clanes</h4>
                  <p>Gana premios, Coins y mucho mas para todo tu clan.</p>
                </div>
              </div>
              <div class="item">
                <a href="http://www.facebook.com/GhostGunz"><img src="img/p1.png" alt=""></a>
                <div class="carousel-caption">
                 <h4>Somos ya mas de 1000 fans en GhostGunz!</h4>
                  <p>Unete a nuestro grupo de Facebook te mantendremos informado de los acontecimientos de GhostGunz!.</p>
                </div>
              </div>
              
            </div>
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
          </div>

 </div>

