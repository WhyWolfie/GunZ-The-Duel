<div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
	<td><a href="?skr=donar">Donar a GhostGunZ</a></td>
	</tr>
<tr>
	<td><a href="?skr=staff">Miembros de Staff</a></td>
	</tr>
<tr>
	<td><a href="?skr=cambiopw">Cambiar Contrase&ntilde;a</a></td>
	</tr>
<tr>
	<td><a href="?skr=createclan">Crear clan </a></td>
	</tr>

<tr>
	<td><a href="#">Ganadores de Evento</a></td>
	</tr>
	
	
<tr>
	<td><a href="#">Ultimos ClanWar</a></td>
	</tr>
<tr>
	<td><a href="#">Ultimos DT</a></td>
	</tr>
<tr>
	<td><a href="#">Coins Facebook</a></td>
	</tr>
<tr>
	<td><a href="?skr=torneos">Torneos online</a></td>
	</tr>
<tr>
	<td><a href="#">Contacto</a></td>
	</tr>
<tr>
	<td> </td>
	</tr>
	</tbody>
</table>       
            </ul>

<p aling="center">

<a href="index.php?skr=createclan">
<img src="http://i.imgur.com/7m27lin.png" width="260" height="355" border="0" /></a>

</p>
<p aling="center">

<a href="index.php?skr=suerte">
<img src="http://i.imgur.com/Y8srJp7.png" width="280" height="355" border="0" /></a>

</p>
	<p aling="center"><a href="index.php?skr=donar"><img src="../img/Donate.png" width="260" height="255px" border="0" /></a></p>
          </div>
  