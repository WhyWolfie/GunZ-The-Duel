<?
if(!empty($_SESSION['AID']))
{
$g = "SELECT * From Account WHERE AID='".$_SESSION['AID']."'";
$r = skr_query($g);
$uh = skr_object($r);
$pin = $uh->PIN;

if(empty($pin)){
?>
<div class="span8">

<div class="alert alert-block fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
<strong> Genera tu PIN Usuario: <?=$pin?>   Asi puedes cambiar o recuperar tu contrase&ntilde;a:</strong><br>
Esto es urgente para la seguridad de tu cuenta. <a href="?skr=pingenerator">GENERAR PIN</a>
</div>
</div>

<? }

}else{ }?>