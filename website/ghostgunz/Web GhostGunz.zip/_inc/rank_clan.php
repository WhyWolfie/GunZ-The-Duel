<?
$r = skr_query("SELECT TOP 5 * From Clan  WHERE DeleteFlag = 0 Order BY Point DESC");


?>
<div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Ranking Clanes</li>
<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Clan</th>
            <th>Puntos</th>
          </tr>
        </thead>
        <tbody>

									<? 
									if(skr_num_rows($r)){
										$count = 1;
									while($clan = skr_object($r)){ ?>
                                    					<tr>

<td><?=$count++;?></td>
															<td>
<a href="?skr=info&clan=<?=$clan->CLID?>" role="button" data-toggle="modal">
<font color='black'><?=$clan->Name?></a></td>
															<td>
															<font color='black'><?=$clan->Point?>Pts.</font></td>
														</tr>
                                                        <? }
                                                        }else{
                                                       ?>
                                                       	<tr align="center">

<td colspan="3" > No hay clanes<font color='black'>&nbsp;</font></td>
														</tr>
                                                       <?
                                                        }
														
														 ?>
												             </tbody>
      </table>
            </ul>
          </div>