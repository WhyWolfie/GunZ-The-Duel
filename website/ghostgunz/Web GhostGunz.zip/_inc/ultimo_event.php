
<div class="span8">
 <div class="well">
	      <h3>Ultimos Eventos</h3>
<div class="alert alert-success fade in">
   <strong>
   <?
$qcw = skr_query("SELECT TOP 3 * From GanadorEvent Order By ID DESC");
if(skr_num_rows($qcw)){
while($event = skr_object($qcw))
	{
	
	
?>

<i class=icon-ok > </i> <?=Typeevent($event->TIPO)?>  
-  Win: <?=Name_AID($event->WIN)?> - By: <?=Name_AID($event->GM)?>  

<? // timesince($event->TIME) ?>



<br> 
<? }}else{ ?> 
Aun no hay clan war.
<? } ?>

</strong>

</div>
</div>
</div>