
<div class="span8">
 <div class="well">
	      <h3>Ultimos Clan War</h3>
<div class="alert alert-success fade in">
   <strong>
   <?
$qcw = skr_query("SELECT TOP 5 * From ClanGameLog Order By id DESC");
if(skr_num_rows($qcw)){
while($clan = skr_object($qcw))
	{
	
	
?>

<i class=icon-ok > </i> <?=$clan->WinnerClanName?> ( <?=$clan->WinnerMembers?> ) derroto ( <?=$clan->RoundWins?> - <?=$clan->RoundLosses?> ) a <?=$clan->LoserClanName?> ( <?=$clan->LoserMembers?> ) <?
$test = $clan->RegDate;
echo $test
?> <br> 
<? }}else{ ?> 
Aun no hay clan war.
<? } ?>

</strong>

</div>
</div>
</div>

