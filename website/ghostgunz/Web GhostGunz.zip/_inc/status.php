<div class="well sidebar-nav">
            <ul class="nav nav-list">

              <li class="nav-header">Traductor web</li>

<div align="center">
<div id="google_translate_element"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'es', includedLanguages: 'ar,de,en,es,fr,it,pt,ru,zh-CN', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        

       

 
</div>       
            </ul>
          </div>

<?
$useron = skr_query("SELECT * From ServerStatus");
$onlines = skr_object($useron);

?>
<div class="well sidebar-nav">
            <ul class="nav nav-list">
             
<li class="nav-header">Usuarios Online</li>
<div aling="center">
	
<i class="icon-signal"></i>Estadisticas del servidor <br>
<div class="progress progress-success progress-striped active">
  <div class="bar" rel="tooltip" title="Servidor <? status()?>% lleno " style="width: <? status()?>%; "></div>
</div>
El server est&aacute;: <span> <font color="#00d300">Encendido</font></span><br /><span><font color='#000'><?=$onlines->CurrPlayer?></font></span> Jugadores En Linea
</div>       
            </ul>
          </div>