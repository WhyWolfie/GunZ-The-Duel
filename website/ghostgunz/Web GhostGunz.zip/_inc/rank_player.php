<?
$p = skr_query("SELECT Top 5 * From Character WHERE DeleteFlag='0' Order By Level DESC");
?>
<div class="well sidebar-nav">
  <ul class="nav nav-list">
              <li class="nav-header">Ranking Jugadores</li>
<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Personaje</th>
            <th>Lvl</th>
          </tr>
        </thead>
        <tbody>
        
    <?
	if(skr_num_rows($p)){
		$count = 1;
	while($player = skr_object($p)){
		$kill = $player->KillCount;
		$death = $player->DeathCount;
	?>
 <tr><td><?=$count++;?></td><td>
<a href="#<?=$count?>myModal" role="button" data-toggle="modal">
<div id="<?=$count?>myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
 
    <h3 id="myModalLabel">Datos de <?=FormatCharName($player->CID)?></h3>
  </div>
  <div class="modal-body">
    <p><table><tr><td>Exp: <?=$player->XP?><br> Wins: <?=$kill?> 
<br>Loses:<br>Loses: <?=$death?> <br> Ratio: <? // RatioPlayer($kill,$death)?>%</td>
; &nbsp; </td><td>&nbsp; &nbsp;  </td><td><img src='' width='100' height='100'></td></table></p>
  </div>
  <div class="modal-footer">
    Click en cualquier lugar para cerrar ventana
  </div>
</div>

<font color='black'><?=FormatCharName($player->CID)?></a></td><td> <font color='black'><?=$player->Level?> Lvl.<td><tr> 

   </tbody>
 <?  
}
}else{
	?>
    <tr>
    <td colspan="3">No hay personajes.</td>
    </tr>
    
    <?
	
	}
?>
      </table>
              
            </ul>
          </div>


<?
$p = skr_query("SELECT Top 5 * From Character WHERE DeleteFlag='0' Order By PointEvent DESC");
?>
<div class="well sidebar-nav">
  <ul class="nav nav-list">
              <li class="nav-header">Ranking King Event</li>
<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Personaje</th>
            <th>Wins</th>
          </tr>
        </thead>
        <tbody>
        
    <?
	if(skr_num_rows($p)){
		$count = 1;
	while($player = skr_object($p)){
		$kill = $player->KillCount;
		$death = $player->DeathCount;
	?>
 <tr><td><?=$count++;?></td><td>
<a href="#<?=$count?>myModal" role="button" data-toggle="modal">
<div id="<?=$count?>myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
 
    <h3 id="myModalLabel">Datos de <?=FormatCharName($player->CID)?></h3>
  </div>
  <div class="modal-body">
    <p><table><tr><td>Exp: <?=$player->XP?><br> Wins: <?=$kill?> 
<br>Loses:<br>Loses: <?=$death?> <br> Ratio: <? // RatioPlayer($kill,$death)?>%</td>
; &nbsp; </td><td>&nbsp; &nbsp;  </td><td><img src='' width='100' height='100'></td></table></p>
  </div>
  <div class="modal-footer">
    Click en cualquier lugar para cerrar ventana
  </div>
</div>

<font color='black'><?=FormatCharName($player->CID)?></a></td><td> <font color='black'><?=$player->PointEvent?> Win.<td><tr> 

   </tbody>
 <?  
}
}else{
	?>
    <tr>
    <td colspan="3">No hay Ganador de eventos.</td>
    </tr>
    
    <?
	
	}
?>
      </table>
              
            </ul>
          </div>


