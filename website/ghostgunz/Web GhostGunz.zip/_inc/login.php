<?
if($_SESSION['AID'] == ""){?>
<form class="navbar-form pull-right" name="login" method="POST" action="index.php?skr=login">
  	<input type="text" name="userid" id="userid" class="input-small" placeholder="Usuario">
  	<input type="password" name="pass" id="pass" class="input-small" placeholder="Clave">
	<button type="submit" class="btn btn-inverse"><i class="icon-user icon-white"></i> Ingresar</button>
	
<input type="hidden" name="submit" value="1">
	</form>
    
    <? } else{
		$ver = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
		$acc = skr_object($ver);
		?>
    <div class="btn-group pull-right">
          <a class="btn btn-inverse" href="#"><i class="icon-user icon-white"></i> Bienvenido, 
<?=$_SESSION['UserID']?></a>
          <a class="btn btn-inverse dropdown-toggle" data-toggle="dropdown" href="#"><span class="caret"></span></a>
          <ul class="dropdown-menu">

<li><a href=""><i class="icon-remove-sign"> </i> TU AID: <?=$_SESSION['AID']?></a></li>
            

<li><a href="">Referidos: 0</a></li>
<li><a href=""><i class="icon-thumbs-up"></i> GCoins: <?=$acc->Coins?></a></li>
<li><a href=""><i class="icon-thumbs-up"></i> ECoins: <?=$acc->EventCoins?></a></li>
	
            <li><a href=""><i class="icon-shopping-cart"></i> DCoins:<?=$acc->DonatorCoins?></a></li>
	    	<li class="divider"></li>
            <li><a href="?skr=panel"><i class="icon-home"></i> Panel de Usuario</a></li>

			<?
		if($_SESSION['UGradeID'] == 254)
{
?>
<li><a href="?skr=gmpanel"><i class="icon-home"></i> Panel de GM</a></li>
<?
}
?>
		<?
		if($_SESSION['UGradeID'] == 255)
{
?>
<li><a href="?skr=adminpanel"><i class="icon-home"></i> Panel de ADMIN</a></li>
<?
}
?>


            <li><a href="#" ><i class="icon-pencil"></i> Perfil GhostFB</a></li>
  <li class="divider"></li>
<li><a href="">Premios Gratis (c/12h)</a></li>

<li><a onclick='postToFeed(); return false;'><i class="icon-thumbs-up"></i> Publicar por Premio</a></li>
            <li class="divider"></li>
            <li><a href="index.php?skr=logout"><i class="i"></i> Salir de la Cuenta</a></li>
          </ul>
        </div>
        <? } ?>