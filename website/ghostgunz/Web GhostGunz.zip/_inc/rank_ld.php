<div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Ranking DT</li>
<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th width="8">#</th>
            <th width="66">Personaje</th>
            <th width="29">&nbsp;</th>
             <th width="38">DT</th>
          </tr>
        </thead>
        <tbody>
<?
$te = 1;
$querydt = skr_query("SELECT TOP 5 * From DTCharacterRanking  Order By TP DESC");
if(skr_num_rows($querydt))
{
while($dt = skr_object($querydt)){
?>
														<tr>
<td><?=$te++?></td>
															<td><font color='black'><?=FormatCharName($dt->CID)?></td>
															<td>
															<font color='black'><img src="img/DT/<?=$dt->PreGrade?>.jpg" width="25" height="25" />
															</font></td>
                                                            <td>
															<font color='black'><?=$dt->TP?>Pts.</font></td>
													</tr>
                                                    <? } }else{ ?>
                                                    <tr><td colspan="4">No hay Ladder</td></tr>
                                                    <? } ?>
														
													         </tbody>
      </table>
            </ul>
          </div>