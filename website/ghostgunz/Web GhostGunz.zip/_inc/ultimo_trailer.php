<div class="span8">
<div class="well">
  <h3>Ultimos Trailer</h3>         
	      
	<ul class="thumbnails">
    
	
             
           <div class="alert alert-success fade in">
             
              <table>
              <tr><td>
              1ro<br />
             <iframe width="200" height="200" src="http://www.youtube.com/embed/PAZXHHG9cto" frameborder="0" allowfullscreen></iframe>
             </td>
             <td>
             2do<br />
             <iframe width="200" height="200" src="http://www.youtube.com/embed/WG2qCHON6GE" frameborder="0" allowfullscreen></iframe>
             </td></tr>
             </table>
           </div>
    
    
      </ul>
</div></div>