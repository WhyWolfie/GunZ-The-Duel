<div class="span8">
<div class="well">
  <h3>Ultimos Items Donador</h3>         
	      
	<ul class="thumbnails">
    <? 
	$q = skr_query("SELECT Top 4 * From TiendaDonante Order By ID DESC");
	if(skr_num_rows($q)){
	while($item = skr_object($q)){
		$img = $item->Img;
		?>
        <li class="span3">
          <div class="thumbnail">
            <img src="img/shop/<?=Img_ex($img)?>"  width="100" height="100" alt="">
            <div class="caption">
              <h5><?=$item->Name?></h5>
             <p><a href="index.php?skr=dcomprar&id=<?=$item->ID?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=rcomprar&id=<?=$item->ID?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
       <? }}else{ ?>
             
           <div class="alert alert-success fade in">
              <h5>No hay ultimos Items</h5>
             
           </div>
    
       <? } ?>
      </ul>
</div></div>