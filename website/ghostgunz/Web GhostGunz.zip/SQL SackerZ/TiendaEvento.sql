USE [Prueba]
GO

/****** Object:  Table [dbo].[TiendaEvento]    Script Date: 28/08/2013 04:21:28 p.m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[TiendaEvento](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](20) NULL,
	[Precio] [int] NULL,
	[ItemID] [int] NULL,
	[Img] [varchar](max) NULL,
	[Ventas] [int] NULL,
	[Tipo] [int] NULL,
	[Regalado] [int] NULL,
	[Fecha] [datetime] NULL,
	[Sexo] [int] NULL,
	[Level] [int] NULL,
	[Control] [int] NULL,
	[HP] [int] NULL,
	[AP] [int] NULL,
	[Damage] [int] NULL,
	[Peso] [int] NULL,
	[Duracion] [int] NULL,
	[Cartucho] [int] NULL,
	[MaxBalas] [int] NULL,
	[Retraso] [int] NULL,
	[MaxPeso] [int] NULL,
	[TCarga] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[TiendaEvento] ADD  CONSTRAINT [DF_TiendaEvento_ItemID]  DEFAULT ((0)) FOR [ItemID]
GO

ALTER TABLE [dbo].[TiendaEvento] ADD  CONSTRAINT [DF_TiendaEvento_Tipo]  DEFAULT ((0)) FOR [Tipo]
GO


