USE [Prueba]
GO

/****** Object:  Table [dbo].[WinEvent]    Script Date: 28/08/2013 04:38:47 p.m. ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[GanadorEvent](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[WIN] [int] NULL,
	[REGDATE] [datetime] NULL,
	[GM] [int] NULL,
	[TIPO] [int] NULL,
	[Coins] [int] NULL
	[RE] [int] NULL
) ON [PRIMARY]

GO


