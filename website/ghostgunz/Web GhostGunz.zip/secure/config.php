<?
@session_start();
// conexion sql //
$_HOST['IP']	=	"127.0.0.1";
$_HOST['HOST']	=	"Tu-PC\SQLEXPRESS";
$_HOST['USER']	=	"sa";
$_HOST['PASS']	=	"2saddasd";
$_HOST['DB']	=	"GunzDB";
$co = mssql_connect($_HOST['HOST'],$_HOST['USER'],$_HOST['PASS']);
mssql_select_db($_HOST['DB'],$co) or die("Error en conexion");
///////////////////////// CONFIG WEB /////////////////////
$_SESSION['NAMESVR'] = "GhostGunZ";

$foro = "http://foro.ghostgamerz.net";
$mantenimiento = "0";  // 1 mantenimiento   // 0 sin mantenimiento.
$link1			= "https://mega.co.nz/#!jZAxmJLL!URt3tng8BCOh1xL5BcrZpEwk4xpRPvKT5f7Z_ip4Soc";
$link2			= "https://mega.co.nz/#!jZAxmJLL!URt3tng8BCOh1xL5BcrZpEwk4xpRPvKT5f7Z_ip4Soc";
$link3			= "https://mega.co.nz/#!jZAxmJLL!URt3tng8BCOh1xL5BcrZpEwk4xpRPvKT5f7Z_ip4Soc";
$link4			= "https://mega.co.nz/#!jZAxmJLL!URt3tng8BCOh1xL5BcrZpEwk4xpRPvKT5f7Z_ip4Soc";
$foroggz		= "http://foro.ghostgamerz.net";




$addpanel = "additem";
// Config no tocar //
$DONATOR_DC = "0";  //
$EVENT_DC =  "0";	

///////////////
$D_DC = $DONATOR_DC;
$E_DC = $EVENT_DC;
date_default_timezone_set("AMERICA/LIMA");

// CODING BY SACKERZ

// SACKERZ.BLOGSPOT.COM
?>