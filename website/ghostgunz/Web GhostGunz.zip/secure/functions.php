﻿<?php
include "anti_hack.php";
if($activation == "adqwdwqdwqaoiasnfoasdqwdwqdweg4g45g45g45hgjh45h45haisxiaib45h4h45h45h4qeqd2d45h45hqwdwqdwqaoiasnfoasinfsaasnfsaoinfoaisxiaib==wqeqd2infsaasnfsaoinfoaisxiaib==wqeqd2adqwdwqdwqaoiasnfoasdqwdwqdweg4g45g45g45hgjh45h45haisxiaib45h4h45h45h4qeqd2d45h45hqwdwqdwqaoiasnfoasinfsaasnfsaoinfoaisxiaFQWFQFAHRWEHW65168AGSGqd2infsaasnfsaoinfoaisxiaiGWEGWGWEGWEGHRPOMPOPOJP651651684ON"){
function Logz($log){
$fp = fopen("errorlog.txt", "a+");
	$time = date("d/m/Y H:i:s"); 
	fwrite($fp,"$log  -  HORA:$time \t\n");
	$linea = fgets($fp);
	fclose($fp);
}
function LogQuery($log){
$fp = fopen("Querylog.txt", "a+");
	$time = date("d/m/Y H:i:s"); 
	fwrite($fp,"$log  -  HORA:$time \t\n");
	$linea = fgets($fp);
	fclose($fp);
}
function GetEmblem($emblema)
		{
			if(empty($emblema))
			{
				$emblema = "Q3lHDBD.png";
			}
			return $emblema;
		}
$FGH = "aHR0cDovL2d1bnouZ2hvc3RnYW1lcnoubmV0Lw";
function Name_AID($aid){
$xe = skr_query("SELECT * From Account WHERE AID='".$aid."'");
$gano = skr_object($xe);
return $gano->Name;
}
function GetCharLevel($cid)
{
	$char = skr_query("SELECT * From Character WHERE CID='".$cid."'");

	if(skr_num_rows($char) == 0)
	{
		$level = 1;
	}else{
		$char2 = skr_object($char);
		$level = $char2->Level;
	}
	return $level;
}
function Typeevent($type)
	{
		switch($type)
		{
			case 1:
			return "Evento Escondite";
			break;
			case 2:
			return "Evento Linea Enemiga";
			break;
			case 3:
			return "Evento Buscaminas";
			break;
			case 4:
			return "Evento Boss";
			break;
			case 5:
			return "Evento Atrapa la bomba";
			break;
			case 6:
			return "Evento Supervivencia";
			break;
			case 7:
			return "Evento Desconocido.";
			break;
			default:
			return "otro";
        break;
			}
		}
function Chek_GM($AID,$type)
	{
	$FGH = "aHR0cDovL2d1bnouZ2hvc3RnYW1lcnoubmV0Lw";
	$q =		skr_query("SELECT * From Account WHERE AID='".clean($AID)."'");
	$acc	= skr_object($q);
	$grade = $acc->UGradeID;	
		switch($grade){
		case 255:
			return "Administrador";
			break;
			case 254:
			$FGH = "aHR0cDovL2d1bnouZ2hvc3RnYW1lcnoubmV0Lw";
			if($type == 2){ msgbox("No tiene permiso",base64_decode($FGH)); }
			return "Desarrollador";
			break;
			case 252:
			return "Moderador";
			break;	
			default:
			$FGH = "aHR0cDovL2d1bnouZ2hvc3RnYW1lcnoubmV0Lw";
            return msgbox("Error en web.",base64_decode($FGH));
        break;
		}
		}

function IsBan($ugrade)
{
if($ugrade == 253)
{
msgbox("Usted esta banneado no puede acceder.","index.php");
}
}
function NO_GM($UGRADE)
	{
	return $UGRADE;
			
		}
function AIDIS($userid)
	{
		$query = skr_query("SELECT * From Account WHERE UserID='".clean($userid)."'");
		$acc = 	skr_object($query);

		return $acc->AID;
		}
function FormatCharName($cid)
{
    $ncid = clean($cid);
    $res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character(nolock) ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));

    $name = $res[1];

    switch($res[0])
    {
        case 255:
            return "<font color='#FF0000' style=' text-shadow: #FF0000 0px 0px 9px; background:url();'>$name</font>";
        break;
        case 254:
            return "<font color='#00FF00' style=' text-shadow: #00FF00 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 4:
            return "<font color='#5F04B4' style=' text-shadow: #5F04B4 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 5:
            return "<font color='#DF01A5' style=' text-shadow: #DF01A5 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 7:
            return "<font color='#04B404' style=' text-shadow: #04B404 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 6:
            return "<font color='#B18904' style=' text-shadow: #B18904 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 8:
            return "<font color='#04B4AE' style=' text-shadow: #04B4AE 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 9:
            return "<font color='#00F7FF' style=' text-shadow: #00F7F 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 10:
            return "<font color='#E6EC69' style=' text-shadow: #E6EC69 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 11:
            return "<font color='#ECB705' style=' text-shadow: #ECB705 0px 0px 9px; background:url();'>$name</font>";
        break;
		case 12:
            return "<font color='#000000' style=' text-shadow: #000000 0px 0px 9px; background:url();'>$name</font>";
        break;
		
        default:
            return $name;
        break;
    }
}

function Sex($sex)
	{
		switch($sex)
		{
			case 0:
			return "Hombre";
			break;
			case 1:
			return "Mujer";
			break;
			case 2:
			return "Todos";
			break;
			}
		}
function Item_Type($sex)
	{
		switch($sex)
		{
			case 0:
			return "Ropa";
			break;
			case 1:
			return "Arma de fuego";
			break;
			case 2:
			return "Espada";
			break;
			case 3:
			return "Item Especial";
			break;
			}
		}
function Num_item($numero)
	{
		if(empty($numero)){
			return 0;
			}else{
				return $numero;
				}
		}

function Img_ex($img)
	{
		if($img == "")
		{
			return "noimagen.png";
			}else{
				return $img;
				}
		}
function Img_clan($img)
	{
		if($img == "")
		{
			return "noemblem.png";
			}else{
				return $img;
				}
		}
		

function Logueo($userid, $pass)
	{
	if(empty($userid) || empty($pass))
	{
		msgbox("Error: No deje campos vacios.","index.php");
		}
	$q = skr_query("SELECT * From Login WHERE UserID='".$userid."' AND Password='".$pass."'");
	if(!skr_num_rows($q))
	{
		msgbox("Su cuenta no existe","index.php");
	}else{
		$login = skr_object($q);
		$r  = skr_query("SELECT * From Account WHERE UserID='".$userid."' AND AID='".$login->AID."'");
		$acc = skr_object($r);
		IsBan($acc->UGradeID);
		$_SESSION['AID']	= $acc->AID;
		$_SESSION['UserID']	= $acc->UserID;
		$_SESSION['UGradeID'] = $acc->UGradeID;
		$user = $acc->UserID;
		$grado = UserType($acc->UGradeID);
		msgbox("Bienvenido a GhostGunZ $grado : $user ","index.php");
		}
		
	}
	
function CreateAcc($userid,$pw1,$pw2,$email,$edad,$pais,$name,$sex,$codigo)
	{
	if(empty($codigo) || empty($userid) || empty($pw1) || empty($pw2) || empty($email) || empty($edad) || empty($pais))
		{
		msgbox("Error: Dejo campos vacios","?skr=registro");
		}
	$res = "SELECT * From Account ";
	$q = skr_query("$res WHERE UserID='".$userid."'");
	$r = skr_query("$res WHERE Email='".$email."'");
// CODING BY SACKERZ

// SACKERZ.BLOGSPOT.COM	
	
	//Nueva version verificador de la nueva cuenta
	// $re = skr_query("SELECT * From AccountLOG WHERE UserID='".$userid."'");
//	$re2 = skr_query("SELECT * From AccountLOG WHERE Email='".$email."'");
//	if(skr_num_rows($re)){
//		msgbox("Usuario ya existe","?skr=registro");
//		}
//	if(skr_num_rows($re2)){
//		msgbox("Email ya existe","?skr=registro");
//		}
// CODING BY SACKERZ

// SACKERZ.BLOGSPOT.COM	
	
	if($pw1 != $pw2){
		msgbox("Error: Su contraseña no considen","?skr=registro");
		}
	if(skr_num_rows($r))
		{
		msgbox("Email: $email esta siendo usado.","?skr=registro");
		}
	if(skr_num_rows($q))
		{
		msgbox("Usuario $userid esta siendo usado.","?skr=registro");
		}
	if(!is_numeric($edad))
		{
		msgbox("Error: Ingrese su edad correctamente(User Números).","?skr=registro");
		}
	if(!is_numeric($pais))
		{
		msgbox("Error en su pais","?skr=registro");
		}
	if(!is_numeric($codigo)){
			msgbox("Error en su PIN SOLO INGRESE NUMEROS","?skr=registro");
	}else{
		if(strlen($codigo) != 8){
				msgbox("INGRESE 8 NUMEROS EN PIN","?skr=registro");
			}
	}
	
	if(!is_numeric($sex))
		{
		msgbox("Error en tu sexo ","?skr=registro");
		}
	$query = "INSERT INTO Account (UserID, UGradeID, PGradeID, Email, Age, ZipCode, Name, RegDate, Sex, DonatorCoins, EventCoins) VALUES ('$userid', '0', '0', '$email', '$edad', '$pais', '$name', GETDATE(),'$sex', '0', '0')";
	if(skr_query($query))
		{
		$r1		= skr_query("SELECT * From Account WHERE UserID='".$userid."'");
		$acc	= skr_object($r1);
		$aid	= $acc->AID;
		$user	= $acc->UserID;
		skr_query("INSERT INTO Login (UserID,  AID, Password) VALUES ('$user',  '$aid', '$pw1')");
//		skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650043', GETDATE(), '168', '1')");
//		skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650044', GETDATE(), '168', '1')");
//		skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '680005', GETDATE(), '168', '1')");
//		skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '680006', GETDATE(), '168', '1')");
//     	skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '3000291', GETDATE(), '168', '1')");
//    	skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650014', GETDATE(), '168', '1')");
//    	skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '8000053', GETDATE(), '168', '1')");
//    	skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '200075', GETDATE(), '168', '1')");
//    	skr_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '164686', GETDATE(), '168', '1')");
		msgbox("Bienvenido a GhostGunZ, se le regalo items donante.","index.php"); 
		}else{
			msgbox("Error en el registro ","?skr=registro");
			}
	}
// CODING BY SACKERZ

// SACKERZ.BLOGSPOT.COM
function UserType($ugradeid)
	{
		switch($ugradeid){
			case 0:
			 return "Usuario";
			break;
			case 254:
			 return "Moderador";
			break;
			case 255:
			 return "Administrador";
			break;
			 default:
            return $name;
      		break;
			}
		}


if(!function_exists("re_dir") )
{
function re_dir($url)
{
    echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

function clean($value)
{
        $check = $value;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script' ,'/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'DELETE', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');

        $value = str_replace($search, '', $value);

        $value = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);

        if( $check != $value )
        {
            $logf = fopen("injection.txt", "a+");
            fprintf($logf, "%s (m_%s.php) - [AID=%s] - Date: %s IP: %s Valor: %s, Fixed: %s\r\n", $_SERVER[PHP_SELF],$_GET['do'], $_SESSION['AID'],date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
            $str = "aHR0cDovL2d1bnouZ2hvc3RnYW1lcnoubmV0Lw";
			$str2 = "V2ViIEJ5IFNhY2tlclo=";
			msgbox(base64_decode($str2),base64_decode($str));			
        }

        return( $value );
}

if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }


function PlayerRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

function GetClanPercent($Wins, $Losses)
{
    $total = $Wins + $Losses;

    return ($total == 0) ? "0%" : round((100 * $Wins) / $total, 2) . "%";
}
function status(){
	$q = skr_query("SELECT * From ServerStatus");
	$svr =  skr_object($q);
	$usuarios = $svr->CurrPlayer;
	$max = $svr->MaxPlayer;
	$total = $usuarios * 100 / $max;
	$too = (int) $total;
	
	echo $too;
	
	}
function DC_COINS($price, $TIPODCT){
	return (int) $price;
}
function skr_query($query){
	return @mssql_query($query);
}
function skr_object($query){
	return @mssql_fetch_object($query);
	}
function skr_num_rows($query){
	return @mssql_num_rows($query);
	}
function timesince($original) {
$ta = array(
array(31536000, "Año", "Años"),
array(2592000, "Mes", "Meses"),
array(604800, "Semana", "Semanas"),
array(86400, "Día", "Días"),
array(3600, "Hora", "Horas"),
array(60, "Minuto", "Minutos"),
array(1, "Segundo", "Segundos")
);
$since = time() - $original;
$res = "";
$lastkey = 0;
for( $i=0; $i<count($ta); $i++ ){
$cnt = floor($since / $ta[$i][0]);
if ($cnt != 0) {
$since = $since - ($ta[$i][0] * $cnt);
if($res == ""){
$res .= ($cnt == 1) ? "1 {$ta[$i][1]}" : "{$cnt} {$ta[$i][2]}";
$lastkey = $i;
} else if ($ta[0] >= 60 && ($i - $lastkey) == 1 ){
$res .= ($cnt == 1) ? " y 1 {$ta[$i][1]}" : " y {$cnt} {$ta[$i][2]}";
break;
} else {
break;
}
}
}
return $res;
}
function s(){
	echo base64_decode("U2Fja2VyWg==");
	}

function DesBan()
{
	/*
$time = time();
$d = skr_query("SELECT * From AccountBan WHERE TimeBan <= '$time' AND ET='0'");
while($ban = skr_object($d))
{
	$id = $ban->ID;
	$aid = $ban->AID;
	$ugrade = $ban->UGradeID;
	skr_query("UPDATE Account SET UGradeID='$ugrade' WHERE AID='".$aid."'");
	skr_query("DELETE From AccountBan WHERE ID='".$id."'");
	msgbox("","index.php");
//}

}
*/
}}else{
die("Error en key");
}










// CODING BY SACKERZ

// SACKERZ.BLOGSPOT.COM
?>