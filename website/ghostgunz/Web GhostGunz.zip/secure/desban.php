<?
// Desban 
$time = time();
$d = skr_query("SELECT * From Account WHERE TimeBan <= '$time' AND ET='0'");
while($ban = skr_object($d))
{
	$id = $ban->ID;
	$aid = $ban->AID;
	$ugrade = $ban->UGradeID;
	skr_query("UPDATE Account SET UGradeID='$ugrade' WHERE AID='".$aid."'");
	skr_query("DELETE From AccountBan WHERE ID='".$id."'");
}
?>