<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_hack.php";
?>