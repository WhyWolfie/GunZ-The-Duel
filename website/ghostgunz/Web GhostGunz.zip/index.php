<?
include ("includes.php");
DesBan();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="google-translate-customization" content="dd3ab2470aae83e6-bbc3cf485b3295ec-g81ccfda96f259688-14"></meta>
<title>GhostGunZ - Version 2013 </title>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
<link href="/favicon.ico" rel="shortcut icon">

<script language="JavaScript"> 

function bderecho(e) { 
if (navigator.appName == 'Netscape' && (e.which == 3 || e.which == 2)) 
return false; 
else if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3)) { 
alert(" El boton derecho del raton no funciona "); 
return false; 
} 
return true; 
} 
if (document.layers) window.captureEvents(Event.MOUSEDOWN);

window.onmousedown=right; 

function keypressed() { 
alert(" Las teclas no funcionan "); 
} 
document.onmousedown=right; 
document.onkeydown=keypressed; 

</script>



</head>

<body OnContextMenu="return false" >


<br><br><br>
 <div id='fb-root'></div>
    <script type="text/javascript" src="http://connect.facebook.net/en_US/all.js"></script>
<script> 
      FB.init({appId: "489964681041693", status: true, cookie: true});

      function postToFeed() {

        // calling the API ...
        var obj = {
          method: 'feed',
          redirect_uri: 'http://www.ghostgunz.com/index.php?do=facebookfeed',
          link: 'www.ghostgunz.com/',
          picture: 'http://i.imgur.com/IxGumjP.png',
          name: 'GhostGunz 2013',
          caption: 'Tu mejor eleccion!',
          description: 'Servidor dedicado de calidad, Eventos diarios, multiples opciones que haran de tu juego satisfactorio!, Unete Ya!'
        };

        function callback(response) {
          document.getElementById('msg').innerHTML = "Post ID: " + response['post_id'];
        }

        FB.ui(obj, callback);
      }
    
    </script>
<!-- coding by SackerZ -->


<div class="navbar navbar-fixed-top navbar-inverse">
  <div class="navbar-inner">
    <div class="container">

	<a class="brand" href="index.php">
	  <img src="img/banner_2.png" width="70" height="20">
	</a>
	<ul class="nav navbar-fixed-top navbar-inverse">
<li class="divider-vertical"></li>
		
  		<li><a href="index.php?skr=registro">Registro</a></li>
		<li class="divider-vertical"></li>
  		<li><a href="index.php?skr=descargas">Descargas</a></li>
		<li class="divider-vertical"></li>

		<li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Tienda<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="index.php?skr=shop"><i class="icon-thumbs-up"> </i> Inicio de Tienda</a></li>
                      <li class="divider"></li>
                      <li><a href="index.php?skr=shopevento"><i class="icon-shopping-cart"> </i> Tienda Evento</a></li>
			
                      <li class="divider"></li>
                      <li><a href="index.php?skr=shopdonante"><i class="icon-shopping-cart"> </i> Tienda Donador</a></li>
			
                     	
                    </ul>
                  </li>

		<li class="divider-vertical"></li>
		<li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ranking<b class="caret"></b></a>
                    <ul class="dropdown-menu">
                      <li><a href="index.php?skr=rankplayer"><i class="icon-globe"> </i> Ranking Jugadores</a></li>
                      <li class="divider"></li>
                      <li><a href="?skr=rankclan"><i class="icon-globe"> </i> Ranking Clanes</a></li>
			
                    		
                                 
</ul><!-- coding by SackerZ -->
                  </li>
		<li class="divider-vertical"></li>
		

		<li><a href="<?=$foroggz?>">Foro</a></li>
		<li class="divider-vertical"></li>

	</ul>
	<? include "_inc/login.php"; ?>

    </div>
  </div>

</div>
<span style="display:block;text-align:center;" ><img src="img/background.png" alt="descripci�n de imagen" /></span> 
    <div class="container">
 <div class="well2">

 <li class="nav-header">Publicidad:
</li>
<div align="center">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0193781963240618";
/* GhostGunZ */
google_ad_slot = "1898901896";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
</div>
<!-- coding by SackerZ -->
       <?
		
	  if($mantenimiento == 0){
	  if(isset($_GET['skr'])){
		  $do = ($_GET['skr']);
		
		  }else{
			  $do = "index";
			  }
	  if(file_exists("mod/mod_$do.php")){
		  include "mod/mod_$do.php";
		  }else{
			  msgbox("Error: No se encontro la pagina.","index.php");
			  }
	  
	  }else{
		  include "mantenimiento.php";
		  }
	  ?>
    
    
      
 <hr>
<footer>
        <div align="center">
		
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0193781963240618";
/* GhostGunz */
google_ad_slot = "3892051203";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

	

<br><br>
<p aling="center">&copy; GhostGunZ 2013 Coding By <a href="http://sackerz.blogspot.com/"><?=s()?></a> - Todos los Derechos Reservados</p>

</footer>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script> 
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
<script src="js/jquery.js"></script>
<script src="js/google-code-prettify/prettify.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootstrap-popover.js"></script>
<script src="js/bootstrap-tooltip.js"></script>
<script src="js/aplication.js"></script>
<script type="text/javascript">
    $("[rel=tooltip]").tooltip();

</script>
<noscript><a href="http://sackerz.blogspot.com/">Web css by Anonimo coding by <?=s()?></a></noscript> 

</body>
<br><br>

<!-- coding by SackerZ -->
<div style="display:none;"><a name="livezilla_chat_button" href="javascript:void(window.open('http://gunzghost.eshost.es/SoportChat/chat.php?acid=5f214','','width=590,height=760,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'))" class="lz_cbl"><img id="chat_button_image" src="http://gunzghost.eshost.es/SoportChat/image.php?acid=d6f6d&amp;id=1&amp;type=overlay" width="37" height="123" style="border:0px;" alt="LiveZilla Live Chat Software" /></a></div><div id="livezilla_tracking" style="display:none"></div><script type="text/javascript">
/* <![CDATA[ */
var script = document.createElement("script");script.async=true;script.type="text/javascript";var src = "http://gunzghost.eshost.es/SoportChat/server.php?acid=7684d&request=track&output=jcrpt&fbpos=10&fbml=0&fbmt=0&fbmr=0&fbmb=0&fbw=37&fbh=123&nse="+Math.random();setTimeout("script.src=src;document.getElementById('livezilla_tracking').appendChild(script)",1);
/* ]]> */
</script><noscript><img src="http://gunzghost.eshost.es/SoportChat/server.php?acid=7684d&amp;request=track&amp;output=nojcrpt&amp;fbpos=10&amp;fbml=0&amp;fbmt=0&amp;fbmr=0&amp;fbmb=0&amp;fbw=37&amp;fbh=123" width="0" height="0" style="visibility:hidden;" alt="" /></noscript>






















































<!-- coding by SackerZ -->