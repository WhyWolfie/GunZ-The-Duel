<?
if(isset($_POST['submit'])){
	$userid = clean($_POST['userid']);
	$pass	= clean($_POST['pass']);
	Logueo($userid, $pass);
	

}else{
re_dir("index.php");
}
?>