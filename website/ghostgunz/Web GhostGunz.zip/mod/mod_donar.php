﻿<?
if(empty($_SESSION['AID'])){
	msgbox("No puede entrar aqui estando logueado","index.php");
	}
?>
<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <div class="span8 well" >
<h1>Donaciones a <?=$_SESSION['NAMESVR']?></h1>
<br><br>
<div align="left">
  <div style="text-align: left; font-size: 14px;" id="result_box" dir="ltr">
    <p><strong>Donaciones Via SMS </strong> </p>
    <ul>
      <li>Por cada donacion, es decir por cada sms se le dara</li>
      <li>60 DonatorCoins, para que sirve? para comprar items donante en nuestra web shop.</li>
      <li>Para hacer la donacion abajo veran un cuadro.</li>
      <li>Selecionaran su pa&iacute;s y les saldra.</li>
      <li>El mensaje que tienen que enviar para hacer la donacion.</li>
      <li>Para ello donde dice &quot;TU AID&quot; (sin comillas) en esa parte pones tu aid.</li>
      <li>¿Como saber cual es tu AID?</li>
      <li>Muy facil cuando estas logueado en nuestra web abajo de los coins te dice <b style="color:red;">TU AID:
        <?=$_SESSION['AID']?>
      </b></li>
      <li>Teniendo todo listo puedes hacer tu donaciones con exito.</li>
    </ul>
    <b style="color:red;">SI ERES DE PERU Y QUIERES RECIBIR MAS DCOINS PUEDES COMUNICARTE CON EL <a href="http://www.facebook.com/S4ckerZ">Facebook Administrador SackerZ</a> Y TE DIREMOS OTRO METODO DE DONACION SOLO PARA PERU</b>
    <p>
    <script src="http://iframes.recursosmoviles.com/v2/?wmid=4409&cid=22754" type="text/javascript"></script>
    </p>
    <p>En todo cazo pueden ir al foro si no te llegaron los DonadorCoins a tu Cuenta y te llego el mensaje, diciendo que la compra fue un exito, Deberas entrar a nuestro foro ir a la seccion de Donaciones y hacer un Nuevo Tema Con el siguiente titulo.</p>
    <p><strong>[Reporte]</strong> mas el Titulo que vas a poner tu </p>
    <p>Deberas poner en el Tema los siguientes datos </p>
    <p>&nbsp;</p>
    <strong>Tu AID:<b style="color:red;">
      <?=$_SESSION['AID']?>
      </b>
      <p>Tu Pais: </p>
      <p>Como enviaste: </p>
      <p>Numero celular: </p>
      <p>Fecha y hora de envio: </p>
      </strong>
    <p>Recuerda Poner bien los datos para haci evitar problemas. </p><br /><br />
    <p style="color: #F00; font-size: 18px; font-weight: bold;">Compras DonatorCoins Via Paypal </p>
    <p style="color: #F00; font-size: 18px; font-weight: bold;">&nbsp;</p>
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
      <input type="hidden" name="cmd" value="_s-xclick" />
      <input type="hidden" name="hosted_button_id" value="6RHS9QDXSJQBL" />
      <table>
        <tr>
          <td><input type="hidden" name="on0" value="DonatorCoins" />
            DonatorCoins</td>
        </tr>
        <tr>
          <td><select name="os0">
            <option value="110 DCoins">110 DCoins $5.00 USD</option>
            <option value="270 DCoins">270 DCoins $10.00 USD</option>
            <option value="410 DCoins">410 DCoins $15.00 USD</option>
            <option value="560 DCoins">560 DCoins $20.00 USD</option>
            <option value="1150 DCoins">1150 DCoins $40.00 USD</option>
          </select></td>
        </tr>
        <tr>
          <td><input type="hidden" name="on1" value="TU AID o UserID" />
            TU AID o UserID</td>
        </tr>
        <tr>
          <td><input type="text" name="os1" maxlength="200" /></td>
        </tr>
      </table>
      <input type="hidden" name="currency_code" value="USD" />
      <input type="image" src="https://www.paypalobjects.com/es_XC/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal, la forma más segura y rápida de pagar en línea." />
      <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1" />
    </form>
    <p>Al hacer la compra via Paypal envie un email o un mensaje al administrador general con el id de trasferencia. </p>
    <p><a href="http://www.facebook.com/S4ckerZ">Facebook Administrador</a> <strong></strong> </p>
    <p>Reclamos y soporte a nuestro administrador general </p>
    <p><a href="http://www.facebook.com/S4ckerZ">Facebook Administrador</a> <strong></strong> </p>
    <p>&nbsp;</p>
    <center>
     
    </center>
    <p style="color: #F00; font-size: 18px; font-weight: bold;">Comprar DonatorCoins via BCP </p>
    <table width="418" border="0">
      <tr>
        <td colspan="3" style="font-weight: bold; text-align: center; color: #C90;">Precio por compra de DCoins via BCP</td>
      </tr>
      <tr>
        <td width="48">DonatorCoins:</td>
        <td width="68">400</td>
        <td width="277">s/.  20.0</td>
      </tr>
      <tr>
        <td>DonatorCoins:</td>
        <td>600</td>
        <td>s/. 30.0</td>
      </tr>
      <tr>
        <td>DonatorCoins:</td>
        <td>800</td>
        <td>s/. 40.0</td>
      </tr>
      <tr>
        <td>DonatorCoins:</td>
        <td>1000</td>
        <td>s/. 50.0</td>
      </tr>
    </table>
    <table width="415" border="0">
      <tr>
        <td colspan="2" style="color: #C60; text-align: center;">Cuenta  de ahorro &gt;<span style="font-weight: bold">BCP</span>&gt;</td>
      </tr>
      <tr>
        <td width="68">Titular:</td>
        <td width="331"><p>FRANCISCO DANIEL PEREYRA PRUDENCIO</p></td>
      </tr>
      <tr>
        <td>Nº Cuenta:</td>
        <td style="font-size: 18px; font-weight: bold; font-family: Verdana, Geneva, sans-serif;">191-24890183-0-97</td>
      </tr>
    </table>
    <ul>
      <li>Despues de hacer el deposito escanear Baucher.</li>
      <li>Enviarlo al siguiente email o facebook.</li>
      <li>Con su UserID o AID de su cuenta.</li>
    </ul>
    <p>Enviar a:</p>
    <p>E-mail: s4cker@hotmail.com<br />
      Facebook: <a href="http://www.facebook.com/S4ckerZ" target="new">Facebook para confirmacion</a></p>
    <p>Comunicarse con el administrador.</p>
    <a href="?skr=donarbcp"> Enviar datos y vaucher al administrador.</a>
  </div>
</div>
  </div>
        
        
        
<? /* include "_inc/publi.php";
   //           <!--/row-->


//<!--/span-->
 include "_inc/ultimo_items.php";
 include "_inc/ultimo_cw.php";*/ ?>


</div>