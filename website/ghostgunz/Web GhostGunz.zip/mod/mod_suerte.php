<?
if(empty($_SESSION['AID']))
{
	msgbox("Debe estar logueado para acceder.","index.php");
}

if(isset($_POST['suerte']))
{
	$num = clean($_POST['num']);
	$precio = 20;

$ram = rand(1, 20);
$r = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
$q = skr_object($r);
$coins = $q->Coins;
$total = $coins-$precio;
$ecoins = $q->EventCoins;
$etotal = $ecoins+70;
$aid = $q->AID;
if($total < 0)
{
	msgbox("Usted no tiene sufiente GCoins para Usar esta opcion.","index.php");
}
if($num > 20)
{
	msgbox("Error en numero.","index.php");
}
if($num == $ram)
{
	skr_query("UPDATE Account SET EventCoins='$etotal', Coins='$total' WHERE AID='".$aid."'");
	msgbox("Ganaste 70  EventCoins Felicidades.","index.php?skr=suerte");
}else{
	skr_query("UPDATE Account SET Coins='$total' WHERE AID='".$aid."'");
	msgbox("Numero ganador fue: $ram  , No gano  gracias por jugar.","index.php?skr=suerte");
}


}

?>

<div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
  <table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
  <tr>
  <td><a href="index.php?skr=shop">Inicio Tienda</a></td>
  </tr>
  <tr>
  <td><a href="index.php?skr=shopevento">Tienda Event</a></td>
  </tr>
  <tr>
  <td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
  </tr>
  
  
  </tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
  <table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
  <td><a href="index.php?do=donar">Donar</a></td>
  </tr>
<tr>
  <td><a href="index.php?do=staff">Staff</a></td>
  </tr>

<tr>
  <td><a href="index.php?do=listamedallas">Medallas</a></td>
  </tr>
  
  
<tr>
  <td><a href="index.php?do=ultimoscw">Ultimos ClanWar</a></td>
  </tr>

  </tbody>
</table>       
            </ul>
          </div><!--/.well -->
  
   


</div><!--/span-->



              <div class="span9 well" >
<h1><!-- IMG --></h1>

            <strong> </strong>
<br><br>          

<div class="well">
<div class="alert alert-success">Juego de suerte Coins. <br> Con Este juego puede ganar 70 EventCoins si conside con el numero ganador de la maquina. <br> Por cada juego se le descuenta 30 Coins.


<b>Seleccione un numero del 1-20 </b>
</div>


<div class="input-append">
<form name="from1" method="post" >
  

	Ingresa elige un numero:
	<select name="num" class="form-control" style="width: 100px;">
		<?
		for($i=1; $i<=20; $i++){?>
			<option value="<?=$i?>"><?=$i?></option>
		<? }?>
		
	</select>
  <input type="submit" name="suerte" class="btn btn-inverse" value="Jugar." />
  </form>
</div>
</div>
</div>
</div>
</div>
