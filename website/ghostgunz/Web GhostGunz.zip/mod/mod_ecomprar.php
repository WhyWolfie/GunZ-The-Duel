
<?
if(empty($_SESSION['AID'])){
		msgbox("Estar logueado antes de comprar.","index.php?skr=shopevento");
		}
		
if(!isset($_POST['submit']))
{
	
	$x = clean($_GET['id']);
	
	if(empty($x)){
		msgbox("Error en el item","index.php?skr=shopevento");
		}
	if(!is_numeric($x)){
		msgbox("Error en item.","index.php?skr=shopevento");
		}
		
}
if(isset($_POST['itemid']))
			{	
					$id = clean($_POST['itemid']);
					$aid = clean($_SESSION['AID']);
				
				
			
			if(!is_numeric($id))
				{
					msgbox("Error en tienda","index.php");
					}
			$ver = skr_query("SELECT * From TiendaEvento WHERE ID='".clean($id)."'");
			if(skr_num_rows($ver) == 0)
				{
				msgbox("Error en tienda","index.php");	
				}
			$query2 = skr_query("SELECT * From Account WHERE AID='".clean($aid)."'");
			$vitem = skr_object($ver);
			$cuenta = skr_object($query2);
			$vitemid = $vitem->ItemID;
			$aid = $cuenta->AID;
			$ecoins = $cuenta->EventCoins;
			$price =	DC_COINS($vitem->Precio, $E_DC);
			$total = $ecoins - $price;
			
		if($total < 0)
			{
				msgbox("No te alcanza","index.php?skr=shopevento");
				}
			$ok = "INSERT INTO AccountItem (AID, RentDate, ItemID, Cnt) VALUES ('$aid', GETDATE(), '$vitemid', '1')";
			if(skr_query($ok)){
			skr_query("UPDATE Account SET EventCoins='$total' WHERE AID='".$aid."'");
			skr_query("UPDATE TiendaEvento SET Ventas=Ventas+1 WHERE ID='".$id."'");
			Logz("ShopEvent: Compro AID: $aid   Precio: $price Tenia EC: $ecoins AHORA TIENE: $total");
			msgbox("Su compra fue con exito revise su central bank o storage","index.php?skr=shopevento");
					
				}else{
					msgbox("Error al comprar $ok","index.php");
					}}else{
					//saca data 
					$itemid = clean($_GET['id']);
					$qe = skr_query("SELECT * From TiendaEvento WHERE ID='".$itemid."'");
					$item = skr_object($qe);
					$name = $item->Name;
					$precio = DC_COINS($item->Precio, $E_DC);
					//data account
					$query = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
					$acc = skr_object($query);
					$dcoins = $acc->EventCoins;
				
					
					}

?>

<div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
	<tr>
	<td><a href="index.php?skr=shop">Inicio Tienda</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopevento">Tienda Event</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
	</tr>
	
	
	</tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
	<td><a href="index.php?do=donar">Donar</a></td>
	</tr>
<tr>
	<td><a href="index.php?do=staff">Staff</a></td>
	</tr>

<tr>
	<td><a href="index.php?do=listamedallas">Medallas</a></td>
	</tr>
	
	
<tr>
	<td><a href="index.php?do=ultimoscw">Ultimos ClanWar</a></td>
	</tr>

	</tbody>
</table>       
            </ul>
          </div><!--/.well -->
	
   


</div><!--/span-->



              <div class="span9 well" >
<h1><!-- IMG --></h1>

            <strong>Comprar Item Evento:  <?=$name?> </strong>
<br><br>          

<div class="well">
<form method="post" name="frmBuy">
<table style="border-collapse: collapse" border="0" height="100%" width="633">
  <tbody>
    <tr>
      <td width="58">&nbsp;</td>
      <td width="124" align="center">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="58">&nbsp;</td>
      <td valign="top" width="124"><img src="img/shop/<?=Img_ex($item->Img)?>" style="border: 2px solid #1D1B1C" border="0" height="120" width="120"></td>
      <td colspan="2"><div align="center">
        <table style="border-collapse: collapse" class="table table-condense" border="0" height="100%" width="428">
          <tbody>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Tipo: </b></font></td>
              <td align="left" width="146"> <?=Item_Type($item->Tipo)?></td>
              <td align="left" width="61"><font color="black"><b>Hp: </b></font></td>
              <td align="left" width="146"><?=Num_item($item->HP)?></td>
              <td align="left" width="61"><font color="black"><b>Cartucho: </b></font></td>
              <td width="5">&nbsp;</td>
              <td align="left" width="146"><?=Num_item($item->Cartucho)?></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Sexo:</b></font></td>
              <td align="left" width="146"> <?=Sex($item->Sexo)?></td>
              <td align="left" width="61"><font color="black"><b>Ap: </b></font></td>
              <td align="left" width="146"><?=Num_item($item->AP)?></td>
              <td align="left" width="61"><font color="black"><b>MaxBalas: </b></font></td>
              <td width="5">&nbsp;</td>
              <td align="left" width="146"><?=Num_item($item->MaxBalas)?></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Nivel:</b></font></td>
              <td align="left" width="146"><?=Num_item($item->Level)?></td>
              <td align="left" width="61"><font color="black"><b>Damage: </b></font></td>
              <td align="left" width="146"><?=Num_item($item->Damage)?></td>
              <td align="left" width="61"><font color="black"><b>Retraso: </b></font></td>
              <td width="5">&nbsp;</td>
              <td align="left" width="146"><?=Num_item($item->Retraso)?></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Precio:</b></font></td>
              <td align="left" width="146"><span id="currentprice"><?=DC_COINS($item->Precio,$E_DC)?></span></td>
              <td align="left" width="61"><font color="black"><b>Peso: </b></font></td>
              <td align="left" width="146"><?=Num_item($item->Peso)?></td>
              <td align="left" width="61"><font color="black"><b>MaxPeso: </b></font></td>
              <td width="5">&nbsp;</td>
              <td align="left" width="146"><?=Num_item($item->MaxPeso)?></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Control:</b></font></td>
              <td align="left" width="146"><?=Num_item($item->Control)?></td>
              <td align="left" width="61"><font color="black"><b>Duracion: </b></font></td>
              <td align="left" width="146"><?=Num_item($item->Duracion)?></td>
              <td align="left" width="61"><font color="black"><b>T.Carga: </b></font></td>
              <td width="5">&nbsp;</td>
              <td align="left" width="146"><?=Num_item($item->TCarga)?></td>
            </tr>
          <input name="itemid" value="<?=$item->ID?>" type="hidden">
        </table>
      </div></td>
    </tr>
    <tr>
      <td width="58">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
      <td rowspan="4" align="left" width="1">&nbsp;</td>
    </tr>
    <tr>
      <td width="58">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435"><div align="center">
        <table style="border-collapse: collapse" border="0" height="66" width="480">
          <tbody>
            <tr>
              <td width="469" style=" background-repeat: no-repeat;"><table style="border-collapse: collapse" class="well table-condensed" border="0" height="100%" width="492">
                <tbody>
                  <tr>
                    <td colspan="4" >    <div align="center">Eterno
                                </div>
                      </td>
                  </tr>
                  <tr>
                    <td width="206">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Compra:</b></font></td>
                    <td align="left" width="150"><span id="Total"><?=$precio?></span></td>
                    <td width="1">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="206">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Tienes:</b></font></td>
                    <td align="left" width="150"><span id="currbalance"><?=$dcoins?></span></td>
                    <td width="1">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="206">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Tendra:</b></font></td>
                    <td align="left" width="150"><span id="afterpur"><?=$dcoins - $precio?></span></td>
                    <td width="1">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="4" height="1"></td>
                  </tr>
                </tbody>
              </table></td>
              <td style="background-repeat: no-repeat; background-position: left center" width="10">&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </div></td>
    </tr>
    <tr>
      <td width="58">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
    </tr>
    <tr>
      <td width="58">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="4">
      		<p align="center">
									
                                	<a href="javascript:document.frmBuy.submit();" class="btn btn-small">
									<i class="icon-shopping-cart"></i>Comprar
									</a>
									<a href="" class="btn btn-small btn-inverse">
									<i class="icon-remove icon-white"></i>Cancelar
									
									</a>
								
								
							
						</p>
      
      </td>
    </tr>
</table>
</form>
</div>
</div>
</div>
</div>









