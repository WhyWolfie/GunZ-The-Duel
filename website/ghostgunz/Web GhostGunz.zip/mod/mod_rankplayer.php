<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <?
		skr_query("UPDATE Character SET Ranking='0'");
		$q = skr_query("SELECT TOP 100 * From Character WHERE Name != '' Order By XP DESC");
		$c = 1;
		while($r = skr_object($q)){
			skr_query("UPDATE Character SET Ranking='".$c."' WHERE CID='".$r->CID."'");
			$c++;
			}
		if(isset($_POST['buscar'])){
			$name = clean($_POST['name']);
			
			if(empty($name)){
				msgbox("Porfavor no deje el campo vacio.","?skr=rankplayer");
				}		
				
			$q = skr_query("SELECT * From Character WHERE Name='".$name."'");
			}else{
				if(isset($_GET['page'])){
					$page = clean($_GET['page']);
					if(!is_numeric($page))
						{
						$page = 1;
						}
					}else{
						$page = 1;
						}
				switch($page){
					case 1:
					$ir = "WHERE Ranking <= '20'";
					break;
					case 2:
					$ir = "WHERE Ranking >= '21' AND Ranking <='40'";
					break;
					case 3:
					$ir = "WHERE Ranking >= '41' AND Ranking <='60'";
					break;
					case 4:
					$ir = "WHERE Ranking >= '61' AND Ranking <='80'";
					break;
					case 5:
					$ir = "WHERE Ranking >= '81' AND Ranking <='100'";
					break;
					
					}
				$q  = skr_query("SELECT * From Character ".$ir." AND Ranking !='0' Order By Ranking ASC");
				}
		?>
        <div class="span8 well" >
<h1><!-- IMG --> </h1>
<br>
            <strong>Ranking de Jugadores </strong>
<div align="center">

<div class="input-append">
<form name="from1" method="post" action="">
  <input class="span6" name="name" id="appendedInputButtons" type="text">
  <input type="submit" name="buscar" class="btn btn-inverse" value="Buscar personaje" />
  </form>
</div>


</div>
         
<div class="well" align="center">
<span class="label label-danger" style="background-color: red;">Administrador</span>
<span class="label">Donator</span>
<span class="label label-info">Donator</span>
<span class="label label-success">Donator</span>
<table class="table table-condensed">
        <thead>
          <tr>
		<th> </th><th> </th><th> </th>
            <th>Rank</th>
            <th>Personaje</th>
            <th>Lvl</th>
            <th>Exp</th>
            <th>Kill / Death Ratio</th>
		
          </tr>
        </thead>
        <tbody>
        <?
		if(skr_num_rows($q)){
			$count = 1; 
		while($char = skr_object($q)){
 			$xp = $char->XP;
		
		?> 
        <tr> 
        <td> </td><td> </td><td> </td><td><?=$char->Ranking?></td><td>
<a href="#<?=$count?>myModale" role="button" data-toggle="modal"><font class=normal ><?=FormatCharName($char->CID)?>
<div id="<?=$count?>myModale" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
 
    <h3 id="myModalLabel">Datos de <?=FormatCharName($char->CID)?></h3>
  </div>
  <div class="modal-body">
    <p><table><tr><td>Exp: <?=$xp?><br> Wins: <?=$char->KillCount?> 
<br>Loses: <?=$char->DeathCount?> <br> Ratio: 0.0%</td>
<td> &nbsp; &nbsp; </td><td>&nbsp; &nbsp;  </td><td><img src='' width='100' height='100'></td></table></p>
  </div>
  <div class="modal-footer">
    Click en cualquier lugar para cerrar ventana
  </div>
</div>
</font></td><td><?=$char->Level?>Lvl. </td><td><?=$xp?></td>
<td><?=$char->KillCount?> / <?=$char->DeathCount?> (0.0)%</td>

<tr>
      
        <?
		$count++;
		}
		}else{
		?>
           </tbody>
        <tr align="center">
          <td colspan="8"><center>Personaje no existe.</center></td></tr>
        
        <? }?>
        
      </table>
             
              <div class="pagination">
  <ul>
   <li><a href="?skr=rankplayer&page=1">[1-20]</a></li>
   <li><a href="?skr=rankplayer&page=2">[21-40]</a> </li>
   <li> <a href="?skr=rankplayer&page=3">[41-60]</a></li>
   <li> <a href="?skr=rankplayer&page=4">[61-80]</a> </li>
   <li> <a href="?skr=rankplayer&page=5">[81-100]</a> </li>
  
  </ul>



<ul class="thumbnails">

</ul>

</div>
</div>
</div>
       


</div>