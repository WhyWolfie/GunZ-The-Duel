<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <?
		skr_query("UPDATE Clan SET Ranking='0'");
		$q = skr_query("SELECT TOP 100 * From Clan WHERE Name != '' Order By Point DESC");
		$c = 1;
		while($r = skr_object($q)){
			skr_query("UPDATE Clan SET Ranking='".$c."' WHERE CLID='".$r->CLID."'");
			$c++;
			}
		if(isset($_POST['buscar'])){
			$name = clean($_POST['name']);
			
			if(empty($name)){
				msgbox("Porfavor no deje el campo vacio.","?skr=rankclan");
				}		
				
			$q = skr_query("SELECT * From Clan WHERE Name='".$name."'");
			}else{
				if(isset($_GET['page'])){
					$page = clean($_GET['page']);
					if(!is_numeric($page))
						{
						$page = 1;
						}
					}else{
						$page = 1;
						}
				switch($page){
					case 1:
					$ir = "WHERE Ranking <= '20'";
					break;
					case 2:
					$ir = "WHERE Ranking >= '21' AND Ranking <='40'";
					break;
					case 3:
					$ir = "WHERE Ranking >= '41' AND Ranking <='60'";
					break;
					case 4:
					$ir = "WHERE Ranking >= '61' AND Ranking <='80'";
					break;
					case 5:
					$ir = "WHERE Ranking >= '81' AND Ranking <='100'";
					break;
					
					}
				$q  = skr_query("SELECT * From Clan ".$ir." AND Ranking !='0' Order By Ranking ASC");
				}
		?>
        <div class="span8 well" >
<h1><!-- IMG --> </h1>
<br>
            <strong>Ranking de Clan</strong>
            <div class="well"><div align="center">
<table><tr height="100">
        
          <?
		  $top = skr_query("SELECT * From Clan WHERE Name != '' Order By Point DESC");
		  $i = 1;
		  while($top3 = skr_object($top)){
			  
			  $rank[$i]['name'] = $top3->Name;
			  $rank[$i]['emble'] = $top3->EmblemUrl;
			  $i++;
			  
			  }
		  ?>
            <td width="100" align="center"><img class='img-rounded' 
 src='http://i.imgur.com/<?=GetEmblem($rank[1]['emble'])?>' width='100' height='100'>             <br><b style="

color: red; text-shadow: red 0px 0px 9px; background:url();"><?=$rank[1]['name']?></td><td width="25"></td>
           
        
          
            <td width="100" align="center"><img class='img-rounded' src='http://i.imgur.com/<?=GetEmblem($rank[2]['emble'])?>' width='100' height='100'>             <br><b style="color: #01A9DB; text-shadow: #01A9DB 0px 0px 9px; background:url();"><?=$rank[2]['name']?></td><td width="25"></td>
           
        
          
            <td width="100" align="center"><img class='img-rounded' src='http://i.imgur.com/<?=GetEmblem($rank[3]['emble'])?>' width='100' height='100'>             <br><b style="color: #9A2EFE; text-shadow: #9A2EFE 0px 0px 9px; background:url();"><?=$rank[3]['name']?></td><td width="25"></td>
           
        
          
            
           
</table>
</div></tr></div>
<div align="center">

<div class="input-append">
<form name="from1" method="post" action="">
  <input class="span6" name="name" id="appendedInputButtons" type="text">
  <input type="submit" name="buscar" class="btn btn-inverse" value="Buscar Clan" />
  </form>
</div>


</div>
         
<div class="well" align="center">
<table class="table table-condensed">
        <thead>
          <tr>
		<th> </th><th> </th><th> </th>
            <th>Rank</th>
            <th>Nombre</th>
            <th>MasterClan</th>
            <th>Points</th>
            <th>Wins / Losses Ratio</th>
		
          </tr>
        </thead>
        <tbody>
        <?
		if(skr_num_rows($q)){
			$count = 1; 
		while($char = skr_object($q)){
 			$xp = $char->Point;
		
		?> 
        <tr> 
        <td> </td><td> </td><td> </td><td><?=$char->Ranking?></td><td>
<a href="?skr=info&clan=<?=$char->CLID?>" role="button" data-toggle="modal"><font class=normal ><?=$char->Name?>

</font></td><td><?=FormatCharName($char->MasterCID)?> </td><td><?=$xp?></td>
<td> <?=$W = $char->Wins?> / <?=$L = $char->Losses?>  (<?=GetClanPercent($W,$L)?>)</td>

<tr>
      
        <?
		$count++;
		}
		}else{
		?>
           </tbody>
        <tr align="center">
          <td colspan="8"><center>No existe Clan.</center></td></tr>
        
        <? }?>
        
      </table>
             
              <div class="pagination">
  <ul>
   <li><a href="?skr=rankclan&page=1">[1-20]</a></li>
   <li><a href="?skr=rankclan&page=2">[21-40]</a> </li>
   <li> <a href="?skr=rankclan&page=3">[41-60]</a></li>
   <li> <a href="?skr=rankclan&page=4">[61-80]</a> </li>
   <li> <a href="?skr=rankclan&page=5">[81-100]</a> </li>
  
  </ul>



<ul class="thumbnails">

</ul>

</div>
</div>
</div>
       


</div>