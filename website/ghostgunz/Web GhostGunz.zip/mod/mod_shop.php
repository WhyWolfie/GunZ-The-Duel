<div class="row-fluid">





        <div class="span3">


        
       <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
	<tr>
	<td><a href="index.php?skr=shop">Inicio Tienda</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopevento">Tienda Event</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
	</tr>
	
	
	</tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <? include "_inc/menu.php"; ?><!--/.well -->
	
   


</div><!--/span-->

              <div class="span8 well" >
<h1><!-- IMG--> </h1>
<br>

<div class="alert alert-block fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Ultimos Items Evento </strong>
          


<div class="well" align="center">

<ul class="thumbnails">
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/vB26fwz"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Teddy</h5>
              <p><a href="index.php?do=buyevento&itemid=171&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevento&itemid=171&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/UX6SFnT"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Marowak</h5>
             <p><a href="index.php?do=buyevento&itemid=170&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevento&itemid=170&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
           </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/sKKliD0" width="100" height="100" alt="">
            <div class="caption">
              <h5>JigglyPuff</h5>
               <p><a href="index.php?do=buyevento&itemid=169&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevento&itemid=169&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
           </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/PynLFwh"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Yoda</h5>
               <p><a href="index.php?do=buyevento&itemid=168&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevento&itemid=168&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
           </div>
        </li>
</ul>
</div>
</div>


<div class="alert alert-block alert-error fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Ultimos Items Donador </strong>
          


<div class="well" align="center">

<ul class="thumbnails">
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/raISufO"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Zeta Sword</h5>
              <p><a href="index.php?do=buyevent&itemid=725&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevent&itemid=725&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/62EmUxU"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Real Sword</h5>
             <p><a href="index.php?do=buyevent&itemid=724&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevent&itemid=724&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
             </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/NAdqBCL" width="100" height="100" alt="">
            <div class="caption">
              <h5>Barca Sword</h5>
             <p><a href="index.php?do=buyevent&itemid=723&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevent&itemid=723&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
             </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <img src="images/shop/9BJJ3xU"  width="100" height="100" alt="">
            <div class="caption">
              <h5>Deidara Avatar</h5>
             <p><a href="index.php?do=buyevent&itemid=722&cat=" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?do=giftevent&itemid=722&cat=" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
          </div>
        </li>
</ul>
</div>
</div>
</div>
</div>