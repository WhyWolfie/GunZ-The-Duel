<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
          <div class="span8 well" >
        <div class="well">
		<center><font><table border="0"  style="border-collapse: collapse; border-color: #000000">
<tbody>
  <tr>
    <td height="24" style="background-image: url('./images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top"><table border="0" width="600" style="border-collapse: collapse; float:left">
      <tbody>
        <tr>
          <td width="8">&nbsp;</td>
          <td colspan="3">&nbsp;</td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8">&nbsp;</td>
          <td align="center" colspan="3"></td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8">&nbsp;</td>
          <td colspan="3">&nbsp;</td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8">&nbsp;</td>
          <td width="183">&nbsp;</td>
          <td width="344"><div align="center"> Selecciona uno de los siguientes sitios para descargar <br>GhostGunZ<br>
            <br>
            
            <table border="0" width="100%" style="border-collapse: collapse">
              <tbody>
                <tr align="center">
                  
		<td width="23%"><a href="<?=$link2?>" target="_new" class="btn btn-large btn-primary">Mega </a></td>
                  <td width="23%"><a href="<?=$link2?>" class="btn btn-large btn-primary">4Shared</a></td>
                  <td width="26%"><a href="<?=$link3?>" class="btn btn-large btn-primary">Rapishared</a></td>
                  <td width="31%"><a href="<?=$link4?>" class="btn btn-large btn-primary">Mediafire</a></td>
                  
                </tr>
                </tbody>
              </table>
            </div></td>
          <td width="30">&nbsp;</td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8">&nbsp;</td>
          <td colspan="3">&nbsp;</td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8"></td>
          <td height="180" valign="top" colspan="3" style="background-repeat: no-repeat; background-position: center top; "><div align="center">
            <table cellspacing="1" cellpadding="3" border="0" width="100%"  class="table table-bordered">
              <tbody>
                <tr>
                  <td height="21" width="80"><span>&nbsp;</span></td>
                  <td height="21" width="220"><b><span> Requerimientos M�nimos </span></b></td>
                  <td height="21" width="220"><b><span> Requerimientos Recomendados </span></b></td>
                  </tr>
                <tr>
                  <td align="center"><span>OS</span></td>
                  <td align="center" colspan="2"><span> Windows XP, Windows Vista 32/64 bit, Windows 7 32/64 bit</span></td>
                  </tr>
                <tr>
                  <td align="center"><span> DirectX</span></td>
                  <td align="center" colspan="2"><span> DirectX 9.0c o superior</span></td>
                  </tr>
                <tr>
                  <td align="center"><span> Procesador</span></td>
                  <td align="center"><span> Pentium IV 1.0 Ghz</span></td>
                  <td align="center"><span> Core 2 Duo 1.33 Ghz </span></td>
                  </tr>
                <tr>
                  <td align="center"><span> Memoria</span></td>
                  <td align="center"><span> 512 MB</span></td>
                  <td align="center"><span> 1 GB o m�s</span></td>
                  </tr>
                <tr>
                  <td align="center"><span> Tarjeta de Video</span></td>
                  <td align="center"><span> Compatible con Direct3D 9.0 </span></td>
                  <td align="center"><span> GeForce 4 MX o mejor</span></td>
                  </tr>
                <tr>
                  <td align="center"><span> Tarjeta de Sonido</span></td>
                  <td align="center" colspan="2"><span> Compatible con Direct3D Sound </span></td>
                  </tr>
                <tr>
                  <td align="center"><span> Mouse</span></td>
                  <td align="center" colspan="2"><span> Se recomienda un mouse con Scroll (Ruedita)</span></td>
                  </tr>
                </tbody>
              </table>
            </div></td>
          <td width="13">&nbsp;</td>
          </tr>
        <tr>
          <td width="8">&nbsp;</td>
          <td valign="top" colspan="3">&nbsp;</td>
          <td width="13">&nbsp;</td>
          </tr>
        </tbody>
      </table></td>
</tr>
</tbody></table>
</font></center><p>&nbsp;</p>	</div></div>
       


</div>