﻿<?
if(empty($_SESSION['AID']))
{
  msgbox("Error, debe estar logueado.","index.php");
}
// sacar players
$query = skr_query("SELECT * From Character WHERE AID='".$_SESSION['AID']."'");
$query2 = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
$players = mssql_num_rows($query);
$i = 1;
while($char = skr_object($query))
{
  $cid[$i]  = $char->CID;

  $i++;
}
?>


<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
  

        </div><!--/span-->
        
        <div class="span8 well" >
          <?
          $acc = skr_object($query2);
          ?>
          DATOS PERSONALES: 
          Aviso: Si su email no es valio o falso, comunicarse con el administrador, ya<br> que las recuperaciones y cambios de password se haran via email.<br>
          <table>
            <tr>
              <td>
                UserID:
              </td>
               <td>
                <?=$_SESSION['UserID']?>
              </td>
            </tr>
              <tr>
              <td>
                Email:
              </td>
               <td>
                <?=$acc->Email?>
              </td>
            </tr>
              <tr>
              <td>
                PIN GHOSTGZ:
              </td>
               <td>
<?=$acc->PIN?>
              </td>
            </tr>
          </table>
<div class="panel panel-info"> Paneles Clan
    <table class="table table-hover">
        <thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Emblema</th>
            <th>N° Integrantes</th>
            <th>Panel Clan</th>
          </tr>
        </thead>
        <tbody>
        <?
        for($a = 1; $a<= 5; $a++)
        {
          $r = skr_query("SELECT * From Clan WHERE MasterCID='".$cid[$a]."'");
          if(skr_num_rows($r) == 1)
          {
            $clan = skr_object($r);
            ?>
            <tr>
            <td><?=$clan->Ranking?></td>
            <td><?=$clan->Name?></td>
            <td><img src="http://i.imgur.com/<?=GetEmblem($clan->EmblemUrl)?>" width="40" height="40" /></td>
            <td>-</td>
            <td><a href="index.php?skr=info&clan=<?=$clan->CLID?>"> Panel Master</a></td>
          </tr>
            <?
          }
        }
        ?>
          

        </tbody>
      </table>

</div>


 </div>

</div>

</div>