<?
if(empty($_SESSION['AID'])){
		msgbox("Estar logueado antes de comprar.","index.php?skr=shopevento");
		}
if(isset($_POST['itemid']))
			{	
					$id = clean($_POST['itemid']);
					$aid = clean($_SESSION['AID']);
					$colorid = clean($_POST['colorid']);
					function ugrade_ver($grade){
						switch($grade)
						{
							case 4:
							return;
							break;
							case 5:
							return;
							break;
							case 6:
							return;
							break;
							case 7:
							return;
							break;
							case 8:
							return;
							break;
							case 9:
							return;
							break;
							case 10:
							return;
							break;
							case 11:
							return;
							break;
							case 12:
							return;
							break;
							case 13:
							return;
							break;
							case 14:
							return;
							break;
							

							case 255:
							msgbox ("Error en grado","index.php");
							break;
							case 252:
							msgbox ("Error en grado","index.php");
							break;
							case 254:
							msgbox ("Error en grado","index.php");
							break;
							
							
							}
						}
						ugrade_ver($colorid);
			if(!is_numeric($id))
				{
					msgbox("Error en tienda","index.php");
					}
			$ver = skr_query("SELECT * From TiendaDonante WHERE ID='".clean($id)."'");
			if(skr_num_rows($ver) == 0)
				{
				msgbox("Error en tienda","index.php");	
				}
			$query2 = skr_query("SELECT * From Account WHERE AID='".clean($aid)."'");
			$vitem = skr_object($ver);
			$cuenta = skr_object($query2);
			$vitemid = $vitem->ItemID;
			$aid = $cuenta->AID;
			$CUGrade = $cuenta->UGradeID;
			$total = $cuenta->DonatorCoins - $vitem->Precio;
			  NO_GM($CUGrade);
			if($total < 0)
			{
				msgbox("No te alcanza","index.php?skr=shopdonante");
				}
			$ok = "UPDATE Account SET UGradeID='$colorid' WHERE AID='".$aid."'";
			if(skr_query($ok)){
			skr_query("UPDATE Account SET DonatorCoins='$total' WHERE AID='".$aid."'");
			skr_query("UPDATE TiendaDonante SET Ventas=Ventas+1 WHERE ID='".$id."'");
			
			msgbox("Su compra de name color fue con exito. ","index.php?skr=shopdonante");
				
				
				}else{
					msgbox("Error al comprar","index.php");
					}}else{
					//saca data 
					$idid 	= $namecolor;
					$itemid = clean($idid);
					$qe = skr_query("SELECT * From TiendaDonante WHERE ID='".$itemid."'");
					$item = skr_object($qe);
					$name = $item->Name;
					$precio = $item->Precio;
					//data account
					$query = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
					$acc = skr_object($query);
					$dcoins = $acc->DonatorCoins;
					
					}


?>
 <STYLE type="text/css">
                        OPTION{ background-color: #ffffff }
                       	      OPTION.vip1{color:#5F04B4; font-weight: bold }
			    OPTION.vip2{color:#FF01C0; font-weight: bold }
			    OPTION.vip3{color:#8DFF00; font-weight: bold }
			    OPTION.vip4{color:#B18904; font-weight: bold }
			    OPTION.vip5{color:#04B4AE; font-weight: bold }
			    OPTION.vip6{color:#FFFF00; font-weight: bold }
			    OPTION.vip7{color:#00FFFC; font-weight: bold }
			    OPTION.vip8{color:#005EFF; font-weight: bold }
			    OPTION.vip9{color:#000000; font-weight: bold }
			    OPTION.vip10{color:#AA6AE2; font-weight: bold }
			    OPTION.vip11{color:#4F9B58; font-weight: bold }

			    
			
                        


                        </STYLE>
<div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
	<tr>
	<td><a href="index.php?skr=shop">Inicio Tienda</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopevento">Tienda Event</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
	</tr>
	
	
	</tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
	<td><a href="index.php?do=donar">Donar</a></td>
	</tr>
<tr>
	<td><a href="index.php?do=staff">Staff</a></td>
	</tr>

<tr>
	<td><a href="index.php?do=listamedallas">Medallas</a></td>
	</tr>
	
	
<tr>
	<td><a href="index.php?do=ultimoscw">Ultimos ClanWar</a></td>
	</tr>

	</tbody>
</table>       
            </ul>
          </div><!--/.well -->
	
   


</div><!--/span-->



              <div class="span9 well" >
<h1><!-- IMG --></h1>

            <strong>Comprar Especial Donante:  <?=$name?> </strong>
<br><br>          

<div class="well">
<form method="post" name="frmBuy">
<table style="border-collapse: collapse" border="0" height="100%" width="633">
  <tbody>
    <tr>
      <td width="58" height="21">&nbsp;</td>
      <td width="124" align="center">&nbsp;</td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td width="58" height="139">&nbsp;</td>
      <td valign="top" width="124"><img src="img/shop/<?=Img_ex($item->Img)?>" style="border: 2px solid #1D1B1C" border="0" height="120" width="120"></td>
      <td colspan="2"><div align="center">
        <table style="border-collapse: collapse" class="table table-condense" border="0" height="100%" width="397">
          <tbody>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Tipo: </b></font></td>
              <td align="left" width="303"> <?=Item_Type($item->Tipo)?></td>
              </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Nivel:</b></font></td>
              <td align="left" width="303"><?=Num_item($item->Level)?></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="61"><font color="black"><b>Precio:</b></font></td>
              <td align="left" width="303"><span id="currentprice"><?=Num_item($item->Precio)?></span></td>
              </tr>
          <input name="itemid" value="<?=$item->ID?>" type="hidden">
        </table>
        <div align="center"> Selecciona el Color para tus Personajes:&nbsp;&nbsp;
          <select class="rose" name="colorid">
            
            <option selected="selected" class="vip1" value="4">Color VIP 1</option>
            <option class="vip2" value="5">Color VIP 2</option>
            <option class="vip3" value="6">Color VIP 3</option>
            <option class="vip4" value="7">Color VIP 4</option>
	    <option class="vip5" value="8">Color VIP 5</option>
            <option class="vip6" value="9">Color VIP 6</option>
            <option class="vip7" value="10">Color VIP 7</option>
            <option class="vip8" value="11">Color VIP 8</option>
	    <option class="vip9" value="12">Color Black  VIP 9</option>
	    <option class="vip10" value="13">[New]Color VIP 10</option>
	    <option class="vip11" value="14">[New]Color  VIP 11</option>
          </select>
        </div>
      </div></td>
    </tr>
    <tr>
      <td width="58" height="21">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
      <td rowspan="4" align="left" width="1">&nbsp;</td>
    </tr>
    <tr>
      <td width="58" height="226">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435"><div align="center">
        <table style="border-collapse: collapse" border="0" height="66" width="435">
          <tbody>
            <tr>
              <td style=" background-repeat: no-repeat;"><table style="border-collapse: collapse" class="well table-condensed" border="0" height="100%" width="419">
                <tbody>
                  <tr>
                    <td colspan="3" align="center"><br>
                      <font color="black">Duracion al comprar este Item (Permanente)</font></td>
                  </tr>
                  <tr>
                    <td width="216">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Compra:</b></font></td>
                    <td align="left" width="62"><span id="Total"><?=$precio?></span></td>
                    <td width="16">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="216">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Tienes:</b></font></td>
                    <td align="left" width="62"><span id="currbalance"><?=$dcoins?></span></td>
                    <td width="16">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="216">&nbsp;</td>
                    <td align="left" width="117"><font color="black"><b>Tendra:</b></font></td>
                    <td align="left" width="62"><span id="afterpur"><?=$dcoins - $precio?></span></td>
                    <td width="16">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="4" height="1" width="413"></td>
                  </tr>
                </tbody>
              </table></td>
              <td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
            </tr>
          </tbody>
        </table>
      </div></td>
    </tr>
    <tr>
      <td width="58" height="21">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
    </tr>
    <tr>
      <td width="58" height="21">&nbsp;</td>
      <td width="124">&nbsp;</td>
      <td width="435">&nbsp;</td>
    </tr>
    <tr>
      <td height="21" colspan="4">
      		<p align="center">
									
                                	<a href="javascript:document.frmBuy.submit();" class="btn btn-small">
									<i class="icon-shopping-cart"></i>Comprar
									</a>
									<a href="" class="btn btn-small btn-inverse">
									<i class="icon-remove icon-white"></i>Cancelar
									
									</a>
								
								
							
						</p>
      
      </td>
    </tr>
</table>
</form>
</div>
</div>
</div>
</div>









