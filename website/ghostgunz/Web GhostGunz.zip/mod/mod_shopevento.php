<div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
	<tr>
	<td><a href="index.php?skr=shop">Inicio Tienda</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopevento">Tienda Event</a></td>
	</tr>
	<tr>
	<td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
	</tr>
	
	
	</tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
	<table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
	<td><a href="index.php?skr=donar">Donar</a></td>
	</tr>
<tr>
	<td><a href="index.php?skr=staff">Staff</a></td>
	</tr>

<tr>
	<td><a href="index.php?do=listamedallas">Medallas</a></td>
	</tr>

<tr>
	<td><a href="index.php?do=listamedallas">Medallas</a></td>
	</tr>
	
	
<tr>
	<td><a href="index.php?do=ultimoscw">Ultimos ClanWar</a></td>
	</tr>

	</tbody>
</table>       
            </ul>
          </div><!--/.well -->
	
   


</div><!--/span-->

<?
$q = skr_query("SELECT * From TiendaEvento Order By ID DESC");
$count	= 1;
$pags	= 1;
if(skr_num_rows($q)){
while($shop = skr_object($q)){
	$item[$count][$pags]['Name'] =	$shop->Name;
	$item[$count][$pags]['ID'] =	$shop->ID;
	$item[$count][$pags]['Img'] = $shop->Img;
	$item[$count][$pags]['Precio'] = DC_COINS($shop->Precio, $E_DC);
	$item[$count][$pags]['Ventas'] = $shop->Ventas;
	if($count == 12)
	{
		$count = 0;
		$pags++;
		}
	$count++;
	}
	if(isset($_GET['pag']))
	{
		$pag = clean($_GET['pag']);
		if(!is_numeric($pag))
			{
			msgbox("ERROR EN LA PAGINA","?skr=shopevento");
			}
		if($pag > $pags)
		{
			msgbox("Pagina no existe","?skr=shopevento");
			}
		}else{
			$pag = 1;
			}
			
?>

              <div class="span8 well" >
<h1><!-- IMG --> </h1>
<br>
<div class="well"><div align="center">


<a class="btn btn-inverse" href="index.php?do=shopevent"><i class="icon-globe icon-white"></i> Recientes</a>

<a class="btn btn-inverse" href="index.php?do=shopevent&sort=2"><i class="icon-heart icon-white"></i> Mas Vendidos</a>

<a class="btn btn-inverse" href="index.php?do=shopevent&sort=3"><i class="icon-thumbs-down icon-white"></i> Menos Vendidos</a>


<a class="btn btn-inverse" href="index.php?do=shopevent&sort=4"><i class="icon-hand-up icon-white"></i> Costosos</a>


<a class="btn btn-inverse" href="index.php?do=shopevent&sort=5"><i class="icon-hand-down icon-white"></i> Baratos</a>
</div></div>
<div class="alert alert-block alert-error fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong>Lista de Item Evento </strong>
<br><br>          


<div class="well" align="center">

<ul class="thumbnails">
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[1][$pag]['Precio']?> Vendidos: <?=$item[1][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[1][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[1][$pag]['Name']?></h5>
              <p><a href="index.php?skr=ecomprar&id=<?=$item[1][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[1][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[2][$pag]['Precio']?> Vendidos: <?=$item[2][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[2][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[2][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[2][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[2][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[3][$pag]['Precio']?> Vendidos: <?=$item[3][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[3][$pag]['Img'])?>" width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[3][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[3][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[3][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[4][$pag]['Precio']?> Vendidos: <?=$item[4][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[4][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[4][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[4][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[4][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
          </div>
        </li>
</ul>
<ul class="thumbnails">
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[5][$pag]['Precio']?> Vendidos: <?=$item[5][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[5][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[5][$pag]['Name']?></h5>
              <p><a href="index.php?skr=ecomprar&id=<?=$item[5][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[5][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[6][$pag]['Precio']?> Vendidos: <?=$item[6][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[6][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[6][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[6][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[6][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[7][$pag]['Precio']?> Vendidos: <?=$item[7][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[7][$pag]['Img'])?>" width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[7][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[7][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[7][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[8][$pag]['Precio']?> Vendidos: <?=$item[8][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[8][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[8][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[8][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[8][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
          </div>
        </li>
</ul>

<ul class="thumbnails">
        <li class="span3">
          <div class="thumbnail">
           <a href="#" rel="tooltip" title="Precio: <?=$item[9][$pag]['Precio']?> Vendidos: <?=$item[9][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[9][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[9][$pag]['Name']?></h5>
              <p><a href="index.php?skr=ecomprar&id=<?=$item[9][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[9][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="Precio: <?=$item[10][$pag]['Precio']?> Vendidos: <?=$item[10][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[10][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[10][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[10][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[10][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="<?=$item[11][$pag]['Precio']?> Vendidos: <?=$item[11][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[11][$pag]['Img'])?>" width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[11][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[11][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[11][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
        </li>
        <li class="span3">
          <div class="thumbnail">
            <a href="#" rel="tooltip" title="<?=$item[12][$pag]['Precio']?> Vendidos: <?=$item[12][$pag]['Ventas']?>" data-placement="right"><img src="img/shop/<?=Img_ex($item[12][$pag]['Img'])?>"  width="100" height="100" alt=""></A>
            <div class="caption">
              <h5><?=$item[12][$pag]['Name']?></h5>
             <p><a href="index.php?skr=ecomprar&id=<?=$item[12][$pag]['ID']?>" class="btn btn-small"><i class="icon-shopping-cart"></i>Buy</a>
              <a href="index.php?skr=giftdonante&id=<?=$item[12][$pag]['ID']?>" class="btn btn-small btn-inverse"><i class="icon-gift icon-white"></i>Gift</a></p>
            </div>
          </div>
        </li>
</ul>

<div class="alert alert-block alert-error fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
             <strong>
            <?
			for($n = 1; $n <= $pags; $n++){
				if($n == $pag)
				{
				$we = "'color='#00CCFF'";
				}else{
					$we = "color='black'";
					
					}
				
			?>
           [<a href='index.php?skr=shopevento&pag=<?=$n?>'><font <?=$we?> ><b><?=$n?></b></font></a>]  
        <?				}}else{?> 
        
        <center>Aun no hay Items Donantes</center>
                <? } ?>
            </strong>
</div>
</div>
</div>
</div>
</div>