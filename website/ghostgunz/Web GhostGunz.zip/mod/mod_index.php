<div class="row-fluid">
        <div class="span3">


        



<? 
include "_inc/status.php"; 
include "_inc/menu.php";
?>
       <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
<? include "_inc/generar.php";?>
<? include "_inc/publi.php"; ?>
              <!--/row-->


<!--/span-->
<? include "_inc/ultimo_items.php";?>
<? include "_inc/ultimo_cw.php"; ?>
<? include "_inc/ultimo_event.php"; ?>
<? include "_inc/ultimo_trailer.php"; ?>




</div>