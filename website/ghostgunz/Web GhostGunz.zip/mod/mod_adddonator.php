﻿<?php
if(isset($_GET['troll2'])) { 
	echo $addpanel; }
if($_GET['troll']  == $addpanel){

	$qwe = clean($_GET['skr']);
if(isset($_POST['agregar0']))
{ 	$emblem = $_POST['imagen'] ;
	$ItemID = clean($_POST['ItemID']);
	$Name = clean($_POST['Name']);
	$Precio = clean($_POST['Precio']);
	$Level = clean($_POST['Level']);
	$tipo = clean($_POST['tipo']);
	$Sex = clean($_POST['Sex']);
	$Peso = clean($_POST['Peso']);
	$Dano = clean($_POST['Dano']);
	$Retraso = clean($_POST['Delay']);
	$control = clean($_POST['control']);
	$Balas = clean($_POST['Balas']);
	$Maxbalas = clean($_POST['Max_Balas']);
	$Hp = clean($_POST['HP']);
	$Ap = clean($_POST['AP']);
	$MaxPeso = clean($_POST['Max_Peso']);
	$Recarga = clean($_POST['Recarga']);
	$Duracion = clean($_POST['Duracion']);
	
	$FR = clean($_POST['FR']);
	$LR = clean($_POST['LR']);
	$CR = clean($_POST['CR']);
	$PR = clean($_POST['PR']);
	$tienda = clean($_POST['addtipo']);
	
	
	$target = "img/shop/";	
	$target = $target . basename( $_FILES['imagen']['name']) ;
	$ok=1;
	$ext = pathinfo($target);
	$EXT1 = strtolower($ext['extension']);
	$f = $ext['basename'];
	$ok = 1;
	
	if ($ok==0)
	{
		msgbox("Error!!! en tu imagen.","index.php");
 	}else{
		

	$qery = "INSERT INTO Tienda$tienda (Name, ItemID, Img, Fecha, Precio, Tipo, Sexo, Level, Ventas, Control, HP, AP, Damage, Peso, Duracion, Cartucho, MaxBalas, Retraso, MaxPeso, TCarga)VALUES('$Name', '$ItemID', '$f', GETDATE(), '$Precio', '$tipo', '$Sex', '$Level', '0', '$control', '$Hp', '$Ap', '$Dano', '$Peso', '$Duracion', '$Balas', '$Maxbalas', '$Retraso', '$MaxPeso', '$Recarga')";
		if(mssql_query($qery))
			copy($_FILES['imagen']['tmp_name'], $target);
			msgbox("Item Subido con exito.","?skr=adddonator");
			
		}
}
?>
<form name="agregar" method="post" enctype="multipart/form-data">
<font >
<p>Tienda:<select name="addtipo">
	<option value="Donante" selected="selected">Donante</option>
	<option value="Evento">Evento</option>
</select></p>
<table width="470" height="476">
<td width="92">ItemID:</td>
<td width="366"><input type="number" name="ItemID"></td>
</tr>
<tr>
  <td>Name:</td>
  <td><input type="text" name="Name"></td>
</tr>
<tr>
  <td>Image:</td>
  <td><input type="file" name="imagen">
  tamaño:100 x 100</td>
</tr>
<tr>
  <td>Price:</td>
  <td><input name="Precio" type="number" value="0"></td>
</tr>
<tr>
  <td>Level:</td>
  <td><input name="Level" type="number" value="0"></td>
</tr>
<tr>
  <td>Type:</td>
  <td><select name="tipo">
<option selected value="0">Clothes</option>
<option value="1">Ranged Weapons</option>
<option value="2">Melee Weapons</option>
<option value="3">Items</option>
</select></td>
</tr>
<tr>
  <td>Sex:</td>
  <td><select name="Sex">
<option value="0">Hombre</option>
<option value="1">Mujer</option>
<option selected value="2">ALL</option></select></td>
</tr>
<tr>
  <td>Peso:</td>
  <td><input name="Peso" type="number" value="0"></td>
</tr>
<tr>
  <td>Damage:</td>
  <td><input name="Dano" type="number" value="0"></td>
</tr>
<tr>
  <td>Retraso:</td>
  <td><input name="Delay" type="number" value="0"></td>
</tr>
<tr>
  <td>Control:</td>
  <td><input name="control" type="number" value="0"></td>
</tr>
<tr>
  <td>Balas:</td>
  <td><input name="Balas" type="number" value="0"></td>
</tr>
<tr>
  <td>Max Bul:</td>
  <td><input name="Max_Balas" type="number" value="0"></td>
</tr>
<tr>
  <td>HP:</td>
  <td><input name="HP" type="number" value="0"></td>
</tr>
<tr>
  <td>AP:</td>
  <td><input name="AP" type="number" value="0"></td>
</tr>
<tr>
  <td>Max weight:</td>
  <td><input name="Max_Peso" type="number" value="0"></td>
</tr>
<tr>
  <td>Reload time:</td>
  <td><input name="Recarga" type="number" value="0"></td>
</tr>
<tr>
  <td>Duration:</td>
  <td><input name="Duracion" type="number" value="0"></td>
</tr>
<tr>
  <td>FR:</td>
  <td><input name="FR" type="number" value="0"></td>
</tr>
<tr>
  <td>LR:</td>
  <td><input name="LR" type="number" value="0"></td>
</tr>
<tr>
  <td>CR:</td>
  <td><input name="CR" type="number" value="0"></td>
</tr>
<tr>
  <td>PR:</td>
  <td><input name="PR" type="number" value="0"></td>
</tr>
</table>
<input type="submit" name="agregar0" value="Add Item">
</font>
</form>
<? }else{
	msgbox("Ola k ase?","index.php");
	
	} ?>