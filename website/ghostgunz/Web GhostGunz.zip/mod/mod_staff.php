
<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <div class="span8 well" >
<h1>Staff <?=$_SESSION['NAMESVR']?></h1>
<br><br><div class="alert alert-block fade in">
            
<strong> Paginas y Grupos Oficiales GhostGunZ: </strong><br>

         
<h3></h3>
<li><a href="https://www.facebook.com/groups/214931888654645/" target="_BLANK">Grupo GhostGunZ Facebook.</a></li>
<li><a href="http://www.facebook.com/GhostGunz" target="_BLANK">Pagina Facebook oficial GhostGunZ</a></li><br>

      <strong> Administradores: </strong><br>

         
<h3></h3>
<li style="

color: red; text-shadow: red 0px 0px 9px; background:url();">Sacker    (Administrador General (Coding Web)</li>
<li style="

color: red; text-shadow: red 0px 0px 9px; background:url();">Luis Vidal (Administrador General ( Client / Server)</li>
<li style="

color: red; text-shadow: red 0px 0px 9px; background:url();">Daniel Esplua    (Administrador General (Client / Server)</li><br><br>

<strong> Moderadores General: </strong>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">Wrearter</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">Farray</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">RipckScott</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">KingDios</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">Elemnt</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">Reiko</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">Zimerman</li>
<li style="color: #00E81B; text-shadow: #00E81B 0px 0px 9px; background:url();">ParkYoungHee</li>
<br>

<strong> Game Master: </strong>
<li style="color: #E89B01; text-shadow: #E89B01 0px 0px 9px; background:url();">DarckCrack</li>
<li style="color: #E89B01; text-shadow: #E89B01 0px 0px 9px; background:url();">Donalds</li>
<li style="color: #E89B01; text-shadow: #E89B01 0px 0px 9px; background:url();">King[Frank]</li>
<li style="color: #E89B01; text-shadow: #E89B01 0px 0px 9px; background:url();">Amano</li>
 </div>

</div>

</div>