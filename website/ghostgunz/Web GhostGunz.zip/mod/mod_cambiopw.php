
<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <div class="span8 well" >
<h1>Cambio de Password </h1>
<br><br><div class="alert alert-block fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong> Alerta: Se le recomienda usar Email verdadero.</a></strong><br>
El cambio de contrase&ntilde;a tarda unas horas hasta la confirmacion de un administrador, por eso se le pide llenar los datos correctos.<br> Se le enviara a su Email la nueva contrase&ntilde;a y un lugar donde usted lo cambiara. 
       <br> En todo caso de no ser un Email valido comunicarse al administrador.   </div>

<form class="form-horizontal"  method="post" id="regform">
        <fieldset>
      
          <div class="control-group warning">
            <label class="control-label" for="inputWarning">Usuario: </label>
            <div class="controls">
              <input type="text" name="userid" maxlength="12" id="inputWarning">
              <span class="help-inline"> </span>
            </div>
          </div>
         
          
		<div class="control-group">
            <label class="control-label" for="inputError">Email: </label>
            <div class="controls">
              <input type="text" id="focusedInput" name="email" maxlength="35">
              <span class="help-inline">Importante y Valido</span>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="inputError">PIN 8 Digitos: </label>
            <div class="controls">
              <input type="number" id="focusedInput" name="pin" maxlength="8">
              <span class="help-inline">Codigo de seguridad GhostGunZ</span>
            </div>
          </div>
          <div class="control-group">
            <label class="control-label" for="inputError">Contrase&ntilde;a nueva: </label>
            <div class="controls">
              <input type="text" id="focusedInput" name="new" maxlength="16">
              <span class="help-inline">Su nueva contrase&ntilde;a.</span>
            </div>
          </div>
		
          <div class="form-actions">
            <button type="submit" class="btn btn-primary" name="cambio">Cambiar Contrase&ntilde;a.</button>
            <button class="btn" name="clear" type="reset">Resetaer</button>
          </div>
        </fieldset>
      </form>         

</div>
        <?
        	if(isset($_POST['cambio']))
        	{
        		$user = clean($_POST['userid']);
        		$email = clean($_POST['email']);
        		$newpw = clean($_POST['new']);
        		$pin = clean($_POST['pin']);

        		$q = skr_query("SELECT * From Account WHERE UserID='".$user."' AND Email='".$email."' AND PIN='".$pin."'");
        		if(empty($user) || empty($email) || empty($pin) || empty($newpw))
        		{

        			msgbox("NO DEJAR CAMBOS VACIOS.","index.php?skr=cambiopw");
        		}
        		if(!is_numeric($pin))
        		{
        			msgbox("Error en pin","index.php?skr=cambiopw");
        		}
        		if(skr_num_rows($q) == 0)
        		{
        			msgbox("La cuenta no se encontro Email,ID o Pin son incorrectos.","index.php?skr=cambiopw");
        		}else{
        		 $acc = skr_object($q);
        		 $aid = $acc->AID;
        		 $t = "UPDATE Login SET Password='".$newpw."' WHERE AID='".$aid."'";
        		 if(skr_query($t))
        		 {
        		 	msgbox("Su password fue cambiada con exito.","index.php");
        		 }else{
        		 	msgbox("ERROR.","index.php");
        		 }


        		}
        	}
        ?>
		
        
        
<? /* include "_inc/publi.php";
   //           <!--/row-->


//<!--/span-->
 include "_inc/ultimo_items.php";
 include "_inc/ultimo_cw.php";*/ ?>


</div>