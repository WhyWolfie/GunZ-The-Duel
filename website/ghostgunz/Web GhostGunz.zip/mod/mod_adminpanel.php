﻿<?
if(empty($_SESSION['AID']))
{
msgbox("Error en pagina","index.php");
}
Chek_GM($_SESSION['AID'], 2);
?>
<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	
<?
if(isset($_POST['getdcoins']))
{
	$bantype = clean($_POST['Dtype']);
	$nameban = clean($_POST['dname']);
	$dcoins = clean($_POST['dcoins']);
	if(empty($nameban))
	{
		msgbox("Escriba el a quien quiere dar dcoins.","index.php?skr=adminpanel");
	}
	if($bantype == 0)
	{
	// personaje
		$r  = skr_query("SELECT * From Character WHERE Name='".$nameban."'");
		if(!skr_num_rows($r) == 1){
			msgbox("No existe. o Existen otros personajes con el mismo nombre, use userid o aid.","index.php?skr=adminpanel");	
		}else{
		$q = skr_object($r);
		$aid = $q->AID;
		}

		
	}elseif($bantype == 1)
	{
		// UserID
		$r = skr_query("SELECT * From Account WHERE UserID='".$nameban."'");
		if(skr_num_rows($r) == 0)
		{
			msgbox("UserID No existe.","index.php?skr=adminpanel");	
		}
		$q = skr_object($r);
		$aid = $q->AID;
	}elseif($bantype == 2)
	{
		//AID
		$r = skr_query("SELECT * From Account WHERE AID='".$nameban."'");
		if(skr_num_rows($r) == 0)
		{
			msgbox("UserID No existe.","index.php?skr=adminpanel");	
		}
		$q = skr_object($r);
		$aid = $q->AID;
		
	}

		$r = skr_query("SELECT * From Account WHERE AID='".$aid."'");
		$acc = skr_object($r);
		$aid = $acc->AID;
		$ugrade = $acc->UGradeID;
		$userid = $acc->UserID;
		$mydcoins = $acc->DonatorCoins;
		$totaldcoins = $mydcoins+$dcoins;

		
			$ban = "UPDATE Account SET DonatorCoins='$totaldcoins' WHERE AID='".$aid."'";	
		
		if(skr_query($ban))
		{
			
			msgbox("Los DCoins fueron enviados con exito al AID: $aid.","index.php?skr=adminpanel");
		}


}


if(isset($_POST['getban']))
{
	$bantype = clean($_POST['bantype']);
	$nameban = clean($_POST['nameban']);
	$timeban = clean($_POST['timeban']);
	if(empty($nameban))
	{
		msgbox("Escriba el a quien quiere dar ban.","index.php?skr=adminpanel");
	}
	if($bantype == 0)
	{
	// personaje
		$r  = skr_query("SELECT * From Character WHERE Name='".$nameban."'");
	if(!skr_num_rows($r) == 1){
			msgbox("No existe. o Existen otros personajes con el mismo nombre, use userid o aid.","index.php?skr=adminpanel");	
	}else{
		$q = skr_object($r);
		$aid = $q->AID;
	}

		
	}elseif($bantype == 1)
	{
		// UserID
		$r = skr_query("SELECT * From Account WHERE UserID='".$nameban."'");
		if(skr_num_rows($r) == 0)
		{
			msgbox("UserID No existe.","index.php?skr=adminpanel");	
		}
		$q = skr_object($r);
		$aid = $q->AID;
	}elseif($bantype == 2)
	{
		//AID
		$r = skr_query("SELECT * From Account WHERE AID='".$nameban."'");
		if(skr_num_rows($r) == 0)
		{
			msgbox("UserID No existe.","index.php?skr=adminpanel");	
		}
		$q = skr_object($r);
		$aid = $q->AID;
		
	}

		$r = skr_query("SELECT * From Account WHERE AID='".$aid."'");
		$acc = skr_object($r);
		$aid = $acc->AID;
		$ugrade = $acc->UGradeID;
		if($ugrade > 253)
		{
			$ugrade = 0;
		}
		$userid = $acc->UserID;
		$ok = 1;
		
		
		if($ok == 1)
		{
			skr_query("UPDATE Account SET UGradeID='253' WHERE AID='$aid'");
			msgbox("El Usuario ha sido banneado con exito.","index.php?skr=adminpanel");
		}


}


if(isset($_POST['addevent']))
	{
		$player = clean($_POST['userid']);
		$ecoins = clean($_POST['ecoins']);
		$Etype	= clean($_POST['Etype']);
		$type	= clean($_POST['type']);
		if(empty($player))
	{
		msgbox("Escriba el a quien quiere dar ecoins.","index.php?skr=adminpanel");
	}
	$query  = "SELECT * From Account WHERE UserID='".$player."'";
	$query2  = "SELECT * From Character WHERE Name='".$player."'";
		if($type == 0)
			{
			$q = skr_query($query2);
			if(skr_num_rows($q) == 0)
				{
					msgbox("El personaje no existe, tambien puede usar el userid","?skr=gmpanel");
					}
			$char = skr_object($q);
			$aid = $char->AID;	
				}elseif($type == 1)
					{
						$q = skr_query($query);
						if(skr_num_rows($q) == 0)
				{
					msgbox("El usuario no existe.","?skr=gmpanel");
					}
						$acc = skr_object($q);
						$aid	= $acc->AID;
						}
					$envio = "UPDATE Account SET EventCoins=EventCoins+$ecoins WHERE AID='".$aid."'";
					if(skr_query($envio))
					{
						$gm = clean($_SESSION['AID']);	
					skr_query("INSERT INTO GanadorEvent (WIN, REGDATE, GM, TIPO, Coins, RE) VALUES('$aid', GETDATE(), '$gm', '$Etype', '$ecoins', '1')");
					msgbox("Envio EventCoins con existo y registrado.","?skr=gmpanel");
					}
		}
?>
        </div><!--/span-->
        <form method="post" name="fromxd">
          <div class="span9 well" >
         Envio EventCoins ganador de evento.
        <div class="well">
        <select name="type" style="width:110px;">
		<option value="0">Personaje:</option> 
        <option value="1" selected="selected">UserID:</option>
        </select>
        <input type="text" name="userid" style="width:120px;"/> ECoins: <select name="ecoins" style="width:60px;">
        <option value="10">10</option>
        <option value="20">20</option>
        <option value="30">30</option>
        <option value="40">40</option>
        <option value="50">50</option>
        <option value="55">55</option>
        <option value="60">60</option>
        <option value="70">70</option>
        <option value="75">75</option>
        <option value="80">80</option>
        <option value="90">90</option>
         <option value="100">100</option>
        </select>
       	Evento: <select name="Etype"  style="width:120px;" >
        <option value="1"><?=Typeevent(1)?></option>
        <option value="2"><?=Typeevent(2)?></option>
        <option value="3"><?=Typeevent(3)?></option>
        <option value="4"><?=Typeevent(4)?></option>
        <option value="5"><?=Typeevent(5)?></option>
        <option value="6"><?=Typeevent(6)?></option>
        <option value="7"><?=Typeevent(7)?></option>

        </select>
        <button type="submit" class="btn btn-inverse" name="addevent">Enviar</button>
		</div>
  </form>
      Banned Userid o Personaje:
         <div class="well">

          <select name="bantype" style="width:110px;">
          	<option value="2">AID:</option>
             <option value="0">Personaje:</option>
             <option value="1" selected="selected">UserID:</option>
           </select>

           <input type="text" name="nameban">
		Tiempo: <select name="timeban"> 
			<option value="1"> 1 Dias </option>
			<option value="2"> 2 Dias </option>
			<option value="3"> 3 Dias </option>
			<option value="7"> 7 Dias </option>
			<option value="14"> 14 Dias </option>
			<option value="15"> 15 Dias </option>
			<option value="31"> 1 mes </option>
			<option value="186"> 6 meses </option>
			<option value="365"> 1 año </option>
			<option value="0"> Eterno </option>
		</select>
<button type="submit" class="btn btn-inverse" name="getban">OK</button>




		</div>
		 Enviar DCoins:
         <div class="well">

          <select name="Dtype" style="width:110px;">
          	<option value="2"selected="selected">AID:</option>
             <option value="0">Personaje:</option>
             <option value="1" >UserID:</option>
           </select>

           <input type="text" name="dname">
		DCOINS: <select name="dcoins"> 
			<option value="50"> 50 DCOINS </option>
			<option value="50"> 60 DCOINS </option>
			<option value="90"> 90 DCOINS </option>
			<option value="50"> 110 DCOINS </option>
			<option value="180"> 180 DCOINS </option>
			<option value="270"> 270 DCOINS </option>
			<option value="360"> 360 DCOINS </option>
			<option value="400"> 400 DCOINS </option>
			<option value="410"> 410 DCOINS </option>
			<option value="500"> 500 DCOINS </option>
			<option value="560"> 560 DCOINS </option>
			<option value="600"> 600 DCOINS </option>
		</select>
<button type="submit" class="btn btn-inverse" name="getdcoins">OK</button>




		</div>



   	Buscar Informacion completa del UserID:
         <div class="well">
           <select name="type2" style="width:110px;">
             <option value="0">Personaje:</option>
             <option value="1" selected="selected">UserID:</option>
           </select>
           <input type="text" name="name" style="width:120px;"/><input class="btn btn-inverse"  name="buscar" type="submit" value="Buscar" />
          
           
           <?
           
		   if(isset($_POST['buscar']))
	{
		$name = clean($_POST['name']);
		$typo = (int) clean($_POST['type']);
	$query  = "SELECT * From Account WHERE UserID='".$name."'";
	$query2  = "SELECT * From Character WHERE Name='".$name."'";
		$total = $name;
		
		if($type == 0)
			{
			$q = skr_query($query2);
			if(skr_num_rows($q) == 0)
				{
					msgbox("El personaje no existe, tambien puede usar el userid","?skr=gmpanel");
					}
			$char = skr_object($q);
			$aid = $char->AID;	
				}elseif($type == 1)
					{
						$q = skr_query($query);
						if(skr_num_rows($q) == 0)
				{
					msgbox("El usuario no existe.","?skr=gmpanel");
					}
					$acc = skr_object($q);
						$aid	= $acc->AID;
						}
					$r = skr_query("SELECT * From Account WHERE AID='".$aid."'");
					$r2 = skr_query("SELECT * From Login WHERE AID='".$aid."'");
					$acc = skr_object($r);
					$login = skr_object($r2);
					$BAID = $acc->AID;
					$BUSERID = $acc->UserID;
					$BUGRADE = $acc->UGradeID;
					$BEMAIL	= $acc->Email;
					$BIP	= $login->LastIP;
					$BDC	= $acc->DonatorCoins;
					$BEC	= $acc->EventCoins;
					$mostrar = "
					<table>
					<tr>
					<td width='50'>
					AID
					</td>
					<td width='50'>
					UserID
					</td>
					<td width='100'>
					UGradeID
					</td>
					<td width='150'>
					Email
					</td>
					<td width='150'>
					LastIP
					</td>
					<td width='50'>
					EventCoins
					</td>
					<td width='50'>
					DonatorCoins
					</td>
					</tr>
					<tr>
					<td>
					$BAID
					</td>
					<td>
					$BUSERID
					</td>
					<td>
					$BUGRADE
					</td>
					<td>
					$BEMAIL
					</td>
					<td style='color:red;'>
					$BIP 
					</td>
					
					<td>
					$BEC
					</td>
					<td>
					$BDC
					</td>
					
					
					</tr>
					</table>
					";
					echo $mostrar;
					$k = skr_query("SELECT * From Character WHERE AID='".$aid."' AND Name != '' ");
					
					echo  "<table>
					
					<tr>
					
					<td width='100'>
					Name
					</td>
					
					<td width='100'>
					Level
					</td>
					<td width='100'>
					Exp
					</td>
					
					</tr>
					";
					?>
                    <?
					while($pj = skr_object($k)){
						$PNAME = $pj->Name;
					$PLEVEL = $pj->Level;
					$PEXP	= $pj->XP;
					?>
					<?
					echo "<tr>
					
					<td>
					$PNAME
					</td>
					
					<td>
					$PLEVEL
					</td>
					<td>
				$PEXP
					</td>
					
					</tr>";
					
					}?>
		<?	echo "</table>"; 
					
		} ?>
        
         </div>


         	 Donaciones BCP
         	 <p style="color:red;">*Al cancelar la donacion dara un banned de 7 Dias.</p>
         <div class="well">
			<?
			$querybcp = skr_query("SELECT * From DonarBCP WHERE ACT='0'");
			if(skr_num_rows($querybcp) == 0)
{
echo "No hay donaciones BCP";
}else{
			while($bcp = skr_object($querybcp)){
?>

		
		<br>

		<table  class="table table-condensed table-striped">
			<tr>

                <td>N° Factura: <?=$bcp->ID?></td>
			  <td rowspan="6"><img src="http://i.imgur.com/<?=$bcp->IMG?>" width='250' height='400' /></td>
			</tr>
			 <tr>

                <td>UserID: <?=$bcp->AID?></td>
               
            </tr>
             <tr>
                <td>Type: <?=$bcp->Type?></td>
            </tr>
              <tr>
                <td>Fecha enviado: <?=$bcp->Fecha?></td>
            </tr>
            <tr>
                <td>
                	Verificar:	<select name="ver"> 
                			<option value="">Verif</option>
                			<option value="1">Bien</option>
                		</select>	

                </td>
            </tr>
              <tr>
                <td><button type="submit" name="ACT" class="btn btn-inverse" >OK</button> <button class="btn btn-inverse"  type="submit" name="BAN">CANCELAR Y BAN</button></td>

            </tr>
			 <tr>
                

                
               
               
           </tr>
           
           
        </table>
				<?
			}}
			?>

		</div>


         <br><br>

</div>
</div>