<?
if(empty($_SESSION['AID']))
{
  msgbox("Entre a esta opcion logueado.","index.php");
}
$precio = 40;

if(isset($_POST['createclan']))
{
  $name = clean($_POST['name']);
  $cid  = clean($_POST['cid']);

  $pro = "[^a-zA-Z0-9]";
      if(ereg($pro,$name))
        {
          msgbox("No uses signos en el nombre","index.php?skr=createclan");
          }

  if(empty($name) || empty($cid))
  {
    msgbox("Ingrese el nombre del clan.","index.php?skr=createclan");
  }
    if(!is_numeric($cid))
  {
    msgbox("Error en createclan","index.php?skr=createclan");
  }else{
   $ac1 = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
   $ac = skr_object($ac1);
   $coins =  $ac->Coins;
   if($coins < $precio)
   {
    msgbox("Usted no tiene suficiente coins para usar esta opcion.","index.php");
   }else{
    $total = $coins - $precio;
   }
    /*$r1 = skr_query("SELECT * From Clan WHERE MasterCID='".$cid."'");
    
    if(skr_num_rows($r1) != 0)
    {
      msgbox("El personaje ya tiene clan.","index.php?skr=createclan");
    }*/

    $r2 = skr_query("SELECT * From ClanMember WHERE CID='".$cid."'");
    if(skr_num_rows($r2) != 0)
    {
      msgbox("El personaje ya esta en un clan.","index.php?skr=createclan");
    }
     $r = skr_query("SELECT * From Clan WHERE Name='".$name."'");
    if(skr_num_rows($r) != 0)
    {
      msgbox("El nombre $name esta siendo usado.","index.php?skr=createclan");
    }else{
      
      $q = skr_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$name', '$cid', GETDATE())");


      $f = skr_query("SELECT * From Clan WHERE Name='".$name."' AND MasterCID='".$cid."'");
      if($clan = skr_object($f))
      {
        $clid = $clan->CLID;
        $cid = $clan->MasterCID;
        $query = "INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$cid', '1', GETDATE())";
      if(skr_query($query))
      {

       skr_query("UPDATE Account SET Coins='$total' WHERE AID='".$_SESSION['AID']."'");
        msgbox("Su clan fue creado con exito.","index.php");
      }

      }

    }

  }


}else{


}
?>





























<div class="row-fluid">
        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Webshop</li>
  <table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
  <tr>
  <td><a href="index.php?skr=shop">Inicio Tienda</a></td>
  </tr>
  <tr>
  <td><a href="index.php?skr=shopevento">Tienda Event</a></td>
  </tr>
  <tr>
  <td><a href="index.php?skr=shopdonante">Tienda Donante</a></td>
  </tr>
  
  
  </tbody>
</table>       
            </ul>
          </div><!--/.well -->


          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Menu</li>
  <table class="table table-condensed table-striped">
        <thead>
          <tr>
            <th></th>
          </tr>
        </thead>
        <tbody>
       
<tr>
  <td><a href="index.php?do=donar">Donar</a></td>
  </tr>
<tr>
  <td><a href="index.php?do=staff">Staff</a></td>
  </tr>

<tr>
  <td><a href="index.php?do=listamedallas">Medallas</a></td>
  </tr>
  
  
<tr>
  <td><a href="index.php?do=ultimoscw">Ultimos ClanWar</a></td>
  </tr>

  </tbody>
</table>       
            </ul>
          </div><!--/.well -->
  
   


</div><!--/span-->



              <div class="span9 well" >
<h1><!-- IMG --></h1>

            <strong> </strong>
<br><br>          

<div class="well">
 <b>Al crear el clan se les descontara <?=$precio?> Coins. </b>
<form name="fromx" method="post">

<table>
<tr>
<th>
Crear Clan
</th>
</tr>
<tr>
<th>
Personaje:
<select name="cid">
  <option value="">Seleccione un personaje.</option>
<?
$go = skr_query("SELECT * From Character WHERE AID='".$_SESSION['AID']."' AND DeleteFlag !='1' ");
while($char = skr_object($go))
{
  $cid = $char->CID;
  $name = $char->Name;
  ?>
  <option value="<?=$cid?>"> <?=$name?></option>
<? } ?>
</select>
</th>
</tr>
<tr>
<th>
Nombre clan: <input type="text" name="name">
</th>
</tr>
</tr>
<tr>
<th>
<input type="submit" name="createclan" value="Crear clan">
</th>
</tr>
</table>
</form>


  
</div>
</div>
</div>
</div>