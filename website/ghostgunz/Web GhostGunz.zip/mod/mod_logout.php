<?

if(@session_destroy()){
	msgbox("Usuario deslogueado","index.php");
	}
?>