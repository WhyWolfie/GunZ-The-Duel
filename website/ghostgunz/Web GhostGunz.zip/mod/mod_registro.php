<?
if($_SESSION['AID'] <> ""){
	msgbox("No puede entrar aqui estando logueado","index.php");
	}
?>
<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->
        
        <div class="span8 well" >
<h1>Registro <?=$_SESSION['NAMESVR']?></h1>
<br><br><div class="alert alert-block fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong> Alerta: Al registrase usted esta aceptando los <a href="GG.pdf" target="_BLANK">Terminos y Condiciones de GhostGunZ</a></strong><br>
Te regalamos : Brown Breaker, Light Green Breaker, Druid Staff, Gears Avatar y Anillo Fast de Experiencia,
revisalos en tu Storage al ingresar a tu cuenta.
          </div>

<form class="form-horizontal"  method="post" id="regform">
        <fieldset>
      
          <div class="control-group warning">
            <label class="control-label" for="inputWarning">Usuario: </label>
            <div class="controls">
              <input type="text" name="userid" maxlength="12" id="inputWarning">
              <span class="help-inline"> </span>
            </div>
          </div>
          <div class="control-group error">
            <label class="control-label" for="inputError">Contrase&ntilde;a: </label>
            <div class="controls">
              <input type="password" name="pass1" maxlength="12" id="inputError">
              <span class="help-inline"></span>
            </div>
          </div>
           <div class="control-group error">
            <label class="control-label" for="inputError">Repetir Contrase&ntildea: </label>
            <div class="controls">
              <input type="password" name="pass2" maxlength="12" id="inputError">
              <span class="help-inline"></span>
            </div>
          </div>
 	   <div class="control-group">
            <label class="control-label" for="inputError">Nombre: </label>
            <div class="controls">
              <input type="text" id="focusedInput" name="name" maxlength="20">
              <span class="help-inline">De preferencia Completo.</span>
            </div>
          </div>
		<div class="control-group">
            <label class="control-label" for="inputError">Edad: </label>
            <div class="controls">
              <input type="text" onkeypress="return isNumberKey(event)" name="edad" maxlength="2" id="focusedInput">
              <span class="help-inline"></span>
            </div>
          </div>
          
          	<div class="control-group">
            <label class="control-label" for="inputError">Sexo: </label>
            <div class="controls">
              <select name="sex">
              	<option value="0">Hombre</option>
                <option value="1">Mujer</option>
                <option value="2">Gay</option>
              </select>
              <span class="help-inline"></span>
            </div>
          </div>
          
          
		<div class="control-group">
            <label class="control-label" for="inputError">Email: </label>
            <div class="controls">
              <input type="text" id="focusedInput" name="email" maxlength="35">
              <span class="help-inline">Importante y Valido</span>
            </div>
          </div>
		<div class="control-group">
            <label class="control-label" for="inputError">Pais: </label>
            <div class="controls">
            <select class="primary" name="pais" id="pais" tabindex="1">
	
		<option selected="" value="1" >Peru</option>
		<option value="3" >Aaland</option>
		<option value="4" >Afghanistan</option>
		<option value="5" >Albania</option>
		<option value="6" >Algeria</option>
		<option value="7" >American Samoa</option>
		<option value="8" >Andorra</option>
		<option value="9" >Angola</option>
		<option value="10" >Anguilla</option>
		<option value="11" >Antigua</option>
		<option value="12" >Antilles</option>
		<option value="13" >Argentina</option>
		<option value="14" >Armenia</option>
		<option value="15" >Aruba</option>
		<option value="16" >Australia</option>
		<option value="17" >Austria</option>
		<option value="18" >Azerbaijan</option>
		<option value="19" >Bahamas</option>
		<option value="20" >Bahrain</option>
		<option value="21" >Bangladesh</option>
		<option value="22" >Barbados</option>
		<option value="23" >Belarus</option>
		<option value="24" >Belgium</option>
		<option value="25" >Belize</option>
		<option value="26" >Benin</option>
		<option value="27" >Bermuda</option>
		<option value="28" >Bhutan</option>
		<option value="29" >Bolivia</option>
		<option value="30" >Bosnia Herzegovina</option>
		<option value="31" >Botswana</option>
		<option value="32" >Bouvet</option>
		<option value="33" >Brazil</option>
		<option value="34" >Brunei</option>
		<option value="35" >Bulgaria</option>
		<option value="36" >Burkina Faso</option>
		<option value="37" >Burundi</option>
		<option value="38" >Cambodia</option>
		<option value="39" >Cameroon</option>
		<option value="40" >Canada</option>
		<option value="41" >Cape Verde</option>
		<option value="42" >Cayman Islands</option>
		<option value="43" >Central African Republic</option>
		<option value="44" >Chad</option>
		<option value="45" >Chile</option>
		<option value="46" >China</option>
		<option value="47" >Christmas Island</option>
		<option value="48" >Cocos</option>
		<option value="49" >Colombia</option>
		<option value="50" >Comoros</option>
		<option value="51" >Congo</option>
		<option value="52" >Cook Islands</option>
		<option value="53" >Costa Rica</option>
		<option value="54" >Cote D'Ivoire</option>
		<option value="55" >Croatia</option>
		<option value="56" >Cuba</option>
		<option value="57" >Curacao</option>
		<option value="58" >Cyprus</option>
		<option value="59" >Czech Republic</option>
		<option value="60" >Denmark</option>
		<option value="61" >Djibouti</option>
		<option value="62" >Dominica</option>
		<option value="63" >Dominican Republic</option>
		<option value="64" >East Timor</option>
		<option value="65" >Ecuador</option>
		<option value="66" >Egypt</option>
		<option value="67" >El Salvador</option>
		<option value="68" >England</option>
		<option value="69" >Equatorial Guinea</option>
		<option value="70" >Eritrea</option>
		<option value="71" >Estonia</option>
		<option value="72" >Ethiopia</option>
		<option value="73" >Europe</option>
		<option value="74" >Falkland Islands</option>
		<option value="75" >Federated States of Micronesia</option>
		<option value="76" >Fiji</option>
		<option value="77" >Finland</option>
		<option value="78" >Former Czechoslovakia</option>
		<option value="79" >Former Soviet Union</option>
		<option value="80" >France</option>
		<option value="81" >Gabon</option>
		<option value="82" >Gambia</option>
		<option value="83" >Georgia</option>
		<option value="84" >Germany</option>
		<option value="85" >Ghana</option>
		<option value="86" >Gibraltar</option>
		<option value="87" >Great Britain</option>
		<option value="88" >Greece</option>
		<option value="89" >Greenland</option>
		<option value="90" >Grenada</option>
		<option value="91" >Guam</option>
		<option value="92" >Guatemala</option>
		<option value="93" >Guinea</option>
		<option value="94" >Guinea Bissau</option>
		<option value="95" >Guyana</option>
		<option value="96" >Haiti</option>
		<option value="97" >Holy See</option>
		<option value="98" >Honduras</option>
		<option value="99" >Hong Kong</option>
		<option value="100" >Hungary</option>
		<option value="101" >Iceland</option>
		<option value="102" >India</option>
		<option value="103" >Indonesia</option>
		<option value="104" >Iran</option>
		<option value="105" >Iraq</option>
		<option value="106" >Ireland</option>
		<option value="107" >Israel</option>
		<option value="108" >Italy</option>
		<option value="109" >Ivory Coast</option>
		<option value="110" >Jamaica</option>
		<option value="111" >Japan</option>
		<option value="112" >Jordan</option>
		<option value="113" >Kazakhstan</option>
		<option value="114" >Kyrgyzstan</option>
		<option value="115" >Kenya</option>
		<option value="116" >Kiribati</option>
		<option value="117" >Kuwait</option>
		<option value="118" >Kyrgyzstan</option>
		<option value="119" >Laos</option>
		<option value="120" >Latvia</option>
		<option value="121" >Lebanon</option>
		<option value="122" >Lesotho</option>
		<option value="123" >Liberia</option>
		<option value="124" >Libya</option>
		<option value="125" >Liechtenstein</option>
		<option value="126" >Lithuania</option>
		<option value="127" >Luxembourg</option>
		<option value="128" >Macau</option>
		<option value="129" >Macedonia</option>
		<option value="130" >Madagascar</option>
		<option value="131" >Malawi</option>
		<option value="132" >Malaysia</option>
		<option value="133" >Maldives</option>
		<option value="134" >Mali</option>
		<option value="135" >Malta</option>
		<option value="136" >Mariana Islands</option>
		<option value="137" >Marshall Islands</option>
		<option value="138" >Mauritania</option>
		<option value="139" >Mauritius</option>
		<option value="140" >Mexico</option>
		<option value="141" >Moldova</option>
		<option value="142" >Monaco</option>
		<option value="143" >Mongolia</option>
		<option value="144" >Montenegro</option>
		<option value="145" >Montserrat</option>
		<option value="146" >Morocco</option>
		<option value="147" >Mozambique</option>
		<option value="148" >Myanmar</option>
		<option value="149" >Namibia</option>
		<option value="150" >Nauru</option>
		<option value="151" >Nepal</option>
		<option value="152" >Netherlands</option>
		<option value="153" >New Zealand</option>
		<option value="154" >Nicaragua</option>
		<option value="155" >Niger</option>
		<option value="156" >Nigeria</option>
		<option value="157" >Niue</option>
		<option value="158" >Norfolk Island</option>
		<option value="159" >North Korea</option>
		<option value="160" >Norway</option>
		<option value="161" >Oman</option>
		<option value="162" >Pakistan</option>
		<option value="163" >Palau</option>
		<option value="164" >Palestinian Territory</option>
		<option value="165" >Panama</option>
		<option value="166" >Paraguay</option>
		<option value="167" >Philippines</option>
		<option value="168" >PNG</option>
		<option value="169" >Poland</option>
		<option value="170" >Portugal</option>
		<option value="171" >Puerto Rico</option>
		<option value="172" >Qatar</option>
		<option value="173" >Romania</option>
		<option value="174" >Russian Federation</option>
		<option value="175" >Rwanda</option>
		<option value="176" >Saint Helena</option>
		<option value="177" >Saint Kitts Nevis Anguilla</option>
		<option value="178" >Saint Lucia</option>
		<option value="179" >Saint Vincent</option>
		<option value="180" >Samoa</option>
		<option value="181" >San Marino</option>
		<option value="182" >Sao Tome</option>
		<option value="183" >Saudi Arabia</option>
		<option value="184" >Scotland</option>
		<option value="185" >Senegal</option>
		<option value="186" >Serbia</option>
		<option value="187" >Seychelles</option>
		<option value="188" >Sierra Leone</option>
		<option value="189" >Singapore</option>
		<option value="190" >Slovak Republic</option>
		<option value="191" >Slovenia</option>
		<option value="192" >Solomon Islands</option>
		<option value="193" >Somalia</option>
		<option value="194" >South Africa</option>
		<option value="195" >South Georgia</option>
		<option value="196" >South Korea</option>
		<option value="197" >Spain</option>
		<option value="198" >Sri Lanka</option>
		<option value="199" >Sudan</option>
		<option value="200" >Suriname</option>
		<option value="201" >Swaziland</option>
		<option value="202" >Sweden</option>
		<option value="203" >Switzerland</option>
		<option value="204" >Syria</option>
		<option value="205" >Taiwan</option>
		<option value="206" >Tajikistan</option>
		<option value="207" >Tanzania</option>
		<option value="208" >Tenerife</option>
		<option value="209" >Thailand</option>
		<option value="210" >Togo</option>
		<option value="211" >Tokelau</option>
		<option value="212" >Tonga</option>
		<option value="213" >Trinidad Tobago</option>
		<option value="214" >Tunisia</option>
		<option value="215" >Turkey</option>
		<option value="216" >Turkmenistan</option>
		<option value="217" >Tuvalu</option>
		<option value="218" >Uganda</option>
		<option value="219" >UK</option>
		<option value="220" >Ukraine</option>
		<option value="221" >United Arab Emirates</option>
		<option value="222" >United States</option>
		<option value="223" >Uruguay</option>
		<option value="224" >Uzbekistan</option>
		<option value="225" >Vanuatu</option>
		<option value="226" >Vatican</option>
		<option value="227" >Venezuela</option>
		<option value="228" >Vietnam</option>
		<option value="229" >Virgin Islands</option>
		<option value="230" >Wales</option>
		<option value="231" >Yemen</option>
		<option value="232" >Yugoslavia</option>
		<option value="233" >Zaire</option>
		<option value="234" >Zambia</option>
		<option value="235" >Zimbabwe</option>
</select>
              <span class="help-inline"></span>
            </div>
          </div>
<div class="control-group">
            <label class="control-label" for="inputError">Codigo secreto PIN </label>
            <div class="controls">
              <input type="text" onkeypress="return isNumberKey(event)" name="pin" maxlength="8" id="focusedInput">
              <span class="help-inline">Ingresar 8 Numeros secretos para su cuenta.</span>
            </div>
          </div>


          <div class="form-actions">
            <button type="submit" class="btn btn-primary" name="register">Registro</button>
            <button class="btn" name="clear" type="reset">Resetaer</button>
          </div>
        </fieldset>
      </form>         

<div class="alert alert-block alert-error fade in">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <strong> Informacion: El ultimo usuario en registrar fue:  
            <?
            $wea = skr_query("SELECT TOP 1 * From Account Order By AID DESC");
			$acc = skr_object($wea);
			echo $acc->UserID;
			?></strong> 
          </div>
</div>
        <?
		if(isset($_POST['register']))
			{
				$userid = clean($_POST['userid']);
				$pass1  = clean($_POST['pass1']);
				$pass2	= clean($_POST['pass2']);
				$email	= clean($_POST['email']);
				$edad	= clean($_POST['edad']);
				$pais	= clean($_POST['pais']);
				$name	= clean($_POST['name']);
				$sex	= clean($_POST['sex']);
				$codigo	= clean($_POST['pin']);
				$registro = CreateAcc($userid,$pass1,$pass2,$email,$edad,$pais,$name,$sex,$codigo);
				if($registro){
					msgbox("Usuario Registrado","index.php");
					}else{
			msgbox("Error","index.php");	
					}
					}
					
		?>
        
        
<? /* include "_inc/publi.php";
   //           <!--/row-->


//<!--/span-->
 include "_inc/ultimo_items.php";
 include "_inc/ultimo_cw.php";*/ ?>


</div>