<?
if(isset($_GET['clan']))
{
	$clid = clean($_GET['clan']);
	if(!is_numeric($clid))
	{
		msgbox("Error: en la web.","index.php");
	}else{
		$clanquery = skr_query("SELECT * From Clan WHERE CLID='".clean($clid)."'");
		if(mssql_num_rows($clanquery) == 0){
			msgbox("Error en clan.","index.php");
		}
		$clan = skr_object($clanquery);
		$name = $clan->Name;
		$master =  $clan->MasterCID;
		$puntos = $clan->Point;
		$win = $clan->Wins;
		$lose = $clan->Losses;
		$EmblemChecksum = $clan->EmblemChecksum;
		$emblem = $clan->EmblemUrl;

		
	?>

<div class="row-fluid">
        <div class="span3">


        



<?
include "_inc/status.php"; 
include "_inc/menu.php";
?>
          <!--/.well -->


<!-- Rankid Ladder -->
<? include "_inc/rank_ld.php"; ?>

<!-- Ranking Clanes -->
<? include "_inc/rank_clan.php"; ?>

<!-- Ranking Personaje con todo y datos -->
<? include "_inc/rank_player.php"; ?>
	

        </div><!--/span-->

        <div class="span8 well" >
        	<!-- Inicio de cabeza -->
        
        	<table border="0" >
<tr >
<td rowspan="7"><img class='img-rounded' src="http://i.imgur.com/<?=GetEmblem($emblem)?>" width="150" height="150"></td>
<td>Name:</td>
<td><?=$name?></td>
<td rowspan="7">
<?
if(empty($_SESSION['AID']))
{


}else{
	$sclan = skr_query("SELECT * From Character WHERE CID='".$master."' AND AID='".clean($_SESSION['AID'])."'");
	
	if(mssql_num_rows($sclan) == 0){
	
	}else{

include("secure/upload.php");
if(isset($_POST['submit'])){
	$aid = $_SESSION['AID'];
	
	if(!empty($_FILES['image']['tmp_name']))
{
    $imagen = subirimg($_FILES['image']['tmp_name']);
    if(!empty($imagen))
    {
       $imagen =  str_replace("http://i.imgur.com/","", $imagen);
      
       if(skr_query("UPDATE Clan SET EmblemUrl='$imagen', EmblemChecksum=EmblemChecksum + 1  WHERE CLID='".clean($clid)."'")){
        msgbox("Su emblema fue subi con exito.","index.php");
       }else{

       	msgbox("error 2","index.php");
       }
       
    }else{
        echo "Error al Subir la Imagen :/";
    }
  
}
msgbox("error","index.php");
}


if(isset($_POST['dar']))
{
	$type = (int) clean($_POST['type']);
	$cmid = (int) clean($_POST['cmid']);
	if(!is_numeric($type) || !is_numeric($cmid))
	{
		msgbox("Error: panel clan","index.php");
	}
	if(empty($type) || empty($cmid))
	{
		msgbox("Seleccione la opcion o miembro.","index.php");
	}
	if($type == 3){
		skr_query("DELETE From ClanMember WHERE CMID='".$cmid."'");
		msgbox("El miembro fue expulsado.","index.php");
	}else{
		if(skr_query("UPDATE ClanMember SET Grade='$type' WHERE CMID='".$cmid."'"))
		{
	msgbox("El miembro fue actualizado su rango. ","index.php");

		}
	
	}


}
if(isset($_POST['reset']))
{
	if($_POST['re'] == true){
		skr_query("UPDATE Clan SET Point='1000', Wins='0', Losses='0' WHERE CLID='".$clid."' ");
		skr_query("UPDATE ClanMember SET ContPoint='0' WHERE CLID='".$clid."'");
		msgbox("Su clan ha sido Reseteado.","index.php?skr=rankclan");
	}else{
		msgbox("Marque el cuadro para resetear el clan.","index.php?skr=rankclan");
	}
}
if(isset($_POST['delete']))
{
	if($_POST['de'] == true){
		skr_query("DELETE  From ClanMember WHERE CLID='".$clid."'");
		skr_query("UPDATE Clan SET Name = NULL, DeleteFlag = 1, DeleteName = '$name' WHERE CLID = '$clid' ");
		msgbox("Su clan ha sido eliminado.","index.php?skr=rankclan");
		
	}else{
		msgbox("Marque el cuadro para Eliminar el clan.","index.php?skr=rankclan");
	}
}




	
	


?>

<form name="from1" method="post" enctype="multipart/form-data">
<table>
<tr>
	<th>
	Panel de Clan
	</th>
</tr>
<tr>
<th>
Subir Emblema:
</th>
</tr>
<tr>
<th>
<input type="file" name="image"><br><input type="submit" name="submit" value="Subir Emblem" />
</th>
</tr>
<tr>
<th>
Rango Miembro:
</th>
</tr>
<tr>
<th>

<select name="cmid">
	<option value="" selected="selected"> Seleccione el miembro.</option>
	<?
	$po = skr_query("SELECT * From ClanMember WHERE CLID='".$clid."' AND CID != '".$master."' ");
	while($m = mssql_fetch_object($po)){
	?>
<option value="<?=$m->CMID?>"><?=FormatCharName($m->CID)?></option>
<? } ?>
</select>
</th>
</tr>
<th>

<select name="type">
<option value=""  selected="selected"> Selecciona una Opcion.</option>
<option value="9"> Miembro</option>
<option value="2"> Admin </option>
<option value="3"> Expulsar </option>
</select>
</th>
</tr>
<tr>
<th>
<input type="submit" name="dar" class="btn btn-inverse" value="Dar Rango" />

</th>
</tr>
<tr>
<th>

Reset Clan: <input type="checkbox" name="re" />
<input type="submit" name="reset" class="btn btn-inverse" value="Resetear Clan" />
</th>
</tr>
<tr>
<th>

Eliminar Clan: <input type="checkbox" name="de" />
<input type="submit" name="delete" class="btn btn-inverse" value="Eliminar Clan" />
</th>
</tr>
</table>
</form>
<? }	} ?>

</td>
</tr>
<tr>
<td>Master: </td>
<td><?=FormatCharName($master)?></td>

</tr>
<tr>
<td>Points: </td>
<td><?=$puntos?></td>

</tr>
<tr>
<td>Wins: </td>
<td><?=$win?></td>

</tr>
<tr>
<td>Losse: </td>
<td><?=$lose?></td>

</tr>
<tr>
<td>Promedio: </td>
<td>(pronto)</td>

</tr>
<tr>
<td>Medallas: </td>
<td> <img src="http://hermanosalvarez.com/images/medalla.png" width="20" height="20"></td>


</tr>

</table>
        		
        <!-- termina la baina de inicio -->

<table class="table table-condensed">
	<tr>

<th>Name</th>
<th>Level</th>
<th>Rango</th>
<th>Fecha ingreso</th>
<th></th>
<th></th>
	</tr>

	<tr>
<?
$gg = skr_query("SELECT * From ClanMember WHERE CLID='".$clid."' ");
while($miembro = skr_object($gg)){

?>
<td>
<?=FormatCharName($miembro->CID)?>
</td>

<td><?=GetCharLevel($miembro->CID)?></td>

<td>
<?

	switch($miembro->Grade){

	case 0:
	echo "None";
	break;
	case 1:
	echo "Master";
	break;
	case 2:
	echo "Admin";
	break;
	case 9:
	echo "Miembro";
	break;
	default:
		echo "Nada";
	break;	
	}
	
?>
</td>
<td><?=$miembro->RegDate?> <input type="hidden" name="id" value="<?=$miembro->CMID?>"></td>
<td>

</td>
	</tr>
<?
	
}

?>
</table>

</div>

       


</div>

<? 

}
	
}else{
	re_dir("index.php");
}
?>

