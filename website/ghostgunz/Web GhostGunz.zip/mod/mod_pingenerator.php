<?

if($_SESSION['AID'] == "")
{
re_dir("index.php");

}else{


$q = skr_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
$r = skr_object($q);

$n = 1;
while($n != 2){
$pin = rand(10000000,92345678);
if(strlen($pin) == 8)
{
    echo "CORRECTO $pin";
        $n++;
}else{
   echo "FAIL";
}
    
}
$aid= $r->AID;
$t = "UPDATE Account SET PIN='".$pin."', GN='1' WHERE AID='".$aid."'";
if(skr_query($t)){
    msgbox("Su ping AID: $aid fue creado con exito PIN : $pin ","index.php");
}else{
    die("ERROR");
}
}
?>