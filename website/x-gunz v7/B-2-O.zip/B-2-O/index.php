<?
include "includes/title.php";
include "includes/config.php";
include "includes/shield.php";
include "includes/functions.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("modules/mod_" . $_GET['do'] . ".php")) {
        include "modules/mod_" . $_GET['do'] . ".php";
	}
} }
include "includes/banneduser.php";
include "includes/checkcookie.php";
include "includes/captcha/securimage.php";
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Pragma" content="no-cache" />
<title>X-GunZ V7 ~ Voc� esta pronto para voltar a jogar?!<?=$pagetitle?></title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<link rel="stylesheet" type="text/css" href="frontpage.css" />
<script type="text/javascript">var _siteRoot='index.php',_root='index.php';</script>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
<script type='text/javascript' src='js/presentationCycle.js'></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/nav.js"></script>
<script language="JavaScript" src="js/functions.js"> </script>
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" background="images/bg2.jpg">
<div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr><td bgcolor="#000000">
<div id="scroller">
	<div class="l"></div>
  <div class="c" >
	<marquee>X-GunZ Voltando com muitas novidades! Registre-se e fique por dentro!</marquee>
	</div>
	<div class="r"></div>
</div>
</td>
</tr>
		<tr>
			<td background="images/header.jpg" width="921" height="250">&nbsp;</td>
		</tr>
		<tr>
<td bgcolor="#000000">
<ul class="topnav">  
     <li><a href="index.php">Home</a></li>  
     <li>  
         <a href="index.php?do=register">Registro</a>
     </li>  
     <li>  
         <a href="index.php?do=downloads&expand=1&sub=client">Downloads</a>  
         <ul class="subnav">  
             <li><a href="index.php?do=downloads&expand=1&sub=client">Client</a></li>
             <li><a href="index.php?do=downloads&expand=1&sub=WallPapers">Wallpapers</a></li>  
             <li><a href="index.php?do=downloads&expand=1&sub=Screenshots">Screenshots</a></li>  
         </ul>
     </li>  
     <li><a href="http://xgunzevolutionx3.forumbrasil.net/">Forum</a></li>
     <li><a href="index.php?do=individualrank">Ranking</a>
         <ul class="subnav">  
             <li><a href="index.php?do=individualrank">Individual</a></li>  
             <li><a href="index.php?do=clanrank">Clan</a></li>  
             <li><a href="index.php?do=halloffame">Hall da Fama</a></li>
         </ul>  
</li>  
     <li><a href="index.php?do=userpanel">Painel de Controle</a>
         <ul class="subnav">  
             <li><a href="index.php?do=userpanel">CP de Usuario</a></li>
             <li><a href="index.php?do=clancp&expand=1&sub=emblem">CP de Clans</a></li>
         </ul> </li>  
     <li><a href="index.php?do=itemshop&sub=listallitems&expand=1&type=3">Galeria de Itens</a></li>
     <li><a href="http://xgunzevolutionx3.forumbrasil.net/">Suporte</a></li>
     <li><a href="index.php?do=cafe">Cafe</a></li>
     <li><a href="index.php?do=donate">Donate</a></li>
 </ul></td></tr>
		<tr>
			<td background="images/main_bg.png">		
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 				<?	
						if ($_GET['expand'] == 1){
   						if (file_exists("modules/mod_" . $_GET['do'] . ".php")) {
        							include "modules/mod_" . $_GET['do'] . ".php";
        							$include = "1";
								}
						}
 						?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
						<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254){
								include"modules/mod_adminindex.php";echo "</br>";} ?>
						<? include "modules/mod_clanranking.php" ?>
						</div>
					</td>
					<td width="481" valign="top">
						<? 	if($opened == 0){
                        					include "mod_offline.php";
                    				   	}else{
                    					if (isset($_GET['do'])) 
							{
                            					$_GET['expand'] = 0;
						   			if (file_exists("modules/mod_" . $_GET['do'] . ".php")) {
							    		include "modules/mod_" . $_GET['do'] . ".php";
						    			}
                        				}else{
                            					include "modules/mod_index.php";
					    		}
                        				if(isset($default)){
                            					include $default;
                        				}  
						}
                        ?></td>

				</tr>
				</table>

		<tr>
			<td background="images/footer.png" height="75"><p align="center"> &nbsp;</p></td>
		</tr>
	</table>
</div>

<div id="scroller">
	<div class="l"></div>
  <div class="c" >
	<marquee>Website criado por: Maxteam //Lambda //Emisand//SettleSpider //  Redesigned By: Nick // Copyright X-GamerZ 2009~2011</marquee>
	</div>
	<div class="r"></div>
</div>
</body>

</html>
