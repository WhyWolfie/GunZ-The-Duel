<?php
include "includes/config.php";
include "includes/functions.php";
?>
<?php

$email=$_POST['email'];
$validated=validateemail($email);

$existing_users = mssql_query("SELECT * FROM Account WHERE email='$email'");
$numrows = mssql_num_rows($existing_users);

if($numrows>0 || $validated<0)
{
	//user name is not availble
	echo "no";
}
else
{
	//user name is available
	echo "yes";
}
?>
