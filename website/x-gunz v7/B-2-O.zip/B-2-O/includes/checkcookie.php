<?php
//This file has been edited by Wizkid. All rights reserved.
if(!$_COOKIE['MPOGLogin_usr'] == ""){
	//Always use the antisql over a COOKIE, since you can both edit and spoof them.
    $user = antisql($_COOKIE['MPOGLogin_usr']);
    $md5pass = $_COOKIE['MPOGLogin_pwd'];
    $res = mssql_query("SELECT * FROM Login WHERE UserID = '$user'");
    $data = mssql_fetch_assoc($res);
    //
    if(md5("mpogc_".$data['Password']) == $md5pass){
        $_SESSION['AID'] =  $data['AID'];
        $_SESSION['UserID'] = ucfirst($user);
        $_SESSION['euCoins'] = $data['euCoins'];
        //---
        $res2 = mssql_query("SELECT * FROM Account WHERE AID = '".$data['AID']."'");
        $aData = mssql_fetch_assoc($res2);
        //---
        $_SESSION['UGradeID'] = $aData['UGradeID'];
    }
}
?>