<?php

if($_SESSION['UGradeID'] == 253){


if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>

<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Gunz-The Reloaded Duel</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" background="images/bg2.jpg">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr>
			<td background="images/header.jpg" width="921" height="250">&nbsp;</td>
		</tr>
		<tr>
			<td background="images/nav_bar.png" height="28" class="menu" valign="middle">
			<p align="center">Home | Register | Downloads | Forum | Ranking | Clan-CP | Items Gallery | Contact | Cafe | Donate Us</td>
		</tr>
		<tr>
			<td background="images/main_bg.png">

			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?php
				 if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
						</div>
					</td>
					<td width="481" valign="top">
					<div align="center">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/accountbanned.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											Sorry, the account <b>
											<?=$_SESSION['UserID']?></b>
											does not have permission to access</br> Gunz - The Reloaded Duel<p></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<p align="center">The expulsion of users is carried out by 
											failing to meet certain standards, or non-use programs such
											as GunZ Hacks and Cheats.</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
																						<tr>
													<td width="106">
													<p align="center">
													<a href="index.php?do=login&action=logout&header=1"><img border="0" src="images/log-out.jpg" width="70" height="27"></a></td>
												</tr>
<?php echo @$errorbox ?>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
						<p>&nbsp;</div>
					</td>
					<td width="206" valign="top">
					<p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td background="images/footer.png" height="75">&nbsp;</td>
		</tr>
	</table>
</div>

</body>

</html>
    <?php
    die();
}

?>