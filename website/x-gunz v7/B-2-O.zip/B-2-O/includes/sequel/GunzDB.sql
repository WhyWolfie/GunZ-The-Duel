﻿-- SQL Manager 2008 for SQL Server 3.0.0.1
-- ---------------------------------------
-- Host      : ELTON-PC\SQLEXPRESS
-- Database  : GunzDB
-- Version   : Microsoft SQL Server  9.00.3042.00


--
-- Definition for user gunz : 
--

CREATE USER [gunz]
  WITHOUT LOGIN 
  WITH DEFAULT_SCHEMA = [dbo]
GO

--
-- Definition for table Account : 
--

CREATE TABLE [dbo].[Account] (
  [AID] int IDENTITY(1, 1) NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [UGradeID] int NOT NULL,
  [PGradeID] int NOT NULL,
  [RegDate] datetime NOT NULL,
  [Name] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Email] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RegNum] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Age] smallint NULL,
  [Sex] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [ZipCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Address] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Country] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LastCID] int NULL,
  [Cert] tinyint NULL,
  [HackingType] tinyint NULL,
  [HackingRegTime] smalldatetime NULL,
  [EndHackingBlockTime] smalldatetime NULL,
  [LastLoginTime] smalldatetime NULL,
  [ServerID] tinyint NULL,
  [LastLogoutTime] smalldatetime NULL,
  [BirthDate] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [sa] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [sq] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [captcha_code] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [mobile] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Views] int CONSTRAINT [DF_Account_Views] DEFAULT 0 NULL,
  [event1] int CONSTRAINT [DF_Account_event1] DEFAULT 0 NOT NULL,
  CONSTRAINT [Account_PK] PRIMARY KEY CLUSTERED ([AID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Account_RegDate] ON [dbo].[Account]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Account_UserID] ON [dbo].[Account]
  ([UserID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table AccountItem : 
--

CREATE TABLE [dbo].[AccountItem] (
  [AIID] int IDENTITY(1, 1) NOT NULL,
  [AID] int NOT NULL,
  [ItemID] int NOT NULL,
  [RentDate] datetime CONSTRAINT [DF__AccountIt__RentD__116A8EFB] DEFAULT NULL NULL,
  [RentHourPeriod] smallint CONSTRAINT [DF__AccountIt__RentH__125EB334] DEFAULT NULL NULL,
  [Cnt] smallint DEFAULT NULL NULL,
  [ShopItemID] int NULL,
  CONSTRAINT [Table1_PK] PRIMARY KEY CLUSTERED ([AIID]),
  CONSTRAINT [Account_Table1_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Item_Table1_FK1] FOREIGN KEY ([ItemID]) 
  REFERENCES [dbo].[Item] ([ItemID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountItem_AID] ON [dbo].[AccountItem]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_AccountItem_RentDate] ON [dbo].[AccountItem]
  ([RentDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table AccountPenaltyLog : 
--

CREATE TABLE [dbo].[AccountPenaltyLog] (
  [PenaltyLogID] int IDENTITY(1, 1) NOT NULL,
  [AID] int NULL,
  [UGradeID] int NULL,
  [DayLeft] int NULL,
  [RegDate] smalldatetime NULL,
  [GMID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [PK__AccountPenaltyLo__03317E3D] PRIMARY KEY NONCLUSTERED ([PenaltyLogID])
)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_AccountPenaltyLog_AID] ON [dbo].[AccountPenaltyLog]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table AccountPenaltyPeriod : 
--

CREATE TABLE [dbo].[AccountPenaltyPeriod] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NOT NULL,
  [DayLeft] int NOT NULL,
  CONSTRAINT [AccountPenaltyPeriod_PK] PRIMARY KEY CLUSTERED ([id]),
  CONSTRAINT [AccountPenaltyPeriod_Account_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

--
-- Definition for table BillingMethod : 
--

CREATE TABLE [dbo].[BillingMethod] (
  [BillingMethodID] int NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  CONSTRAINT [BillingMethod_PK] PRIMARY KEY CLUSTERED ([BillingMethodID])
)
ON [PRIMARY]
GO

--
-- Definition for table BlockCountryCode : 
--

CREATE TABLE [dbo].[BlockCountryCode] (
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [RoutingURL] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [IsBlock] tinyint CONSTRAINT [DF__BlockCoun__IsBlo__0E04126B] DEFAULT 0 NULL,
  PRIMARY KEY CLUSTERED ([CountryCode3])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_BlockCountryCode_IsBlock] ON [dbo].[BlockCountryCode]
  ([IsBlock])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table BringAccountItemLog : 
--

CREATE TABLE [dbo].[BringAccountItemLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NULL,
  [CID] int NULL,
  [ItemID] int NOT NULL,
  [Date] datetime NOT NULL,
  CONSTRAINT [BringAccountItemLog_PK] PRIMARY KEY NONCLUSTERED ([id]),
  CONSTRAINT [Account_BringAccountItemLog_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Character_BringAccountItemLog_FK1] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Item_BringAccountItemLog_FK1] FOREIGN KEY ([ItemID]) 
  REFERENCES [dbo].[Item] ([ItemID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_BringAccoutItem_AID] ON [dbo].[BringAccountItemLog]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CashItemPresentLog : 
--

CREATE TABLE [dbo].[CashItemPresentLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [SenderUserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [ReceiverAID] int NOT NULL,
  [CSID] int NULL,
  [CSSID] int NULL,
  [Cash] int NOT NULL,
  [Date] datetime NOT NULL,
  [RentHourPeriod] int NULL,
  [MobileCode] char(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [CashItemPresentLog_PK] PRIMARY KEY CLUSTERED ([id]),
  CONSTRAINT [Account_CashItemPresentLog_FK1] FOREIGN KEY ([ReceiverAID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashItemPresentLog_Date] ON [dbo].[CashItemPresentLog]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashItemPresentLog_ReceiverAID] ON [dbo].[CashItemPresentLog]
  ([ReceiverAID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashItemPresentLog_SenderUserID] ON [dbo].[CashItemPresentLog]
  ([SenderUserID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CashSetItem : 
--

CREATE TABLE [dbo].[CashSetItem] (
  [CSIID] int IDENTITY(1, 1) NOT NULL,
  [CSSID] int NOT NULL,
  [CSID] int NOT NULL,
  CONSTRAINT [CashSetItem_PK] PRIMARY KEY CLUSTERED ([CSIID]),
  CONSTRAINT [CashSetShop_CashSetItem_FK1] FOREIGN KEY ([CSSID]) 
  REFERENCES [dbo].[CashSetShop] ([CSSID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Item_CashSetItem_FK1] FOREIGN KEY ([CSID]) 
  REFERENCES [dbo].[CashShop] ([CSID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

--
-- Definition for table CashSetShop : 
--

CREATE TABLE [dbo].[CashSetShop] (
  [CSSID] int NOT NULL,
  [Name] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Description] varchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CashPrice] int NOT NULL,
  [WebImgName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [NewItemOrder] tinyint NULL,
  [ResSex] tinyint NULL,
  [ResLevel] int NULL,
  [Weight] int NULL,
  [Opened] tinyint NULL,
  [RegDate] datetime NULL,
  [RentType] tinyint NULL,
  CONSTRAINT [CashSetShop_PK] PRIMARY KEY CLUSTERED ([CSSID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashSetShop_NewItemOrder] ON [dbo].[CashSetShop]
  ([NewItemOrder])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashSetShop_Opened] ON [dbo].[CashSetShop]
  ([Opened])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CashShop : 
--

CREATE TABLE [dbo].[CashShop] (
  [CSID] int IDENTITY(1, 1) NOT NULL,
  [ItemID] int NOT NULL,
  [NewItemOrder] tinyint NULL,
  [CashPrice] int NOT NULL,
  [WebImgName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Opened] tinyint NULL,
  [RegDate] datetime NULL,
  [RentType] tinyint NULL,
  [CSSID] int NULL,
  [Name] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Slot] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [ResSex] int NULL,
  [ResLevel] int NULL,
  [Weight] int NULL,
  [Damage] int NULL,
  [AP] int NULL,
  [FR] int NULL,
  [Delay] int NULL,
  [HP] int NULL,
  [PR] int NULL,
  [Magazine] int NULL,
  [MaxWeight] int NULL,
  [CR] int NULL,
  [MaxBullet] int NULL,
  [ReloadTime] int NULL,
  [LR] int NULL,
  [Control] int NULL,
  [Duration] int NULL,
  [Description] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Selled] int CONSTRAINT [DF_CashShop_Selled] DEFAULT 0 NULL,
  [ForSale] int CONSTRAINT [DF_CashShop_ForSale] DEFAULT 0 NOT NULL,
  CONSTRAINT [CashShop_PK] PRIMARY KEY CLUSTERED ([CSID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShop_ItemID_Opened] ON [dbo].[CashShop]
  ([ItemID], [Opened])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShop_NewItemOrder] ON [dbo].[CashShop]
  ([NewItemOrder])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShop_Opened] ON [dbo].[CashShop]
  ([Opened])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CashShopNewItem : 
--

CREATE TABLE [dbo].[CashShopNewItem] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [Category] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [NewOrder] int NOT NULL,
  [IsSetItem] int NOT NULL,
  [CSID] int NULL,
  [CSSID] int NULL,
  [Slot] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [ResSex] int NOT NULL,
  [ResLevel] int NOT NULL,
  [CashPrice] int NOT NULL,
  [WebImgName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RegDate] datetime CONSTRAINT [DF__CashShopN__RegDa__2D67AF2B] DEFAULT getdate() NOT NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShopNewItem_NewOrder] ON [dbo].[CashShopNewItem]
  ([NewOrder])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CashShopNewItemCategory : 
--

CREATE TABLE [dbo].[CashShopNewItemCategory] (
  [CategoryID] int NOT NULL,
  [Description] varchar(12) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  CONSTRAINT [PK__CashShopNewItemC__0DAF0CB0] PRIMARY KEY CLUSTERED ([CategoryID]),
  CONSTRAINT [UQ__CashShopNewItemC__0EA330E9] UNIQUE ([Description])
)
ON [PRIMARY]
GO

--
-- Definition for table CashShopRank : 
--

CREATE TABLE [dbo].[CashShopRank] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [Rank] int NOT NULL,
  [Category] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Count] int NOT NULL,
  [CSID] int NULL,
  [CSSID] int NULL,
  [Slot] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [ResSex] int NOT NULL,
  [ResLevel] int NOT NULL,
  [CashPrice] int NOT NULL,
  [RegDate] datetime CONSTRAINT [DF__CashShopR__RegDa__1C3D2329] DEFAULT getdate() NOT NULL,
  CONSTRAINT [pk_CashShopRank_id] PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShopRank_Category] ON [dbo].[CashShopRank]
  ([Category])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CashShopRank_Rank] ON [dbo].[CashShopRank]
  ([Rank])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table Character : 
--

CREATE TABLE [dbo].[Character] (
  [CID] int IDENTITY(1, 1) NOT NULL,
  [AID] int NOT NULL,
  [Name] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Level] smallint NOT NULL,
  [Sex] tinyint NOT NULL,
  [CharNum] smallint NOT NULL,
  [Hair] tinyint NULL,
  [Face] tinyint NULL,
  [XP] int NOT NULL,
  [BP] int NOT NULL,
  [HP] smallint NULL,
  [AP] smallint NULL,
  [FR] int NULL,
  [CR] int NULL,
  [ER] int NULL,
  [WR] int NULL,
  [head_slot] int NULL,
  [chest_slot] int NULL,
  [hands_slot] int NULL,
  [legs_slot] int NULL,
  [feet_slot] int NULL,
  [fingerl_slot] int NULL,
  [fingerr_slot] int NULL,
  [melee_slot] int NULL,
  [primary_slot] int NULL,
  [secondary_slot] int NULL,
  [custom1_slot] int NULL,
  [custom2_slot] int NULL,
  [RegDate] datetime NULL,
  [LastTime] datetime NULL,
  [PlayTime] int NULL,
  [GameCount] int NULL,
  [KillCount] int NULL,
  [DeathCount] int NULL,
  [DeleteFlag] tinyint NULL,
  [DeleteName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [head_itemid] int NULL,
  [chest_itemid] int NULL,
  [hands_itemid] int NULL,
  [legs_itemid] int NULL,
  [feet_itemid] int NULL,
  [fingerl_itemid] int NULL,
  [fingerr_itemid] int NULL,
  [melee_itemid] int NULL,
  [primary_itemid] int NULL,
  [secondary_itemid] int NULL,
  [custom1_itemid] int NULL,
  [custom2_itemid] int NULL,
  [QuestItemInfo] binary(292) NULL,
  [hide] int NULL,
  [Views] int CONSTRAINT [DF_Character_Views] DEFAULT 0 NOT NULL,
  [Ranking] int NULL,
  CONSTRAINT [Character_PK] PRIMARY KEY CLUSTERED ([CID]),
  CONSTRAINT [Account_Character_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Character_AID] ON [dbo].[Character]
  ([AID], [CharNum])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Character_AID_DeleteFlag] ON [dbo].[Character]
  ([AID], [DeleteFlag])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Character_DeleteFlag] ON [dbo].[Character]
  ([DeleteFlag])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Character_Name] ON [dbo].[Character]
  ([Name])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CharacterItem : 
--

CREATE TABLE [dbo].[CharacterItem] (
  [CIID] int IDENTITY(1, 1) NOT NULL,
  [CID] int NULL,
  [ItemID] int NOT NULL,
  [RegDate] datetime NULL,
  [RentDate] datetime CONSTRAINT [DF__Character__RentD__0E8E2250] DEFAULT NULL NULL,
  [RentHourPeriod] smallint CONSTRAINT [DF__Character__RentH__0F824689] DEFAULT NULL NULL,
  [Cnt] smallint CONSTRAINT [DF__CharacterIt__Cnt__10766AC2] DEFAULT NULL NULL,
  CONSTRAINT [CharacterItem_PK] PRIMARY KEY CLUSTERED ([CIID]),
  CONSTRAINT [Character_CharacterItem_FK1] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CharacterItem_CID] ON [dbo].[CharacterItem]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CharacterMakingLog : 
--

CREATE TABLE [dbo].[CharacterMakingLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NULL,
  [CharName] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Type] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Date] datetime NULL
)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_CharacterMakingDete] ON [dbo].[CharacterMakingLog]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CharacterMakingName] ON [dbo].[CharacterMakingLog]
  ([CharName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CharacterMgrLogByGM : 
--

CREATE TABLE [dbo].[CharacterMgrLogByGM] (
  [CharMgrLogID] int IDENTITY(1, 1) NOT NULL,
  [CID] int NULL,
  [CharName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [CharMgrTypeID] tinyint NULL,
  [GMID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [NewName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [OrgValue] int NULL,
  [NewValue] int NULL,
  [RegDate] smalldatetime NULL,
  CONSTRAINT [PK__CharacterMgrLogB__1EA48E88] PRIMARY KEY NONCLUSTERED ([CharMgrLogID]),
  CONSTRAINT [FK__Character__CharM__442B18F2] FOREIGN KEY ([CharMgrTypeID]) 
  REFERENCES [dbo].[CharacterMgrType] ([CharMgrTypeID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [FK__Character__CharM__7226EDCC] FOREIGN KEY ([CharMgrTypeID]) 
  REFERENCES [dbo].[CharacterMgrType] ([CharMgrTypeID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [FK__CharacterMg__CID__451F3D2B] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [FK__CharacterMg__CID__731B1205] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CharacterMgrLogByGM_CharMgrTypeID] ON [dbo].[CharacterMgrLogByGM]
  ([CharMgrTypeID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CharacterMgrLogByGM_CharName] ON [dbo].[CharacterMgrLogByGM]
  ([CharName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_CharacterMgrLogByGM_CID] ON [dbo].[CharacterMgrLogByGM]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CharacterMgrLogByGM_RegDate] ON [dbo].[CharacterMgrLogByGM]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table CharacterMgrType : 
--

CREATE TABLE [dbo].[CharacterMgrType] (
  [CharMgrTypeID] tinyint NOT NULL,
  [Description] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  PRIMARY KEY CLUSTERED ([CharMgrTypeID])
)
ON [PRIMARY]
GO

--
-- Definition for table CharItem : 
--

CREATE TABLE [dbo].[CharItem] (
  [CIID] int IDENTITY(1, 1) NOT NULL,
  [CID] int NULL,
  [ItemID] int NOT NULL,
  [RegDate] datetime NULL,
  [RentDate] datetime CONSTRAINT [DF__Char__RentD__0E8E2250] DEFAULT NULL NULL,
  [RentHourPeriod] smallint CONSTRAINT [DF__Char__RentH__0F824689] DEFAULT NULL NULL,
  [Cnt] smallint CONSTRAINT [DF__CharIt__Cnt__10766AC2] DEFAULT NULL NULL,
  CONSTRAINT [CharItem_PK] PRIMARY KEY CLUSTERED ([CIID]),
  CONSTRAINT [Char_CharItem_FK1] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

--
-- Definition for table charnamelog : 
--

CREATE TABLE [dbo].[charnamelog] (
  [OldName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [NewName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table Clan : 
--

CREATE TABLE [dbo].[Clan] (
  [CLID] int IDENTITY(1, 1) NOT NULL,
  [Name] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Exp] int DEFAULT 0 NOT NULL,
  [Level] tinyint DEFAULT 1 NOT NULL,
  [Point] int CONSTRAINT [DF_Clan_Point] DEFAULT 1000 NOT NULL,
  [MasterCID] int NULL,
  [Wins] int DEFAULT 0 NOT NULL,
  [MarkWebImg] varchar(48) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Introduction] varchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RegDate] datetime NOT NULL,
  [DeleteFlag] tinyint DEFAULT 0 NULL,
  [DeleteName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Homepage] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Losses] int DEFAULT 0 NOT NULL,
  [Draws] int DEFAULT 0 NOT NULL,
  [Ranking] int DEFAULT 0 NOT NULL,
  [TotalPoint] int DEFAULT 0 NOT NULL,
  [Cafe_Url] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Email] varchar(70) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [EmblemUrl] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RankIncrease] int DEFAULT 0 NOT NULL,
  [EmblemChecksum] int DEFAULT 0 NOT NULL,
  [LastDayRanking] int DEFAULT 0 NOT NULL,
  [LastMonthRanking] int DEFAULT 0 NOT NULL,
  CONSTRAINT [Clan_PK] PRIMARY KEY CLUSTERED ([CLID]),
  CONSTRAINT [Clan_Character_FK1] FOREIGN KEY ([MasterCID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Clan_DeleteFlag] ON [dbo].[Clan]
  ([DeleteFlag])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Clan_MasterCID] ON [dbo].[Clan]
  ([MasterCID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Clan_Name] ON [dbo].[Clan]
  ([Name])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Clan_Ranking] ON [dbo].[Clan]
  ([Ranking])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Clan_RegDate] ON [dbo].[Clan]
  ([RegDate] DESC)
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanAdsBoard : 
--

CREATE TABLE [dbo].[ClanAdsBoard] (
  [Seq] int IDENTITY(1, 1) NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Subject] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [RegDate] smalldatetime NOT NULL,
  [ReadCount] int CONSTRAINT [DF__ClanAdsBo__ReadC__2D7CBDC4] DEFAULT 0 NOT NULL,
  [Recommend] int CONSTRAINT [DF__ClanAdsBo__Recom__2E70E1FD] DEFAULT 0 NULL,
  [Content] varchar(2000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [FileName] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Link] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [HTML] smallint CONSTRAINT [DF__ClanAdsBoa__HTML__2F650636] DEFAULT 0 NOT NULL,
  [CommentCount] int CONSTRAINT [DF__ClanAdsBo__Comme__30592A6F] DEFAULT 0 NOT NULL,
  [GR_ID] int CONSTRAINT [DF__ClanAdsBo__GR_ID__314D4EA8] DEFAULT 0 NOT NULL,
  [GR_Depth] int CONSTRAINT [DF__ClanAdsBo__GR_De__324172E1] DEFAULT 0 NOT NULL,
  [GR_Pos] int CONSTRAINT [DF__ClanAdsBo__GR_Po__3335971A] DEFAULT 0 NOT NULL,
  [Thread] int CONSTRAINT [DF__ClanAdsBo__Threa__3429BB53] DEFAULT 0 NOT NULL,
  PRIMARY KEY CLUSTERED ([Seq])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_GR_Depth] ON [dbo].[ClanAdsBoard]
  ([GR_Depth])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_GR_ID] ON [dbo].[ClanAdsBoard]
  ([GR_ID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_GR_Pos] ON [dbo].[ClanAdsBoard]
  ([GR_Pos])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_Subject] ON [dbo].[ClanAdsBoard]
  ([Subject])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_Thraed] ON [dbo].[ClanAdsBoard]
  ([Thread])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsBoard_UserID] ON [dbo].[ClanAdsBoard]
  ([UserID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanAdsComment : 
--

CREATE TABLE [dbo].[ClanAdsComment] (
  [ID] int IDENTITY(1, 1) NOT NULL,
  [Seq] int NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [RegDate] smalldatetime NOT NULL,
  [Content] varchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  PRIMARY KEY CLUSTERED ([ID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsComment_RegDate] ON [dbo].[ClanAdsComment]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanAdsComment_Seq] ON [dbo].[ClanAdsComment]
  ([Seq])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanBoard : 
--

CREATE TABLE [dbo].[ClanBoard] (
  [Seq] int IDENTITY(1, 1) NOT NULL,
  [CLID] int NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Subject] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [RegDate] smalldatetime NOT NULL,
  [ReadCount] int DEFAULT 0 NOT NULL,
  [Recommend] int DEFAULT 0 NULL,
  [Content] varchar(4000) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [FileName] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Link] varchar(255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [HTML] smallint DEFAULT 0 NOT NULL,
  [CommentCount] int DEFAULT 0 NOT NULL,
  [GR_ID] int DEFAULT 0 NOT NULL,
  [GR_Depth] int DEFAULT 0 NOT NULL,
  [GR_Pos] int DEFAULT 0 NOT NULL,
  [Thread] int DEFAULT 0 NOT NULL,
  PRIMARY KEY CLUSTERED ([Seq])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_CLID] ON [dbo].[ClanBoard]
  ([CLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_GR_Depth] ON [dbo].[ClanBoard]
  ([GR_Depth])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_GR_ID] ON [dbo].[ClanBoard]
  ([GR_ID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_GR_Pos] ON [dbo].[ClanBoard]
  ([GR_Pos])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_Thread] ON [dbo].[ClanBoard]
  ([Thread])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoard_UserID] ON [dbo].[ClanBoard]
  ([UserID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanBoardComment : 
--

CREATE TABLE [dbo].[ClanBoardComment] (
  [ID] int IDENTITY(1, 1) NOT NULL,
  [Seq] int NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [RegDate] smalldatetime NOT NULL,
  [Content] varchar(500) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  PRIMARY KEY CLUSTERED ([ID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoardComment_RegDate] ON [dbo].[ClanBoardComment]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanBoardComment_Seq] ON [dbo].[ClanBoardComment]
  ([Seq])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanGameLog : 
--

CREATE TABLE [dbo].[ClanGameLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [WinnerCLID] int NOT NULL,
  [LoserCLID] int NOT NULL,
  [WinnerClanName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LoserClanName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [WinnerMembers] varchar(110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LoserMembers] varchar(110) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RoundWins] tinyint NOT NULL,
  [RoundLosses] tinyint NOT NULL,
  [MapID] tinyint NOT NULL,
  [GameType] tinyint NOT NULL,
  [RegDate] datetime NOT NULL,
  [WinnerPoint] int NULL,
  [LoserPoint] int NULL,
  CONSTRAINT [ClanGameLog_PK] PRIMARY KEY NONCLUSTERED ([id]),
  CONSTRAINT [ClanGameLog_LoserCLID_FK1] FOREIGN KEY ([LoserCLID]) 
  REFERENCES [dbo].[Clan] ([CLID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [ClanGameLog_WinnerCLID_FK1] FOREIGN KEY ([WinnerCLID]) 
  REFERENCES [dbo].[Clan] ([CLID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanGameLog_LoserCLID] ON [dbo].[ClanGameLog]
  ([LoserCLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_ClanGameLog_RegDate] ON [dbo].[ClanGameLog]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanGameLog_WinnerCLID] ON [dbo].[ClanGameLog]
  ([WinnerCLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanHonorRanking : 
--

CREATE TABLE [dbo].[ClanHonorRanking] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [CLID] int NULL,
  [ClanName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Point] int NULL,
  [Wins] int NULL,
  [Losses] int NULL,
  [Ranking] int NULL,
  [Year] smallint NULL,
  [Month] tinyint NULL,
  [RankIncrease] int CONSTRAINT [DF__ClanHonor__RankI__0504B816] DEFAULT 0 NOT NULL,
  CONSTRAINT [PK_ClanHonorRanking_ID] PRIMARY KEY CLUSTERED ([id]),
  CONSTRAINT [ClanHonorRanking_CLID_FK1] FOREIGN KEY ([CLID]) 
  REFERENCES [dbo].[Clan] ([CLID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanHonorRanking_ClanName] ON [dbo].[ClanHonorRanking]
  ([ClanName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanHonorRanking_CLID] ON [dbo].[ClanHonorRanking]
  ([CLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanHonorRanking_Ranking] ON [dbo].[ClanHonorRanking]
  ([Ranking])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanHonorRanking_YearMonthRanking] ON [dbo].[ClanHonorRanking]
  ([Year], [Month], [Ranking])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanMember : 
--

CREATE TABLE [dbo].[ClanMember] (
  [CMID] int IDENTITY(1, 1) NOT NULL,
  [CLID] int NULL,
  [CID] int NULL,
  [Grade] tinyint NOT NULL,
  [RegDate] datetime NOT NULL,
  [ContPoint] int CONSTRAINT [DF__ClanMembe__ContP__6B44E613] DEFAULT 0 NOT NULL,
  CONSTRAINT [ClanMember_PK] PRIMARY KEY CLUSTERED ([CMID]),
  CONSTRAINT [ClanMember_Clan_FK1] FOREIGN KEY ([CLID]) 
  REFERENCES [dbo].[Clan] ([CLID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [ClanMember_Clan_FK2] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanMember_CID] ON [dbo].[ClanMember]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ClanMember_CLID] ON [dbo].[ClanMember]
  ([CLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ClanMemberGrade : 
--

CREATE TABLE [dbo].[ClanMemberGrade] (
  [GradeID] int NOT NULL,
  [Grade] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  PRIMARY KEY CLUSTERED ([GradeID])
)
ON [PRIMARY]
GO

--
-- Definition for table CoinsLog : 
--

CREATE TABLE [dbo].[CoinsLog] (
  [From] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [To] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Coins] int NULL,
  [Date] datetime NULL,
  [Paid] int NULL
)
ON [PRIMARY]
GO

--
-- Definition for table ConnLog : 
--

CREATE TABLE [dbo].[ConnLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NOT NULL,
  [Time] smalldatetime NULL,
  [IPPart1] tinyint NOT NULL,
  [IPPart2] tinyint NOT NULL,
  [IPPart3] tinyint NOT NULL,
  [IPPart4] tinyint NOT NULL,
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table ConnLog2 : 
--

CREATE TABLE [dbo].[ConnLog2] (
  [AID] int NULL,
  [Time] datetime NULL,
  [IPPart1] tinyint NULL,
  [IPPart2] tinyint NULL,
  [IPPart3] tinyint NULL,
  [IPPart4] tinyint NULL,
  [CountryCode3] char(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table CountryCode : 
--

CREATE TABLE [dbo].[CountryCode] (
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [CountryName] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  PRIMARY KEY CLUSTERED ([CountryCode3])
)
ON [PRIMARY]
GO

--
-- Definition for table CustomIP : 
--

CREATE TABLE [dbo].[CustomIP] (
  [ID] int NULL,
  [IPFrom] bigint NOT NULL,
  [IPTo] bigint NOT NULL,
  [IsBlock] tinyint NOT NULL,
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Comment] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RegDate] smalldatetime NULL,
  UNIQUE ([IPFrom]),
  UNIQUE ([IPTo]),
  UNIQUE ([IPFrom]),
  UNIQUE ([IPTo])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CustomIP_CountryCode3] ON [dbo].[CustomIP]
  ([CountryCode3])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CustomIP_IPFrom] ON [dbo].[CustomIP]
  ([IPFrom])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_CustomIP_IPTo] ON [dbo].[CustomIP]
  ([IPTo])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table DayRanking : 
--

CREATE TABLE [dbo].[DayRanking] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [Name] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Level] smallint NOT NULL,
  [Point] int NULL,
  [Rank] int NULL,
  CONSTRAINT [PK_DayRanking_ID] PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_DayRanking_Rank] ON [dbo].[DayRanking]
  ([Rank])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table DeleteAccountLog : 
--

CREATE TABLE [dbo].[DeleteAccountLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [UserID] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [AID] int NOT NULL,
  [RegDate] smalldatetime NULL,
  PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

--
-- Definition for table DonationLog : 
--

CREATE TABLE [dbo].[DonationLog] (
  [Character] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Donated] int NULL,
  [paidon] datetime NULL
)
ON [PRIMARY]
GO

--
-- Definition for table Effect : 
--

CREATE TABLE [dbo].[Effect] (
  [ID] int NOT NULL,
  [Name] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Area] int NULL,
  [Time] int NULL,
  [ModHP] int NULL,
  [ModAP] int NULL,
  [ModMaxWT] int NULL,
  [ModSF] int NULL,
  [ModFR] int NULL,
  [ModCR] int NULL,
  [ModPR] int NULL,
  [ModLR] int NULL,
  [ResAP] int NULL,
  [ResFR] int NULL,
  [ResCR] int NULL,
  [ResPR] int NULL,
  [ResLR] int NULL,
  [Stun] int NULL,
  [KnockBack] int NULL,
  [Smoke] int NULL,
  [Flash] int NULL,
  [Tear] int NULL,
  [Flame] int NULL,
  CONSTRAINT [Effect_PK] PRIMARY KEY CLUSTERED ([ID])
)
ON [PRIMARY]
GO

--
-- Definition for table Event : 
--

CREATE TABLE [dbo].[Event] (
  [AID] int NOT NULL,
  [CID] int NOT NULL,
  [RegDate] smalldatetime NOT NULL,
  [Checked] bit NULL,
  [EventName] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_AID] ON [dbo].[Event]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_CID] ON [dbo].[Event]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_RegDate] ON [dbo].[Event]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table Event_ClanPointRanking : 
--

CREATE TABLE [dbo].[Event_ClanPointRanking] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [Rank] int NOT NULL,
  [CLID] int NOT NULL,
  [Name] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Count] int NOT NULL,
  [Point] int NOT NULL,
  [RegDate] datetime CONSTRAINT [DF__Event_Cla__RegDa__49CEE3AF] DEFAULT getdate() NOT NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_ClanPointRanking_CLID] ON [dbo].[Event_ClanPointRanking]
  ([CLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_ClanPointRanking_Rank] ON [dbo].[Event_ClanPointRanking]
  ([Rank])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Event_ClanPointRanking_RegDate] ON [dbo].[Event_ClanPointRanking]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table Friend : 
--

CREATE TABLE [dbo].[Friend] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [CID] int NOT NULL,
  [FriendCID] int NOT NULL,
  [Type] int NOT NULL,
  [Favorite] tinyint NULL,
  [DeleteFlag] tinyint NULL,
  CONSTRAINT [Friend_PK] PRIMARY KEY CLUSTERED ([id]),
  CONSTRAINT [Character_Friend_FK1] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Character_Friend_FK2] FOREIGN KEY ([FriendCID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Friend_CID_FriendCID] ON [dbo].[Friend]
  ([CID], [FriendCID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table GambleItem : 
--

CREATE TABLE [dbo].[GambleItem] (
  [GIID] int NOT NULL,
  [Name] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Description] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Price] int NOT NULL,
  [RegDate] datetime CONSTRAINT [DF__GambleIte__RegDa__2665ABE1] DEFAULT getdate() NOT NULL,
  [StartDate] datetime CONSTRAINT [DF__GambleIte__Start__2759D01A] DEFAULT 0 NOT NULL,
  [LifeTimeHour] smallint CONSTRAINT [DF__GambleIte__LifeT__284DF453] DEFAULT 0 NOT NULL,
  [IsCash] tinyint CONSTRAINT [DF__GambleIte__IsCas__2942188C] DEFAULT 0 NOT NULL,
  [Opened] tinyint CONSTRAINT [DF__GambleIte__Opene__2A363CC5] DEFAULT 0 NOT NULL,
  PRIMARY KEY CLUSTERED ([GIID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IDX_GambleItem_Name] ON [dbo].[GambleItem]
  ([Name])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table GambleRewardItem : 
--

CREATE TABLE [dbo].[GambleRewardItem] (
  [GRIID] int IDENTITY(1, 1) NOT NULL,
  [GIID] int NOT NULL,
  [ItemIDMale] int NOT NULL,
  [ItemIDFemale] int NOT NULL,
  [RentHourPeriod] int CONSTRAINT [DF__GambleRew__RentH__2D12A970] DEFAULT 0 NOT NULL,
  [RatePerThousand] smallint NOT NULL,
  PRIMARY KEY CLUSTERED ([GRIID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IDX_GambleRewardItem_GIID] ON [dbo].[GambleRewardItem]
  ([GIID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IDX_GambleRewardItem_ItemIDFemale] ON [dbo].[GambleRewardItem]
  ([ItemIDFemale])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IDX_GambleRewardItem_ItemIDMale] ON [dbo].[GambleRewardItem]
  ([ItemIDMale])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table GameLog : 
--

CREATE TABLE [dbo].[GameLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [GameName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [MasterCID] int NULL,
  [Map] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [GameType] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Round] int NULL,
  [StartTime] datetime NOT NULL,
  [PlayerCount] tinyint NULL,
  [Players] varchar(1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_GameLOg_StartTime] ON [dbo].[GameLog]
  ([StartTime])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table GameType : 
--

CREATE TABLE [dbo].[GameType] (
  [GameTypeID] int NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [GameType_PK] PRIMARY KEY CLUSTERED ([GameTypeID])
)
ON [PRIMARY]
GO

--
-- Definition for table GiftLog : 
--

CREATE TABLE [dbo].[GiftLog] (
  [From] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [to] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Coins] int NULL,
  [Date] datetime NULL,
  [ID] int IDENTITY(1, 1) NOT NULL
)
ON [PRIMARY]
GO

--
-- Definition for table GMLog : 
--

CREATE TABLE [dbo].[GMLog] (
  [LogID] int IDENTITY(1, 1) NOT NULL,
  [Date] datetime NULL,
  [IP] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [AID] int NULL,
  [UserID] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [type] int NULL,
  [info] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [PK_GMLog] PRIMARY KEY CLUSTERED ([LogID])
)
ON [PRIMARY]
GO

--
-- Definition for table IndexContent : 
--

CREATE TABLE [dbo].[IndexContent] (
  [ICID] int IDENTITY(1, 1) NOT NULL,
  [Type] tinyint NULL,
  [Title] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [User] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Date] datetime NULL,
  [Text] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

--
-- Definition for table IPtoCountry : 
--

CREATE TABLE [dbo].[IPtoCountry] (
  [IPFrom] varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [IPTo] varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CountryCode2] varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CountryCode3] varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [CountryName] varchar(8000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_IPtoCountryCode_IPRange_060612] ON [dbo].[IPtoCountry]
  ([IPFrom], [IPTo], [CountryCode3])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table IPtoCountryOld060612 : 
--

CREATE TABLE [dbo].[IPtoCountryOld060612] (
  [IPFrom] numeric(18, 0) NOT NULL,
  [IPTo] numeric(18, 0) NOT NULL,
  [CountryCode2] char(2) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [CountryName] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  CONSTRAINT [PK_IPtoCountry_IPRange] PRIMARY KEY CLUSTERED ([IPFrom], [IPTo])
)
ON [PRIMARY]
GO

--
-- Definition for table Item : 
--

CREATE TABLE [dbo].[Item] (
  [ItemID] int NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [TotalPoint] int NULL,
  [ResSex] tinyint NULL,
  [ResRace] tinyint NULL,
  [ResLevel] int NULL,
  [Slot] tinyint NULL,
  [Weight] int NULL,
  [BountyPrice] int NULL,
  [Damage] int NULL,
  [Delay] int NULL,
  [EffectID] int NULL,
  [Controllability] int NULL,
  [Magazine] int NULL,
  [ReloadTime] int NULL,
  [SlugOutput] tinyint NULL,
  [Gadget] int NULL,
  [HP] int NULL,
  [AP] int NULL,
  [MAXWT] int NULL,
  [SF] int NULL,
  [FR] int NULL,
  [CR] int NULL,
  [PR] int NULL,
  [LR] int NULL,
  [BlendColor] int NULL,
  [ModelName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Description] varchar(1024) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [MaxBullet] int NULL,
  [LimitSpeed] tinyint NULL,
  [IsCashItem] tinyint NULL,
  CONSTRAINT [Item_PK] PRIMARY KEY CLUSTERED ([ItemID]),
  CONSTRAINT [Effect_Item_FK1] FOREIGN KEY ([EffectID]) 
  REFERENCES [dbo].[Effect] ([ID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Item_Name] ON [dbo].[Item]
  ([Name])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Item_ResLevel] ON [dbo].[Item]
  ([ResLevel])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Item_ResSex] ON [dbo].[Item]
  ([ResSex])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Item_Slot] ON [dbo].[Item]
  ([Slot])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ItemPurchaseLogByBounty : 
--

CREATE TABLE [dbo].[ItemPurchaseLogByBounty] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [ItemID] int NOT NULL,
  [CID] int NULL,
  [Date] datetime NULL,
  [Bounty] int NULL,
  [CharBounty] int NULL,
  [Type] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [Character_PurchaseItemByBountyHistory_FK20050314] FOREIGN KEY ([CID]) 
  REFERENCES [dbo].[Character] ([CID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ItemPurchaseLogByBounty_CID] ON [dbo].[ItemPurchaseLogByBounty]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_ItemPurchaseLogByBounty_Date] ON [dbo].[ItemPurchaseLogByBounty]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ItemPurhcaseLogByBountry_Date] ON [dbo].[ItemPurchaseLogByBounty]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ItemPurchaseLogByCash : 
--

CREATE TABLE [dbo].[ItemPurchaseLogByCash] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NULL,
  [ItemID] int NOT NULL,
  [Date] datetime NOT NULL,
  [Cash] int NULL,
  [RentHourPeriod] int NULL,
  [MobileCode] char(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [Account_PurchaseLogByCash_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [Item_PurchaseLogByCash_FK1] FOREIGN KEY ([ItemID]) 
  REFERENCES [dbo].[Item] ([ItemID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ItemPurchaseLogByCash_AID] ON [dbo].[ItemPurchaseLogByCash]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_ItemPurchaseLogByCash_Date] ON [dbo].[ItemPurchaseLogByCash]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ItemSlotType : 
--

CREATE TABLE [dbo].[ItemSlotType] (
  [SlotType] int NOT NULL,
  [Description] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Category] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  PRIMARY KEY CLUSTERED ([SlotType])
)
ON [PRIMARY]
GO

--
-- Definition for table KillLog : 
--

CREATE TABLE [dbo].[KillLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AttackerCID] int NULL,
  [VictimCID] int NULL,
  [Time] datetime NULL,
  CONSTRAINT [KillLog_PK] PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

--
-- Definition for table Level : 
--

CREATE TABLE [dbo].[Level] (
  [Level] smallint NOT NULL,
  [MinXP] int NULL,
  PRIMARY KEY CLUSTERED ([Level])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Level_MinXP] ON [dbo].[Level]
  ([MinXP])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table LevelUpLog : 
--

CREATE TABLE [dbo].[LevelUpLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [CID] int NULL,
  [Level] smallint NULL,
  [BP] int NULL,
  [KillCount] int NULL,
  [DeathCount] int NULL,
  [PlayTime] int NULL,
  [Date] datetime NULL,
  CONSTRAINT [LevelUpLog_PK_20050310] PRIMARY KEY NONCLUSTERED ([id])
)
ON [PRIMARY]
GO

--
-- Definition for table LocatorCountryStatistics : 
--

CREATE TABLE [dbo].[LocatorCountryStatistics] (
  [LocatorID] int NULL,
  [CountryCode3] char(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Count] int NULL,
  [RegDate] smalldatetime NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LocatorCountryStatistics_CountryCode3] ON [dbo].[LocatorCountryStatistics]
  ([CountryCode3])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LocatorCountryStatistics_RegDate] ON [dbo].[LocatorCountryStatistics]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table LocatorLog : 
--

CREATE TABLE [dbo].[LocatorLog] (
  [LocatorID] int NULL,
  [CountryCode3] varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Count] int NULL,
  [RegDate] smalldatetime NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LocatorLog_CountryCode3] ON [dbo].[LocatorLog]
  ([CountryCode3])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LocatorLog_RegDate] ON [dbo].[LocatorLog]
  ([RegDate])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table LocatorStatus : 
--

CREATE TABLE [dbo].[LocatorStatus] (
  [LocatorID] int NOT NULL,
  [IP] varchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Port] int NOT NULL,
  [RecvCount] int NULL,
  [SendCount] int NULL,
  [BlockCount] int NULL,
  [DuplicatedCount] int NULL,
  [UpdateElapsedTime] int NOT NULL,
  [LastUpdatedTime] datetime NULL,
  PRIMARY KEY CLUSTERED ([LocatorID]),
  UNIQUE ([IP])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_LocatorStatus_IP] ON [dbo].[LocatorStatus]
  ([IP])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table Login : 
--

CREATE TABLE [dbo].[Login] (
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [AID] int NOT NULL,
  [Password] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LastConnDate] datetime NULL,
  [LastIP] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [euCoins] int NULL,
  CONSTRAINT [Login_PK] PRIMARY KEY CLUSTERED ([UserID])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_Login_AID] ON [dbo].[Login]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table Map : 
--

CREATE TABLE [dbo].[Map] (
  [MapID] int NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [MaxPlayer] int NOT NULL,
  CONSTRAINT [Map_PK] PRIMARY KEY CLUSTERED ([MapID])
)
ON [PRIMARY]
GO

--
-- Definition for table Mobile : 
--

CREATE TABLE [dbo].[Mobile] (
  [MID] int IDENTITY(1, 1) NOT NULL,
  [AID] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Name] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Mobile] varchar(max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [done] int CONSTRAINT [DF_Mobile_done] DEFAULT 0 NOT NULL
)
ON [PRIMARY]
GO

--
-- Definition for table PenaltyLog : 
--

CREATE TABLE [dbo].[PenaltyLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NOT NULL,
  [UGradeID] int NOT NULL,
  [Date] datetime NOT NULL,
  CONSTRAINT [PenaltyLog_PK] PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_PenaltyLog_AID] ON [dbo].[PenaltyLog]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_PenaltyLog_Date] ON [dbo].[PenaltyLog]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table PersonalinfoGunz : 
--

CREATE TABLE [dbo].[PersonalinfoGunz] (
  [AID] int NOT NULL,
  [birthday] smalldatetime NULL,
  [city] nvarchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [state] char(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [connecType] nvarchar(30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [phone] varchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [speed] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [msgLU] bit NULL,
  [statusLUA] bit CONSTRAINT [DF_PersonalinfoGunz_statusLUA] DEFAULT 1 NOT NULL,
  CONSTRAINT [PK_PersonalinfoGunz] PRIMARY KEY CLUSTERED ([AID])
)
ON [PRIMARY]
GO

--
-- Definition for table pf20080522 : 
--

CREATE TABLE [dbo].[pf20080522] (
  [RowNumber] int IDENTITY(1, 1) NOT NULL,
  [EventClass] int NULL,
  [TextData] ntext COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LoginName] nvarchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [SPID] int NULL,
  [Duration] bigint NULL,
  [StartTime] datetime NULL,
  [EndTime] datetime NULL,
  [Reads] bigint NULL,
  [CPU] int NULL,
  PRIMARY KEY CLUSTERED ([RowNumber])
)
ON [PRIMARY]
TEXTIMAGE_ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_pf20080522_duration] ON [dbo].[pf20080522]
  ([Duration])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_pf20080522_loginname] ON [dbo].[pf20080522]
  ([LoginName])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [ix_pf20080522_reads] ON [dbo].[pf20080522]
  ([Reads])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table PlayerLog : 
--

CREATE TABLE [dbo].[PlayerLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [CID] int NULL,
  [DisTime] datetime NULL,
  [PlayTime] int NULL,
  [Kills] int NULL,
  [Deaths] int NULL,
  [XP] int NULL,
  [TotalXP] int NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_PlayerLog_DisTime] ON [dbo].[PlayerLog]
  ([DisTime])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_PlyaerLog_CID] ON [dbo].[PlayerLog]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table PremiumGrade : 
--

CREATE TABLE [dbo].[PremiumGrade] (
  [PGradeID] int NOT NULL,
  [Name] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  CONSTRAINT [PremiumGrade_PK] PRIMARY KEY CLUSTERED ([PGradeID])
)
ON [PRIMARY]
GO

--
-- Definition for table PurchaseMethod : 
--

CREATE TABLE [dbo].[PurchaseMethod] (
  [PurchaseMethodID] int NOT NULL,
  [Name] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [PurchaseMethod_PK] PRIMARY KEY CLUSTERED ([PurchaseMethodID])
)
ON [PRIMARY]
GO

--
-- Definition for table QuestGameLog : 
--

CREATE TABLE [dbo].[QuestGameLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [GameName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Master] int NOT NULL,
  [Player1] int NULL,
  [Player2] int NULL,
  [Player3] int NULL,
  [TotalQItemCount] tinyint NULL,
  [ScenarioID] smallint NOT NULL,
  [StartTime] smalldatetime NOT NULL,
  [EndTime] smalldatetime NOT NULL,
  PRIMARY KEY NONCLUSTERED ([id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_QuestGameLog_EndTime] ON [dbo].[QuestGameLog]
  ([EndTime])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_QuestGameLog_StartTime] ON [dbo].[QuestGameLog]
  ([StartTime])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table QuestItem : 
--

CREATE TABLE [dbo].[QuestItem] (
  [QIID] int NOT NULL,
  [Name] char(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Level] tinyint NULL,
  [Description] varchar(200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Price] int NULL,
  [UniqueItem] bit NOT NULL,
  [Sacrifice] bit NOT NULL,
  [Type] char(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Param] int NULL,
  PRIMARY KEY CLUSTERED ([QIID])
)
ON [PRIMARY]
GO

--
-- Definition for table QUniqueItemLog : 
--

CREATE TABLE [dbo].[QUniqueItemLog] (
  [QUILID] int IDENTITY(1, 1) NOT NULL,
  [QGLID] int NULL,
  [CID] int NOT NULL,
  [QIID] int NOT NULL,
  PRIMARY KEY NONCLUSTERED ([QUILID])
)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_QUniqueItemLog_CID] ON [dbo].[QUniqueItemLog]
  ([CID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_QUniqueItemLog_QGLID] ON [dbo].[QUniqueItemLog]
  ([QGLID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_QUniqueItemLog_QIID] ON [dbo].[QUniqueItemLog]
  ([QIID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table RentCashSetShopPrice : 
--

CREATE TABLE [dbo].[RentCashSetShopPrice] (
  [RCSSPID] int IDENTITY(1, 1) NOT NULL,
  [CSSID] int NULL,
  [RentHourPeriod] smallint NULL,
  [CashPrice] int NULL,
  CONSTRAINT [PK__RentCashSetShopP__0D7A0286] PRIMARY KEY CLUSTERED ([RCSSPID]),
  CONSTRAINT [FK__RentCashS__CSSID__65C116E7] FOREIGN KEY ([CSSID]) 
  REFERENCES [dbo].[CashSetShop] ([CSSID]) 
  ON UPDATE CASCADE
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RentCashSetShopPrice_CSSID] ON [dbo].[RentCashSetShopPrice]
  ([CSSID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table RentCashShopPrice : 
--

CREATE TABLE [dbo].[RentCashShopPrice] (
  [RCSPID] int IDENTITY(1, 1) NOT NULL,
  [CSID] int NULL,
  [RentHourPeriod] smallint NULL,
  [CashPrice] int NULL,
  CONSTRAINT [PK__RentCashShopPric__2CF2ADDF] PRIMARY KEY CLUSTERED ([RCSPID]),
  CONSTRAINT [FK__RentCashSh__CSID__7CA47C3F] FOREIGN KEY ([CSID]) 
  REFERENCES [dbo].[CashShop] ([CSID]) 
  ON UPDATE CASCADE
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_RentCashShopPrice_CSID] ON [dbo].[RentCashShopPrice]
  ([CSID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table RentPeriodDay : 
--

CREATE TABLE [dbo].[RentPeriodDay] (
  [Day] int NOT NULL,
  [Hour] int NOT NULL,
  PRIMARY KEY CLUSTERED ([Day]),
  UNIQUE ([Hour])
)
ON [PRIMARY]
GO

--
-- Definition for table RentType : 
--

CREATE TABLE [dbo].[RentType] (
  [TypeID] int NOT NULL,
  [Description] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  PRIMARY KEY CLUSTERED ([TypeID])
)
ON [PRIMARY]
GO

--
-- Definition for table ServerLog : 
--

CREATE TABLE [dbo].[ServerLog] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [ServerID] smallint NULL,
  [PlayerCount] smallint NULL,
  [GameCount] smallint NULL,
  [Time] smalldatetime NULL,
  [BlockCount] int NULL,
  [NonBlockCount] int NULL
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_ServerLog_ID_Time] ON [dbo].[ServerLog]
  ([ServerID], [Time])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_ServerLog_Time] ON [dbo].[ServerLog]
  ([Time])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table ServerLogStorage : 
--

CREATE TABLE [dbo].[ServerLogStorage] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [ServerID] smallint NOT NULL,
  [PlayerCount] int NOT NULL,
  [GameCount] int NOT NULL,
  [BlockCount] int NOT NULL,
  [NonBlockCount] int NOT NULL,
  [Time] smalldatetime NOT NULL,
  PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

--
-- Definition for table ServerStatus : 
--

CREATE TABLE [dbo].[ServerStatus] (
  [ServerID] int NOT NULL,
  [CurrPlayer] smallint NULL,
  [MaxPlayer] smallint NULL,
  [Time] datetime NULL,
  [IP] varchar(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Port] int NULL,
  [ServerName] varchar(64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Opened] tinyint NULL,
  [Type] int NULL,
  CONSTRAINT [ServerStatus_PK] PRIMARY KEY CLUSTERED ([ServerID])
)
ON [PRIMARY]
GO

--
-- Definition for table ServerType : 
--

CREATE TABLE [dbo].[ServerType] (
  [Type] int NOT NULL,
  [Description] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  PRIMARY KEY CLUSTERED ([Type])
)
ON [PRIMARY]
GO

--
-- Definition for table SessionHash : 
--

CREATE TABLE [dbo].[SessionHash] (
  [HashString] int NULL,
  [IP] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Used] tinyint NULL,
  [User] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
)
ON [PRIMARY]
GO

--
-- Definition for table SetItemPurchaseLogByCash : 
--

CREATE TABLE [dbo].[SetItemPurchaseLogByCash] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [AID] int NULL,
  [CSSID] int NULL,
  [Date] datetime NOT NULL,
  [Cash] int NULL,
  [RentHourPeriod] int NULL,
  [MobileCode] char(16) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  CONSTRAINT [Account_SetItemPurchaseLogByCash_FK1] FOREIGN KEY ([AID]) 
  REFERENCES [dbo].[Account] ([AID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION,
  CONSTRAINT [CashSetShop_SetItemPurchaseLogByCash_FK1] FOREIGN KEY ([CSSID]) 
  REFERENCES [dbo].[CashSetShop] ([CSSID]) 
  ON UPDATE NO ACTION
  ON DELETE NO ACTION
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_SetItemPurchaseLogByCash_AID] ON [dbo].[SetItemPurchaseLogByCash]
  ([AID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE CLUSTERED INDEX [IX_SetItemPurchaseLogByCash_Date] ON [dbo].[SetItemPurchaseLogByCash]
  ([Date])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table sjr_TableSizeIncr : 
--

CREATE TABLE [dbo].[sjr_TableSizeIncr] (
  [name] varchar(40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [rows] int NULL,
  [reserved] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [date] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [index_size] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [unused] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [rd] datetime CONSTRAINT [DF__sjr_TableSiz__rd__1229A90A] DEFAULT getdate() NULL
)
ON [PRIMARY]
GO

--
-- Definition for table TESTE : 
--

CREATE TABLE [dbo].[TESTE] (
  [AID] int IDENTITY(1, 1) NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [UGradeID] int NOT NULL,
  [PGradeID] int NOT NULL,
  [RegDate] datetime NOT NULL,
  [Name] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Email] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [RegNum] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Age] smallint NULL,
  [Sex] tinyint NULL,
  [ZipCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Address] varchar(256) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Country] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [LastCID] int NULL,
  [Cert] tinyint NULL
)
ON [PRIMARY]
GO

--
-- Definition for table TotalRanking : 
--

CREATE TABLE [dbo].[TotalRanking] (
  [Rank] int IDENTITY(1, 1) NOT NULL,
  [UserID] varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
  [Name] varchar(24) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  [Level] smallint NOT NULL,
  [XP] int NULL,
  [KillCount] int NULL,
  [DeathCount] int NULL,
  CONSTRAINT [PK_TotalRanking_Rank] PRIMARY KEY CLUSTERED ([Rank])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_TotalRanking_Name] ON [dbo].[TotalRanking]
  ([Name])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_TotalRanking_UserID] ON [dbo].[TotalRanking]
  ([UserID])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for table UserGrade : 
--

CREATE TABLE [dbo].[UserGrade] (
  [UGradeID] int NOT NULL,
  [Name] varchar(128) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
  CONSTRAINT [UserGrade_PK] PRIMARY KEY CLUSTERED ([UGradeID])
)
ON [PRIMARY]
GO

--
-- Definition for table UV : 
--

CREATE TABLE [dbo].[UV] (
  [id] int IDENTITY(1, 1) NOT NULL,
  [Time] smalldatetime NOT NULL,
  [Count] int NOT NULL,
  PRIMARY KEY CLUSTERED ([id])
)
ON [PRIMARY]
GO

CREATE NONCLUSTERED INDEX [IX_UV_Time] ON [dbo].[UV]
  ([Time])
WITH (
  PAD_INDEX = OFF,
  DROP_EXISTING = OFF,
  STATISTICS_NORECOMPUTE = OFF,
  SORT_IN_TEMPDB = OFF,
  ONLINE = OFF,
  ALLOW_ROW_LOCKS = ON,
  ALLOW_PAGE_LOCKS = ON)
ON [PRIMARY]
GO

--
-- Definition for user-defined function fnGetMax : 
--
GO
/* ??? ??? ?? */
CREATE  FUNCTION [dbo].[fnGetMax]
	(@n1 int, 
	 @n2 int)
RETURNS int
AS
BEGIN
RETURN (CASE WHEN @n1 > @n2 THEN @n1 ELSE @n2 END)
END
GO

--
-- Definition for user-defined function fnGetMin : 
--
GO
/* ??? ??? ?? */
CREATE  FUNCTION [dbo].[fnGetMin]
	(@n1 int, 
	 @n2 int)
RETURNS int
AS
BEGIN
RETURN (CASE WHEN @n1 < @n2 THEN @n1 ELSE @n2 END)
END
GO

--
-- Definition for user-defined function inet_aton : 
--
GO
CREATE FUNCTION [dbo].[inet_aton] (@IP VARCHAR(15))
RETURNS BIGINT
AS
BEGIN
	DECLARE @A BIGINT, @B BIGINT, @C BIGINT, @D BIGINT
	DECLARE @iBegin INT, @iEnd INT
	
	SELECT @iBegin=1
	SELECT @iEnd=CHARINDEX('.', @IP)
	SELECT @A=CAST(SUBSTRING(@IP, @iBegin, @iEnd-@iBegin) AS BIGINT)
	
	SELECT @iBegin=@iEnd+1
	SELECT @iEnd=CHARINDEX('.', @IP, @iBegin)
	SELECT @B=CAST(SUBSTRING(@IP, @iBegin, @iEnd-@iBegin) AS BIGINT)
	
	SELECT @iBegin=@iEnd+1
	SELECT @iEnd=CHARINDEX('.', @IP, @iBegin)
	SELECT @C=CAST(SUBSTRING(@IP, @iBegin, @iEnd-@iBegin) AS BIGINT)
	
	SELECT @iBegin=@iEnd+1
	SELECT @iEnd=CHARINDEX('.', @IP, @iBegin)
	SELECT @D=CAST(SUBSTRING(@IP, @iBegin, 15) AS BIGINT)
	
	DECLARE @IPNumber BIGINT
	SELECT @IPNumber=@A*16777216+@B*65536+@C*256+@D
	
	RETURN @IPNumber
END
GO

--
-- Definition for user-defined function inet_ntoa : 
--
GO
CREATE  FUNCTION [dbo].[inet_ntoa] (@IP bigint)
 RETURNS varchar(15)
AS
BEGIN
 DECLARE @NumIP bigint
 DECLARE @a int
 DECLARE @b int
 DECLARE @c int
 DECLARE @d int

 SET @NumIP = @IP

 SET @a = @NumIP / 16777216
 SET @NumIP = @NumIP % 16777216

 SET @b = @NumIP / 65536
 SET @NumIP = @NumIP % 65536

 SET @c = @NumIP / 256
 SET @NumIP = @NumIP % 256

 SET @d = @NumIP

 RETURN CAST(@a AS varchar(3)) + '.' + CAST(@b AS varchar(3)) + '.' +
  CAST(@c AS varchar(3)) + '.' + CAST(@d AS varchar(3))
END
GO

--
-- Definition for view viewCashItemPresentLog : 
--
GO
CREATE VIEW [dbo].[viewCashItemPresentLog]
AS

SELECT cpl.id AS id, cpl.SenderUserID AS SenderUserID, a.UserID AS ReceiverUserID, 
i.Name AS ItemName, cpl.Date AS Date FROM CashItemPresentLog cpl, Account a(nolock), CashShop cs(nolock), Item i(nolock)
WHERE cpl.ReceiverAID=a.AID AND cpl.CSID IS Not NULL AND cpl.csid=cs.csid AND cs.ItemID=i.ItemID
GO

--------------------

CREATE   VIEW [dbo].[viewCashSetItemPresentLog] -- M
AS

SELECT cpl.id AS id, cpl.SenderUserID AS SenderUserID, a.UserID AS ReceiverUserID, 
css.Name AS SetItemName, cpl.Date AS Date, MobileCode
FROM CashItemPresentLog cpl, Account a(nolock), CashSetShop css(nolock)
WHERE cpl.ReceiverAID=a.AID AND cpl.CSSID IS Not NULL AND cpl.cssid=css.cssid
GO

-----------------------

CREATE VIEW [dbo].[viewEventGetCharacterLevel]
AS

SELECT a.userid AS userid, c.name AS chr_name, c.level AS chr_level FROM Account a(nolock), Character c(nolock)
WHERE 
a.aid=c.aid AND c.DeleteFlag=0
GO

----------------------------

CREATE  VIEW [dbo].[viewHonorRankGunzClan]
AS

SELECT chr.CLID, chr.ClanName, chr.Point, chr.Wins, chr.Losses, c.EmblemUrl, chr.Ranking, chr.RankIncrease, chr.Year, chr.Month
FROM ClanHonorRanking chr(nolock), Clan c(nolock)
WHERE chr.CLID=c.CLID
GO

--
-- Definition for view viewItem : 
--
GO
CREATE VIEW [dbo].[viewItem]
AS
SELECT	  itm.*, CASE WHEN itm.slot = 1 THEN 1 WHEN itm.slot = 2 THEN 2 WHEN itm.slot BETWEEN 4 AND 8 THEN 3 WHEN itm.slot = 3 OR
							 itm.slot = 9 THEN 4 ELSE 0 END AS SlotEx
FROM			dbo.Item itm
GO

-----------------------------

CREATE   VIEW [dbo].[viewItemPurchaseLogByCash]  -- M
AS
SELECT ipl.id AS id, a.UserID AS UserID, i.Name AS ItemName, ipl.Date AS Date, ipl.Cash AS Cash, ipl.MobileCode
FROM ItemPurchaseLogByCash ipl, Account a, Item i
WHERE ipl.AID = a.AID AND ipl.ItemID=i.ItemID
GO

-------------------------------

CREATE  VIEW [dbo].[viewRankGunzClan]
AS

SELECT CLID, Name as ClanName, Point, Wins, Losses, EmblemUrl, Ranking, RankIncrease
FROM Clan(nolock)
WHERE DeleteFlag=0 and Ranking>0
GO

---------------------------------

CREATE   VIEW [dbo].[viewSetItemPurchaseLogByCash] -- M
AS
SELECT id, a.UserID AS UserID, css.Name AS SetItemName, sipl.Date AS Date, sipl.Cash, MobileCode
FROM SetItemPurchaseLogByCash sipl, Account a, CashSetShop css
WHERE sipl.AID = a.AID AND css.cssid = sipl.cssid
GO

--
-- Definition for stored procedure CREDIT_TD_GAMEITEM : 
--
GO
CREATE PROCEDURE [dbo].[CREDIT_TD_GAMEITEM] 

    @USERID AS VARCHAR(20),
    @ITEMNAME AS VARCHAR(256),
    @RENTHOURPERIOD AS INT

AS

BEGIN

    DECLARE @ITEMID AS INT, @AID AS INT, @SQL VARCHAR(4000)
        
    IF NOT EXISTS
    (
     SELECT *
     FROM dbo.ACCOUNT 
     WHERE USERID = @USERID
    )
    BEGIN 
        RAISERROR 50000 'The user account especified does not exist.'  
        RETURN
    END

    IF NOT EXISTS
    (
     SELECT *
     FROM dbo.ITEM 
     WHERE NAME = @ITEMNAME
    )
    BEGIN 
        RAISERROR 50000 'The item name especified does not exist.'  
        RETURN
    END

    IF NOT @RENTHOURPERIOD BETWEEN -1 AND 720
    BEGIN 
        RAISERROR 50000 'The item period need to be between -1 and 720.'  
        RETURN
    END

    SELECT @ITEMID = ITM.ITEMID,
           @AID = ACC.AID
    FROM dbo.ITEM ITM, dbo.ACCOUNT ACC
    WHERE ITM.[NAME] = @ITEMNAME
    AND   ACC.USERID = @USERID 

    IF @RENTHOURPERIOD BETWEEN 0 AND 720
    BEGIN

        SET @SQL = '
                    INSERT INTO dbo.ACCOUNTITEM(AID, ITEMID, RENTDATE, RENTHOURPERIOD)
                    VALUES('+CAST(@AID AS VARCHAR)+','+CAST(@ITEMID AS VARCHAR)+', GETDATE(),'+ CAST(@RENTHOURPERIOD AS VARCHAR)+')'
    END
    ELSE
    IF @RENTHOURPERIOD =-1
    BEGIN

        SET @SQL = '
                    INSERT INTO dbo.ACCOUNTITEM(AID, ITEMID, RENTDATE, RENTHOURPERIOD)
                    VALUES('+CAST(@AID AS VARCHAR)+','+CAST(@ITEMID AS VARCHAR)+', GETDATE(), NULL)'

    END
               

    EXEC(@SQL)

END
GO

--
-- Definition for stored procedure dt_addtosourcecontrol : 
--
GO
create proc [dbo].[dt_addtosourcecontrol]
    @vchSourceSafeINI varchar(255) = '',
    @vchProjectName   varchar(255) ='',
    @vchComment       varchar(255) ='',
    @vchLoginName     varchar(255) ='',
    @vchPassword      varchar(255) =''

as

set nocount on

declare @iReturn int
declare @iObjectId int
select @iObjectId = 0

declare @iStreamObjectId int
select @iStreamObjectId = 0

declare @VSSGUID varchar(100)
select @VSSGUID = 'SQLVersionControl.VCS_SQL'

declare @vchDatabaseName varchar(255)
select @vchDatabaseName = db_name()

declare @iReturnValue int
select @iReturnValue = 0

declare @iPropertyObjectId int
declare @vchParentId varchar(255)

declare @iObjectCount int
select @iObjectCount = 0

    exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
    if @iReturn <> 0 GOTO E_OAError


    /* Create Project in SS */
    exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
											'AddProjectToSourceSafe',
											NULL,
											@vchSourceSafeINI,
											@vchProjectName output,
											@@SERVERNAME,
											@vchDatabaseName,
											@vchLoginName,
											@vchPassword,
											@vchComment


    if @iReturn <> 0 GOTO E_OAError

    /* Set Database Properties */

    begin tran SetProperties

    /* add high level object */

    exec @iPropertyObjectId = dbo.dt_adduserobject_vcs 'VCSProjectID'

    select @vchParentId = CONVERT(varchar(255),@iPropertyObjectId)

    exec dbo.dt_setpropertybyid @iPropertyObjectId, 'VCSProjectID', @vchParentId , NULL
    exec dbo.dt_setpropertybyid @iPropertyObjectId, 'VCSProject' , @vchProjectName , NULL
    exec dbo.dt_setpropertybyid @iPropertyObjectId, 'VCSSourceSafeINI' , @vchSourceSafeINI , NULL
    exec dbo.dt_setpropertybyid @iPropertyObjectId, 'VCSSQLServer', @@SERVERNAME, NULL
    exec dbo.dt_setpropertybyid @iPropertyObjectId, 'VCSSQLDatabase', @vchDatabaseName, NULL

    if @@error <> 0 GOTO E_General_Error

    commit tran SetProperties
    
    select @iObjectCount = 0;

CleanUp:
    select @vchProjectName
    select @iObjectCount
    return

E_General_Error:
    /* this is an all or nothing.  No specific error messages */
    goto CleanUp

E_OAError:
    exec dbo.dt_displayoaerror @iObjectId, @iReturn
    goto CleanUp
GO

--
-- Definition for stored procedure dt_addtosourcecontrol_u : 
--
GO
create proc [dbo].[dt_addtosourcecontrol_u]
    @vchSourceSafeINI nvarchar(255) = '',
    @vchProjectName   nvarchar(255) ='',
    @vchComment       nvarchar(255) ='',
    @vchLoginName     nvarchar(255) ='',
    @vchPassword      nvarchar(255) =''

as
	-- This procedure should no longer be called;  dt_addtosourcecontrol should be called instead.
	-- Calls are forwarded to dt_addtosourcecontrol to maintain backward compatibility
	set nocount on
	exec dbo.dt_addtosourcecontrol 
		@vchSourceSafeINI, 
		@vchProjectName, 
		@vchComment, 
		@vchLoginName, 
		@vchPassword
GO

--
-- Definition for stored procedure dt_adduserobject : 
--
GO
/*
**	Add an object to the dtproperties table
*/
create procedure [dbo].[dt_adduserobject]
as
	set nocount on
	/*
	** Create the user object if it does not exist already
	*/
	begin transaction
		insert dbo.dtproperties (property) VALUES ('DtgSchemaOBJECT')
		update dbo.dtproperties set objectid=@@identity 
			where id=@@identity and property='DtgSchemaOBJECT'
	commit
	return @@identity
GO

--
-- Definition for stored procedure dt_adduserobject_vcs : 
--
GO
create procedure [dbo].[dt_adduserobject_vcs]
    @vchProperty varchar(64)

as

set nocount on

declare @iReturn int
    /*
    ** Create the user object if it does not exist already
    */
    begin transaction
        select @iReturn = objectid from dbo.dtproperties where property = @vchProperty
        if @iReturn IS NULL
        begin
            insert dbo.dtproperties (property) VALUES (@vchProperty)
            update dbo.dtproperties set objectid=@@identity
                    where id=@@identity and property=@vchProperty
            select @iReturn = @@identity
        end
    commit
    return @iReturn
GO

--
-- Definition for stored procedure dt_getpropertiesbyid_vcs : 
--
GO
create procedure [dbo].[dt_getpropertiesbyid_vcs]
    @id       int,
    @property varchar(64),
    @value    varchar(255) = NULL OUT

as

    set nocount on

    select @value = (
        select value
                from dbo.dtproperties
                where @id=objectid and @property=property
                )
GO

--
-- Definition for stored procedure dt_displayoaerror : 
--
GO
CREATE PROCEDURE [dbo].[dt_displayoaerror]
    @iObject int,
    @iresult int
as

set nocount on

declare @vchOutput      varchar(255)
declare @hr             int
declare @vchSource      varchar(255)
declare @vchDescription varchar(255)

    exec @hr = master.dbo.sp_OAGetErrorInfo @iObject, @vchSource OUT, @vchDescription OUT

    select @vchOutput = @vchSource + ': ' + @vchDescription
    raiserror (@vchOutput,16,-1)

    return
GO

--
-- Definition for stored procedure dt_checkinobject : 
--
GO
create proc [dbo].[dt_checkinobject]
    @chObjectType  char(4),
    @vchObjectName varchar(255),
    @vchComment    varchar(255)='',
    @vchLoginName  varchar(255),
    @vchPassword   varchar(255)='',
    @iVCSFlags     int = 0,
    @iActionFlag   int = 0,   /* 0 => AddFile, 1 => CheckIn */
    @txStream1     Text = '', /* drop stream   */ /* There is a bug that if items are NULL they do not pass to OLE servers */
    @txStream2     Text = '', /* create stream */
    @txStream3     Text = ''  /* grant stream  */


as

	set nocount on

	declare @iReturn int
	declare @iObjectId int
	select @iObjectId = 0
	declare @iStreamObjectId int

	declare @VSSGUID varchar(100)
	select @VSSGUID = 'SQLVersionControl.VCS_SQL'

	declare @iPropertyObjectId int
	select @iPropertyObjectId  = 0

    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchProjectName   varchar(255)
    declare @vchSourceSafeINI varchar(255)
    declare @vchServerName    varchar(255)
    declare @vchDatabaseName  varchar(255)
    declare @iReturnValue	  int
    declare @pos			  int
    declare @vchProcLinePiece varchar(255)

    
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSProject',       @vchProjectName   OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLServer',     @vchServerName    OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLDatabase',   @vchDatabaseName  OUT

    if @chObjectType = 'PROC'
    begin
        if @iActionFlag = 1
        begin
            /* Procedure Can have up to three streams
            Drop Stream, Create Stream, GRANT stream */

            begin tran compile_all

            /* try to compile the streams */
            exec (@txStream1)
            if @@error <> 0 GOTO E_Compile_Fail

            exec (@txStream2)
            if @@error <> 0 GOTO E_Compile_Fail

            exec (@txStream3)
            if @@error <> 0 GOTO E_Compile_Fail
        end

        exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
        if @iReturn <> 0 GOTO E_OAError

        exec @iReturn = master.dbo.sp_OAGetProperty @iObjectId, 'GetStreamObject', @iStreamObjectId OUT
        if @iReturn <> 0 GOTO E_OAError
        
        if @iActionFlag = 1
        begin
            
            declare @iStreamLength int
			
			select @pos=1
			select @iStreamLength = datalength(@txStream2)
			
			if @iStreamLength > 0
			begin
			
				while @pos < @iStreamLength
				begin
						
					select @vchProcLinePiece = substring(@txStream2, @pos, 255)
					
					exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'AddStream', @iReturnValue OUT, @vchProcLinePiece
            		if @iReturn <> 0 GOTO E_OAError
            		
					select @pos = @pos + 255
					
				end
            
				exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
														'CheckIn_StoredProcedure',
														NULL,
														@sProjectName = @vchProjectName,
														@sSourceSafeINI = @vchSourceSafeINI,
														@sServerName = @vchServerName,
														@sDatabaseName = @vchDatabaseName,
														@sObjectName = @vchObjectName,
														@sComment = @vchComment,
														@sLoginName = @vchLoginName,
														@sPassword = @vchPassword,
														@iVCSFlags = @iVCSFlags,
														@iActionFlag = @iActionFlag,
														@sStream = ''
                                        
			end
        end
        else
        begin
        
            select colid, text into #ProcLines
            from syscomments
            where id = object_id(@vchObjectName)
            order by colid

            declare @iCurProcLine int
            declare @iProcLines int
            select @iCurProcLine = 1
            select @iProcLines = (select count(*) from #ProcLines)
            while @iCurProcLine <= @iProcLines
            begin
                select @pos = 1
                declare @iCurLineSize int
                select @iCurLineSize = len((select text from #ProcLines where colid = @iCurProcLine))
                while @pos <= @iCurLineSize
                begin                
                    select @vchProcLinePiece = convert(varchar(255),
                        substring((select text from #ProcLines where colid = @iCurProcLine),
                                  @pos, 255 ))
                    exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'AddStream', @iReturnValue OUT, @vchProcLinePiece
                    if @iReturn <> 0 GOTO E_OAError
                    select @pos = @pos + 255                  
                end
                select @iCurProcLine = @iCurProcLine + 1
            end
            drop table #ProcLines

            exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
													'CheckIn_StoredProcedure',
													NULL,
													@sProjectName = @vchProjectName,
													@sSourceSafeINI = @vchSourceSafeINI,
													@sServerName = @vchServerName,
													@sDatabaseName = @vchDatabaseName,
													@sObjectName = @vchObjectName,
													@sComment = @vchComment,
													@sLoginName = @vchLoginName,
													@sPassword = @vchPassword,
													@iVCSFlags = @iVCSFlags,
													@iActionFlag = @iActionFlag,
													@sStream = ''
        end

        if @iReturn <> 0 GOTO E_OAError

        if @iActionFlag = 1
        begin
            commit tran compile_all
            if @@error <> 0 GOTO E_Compile_Fail
        end

    end

CleanUp:
	return

E_Compile_Fail:
	declare @lerror int
	select @lerror = @@error
	rollback tran compile_all
	RAISERROR (@lerror,16,-1)
	goto CleanUp

E_OAError:
	if @iActionFlag = 1 rollback tran compile_all
	exec dbo.dt_displayoaerror @iObjectId, @iReturn
	goto CleanUp
GO

--
-- Definition for stored procedure dt_checkinobject_u : 
--
GO
create proc [dbo].[dt_checkinobject_u]
    @chObjectType  char(4),
    @vchObjectName nvarchar(255),
    @vchComment    nvarchar(255)='',
    @vchLoginName  nvarchar(255),
    @vchPassword   nvarchar(255)='',
    @iVCSFlags     int = 0,
    @iActionFlag   int = 0,   /* 0 => AddFile, 1 => CheckIn */
    @txStream1     text = '',  /* drop stream   */ /* There is a bug that if items are NULL they do not pass to OLE servers */
    @txStream2     text = '',  /* create stream */
    @txStream3     text = ''   /* grant stream  */

as	
	-- This procedure should no longer be called;  dt_checkinobject should be called instead.
	-- Calls are forwarded to dt_checkinobject to maintain backward compatibility.
	set nocount on
	exec dbo.dt_checkinobject
		@chObjectType,
		@vchObjectName,
		@vchComment,
		@vchLoginName,
		@vchPassword,
		@iVCSFlags,
		@iActionFlag,   
		@txStream1,		
		@txStream2,		
		@txStream3
GO

--
-- Definition for stored procedure dt_checkoutobject : 
--
GO
create proc [dbo].[dt_checkoutobject]
    @chObjectType  char(4),
    @vchObjectName varchar(255),
    @vchComment    varchar(255),
    @vchLoginName  varchar(255),
    @vchPassword   varchar(255),
    @iVCSFlags     int = 0,
    @iActionFlag   int = 0/* 0 => Checkout, 1 => GetLatest, 2 => UndoCheckOut */

as

	set nocount on

	declare @iReturn int
	declare @iObjectId int
	select @iObjectId =0

	declare @VSSGUID varchar(100)
	select @VSSGUID = 'SQLVersionControl.VCS_SQL'

	declare @iReturnValue int
	select @iReturnValue = 0

	declare @vchTempText varchar(255)

	/* this is for our strings */
	declare @iStreamObjectId int
	select @iStreamObjectId = 0

    declare @iPropertyObjectId int
    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchProjectName   varchar(255)
    declare @vchSourceSafeINI varchar(255)
    declare @vchServerName    varchar(255)
    declare @vchDatabaseName  varchar(255)
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSProject',       @vchProjectName   OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLServer',     @vchServerName    OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLDatabase',   @vchDatabaseName  OUT

    if @chObjectType = 'PROC'
    begin
        /* Procedure Can have up to three streams
           Drop Stream, Create Stream, GRANT stream */

        exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT

        if @iReturn <> 0 GOTO E_OAError

        exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
												'CheckOut_StoredProcedure',
												NULL,
												@sProjectName = @vchProjectName,
												@sSourceSafeINI = @vchSourceSafeINI,
												@sObjectName = @vchObjectName,
												@sServerName = @vchServerName,
												@sDatabaseName = @vchDatabaseName,
												@sComment = @vchComment,
												@sLoginName = @vchLoginName,
												@sPassword = @vchPassword,
												@iVCSFlags = @iVCSFlags,
												@iActionFlag = @iActionFlag

        if @iReturn <> 0 GOTO E_OAError


        exec @iReturn = master.dbo.sp_OAGetProperty @iObjectId, 'GetStreamObject', @iStreamObjectId OUT

        if @iReturn <> 0 GOTO E_OAError

        create table #commenttext (id int identity, sourcecode varchar(255))


        select @vchTempText = 'STUB'
        while @vchTempText is not null
        begin
            exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'GetStream', @iReturnValue OUT, @vchTempText OUT
            if @iReturn <> 0 GOTO E_OAError
            
            if (@vchTempText = '') set @vchTempText = null
            if (@vchTempText is not null) insert into #commenttext (sourcecode) select @vchTempText
        end

        select 'VCS'=sourcecode from #commenttext order by id
        select 'SQL'=text from syscomments where id = object_id(@vchObjectName) order by colid

    end

CleanUp:
    return

E_OAError:
    exec dbo.dt_displayoaerror @iObjectId, @iReturn
    GOTO CleanUp
GO

--
-- Definition for stored procedure dt_checkoutobject_u : 
--
GO
create proc [dbo].[dt_checkoutobject_u]
    @chObjectType  char(4),
    @vchObjectName nvarchar(255),
    @vchComment    nvarchar(255),
    @vchLoginName  nvarchar(255),
    @vchPassword   nvarchar(255),
    @iVCSFlags     int = 0,
    @iActionFlag   int = 0/* 0 => Checkout, 1 => GetLatest, 2 => UndoCheckOut */

as

	-- This procedure should no longer be called;  dt_checkoutobject should be called instead.
	-- Calls are forwarded to dt_checkoutobject to maintain backward compatibility.
	set nocount on
	exec dbo.dt_checkoutobject
		@chObjectType,  
		@vchObjectName, 
		@vchComment,    
		@vchLoginName,  
		@vchPassword,  
		@iVCSFlags,    
		@iActionFlag
GO

--
-- Definition for stored procedure dt_displayoaerror_u : 
--
GO
CREATE PROCEDURE [dbo].[dt_displayoaerror_u]
    @iObject int,
    @iresult int
as
	-- This procedure should no longer be called;  dt_displayoaerror should be called instead.
	-- Calls are forwarded to dt_displayoaerror to maintain backward compatibility.
	set nocount on
	exec dbo.dt_displayoaerror
		@iObject,
		@iresult
GO

--
-- Definition for stored procedure dt_droppropertiesbyid : 
--
GO
/*
**	Drop one or all the associated properties of an object or an attribute 
**
**	dt_dropproperties objid, null or '' -- drop all properties of the object itself
**	dt_dropproperties objid, property -- drop the property
*/
create procedure [dbo].[dt_droppropertiesbyid]
	@id int,
	@property varchar(64)
as
	set nocount on

	if (@property is null) or (@property = '')
		delete from dbo.dtproperties where objectid=@id
	else
		delete from dbo.dtproperties 
			where objectid=@id and property=@property
GO

--
-- Definition for stored procedure dt_dropuserobjectbyid : 
--
GO
/*
**	Drop an object from the dbo.dtproperties table
*/
create procedure [dbo].[dt_dropuserobjectbyid]
	@id int
as
	set nocount on
	delete from dbo.dtproperties where objectid=@id
GO

--
-- Definition for stored procedure dt_generateansiname : 
--
GO
/* 
**	Generate an ansi name that is unique in the dtproperties.value column 
*/ 
create procedure [dbo].[dt_generateansiname](@name varchar(255) output) 
as 
	declare @prologue varchar(20) 
	declare @indexstring varchar(20) 
	declare @index integer 
 
	set @prologue = 'MSDT-A-' 
	set @index = 1 
 
	while 1 = 1 
	begin 
		set @indexstring = cast(@index as varchar(20)) 
		set @name = @prologue + @indexstring 
		if not exists (select value from dtproperties where value = @name) 
			break 
		 
		set @index = @index + 1 
 
		if (@index = 10000) 
			goto TooMany 
	end 
 
Leave: 
 
	return 
 
TooMany: 
 
	set @name = 'DIAGRAM' 
	goto Leave
GO

--
-- Definition for stored procedure dt_getobjwithprop : 
--
GO
/*
**	Retrieve the owner object(s) of a given property
*/
create procedure [dbo].[dt_getobjwithprop]
	@property varchar(30),
	@value varchar(255)
as
	set nocount on

	if (@property is null) or (@property = '')
	begin
		raiserror('Must specify a property name.',-1,-1)
		return (1)
	end

	if (@value is null)
		select objectid id from dbo.dtproperties
			where property=@property

	else
		select objectid id from dbo.dtproperties
			where property=@property and value=@value
GO

--
-- Definition for stored procedure dt_getobjwithprop_u : 
--
GO
/*
**	Retrieve the owner object(s) of a given property
*/
create procedure [dbo].[dt_getobjwithprop_u]
	@property varchar(30),
	@uvalue nvarchar(255)
as
	set nocount on

	if (@property is null) or (@property = '')
	begin
		raiserror('Must specify a property name.',-1,-1)
		return (1)
	end

	if (@uvalue is null)
		select objectid id from dbo.dtproperties
			where property=@property

	else
		select objectid id from dbo.dtproperties
			where property=@property and uvalue=@uvalue
GO

--
-- Definition for stored procedure dt_getpropertiesbyid : 
--
GO
/*
**	Retrieve properties by id's
**
**	dt_getproperties objid, null or '' -- retrieve all properties of the object itself
**	dt_getproperties objid, property -- retrieve the property specified
*/
create procedure [dbo].[dt_getpropertiesbyid]
	@id int,
	@property varchar(64)
as
	set nocount on

	if (@property is null) or (@property = '')
		select property, version, value, lvalue
			from dbo.dtproperties
			where  @id=objectid
	else
		select property, version, value, lvalue
			from dbo.dtproperties
			where  @id=objectid and @property=property
GO

--
-- Definition for stored procedure dt_getpropertiesbyid_u : 
--
GO
/*
**	Retrieve properties by id's
**
**	dt_getproperties objid, null or '' -- retrieve all properties of the object itself
**	dt_getproperties objid, property -- retrieve the property specified
*/
create procedure [dbo].[dt_getpropertiesbyid_u]
	@id int,
	@property varchar(64)
as
	set nocount on

	if (@property is null) or (@property = '')
		select property, version, uvalue, lvalue
			from dbo.dtproperties
			where  @id=objectid
	else
		select property, version, uvalue, lvalue
			from dbo.dtproperties
			where  @id=objectid and @property=property
GO

--
-- Definition for stored procedure dt_getpropertiesbyid_vcs_u : 
--
GO
create procedure [dbo].[dt_getpropertiesbyid_vcs_u]
    @id       int,
    @property varchar(64),
    @value    nvarchar(255) = NULL OUT

as

    -- This procedure should no longer be called;  dt_getpropertiesbyid_vcsshould be called instead.
	-- Calls are forwarded to dt_getpropertiesbyid_vcs to maintain backward compatibility.
	set nocount on
    exec dbo.dt_getpropertiesbyid_vcs
		@id,
		@property,
		@value output
GO

--
-- Definition for stored procedure dt_isundersourcecontrol : 
--
GO
create proc [dbo].[dt_isundersourcecontrol]
    @vchLoginName varchar(255) = '',
    @vchPassword  varchar(255) = '',
    @iWhoToo      int = 0 /* 0 => Just check project; 1 => get list of objs */

as

	set nocount on

	declare @iReturn int
	declare @iObjectId int
	select @iObjectId = 0

	declare @VSSGUID varchar(100)
	select @VSSGUID = 'SQLVersionControl.VCS_SQL'

	declare @iReturnValue int
	select @iReturnValue = 0

	declare @iStreamObjectId int
	select @iStreamObjectId   = 0

	declare @vchTempText varchar(255)

    declare @iPropertyObjectId int
    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchProjectName   varchar(255)
    declare @vchSourceSafeINI varchar(255)
    declare @vchServerName    varchar(255)
    declare @vchDatabaseName  varchar(255)
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSProject',       @vchProjectName   OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLServer',     @vchServerName    OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLDatabase',   @vchDatabaseName  OUT

    if (@vchProjectName = '')	set @vchProjectName		= null
    if (@vchSourceSafeINI = '') set @vchSourceSafeINI	= null
    if (@vchServerName = '')	set @vchServerName		= null
    if (@vchDatabaseName = '')	set @vchDatabaseName	= null
    
    if (@vchProjectName is null) or (@vchSourceSafeINI is null) or (@vchServerName is null) or (@vchDatabaseName is null)
    begin
        RAISERROR('Not Under Source Control',16,-1)
        return
    end

    if @iWhoToo = 1
    begin

        /* Get List of Procs in the project */
        exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
        if @iReturn <> 0 GOTO E_OAError

        exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
												'GetListOfObjects',
												NULL,
												@vchProjectName,
												@vchSourceSafeINI,
												@vchServerName,
												@vchDatabaseName,
												@vchLoginName,
												@vchPassword

        if @iReturn <> 0 GOTO E_OAError

        exec @iReturn = master.dbo.sp_OAGetProperty @iObjectId, 'GetStreamObject', @iStreamObjectId OUT

        if @iReturn <> 0 GOTO E_OAError

        create table #ObjectList (id int identity, vchObjectlist varchar(255))

        select @vchTempText = 'STUB'
        while @vchTempText is not null
        begin
            exec @iReturn = master.dbo.sp_OAMethod @iStreamObjectId, 'GetStream', @iReturnValue OUT, @vchTempText OUT
            if @iReturn <> 0 GOTO E_OAError
            
            if (@vchTempText = '') set @vchTempText = null
            if (@vchTempText is not null) insert into #ObjectList (vchObjectlist ) select @vchTempText
        end

        select vchObjectlist from #ObjectList order by id
    end

CleanUp:
    return

E_OAError:
    exec dbo.dt_displayoaerror @iObjectId, @iReturn
    goto CleanUp
GO

--
-- Definition for stored procedure dt_isundersourcecontrol_u : 
--
GO
create proc [dbo].[dt_isundersourcecontrol_u]
    @vchLoginName nvarchar(255) = '',
    @vchPassword  nvarchar(255) = '',
    @iWhoToo      int = 0 /* 0 => Just check project; 1 => get list of objs */

as
	-- This procedure should no longer be called;  dt_isundersourcecontrol should be called instead.
	-- Calls are forwarded to dt_isundersourcecontrol to maintain backward compatibility.
	set nocount on
	exec dbo.dt_isundersourcecontrol
		@vchLoginName,
		@vchPassword,
		@iWhoToo
GO

--
-- Definition for stored procedure dt_removefromsourcecontrol : 
--
GO
create procedure [dbo].[dt_removefromsourcecontrol]

as

    set nocount on

    declare @iPropertyObjectId int
    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    exec dbo.dt_droppropertiesbyid @iPropertyObjectId, null

    /* -1 is returned by dt_droppopertiesbyid */
    if @@error <> 0 and @@error <> -1 return 1

    return 0
GO

--
-- Definition for stored procedure dt_setpropertybyid : 
--
GO
/*
**	If the property already exists, reset the value; otherwise add property
**		id -- the id in sysobjects of the object
**		property -- the name of the property
**		value -- the text value of the property
**		lvalue -- the binary value of the property (image)
*/
create procedure [dbo].[dt_setpropertybyid]
	@id int,
	@property varchar(64),
	@value varchar(255),
	@lvalue image
as
	set nocount on
	declare @uvalue nvarchar(255) 
	set @uvalue = convert(nvarchar(255), @value) 
	if exists (select * from dbo.dtproperties 
			where objectid=@id and property=@property)
	begin
		--
		-- bump the version count for this row as we update it
		--
		update dbo.dtproperties set value=@value, uvalue=@uvalue, lvalue=@lvalue, version=version+1
			where objectid=@id and property=@property
	end
	else
	begin
		--
		-- version count is auto-set to 0 on initial insert
		--
		insert dbo.dtproperties (property, objectid, value, uvalue, lvalue)
			values (@property, @id, @value, @uvalue, @lvalue)
	end
GO

--
-- Definition for stored procedure dt_setpropertybyid_u : 
--
GO
/*
**	If the property already exists, reset the value; otherwise add property
**		id -- the id in sysobjects of the object
**		property -- the name of the property
**		uvalue -- the text value of the property
**		lvalue -- the binary value of the property (image)
*/
create procedure [dbo].[dt_setpropertybyid_u]
	@id int,
	@property varchar(64),
	@uvalue nvarchar(255),
	@lvalue image
as
	set nocount on
	-- 
	-- If we are writing the name property, find the ansi equivalent. 
	-- If there is no lossless translation, generate an ansi name. 
	-- 
	declare @avalue varchar(255) 
	set @avalue = null 
	if (@uvalue is not null) 
	begin 
		if (convert(nvarchar(255), convert(varchar(255), @uvalue)) = @uvalue) 
		begin 
			set @avalue = convert(varchar(255), @uvalue) 
		end 
		else 
		begin 
			if 'DtgSchemaNAME' = @property 
			begin 
				exec dbo.dt_generateansiname @avalue output 
			end 
		end 
	end 
	if exists (select * from dbo.dtproperties 
			where objectid=@id and property=@property)
	begin
		--
		-- bump the version count for this row as we update it
		--
		update dbo.dtproperties set value=@avalue, uvalue=@uvalue, lvalue=@lvalue, version=version+1
			where objectid=@id and property=@property
	end
	else
	begin
		--
		-- version count is auto-set to 0 on initial insert
		--
		insert dbo.dtproperties (property, objectid, value, uvalue, lvalue)
			values (@property, @id, @avalue, @uvalue, @lvalue)
	end
GO

--
-- Definition for stored procedure dt_validateloginparams : 
--
GO
create proc [dbo].[dt_validateloginparams]
    @vchLoginName  varchar(255),
    @vchPassword   varchar(255)
as

set nocount on

declare @iReturn int
declare @iObjectId int
select @iObjectId =0

declare @VSSGUID varchar(100)
select @VSSGUID = 'SQLVersionControl.VCS_SQL'

    declare @iPropertyObjectId int
    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchSourceSafeINI varchar(255)
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT

    exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
    if @iReturn <> 0 GOTO E_OAError

    exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
											'ValidateLoginParams',
											NULL,
											@sSourceSafeINI = @vchSourceSafeINI,
											@sLoginName = @vchLoginName,
											@sPassword = @vchPassword
    if @iReturn <> 0 GOTO E_OAError

CleanUp:
    return

E_OAError:
    exec dbo.dt_displayoaerror @iObjectId, @iReturn
    GOTO CleanUp
GO

--
-- Definition for stored procedure dt_validateloginparams_u : 
--
GO
create proc [dbo].[dt_validateloginparams_u]
    @vchLoginName  nvarchar(255),
    @vchPassword   nvarchar(255)
as

	-- This procedure should no longer be called;  dt_validateloginparams should be called instead.
	-- Calls are forwarded to dt_validateloginparams to maintain backward compatibility.
	set nocount on
	exec dbo.dt_validateloginparams
		@vchLoginName,
		@vchPassword
GO

--
-- Definition for stored procedure dt_vcsenabled : 
--
GO
create proc [dbo].[dt_vcsenabled]

as

set nocount on

declare @iObjectId int
select @iObjectId = 0

declare @VSSGUID varchar(100)
select @VSSGUID = 'SQLVersionControl.VCS_SQL'

    declare @iReturn int
    exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT
    if @iReturn <> 0 raiserror('', 16, -1) /* Can't Load Helper DLLC */
GO

--
-- Definition for stored procedure dt_verstamp006 : 
--
GO
/*
**	This procedure returns the version number of the stored
**    procedures used by legacy versions of the Microsoft
**	Visual Database Tools.  Version is 7.0.00.
*/
create procedure [dbo].[dt_verstamp006]
as
	select 7000
GO

--
-- Definition for stored procedure dt_verstamp007 : 
--
GO
/*
**	This procedure returns the version number of the stored
**    procedures used by the the Microsoft Visual Database Tools.
**	Version is 7.0.05.
*/
create procedure [dbo].[dt_verstamp007]
as
	select 7005
GO

--
-- Definition for stored procedure dt_whocheckedout : 
--
GO
create proc [dbo].[dt_whocheckedout]
        @chObjectType  char(4),
        @vchObjectName varchar(255),
        @vchLoginName  varchar(255),
        @vchPassword   varchar(255)

as

set nocount on

declare @iReturn int
declare @iObjectId int
select @iObjectId =0

declare @VSSGUID varchar(100)
select @VSSGUID = 'SQLVersionControl.VCS_SQL'

    declare @iPropertyObjectId int

    select @iPropertyObjectId = (select objectid from dbo.dtproperties where property = 'VCSProjectID')

    declare @vchProjectName   varchar(255)
    declare @vchSourceSafeINI varchar(255)
    declare @vchServerName    varchar(255)
    declare @vchDatabaseName  varchar(255)
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSProject',       @vchProjectName   OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSourceSafeINI', @vchSourceSafeINI OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLServer',     @vchServerName    OUT
    exec dbo.dt_getpropertiesbyid_vcs @iPropertyObjectId, 'VCSSQLDatabase',   @vchDatabaseName  OUT

    if @chObjectType = 'PROC'
    begin
        exec @iReturn = master.dbo.sp_OACreate @VSSGUID, @iObjectId OUT

        if @iReturn <> 0 GOTO E_OAError

        declare @vchReturnValue varchar(255)
        select @vchReturnValue = ''

        exec @iReturn = master.dbo.sp_OAMethod @iObjectId,
												'WhoCheckedOut',
												@vchReturnValue OUT,
												@sProjectName = @vchProjectName,
												@sSourceSafeINI = @vchSourceSafeINI,
												@sObjectName = @vchObjectName,
												@sServerName = @vchServerName,
												@sDatabaseName = @vchDatabaseName,
												@sLoginName = @vchLoginName,
												@sPassword = @vchPassword

        if @iReturn <> 0 GOTO E_OAError

        select @vchReturnValue

    end

CleanUp:
    return

E_OAError:
    exec dbo.dt_displayoaerror @iObjectId, @iReturn
    GOTO CleanUp
GO

--
-- Definition for stored procedure dt_whocheckedout_u : 
--
GO
create proc [dbo].[dt_whocheckedout_u]
        @chObjectType  char(4),
        @vchObjectName nvarchar(255),
        @vchLoginName  nvarchar(255),
        @vchPassword   nvarchar(255)

as

	-- This procedure should no longer be called;  dt_whocheckedout should be called instead.
	-- Calls are forwarded to dt_whocheckedout to maintain backward compatibility.
	set nocount on
	exec dbo.dt_whocheckedout
		@chObjectType, 
		@vchObjectName,
		@vchLoginName, 
		@vchPassword
GO

--
-- Definition for stored procedure LUG_checkAccountByEmail : 
--
GO
CREATE Procedure [dbo].[LUG_checkAccountByEmail]
 
 (
  @UserID VARCHAR(24),
  @email VARCHAR(50),
  @result BIT OUTPUT
 )
 

AS
 
-- LEVEUP UP BRAZIL - Please, do not modify this procedure!
-- Return 0 = Not Exist
-- Return 1 = Exist
 
SET NOCOUNT ON
 
-- Check if user exists
IF EXISTS (SELECT 1 FROM game.account WHERE UserID = @UserID AND email = @email)
 SET @result = 1
ELSE
 SET @result = 0
GO

--
-- Definition for stored procedure LUG_ChkLogon : 
--
GO
CREATE PROC [dbo].[LUG_ChkLogon]
(
	@userId NVARCHAR(24),
	@passwd NVARCHAR(24),
	@result BIT OUTPUT
)
AS
BEGIN
	IF EXISTS (SELECT 1 FROM game.login (NOLOCK) WHERE [userId] = @userId AND password = @passwd)
		SET @result = 1
	ELSE
		SET @result = 0
END
GO

--
-- Definition for stored procedure LUG_GetClanRanking : 
--
GO
CREATE PROCEDURE [dbo].[LUG_GetClanRanking]
AS

SELECT TOP 5000
	cl.name,
	cl.totalpoint,
	cl.point,
	cl.wins,
	cl.losses,
	 ch.name as masterName
FROM
	dbo.Clan cl
	inner join dbo.Character ch on cl.MasterCID = ch.CID
where
	cl.DeleteFlag = 0
order by
	point desc,
	totalpoint desc,
	wins desc,
	losses asc
GO

--
-- Definition for stored procedure LUG_GetRanking : 
--
GO
CREATE PROCEDURE [dbo].[LUG_GetRanking]
AS

SELECT TOP 5000
	ch.Name, ch.Level, ch.XP
FROM
	dbo.Character ch
	INNER JOIN dbo.Account acc ON ch.AID = acc.AID
WHERE
	DeleteFlag = 0
	AND acc.UGradeID NOT IN (252, 253, 254, 255)
ORDER BY
	XP DESC,
	BP DESC
GO

--
-- Definition for stored procedure LUG_GetRankingByDate : 
--
GO
CREATE  PROCEDURE [dbo].[LUG_GetRankingByDate] (
	@cutDate	DATETIME,
	@days		INT
)
AS

SELECT top 5000
	ch.name,
	l.CID,
--	CONVERT(VARCHAR, DisTime, 102) as DisTime,
--	SUM(Playtime) as PlayTime,
--	SUM(Kills) as Kills,
--	SUM(Deaths) as Deaths,
	SUM(l.XP) as XP
--	MAX(TotalXP) as TotalXp
FROM
	dbo.PlayerLog l
	INNER JOIN dbo.Character ch ON l.CID = ch.CID
where
	DisTime between @cutDate and dateadd(d, @days, @cutdate)
GROUP BY
	ch.name,
	l.CID
order by
	SUM(l.XP) DESC
GO

--
-- Definition for stored procedure LUG_GetUserCount : 
--
GO
CREATE PROC [dbo].[LUG_GetUserCount]
@qtde INT OUTPUT
AS

SET NOCOUNT ON

SELECT @qtde = COUNT(1) 
FROM dbo.Login /*(NOLOCK)*/
GO

-- LEVEUP UP BRAZIL - Please, do not modify this procedure!
-- Return  0 = Sucess
-- Return -1 = Limit of Users Reached
-- Return -2 = User Exists
-- Return -3 = Email Exists
-- Return -4 = Error

CREATE  PROC [dbo].[LUG_InsertAccountGunz]
	@userId VARCHAR(20),
	@passwd VARCHAR(20),
	@userName VARCHAR(50),
	@phone VARCHAR(15),
	@email VARCHAR(50),
	@sex BIT,
	@birthday SMALLDATETIME,
	@city VARCHAR(50),
	@state CHAR(2),
	@connecType VARCHAR(50),
	@speed VARCHAR (50),
	--@limit SMALLINT,
	@result	SMALLINT OUTPUT
AS

SET NOCOUNT ON
DECLARE
	@AIDIdent		INT,
	@ERROR			INT

-- Check if user exists
IF EXISTS(SELECT 1 FROM dbo.Account WHERE UserId = @userId)
BEGIN
	SET @result = -2
	RETURN
END

BEGIN TRAN

	-- Insert User
	INSERT INTO dbo.Account
	(
		UserID,
		[Name],
		UGradeID,
		PGradeID,
		RegDate,
		Email,
		RegNum,
		Age,
		Sex,
		ZipCode,
		Address,
		Country,
		Cert
	)
	VALUES
	(
		@UserID,
		@userName,
		0,
		0,
		GETDATE(),
		@email,
		null,
		null,
		@sex,
		null,
		null,
		null,
		0
	)

	SELECT @AIDIdent = @@IDENTITY, @ERROR = @@ERROR

	IF @ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END


	INSERT INTO dbo.Login
	(
		UserID,
		AID,
		Password
	)
	VALUES
	(
		@UserID,
		@AIDIdent,
		@passwd
	)

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	INSERT INTO dbo.PersonalinfoGunz
	(
		aid,
		birthday,
		city,
		state,
		connecType,
		phone,
		speed
	)
	VALUES
	(
		@AIDIdent,
		@birthday,
		@city,
		@state, 
		@connecType, 
		@phone, 
		@speed
	)

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	SET @result = 0

COMMIT TRAN
RETURN
GO

--
-- Definition for stored procedure LUG_UpdateStatusLUA : 
--
GO
CREATE PROCEDURE [dbo].[LUG_UpdateStatusLUA]
(
	@gameUsername	VARCHAR(24),
	@email			VARCHAR(128)
)
AS
BEGIN TRAN

	UPDATE
		pinfo
	SET
		statusLua = 1
	FROM
		dbo.login login
		INNER JOIN dbo.personalInfoGunz pinfo ON login.AID = pinfo.AID
	WHERE
		Login.userId = @gameUsername

	-- se der erro rollback
	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	UPDATE
		dbo.Account
	SET
		email = @email
	WHERE
		userId = @gameUsername

	-- se der erro rollback
	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

COMMIT TRAN
GO

--
-- Definition for stored procedure LUG_UpdateTheDuelAccountData : 
--
GO
CREATE  Procedure [dbo].[LUG_UpdateTheDuelAccountData]
(
	@gameUserId	VARCHAR(24),
	@userNameAcc	VARCHAR(50),
	@email		VARCHAR(50),
	@birthday	DATETIME,
	@sex		BIT,
	@zipcode	VARCHAR(10),
	@address	VARCHAR(250),
	@country	VARCHAR(3),
	@city		VARCHAR(50),
	@state		VARCHAR(2),
	@connecType	INT,
	@phone		VARCHAR(13),
	@speed		INT,
	@msgLU		BIT
)
AS

SET XACT_ABORT ON

BEGIN TRAN

	--Realizando UPDATE na base RA
	UPDATE
	      game.Account
	SET	
		name = @userNameAcc,
		email = @email,
		age = SUBSTRING(CONVERT(VARCHAR, @birthday,103), 7, 4),
		sex = @sex,
		zipcode = @zipcode,
		address = @address,
		country = @country
	WHERE 	
		userid = @gameUserId

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	--Realizando UPDATE na base RA	
	UPDATE
		personal
	SET	
		birthday = convert(smalldatetime, @birthday, 112),
		city = @city,
		state = @state,
		connecType = @connecType,
		phone	= @phone,
		speed	= @speed,
		msgLU	= @msgLU
	FROM
		game.personalInfoGunz personal
		INNER JOIN game.Account acc ON personal.AID = acc.AID
	WHERE
		acc.userid = @gameUserId

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

COMMIT TRAN
GO

--
-- Definition for stored procedure LUG_UpdateTheDuelAccountEmail : 
--
GO
CREATE  Procedure [dbo].[LUG_UpdateTheDuelAccountEmail]
(
	@gameUserId	VARCHAR(24),
	@email		VARCHAR(50)
)
AS

SET XACT_ABORT ON

BEGIN TRAN

	--Realizando UPDATE na base RA
	UPDATE
	      game.Account
	SET	
		email = @email
	WHERE 	
		aid = @gameUserId

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END


COMMIT TRAN
GO

--
-- Definition for stored procedure LUG_UpdateTheDuelAccountEmail2 : 
--
GO
create   Procedure [dbo].[LUG_UpdateTheDuelAccountEmail2]
(
	@userid		VARCHAR(24),
	@email		VARCHAR(50)
)
AS

SET XACT_ABORT ON

BEGIN TRAN

	--Realizando UPDATE na base RA
	UPDATE
	      	dbo.Account
	SET	
		email = @email
	WHERE 	
		userid = @userid

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END


COMMIT TRAN
GO

--
-- Definition for stored procedure LUG_UpdateTheDuelPassword : 
--
GO
CREATE Procedure [dbo].[LUG_UpdateTheDuelPassword]
(
@UserId VARCHAR(24),
@Password VARCHAR(32)
)
AS
BEGIN
	
	UPDATE
		GunzDB.dbo.Login
	SET
		[Password] = @Password
	WHERE
		UserId = @UserId

END
GO

--
-- Definition for stored procedure LUG_ValidateForumUserTD : 
--
GO
CREATE PROC [dbo].[LUG_ValidateForumUserTD] 
@userId VARCHAR(24),
@passwd VARCHAR(24)
AS

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
SET NOCOUNT ON

DECLARE @email VARCHAR(200)

SELECT @email = b.email
FROM game.login a
	INNER JOIN game.account b
		ON a.AID = b.AID 
WHERE a.userid = @userId
AND a.[password] COLLATE Latin1_General_CS_AI = @passwd

SELECT @email AS email
GO

-- LEVEUP UP BRAZIL - Please, do not modify this procedure!
-- Return 0 = Not Exist
-- Return 1 = Exist


CREATE PROC [dbo].[OLD_LUG_CheckAccountGunz]
@userId VARCHAR(20),
@result BIT OUTPUT
AS

SET NOCOUNT ON

-- Check if user exists
IF EXISTS (SELECT 1 FROM dbo.Login /*(NOLOCK)*/ WHERE userId = @userId)
	SET @result = 1
ELSE
	SET @result = 0
GO

--
-- Definition for stored procedure OLD_LUG_ChkLogon : 
--
GO
CREATE PROC [dbo].[OLD_LUG_ChkLogon]
(
	@userId NVARCHAR(24),
	@passwd NVARCHAR(24),
	@result BIT OUTPUT
)
AS
BEGIN
	IF EXISTS (SELECT 1 FROM dbo.login /*(NOLOCK)*/ WHERE [userId] = @userId AND password = @passwd)
		SET @result = 1
	ELSE
		SET @result = 0
END
GO

-- LEVEUP UP BRAZIL - Please, do not modify this procedure!

CREATE  PROC [dbo].[OLD_LUG_GetTheDuelUser]
	@userName VARCHAR(50)
AS
	select * from  dbo.Account where userId = @userName
GO

--
-- Definition for stored procedure OLD_LUG_UpdateTheDuelAccountData : 
--
GO
CREATE  Procedure [dbo].[OLD_LUG_UpdateTheDuelAccountData]
(
	@gameUserId	VARCHAR(24),
	@userNameAcc	VARCHAR(50),
	@email		VARCHAR(50),
	@birthday	DATETIME,
	@sex		BIT,
	@zipcode	VARCHAR(10),
	@address	VARCHAR(250),
	@country	VARCHAR(3),
	@city		VARCHAR(50),
	@state		VARCHAR(2),
	@connecType	INT,
	@phone		VARCHAR(13),
	@speed		INT,
	@msgLU		BIT
)
AS

SET XACT_ABORT ON

BEGIN TRAN

	--Realizando UPDATE na base RA
	UPDATE
	      dbo.Account
	SET	
		name = @userNameAcc,
		email = @email,
		age = SUBSTRING(CONVERT(VARCHAR, @birthday,103), 7, 4),
		sex = @sex,
		zipcode = @zipcode,
		address = @address,
		country = @country
	WHERE 	
		userid = @gameUserId

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	--Realizando UPDATE na base RA	
	UPDATE
		personal
	SET	
		birthday = convert(smalldatetime, @birthday, 112),
		city = @city,
		state = @state,
		connecType = @connecType,
		phone	= @phone,
		speed	= @speed,
		msgLU	= @msgLU
	FROM
		dbo.personalInfoGunz personal
		INNER JOIN dbo.Account acc ON personal.AID = acc.AID
	WHERE
		acc.userid = @gameUserId

	IF @@ERROR <> 0
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

COMMIT TRAN
GO

-- ?? ??
CREATE PROC [dbo].[spAddClanMember]
	@CLID		int,
	@CID		int,
	@Grade		tinyint
AS
	SET NOCOUNT ON
	-- ??? ????? ??
	DECLARE @varClanCount		int

	SELECT @varClanCount=COUNT(*) FROM Clan(nolock) WHERE CLID=@CLID AND ((DeleteFlag IS NULL) OR (DeleteFlag=0))
	IF (@varClanCount = 0)
	BEGIN
		SELECT 0 AS Ret
		return (-1)
	END

	-- ???? ??
	DECLARE @MemberCount		int

	SELECT @MemberCount=COUNT(*) FROM ClanMember(nolock) WHERE CLID=@CLID
	IF @MemberCount >= 64	-- ?? 64??? ??
	BEGIN
		SELECT 0 AS Ret
		return (-1)
	END

	BEGIN TRAN
	INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@CLID, @CID, @Grade, GETDATE())
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		SELECT 0 AS Ret
		RETURN (-1)
	END
	COMMIT TRAN
	SELECT 1 AS Ret
GO

-- sp 

-- ?? ??
CREATE PROC [dbo].[spAddFriend]
	@CID		int
,	@FriendCID	int
,	@Favorite	tinyint
AS
BEGIN TRAN
	SET NOCOUNT ON
	DECLARE @ID	int
	INSERT INTO Friend(CID, FriendCID, Favorite, DeleteFlag, Type) Values (@CID, @FriendCID, @Favorite, 0, 1)
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		RETURN
	END
	SET @ID = @@IDENTITY
	SELECT @ID as ID
COMMIT TRAN
GO

--
-- Definition for stored procedure spAdmWebAccountItemInfoByAID : 
--
GO
CREATE PROC [dbo].[spAdmWebAccountItemInfoByAID] 
 @AID int
AS
 SET NOCOUNT ON
 SELECT ai.AIID, ai.RentHourPeriod, i.Name, i.ItemID
  , CASE ISNULL(RentDate, 0 )
    WHEN 0 THEN '0'
    ELSE (RentHourPeriod-DATEDIFF (hh, RentDate, GetDate()))  
    END AS RentRemain
  , CASE ISNULL(ai.RentDate, 0)
    WHEN 0 THEN '0'
    ELSE CAST(ai.RentDate AS varchar(24))
    END as RentDate
 FROM   AccountItem ai(NOLOCK) JOIN Item i(NOLOCK) 
 ON ai.AID = @AID AND i.ItemID = ai.ItemID
GO

--
-- Definition for stored procedure spAdmWebAddClanMember : 
--
GO
CREATE PROC [dbo].[spAdmWebAddClanMember]
 @CLID int
, @NewCID int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 IF NOT EXISTS (SELECT CID FROM Character(NOLOCK)
  WHERE CID = @NewCID AND DeleteFlag <> 1) BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END 

 IF NOT EXISTS (SELECT CLID FROM Clan(NOLOCK) 
  WHERE CLID = @CLID AND DeleteFlag <> 1) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 IF EXISTS (SELECT CMID FROM ClanMember(NOLOCK)
  WHERE CID = @NewCID) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 INSERT INTO ClanMember(CLID, CID, Grade, RegDate, ContPoint)
 VALUES (@CLID, @NewCID, 9, GETDATE(), 0)
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeCharDeathCount : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeCharDeathCount]
 @CID int
, @DeathCount int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF (0 > @DeathCount) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Character SET DeathCount = @DeathCount
 WHERE CID = @CID
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeCharKillCount : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeCharKillCount]
 @CID int
, @KillCount int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 IF (0 > @KillCount) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Character SET KillCount = @KillCount 
 WHERE CID = @CID
 IF 0 = @@ROWCOUNT BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeCharName]
 @CID int
, @CharName varchar(24)
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 IF NOT EXISTS( SELECT CID FROM Character(NOLOCK) 
  WHERE (DeleteFlag <> 1) AND (Name = @CharName)) BEGIN
  UPDATE Character SET Name = @CharName WHERE CID = @CID
  IF 0 = @@ROWCOUNT BEGIN
   SET @Ret = 0
   RETURN @Ret
  END
 END
 ELSE BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanEXP : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanEXP]
 @CLID int
, @NewEXP int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF 0 > @NewEXP BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Clan SET EXP = @NewEXP 
  WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanHomepage : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanHomepage]
 @CLID int
, @NewHomePage varchar(128)
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 UPDATE Clan SET Homepage = @NewHomepage 
  WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanIntroduction : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanIntroduction]  
 @CLID int  
, @NewIntroduction varchar(1024)  
, @GMID varchar(20)
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
  
 UPDATE Clan SET Introduction = @NewIntroduction WHERE CLID = @CLID  
 IF 0 = @@ROWCOUNT BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
  
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanMemberGrade : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanMemberGrade]
 @CLID int
, @CID int
, @NewGrade int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 IF NOT EXISTS (SELECT GradeID FROM ClanMemberGrade(NOLOCK) 
  WHERE GradeID=@NewGrade) BEGIN
  SET @Ret=0
  RETURN @Ret
 END

 IF 1=@NewGrade BEGIN -- master duplication check.
  IF EXISTS (SELECT CID FROM ClanMember(NOLOCK) 
   WHERE CLID=@CLID AND Grade=@NewGrade) BEGIN
   SET @Ret=0
   RETURN @Ret
  END
 END

 UPDATE ClanMember SET Grade=@NewGrade WHERE CLID=@CLID AND CID=@CID
 IF 0=@@ROWCOUNT BEGIN
  SET @Ret=0
  RETURN @Ret
 END

 SET @Ret=1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanName : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanName]
 @CLID int
, @NewClanName varchar(24)
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 IF EXISTS (SELECT CLID FROM Clan(NOLOCK) 
  WHERE Name = @NewClanName AND DeleteFlag <> 1) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Clan SET Name = @NewClanName 
 WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanPoint : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanPoint]
 @CLID int
, @NewClanPoint int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF 0 > @NewClanPoint BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Clan SET Point = @NewClanPoint 
  WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeClanTotalPoint : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeClanTotalPoint]
 @CLID int
, @NewClanTotalPoint int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 IF 0 > @NewClanTotalPoint BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Clan SET TotalPoint = @NewClanTotalPoint 
 WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebChangeWinsLosses : 
--
GO
CREATE PROC [dbo].[spAdmWebChangeWinsLosses]
 @CLID int
, @NewWins int
, @NewLosses int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF (0 > @NewWins) OR (0 > @NewLosses) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Clan SET Wins = @NewWins, Losses = @NewLosses 
 WHERE CLID = @CLID AND DeleteFlag <> 1
 IF 0=@@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteAccountItem : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteAccountItem]
	@AID int
,	@AIID int
,	@ItemID int
,	@GMID varchar(20)
,	@Ret int OUTPUT
AS
 SET NOCOUNT ON 

 IF NOT EXISTS (SELECT AID FROM Account(NOLOCK) 
 WHERE AID = @AID) BEGIN
  SET @Ret = 0
  RETURN @Ret	
 END

 DELETE AccountItem WHERE AIID = @AIID AND AID = @AID AND ItemID = @ItemID
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteCashSetShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteCashSetShopItem]
 @CSSID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DELETE CashSetShop WHERE CSSID = @CSSID
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteCashShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteCashShopItem]
 @CSID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 

 BEGIN TRAN
 DELETE CashShop WHERE CSID = @CSID
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret 
 END

 DELETE RentCashShopPrice WHERE CSID = @CSID
 IF 0 <> @@ERROR BEGIN
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret
 END 
 COMMIT TRAN

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteChar : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteChar]
 @AID  int
, @CharNum smallint
, @CharName varchar(24)
, @GMID varchar(20)
, @Ret int OUTPUT	
AS
 SET NOCOUNT ON 

 DECLARE @CID int
 DECLARE @ErrSlot int
 DECLARE @ErrDelInfo int
 DECLARE @ErrName int

 SELECT @CID = CID FROM Character(NOLOCK) 
 WHERE AID = @AID AND Name = @CharName AND CharNum = @CharNum
 IF @CID IS NULL BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END

 BEGIN TRAN
 -- ?????? ?????? ???? ?.
 INSERT INTO AccountItem( AID, ItemID, RentDate, RentHourPeriod, Cnt )
 SELECT @AID AS AID, ItemID, RentDate, RentHourPeriod, Cnt
 FROM CharacterItem(NOLOCK)
 WHERE CID = @CID AND ItemID > 499999
 IF 0 <> @@ERROR BEGIN 
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret
 END

 DELETE CharacterItem WHERE CID = @CID
 IF 0 <> @@ERROR BEGIN 
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Character SET head_slot = NULL, chest_slot = NULL, hands_slot = NULL,
 legs_slot = NULL, feet_slot = NULL, fingerl_slot = NULL, 
 fingerr_slot = NULL, melee_slot = NULL, primary_slot = NULL, 
 secondary_slot = NULL, custom1_slot = NULL, custom2_slot = NULL
 WHERE CID = @CID
 SET @ErrSlot = @@ROWCOUNT

 UPDATE Character SET DeleteName = Name, DeleteFlag = 1 WHERE CID = @CID
 SET @ErrDelInfo = @@ROWCOUNT

 UPDATE Character SET Name = '' WHERE CID = @CID
 SET @ErrName = @@ROWCOUNT

 IF (0 = @ErrSlot) OR (0 = @ErrDelInfo) OR (0 = @ErrName) BEGIN
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret
 END
 COMMIT TRAN
	
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteCharacterItem : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteCharacterItem]
 @CID int
, @CIID int
, @ItemID int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF NOT EXISTS (SELECT CID FROM Character(NOLOCK) WHERE CID = @CID) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 -- ????? ???? ???? ??? ?? ????? ?.
 BEGIN TRAN
 UPDATE Character SET head_slot = NULL WHERE CID = @CID AND head_slot = @CIID
 UPDATE Character SET chest_slot = NULL WHERE CID = @CID AND chest_slot = @CIID
 UPDATE Character SET hands_slot = NULL WHERE CID = @CID AND hands_slot = @CIID
 UPDATE Character SET legs_slot = NULL WHERE CID = @CID AND legs_slot = @CIID
 UPDATE Character SET feet_slot = NULL WHERE CID = @CID AND feet_slot = @CIID
 UPDATE Character SET fingerl_slot = NULL WHERE CID = @CID AND fingerl_slot = @CIID
 UPDATE Character SET fingerr_slot = NULL WHERE CID = @CID AND fingerr_slot = @CIID
 UPDATE Character SET melee_slot = NULL WHERE CID = @CID AND melee_slot = @CIID
 UPDATE Character SET primary_slot = NULL WHERE CID = @CID AND primary_slot = @CIID
 UPDATE Character SET secondary_slot = NULL WHERE CID = @CID AND secondary_slot = @CIID
 UPDATE Character SET custom1_slot = NULL WHERE CID = @CID AND custom1_slot = @CIID
 UPDATE Character SET custom2_slot = NULL WHERE CID = @CID AND custom2_slot = @CIID

 DELETE CharacterItem WHERE CIID = @CIID AND CID = @CID AND ItemID = @ItemID
 IF 0 <> @@ERROR BEGIN
  ROLLBACK TRAN
  SET @Ret = 0
  RETURN @Ret
 END
 COMMIT TRAN	

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteClanByCID : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteClanByCID]  
 @MasterCID int /* ??? CID */  
AS  
 SET NOCOUNT ON
 DECLARE @CLID int  
  
 SELECT @CLID = c.CLID  
 FROM Clan c(NOLOCK)  
 WHERE c.MasterCID = @MasterCID  
  
 -- ?? ?? ??.  
 IF (@MasterCID IS NULL) OR (@CLID IS NULL) BEGIN  
  SELECT 0 AS Ret  
  ROLLBACK TRAN  
  RETURN  
 END  

 BEGIN TRAN    
 -- Clan Member ??.  
 DELETE ClanMember WHERE CLID = @CLID  
 IF 0  <> @@ERROR BEGIN  
  SELECT 0 AS Ret  
  ROLLBACK TRAN  
  RETURN  
 END  
  
 -- Clan? ???? ?? ??? ??.  
 UPDATE Clan SET DeleteFlag = 1, MasterCID = NULL WHERE CLID = @CLID  
 UPDATE Clan SET DeleteName = Name WHERE CLID = @CLID  
 UPDATE Clan SET Name = NULL WHERE CLID = @CLID  
 COMMIT TRAN  
 
 SELECT 1 AS Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteCustomIP : 
--
GO
CREATE  PROC [dbo].[spAdmWebDeleteCustomIP]
 @IPFrom varchar(15)
, @IPTo varchar(15)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DECLARE @TmpIPFrom BIGINT
 DECLARE @TmpIPTo BIGINT
 
 SET @TmpIPFrom = GunzDB.game.inet_aton( @IPFrom )
 SET @TmpIPTo = GunzDB.game.inet_aton( @IPTo )
 IF @TmpIPFrom > @TmpIPTo BEGIN
  SET @Ret = 0
  RETURN @Ret
 END
 
 DELETE CustomIP WHERE IPFrom = @TmpIPFrom AND IPTo = @TmpIPTo
 IF 0 <> @@ERROR SET @Ret = 0
 ELSE SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteOneCashSetItem : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteOneCashSetItem]
 @CSSID int
, @CSID int
, @Ret int OUTPUT
AS 
 SET NOCOUNT ON
 DELETE CashSetItem WHERE CSSID = @CSSID AND CSID = @CSID
 IF (0 <> @@ERROR) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteRentCashSetShopPrice : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteRentCashSetShopPrice]
 @RCSSPID int
, @CSSID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DELETE RentCashSetShopPrice WHERE RCSSPID = @RCSSPID AND CSSID = @CSSID
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebDeleteRentCashShopPrice : 
--
GO
CREATE PROC [dbo].[spAdmWebDeleteRentCashShopPrice]
 @RCSPID int
, @CSID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DELETE RentCashShopPrice WHERE RCSPID = @RCSPID AND CSID = @CSID
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebEditCharBP : 
--
GO
CREATE PROC [dbo].[spAdmWebEditCharBP]
 @CID int
, @BP int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 UPDATE Character SET BP = @BP WHERE CID = @CID
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebEditCharKillDeathCount : 
--
GO
CREATE PROC [dbo].[spAdmWebEditCharKillDeathCount]
 @CID int
, @KillCount int
, @DeathCount int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 IF (0 > @KillCount) OR (0 > @DeathCount) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Character SET KillCount = @KillCount, DeathCount = @DeathCount
 WHERE CID = @CID
 IF 0 = @@ROWCOUNT BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebEditCharLevel : 
--
GO
CREATE PROC [dbo].[spAdmWebEditCharLevel]  
 @CID int  
, @Level smallint  
, @GMID varchar(20)  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
  
 IF (1 > @Level) OR (99 < @Level)  BEGIN  
  SET @Ret = -1  
  RETURN @Ret  
 END  

 IF NOT EXISTS (SELECT CID FROM Character(NOLOCK) WHERE CID = @CID) BEGIN
  SET @Ret = -2
  RETURN @Ret
 END
  
 IF EXISTS (SELECT CID FROM Character(NOLOCK)   
  WHERE CID = @CID AND Level = @Level) BEGIN  
  SET @Ret = 1  
  RETURN @Ret  
 END  
  
 DECLARE @XP int  
  
 SELECT @XP = MinXP FROM Level(NOLOCK) WHERE Level = @Level  
 IF @XP IS NULL BEGIN  
  SET @Ret = -3  
  RETURN @Ret  
 END  
  
 UPDATE Character SET Level = @Level, XP = @XP WHERE CID = @CID AND DeleteFlag <> 1  
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN  
  SET @Ret = -4  
  RETURN @Ret  
 END
GO

--
-- Definition for stored procedure spAdmWebEditCharPlayTime : 
--
GO
CREATE PROC [dbo].[spAdmWebEditCharPlayTime]
 @CID int
, @PlayTime int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 
 IF (0 > @PlayTime) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 UPDATE Character SET PlayTime = @PlayTime WHERE CID = @CID
 IF 0 = @@ROWCOUNT BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END
	
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebEditCharXP : 
--
GO
CREATE PROC [dbo].[spAdmWebEditCharXP]
 @CID int
, @XP int
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 IF 0 > @XP BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 DECLARE @MaxMinXP int
 DECLARE @Level smallint

 SELECT TOP 1 @MaxMinXP = MinXP FROM Level(NOLOCK) 
 ORDER BY MinXP DESC

 IF @MaxMinXP > @XP BEGIN
  SELECT TOP 1 @Level = Level FROM Level(NOLOCK) 
  WHERE MinXP <= @XP ORDER BY Level DESC
 END
 ELSE BEGIN
  SELECT TOP 1 @Level = Level FROM Level(NOLOCK) 
  ORDER BY Level DESC
 END

 UPDATE Character SET Level = @Level, XP = @XP 
 WHERE CID = @CID AND DeleteFlag <> 1
 IF 0 = @@ROWCOUNT BEGIN 
  SET @Ret = 0
  RETURN @Ret
 END
 
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebGetAccountInfoByAID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAccountInfoByAID]  
	@AID int
AS  
 	SET NOCOUNT ON  
  
 	SELECT AID, UserID, Name, Age, Sex, UGradeID, RegDate  
 	FROM Account(NOLOCK)  
 	WHERE AID = @AID
GO

--
-- Definition for stored procedure spAdmWebGetAccountInfoByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAccountInfoByCharName]
	@CharName varchar( 24 ) 
AS
	SET NOCOUNT ON

	SELECT a.UserID, a.AID, a.RegDate, a.UGradeID, a.Sex, a.Age, a.Name
	FROM Character c(NOLOCK) JOIN Account a(NOLOCK)
	ON c.Name = @CharName AND c.AID = a.AID
GO

--
-- Definition for stored procedure spAdmWebGetAccountInfoByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAccountInfoByUserID]
	@UserID varchar( 20 )
AS
	SET NOCOUNT ON

	SELECT AID, UserID, Name, Age, Sex, UGradeID, RegDate
	FROM Account(NOLOCK)
	WHERE UserID = @UserID
GO

--
-- Definition for stored procedure spAdmWebGetAccountJoinStatistics : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAccountJoinStatistics]
 @StartDate smalldatetime
, @EndDate smalldatetime
AS
 SET NOCOUNT ON 

 SELECT  convert(char(10), RegDate, 120) as Date ,count(AID) as Count
 FROM Account(nolock)  
 WHERE RegDate between convert(datetime, @StartDate) and convert(datetime, @EndDate)
 GROUP BY convert(char(10), RegDate, 120)
GO

--
-- Definition for stored procedure spAdmWebGetAllCharInfoByAID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllCharInfoByAID]  
 @AID int  
AS  
 SET NOCOUNT ON  
  
 SELECT c.Name, c.AID, c.CID, c.RegDate, c.PlayTime, c.LastTime
  , c.Sex, c.CharNum, c.Level, c.XP, c.BP, c.KillCount, c.DeathCount, c.DeleteFlag, c.DeleteName  
 FROM Account a(NOLOCK) JOIN Character c(NOLOCK)  
 ON a.AID = @AID AND c.AID = a.AID
GO

--
-- Definition for stored procedure spAdmWebGetAllCharInfoByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllCharInfoByCharName]
 @CharName varchar( 24 )
AS
 SET NOCOUNT ON
 
 SELECT Name, AID, CID, RegDate, PlayTime, LastTime, Sex,
  CharNum, Level, XP, BP, DeleteFlag, DeleteName, 
  KillCount, DeathCount
 FROM Character(NOLOCK)
 WHERE Name = @CharName
 ORDER BY DeleteFlag, CharNum
GO

--
-- Definition for stored procedure spAdmWebGetAllCharInfoByOneCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllCharInfoByOneCharName]
 @CharName varchar(24)
AS
 SET NOCOUNT ON 

 SELECT c2.Name, c2.CID
 FROM (Character c1(NOLOCK) JOIN Account a(NOLOCK)
 ON c1.Name = @CharName AND a.AID = c1.AID) JOIN Character c2(NOLOCK)
 ON c2.AID = a.AID
 ORDER BY c2.DeleteFlag, c2.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetAllCharInfoByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllCharInfoByUserID]
 @UserID varchar( 20 )
AS
 SET NOCOUNT ON

 SELECT c.Name, c.AID, c.CID, c.RegDate, c.PlayTime, c.LastTime, 
  c.Sex, c.CharNum, c.Level, c.XP, c.BP, c.DeleteFlag, 
  c.DeleteName, c.KillCount, c.DeathCount
 FROM Account a(NOLOCK) JOIN Character c(NOLOCK)
 ON a.UserID = @UserID AND c.AID = a.AID
 ORDER BY c.DeleteFlag, c.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetAllCharNameCIDByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllCharNameCIDByUserID]
	@UserID varchar(20)
AS
	SET NOCOUNT ON

	SELECT c.Name, c.CID, c.DeleteFlag
	FROM Account a(NOLOCK) JOIN Character c(NOLOCK)
	ON a.UserID = @UserID AND c.AID = a.AID
	ORDER BY c.DeleteFlag, c.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetAllSimpleCharInfoByOneCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetAllSimpleCharInfoByOneCharName]
 @CharName varchar( 24 )
AS
 SET NOCOUNT ON

 SELECT c2.Name, c2.CID
 FROM (Character c1(NOLOCK) JOIN Account a(NOLOCK)
 ON c1.Name = 'sunge_se' AND a.AID = c1.AID) JOIN Character c2(NOLOCK)
 ON c2.AID = a.AID
 ORDER BY c2.DeleteFlag, c2.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetBlockCountryCodeList : 
--
GO
CREATE PROC [dbo].[spAdmWebGetBlockCountryCodeList]
 @Code char
AS
 SET NOCOUNT ON

 SELECT bcc.CountryCode3, bcc.RoutingURL, bcc.IsBlock, cc.CountryName
 FROM BlockCountryCode bcc(NOLOCK) JOIN CountryCode cc(NOLOCK)
 ON cc.CountryCode3 = bcc.CountryCode3
 WHERE cc.CountryName LIKE @Code + '%'
 ORDER BY CountryName ASC
GO

--
-- Definition for stored procedure spAdmWebGetBountyItemPurchaseLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetBountyItemPurchaseLog]
 @CID int
, @ItemID int
AS
 SET NOCOUNT ON

 SELECT ipl.id AS ID, c.Name AS CharName, ipl.ItemID, i.Name, c.CID, 
  0 AS CIID, ipl.Bounty, ipl.CharBounty, i.Slot, ipl.Type, ipl.Date
 FROM (Character c(NOLOCK) JOIN ItemPurchaseLogByBounty ipl(NOLOCK)
 ON c.CID = @CID AND ipl.CID = c.CID) JOIN Item i(NOLOCK)
 ON i.ItemID = ipl.ItemID
 WHERE ipl.ItemID = @ItemID
 ORDER BY ipl.id DESC
GO

--
-- Definition for stored procedure spAdmWebGetBountyItemPurchaseLogByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetBountyItemPurchaseLogByCharName]  
 @CharName varchar( 24 )  
AS  
 SET NOCOUNT ON  
  
 SELECT ipl.id AS ID, ipl.ItemID, i.Name, c.CID, 0 AS CIID, ipl.Bounty,    
  ipl.CharBounty, i.Slot, ipl.type, ipl.Date  
 FROM (Character c(NOLOCK) JOIN ItemPurchaseLogByBounty ipl(NOLOCK)  
 ON c.Name = @CharName AND ipl.CID = c.CID) JOIN Item i(NOLOCK)  
 ON i.ItemID = ipl.ItemID  
 ORDER BY ipl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCaracterMakingLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCaracterMakingLog]  
 @CharName varchar(24)  
AS  
 SET NOCOUNT ON  
 SELECT a.UserID, cml.AID,  cml.CharName, cml.Type, cml.Date  
 FROM Account a(nolock), CharacterMakingLog cml(nolock)   
 WHERE cml.CharName = @CharName AND a.AID = cml.AID   
 ORDER BY cml.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCashItemPresentRecvLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashItemPresentRecvLog]
 @AID int  
AS  
 SET NOCOUNT ON  
 SELECT cpl.id, cpl.SenderUserID, a.UserID AS ReceiverUserID
  , i.Name AS ItemName, cpl.Date, cpl.Cash  
  , CASE ISNULL(cpl.RentHourPeriod, 0)
   WHEN 0 THEN '0'
   ELSE CAST(cpl.RentHourPeriod AS varchar(10))
   END AS 'RentHourPeriod'
 FROM ((Account a(NOLOCK) JOIN CashItemPresentLog cpl(NOLOCK)  
 ON a.AID = @AID AND cpl.ReceiverAID = a.AID) JOIN CashShop cs(NOLOCK)  
 ON cs.CSID = cpl.CSID) JOIN Item i(NOLOCK)  
 ON i.ItemID = cs.ItemID  
 ORDER BY cpl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCashItemPresentSendLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashItemPresentSendLog]
 @AID int  
AS  
 SET NOCOUNT ON   
 SELECT cpl.id, cpl.SenderUserID, ar.UserID AS ReceiverUserID
  , i.Name AS ItemName, cpl.Date, cpl.Cash  
  , CASE ISNULL(cpl.RentHourPeriod, 0)
    WHEN 0 THEN '0'
    ELSE CAST(cpl.RentHourPeriod AS varchar(10))
   END AS 'RentHourPeriod'
 FROM (((Account a(NOLOCK) JOIN CashItemPresentLog cpl(NOLOCK)  
 ON a.AID = @AID AND cpl.SenderUserID = a.UserID) JOIN CashShop cs(NOLOCK)  
 ON cs.CSID = cpl.CSID) JOIN Item i(NOLOCK)  
 ON i.ItemID = cs.ItemID) JOIN Account ar(NOLOCK)   
 ON ar.AID = cpl.ReceiverAID  
 ORDER BY cpl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCashSetItemPresentRecvLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashSetItemPresentRecvLog]  
 @AID int  
AS  
 SET NOCOUNT ON  
 SELECT cpl.id, cpl.SenderUserID, a.UserID AS ReceiverUserID
  , css.Name AS ItemName, cpl.Date, cpl.Cash
  , CASE ISNULL(cpl.RentHourPeriod, 0)
    WHEN 0 THEN '0'
    ELSE CAST(cpl.RentHourPeriod AS varchar(10))
   END AS 'RentHourPeriod'
 FROM (Account a(NOLOCK) JOIN CashItemPresentLog cpl(NOLOCK)  
 ON a.AID = @AID AND cpl.ReceiverAID = a.AID) JOIN CashSetShop css(NOLOCK)  
 ON css.CSSID = cpl.CSSID  
 ORDER BY cpl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCashSetItemPresentSendLog : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashSetItemPresentSendLog]      
 @AID int      
AS      
 SET NOCOUNT ON       
 SELECT cpl.id, cpl.SenderUserID, aa.UserID AS ReceiverUserID    
  , css.Name AS ItemName, cpl.Date, cpl.Cash      
  , CASE ISNULL(cpl.RentHourPeriod, 0)    
    WHEN 0 THEN '0'    
    ELSE CAST(cpl.RentHourPeriod AS varchar(10))     
   END AS 'RentHourPeriod'    
 FROM ((Account a(NOLOCK) JOIN CashItemPresentLog cpl(NOLOCK)      
 ON a.AID = @AID AND cpl.SenderUserID = a.UserID) JOIN CashSetShop css(NOLOCK)      
 ON css.CSSID = cpl.CSSID) JOIN Account aa(NOLOCK)     
 ON aa.AID = cpl.ReceiverAID     
 ORDER BY cpl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetCashSetShopList : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashSetShopList]
AS
 SET NOCOUNT ON
 SELECT CSSID, Name
 FROM CashSetShop(NOLOCK)
 ORDER BY CSSID
GO

--
-- Definition for stored procedure spAdmWebGetCashShopList : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCashShopList]
AS
 SET NOCOUNT ON
  SELECT cs.CSID, i.Name, i.Slot, cs.Opened, cs.NewItemOrder,
  cs.CashPrice, cs.WebImgName, ISNULL(cs.RentType, 0) AS 'RentType'
 FROM CashShop cs(NOLOCK) JOIN Item i(NOLOCK)
 ON i.ItemID = cs.ItemID
GO

--
-- Definition for stored procedure spAdmWebGetCharInfoByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCharInfoByUserID]  
 @UserID varchar(20)  
AS  
 SET NOCOUNT ON  
  
 SELECT c.Name, c.AID, c.CID, c.RegDate, c.PlayTime, c.LastTime,c.Sex,  
  c.CharNum, c.Level, c.XP, c.BP, c.DeleteFlag, c.DeleteName,  
  c.KillCount, c.DeathCount  
 FROM Account a(NOLOCK) JOIN Character c(NOLOCK)  
 ON a.UserID = @UserID AND c.AID = a.AID  
 ORDER BY DeleteFlag, CharNum
GO

--
-- Definition for stored procedure spAdmWebGetCharItemByCID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCharItemByCID]
	@CID int
AS
BEGIN
	SET NOCOUNT ON

	SELECT ci.ItemID, i.Name, ci.CIID, ci.RegDate AS RegDate,  
		CASE 
		WHEN ci.RentHourPeriod IS NOT NULL THEN (RentHourPeriod) - (DateDiff(hh, RentDate, GETDATE()))
		WHEN ci.RentHourPeriod IS NULL THEN -1
		ELSE -2 -- error.
		END AS RentPeriodRemainderHour,
		CASE ci.CIID 
		WHEN c.head_slot THEN 'Head'
		WHEN c.chest_slot THEN 'Chest'
		WHEN c.hands_slot THEN 'Hands'
		WHEN c.legs_slot THEN 'Legs'
		WHEN c.feet_slot THEN 'Feet'
		WHEN c.fingerl_slot THEN 'Left finger'
		WHEN c.fingerr_slot THEN 'Right finger'
		WHEN c.melee_slot THEN 'Melee'
		WHEN c.primary_slot THEN 'Primary'
		WHEN c.secondary_slot THEN 'Secondary'
		WHEN c.custom1_slot THEN 'Custom1'
		WHEN c.custom2_slot THEN 'Custom2'
		ELSE 'Free item'
		END AS KeepOnPosition,
		CASE ci.CIID
		WHEN c.head_slot THEN 11
		WHEN c.chest_slot THEN 12
		WHEN c.hands_slot THEN 13
		WHEN c.legs_slot THEN 14
		WHEN c.feet_slot THEN 15
		WHEN c.fingerl_slot THEN 16
		WHEN c.fingerr_slot THEN 17
		WHEN c.melee_slot THEN 18
		WHEN c.primary_slot THEN 19
		WHEN c.secondary_slot THEN 20
		WHEN c.custom1_slot THEN 21
		WHEN c.custom2_slot THEN 22
		ELSE 23
		END AS Orders
	FROM (Character c(NOLOCK) JOIN CharacterItem ci(NOLOCK)
	ON c.CID = @CID AND ci.CID = c.CID) JOIN Item i(NOLOCK)
	ON i.ItemID = ci.ItemID
	ORDER BY Orders 
END
GO

--
-- Definition for stored procedure spAdmWebGetCharLogByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCharLogByCharName]
 @CharName varchar(24)
AS
 SET NOCOUNT ON

 SELECT a.UserID, cml.CharName, cml.Type, cml.Date
 FROM CharacterMakingLog cml(NOLOCK) JOIN Account a(NOLOCK)
 ON cml.CharName = @CharName AND a.AID = cml.AID
GO

--
-- Definition for stored procedure spAdmWebGetCharQuestItem : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCharQuestItem]
	@CharName varchar( 24 )
AS	
BEGIN
	SET NOCOUNT ON

	SELECT QuestItemInfo
	FROM Character( NOLOCK )
	WHERE Name = @CharName
END
GO

--
-- Definition for stored procedure spAdmWebGetCharQuestItemInfoByCID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCharQuestItemInfoByCID]
	@CID int
AS
	SET NOCOUNT ON

	SELECT QuestItemInfo FROM Character(NOLOCK) WHERE CID = @CID
GO

--
-- Definition for stored procedure spAdmWebGetClanInfoByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetClanInfoByCharName]
 @CharName varchar(24)
AS
 SET NOCOUNT ON

 DECLARE @CLID int

 SELECT @CLID = cm.CLID
 FROM Character c(NOLOCK) JOIN ClanMember cm(NOLOCK)
 ON c.Name = @CharName AND cm.CID = c.CID
 IF @CLID IS NULL RETURN

 SELECT cl.CLID, cl.Name, c.Name AS 'MastName', cl.Introduction, cl.RegDate, cl.HomePage, cl.EmblemURL, cl.DeleteFlag
 FROM Clan cl(NOLOCK) JOIN Character c(NOLOCK)
 ON cl.CLID = @CLID AND cl.MasterCID = c.CID
GO

--
-- Definition for stored procedure spAdmWebGetClanInfoByClanName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetClanInfoByClanName]
 @ClanName varchar(24)
AS
 SET NOCOUNT ON

 SELECT cl.CLID, cl.Name, c.Name AS 'MastName', cl.Introduction, 
  cl.RegDate, cl.HomePage, cl.EmblemURL, cl.DeleteFlag
 FROM Clan cl(NOLOCK) JOIN Character c(NOLOCK)
 ON cl.Name = @ClanName AND cl.MasterCID = c.CID
GO

--
-- Definition for stored procedure spAdmWebGetClanMemberInfoByCLID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetClanMemberInfoByCLID]      
 @CLID int      
AS      
 SET NOCOUNT ON       
      
 SELECT cm.CLID, cm.Grade, a.AID, a.UserID, c.Name, cm.CID, c.Level, cm.ContPoint, cm.RegDate      
 FROM (ClanMember cm(NOLOCK) JOIN Character c(NOLOCK)      
 ON cm.CLID = @CLID AND c.CID = cm.CID) JOIN Account a( NOLOCK)      
 ON a.AID = c.AID      
 WHERE c.DeleteFlag <> 1      
Order by cm.Grade, cm.RegDate
GO

--
-- Definition for stored procedure spAdmWebGetClanRankInfoByCLID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetClanRankInfoByCLID]  
 @CLID int   
AS  
 SELECT Exp, Point, TotalPoint, Wins, Losses, Ranking, LastDayRanking, LastMonthRanking, RankIncrease  
 FROM Clan(NOLOCK)  
 WHERE CLID = @CLID
GO

--
-- Definition for stored procedure spAdmWebGetCustomIP : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCustomIP]  
 @RegDateFrom smalldatetime  
, @RegDateTo smalldatetime  
AS  
 SET NOCOUNT ON  
 DECLARE @TmpIP bigint  
  
 SET @RegDateTo = DATEADD( dd, 1, @RegDateTo )  
  
 SELECT GunzDB.game.inet_ntoa(IPFrom) AS IPFrom, GunzDB.game.inet_ntoa(IPTo) AS IPTo,   
  CountryCode3, Comment, IsBlock, RegDate  
 FROM CustomIP(NOLOCK)  
 WHERE RegDate >= @RegDateFrom AND RegDate <= @RegDateTo
GO

--
-- Definition for stored procedure spAdmWebGetCustomIPByIP : 
--
GO
CREATE PROC [dbo].[spAdmWebGetCustomIPByIP]  
 @IP varchar(15)  
, @RegDateFrom smalldatetime  
, @RegDateTo smalldatetime  
AS  
 SET NOCOUNT ON  
 DECLARE @TmpIP bigint  
  
 SET @TmpIP = GunzDB.game.inet_aton( @IP )  
 SET @RegDateTo = DATEADD( dd, 1, @RegDateTo )  
  
 SELECT GunzDB.game.inet_ntoa(IPFrom) AS IPFrom, GunzDB.game.inet_ntoa(IPTo) AS IPTo,   
  CountryCode3, Comment, IsBlock, RegDate  
 FROM CustomIP(NOLOCK)  
 WHERE RegDate >= @RegDateFrom AND RegDate <= @RegDateTo AND  
  IPFrom <= @TmpIP AND IPTo >= @TmpIP
GO

--
-- Definition for stored procedure spAdmWebGetItemList : 
--
GO
CREATE PROC [dbo].[spAdmWebGetItemList]
AS
 SET NOCOUNT ON
 SELECT ItemID, Name, Slot, IsCashItem
 FROM Item(NOLOCK)
 ORDER BY ItemID
GO

--
-- Definition for stored procedure spAdmWebGetItemPurchaseLogByCash : 
--
GO
CREATE PROC [dbo].[spAdmWebGetItemPurchaseLogByCash]
 @AID int  
AS  
 SET NOCOUNT ON  
 SELECT ipl.id, a.UserID AS SenderUserID, a.UserID AS ReceiverUserID, 
  i.Name AS ItemName, ipl.Date, ipl.Cash
  , CASE ISNULL(ipl.RentHourPeriod, 0) 
   WHEN 0 THEN '0'
   ELSE CAST(ipl.RentHourPeriod AS varchar(10)) 
   END AS 'RentHourPeriod'
 FROM (Account a(NOLOCK) JOIN ItemPurchaseLogByCash ipl(NOLOCK)  
 ON a.AID = @AID AND ipl.AID = a.AID) JOIN Item i(NOLOCK)  
 ON i.ItemID = ipl.ItemID  
 ORDER BY ipl.Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetLiveCharInfoByAID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetLiveCharInfoByAID]
 @AID int
AS
 SET NOCOUNT ON

 SELECT c.Name, c.AID, c.CID, c.RegDate, c.PlayTime, c.LastTime, 
  c.Sex, c.CharNum, c.Level, c.XP, c.BP, c.KillCount, c.DeathCount
 FROM Account a(NOLOCK) JOIN Character c(NOLOCK)
 ON a.AID = @AID AND c.AID = a.AID 
 WHERE c.DeleteFlag <> 1
GO

--
-- Definition for stored procedure spAdmWebGetLiveCharInfoByCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetLiveCharInfoByCharName]
 @CharName varchar( 24 )
AS 
 SET NOCOUNT ON

 SELECT Name, AID, CID, RegDate, PlayTime, LastTime, Sex, 
  CharNum, Level, XP, BP, KillCount, DeathCount
 FROM Character(NOLOCK)
 WHERE Name = @CharName AND DeleteFlag <> 1
 ORDER BY CharNum
GO

--
-- Definition for stored procedure spAdmWebGetLiveCharInfoByOneCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetLiveCharInfoByOneCharName]
 @CharName varchar(24)
AS
 SET NOCOUNT ON
 
 SELECT c2.Name, c2.CID
 FROM (Character c1(NOLOCK) JOIN Account a(NOLOCK)
 ON c1.Name = @CharName AND a.AID = c1.AID) JOIN Character c2(NOLOCK)
 ON c2.AID = a.AID
 WHERE c2.DeleteFlag <> 1
 ORDER BY c2.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetLiveCharListByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetLiveCharListByUserID]
	@UserID varchar( 20 )
AS 
	SET NOCOUNT ON

	SELECT c.Name, c.AID, c.CID, c.RegDate, c.PlayTime, c.LastTime, 
		c.Sex, c.CharNum, c.Level, c.XP, c.BP, c.KillCount, c.DeathCount
	FROM Account a(NOLOCK) JOIN Character c(NOLOCK)
	ON a.UserID = @UserID AND c.AID = a.AID
	WHERE c.DeleteFlag <> 1
	ORDER BY c.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetLiveCharNameCIDByUserID : 
--
GO
CREATE PROC [dbo].[spAdmWebGetLiveCharNameCIDByUserID]
	@UserID varchar(20)
AS
	SET NOCOUNT ON 

	SELECT c.Name, c.CID, c.DeleteFlag
	FROM Account a(NOLOCK) JOIN Character c(NOLOCK)
	ON a.UserID = @UserID AND c.AID = a.AID
	WHERE c.DeleteFlag <> 1
	ORDER BY c.DeleteFlag, c.CharNum
GO

--
-- Definition for stored procedure spAdmWebGetQuestItemInfo : 
--
GO
CREATE PROC [dbo].[spAdmWebGetQuestItemInfo]
 @CID int
AS
 SET NOCOUNT ON 
 SELECT CID, Name, QuestItemInfo 
 FROM Character(NOLOCK)
 WHERE CID = @CID
GO

--
-- Definition for stored procedure spAdmWebGetRentPeriodDayList : 
--
GO
CREATE PROC [dbo].[spAdmWebGetRentPeriodDayList]
AS
 SET NOCOUNT ON
 SELECT  Day FROM RentPeriodDay(NOLOCK) ORDER BY Day
GO

------------------------------------------------------------------------------------------------------------------------

CREATE   PROC [dbo].[spAdmWebGetServerLog10Min]
 @ServerID tinyint
, @StartTime smalldatetime
, @EndTime smalldatetime
AS
 SET NOCOUNT ON

 IF @StartTime > @EndTime RETURN

 SELECT	a.ServerID, ss.ServerName,
	CONVERT(smalldatetime,DATEADD(mi,a.time*10 ,@StartTime)) as starttime,  
	CONVERT(smalldatetime,DATEADD(mi,(a.time*10+10)-1 ,@StartTime)) as endtime,  
	SUM(playercount)/10/(DATEDIFF(DAY,@StartTime, @EndTime)+ 1) as PlayerCount
 FROM(
	SELECT	ServerID, ISNULL(playercount,0) as PlayerCount, DATEPART(mi,DATEADD(mi, -1, time)) /10 as time
	FROM	LogDB.game.ServerLogStorage(NOLOCK)
	WHERE	Time BETWEEN @StartTime AND @EndTime 
		AND datediff(hh,@StartTime, DATEADD(mi, -1, time) ) % 24 = 0
 ) as a, ServerStatus ss(NOLOCK)
 WHERE  a.ServerID = @ServerID AND ss.ServerID = a.ServerID
 Group By a.ServerID, ss.ServerName, a.Time
 Order By a.Time
GO

--
-- Definition for stored procedure spAdmWebGetServerLogDayHour : 
--
GO
CREATE   PROC [dbo].[spAdmWebGetServerLogDayHour]
 @ServerType tinyint -- 0:??, 1:??, 2:??, 3:???, 4:???
, @StartDate smalldatetime
, @EndDate smalldatetime
AS
 SET NOCOUNT ON

 IF @StartDate > @EndDate RETURN

 DECLARE @StartServerID int
 DECLARE @EndServerID int

 IF 0 = @ServerType -- all
  SELECT @StartServerID = 1, @EndServerID = 255
 ELSE IF 1 = @ServerType -- normal
  SELECT @StartServerID = 1, @EndServerID = 49
 ELSE IF 2 = @ServerType -- clan
  SELECT @StartServerID = 50, @EndServerID = 99
 ELSE IF 3 = @ServerType -- quest
  SELECT @STartServerID = 100, @EndServerID = 149
 ELSE IF 4 = @ServerType -- event
  RETURN
 ELSE -- error
  RETURN

 SELECT ss.ServerID, ss.ServerName, 
  SUM(CASE DATEPART(hh, t.Time) WHEN 0 THEN t.PlayerCount ELSE 0 END) AS H0
 , SUM(CASE DATEPART(hh, t.Time) WHEN 1 THEN t.PlayerCount ELSE 0 END) AS H1
 , SUM(CASE DATEPART(hh, t.Time) WHEN 2 THEN t.PlayerCount ELSE 0 END) AS H2
 , SUM(CASE DATEPART(hh, t.Time) WHEN 3 THEN t.PlayerCount ELSE 0 END) AS H3
 , SUM(CASE DATEPART(hh, t.Time) WHEN 4 THEN t.PlayerCount ELSE 0 END) AS H4
 , SUM(CASE DATEPART(hh, t.Time) WHEN 5 THEN t.PlayerCount ELSE 0 END) AS H5
 , SUM(CASE DATEPART(hh, t.Time) WHEN 6 THEN t.PlayerCount ELSE 0 END) AS H6
 , SUM(CASE DATEPART(hh, t.Time) WHEN 7 THEN t.PlayerCount ELSE 0 END) AS H7
 , SUM(CASE DATEPART(hh, t.Time) WHEN 8 THEN t.PlayerCount ELSE 0 END) AS H8
 , SUM(CASE DATEPART(hh, t.Time) WHEN 9 THEN t.PlayerCount ELSE 0 END) AS H9
 , SUM(CASE DATEPART(hh, t.Time) WHEN 10 THEN t.PlayerCount ELSE 0 END) AS H10
 , SUM(CASE DATEPART(hh, t.Time) WHEN 11 THEN t.PlayerCount ELSE 0 END) AS H11
 , SUM(CASE DATEPART(hh, t.Time) WHEN 12 THEN t.PlayerCount ELSE 0 END) AS H12
 , SUM(CASE DATEPART(hh, t.Time) WHEN 13 THEN t.PlayerCount ELSE 0 END) AS H13
 , SUM(CASE DATEPART(hh, t.Time) WHEN 14 THEN t.PlayerCount ELSE 0 END) AS H14
 , SUM(CASE DATEPART(hh, t.Time) WHEN 15 THEN t.PlayerCount ELSE 0 END) AS H15
 , SUM(CASE DATEPART(hh, t.Time) WHEN 16 THEN t.PlayerCount ELSE 0 END) AS H16
 , SUM(CASE DATEPART(hh, t.Time) WHEN 17 THEN t.PlayerCount ELSE 0 END) AS H17
 , SUM(CASE DATEPART(hh, t.Time) WHEN 18 THEN t.PlayerCount ELSE 0 END) AS H18
 , SUM(CASE DATEPART(hh, t.Time) WHEN 19 THEN t.PlayerCount ELSE 0 END) AS H19
 , SUM(CASE DATEPART(hh, t.Time) WHEN 20 THEN t.PlayerCount ELSE 0 END) AS H20
 , SUM(CASE DATEPART(hh, t.Time) WHEN 21 THEN t.PlayerCount ELSE 0 END) AS H21
 , SUM(CASE DATEPART(hh, t.Time) WHEN 22 THEN t.PlayerCount ELSE 0 END) AS H22
 , SUM(CASE DATEPART(hh, t.Time) WHEN 23 THEN t.PlayerCount ELSE 0 END) AS H23
 , SUM(t.PlayerCount) / 24 AS AVG
 FROM (
  SELECT ServerID
  , CASE(DATEPART(mi, Time) % 10)
    WHEN 0 THEN DATEADD(mi, -1, Time)
    ELSE DATEADD(mi, (DATEPART(mi, Time) % 10) * -1, Time) END
    AS Time
  , PlayerCount
  FROM LogDB.game.ServerLogStorage(NOLOCK)
  WHERE (Time BETWEEN @StartDate AND @EndDate) 
   AND (ServerID BETWEEN @StartServerID AND @EndServerID)
 ) AS t, ServerStatus ss(NOLOCK)
 WHERE ss.ServerID = t.ServerID
 GROUP BY ss.ServerID, ss.ServerName
 ORDER BY ss.ServerID
GO

-------------------------------------------------------------------------------------------------------------

CREATE   PROC [dbo].[spAdmWebGetServerLogMaxPlayerCntDay] 
 @ServerType tinyint  
, @StartDate smalldatetime
, @EndDate smalldatetime
AS
 SET NOCOUNT ON    

 IF @StartDate > @EndDate RETURN
 
 DECLARE @TmpStartDate smalldatetime
 DECLARE @TmpEndDate smalldatetime
 DECLARE @RangeStartDate smalldatetime
 DECLARE @RangeEndDate smalldatetime
 DECLARE @DayDiff int
 DECLARE @StartServerID tinyint    
 DECLARE @EndServerID tinyint    
 DECLARE @LiveServerCount tinyint   
 DECLARE @Date smalldatetime  
 DECLARE @Query varchar(8000)

 SELECT TOP 1 @TmpStartDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time 
 SELECT TOP 1 @TmpEndDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time DESC

 IF @StartDate < @TmpStartDate 
  SET @StartDate = @TmpStartDate
 IF @EndDate > @TmpEndDate
  SET @EndDate = @TmpEndDate

 SET @RangeStartDate = DATEADD(mi, -1, @StartDate)
 SET @RangeEndDate = DATEADD(mi, -1, @EndDate)
 SET @DayDiff = DATEDIFF(dd, @RangeStartDate, @RangeEndDate) + 1
    
 IF 0 = @ServerType SELECT @StartServerID = 1, @EndServerID = 255   -- all
 ELSE IF 1 = @ServerType SELECT @StartServerID = 1, @EndServerID = 49 -- normal    
 ELSE IF 2 = @ServerType SELECT @StartServerID = 50, @EndServerID = 99 -- clan    
 ELSE IF 3 = @ServerType SELECT @STartServerID = 100, @EndServerID = 149 -- quest    
 ELSE IF 4 = @ServerType RETURN-- event 
 ELSE RETURN    

 SELECT @LiveServerCount = COUNT(ServerID) 
 FROM ServerStatus(NOLOCK) 
 WHERE ServerID >= @StartServerID AND ServerID <= @EndServerID AND Opened <> 0    

 SET @Query = 'SELECT t.ServerID, t.ServerName, '    

 -- ???? ???? ??? ??? ?? 0?? ???.
 SET @Date = DATEADD(hh, DATEPART(hh, @RangeStartDate) * -1, @RangeStartDate)
 SET @Date = DATEADD(mi, DATEPART(mi, @RangeStartDate) * -1, @Date)

 WHILE @Date <= @RangeEndDate BEGIN
  SET @Query = @Query + 'MAX(CASE t.Day WHEN ' + CAST(DATEPART(dd, @Date) AS varchar(8))
   + ' THEN t.MaxPlayerCount ELSE 0 END)  AS ' + '''' + 'Day' 
   + CAST(DATEPART(dd, @Date) AS varchar(8)) + ''''

  SET @Date = DATEADD(dd, 1, @Date)
  IF @Date > @RangeEndDate BREAK
  SET @Query = @Query + ', '    
 END    

 SET @Query = @Query + ', SUM(MaxPlayerCount) / ' + CAST(@DayDiff AS varchar(8)) + ' AS AVG
 FROM
 (
 SELECT sls.ServerID, ss.ServerName, DATEPART(dd, DATEADD(mi, -1, sls.Time)) AS Day, MAX(PlayerCount) AS MaxPlayerCount
 FROM LogDB.game.ServerLogStorage sls(NOLOCK), ServerStatus ss(NOLOCK)
 WHERE sls.ServerID < 200 AND sls.ServerID >= ' + CAST(@StartServerID AS varchar(4)) 
  + ' AND sls.ServerID <= ' + CAST(@EndServerID AS varchar(4))
  + ' AND sls.Time >= ' + '''' + CAST(@StartDate AS varchar(64)) + '''' + ' 
  AND sls.Time <= ' + '''' + CAST(@EndDate AS varchar(64)) + '''' + '
  AND ss.ServerID = sls.ServerID
  GROUP BY sls.ServerID, ss.ServerName, DATEPART(dd, DATEADD(mi, -1, sls.Time))
 ) as t
 GROUP BY t.ServerID, t.ServerName
 ORDER BY t.ServerID'

 EXEC (@Query)
GO

----------------------------------------------------------------------------------------------------------------------------

CREATE  PROC [dbo].[spAdmWebGetServerLogMaxPlayerCntHour] 
 @ServerType tinyint  
, @StartDate smalldatetime  
, @EndDate smalldatetime  
AS  
 SET NOCOUNT ON  

 IF @StartDate > @EndDate RETURN

 DECLARE @StartServerID tinyint  
 DECLARE @EndServerID tinyint  

 IF 0 = @ServerType -- all  
  SELECT @StartServerID = 1, @EndServerID = 255  
 ELSE IF 1 = @ServerType -- normal  
  SELECT @StartServerID = 1, @EndServerID = 49  
 ELSE IF 2 = @ServerType -- clan  
  SELECT @StartServerID = 50, @EndServerID = 99  
 ELSE IF 3 = @ServerType -- quest  
  SELECT @STartServerID = 100, @EndServerID = 149  
 ELSE IF 4 = @ServerType -- event  
  RETURN  
 ELSE  
  RETURN  

SELECT t.ServerID, t.ServerName  
 , MAX(CASE t.Time WHEN 0 THEN t.MaxPlayerCount ELSE 0 END) AS H0  
 , MAX(CASE t.Time WHEN 1 THEN t.MaxPlayerCount ELSE 0 END) AS H1  
 , MAX(CASE t.Time WHEN 2 THEN t.MaxPlayerCount ELSE 0 END) AS H2  
 , MAX(CASE t.Time WHEN 3 THEN t.MaxPlayerCount ELSE 0 END) AS H3  
 , MAX(CASE t.Time WHEN 4 THEN t.MaxPlayerCount ELSE 0 END) AS H4  
 , MAX(CASE t.Time WHEN 5 THEN t.MaxPlayerCount ELSE 0 END) AS H5  
 , MAX(CASE t.Time WHEN 6 THEN t.MaxPlayerCount ELSE 0 END) AS H6  
 , MAX(CASE t.Time WHEN 7 THEN t.MaxPlayerCount ELSE 0 END) AS H7  
 , MAX(CASE t.Time WHEN 8 THEN t.MaxPlayerCount ELSE 0 END) AS H8  
 , MAX(CASE t.Time WHEN 9 THEN t.MaxPlayerCount ELSE 0 END) AS H9  
 , MAX(CASE t.Time WHEN 10 THEN t.MaxPlayerCount ELSE 0 END) AS H10  
 , MAX(CASE t.Time WHEN 11 THEN t.MaxPlayerCount ELSE 0 END) AS H11  
 , MAX(CASE t.Time WHEN 12 THEN t.MaxPlayerCount ELSE 0 END) AS H12  
 , MAX(CASE t.Time WHEN 13 THEN t.MaxPlayerCount ELSE 0 END) AS H13  
 , MAX(CASE t.Time WHEN 14 THEN t.MaxPlayerCount ELSE 0 END) AS H14  
 , MAX(CASE t.Time WHEN 15 THEN t.MaxPlayerCount ELSE 0 END) AS H15  
 , MAX(CASE t.Time WHEN 16 THEN t.MaxPlayerCount ELSE 0 END) AS H16  
 , MAX(CASE t.Time WHEN 17 THEN t.MaxPlayerCount ELSE 0 END) AS H17  
 , MAX(CASE t.Time WHEN 18 THEN t.MaxPlayerCount ELSE 0 END) AS H18  
 , MAX(CASE t.Time WHEN 19 THEN t.MaxPlayerCount ELSE 0 END) AS H19  
 , MAX(CASE t.Time WHEN 20 THEN t.MaxPlayerCount ELSE 0 END) AS H20  
 , MAX(CASE t.Time WHEN 21 THEN t.MaxPlayerCount ELSE 0 END) AS H21  
 , MAX(CASE t.Time WHEN 22 THEN t.MaxPlayerCount ELSE 0 END) AS H22  
 , MAX(CASE t.Time WHEN 23 THEN t.MaxPlayerCount ELSE 0 END) AS H23  
 , SUM(t.MaxPlayerCount) / 24 AS 'AVG'
 FROM (  
  SELECT sls.ServerID, ss.ServerName, DATEPART(hh, DATEADD(mi, -1, sls.Time)) AS Time, MAX(PlayerCount) as MaxPlayerCount
  FROM LogDB.game.ServerLogStorage sls(NOLOCK), ServerStatus ss(NOLOCK)
  WHERE (sls.Time BETWEEN @StartDate AND @EndDate)   
   AND (sls.ServerID BETWEEN @StartServerID AND @EndServerID)
   AND ss.ServerID = sls.ServerID
  GROUP BY sls.ServerID, ss.ServerName, DATEPART(hh, DATEADD(mi, -1, sls.Time))
 ) AS t 
 GROUP BY t.ServerID, t.ServerName 
 ORDER BY t.ServerID
GO

-------------------------------------------------------------------------------------------------------------

CREATE PROC [dbo].[spAdmWebGetServerLogMaxTimeDay]  
 @ServerType tinyint    
, @StartDate smalldatetime      
, @EndDate smalldatetime      
AS       
 SET NOCOUNT ON      
  
 IF @StartDate > @EndDate RETURN  
   
 DECLARE @TmpStartDate smalldatetime  
 DECLARE @TmpEndDate smalldatetime  
 DECLARE @RangeStartDate smalldatetime  
 DECLARE @RangeEndDate smalldatetime  
 DECLARE @DayDiff int  
 DECLARE @StartServerID tinyint      
 DECLARE @EndServerID tinyint      
 DECLARE @LiveServerCount tinyint     
 DECLARE @Date smalldatetime    
 DECLARE @Query varchar(8000)  
  
 SELECT TOP 1 @TmpStartDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time   
 SELECT TOP 1 @TmpEndDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time DESC  
  
 IF @StartDate < @TmpStartDate   
  SET @StartDate = @TmpStartDate  
 IF @EndDate > @TmpEndDate  
  SET @EndDate = @TmpEndDate  
  
 SET @RangeStartDate = DATEADD(mi, -1, @StartDate)  
 SET @RangeEndDate = DATEADD(mi, -1, @EndDate)  
 SET @DayDiff = DATEDIFF(dd, @RangeStartDate, @RangeEndDate) + 1  
      
 IF 0 = @ServerType SELECT @StartServerID = 1, @EndServerID = 255   -- all  
 ELSE IF 1 = @ServerType SELECT @StartServerID = 1, @EndServerID = 49 -- normal      
 ELSE IF 2 = @ServerType SELECT @StartServerID = 50, @EndServerID = 99 -- clan      
 ELSE IF 3 = @ServerType SELECT @STartServerID = 100, @EndServerID = 149 -- quest      
 ELSE IF 4 = @ServerType RETURN-- event   
 ELSE RETURN      
  
SELECT @LiveServerCount = COUNT(ServerID)   
 FROM ServerStatus(NOLOCK)   
 WHERE ServerID >= @StartServerID AND ServerID <= @EndServerID AND Opened <> 0      
  
 SET @Query = 'SELECT   
  t.TimeGroup  AS TimeGroup, '      
  
 -- ???? ???? ??? ??? ?? 0?? ???.  
 SET @Date = DATEADD(hh, DATEPART(hh, @RangeStartDate) * -1, @RangeStartDate)  
 SET @Date = DATEADD(mi, DATEPART(mi, @RangeStartDate) * -1, @Date)  
  
 WHILE @Date <= @RangeEndDate BEGIN  
  SET @Query = @Query + 'MAX(CASE t.Date WHEN ' + CAST(DATEPART(dd, @Date) AS varchar(8))  
    + ' THEN t.MaxPlayerCount ELSE 0 END) AS ' + '''' + 'Day' +      
   CAST(DATEPART(dd, @Date) AS varchar(8)) + ''''      
  
  SET @Date = DATEADD(dd, 1, @Date)  
  IF @Date > @RangeEndDate BREAK  
  SET @Query = @Query + ', '  
 END  
  
 SET @Query = @Query + ', SUM(t.MaxPlayerCount) / ' + CAST(@DayDiff AS varchar(8)) + ' AS AVG      
 FROM       
 (      
SELECT tt.Date, tt.TimeGroup, SUM(tt.MaxPlayerCount) as MaxPlayerCount  
 FROM  
 (  
 SELECT ServerID, DATEPART(dd, DATEADD(mi, -1, Time)) as Date   
   ,DATEPART(hh, DATEADD(mi, -1, Time)) AS TimeGroup,  
  MAX(PlayerCount) AS MaxPlayerCount  
  FROM LogDB.game.ServerLogStorage(NOLOCK)       
  WHERE Time >= ' + '''' + CAST(@StartDate AS varchar(64)) + '''' + '  AND Time <=  ' + '''' + CAST(@EndDate AS      
 varchar(64)) + '''' + ' AND ServerID >= ' + CAST(@StartServerID AS varchar(8)) + '  AND ServerID <=  ' + CAST(@EndServerID AS      
 varchar(8)) + '  
   GROUP BY ServerID, DATEPART(dd, DATEADD(mi, -1,Time))  
    , DATEPART(hh, DATEADD(mi, -1, Time))   
 ) AS tt  
GROUP BY tt.Date, tt.TimeGroup   
) AS t      
 GROUP BY t.TimeGroup      
 ORDER BY CAST(t.TimeGroup AS float)'  
  
 EXEC(@Query)
GO

----------------------------------------------------------------------------------------------------------------------

CREATE   PROC [dbo].[spAdmWebGetServerLogServerIDDay]
 @ServerType tinyint  
, @StartDate smalldatetime
, @EndDate smalldatetime
AS
 SET NOCOUNT ON    

 IF @StartDate > @EndDate RETURN
 
 DECLARE @TmpStartDate smalldatetime
 DECLARE @TmpEndDate smalldatetime
 DECLARE @RangeStartDate smalldatetime
 DECLARE @RangeEndDate smalldatetime
 DECLARE @DayDiff int
 DECLARE @StartServerID tinyint    
 DECLARE @EndServerID tinyint    
 DECLARE @LiveServerCount tinyint   
 DECLARE @Date smalldatetime  
 DECLARE @Query varchar(8000)

 SELECT TOP 1 @TmpStartDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time 
 SELECT TOP 1 @TmpEndDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time DESC

 IF @StartDate < @TmpStartDate 
  SET @StartDate = @TmpStartDate
 IF @EndDate > @TmpEndDate
  SET @EndDate = @TmpEndDate

 SET @RangeStartDate = DATEADD(mi, -1, @StartDate)
 SET @RangeEndDate = DATEADD(mi, -1, @EndDate)
 SET @DayDiff = DATEDIFF(dd, @RangeStartDate, @RangeEndDate) + 1
    
 IF 0 = @ServerType SELECT @StartServerID = 1, @EndServerID = 255   -- all
 ELSE IF 1 = @ServerType SELECT @StartServerID = 1, @EndServerID = 49 -- normal    
 ELSE IF 2 = @ServerType SELECT @StartServerID = 50, @EndServerID = 99 -- clan    
 ELSE IF 3 = @ServerType SELECT @STartServerID = 100, @EndServerID = 149 -- quest    
 ELSE IF 4 = @ServerType RETURN-- event 
 ELSE RETURN    

 SELECT @LiveServerCount = COUNT(ServerID) 
 FROM ServerStatus(NOLOCK) 
 WHERE ServerID >= @StartServerID AND ServerID <= @EndServerID AND Opened <> 0    

 SET @Query = 'SELECT sls.ServerID, ss.ServerName, '

 -- ???? ???? ??? ??? ?? 0?? ???.
 SET @Date = DATEADD(hh, DATEPART(hh, @RangeStartDate) * -1, @RangeStartDate)
 SET @Date = DATEADD(mi, DATEPART(mi, @RangeStartDate) * -1, @Date)

 WHILE @Date <= @RangeEndDate BEGIN
  SET @Query = @Query + '(SUM(CASE DATEPART(dd, DATEADD(mi, -1, sls.Time)) WHEN ' + CAST(DATEPART(dd, @Date) AS varchar(8))
   + ' THEN sls.PlayerCount ELSE 0 END) / 1440) AS ' + '''' + 'Day' 
   + CAST(DATEPART(dd, @Date) AS varchar(8)) + ''''

  SET @Date = DATEADD(dd, 1, @Date)
  IF @Date > @RangeEndDate BREAK
  SET @Query = @Query + ', '    
 END    

 SET @Query = @Query + ', SUM(sls.PlayerCount) / ' + CAST((@DayDiff * 1440) AS varchar(8)) + ' AS AVG
 FROM LogDB.game.ServerLogStorage sls(NOLOCK), ServerStatus ss(NOLOCK)
 WHERE sls.ServerID < 200 AND sls.ServerID >= ' + CAST(@StartServerID AS varchar(4)) 
  + ' AND sls.ServerID <= ' + CAST(@EndServerID AS varchar(4)) 
  + ' AND sls.Time >= ' + '''' + CAST(@StartDate AS varchar(64)) + '''' + ' 
  AND sls.Time <= ' + '''' + CAST(@EndDate AS varchar(64)) + '''' 
  + ' AND ss.ServerID = sls.ServerID
 GROUP BY sls.ServerID, ss.ServerName
 ORDER BY sls.ServerID'

 EXEC (@Query)
GO

--
-- Definition for stored procedure spAdmWebGetServerLogTimeDay : 
--
GO
CREATE PROC [dbo].[spAdmWebGetServerLogTimeDay]  
 @ServerType tinyint    
, @StartDate smalldatetime      
, @EndDate smalldatetime      
AS       
 SET NOCOUNT ON      
  
 IF @StartDate > @EndDate RETURN  
   
 DECLARE @TmpStartDate smalldatetime  
 DECLARE @TmpEndDate smalldatetime  
 DECLARE @RangeStartDate smalldatetime  
 DECLARE @RangeEndDate smalldatetime  
 DECLARE @DayDiff int  
 DECLARE @StartServerID tinyint      
 DECLARE @EndServerID tinyint      
 DECLARE @LiveServerCount tinyint     
 DECLARE @Date smalldatetime    
 DECLARE @Query varchar(8000)  
  
 SELECT TOP 1 @TmpStartDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time   
 SELECT TOP 1 @TmpEndDate = Time FROM LogDB.game.ServerLogStorage(NOLOCK) ORDER BY Time DESC  
  
 IF @StartDate < @TmpStartDate   
  SET @StartDate = @TmpStartDate  
 IF @EndDate > @TmpEndDate  
  SET @EndDate = @TmpEndDate  
  
 SET @RangeStartDate = DATEADD(mi, -1, @StartDate)  
 SET @RangeEndDate = DATEADD(mi, -1, @EndDate)  
 SET @DayDiff = DATEDIFF(dd, @RangeStartDate, @RangeEndDate) + 1  
      
 IF 0 = @ServerType SELECT @StartServerID = 1, @EndServerID = 255   -- all  
 ELSE IF 1 = @ServerType SELECT @StartServerID = 1, @EndServerID = 49 -- normal      
 ELSE IF 2 = @ServerType SELECT @StartServerID = 50, @EndServerID = 99 -- clan      
 ELSE IF 3 = @ServerType SELECT @STartServerID = 100, @EndServerID = 149 -- quest      
 ELSE IF 4 = @ServerType RETURN-- event   
 ELSE RETURN      
  
  
 SELECT @LiveServerCount = COUNT(ServerID)   
 FROM ServerStatus(NOLOCK)   
 WHERE ServerID >= @StartServerID AND ServerID <= @EndServerID AND Opened <> 0      
  
 SET @Query = 'SELECT t.TimeGroup, '      
  
 -- ???? ???? ??? ??? ?? 0?? ???.  
 SET @Date = DATEADD(hh, DATEPART(hh, @RangeStartDate) * -1, @RangeStartDate)  
 SET @Date = DATEADD(mi, DATEPART(mi, @RangeStartDate) * -1, @Date)  
  
 WHILE @Date <= @RangeEndDate BEGIN  
    SET @Query = @Query + 'SUM(CASE t.Date WHEN ' + CAST(DATEPART(dd, @Date) AS varchar(8))  
    + ' THEN t.PlayerCount ELSE 0 END) AS ' + '''' + 'Day' +      
   CAST(DATEPART(dd, @Date) AS varchar(8)) + ''''      
  
  SET @Date = DATEADD(dd, 1, @Date)  
  IF @Date > @RangeEndDate BREAK  
  SET @Query = @Query + ', '  
 END  
  
 SET @Query = @Query + ', SUM(t.PlayerCount) / ' + CAST((@DayDiff  ) AS varchar(8)) + ' AS AVG  FROM       
 (     
 SELECT  tt.Date, tt.TimeGroup as TimeGroup,SUM(tt.PlayerCount )  as PlayerCount  
 FROM  
 (  
  SELECT SUM(PlayerCount ) /60 as PlayerCount, ServerID  
 ,DATEPART(dd, Time) as Date  
 ,DATEPART(hh, DATEADD(mi, -1, Time)) as TimeGroup  
  FROM LogDB.game.ServerLogStorage(NOLOCK)       
  WHERE Time >= ' + '''' + CAST(@StartDate AS varchar(64)) + '''' + '  AND Time <= ' + '''' + CAST(@EndDate AS      
 varchar(64)) + '''' + '  AND ServerID >= ' + CAST(@StartServerID AS varchar(8)) + '   AND ServerID <= ' + CAST(@EndServerID AS      
 varchar(8)) + '   
 GROUP BY DATEPART(dd, Time), DATEPART(hh, DATEADD(mi, -1, Time)), ServerID  
   
 ) as tt  
 GROUP BY tt.Date, tt.TimeGroup  
 ) AS t      
 GROUP BY  t.TimeGroup      
 ORDER BY  t.TimeGroup'      
  
 EXEC (@Query)
GO

--
-- Definition for stored procedure spAdmWebGetSetItemPurchaseLogByCash : 
--
GO
CREATE PROC [dbo].[spAdmWebGetSetItemPurchaseLogByCash]  
 @AID int  
AS  
 SET NOCOUNT ON  
 SELECT sipl.id, a.UserID AS SenderUserID, a.UserID AS ReceiverUserID
  , css.Name AS ItemName, sipl.Date, sipl.Cash  
  , CASE ISNULL(sipl.RentHourPeriod, 0)
   WHEN 0 THEN '0'
   ELSE CAST(sipl.RentHourPeriod AS varchar(10))
  END AS 'RentHourPeriod'
 FROM (Account a(NOLOCK) JOIN SetItemPurchaseLogByCash sipl(NOLOCK)  
 ON a.AID = @AID AND sipl.AID = a.AID) JOIN CashSetShop css(NOLOCK)  
 ON css.CSSID = sipl.CSSID  
 ORDER BY Date DESC
GO

--
-- Definition for stored procedure spAdmWebGetSimpleLiveCharInfoByOneCharName : 
--
GO
CREATE PROC [dbo].[spAdmWebGetSimpleLiveCharInfoByOneCharName]
	@CharName varchar( 24 )
AS
	SET NOCOUNT ON

	DECLARE @AID int
	
	SELECT @AID = a.AID
	FROM Character c(NOLOCK) JOIN Account a(NOLOCK)
	ON c.Name = @CharName AND a.AID = c.AID

	IF @AID IS NULL RETURN

	SELECT Name, CID FROM Character(NOLOCK) WHERE AID = @AID AND DeleteFlag <> 1
	ORDER BY CharNum
GO

--
-- Definition for stored procedure spAdmWebGetUniqueQuestItemInfo : 
--
GO
CREATE PROC [dbo].[spAdmWebGetUniqueQuestItemInfo]
 @CID int
AS
 SET NOCOUNT ON 

 SELECT qi.Name, qgl.StartTime, qgl.EndTime
 FROM QuestGameLog qgl(NOLOCK), QUniqueItemLog qul(NOLOCK), QuestItem qi(NOLOCK)
 WHERE qgl.ID = qul.QGLID AND qul.QIID = qi.QIID AND qul.CID = @CID
 ORDER BY qgl.StartTime DESC
GO

--
-- Definition for stored procedure spAdmWebGetUV : 
--
GO
CREATE PROC [dbo].[spAdmWebGetUV] 
 @StartDate smalldatetime
, @EndDate smalldatetime
AS
 SET NOCOUNT ON

 IF @StartDate > @EndDate RETURN
 IF 3 < DATEDIFF(dd, @StartDate, @EndDate) RETURN

 SELECT  t.Time, COUNT(t.AID) as UCount
 FROM
 (
 SELECT AID, CONVERT(char(10),Time,120) as Time
 FROM LogDB.game.ConnLog(NOLOCK) 
 WHERE time >= @StartDate and time <= @EndDate
 GROUP BY AID, CONVERT(char(10),Time,120)
 ) as t
 GROUP BY t.Time 
 ORDER BY t.Time
GO

--
-- Definition for stored procedure spAdmWebInsertAccountItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertAccountItem]
 @AID int
, @ItemID int
, @Period int 
, @GMID varchar(20)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 IF (500001 > @ItemID) OR ((@Period IS NOT NULL) AND (0 > @Period)) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 IF NOT EXISTS (SELECT AID FROM Account(NOLOCK) WHERE AID = @AID) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 DECLARE @RentHourPeriod int
 DECLARE @RentDate datetime
	
 IF (0 = @Period) OR (@Period IS NULL)
  SELECT @RentHourPeriod = NULL, @RentDate = NULL
 ELSE
  SELECT @RentHourPeriod = @Period, @RentDate = GETDATE()

 INSERT INTO AccountItem( AID, ItemID, RentDate, RentHourPeriod)
 VALUES (@AID, @ItemID, @RentDate, @RentHourPeriod )
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertCashSetShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertCashSetShopItem]
 @Name varchar(64)
, @ResSex tinyint
, @ResLevel int
, @Weight int
, @Description varchar(1024)
, @Opened tinyint
, @CashPrice int
, @WebImgName varchar(64)
, @RentType tinyint
, @Ret int OUTPUT
AS
 SET NOCOUNT ON 
 IF (@Name IS NULL) OR (@ResSex IS NULL) OR (@ResLevel IS NULL) 
  OR (@Weight IS NULL) OR (@Description IS NULL) OR (@Opened IS NULL)
  OR (@CashPrice IS NULL) OR (@WebImgName IS NULL) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 declare @cssid int
 select @cssid = max(cssid) + 1 from CashSetShop(nolock)

 INSERT INTO CashSetShop(cssid, Name, ResSex, ResLevel, Weight, Description, Opened,
  CashPrice, WebImgName, RentType, RegDate)
 VALUES (@cssid, @Name, @ResSex, @ResLevel, @Weight, @Description, @Opened,
  @CashPrice, @WebImgName, @RentType, GETDATE())
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 SET @Ret = @cssid
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertCashShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertCashShopItem]  
 @ItemID int  
, @Opened tinyint  
, @CashPrice int  
, @WebImgName varchar(64)  
, @RentType tinyint  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
 IF (@ItemID IS NULL) OR (500000 > @ItemID) OR (@Opened IS NULL)
  OR (@CashPrice IS NULL) BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  

 declare @csid int

 select @csid = max(csid) + 1 from CashShop(nolock) 
  
 INSERT INTO CashShop(csid,  ItemID, Opened, CashPrice, WebImgName, RegDate, RentType )  
 VALUES (@csid, @ItemID, @Opened, @CashPrice, @WebImgName, GETDATE(), @RentType)  
 IF 0 <> @@ERROR BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
   
 SET @Ret = @csid
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertCharacterItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertCharacterItem]
	@CID int
,	@ItemID int
,	@Period smallint 
,	@GMID varchar(20)
,	@Ret int OUTPUT
AS
	SET NOCOUNT ON 
	IF (500000 < @ItemID) OR ((@Period IS NOT NULL) AND (0 > @Period)) BEGIN
		SET @Ret = 0
		RETURN @Ret
	END

	IF NOT EXISTS( SELECT CID FROM Character(NOLOCK) WHERE CID = @CID) BEGIN
		SET @Ret = 0
		RETURN @Ret
	END

	DECLARE @RentHourPeriod smallint
	DECLARE @RentDate datetime
	
	IF (0 = @Period) OR (@Period IS NULL)
		SELECT @RentHourPeriod = NULL, @RentDate = NULL
	ELSE
		SELECT @RentHourPeriod = @Period, @RentDate = GETDATE()

	INSERT INTO CharacterItem( CID, ItemID, RegDate, RentDate, RentHourPeriod )
	VALUES (@CID, @ItemID, GETDATE(), @RentDate, @RentHourPeriod )
	IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
		SET @Ret = 0
		RETURN @Ret
	END

	SET @Ret = 1
	RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertCustomIP : 
--
GO
/*  
 * @Ret(0:Fail, 1:Success, 2:Duplicate, 3:Invers range)  
 */  
CREATE PROC [dbo].[spAdmWebInsertCustomIP]  
 @IPFrom varchar(15)  
, @IPTo varchar(15)  
, @IsBlock tinyint  
, @CountryCode3 char(3)  
, @Comment varchar(128)  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
 DECLARE @DupRet int  
 DECLARE @TmpIPFrom BIGINT  
 DECLARE @TmpIPTo BIGINT  
  
 SET @TmpIPFrom = GunzDB.game.inet_aton( @IPFrom )  
 SET @TmpIPTo = GunzDB.game.inet_aton( @IPTo )  
 IF @TmpIPFrom > @TmpIPTo BEGIN  
  SET @Ret = 3  
  RETURN @Ret  
 END  
  
 EXEC spIPFltCheckIsDuplicateRange @TmpIPFrom, @TmpIPTo, @DupRet OUTPUT  
 IF 1 = @DupRet BEGIN  
  SET @Ret = 2  
  RETURN @Ret  
 END   
  
 INSERT INTO CustomIP(IPFrom, IPTo, CountryCode3, IsBlock, Comment, RegDate)  
 VALUES (@TmpIPFrom, @TmpIPTo, @CountryCode3, @IsBlock, @Comment, GETDATE() )  
 IF 0 <> @@ERROR SET @Ret = 0  
 ELSE SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertOneCashSetItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertOneCashSetItem]
 @CSSID int
, @CSID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 IF (@CSSID IS NULL) OR (@CSID IS NULL) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 INSERT INTO CashSetItem(CSSID, CSID) VALUES (@CSSID, @CSID)
 IF 0 <> @@ERROR BEGIN
  SET @Ret = 0
  RETURN @Ret
 END
 
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertRentCashSetShopPrice : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertRentCashSetShopPrice]  
 @CSSID int  
, @RentHourPeriod int  
, @CashPrice int  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
 IF (@CSSID IS NULL) OR (@CashPrice IS NULL) BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  

 IF 0 = @RentHourPeriod SET @RentHourPeriod = NULL
  
 INSERT INTO RentCashSetShopPrice(CSSID, RentHourPeriod, CashPrice)  
 VALUES (@CSSID, @RentHourPeriod, @CashPrice)  
 IF 0 <> @@ERROR BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
  
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertRentCashShopPrice : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertRentCashShopPrice]  
 @CSID int  
, @RentHourPeriod int  
, @CashPrice int  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON  
  
 IF (@CSID IS NULL) OR (@CashPrice IS NULL) BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  

 IF 0 = @RentHourPeriod SET @RentHourPeriod = NULL
  
 INSERT INTO RentCashShopPrice(CSID, RentHourPeriod, CashPrice)  
 VALUES (@CSID, @RentHourPeriod, @CashPrice)  
 IF 0 <> @@ERROR BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebInsertSetItem : 
--
GO
CREATE PROC [dbo].[spAdmWebInsertSetItem]
	@UserID varchar( 20 )
,	@CSSID int
,	@RentHourPeriod smallint
,	@GMID varchar(20)
,	@Ret int OUTPUT
AS 
 SET NOCOUNT ON
  
 DECLARE @AID  int  
   
 SELECT @AID = AID FROM Account WHERE UserID = @UserID  
  
 -- ???? ???? ??.  
 IF @AID IS NULL  
 BEGIN  
  SET @Ret = 0
  RETURN @Ret
 END  
 ELSE  
 BEGIN  
  DECLARE @RentDate  datetime     
  
  -- @RentHourPeriod?? ??? ????? ??.  
  IF @RentHourPeriod = 0 OR @RentHourPeriod IS NULL  
  BEGIN  
   -- ??? ???? ?? ?? ??? ?? ?? ??  
   DECLARE @RentType  TINYINT  
   DECLARE @RCSSPID  INT  
  
   SELECT @RentType = RentType FROM CashSetShop WHERE CSSID=@CSSID  
   IF @RentType = 1  
   BEGIN  
    SELECT @RCSSPID = RCSSPID FROM RentCashSetShopPrice WHERE CSSID=@CSSID AND RentHourPeriod is NULL  
    IF @RCSSPID IS NULL  
    BEGIN  
     SET @Ret = 0
     RETURN @Ret
    END  
   END  
  
   -- ?? ???? ??  
   SET @RentDate = NULL  
  END  
  ELSE  
  BEGIN  
   SET @RentDate = GETDATE()  
  END  
      
  BEGIN TRAN  
  
  DECLARE curBuyCashSetItem  INSENSITIVE CURSOR  
  
  FOR  
   SELECT CSID FROM CashSetItem (NOLOCK) WHERE CSSID = @CSSID  
  FOR READ ONLY  
  
  OPEN curBuyCashSetItem   
  
  DECLARE @varCSID  int  
  DECLARE @ItemID   int  
  
  FETCH FROM curBuyCashSetItem INTO @varCSID  
  
  WHILE @@FETCH_STATUS = 0  
  BEGIN  
   SELECT @ItemID = cs.ItemID  
   FROM CashShop cs (NOLOCK)   
   WHERE cs.CSID = @varCSID   
  
   IF @ItemID IS NOT NULL  
   BEGIN  
    -- ??? ??.  
    INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod)  
    VALUES (@AID, @ItemID, @RentDate, @RentHourPeriod)  
   END  
  
   FETCH curBuyCashSetItem  INTO @varCSID  
  END  
  
  CLOSE curBuyCashSetItem   
  DEALLOCATE curBuyCashSetItem   
  
  -- GM?? ??.
  
  COMMIT TRAN  
  SET @Ret = 1
  RETURN @Ret
 END
GO

--
-- Definition for stored procedure spAdmWebItemUseLog : 
--
GO
CREATE PROC [dbo].[spAdmWebItemUseLog]  
 @UserID  VARCHAR(32)  
AS  
BEGIN  
 SET NOCOUNT ON 
 DECLARE @TargetAID INT  
 SELECT @TargetAID = AID FROM Account(NOLOCK) WHERE UserID=@UserID  
  
 SELECT l.AID, l.CID, c.Name AS CharName, i.ItemID, i.Name AS ItemName, l.Date, c.DeleteName   
 FROM BringAccountItemLog l(NOLOCK), Item i(NOLOCK), Character c(NOLOCK)  
 WHERE l.AID=@TargetAID AND l.CID=c.CID AND l.ItemID=i.ItemID  
 ORDER BY  Date DESC  
END
GO

--
-- Definition for stored procedure spAdmWebLeaveClanByCID : 
--
GO
CREATE PROC [dbo].[spAdmWebLeaveClanByCID]  
 @CID int /* ???? ??? CID */  
, @GMID varchar(20)
, @Ret int OUTPUT
AS  
 IF (@CID IS NULL) OR (@GMID IS NULL) BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 DECLARE @CLID int  
 DECLARE @MasterCID int  
  
 -- ???? ??????  
 SELECT @CLID = cm.CLID, @MasterCID = cl.MasterCID  
 FROM Clan cl(NOLOCK), ClanMember cm(NOLOCK)  
 WHERE cm.CID = @CID AND cl.CLID = cm.CLID  
  
 -- ?????? ??? ??? ??? ?? ???.  
 IF (@CID IS NULL) OR (@MasterCID = @CID) OR (@CLID IS NULL) BEGIN  
  SET @Ret = 0
  RETURN @Ret
 END  
    
 DELETE ClanMember WHERE CID = @CID  
 IF 0 <> @@ERROR  
 BEGIN  
  SET @Ret = 0
  RETURN @Ret
 END  
  
 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUndeleteCharacter : 
--
GO
CREATE   PROC [dbo].[spAdmWebUndeleteCharacter]    
 @AID int    
, @CID int
, @GMID varchar(20)  
, @Ret int OUTPUT    
AS    
 SET NOCOUNT ON   
  
 IF EXISTS (SELECT LiveChar.CID FROM Character DelChar(NOLOCK) JOIN Character LiveChar(NOLOCK)
	ON DelChar.CID = @CID AND DelChar.DeleteFlag = 1 AND LiveChar.Name = DelChar.DeleteName
	WHERE LiveChar.DeleteFlag <> 1) BEGIN
  SET @Ret = 0    
  RETURN @Ret   
 END    
  
 DECLARE @CharCount int     
    
 SELECT @CharCount = COUNT(CID) FROM Character(NOLOCK) WHERE AID = @AID AND DeleteFlag <> 1    
 IF 4 > @CharCount BEGIN     
  DECLARE @FreeNum int    
  DECLARE @tb table( a int )  
  
  INSERT @tb VALUES( 0 )  
  INSERT @tb VALUES( 1 )  
  INSERT @tb VALUES( 2 )  
  INSERT @tb VALUES( 3 )  
  
  SELECT TOP 1 @FreeNum = t.a  
  FROM @tb t LEFT OUTER JOIN Character c(NOLOCK)  
  ON c.AID = @AID AND c.DeleteFlag <> 1 AND c.CharNum = t.a  
  WHERE c.CharNum IS NULL  
  
  IF @FreeNum IS NULL BEGIN    
   SET @Ret = 0    
   RETURN @Ret    
  END    
    
  BEGIN TRAN    
  UPDATE Character     
  SET Name = DeleteName, CharNum = @FreeNum, DeleteFlag = 0, DeleteName = ''
  WHERE CID = @CID AND AID = @AID AND DeleteFlag = 1 
  IF 0 = @@ROWCOUNT BEGIN    
   ROLLBACK TRAN    
   SET @Ret = 0    
   RETURN  @Ret  
  END    
  COMMIT TRAN    
  SET @Ret = 1    
  RETURN @Ret  
 END
GO

--
-- Definition for stored procedure spAdmWebUpdateAccountPenaltyPeriod : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateAccountPenaltyPeriod]
	@AID int
,	@UGradeID int
,	@Period int 
,	@GMID varchar(20)
,	@Ret int OUTPUT
AS
	SET NOCOUNT ON

	IF NOT EXISTS (SELECT AID FROM Account(NOLOCK) WHERE AID = @AID) BEGIN
		SET @Ret = 0
		RETURN @Ret
	END

	IF (0 > @Period) OR (@Period IS NULL) OR (0 > @UGradeID) OR (@UGradeID IS NULL) BEGIN
		SET @Ret = 0
		RETURN @Ret
	END

	BEGIN TRAN
	UPDATE Account SET UGradeID = @UGradeID WHERE AID = @AID
	IF 0 = @@ROWCOUNT BEGIN
		ROLLBACK TRAN
		SET @Ret = 0
		RETURN @Ret
	END

	IF NOT EXISTS (SELECT AID FROM AccountPenaltyPeriod(NOLOCK) WHERE AID = @AID) BEGIN
		IF 0 < @Period BEGIN
			-- ?? ??? ????.
			INSERT INTO AccountPenaltyPeriod( AID, DayLeft ) VALUES (@AID, @Period)
			IF 0 <> @@ERROR BEGIN 
				ROLLBACK TRAN
				SET @Ret = 0
				RETURN @Ret
			END
		END
	END
	ELSE BEGIN
		IF 0 < @Period BEGIN
			-- ?? ?? ??? ???? ??? ???.
			UPDATE AccountPenaltyPeriod SET DayLeft = @Period WHERE AID = @AID
				IF 0 = @@ROWCOUNT BEGIN
				ROLLBACK TRAN
				SET @Ret = 0
				RETURN @Ret
			END
		END
		ELSE BEGIN
			DELETE AccountPenaltyPeriod WHERE AID = @AID
			IF 0 <> @@ERROR BEGIN
				ROLLBACK TRAN	
				SET @Ret = 0
				RETURN @Ret
			END
		END
	END

	INSERT INTO AccountPenaltyLog( AID, UGradeID, DayLeft, RegDate, GMID )
	VALUES (@AID, @UGradeID, @Period, GETDATE(), @GMID )
	IF 0 <> @@ERROR BEGIN 
		ROLLBACK TRAN
		SET @Ret = 0
		RETURN @Ret
	END
	COMMIT TRAN

	SET @Ret = 1
	RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateBlockCountryCode : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateBlockCountryCode]  
 @CountryCode3 char(3)  
, @RoutingURL varchar(64)  
, @IsBlock tinyint  
, @Ret int Output  
AS  
 SET NOCOUNT ON  
 UPDATE BlockCountryCode   
 SET RoutingURL = @RoutingURL , IsBlock = @IsBlock  
 WHERE CountryCode3 = @CountryCode3   
 IF 0 = @@ROWCOUNT SET @Ret = 0  
 ELSE SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateCashSetShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateCashSetShopItem]  
 @CSSID int  
, @Name varchar(64)
, @ResSex tinyint  
, @ResLevel int  
, @Weight int  
, @Description varchar(1024)
, @Opened tinyint  
, @CashPrice int  
, @WebImgName varchar(64)  
, @RentType tinyint
, @Ret int OUTPUT  
 AS  
 SET NOCOUNT ON  
 IF (@CSSID IS NULL) OR (@ResSex IS NULL) OR (@Weight IS NULL)  
  OR (@Opened IS NULL) OR (@Description IS NULL ) OR (@CashPrice IS NULL)
  OR (@WebImgName IS NULL) OR (@RentType IS NULL) OR (@Name IS NULL) BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
  
 UPDATE CashSetShop  
 SET ResSex = @ResSex, ResLevel = @ResLevel, Weight = @Weight,   
  Description = @Description, Opened = @Opened, CashPrice = @CashPrice,   
  WebImgName = @WebImgName, RentType = @RentType, Name = @Name
 WHERE CSSID = @CSSID  
 IF 0 = @@ROWCOUNT BEGIN  
  SET @Ret = 0  
  RETURN   
 END  
  
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateCashShopItem : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateCashShopItem]  
 @CSID int  
, @Opened tinyint  
, @CashPrice int  
, @WebImgName varchar(64)  
, @RentType tinyint
, @Ret int OUTPUT  
AS  
 UPDATE CashShop   
 SET Opened = @Opened, CashPrice = @CashPrice, WebImgName = @WebImgName,
  RentType = @RentType
 WHERE CSID = @CSID  
 IF 0 = @@ROWCOUNT BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
   
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateCashShopNewItem : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateCashShopNewItem]
 @NewOrder int
, @CSID int
, @CSSID int
, @IsSetItem int
, @CategoryID int
, @Ret int OUTPUT
AS
 SET NOCOUNT ON

 DECLARE @Category varchar(12)
 SELECT @Category = Description FROM CashShopNewItemCategory(NOLOCK)
 WHERE CategoryID = @CategoryID

 IF 0 = @IsSetItem BEGIN
  UPDATE CashShopNewItem 
  SET Category = @Category, NewOrder = @NewOrder, IsSetItem = @IsSetItem,
   CSID = @CSID, CSSID = @CSSID, Slot = ist.Description, Name = i.Name,
   ResSex = i.ResSex, ResLevel = i.ResLevel, CashPrice = cs.CashPrice, 
   WebImgName = cs.WebImgName, RegDate = cs.RegDate
  FROM (Item i(NOLOCK) JOIN CashShop cs(NOLOCK)
  ON cs.CSID = @CSID AND i.ItemID = cs.ItemID) 
   JOIN ItemSlotType ist(NOLOCK) ON ist.SlotType = i.Slot
  WHERE NewOrder = @NewOrder
  IF 0 = @@ROWCOUNT BEGIN
   SET @Ret = 0
   RETURN @Ret
  END
 END
 ELSE IF 1 = @IsSetItem BEGIN
  UPDATE CashShopNewItem
  SET Category = @Category, NewOrder = @NewOrder, IsSetItem = @IsSetItem,
   CSID = @CSID, CSSID = @CSSID, Slot = ist.Description, Name = css.Name,
   ResSex = css.ResSex, ResLevel = css.ResLevel, CashPrice = css.CashPrice,
   WebImgName = css.WebImgName, RegDate = css.RegDate
  FROM CashSetShop css(NOLOCK) JOIN ItemSlotType ist(NOLOCK)
  ON css.CSSID = @CSSID AND ist.SlotType = 10
  WHERE NewOrder = @NewOrder
  IF 0 = @@ROWCOUNT BEGIN
   SET @Ret = 0
   RETURN @Ret
  END
 END

 SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateCustomIP : 
--
GO
/*  
 * @Ret(0:Fail, 1:Success, 2:Duplicate, 3:Invers range)  
 */  
CREATE PROC [dbo].[spAdmWebUpdateCustomIP]  
 @IPFrom varchar(15)  
, @IPTo varchar(15)  
, @NewIPFrom varchar(15)  
, @NewIPTo varchar(15)  
, @IsBlock tinyint  
, @CountryCode3 char(3)  
, @Comment varchar(128)  
, @Ret int OUTPUT  
AS  
 SET NOCOUNT ON   
 DECLARE @DupRet bigint  
 DECLARE @TmpIPFrom BIGINT  
 DECLARE @TmpIPTo BIGINT  
 DECLARE @TmpNewIPFrom bigint  
 DECLARE @TmpNewIPTo bigint  
  
 SET @TmpIPFrom = GunzDB.game.inet_aton( @IPFrom )  
 SET @TmpIPTo = GunzDB.game.inet_aton( @IPTo )  
  
 IF @TmpIPFrom > @TmpIPTo BEGIN  
  SET @Ret = 3  
  RETURN @Ret  
 END  
  
 SET @TmpNewIPFrom = GunzDB.game.inet_aton( @NewIPFrom )  
 SET @TmpNewIPTo = GunzDB.game.inet_aton( @NewIPTo )  
  
 IF @TmpNewIPFrom > @TmpNewIPTo BEGIN  
  SET @Ret = 0  
  RETURN @Ret  
 END  
  
 -- ?? IP??? ??? IP?? ?? ?? ???? ???? ??.  
 IF (@TmpIPFrom <> @TmpNewIPFrom) OR (@TmpIPTo <> @TmpNewIPTo) BEGIN  
  EXEC spIPFltCheckIsDuplicateRange @TmpNewIPFrom, @TmpNewIPTo, @DupRet OUTPUT  
  IF 1 = @DupRet BEGIN   
   SET @Ret = 2  
   RETURN @Ret  
  END  
 END  
  
 UPDATE CustomIP  
 SET IPFrom = @TmpNewIPFrom, IPTo = @TmpNewIPTo,  
  IsBlock = @IsBlock, CountryCode3 = @CountryCode3,  
  Comment = @Comment  
 WHERE IPFrom = @TmpIPFrom AND IPTo = @TmpIPTo  
 IF 0 <> @@ERROR OR 0 = @@ROWCOUNT SET @Ret = 0  
 ELSE SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spAdmWebUpdateQuestItemInfo : 
--
GO
CREATE PROC [dbo].[spAdmWebUpdateQuestItemInfo]
 @CID int
, @QuestItemInfo binary(292)
AS
 SET NOCOUNT ON 
 UPDATE Character
 SET QuestItemInfo = @QuestItemInfo
 WHERE CID = @CID
GO

-- ?? ??? ? ???? ???? ----------
CREATE PROC [dbo].[spBringAccountItem]
	@AID		int,
	@CID		int,
	@AIID		int
AS
SET NoCount On

DECLARE @ItemID int
DECLARE @CAID int
DECLARE @OrderCIID int

DECLARE @RentDate			DATETIME
DECLARE @RentHourPeriod		SMALLINT
DECLARE @Cnt				SMALLINT

SELECT @ItemID=ItemID, @RentDate=RentDate, @RentHourPeriod=RentHourPeriod, @Cnt=Cnt
FROM AccountItem WHERE AIID = @AIID


SELECT @CAID = AID FROM Character WHERE CID=@CID

IF @ItemID IS NOT NULL AND @CAID = @AID
BEGIN
	BEGIN TRAN ----------------
	DELETE FROM AccountItem WHERE AIID = @AIID
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN 
		RETURN
	END

	INSERT INTO CharacterItem (CID, ItemID, RegDate, RentDate, RentHourPeriod, Cnt)
	VALUES (@CID, @ItemID, GETDATE(), @RentDate, @RentHourPeriod, @Cnt)
	IF 0 <> @@ERROR BEGIN 
		ROLLBACK TRAN
		RETURN 
	END

	SET @OrderCIID = @@IDENTITY

	INSERT INTO BringAccountItemLog	(ItemID, AID, CID, Date)
	VALUES (@ItemID, @AID, @CID, GETDATE())
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		RETURN
	END

	COMMIT TRAN ---------------

	SELECT @OrderCIID AS ORDERCIID, @ItemID AS ItemID, (@RentHourPeriod*60) - (DateDiff(n, @RentDate, GETDATE())) AS RentPeriodRemainder
END
GO

--
-- Definition for stored procedure spBringAccountItem2 : 
--
GO
CREATE PROC [dbo].[spBringAccountItem2]  
 @AID  int,  
 @CID  int,  
 @AIID  int  
AS  
SET NoCount On  
  
DECLARE @ItemID int  
DECLARE @CAID int  
DECLARE @OrderCIID int  
  
DECLARE @RentDate   DATETIME  
DECLARE @RentHourPeriod  SMALLINT  
DECLARE @Cnt    SMALLINT  
  
SELECT @ItemID=ItemID, @RentDate=RentDate, @RentHourPeriod=RentHourPeriod, @Cnt=Cnt  
FROM AccountItem WHERE AIID = @AIID  
  
  
SELECT @CAID = AID FROM Character WHERE CID=@CID  
  
IF @ItemID IS NOT NULL AND @CAID = @AID  
BEGIN  
 BEGIN TRAN ----------------  
 DELETE FROM AccountItem WHERE AIID = @AIID  
 IF 0 <> @@ERROR BEGIN  
  ROLLBACK TRAN   
  RETURN  
 END  
  
 INSERT INTO CharacterItem (CID, ItemID, RegDate, RentDate, RentHourPeriod, Cnt)  
 VALUES (@CID, @ItemID, GETDATE(), @RentDate, @RentHourPeriod, @Cnt)  
 IF 0 <> @@ERROR BEGIN   
  ROLLBACK TRAN  
  RETURN   
 END  
  
 SET @OrderCIID = @@IDENTITY  
  
 INSERT INTO BringAccountItemLog (ItemID, AID, CID, Date)  
 VALUES (@ItemID, @AID, @CID, GETDATE())  
 IF 0 <> @@ERROR BEGIN  
  ROLLBACK TRAN  
  RETURN  
 END  
  
 COMMIT TRAN ---------------  
  
 SELECT @OrderCIID AS ORDERCIID, @ItemID AS ItemID
  , @RentHourPeriod as 'RentHourPeriod'
  , (@RentHourPeriod*60) - (DateDiff(n, @RentDate, GETDATE())) AS RentPeriodRemainder  
END
GO

-- ? ??? ?????? ??? ?? ---------
CREATE PROC [dbo].[spBringBackAccountItem]
	@AID		int,
	@CID		int,
	@CIID		int
AS
SET NOCOUNT ON

DECLARE @ItemID int
DECLARE @RentDate		DATETIME
DECLARE @RentHourPeriod	SMALLINT
DECLARE @Cnt			SMALLINT

DECLARE @HeadCIID 	int
DECLARE @ChestCIID	int
DECLARE @HandsCIID	int
DECLARE @LegsCIID	int
DECLARE @FeetCIID	int
DECLARE @FingerLCIID	int
DECLARE @FingerRCIID	int
DECLARE @MeleeCIID	int
DECLARE @PrimaryCIID	int
DECLARE @SecondaryCIID	int
DECLARE @Custom1CIID	int
DECLARE @Custom2CIID	int

SELECT 
@HeadCIID=head_slot, @ChestCIID=chest_slot, @HandsCIID=hands_slot, 
@LegsCIID=legs_slot, @FeetCIID=feet_slot, @FingerLCIID=fingerl_slot, @FingerRCIID=fingerr_slot, 
@MeleeCIID=melee_slot, @PrimaryCIID=primary_slot, @SecondaryCIID=secondary_slot, 
@Custom1CIID=custom1_slot, @Custom2CIID=custom2_slot
FROM Character(nolock) WHERE cid=@CID AND aid=@AID

SELECT @ItemID=ItemID, @RentDate=RentDate, @RentHourPeriod=RentHourPeriod, @Cnt=Cnt
FROM CharacterItem WHERE CIID=@CIID AND CID=@CID

IF ((@ItemID IS NOT NULL) AND (@ItemID >= 400000) AND
   (@HeadCIID IS NULL OR @HeadCIID != @CIID) AND
   (@ChestCIID IS NULL OR @ChestCIID != @CIID) AND 
   (@HandsCIID IS NULL OR @HandsCIID != @CIID) AND
   (@LegsCIID IS NULL OR @LegsCIID != @CIID) AND 
   (@FeetCIID IS NULL OR @FeetCIID != @CIID) AND
   (@FingerLCIID IS NULL OR @FingerLCIID != @CIID) AND 
   (@FingerRCIID IS NULL OR @FingerRCIID != @CIID) AND
   (@MeleeCIID IS NULL OR @MeleeCIID != @CIID) AND 
   (@PrimaryCIID IS NULL OR @PrimaryCIID != @CIID) AND
   (@SecondaryCIID IS NULL OR @SecondaryCIID != @CIID) AND 
   (@Custom1CIID IS NULL OR @Custom1CIID != @CIID) AND
   (@Custom2CIID IS NULL OR @Custom2CIID != @CIID))
BEGIN
	BEGIN TRAN -------------
	UPDATE CharacterItem SET CID=NULL WHERE CIID=@CIID AND CID=@CID
	IF 0 = @@ROWCOUNT BEGIN
		ROLLBACK TRAN
		RETURN
	END

	INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, Cnt) 
	VALUES (@AID, @ItemID, @RentDate, @RentHourPeriod, @Cnt)
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		RETURN
	END
	COMMIT TRAN -----------
END
GO

--
-- Definition for stored procedure spBuyBountyItem : 
--
GO
CREATE   PROC [dbo].[spBuyBountyItem]
	@CID		INT,
	@ItemID		INT,
	@Price		INT
AS
SET NOCOUNT ON
BEGIN
	DECLARE @OrderCIID	int
	DECLARE @Bounty	INT

	BEGIN TRAN
		-- ????
		SELECT @Bounty=BP FROM Character(NOLOCK) WHERE CID=@CID
		IF @Bounty IS NULL OR @Bounty < @Price
		BEGIN
			ROLLBACK TRAN
			RETURN 0
		END

		-- Bounty ??
		UPDATE Character SET BP=BP-@Price WHERE CID=@CID
		IF 0 = @@ROWCOUNT
		BEGIN
			ROLLBACK TRAN
			RETURN (-1)
		END

		-- Item ??
		INSERT INTO CharacterItem (CID, ItemID, RegDate) Values (@CID, @ItemID, GETDATE())
		IF 0 <> @@ERROR
		BEGIN
			ROLLBACK TRAN
			RETURN (-1)
		END

		SELECT @OrderCIID = @@IDENTITY
		
		-- Item ???? ??
		INSERT INTO ItemPurchaseLogByBounty (ItemID, CID, Date, Bounty, CharBounty, Type)
		VALUES (@ItemID, @CID, GETDATE(), @Price, @Bounty, '??')
		IF 0 <> @@ERROR BEGIN
			ROLLBACK TRAN
			RETURN (-1)
		END

		SELECT @OrderCIID as ORDERCIID
	COMMIT TRAN

	RETURN 1
END
GO

--
-- Definition for stored procedure spBuyBountyItem2 : 
--
GO
CREATE PROC [dbo].[spBuyBountyItem2] 
 @CID  INT
,  @ItemID  INT
, @Price  INT  
, @RentHourPeriod INT 
AS  
SET NOCOUNT ON  
BEGIN  
 DECLARE @OrderCIID int  
 DECLARE @Bounty INT  
  
 BEGIN TRAN  
  -- ????  
  SELECT @Bounty=BP FROM Character(NOLOCK) WHERE CID=@CID  
  IF @Bounty IS NULL OR @Bounty < @Price  
  BEGIN  
   ROLLBACK TRAN  
   RETURN 0  
  END  
  
  -- Bounty ??  
  UPDATE Character SET BP=BP-@Price WHERE CID=@CID  
  IF 0 = @@ROWCOUNT  
  BEGIN  
   ROLLBACK TRAN  
   RETURN (-1)  
  END  
  
  -- Item ??  
  INSERT INTO CharacterItem (CID, ItemID, RegDate, RentDate, RentHourPeriod) 
  Values (@CID, @ItemID, GETDATE(), GETDATE(), @RentHourPeriod)  
  IF 0 <> @@ERROR  
  BEGIN  
   ROLLBACK TRAN  
   RETURN (-1)  
  END  
  
  SELECT @OrderCIID = @@IDENTITY  
    
  -- Item ???? ??  
  INSERT INTO ItemPurchaseLogByBounty (ItemID, CID, Date, Bounty, CharBounty, Type)  
  VALUES (@ItemID, @CID, GETDATE(), @Price, @Bounty, '??')  
  IF 0 <> @@ERROR BEGIN  
   ROLLBACK TRAN  
   RETURN (-1)  
  END  
  
  SELECT @OrderCIID as ORDERCIID  
 COMMIT TRAN  
  
 RETURN 1  
END
GO

--------------------------------------------------------------------------------    
    
-- cash shop?? ??? ???? accountitme? ??.    
CREATE   PROC [dbo].[spBuyCashItem]    
 @UserID  varchar(20),    
 @CSID  int,    
 @Cash  int,    
 @RentHourPeriod smallint = NULL,    
 @MobileCode char(16) = NULL    
AS    
 SET NoCount On    
    
 DECLARE @AID  int    
 DECLARE @ItemID  int    
    
 -- Account ??    
 SELECT @AID = AID FROM Account WHERE UserID = @UserID    
 IF @AID IS NULL    
 BEGIN    
  RETURN 0    
 END    
 ELSE    
 BEGIN    
  SELECT @ItemID = ItemID FROM CashShop cs (NOLOCK) WHERE cs.CSID = @CSID    
    
  IF @ItemID IS NOT NULL    
  BEGIN     
   DECLARE @RentDate datetime    
    
   -- @RentHourPeriod?? ??? ????? ??.    
   IF @RentHourPeriod = 0 OR @RentHourPeriod IS NULL    
   BEGIN    
    -- ??? ???? ?? ?? ??? ?? ?? ??    
    DECLARE @RentType  TINYINT    
    DECLARE @RCSPID  INT    
    
    SELECT @RentType = RentType FROM CashShop WHERE CSID=@CSID    
    IF @RentType = 1    
    BEGIN    
     SELECT @RCSPID = RCSPID FROM RentCashShopPrice WHERE CSID=@CSID AND RentHourPeriod is NULL    
     IF @RCSPID IS NULL    
     BEGIN    
      RETURN 0    
     END    
    END    
    
    -- ?? ???? ??    
    SET @RentDate = NULL    
   END    
   ELSE    
   BEGIN    
    SET @RentDate = GETDATE()    
   END    
    
    
   BEGIN TRAN tranBuyCashItem  
       
    -- ??? ??.    
    INSERT INTO accountitem(AID, ItemID, RentDate, RentHourPeriod)     
    VALUES (@AID, @ItemID, @RentDate, @RentHourPeriod)    
    
    IF @@ERROR <> 0    
    BEGIN    
     ROLLBACK TRAN tranBuyCashItem  
     RETURN 0    
    END    
     
    -- ??? ?? log??.    
    INSERT INTO ItemPurchaseLogByCash(AID, ItemID, Date, RentHourPeriod, Cash, MobileCode)     
    VALUES (@AID, @ItemID, GETDATE(), @RentHourPeriod, @Cash, @MobileCode)    
        
    IF @@ERROR <> 0    
    BEGIN    
     ROLLBACK TRAN tranBuyCashItem  
     RETURN 0    
    END    
        
   COMMIT TRAN tranBuyCashItem  
    
   RETURN 1    
    
  END     
  ELSE    
  BEGIN    
   RETURN 0    
  END    
 END    
    
 RETURN 1
GO

--
-- Definition for stored procedure spBuyCashSetItem : 
--
GO
CREATE    PROC [dbo].[spBuyCashSetItem]      
 @UserID  varchar(20),      
 @CSSID  int,      
 @Cash  int,      
 @RentHourPeriod smallint = NULL,      
 @MobileCode char(16) = NULL      
AS      
 SET NoCount On      
    
 IF NOT EXISTS(SELECT CSSID FROM CashSetShop(NOLOCK) WHERE CSSID = @CSSID)     
  RETURN 0    
      
 DECLARE @AID  int      
       
 SELECT @AID = AID FROM Account WHERE UserID = @UserID      
      
 -- ???? ???? ??.      
 IF @AID IS NULL      
 BEGIN      
  RETURN 0      
 END      
 ELSE      
 BEGIN      
  DECLARE @RentDate  datetime         
    
    
      
  -- @RentHourPeriod?? ??? ????? ??.      
  IF @RentHourPeriod = 0 OR @RentHourPeriod IS NULL      
  BEGIN      
   -- ??? ???? ?? ?? ??? ?? ?? ??      
   DECLARE @RentType  TINYINT      
   DECLARE @RCSSPID  INT      
      
   SELECT @RentType = RentType FROM CashSetShop WHERE CSSID=@CSSID      
   IF @RentType = 1      
   BEGIN      
    SELECT @RCSSPID=RCSSPID FROM RentCashSetShopPrice WHERE CSSID=@CSSID AND RentHourPeriod is NULL      
    IF @RCSSPID IS NULL      
    BEGIN      
     RETURN 0      
    END      
   END      
      
   -- ?? ???? ??      
   SET @RentDate = NULL      
  END      
  ELSE      
  BEGIN      
   SET @RentDate = GETDATE()      
  END      
      
      
      
  BEGIN TRAN      
      
   DECLARE curBuyCashSetItem  INSENSITIVE CURSOR      
   FOR      
    SELECT CSID FROM CashSetItem (NOLOCK) WHERE CSSID = @CSSID      
   FOR READ ONLY      
       
   OPEN curBuyCashSetItem       
       
   DECLARE @varCSID  int      
   DECLARE @ItemID   int      
       
   FETCH FROM curBuyCashSetItem INTO @varCSID      
       
   WHILE @@FETCH_STATUS = 0      
   BEGIN      
    SELECT @ItemID = cs.ItemID      
    FROM CashShop cs (NOLOCK)       
    WHERE cs.CSID = @varCSID       
       
    IF @ItemID IS NOT NULL      
    BEGIN      
     -- ??? ??.      
     INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod)      
     VALUES (@AID, @ItemID, @RentDate, @RentHourPeriod)      
           
     IF @@ERROR <> 0      
     BEGIN      
      ROLLBACK      
      CLOSE curBuyCashSetItem       
      DEALLOCATE curBuyCashSetItem       
      RETURN 0      
     END           
    END      
       
    FETCH curBuyCashSetItem  INTO @varCSID      
   END      
       
   CLOSE curBuyCashSetItem       
   DEALLOCATE curBuyCashSetItem       
       
   -- ?? ??? ?? ??.      
   INSERT INTO SetItemPurchaseLogByCash (AID, CSSID, Date, RentHourPeriod, Cash, MobileCode)      
   VALUES (@AID, @CSSID, GETDATE(), @RentHourPeriod, @Cash, @MobileCode)      
      
   IF @@ERROR <> 0      
   BEGIN      
    ROLLBACK      
    RETURN 0      
   END      
             
  COMMIT TRAN      
  RETURN 1      
 END
GO

--
-- Definition for stored procedure spCashShopGetRankedList : 
--
GO
CREATE PROC [dbo].[spCashShopGetRankedList]
	@Category	varchar(32)
	-- @Category : ?????, ????, ?????, ???, ??
AS
SET NOCOUNT ON
BEGIN
	IF (@Category = '??')
	BEGIN
		SELECT TOP 5 r.Category, r.Rank, r.Name, r.CSID, r.CSSID, r.Slot, r.ResSex, r.ResLevel, r.CashPrice, r.RegDate, s.WebImgName
		FROM CashShopRank r(NOLOCK), CashSetShop s(NOLOCK)
		WHERE r.CSSID=s.CSSID AND Category=@Category AND s.Opened=1
	END
	ELSE
	BEGIN
		SELECT TOP 5 r.Category, r.Rank, r.Name, r.CSID, r.CSSID, r.Slot, r.ResSex, r.ResLevel, r.CashPrice, r.RegDate, s.WebImgName
		FROM CashShopRank r(NOLOCK), CashShop s(NOLOCK)
		WHERE r.CSID=s.CSID AND Category=@Category AND s.Opened=1
	END
END
GO

--
-- Definition for stored procedure spCashShopNewItemList : 
--
GO
CREATE   PROC [dbo].[spCashShopNewItemList]
	@IsSetItem		INT
AS
BEGIN
	IF @IsSetItem=0
	BEGIN
		SELECT TOP 4 n.* FROM CashShopNewItem n(NOLOCK), CashShop c(NOLOCK)
		WHERE n.CSID=c.CSID AND c.Opened=1 AND IsSetItem=0 ORDER BY NewOrder
	END
	ELSE
	BEGIN
		SELECT TOP 4 n.* FROM CashShopNewItem n(NOLOCK), CashSetShop c(NOLOCK)
		WHERE n.CSSID=c.CSSID AND c.Opened=1 AND  IsSetItem=1 ORDER BY NewOrder
	END
END
GO

--
-- Definition for stored procedure spCashShopNewItemUpdate : 
--
GO
CREATE PROC [dbo].[spCashShopNewItemUpdate]
	@NewOrder		INT,
	@IsSetItem		INT,
	@CSID			INT,
	@CSSID			INT
AS
SET NOCOUNT ON
BEGIN

	IF EXISTS(SELECT id FROM CashShopNewItem(NOLOCK) WHERE NewOrder=@NewOrder)
	BEGIN
		DELETE CashShopNewItem WHERE NewOrder=@NewOrder
	END

	IF @IsSetItem = 0
	BEGIN
		INSERT INTO CashShopNewItem (NewOrder, Category, IsSetItem, CSID, CSSID, Slot, Name, ResSex, ResLevel, CashPrice, WebImgName)
		SELECT @NewOrder AS NewOrder, 
			CASE i.Slot 
				WHEN 0 THEN '????'
				WHEN 1 THEN '????'
				WHEN 2 THEN '?????'
				WHEN 3 THEN '?????'
				WHEN 4 THEN '???'
				WHEN 5 THEN '???'
				WHEN 6 THEN '???'
				WHEN 7 THEN '???'
				WHEN 8 THEN '???'
				WHEN 9 THEN '???'
			END AS Category, 
			@IsSetItem, s.CSID, NULL AS CSSID,
			CASE i.Slot 
				WHEN 0 THEN '????'
				WHEN 1 THEN '????'
				WHEN 2 THEN '?????'
				WHEN 3 THEN '???'
				WHEN 4 THEN '??'
				WHEN 5 THEN '??'
				WHEN 6 THEN '?'
				WHEN 7 THEN '??'
				WHEN 8 THEN '?'
				WHEN 9 THEN '???'
			END AS Slot, 
			i.Name, i.ResSex, i.ResLevel, CashPrice, s.WebImgName
		FROM CashShop s(NOLOCK), Item i(NOLOCK) 
		WHERE s.ItemID=i.ItemID AND CSID=@CSID
	END
	ELSE
	BEGIN
		INSERT INTO CashShopNewItem (NewOrder, Category, IsSetItem, CSID, CSSID, Slot, Name, ResSex, ResLevel, CashPrice, WebImgName)
		SELECT @NewOrder AS NewOrder, '??', @IsSetItem, NULL AS CSID, CSSID, '??' AS Slot, Name, ResSex, ResLevel, CashPrice, WebImgName
		FROM CashSetShop(NOLOCK)
		WHERE CSSID=@CSSID
	END
END
GO

-- ??? ?? ??
CREATE PROC [dbo].[spChangeCharName]
	@AID		int,
	@CID		int,
	@NewName	varchar(24)
AS
SET NOCOUNT ON
IF (LEN(@NewName) <= 0) OR (LEN(@NewName) > 12)
BEGIN
	SELECT 0 AS Ret
END

IF EXISTS (SELECT TOP 1 CID FROM Character where (Name=@NewName) AND (DeleteFlag=0))
BEGIN
	SELECT 0 AS Ret
	return (-1)
END

UPDATE Character SET Name=@NewName WHERE AID=@AID AND CID=@CID
IF 0 = @@ROWCOUNT BEGIN
	SELECT 0 AS Ret
	RETURN (-1)
END

SELECT 1 AS Ret
GO

--
-- Definition for stored procedure spChangeGambleItemToRewardItem : 
--
GO
CREATE PROC [dbo].[spChangeGambleItemToRewardItem]
 @CID int
, @CIID int
, @GIID int
, @RewardItemID int
AS
BEGIN
 SET NOCOUNT ON

 DECLARE @RentHourPeriod smallint

 SELECT @RentHourPeriod = RentHourPeriod
 FROM GambleRewardItem 
 WHERE GIID = @GIID AND (ItemIDMale = @RewardItemID OR ItemIDFemale = @RewardItemID)

 IF @RentHourPeriod IS NULL BEGIN
  SELECT -1 as 'Ret'
  RETURN
 END

 BEGIN TRAN
  UPDATE CharacterItem
  SET ItemID = @RewardItemID, RentHourPeriod = @RentHourPeriod
   , RentDate = GETDATE()
  WHERE CID = @CID AND CIID = @CIID AND ItemID = @GIID
  IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
   ROLLBACK TRAN
   SELECT -2 AS 'Ret'
   RETURN
  END


 COMMIT TRAN

 SELECT 1 AS 'Ret'
END
GO

--
-- Definition for stored procedure spCheckDuplicateCharName : 
--
GO
create proc [dbo].[spCheckDuplicateCharName]   
 @Name varchar(24)  
as
 set nocount on  
 select top 1 cid from character(nolock) where deleteflag <> 1 and name = @Name
GO

--
-- Definition for stored procedure spCheckRegisteredUser : 
--
GO
CREATE   PROC [dbo].[spCheckRegisteredUser]
	@UserID VARCHAR(20)
AS
BEGIN
 SET NOCOUNT ON
	DECLARE @AID INT

	SELECT @AID = AID FROM Account WHERE UserID = @UserID

	IF @@ERROR <> 0
	BEGIN
		RETURN	-- ????
	END

	IF @AID IS NULL
	BEGIN
		RETURN -1	-- ????
	END
		select 1
	RETURN 1 -- ??? ??
END
GO

--  -1:DB Failure
--  0:Unregistered user
--  1:Wrong Password
--  2:Valid User
CREATE PROC [dbo].[spCheckUserPassword]
        @UserID VARCHAR(20),
        @Password VARCHAR(20)
AS
BEGIN
        DECLARE @AID INT
        SELECT @AID=AID FROM LOGIN(NOLOCK) WHERE UserID=@UserID

        IF @@ERROR <> 0
        BEGIN
                RETURN        -1   -- DB Failure
        END

        IF @AID IS NULL
        BEGIN
                RETURN 0        -- Unregistered user
        END

        DECLARE @AID2 INT
        SELECT @AID2=AID FROM LOGIN(NOLOCK) WHERE UserID=@UserID AND Password=@Password

        IF @AID2 IS NULL
        BEGIN
                RETURN 1        -- Wrong Password
        END

        RETURN 2 -- Valid User
END
GO

--
-- Definition for stored procedure spClearAllEquipedItem : 
--
GO
/* ??? ?? ?? ??  */
CREATE PROC [dbo].[spClearAllEquipedItem]
	@CID		int
AS
SET NOCOUNT ON

UPDATE Character WITH (rowlock)
SET head_slot=NULL, chest_slot=NULL, hands_slot=NULL, legs_slot=NULL, feet_slot=NULL,
  fingerl_slot=NULL, fingerr_slot=NULL, melee_slot=NULL, primary_slot=NULL, secondary_slot=NULL, custom1_slot=NULL, custom2_slot=NULL,
  head_itemid=NULL, chest_itemid=NULL, hands_itemid=NULL, legs_itemid=NULL, feet_itemid=NULL,
  fingerl_itemid=NULL, fingerr_itemid=NULL, melee_itemid=NULL, primary_itemid=NULL, secondary_itemid=NULL, custom1_itemid=NULL, custom2_itemid=NULL

WHERE CID=@CID
GO

--
-- Definition for stored procedure spConfirmBuyCashItem : 
--
GO
/* ?? ??? ?????? ???? */
CREATE PROC [dbo].[spConfirmBuyCashItem]
	@UserID								varchar(20),
	@CSID									int,
	@RetEnableBuyItem			int OUTPUT,
	@RetRepeatBuySameItem	int OUTPUT
AS
SET NoCount On
	
DECLARE @AID		int
DECLARE @ItemID	int
DECLARE @AIID		int


SELECT @AID = AID FROM Account(nolock) where UserID = @UserID
SELECT @ItemID = ItemID FROM CashShop(nolock) WHERE CSID=@CSID

IF @AID IS NULL
BEGIN
	SELECT @RetEnableBuyItem = 0
	SELECT @RetRepeatBuySameItem = 0
END
ELSE
BEGIN
	SELECT @RetEnableBuyItem = 1


	IF (@ItemID IS NOT NULL)
	BEGIN
		SELECT TOP 1 @AIID = AIID FROM AccountItem(nolock) WHERE AID=@AID AND ItemID=@ItemID
		IF (@AIID IS NOT NULL)
		BEGIN
			SELECT @RetRepeatBuySameItem = 1
		END
		ELSE
		BEGIN
			SELECT @RetRepeatBuySameItem = 0
		END
	END
	ELSE
	BEGIN
		SELECT @RetRepeatBuySameItem = 0
	END


END
GO

--
-- Definition for stored procedure spConfirmBuyCashSetItem : 
--
GO
/* ?? ??? ?????? ???? */
CREATE PROC [dbo].[spConfirmBuyCashSetItem]
	@UserID								varchar(20),
	@CSSID								int,
	@RetEnableBuyItem			int OUTPUT,
	@RetRepeatBuySameItem	int OUTPUT
AS
SET NoCount On
	
DECLARE @AID		int
DECLARE @SIL_ID	int
DECLARE @LAST_ID int

SELECT @AID = AID FROM Account(nolock) where UserID = @UserID


IF @AID IS NULL
BEGIN
	SELECT @RetEnableBuyItem = 0
	SELECT @RetRepeatBuySameItem = 0
END
ELSE
BEGIN
	SELECT @RetEnableBuyItem = 1

	SELECT TOP 1 @LAST_ID = id FROM SetItemPurchaseLogByCash spl(nolock) order by id desc

	SELECT TOP 1 @SIL_ID = id FROM SetItemPurchaseLogByCash spl(nolock) 
	WHERE id > (@LAST_ID-10000) AND AID=@AID AND CSSID=@CSSID

	IF (@SIL_ID IS NOT NULL)
	BEGIN
		SELECT @RetRepeatBuySameItem = 1
	END
	ELSE
	BEGIN
		SELECT @RetRepeatBuySameItem = 0
	END

END
GO

-- ??? ????? ????
CREATE PROC [dbo].[spConfirmExistClan]
	@ClanName		varchar(24)
AS
	SET NOCOUNT ON
	SELECT COUNT(*) FROM Clan(NOLOCK) WHERE Name=@ClanName
GO

-- ?? ????
CREATE PROC [dbo].[spCreateClan]
	@ClanName		varchar(24),
	@MasterCID		int,
	@Member1CID		int,
	@Member2CID		int,
	@Member3CID		int,
	@Member4CID		int
AS
	DECLARE @NewCLID	int

	-- ????? ???? ??????.
	SELECT @NewCLID=CLID FROM Clan(NOLOCK) WHERE Name=@ClanName

	IF @NewCLID IS NOT NULL
	BEGIN
		SELECT 0 AS Ret, 0 AS NewCLID
		RETURN
	END


	DECLARE @CNT		int

	-- ???? ?? ?? ???? ??????.
	SELECT @CNT = COUNT(*) FROM ClanMember cm(NOLOCK), Character c(NOLOCK) WHERE ((cm.CID=@MasterCID) OR (cm.CID=@Member1CID) OR (cm.CID=@Member2CID) OR (cm.CID=@Member3CID) OR
(cm.CID=@Member4CID) ) AND cm.CID=c.CID AND c.DeleteFlag=0

	IF @CNT != 0
	BEGIN
		SELECT 0 AS Ret, 0 AS NewCLID
		RETURN
	END


	BEGIN TRAN
	-- ?? ??
	INSERT INTO Clan (Name, MasterCID, RegDate) VALUES (@ClanName, @MasterCID, GETDATE())
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		SELECT 0 AS Ret, 0 AS NewCLID
		RETURN
	END

	SELECT @NewCLID = @@IDENTITY
	IF (@NewCLID IS not NULL)
	BEGIN
		DECLARE @Err1 int
		DECLARE @Err2 int
		DECLARE @Err3 int
		DECLARE @Err4 int
		DECLARE @Err5 int

		-- ??? ??
		INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@NewCLID, @MasterCID, 1, GETDATE())
		SET @Err1 = @@ERROR		
		INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@NewCLID, @Member1CID, 9, GETDATE())
		SET @Err2 = @@ERROR
		INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@NewCLID, @Member2CID, 9, GETDATE())
		SET @Err3 = @@ERROR
		INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@NewCLID, @Member3CID, 9, GETDATE())
		SET @Err4 = @@ERROR
		INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES (@NewCLID, @Member4CID, 9, GETDATE())
		SET @Err5 = @@ERROR

		IF (0 <> @Err1) OR (0 <> @Err2) OR (0 <> @Err3) OR (0 <> @Err4) OR (0 <> @Err5) BEGIN
			ROLLBACK TRAN
			SELECT 0 AS Ret, 0 AS NewCLID
			RETURN
		END
	END
	COMMIT TRAN

	-- ??? ??? ??
	--UPDATE Character SET BP=BP-1000 WHERE CID=@MasterCID


	SELECT 1 AS Ret, @NewCLID AS NewCLID
GO

--
-- Definition for stored procedure spDeleteChar : 
--
GO
/* ??? ?? */  
CREATE  PROC [dbo].[spDeleteChar]  
 @AID  int,  
 @CharNum smallint,  
 @CharName varchar(24)  
AS  
DECLARE @CID  int  
DECLARE @CashItemCount int  
  
SELECT @CID=CID FROM Character WITH (nolock) WHERE AID=@AID and CharNum=@CharNum  
IF (@CID IS NULL)  
BEGIN  
 return (-1)  
END  
  
SELECT @CashItemCount=COUNT(*) FROM CharacterItem(nolock) WHERE CID=@CID AND ItemID>=500000  
  
IF (@CashItemCount > 0) OR  
   (EXISTS (SELECT TOP 1 CLID FROM ClanMember WHERE CID=@CID))  
BEGIN  
 return (-1)  
END  
  
BEGIN TRAN

UPDATE Character SET CharNum = -1, DeleteFlag = 1, Name='', DeleteName=@CharName  
WHERE AID=@AID AND CharNum=@CharNum AND Name=@CharName  
IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
 ROLLBACK TRAN
 RETURN (-1)
END

INSERT INTO CharacterMakingLog(AID, CharName, Type, Date)
VALUES(@AID, @CharName, '??', GETDATE())
IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
 ROLLBACK TRAN
 RETURN (-1) 
END
  
COMMIT TRAN
SELECT 1 AS Ret
GO

--
-- Definition for stored procedure spDeleteCharItem : 
--
GO
/* ??? ??? ?? */
CREATE PROC [dbo].[spDeleteCharItem]
	@CID		int,
	@CIID		int
AS
SET NOCOUNT ON

UPDATE CharacterItem SET CID=NULL
WHERE CID=@CID AND CIID=@CIID

/* ???
DELETE FROM CharacterItem 
WHERE CID=@CID AND CIID=@CIID
*/
GO

-- ?? ????
CREATE PROC [dbo].[spDeleteClan]
	@CLID		int,
	@ClanName	varchar(24)

AS
	SET NOCOUNT ON
	-- ??? ?? ??
	DELETE FROM ClanMember WHERE CLID=@CLID

	-- ?? ??
	UPDATE Clan SET Name=NULL, DeleteFlag=1, DeleteName=@ClanName WHERE CLID=@CLID
GO

--
-- Definition for stored procedure spDeleteExpiredAccountItem : 
--
GO
/* ????? ???? ??? ?? */
CREATE PROC [dbo].[spDeleteExpiredAccountItem]
	@AIID		int
AS
SET NOCOUNT ON

DELETE FROM AccountItem WHERE AIID=@AIID AND RentDate IS NOT NULL
GO

--
-- Definition for stored procedure spFetchTotalRanking : 
--
GO
/* ?? ??? ????. - ?? ?????? ????? ???? */
CREATE PROC [dbo].[spFetchTotalRanking]
AS
SET NOCOUNT ON
TRUNCATE TABLE TotalRanking

INSERT into TotalRanking(UserID, Name, Level, XP, KillCount, DeathCount)

SELECT Account.UserID, c.name, c.Level, c.XP, c.KillCount, c.DeathCount
FROM Character c(nolock), Account(nolock)
WHERE Account.AID=c.aid AND c.DeleteFlag=0 AND c.XP >= 500
ORDER BY c.xp DESC, c.KillCount DESC, c.DeathCount ASC, c.PlayTime DESC
GO

-- ?????? ??? ?? ????
CREATE PROC [dbo].[spGetAccountCharInfo]
	@AID		int
,	@CharNum	smallint
AS
SET NOCOUNT ON
DECLARE @CID		int
DECLARE @CLID		int
DECLARE @ClanName	varchar(24)
DECLARE @ClanGrade	int
DECLARE @ClanContPoint	int

SELECT @CID=CID FROM Character WITH (nolock) WHERE AID=@AID and CharNum=@CharNum

SELECT @CID AS CID, c.Name AS Name, c.CharNum AS CharNum, c.Level AS Level, c.Sex AS Sex, c.Hair AS Hair, c.Face AS Face,
       c.XP AS XP, c.BP AS BP,
       (SELECT cl.Name FROM Clan cl(nolock), ClanMember cm(nolock) WHERE cm.cid=@CID AND cm.CLID=cl.CLID) AS ClanName,
	head_itemid, chest_itemid, hands_itemid, legs_itemid, feet_itemid, fingerl_itemid, 
	fingerr_itemid, melee_itemid, primary_itemid, secondary_itemid, custom1_itemid, custom2_itemid
FROM Character AS c WITH (nolock)
WHERE c.CID = @CID
GO

--
-- Definition for stored procedure spGetAccountInfo : 
--
GO
CREATE  PROC [dbo].[spGetAccountInfo]
 @AID  int      
, @ServerID int = 0
AS    
BEGIN  
 SET NOCOUNT ON    

 SELECT AID, UserID, UGradeID, Name, HackingType
 , DATEPART(yy, EndHackingBlockTime) AS HackBlockYear, DATEPART(mm, EndHackingBlockTime) AS HackBlockMonth    
 , DATEPART(dd, EndHackingBlockTime) AS HackBlockDay, DATEPART(hh, EndHackingBlockTime) AS HackBlockHour    
 , DATEPART(mi, EndHackingBlockTime) AS HackBlockMin
 FROM Account(NOLOCK) WHERE AID = @AID      

 update Account set LastLoginTime = getdate(), ServerID = @ServerID  where aid = @aid  
END
GO

-- ?? ??? ???? ?? ?? ??? ?? ??( EX, 2004-10-15 )
-- spRegularUpdateConnLog? ?????? ?? ??? ?? ?.
CREATE PROC [dbo].[spGetAgoDay]
	@DiffDay int
,	@AgoDay datetime OUTPUT
AS
	SET NOCOUNT ON
	DECLARE @CurDay datetime

	SELECT @CurDay = CONVERT( varchar(30), GETDATE(), 2 )
	SELECT @AgoDay = DATEADD( dd, -@DiffDay, @CurDay )
GO

-- ?? ????? ????? ????
CREATE PROC [dbo].[spGetCashItemImageFile]
	@CSID			int
,	@RetImageFileName	varchar(64) OUTPUT
AS
SET NOCOUNT ON

SELECT @RetImageFileName = WebImgName
FROM CashShop cs(nolock)
WHERE cs.csid=@CSID

RETURN 1
GO

--
-- Definition for stored procedure spGetCashItemInfo : 
--
GO
CREATE  PROC [dbo].[spGetCashItemInfo]
	@CSID		int
AS
	SET NOCOUNT ON

	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot, 
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Damage AS Damage, i.Delay AS Delay, i.Controllability AS Controllability,
		i.Magazine AS Magazine, i.MaxBullet AS MaxBullet, i.ReloadTime AS ReloadTime, 
		i.HP AS HP, i.AP AS AP,	i.MAXWT AS MaxWeight, i.LimitSpeed AS LimitSpeed,
		i.FR AS FR, i.CR AS CR, i.PR AS PR, i.LR AS LR,
		i.Description AS Description, cs.NewItemOrder AS IsNewItem,
		cs.RentType AS RentType
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE i.ItemID = cs.ItemID AND cs.csid = @CSID
GO

--
-- Definition for stored procedure spGetCashItemList : 
--
GO
/* ??? ??? ???? */
CREATE PROC [dbo].[spGetCashItemList]
	@ItemType	int,
	@Page		int,		
	@PageCount	int OUTPUT
AS
SET NoCount On

DECLARE @Rows int
DECLARE @ViewCount int

SELECT @Rows = @Page * 8	/* ????? 8?? ???? */

DECLARE @PageSize INT
SELECT @PageSize = 8

DECLARE @PageHead INT
DECLARE @RowCount INT


IF @ItemType = 1 /* ???? */
BEGIN

	SELECT @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE i.ItemID = cs.ItemID AND i.Slot = 1 AND cs.Opened=1

	SELECT @RowCount = ((@Page -1) * @PageSize + 1)

	SET ROWCOUNT @RowCount
	SELECT @PageHead = cs.csid FROM CashShop cs(NOLOCK), Item i(nolock) 
	WHERE cs.ItemID=i.ItemID AND i.Slot=1 AND cs.Opened=1
	ORDER BY cs.csid DESC

	SET ROWCOUNT @PageSize
	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Description AS Description, cs.RegDate As RegDate, cs.NewItemOrder AS IsNewItem,
		cs.RentType AS RentType
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE csid <= @PageHead AND i.ItemID = cs.ItemID AND i.Slot = 1 AND cs.Opened=1
	ORDER BY cs.csid DESC

END
ELSE
IF @ItemType=2 		/* ????? */
BEGIN

	SELECT @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE i.ItemID = cs.ItemID AND i.Slot = 2 AND cs.Opened=1

	SELECT @RowCount = ((@Page -1) * @PageSize + 1)

	SET ROWCOUNT @RowCount
	SELECT @PageHead = cs.csid FROM CashShop cs(NOLOCK), Item i(nolock) 
	WHERE cs.ItemID=i.ItemID AND i.Slot=2 AND cs.Opened=1
	ORDER BY cs.csid DESC

	SET ROWCOUNT @PageSize
	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Description AS Description, cs.RegDate As RegDate, cs.NewItemOrder AS IsNewItem,
		cs.RentType AS RentType
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE csid <= @PageHead AND i.ItemID = cs.ItemID AND i.Slot = 2 AND cs.Opened=1
	ORDER BY cs.csid DESC

END
ELSE
IF @ItemType=3 		/* ??? */
BEGIN

	SELECT @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE i.ItemID = cs.ItemID AND i.Slot BETWEEN 4 AND 8 AND cs.Opened=1

	SELECT @RowCount = ((@Page -1) * @PageSize + 1)

	SET ROWCOUNT @RowCount
	SELECT @PageHead = cs.csid FROM CashShop cs(NOLOCK), Item i(nolock) 
	WHERE cs.ItemID=i.ItemID AND i.Slot BETWEEN 4 AND 8 AND cs.Opened=1
	ORDER BY cs.csid DESC

	SET ROWCOUNT @PageSize
	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Description AS Description, cs.RegDate As RegDate, cs.NewItemOrder AS IsNewItem,
		cs.RentType AS RentType
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE csid <= @PageHead AND i.ItemID = cs.ItemID AND i.Slot BETWEEN 4 AND 8 AND cs.Opened=1
	ORDER BY cs.csid DESC

END
ELSE
IF @ItemType=4 		/* ????? */
BEGIN

	SELECT @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE i.ItemID = cs.ItemID AND (i.Slot = 3 OR i.Slot=9) AND cs.Opened=1

	SELECT @RowCount = ((@Page -1) * @PageSize + 1)

	SET ROWCOUNT @RowCount
	SELECT @PageHead = cs.csid FROM CashShop cs(NOLOCK), Item i(nolock) 
	WHERE cs.ItemID=i.ItemID AND (i.Slot = 3 OR i.Slot=9) AND cs.Opened=1
	ORDER BY cs.csid DESC

	SET ROWCOUNT @PageSize
	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Description AS Description, cs.RegDate As RegDate, cs.NewItemOrder AS IsNewItem,
		cs.RentType AS RentType
	FROM CashShop cs(nolock), Item i(nolock)
	WHERE csid <= @PageHead AND i.ItemID = cs.ItemID AND (i.Slot = 3 OR i.Slot=9) AND cs.Opened=1
	ORDER BY cs.csid DESC

END

SET ROWCOUNT 0
GO

--
-- Definition for stored procedure spGetCashSetItemComposition : 
--
GO
/* ?? ???? ????? ?? ?? */
CREATE PROC [dbo].[spGetCashSetItemComposition]
	@CSSID		int,
	@OutRowCount	int OUTPUT
AS
SET NOCOUNT ON

SELECT @OutRowCount = COUNT(*)
FROM CashSetItem csi(nolock), CashShop cs(nolock), Item i(nolock)
WHERE @CSSID = csi.CSSID AND csi.csid = cs.csid	AND cs.ItemID = i.ItemID

SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot, 
	cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
	i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
	i.Description AS Description, cs.RegDate As RegDate,
	cs.NewItemOrder AS IsNewItem

FROM CashSetItem csi(nolock), CashShop cs(nolock), Item i(nolock)
WHERE @CSSID = csi.CSSID AND csi.csid = cs.csid	AND cs.ItemID = i.ItemID
GO

-- ?? ????? ????? ????
CREATE PROC [dbo].[spGetCashSetItemImageFile]
	@CSSID			int
,	@RetImageFileName	varchar(64) OUTPUT
AS
SET NOCOUNT ON

SELECT @RetImageFileName=WebImgName FROM CashSetShop css(nolock) WHERE CSSID=@CSSID

RETURN 1
GO

--
-- Definition for stored procedure spGetCashSetItemInfo : 
--
GO
/* ?????? ?? ?? ?? */
CREATE  PROC [dbo].[spGetCashSetItemInfo]
	@CSSID	int
AS
	SET NOCOUNT ON

	SELECT CSSID AS CSSID, Name AS Name, CashPrice AS Cash, WebImgName AS WebImgName, 
	ResSex AS ResSex, ResLevel AS ResLevel, Weight AS Weight,
	Description AS Description, NewItemOrder As IsNewItem, RentType AS RentType

	FROM CashSetShop css(nolock)
	WHERE CSSID = @CSSID
GO

--
-- Definition for stored procedure spGetCashSetItemList : 
--
GO
/* ????? ?? ?? */
CREATE PROC [dbo].[spGetCashSetItemList]
	@Page		int,
	@PageCount	int OUTPUT
AS
SET NoCount On
DECLARE @Rows int
DECLARE @ViewCount int

DECLARE @PageSize INT
SELECT @PageSize = 8		/* ????? 8?? ???? */

DECLARE @PageHead INT
DECLARE @RowCount INT

SELECT @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize FROM CashSetShop css(nolock) WHERE css.Opened=1
SELECT @RowCount = ((@Page -1) * @PageSize + 1)

SET ROWCOUNT @RowCount
SELECT @PageHead = css.CSSID FROM CashSetShop css(nolock)
WHERE css.Opened=1
ORDER BY css.cssid DESC


SET ROWCOUNT @PageSize
SELECT CSSID AS CSSID, Name AS Name, CashPrice AS Cash, WebImgName AS WebImgName, 
	ResSex AS ResSex, ResLevel AS ResLevel, Weight AS Weight,
	Description AS Description, RegDate AS RegDate, NewItemOrder AS IsNewItem,
	RentType AS RentType
FROM CashSetShop css(nolock)
WHERE cssid <= @PageHead AND css.Opened=1
ORDER BY css.cssid DESC


SET ROWCOUNT 0
GO

-- ???? ????
CREATE PROC [dbo].[spGetCharClan]
	@CID			int
AS
	SET NOCOUNT ON
	SELECT cl.CLID AS CLID, cl.Name AS ClanName FROM ClanMember cm(nolock), Clan cl(nolock) WHERE cm.cid=@CID AND cm.CLID=cl.CLID
GO

-- ??? ?? ????
CREATE  PROC [dbo].[spGetCharInfoByCharNum]
	@AID		int
,	@CharNum	smallint
AS
SET NOCOUNT ON

DECLARE @CID		int
DECLARE @CLID		int
DECLARE @ClanName	varchar(24)
DECLARE @ClanGrade	int
DECLARE @ClanContPoint	int
BEGIN
SELECT @CID=CID FROM Character WITH (nolock) WHERE AID=@AID and CharNum=@CharNum
SELECT @CLID=cl.CLID, @ClanName=cl.Name, @ClanGrade=cm.Grade, @ClanContPoint=cm.ContPoint FROM ClanMember cm(nolock), Clan cl(nolock) WHERE cm.cid=@CID AND cm.CLID=cl.CLID

SELECT CID, AID, Name, Level, Sex, CharNum, Hair, Face, XP, BP, HP, AP, FR, CR, ER, WR, GameCount, KillCount, DeathCount, PlayTime,
       head_slot, chest_slot, hands_slot, legs_slot, feet_slot, fingerl_slot, fingerr_slot, melee_slot, primary_slot,
       secondary_slot, custom1_slot, custom2_slot,
       @CLID AS CLID, @ClanName AS ClanName, @ClanGrade AS ClanGrade, @ClanContPoint AS ClanContPoint 
FROM Character WITH (nolock) where cid=@CID
END
GO

--
-- Definition for stored procedure spGetCharList : 
--
GO
/* ??? ??? ??? ????  */
CREATE PROC [dbo].[spGetCharList]
	@AID		int
AS
SET NOCOUNT ON
SELECT c.CID AS CID, c.Name AS Name, c.CharNum AS CharNum, c.Level AS Level
FROM Character AS c WITH (nolock)
WHERE c.AID=@AID AND c.DeleteFlag = 0
GO

--------------------------------------------

create proc [dbo].[spGetCharNameByCID]
 @CID int
as 
 set nocount on
 select name from character(nolock) where CID = @CID
GO

--
-- Definition for stored procedure spGetCheckBlockedIP : 
--
GO
CREATE PROC [dbo].[spGetCheckBlockedIP]
@IP varchar(15)
AS
BEGIN
	SELECT ic.CountryName as Name, bcc.CountryCode3 as Code, bcc.IsBlock
	FROM BlockCountryCode bcc(NOLOCK), IPtoCountry ic(NOLOCK)
	WHERE   ic.CountryCode3 = bcc.CountryCode3 and 
		ic.IPFrom <= GunzDB.game.inet_aton( @IP ) and ic.IPTo >= GunzDB.game.inet_aton( @IP ) 
END
GO

--------------------------------------------

create proc [dbo].[spGetCIDbyCharName]
 @Name varchar(24)
as
 set nocount on
 select cid from character(nolock) where name = @Name
GO

--
-- Definition for stored procedure spGetClanHonorRanking : 
--
GO
/* ?? ??? ?? ?? ?? 10??? 
	2004? 9? ~ ???????(?? ??) */
CREATE PROC [dbo].[spGetClanHonorRanking]
	@Year INT,
	@Month INT
AS
SET NOCOUNT ON
BEGIN
	SELECT TOP 10 r.Ranking, r.ClanName, r.Point, r.Wins, r.Losses, r.CLID, c.EmblemUrl 
	FROM ClanHonorRanking r(NOLOCK), Clan c(NOLOCK)
	WHERE r.CLID=c.CLID AND Year = @Year AND Month = @Month
	ORDER BY r.Ranking
END
GO

-- ?? ?? ??
CREATE PROC [dbo].[spGetClanInfo]
	@CLID			int
AS
SET NOCOUNT ON

SELECT cl.CLID AS CLID, cl.Name AS Name, cl.TotalPoint AS TotalPoint, cl.Level AS Level, cl.Ranking AS Ranking,
cl.Point AS Point, cl.Wins AS Wins, cl.Losses AS Losses, cl.Draws AS Draws,
c.Name AS ClanMaster,
(SELECT COUNT(*) FROM ClanMember WHERE CLID=@CLID) AS MemberCount,
cl.EmblemUrl AS EmblemUrl, cl.EmblemChecksum AS EmblemChecksum

FROM Clan cl(nolock), Character c(nolock)
WHERE cl.CLID=@CLID and cl.MasterCID=c.CID
GO

--
-- Definition for stored procedure spGetClanList : 
--
GO
/* ?? ?? ?? 
    ???? 15?? ??, ?? ??? ?? ?? COUNT(*) ???? ??.(??,?? ???? ??) 
    Arg1 : @Page (?????)
    Arg2 : @Backward (???? ????, 1??? ?? 					*/
CREATE PROC [dbo].[spGetClanList]
	@Page INT,
	@Backward INT  = 0
AS
SET NOCOUNT ON
BEGIN
	DECLARE @PageHead INT
	DECLARE @RowCount INT

	IF @Backward = 0
	BEGIN
		SELECT @RowCount = ((@Page -1) * 15 + 1)
		
		SET ROWCOUNT @RowCount
		SELECT @PageHead = CLID FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY CLID DESC
		
		SET ROWCOUNT 15
		SELECT cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point
		FROM Clan cl(NOLOCK), Character c(nolock)
		WHERE cl.MasterCID=c.CID AND cl.DeleteFlag=0 AND cl.CLID<@PageHead 
		ORDER BY cl.CLID DESC
	END
	ELSE
	BEGIN	-- ??
		SELECT @RowCount = ((@Page -1) * 15 + 1)
		
		SET ROWCOUNT @RowCount
		SELECT @PageHead = CLID FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY CLID
		
		SET ROWCOUNT 15
		SELECT CLID, ClanName, Master, RegDate, EmblemUrl, Point
		FROM
		(
			SELECT TOP 15 cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point
			FROM Clan cl(NOLOCK), Character c(nolock)
			WHERE cl.MasterCID=c.CID AND cl.DeleteFlag=0 AND cl.CLID>=@PageHead ORDER BY cl.CLID
		) AS t
		ORDER BY CLID DESC
	END
END
GO

--
-- Definition for stored procedure spGetClanListSearchByMaster : 
--
GO
/* ?? ???? (???????)
    Arg1 : @CharName (????) */
CREATE PROC [dbo].[spGetClanListSearchByMaster]
	@CharName VARCHAR(24)
AS
SET NOCOUNT ON
BEGIN

SELECT TOP 20 cl.CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate, cl.EmblemUrl, cl.Point
FROM Clan cl(NOLOCK), Character c(nolock)

WHERE cl.DeleteFlag=0 AND cl.MasterCID=c.CID and c.Name=@CharName
ORDER BY cl.CLID

END
GO

--
-- Definition for stored procedure spGetClanListSearchByName : 
--
GO
/* ?? ???? (????)
    Arg1 : @Name (????) */
CREATE PROC [dbo].[spGetClanListSearchByName]
	@Name VARCHAR(24)
AS
SET NOCOUNT ON
BEGIN
	SELECT TOP 20 cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point
	FROM Clan cl(NOLOCK), Character c(NOLOCK)
	WHERE cl.MasterCID=c.CID AND c.DeleteFlag=0 AND cl.Name=@Name 
	ORDER BY cl.CLID
END
GO

-- ??? ????
CREATE PROC [dbo].[spGetClanMember]
	@CLID		int
AS
	SET NOCOUNT ON
	SELECT cm.clid AS CLID, cm.Grade AS ClanGrade, c.cid AS CID, c.name AS CharName
	FROM ClanMember cm(nolock), Character c(nolock)
	WHERE CLID=@CLID AND cm.cid=c.cid
GO

-- Master??? RegDate??.
/* ?? ???? : ???? 20?? ??  
    Arg1 : @Page (?????)  
    Arg2 : @Backward (???? ????, 1??? ?? */  
CREATE PROC [dbo].[spGetClanRanking]  
 @Page INT,  
 @Backward INT  = 0  
AS  
SET NOCOUNT ON
BEGIN  
 /* ????? 20?? ???? (????? ?? ??) */  
 DECLARE @RowCount INT  
 DECLARE @PageHead INT  
  
 IF @Backward = 0  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
  SELECT TOP 20 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, ch.Name AS Master, cl.RegDate
  FROM Clan cl(NOLOCK), Character ch(NOLOCK)
  WHERE cl.DeleteFlag=0 AND cl.Ranking>0 AND cl.Ranking >= @RowCount  AND ch.CID = cl.MasterCID
  ORDER BY cl.Ranking  
 END  
 ELSE  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
   
  SET ROWCOUNT @RowCount  
  SELECT @PageHead = Ranking FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY Ranking DESC  
   
  SET ROWCOUNT 20  
  SELECT Ranking, RankIncrease, ClanName, Point, Wins, Losses, CLID, EmblemUrl, Master, RegDate FROM  
  (  
  -- SELECT TOP 20 Ranking, RankIncrease, Name as ClanName, Point, Wins, Losses, CLID, EmblemUrl 
   SELECT TOP 20 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, ch.Name AS Master, cl.RegDate
   FROM Clan cl(NOLOCK), Character ch(NOLOCK)
   WHERE cl.DeleteFlag=0 AND cl.Ranking>0 AND cl.Ranking <= @PageHead AND ch.CID = cl.MasterCID
   ORDER BY cl.Ranking DESC  
  ) AS t ORDER BY Ranking  
 END  
END
GO

--
-- Definition for stored procedure spGetClanRankingHistory : 
--
GO
/* ?? ?? ????
    Arg1 : @Year (??) 
    Arg2 : @Month (?) 
    Arg3 : @Page (???) 
    Arg4 : @Backward (??) */
CREATE  PROC [dbo].[spGetClanRankingHistory]
	@Year INT,
	@Month INT,
	@Page INT,
	@Backward INT = 0
AS
SET NOCOUNT ON
BEGIN
	/* ????? 20?? ???? (????? ?? ??) */
	DECLARE @RowCount INT
	DECLARE @PageHead INT

	IF @Backward = 0
	BEGIN
		SELECT @RowCount = ((@Page -1) * 20 + 1)
		SELECT TOP 20 Ranking, ClanName as ClanName, Point, Wins, Losses, CLID FROM ClanHonorRanking(NOLOCK) 
		WHERE Year=@Year AND Month=@Month AND Ranking>0 AND Ranking >= @RowCount ORDER BY Ranking
	END
	ELSE
	BEGIN
		SELECT @RowCount = ((@Page -1) * 20 + 1)
	
		SET ROWCOUNT @RowCount
		SELECT @PageHead = Ranking FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY Ranking DESC
	
		SET ROWCOUNT 20
		SELECT  Ranking, RankIncrease=0, ClanName, Point, Wins, Losses, CLID, EmblemUrl=NULL FROM
		(
			SELECT TOP 20 Ranking, ClanName, Point, Wins, Losses, CLID FROM ClanHonorRanking(NOLOCK) 
			WHERE Year=@Year AND Month=@Month AND Ranking>0 AND Ranking <= @PageHead ORDER BY Ranking DESC
		) AS t ORDER BY Ranking
	END
END
GO

--
-- Definition for stored procedure spGetClanRankingMaxPage : 
--
GO
CREATE PROC [dbo].[spGetClanRankingMaxPage]
AS
SET NOCOUNT ON
BEGIN
	DECLARE @MaxPage INT
	SELECT TOP 1 @MaxPage = Ranking / 20 + 1 FROM Clan(NOLOCK) WHERE DeleteFlag=0 AND Ranking>0 ORDER BY Ranking DESC
--	SELECT @MaxPage
	RETURN @MaxPage
END
GO

--
-- Definition for stored procedure spGetClanRankingSearchByName : 
--
GO
CREATE PROC [dbo].[spGetClanRankingSearchByName]
	@Name VARCHAR(24)
AS
SET NOCOUNT ON
BEGIN
	SELECT TOP 20 Ranking, RankIncrease, Name as ClanName, Point, Wins, Losses, CLID, EmblemUrl FROM Clan(NOLOCK) 
	WHERE DeleteFlag=0 AND Ranking>0 AND Name=@Name ORDER BY Ranking
END
GO

--
-- Definition for stored procedure spGetClanRankingSearchByRanking : 
--
GO
/* ?? ???? (???)
    Arg1 : @Ranking (??) */
CREATE PROC [dbo].[spGetClanRankingSearchByRanking]
	@Ranking INT
AS
SET NOCOUNT ON
BEGIN
	SELECT TOP 20 Ranking, RankIncrease, Name as ClanName, Point, Wins, Losses, CLID, EmblemUrl FROM Clan(NOLOCK) 
	WHERE DeleteFlag=0 AND Ranking>0 AND Ranking=@Ranking ORDER BY Ranking
END
GO

-- ?????? CLID????
CREATE PROC [dbo].[spGetCLIDFromClanName]
	@ClanName		varchar(24)
AS
	SET NOCOUNT ON
	SELECT CLID FROM Clan(NOLOCK) WHERE Name=@ClanName
GO

--
-- Definition for stored procedure spGetDBConnection : 
--
GO
CREATE PROC [dbo].[spGetDBConnection]  
AS  
BEGIN
 SET NOCOUNT ON
 SELECT top 1 ServerID  
 FROM ServerStatus(NOLOCK)  
END
GO

-- ?? ?? ????
CREATE PROC [dbo].[spGetFriendList]
	@CID		int
AS
SET NOCOUNT ON
SELECT  f.FriendCID, f.Favorite,  c.Name 
FROM Friend f(NOLOCK), Character c(NOLOCK) 
WHERE f.CID=@CID AND f.FriendCID=c.CID AND f.DeleteFlag=0 AND f.Type=1
GO

--
-- Definition for stored procedure spGetGambleItemList : 
--
GO
CREATE PROC [dbo].[spGetGambleItemList]
AS
BEGIN
 SET NOCOUNT ON
 
 SELECT GIID, Name, Description, Price
 , DATEDIFF(mi, GETDATE(), StartDate) AS 'StartDiffMin'
 , LifeTimeHour * 60 as 'LifeTimeMin', Opened, IsCash
 FROM GambleItem(NOLOCK) 
END
GO

--
-- Definition for stored procedure spGetGambleRewardItem : 
--
GO
CREATE PROC [dbo].[spGetGambleRewardItem]
AS
BEGIN
 SET NOCOUNT ON
 SELECT GIID, ItemIDMale, ItemIDFemale, RentHourPeriod, RatePerThousand 
 FROM GambleRewardItem(NOLOCK)
END
GO

--
-- Definition for stored procedure spGetHourMaxPlayerCount : 
--
GO
CREATE proc [dbo].[spGetHourMaxPlayerCount] 
 @begin smalldatetime
, @end smalldatetime
as
 set nocount on

 if 0 <> datediff(dd, @begin, @end) return

 select t.hour, max(t.playercount) as maxplayercount
 from
 (
  select datepart(hh, time) as hour, sum(playercount) as playercount
  from logdb.game.serverlogstorage(nolock)
  where time >= @begin and time <= @end
  group by time
 ) as t
 group by t.hour
 order by t.hour
GO

--
-- Definition for stored procedure spGetIPCountryCode : 
--
GO
CREATE PROC [dbo].[spGetIPCountryCode]         
 @IP char(15)        
AS        
 SET NOCOUNT ON        
        
 DECLARE @IPNumber BIGINT        
 SET @IPNumber = GunzDB.game.inet_aton(@IP)        
        
 SELECT IPFrom, IPTo, CountryCode3 FROM IPtoCountry(NOLOCK)        
 WHERE IPFrom <= @IPNumber AND IPTo >= @IPNumber
GO

--
-- Definition for stored procedure spGetIPtoCountry : 
--
GO
CREATE PROCEDURE [dbo].[spGetIPtoCountry]  
@IP VARCHAR(15),  
@Code VARCHAR(3) OUTPUT  
AS  
BEGIN  
 DECLARE @IPNumber BIGINT  
 SELECT @IPNumber=GunzDB.game.inet_aton(@IP)  
   
 SELECT @Code=CountryCode3 FROM IPtoCountry(NOLOCK)   
 WHERE IPFrom <= @IPNumber AND IPTo >= @IPNumber  
END
GO

--
-- Definition for stored procedure spGetIPtoCountryList : 
--
GO
CREATE PROC [dbo].[spGetIPtoCountryList]  
AS  
 SELECT IPFrom, IPTo, CountryCode3   
 FROM IPtoCountry(NOLOCK)  
 ORDER BY IPFrom
GO

--
-- Definition for stored procedure spGetItemList : 
--
GO
CREATE proc [dbo].[spGetItemList]
 @ItemType int -- 0:any 1:melee 2:range 3:amor 4:special
, @Page int
, @PageCount int output
, @PageSize int
, @ItemSex tinyint -- 0:common 1:male 2:female
, @ItemLevel int -- max level 0:any
, @ItemName varchar(256)
, @RecordCount int output
, @Ret int output
as
 set nocount on	

 declare @sql varchar(8000)
 declare @sql_param nvarchar(128)
 declare @sql_ShopItemCount nvarchar(4000)
 declare @ItemTypeWhere varchar(256)
 declare @PageSizeWhere varchar(256)
 declare @ItemSexWhere varchar(256)
 declare @ItemLevelWhere varchar(256)
 declare @ItemNameWhere varchar(256)
 declare @rowcnt int
 declare @itemcnt int
 declare @show_page_size int

 if (0 > @ItemType) or (4 < @ItemType) begin
  set @Ret = -1
  return @Ret
 end

 set @ItemTypeWhere = ''
 set @PageSizeWhere = ''
 set @ItemSexWhere = ''
 set @ItemLevelWhere = ''
 set @ItemNameWhere = ''

 if 1 = @ItemType begin
  set @ItemTypeWhere = 'and i.Slot = 1 '
 end
 else if 2 = @ItemType begin
  set @ItemTypeWhere = 'and i.Slot = 2 '
 end
 else if 3 = @ItemType begin
  set @ItemTypeWhere = 'and (i.Slot = 4 or i.Slot = 5 or i.Slot = 6 or
 i.Slot = 7 or i.Slot = 8) '
 end
 else if 4 = @ItemType begin
  set @ItemTypeWhere = 'and (i.Slot = 3 or i.Slot = 10 or i.Slot = 0) '
 end

 if 1 = @ItemSex begin
  set @ItemSexWhere = 'and i.ResSex = 1 '
 end
 else if 2 = @ItemSex begin
  set @ItemSexWhere = 'and i.ResSex = 2'
 end

 if 0 < @ItemLevel begin
  set @ItemLevelWhere = 'and  i.ResLevel <= ' + cast(@ItemLevel as char(2)) + ' '
 end

 if @itemName is not null begin
  set @ItemNameWhere = 'and i.Name like ''%' + @ItemName + '%'''
 end

 set @sql_ShopItemCount = ' 
  select @itemcnt = count(cs.csid) from dbo.item i(nolock), dbo.cashshop cs(nolock)
  where i.itemid = cs.itemid and cs.opened = 1 '
  + @ItemTypeWhere
  + @ItemSexWhere
  + @ItemLevelWhere
  + @ItemNameWhere + ' 
  if( 0 < (@itemcnt % @PageSize) )
   set @PageCount = (@itemcnt / @PageSize) + 1
  else
   set @PageCount = @itemcnt / @PageSize '

-- select @pagecount as pagecount, @itemcnt as itemcount, @pagesize as pagesize '

 set @sql_param = '@PageCount int output, @itemcnt int output , @PageSize int'
 exec sp_executesql @sql_ShopItemCount, @sql_param, @PageCount output, @itemcnt output, @PageSize

 if (0 = @page) or (@page > @PageCount) begin
  set @Ret = -2
  return @Ret
 end

 set @RecordCount = @itemcnt

--  exec (  'select cs.csid, i.itemid, i.name, i.ressex, i.reslevel from item i(nolock), cashshop cs(nolock)
--   where i.itemid = cs.itemid and cs.opened = 1 '
--   + @ItemTypeWhere
--   + @ItemSexWhere
--   + @ItemLevelWhere
--   + @ItemNameWhere + ' order by cs.csid desc'  )

 set @rowcnt = @page * @pagesize

 if @itemcnt < (@page * @pagesize)
  set @show_page_size = @itemcnt % @pagesize
 else
  set @show_page_size = @pagesize

-- select @show_page_size as 'show page size', @itemcnt as 'item count', @page * @pagesize as 'total size'

 set @sql = '
  declare @csid table(id int)

  set rowcount ' + cast(@rowcnt as varchar(128)) + '

  insert into @csid(id) 
  select cs.csid from dbo.item i(nolock), dbo.cashshop cs(nolock)
  where i.itemid = cs.itemid and cs.opened = 1 '  
  + @ItemTypeWhere
  + @ItemSexWhere
  + @ItemLevelWhere
  + @ItemNameWhere
  + ' order by cs.csid

  set rowcount ' + cast(@show_page_size as varchar(128)) + ' 

  select t.*
  from
  (
   select top ' + cast(@show_page_size as varchar(128)) + ' 
   cs.CSID, i.Name, i.Slot, cs.CashPrice as Cash, cs.WebImgName
    , i.ResSex, i.ResLevel, i.Weight, i.Description, cs.RegDate
    , cs.NewItemOrder, cs.RentType
   from dbo.cashshop cs(nolock), @csid c, dbo.item i(nolock)
   where cs.csid = c.id and cs.opened = 1 and i.itemid = cs.itemid
   order by cs.csid desc
  ) as t
  order by t.csid'

 exec (@sql)

 set @Ret = 1
 return @Ret
GO

-- ??? ????
CREATE PROC [dbo].[spGetLadderTeamMemberByCID]
	@CID		int
AS
RETURN
GO

--
-- Definition for stored procedure spGetLoginInfo : 
--
GO
/* LoginInfo ??? */
CREATE PROC [dbo].[spGetLoginInfo]
	@UserID		varchar(20)
AS
SET NOCOUNT ON
SELECT AID, UserID, Password FROM Login(nolock) WHERE UserID = @UserID
GO

--
-- Definition for stored procedure spGetNewCashItem : 
--
GO
CREATE  PROC [dbo].[spGetNewCashItem]
	@ItemCount	int 	= 0
AS
SET NoCount On

IF @ItemCount != 0
BEGIN
	SET ROWCOUNT @ItemCount
END

	SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot, 
		cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
		i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight,
		i.Description AS Description, cs.RentType AS RentType
	FROM CashShop cs (nolock) , Item i (nolock)
	WHERE i.ItemID = cs.ItemID AND cs.NewItemOrder > 0 AND Opened=1 
	order by cs.NewItemOrder asc
GO

-- ??? ?? ??? ?? ?? ??
CREATE  PROC [dbo].[spGetRentCashSetShopPrice]
	@CSSID		int
AS
	SET NOCOUNT ON
	SELECT RentHourPeriod, CashPrice 
	FROM RentCashSetShopPrice(nolock) WHERE CSSID = @CSSID
	ORDER BY CashPrice
GO

--
-- Definition for stored procedure spGetRentCashSetShopPriceByHour : 
--
GO
CREATE PROC [dbo].[spGetRentCashSetShopPriceByHour]
	@CSSID		int
,	@RentHourPeriod	smallint
AS
	SET NOCOUNT ON
	IF @RentHourPeriod IS NOT NULL
	BEGIN
		-- ??? ???
		SELECT CashPrice
		FROM RentCashSetShopPrice(nolock)
		WHERE CSSID = @CSSID AND RentHourPeriod = @RentHourPeriod
	END
	ELSE IF @RentHourPeriod IS NULL
	BEGIN
		-- ?? ???.
		SELECT CashPrice
		FROM RentCashSetShopPrice(nolock)
		WHERE CSSID = @CSSID AND RentHourPeriod IS NULL
	END
GO

-- ??? ??? ?? ?? ??
CREATE PROC [dbo].[spGetRentCashShopPrice]
	@CSID		int
AS
	SET NOCOUNT ON
	SELECT RentHourPeriod, CashPrice 
	FROM RentCashShopPrice(nolock) WHERE CSID = @CSID
	ORDER BY CashPrice
GO

--
-- Definition for stored procedure spGetRentCashShopPriceByHour : 
--
GO
CREATE   PROC [dbo].[spGetRentCashShopPriceByHour]
	@CSID		int
,	@RentHourPeriod	smallint
AS
	SET NOCOUNT ON
	IF @RentHourPeriod IS NOT NULL
	BEGIN
		-- ??? ???
		SELECT CashPrice 
		FROM RentCashShopPrice (nolock)
		WHERE CSID = @CSID AND RentHourPeriod = @RentHourPeriod
	END
	ELSE IF @RentHourPeriod IS NULL
	BEGIN
		-- ?? ???
		SELECT CashPrice
		FROM RentCashShopPrice (nolock)
		WHERE CSID = @CSID AND RentHourPeriod IS NULL
	END
GO

--
-- Definition for stored procedure spGetSetItemList : 
--
GO
CREATE proc [dbo].[spGetSetItemList]
 @ItemType int -- 0:any 1:melee 2:range 3:amor 4:special
, @Page int
, @PageCount int output
, @PageSize int
, @ItemSex tinyint -- 0:common 1:male 2:female
, @ItemLevel int -- max level 0:any
, @ItemName varchar(256)
, @RecordCount int output
, @Ret int output
as
 set nocount on

 declare @sql varchar(8000)
 declare @sql_param nvarchar(128)
 declare @sql_SetShopItemCount nvarchar(4000)
 declare @PageSizeWhere varchar(256)
 declare @ItemSexWhere varchar(256)
 declare @ItemLevelWhere varchar(256)
 declare @ItemNameWhere varchar(256)
 declare @rowcnt int
 declare @itemcnt int
 declare @show_page_size int

 if (0 > @ItemType) or (4 < @ItemType) begin
  set @Ret = -1
  return @Ret
 end

 set @PageSizeWhere = ''
 set @ItemSexWhere = ''
 set @ItemLevelWhere = ''
 set @ItemNameWhere = ''

 if 1 = @ItemSex begin
  set @ItemSexWhere = 'and css.ResSex = 1 '
 end
 else if 2 = @ItemSex begin
  set @ItemSexWhere = 'and css.ResSex = 2'
 end

 if 0 < @ItemLevel begin
  set @ItemLevelWhere = 'and  css.ResLevel <= ' + cast(@ItemLevel as char(2)) + ' '
 end

 if @itemName is not null begin
  set @ItemNameWhere = 'and css.Name like ''%' + @ItemName + '%'''
 end

 set @sql_SetShopItemCount = ' 
  select @itemcnt = count(css.cssid) from dbo.cashsetshop css(nolock)
  where css.opened = 1 '
  + @ItemSexWhere
  + @ItemLevelWhere
  + @ItemNameWhere + ' 
  if( 0 < (@itemcnt % @PageSize) )
   set @PageCount = (@itemcnt / @PageSize) + 1
  else
   set @PageCount = @itemcnt / @PageSize '

-- select @pagecount as pagecount, @itemcnt as itemcount, @pagesize as pagesize '

 set @sql_param = '@PageCount int output, @itemcnt int output , @PageSize int'
 exec sp_executesql @sql_SetShopItemCount, @sql_param, @PageCount output, @itemcnt output, @PageSize

 if (0 = @page) or (@page > @PageCount) begin
  set @Ret = -2
  return @Ret
 end

 set @RecordCount = @itemcnt
 set @rowcnt = @page * @pagesize

 if @itemcnt < (@page * @pagesize)
  set @show_page_size = @itemcnt % @pagesize
 else
  set @show_page_size = @pagesize

-- select @show_page_size as 'show page size', @itemcnt as 'item count', @page * @pagesize as 'total size'

 set @sql = '
  declare @cssid table(id int)

  set rowcount ' + cast(@rowcnt as varchar(128)) + '

  insert into @cssid(id) 
  select css.cssid from dbo.cashsetshop css(nolock) where css.opened = 1 '  
  + @ItemSexWhere
  + @ItemLevelWhere
  + @ItemNameWhere
  + ' order by css.cssid

  set rowcount ' + cast(@show_page_size as varchar(128)) + ' 

  select t.*
  from
  (
   select top ' + cast(@show_page_size as varchar(128)) + ' 
    css.CSSID, css.Name, css.CashPrice as Cash, css.WebImgName, 
    css.ResSex, css.ResLevel, css.Weight, css.Description, css.RegDate,
    css.NewItemOrder as IsNewItem, css.RentType
   from dbo.cashsetshop css(nolock), @cssid cs
   where css.cssid = cs.id and css.opened = 1
   order by css.cssid desc
  ) as t
  order by t.cssid'

 exec (@sql)

 set @Ret = 1
 return @Ret
GO

--
-- Definition for stored procedure spGetSexInfo : 
--
GO
CREATE PROC [dbo].[spGetSexInfo]
	@AID		int
AS
SET NOCOUNT ON
SELECT Sex, RegNum, Email FROM Account WHERE AID=@AID
GO

--
-- Definition for stored procedure spGetTotalRanking : 
--
GO
/* ?? ?? ?? */
CREATE PROC [dbo].[spGetTotalRanking]
	@MinRank		int,
	@MaxRank		int
AS
SET NOCOUNT ON

SELECT Rank, Level, UserID, Name, XP, KillCount, DeathCount FROM TotalRanking(nolock)
WHERE Rank BETWEEN @MinRank AND @MaxRank
ORDER BY Rank
GO

--
-- Definition for stored procedure spInsertAccount : 
--
GO
/* ?? ?? */
CREATE   PROC [dbo].[spInsertAccount] 
	@UserID		varchar(20)
,	@Password	varchar(20)
, @Cert		tinyint
,	@Name		varchar(128)
, @Age		smallint
,	@Sex		tinyint

AS

BEGIN TRAN

 	SET NOCOUNT ON
	DECLARE @AIDIdent 	int

	INSERT INTO Account (UserID, Cert, Name, Age, Sex, UGradeID, PGradeID, RegDate)
	Values (@UserID, @Cert, @Name, @Age, @Sex, 0, 0, GETDATE())
	IF 0 <> @@ERROR
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

	SET @AIDIdent = @@IDENTITY

	INSERT INTO Login (UserID, AID, Password)
	Values (@UserID, @AIDIdent, @Password)
	IF 0 <> @@ERROR
	BEGIN
		ROLLBACK TRAN
		RETURN
	END

COMMIT TRAN
GO

--
-- Definition for stored procedure spInsertChar : 
--
GO
/* ??? ?? */
CREATE PROC [dbo].[spInsertChar]
	@AID		int,
	@CharNum	smallint,
	@Name		varchar(24),
	@Sex		tinyint,
	@Hair		int,  
	@Face		int,
	@Costume	int
AS
SET NOCOUNT ON
BEGIN TRAN
IF EXISTS (SELECT CID FROM Character where (AID=@AID AND CharNum=@CharNum) OR (Name=@Name))
BEGIN	
	ROLLBACK TRAN
	return(-1)
END

DECLARE @CharIdent 	int
DECLARE @ChestCIID	int
DECLARE @LegsCIID	int
DECLARE @MeleeCIID	int
DECLARE @PrimaryCIID	int
DECLARE @SecondaryCIID  int
DECLARE @Custom1CIID	int
DECLARE @Custom2CIID	int

DECLARE @ChestItemID	int
DECLARE @LegsItemID	int
DECLARE @MeleeItemID	int
DECLARE @PrimaryItemID	int
DECLARE @SecondaryItemID  int
DECLARE @Custom1ItemID	int
DECLARE @Custom2ItemID	int

SET @SecondaryCIID = NULL
SET @SecondaryItemID = NULL

SET @Custom1CIID = NULL
SET @Custom1ItemID = NULL

SET @Custom2CIID = NULL
SET @Custom2ItemID = NULL

INSERT INTO Character (AID, Name, CharNum, Level, Sex, Hair, Face, XP, BP, FR, CR, ER, WR, 
         		           GameCount, KillCount, DeathCount, RegDate, PlayTime, DeleteFlag)
Values (@AID, @Name, @CharNum, 1, @Sex, @Hair, @Face, 0, 0, 0, 0, 0, 0, 0, 0, 0, GETDATE(), 0, 0)
IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
END


SET @CharIdent = @@IDENTITY

  /* Melee */
  SET @MeleeItemID = 
    CASE @Costume
    WHEN 0 THEN 1
    WHEN 1 THEN 2
    WHEN 2 THEN 1
    WHEN 3 THEN 2
    WHEN 4 THEN 2
    WHEN 5 THEN 1
    END

  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @MeleeItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END

  SET @MeleeCIID = @@IDENTITY

  /* Primary */
  SET @PrimaryItemID = 
    CASE @Costume
    WHEN 0 THEN 5001
    WHEN 1 THEN 5002
    WHEN 2 THEN 4005
    WHEN 3 THEN 4001
    WHEN 4 THEN 4002
    WHEN 5 THEN 4006
    END

  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @PrimaryItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END

  SET @PrimaryCIID = @@IDENTITY

  /* Secondary */
IF @Costume = 0 OR @Costume = 2 BEGIN
  SET @SecondaryItemID =
    CASE @Costume
    WHEN 0 THEN 4001
    WHEN 1 THEN 0
    WHEN 2 THEN 5001
    WHEN 3 THEN 4006
    WHEN 4 THEN 0
    WHEN 5 THEN 4006
    END

  IF @SecondaryItemID <> 0 BEGIN
    INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @SecondaryItemID)
    IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
    END

    SET @SecondaryCIID = @@IDENTITY
  END
END
  SET @Custom1ItemID = 
    CASE @Costume
    WHEN 0 THEN 30301
    WHEN 1 THEN 30301
    WHEN 2 THEN 30401
    WHEN 3 THEN 30401
    WHEN 4 THEN 30401
    WHEN 5 THEN 30101
    END

  /* Custom1 */
  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @Custom1ItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END

  SET @Custom1CIID = @@IDENTITY

  /* Custom2 */
IF @Costume = 4 OR @Costume = 5
BEGIN
  SET @Custom2ItemID =
    CASE @Costume
    WHEN 0 THEN 0
    WHEN 1 THEN 0
    WHEN 2 THEN 0
    WHEN 3 THEN 0
    WHEN 4 THEN 30001
    WHEN 5 THEN 30001
    END

  IF @Custom2ItemID <> 0
  BEGIN
    INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @Custom2ItemID)
    IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
    END

    SET @Custom2CIID = @@IDENTITY
  END
END


IF @Sex = 0		/* ??? ?? */
BEGIN

  /* Chest */
  SET @ChestItemID =
    CASE @Costume
    WHEN 0 THEN 21001
    WHEN 1 THEN 21001
    WHEN 2 THEN 21001
    WHEN 3 THEN 21001
    WHEN 4 THEN 21001
    WHEN 5 THEN 21001
    END


  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @ChestItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END

  SET @ChestCIID = @@IDENTITY

  /* Legs */
  SET @LegsItemID =
    CASE @Costume
    WHEN 0 THEN 23001
    WHEN 1 THEN 23001
    WHEN 2 THEN 23001
    WHEN 3 THEN 23001
    WHEN 4 THEN 23001
    WHEN 5 THEN 23001
    END


  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @LegsItemID)
  IF 0 <> @@ERROR BEGIN 
	ROLLBACK TRAN
	RETURN (-1)
  END

  SET @LegsCIID = @@IDENTITY

END
ELSE
BEGIN			/* ??? ?? */

  /* Chest */
  SET @ChestItemID =
    CASE @Costume
    WHEN 0 THEN 21501
    WHEN 1 THEN 21501
    WHEN 2 THEN 21501
    WHEN 3 THEN 21501
    WHEN 4 THEN 21501
    WHEN 5 THEN 21501
    END


  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @ChestItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END
  SET @ChestCIID = @@IDENTITY

  /* Legs */
  SET @LegsItemID =
    CASE @Costume
    WHEN 0 THEN 23501
    WHEN 1 THEN 23501
    WHEN 2 THEN 23501
    WHEN 3 THEN 23501
    WHEN 4 THEN 23501
    WHEN 5 THEN 23501
    END


  INSERT INTO CharacterItem (CID, ItemID) Values (@CharIdent, @LegsItemID)
  IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
  END
  SET @LegsCIID = @@IDENTITY

END  

UPDATE Character
SET chest_slot = @ChestCIID, legs_slot = @LegsCIID, melee_slot = @MeleeCIID,
    primary_slot = @PrimaryCIID, secondary_slot = @SecondaryCIID, custom1_slot = @Custom1CIID,
    custom2_slot = @Custom2CIID,
    chest_itemid = @ChestItemID, legs_itemid = @LegsItemID, melee_itemid = @MeleeItemID,
    primary_itemid = @PrimaryItemID, secondary_itemid = @SecondaryItemID, custom1_itemid = @Custom1ItemID,
    custom2_itemid = @Custom2ItemID
WHERE CID=@CharIdent
IF 0 = @@ROWCOUNT BEGIN
	ROLLBACK TRAN
	RETURN (-1)
END
COMMIT TRAN
GO

--
-- Definition for stored procedure spInsertCharItem : 
--
GO
/****** Object:  Stored Procedure dbo.spInsertCharItem    Script Date: 12/3/2008 3:42:11 PM ******/


/* ??? ??? ?? - ?? */
CREATE PROC [dbo].[spInsertCharItem]
    @CID        int,
    @ItemID        int,
    @per        int
AS
SET NOCOUNT ON 

DECLARE @OrderCIID    int
DECLARE @varBP         int
-- ??
SELECT @varBP = BP FROM Character where CID=@CID
IF @varBP < 0
BEGIN
    UPDATE Character SET BP=0 WHERE CID=@CID
    RETURN (-1)
END


BEGIN TRAN
INSERT INTO CharacterItem (CID, ItemID, RegDate, RentDate, RentHourPeriod) Values (@CID, @ItemID, GETDATE(), GETDATE(), @per)
IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN (-1)
END
COMMIT TRAN

SET @OrderCIID = @@IDENTITY
SELECT @OrderCIID as ORDERCIID
GO

--
-- Definition for stored procedure spInsertCharMakingLog : 
--
GO
/* ??? ?? ?? */
CREATE PROC [dbo].[spInsertCharMakingLog]
	@AID		int,
	@CharName	varchar(32),
	@Type		varchar(20)
AS
SET NOCOUNT ON
BEGIN TRAN
INSERT INTO CharacterMakingLog (AID, CharName, Type, Date)
VALUES (@AID, @CharName, @Type, GETDATE())
IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN
END
COMMIT TRAN
GO

--
-- Definition for stored procedure spInsertConnLog : 
--
GO
CREATE PROC [dbo].[spInsertConnLog] 
 @AID int
, @IPPart1 tinyint
, @IPPart2 tinyint
, @IPPart3 tinyint
, @IPPart4 tinyint
, @CountryCode3	char(3)
AS
 SET NOCOUNT ON
 INSERT INTO ConnLog( AID, Time, IPPart1, IPPart2, IPPart3, IPPart4, CountryCode3)
 VALUES (@AID, GETDATE(), @IPPart1, @IPPart2, @IPPart3, @IPPart4, @CountryCode3)
GO

--
-- Definition for stored procedure spInsertEvent : 
--
GO
CREATE PROC [dbo].[spInsertEvent] 
 @AID int
, @CID int
, @EventName varchar(24)
AS
 SET NOCOUNT ON 
 INSERT INTO Event( AID, CID, RegDate, Checked, EventName )
 VALUES (@AID, @CID, GETDATE(), 0, @EventName)
GO

--
-- Definition for stored procedure spInsertGameLog : 
--
GO
/* ?? ?? ?? */
CREATE PROC [dbo].[spInsertGameLog]
	@GameName	varchar(64),
	@Map		varchar(32),
	@GameType	varchar(24),
	@Round		int,
	@MasterCID	int,
	@PlayerCount	tinyint,
	@Players	varchar(1000)

AS
SET NOCOUNT ON
BEGIN TRAN
INSERT INTO GameLog (GameName, Map, GameType, Round, MasterCID, StartTime, PlayerCount, Players)
VALUES (@GameName, @Map, @GameType, @Round, @MasterCID, GETDATE(), @PlayerCount, @Players)
IF 0 <> @@ERROR BEGIN 
	ROLLBACK TRAN
	RETURN
END
COMMIT TRAN
GO

--
-- Definition for stored procedure spInsertItemPurchaseLogByBounty : 
--
GO
/* ??? ??(???) ?? */
CREATE PROC [dbo].[spInsertItemPurchaseLogByBounty]
	@ItemID		int,
	@CID		int,
	@Bounty		int,
	@CharBounty	int,
	@Type		varchar(20)
AS
SET NOCOUNT ON
INSERT INTO ItemPurchaseLogByBounty
	(ItemID, CID, Date, Bounty, CharBounty, Type)
VALUES
	(@ItemID, @CID, GETDATE(), @Bounty, @CharBounty, @Type)
GO

--
-- Definition for stored procedure spInsertKillLog : 
--
GO
/* ? ?? ?? */
CREATE PROC [dbo].[spInsertKillLog]
	@AttackerCID	int,
	@VictimCID	int
AS
SET NOCOUNT ON
BEGIN TRAN
INSERT INTO KillLog (AttackerCID, VictimCID, Time)
VALUES (@AttackerCID, @VictimCID, GETDATE())
IF 0 <> @@ERROR BEGIN
	ROLLBACK TRAN
	RETURN
END
COMMIT TRAN
GO

-- ??? ?? ??
CREATE PROC [dbo].[spInsertLevelUpLog]
	@CID			int,
	@Level			smallint,
	@BP				int,
	@KillCount		int,
	@DeathCount		int,
	@PlayTime		int
AS
SET NOCOUNT ON
BEGIN TRAN
	INSERT INTO LevelUpLog(CID, Level, BP, KillCount, DeathCount, PlayTime, Date)
	VALUES (@CID, @Level, @BP, @KillCount, @DeathCount, @PlayTime, GETDATE())
	IF 0 <> @@ERROR BEGIN
		ROLLBACK TRAN
		RETURN
	END
COMMIT TRAN
GO

--
-- Definition for stored procedure spInsertLocatorLog : 
--
GO
CREATE  PROC [dbo].[spInsertLocatorLog]  
 @LocatorID int  
, @CountryCode3 varchar(3)  
, @Count int   
AS  
 SET NOCOUNT ON   
 INSERT INTO LogDB.game.LocatorLog(LocatorID, CountryCode3, Count, RegDate)  
 VALUES (@LocatorID, @CountryCode3, @Count, GETDATE())
GO

--
-- Definition for stored procedure spInsertPlayerLog : 
--
GO
/* ???? ?? */
CREATE PROC [dbo].[spInsertPlayerLog]
	@CID          int,
	@PlayTime     int,
	@Kills        int,
	@Deaths       int,
	@XP           int,
	@TotalXP      int
AS
SET NOCOUNT ON
BEGIN TRAN
INSERT INTO PlayerLog (CID, DisTime, PlayTime, Kills, Deaths, XP, TotalXP)
VALUES	(@CID, GETDATE(), @PlayTime, @Kills, @Deaths, @XP, @TotalXP)
IF 0 <> @@ERROR BEGIN 
	ROLLBACK TRAN
	RETURN
END
COMMIT TRAN
GO

-- ??? ?? ?? ?? ?? ????.
CREATE PROC [dbo].[spInsertQuestGameLog]
	@GameName varchar(64)
,	@Master int 
,	@Player1 int 
,	@Player2 int
,	@Player3 int
,	@TotalQItemCount smallint 
,	@ScenarioID smallint 
,	@GamePlayTime tinyint 
AS
SET NOCOUNT ON

BEGIN TRAN
	INSERT INTO QuestGameLog(GameName, Master, Player1, Player2, Player3, TotalQItemCount, ScenarioID, StartTime, EndTime)
	VALUES (@GameName, @Master, @Player1, @Player2, @Player3, @TotalQItemCount, @ScenarioID, DATEADD(n, -(@GamePlayTime), GETDATE()), GETDATE() )
	IF 0 <> @@ERROR BEGIN -- ?? ??.
		ROLLBACK TRAN
		RETURN
	END

	SELECT @@IDENTITY AS 'ORDERQGLID'
COMMIT TRAN
GO

-- ??? ??? ??? ?? ????.
CREATE PROC [dbo].[spInsertQUniqueItemLog]
	@QGLID int
,	@CID int
,	@QIID int
AS
BEGIN
	SET NOCOUNT ON
	INSERT INTO QUniqueItemLog(QGLID, CID, QIID) VALUES (@QGLID, @CID, @QIID)
END
GO

-- ??? ?? ??? ?? ?? ??
CREATE PROC [dbo].[spInsertRentCashSetShopPrice]
	@CSSID		int,
	@RentHourPeriod	smallint,
	@CashPrice	int
AS
	SET NOCOUNT ON
	INSERT INTO RentCashSetShopPrice(CSSID, RentHourPeriod, CashPrice) 
	VALUES (@CSSID, @RentHourPeriod, @CashPrice)
GO

-- ??? ??? ?? ?? ??
CREATE PROC [dbo].[spInsertRentCashShopPrice]
	@CSID			int
,	@RentHourPeriod		smallint
,	@CashPrice		int
AS
	SET NOCOUNT ON
	INSERT INTO RentCashShopPrice (CSID, RentHourPeriod, CashPrice)
	VALUES (@CSID, @RentHourPeriod, @CashPrice)
GO

--
-- Definition for stored procedure spInsertServerLog : 
--
GO
CREATE PROC [dbo].[spInsertServerLog]
 @ServerID smallint
, @PlayerCount smallint
, @GameCount smallint
, @BlockCount int
, @NonBlockCount int
AS
 SET NOCOUNT ON
 INSERT INTO ServerLog(ServerID, PlayerCount, 
  GameCount, Time, BlockCount, NonBlockCount)
 VALUES (@ServerID, @PlayerCount, @GameCount, 
  GETDATE(), @BlockCount, @NonBlockCount )
GO

--
-- Definition for stored procedure spIPFltCheckIsDuplicateRange : 
--
GO
CREATE PROC [dbo].[spIPFltCheckIsDuplicateRange]
 @IPFrom bigint
, @IPTo bigint
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
  IF EXISTS (SELECT CountryCode3 FROM CustomIP(NOLOCK)
  WHERE (IPFrom <= @IPFrom AND IPTo >= @IPFrom) OR
   (IPFrom <= @IPTo AND IPTo >= @IPTo)) SET @Ret = 1
 ELSE SET @Ret = 0
GO

--
-- Definition for stored procedure spIPFltDeleteCustomIP : 
--
GO
CREATE PROC [dbo].[spIPFltDeleteCustomIP]
 @IPFrom varchar(15)
, @IPTo varchar(15)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DECLARE @TmpIPFrom BIGINT
 DECLARE @TmpIPTo BIGINT

 SET @TmpIPFrom = dbo.inet_aton( @IPFrom )
 SET @TmpIPTo = dbo.inet_aton( @IPTo )
 IF @TmpIPFrom > @TmpIPTo BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 DELETE CustomIP WHERE IPFrom = @TmpIPFrom AND IPTo = @TmpIPTo
 IF 0 <> @@ERROR SET @Ret = 0
 ELSE SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spIPFltGetBlockCountryCodeList : 
--
GO
CREATE PROC [dbo].[spIPFltGetBlockCountryCodeList]
AS
 SET NOCOUNT ON
 SELECT CountryCode3, RoutingURL, IsBlock
 FROM BlockCountryCode(NOLOCK)
 ORDER BY CountryCode3
GO

--
-- Definition for stored procedure spIPFltGetCountryCode : 
--
GO
CREATE PROC [dbo].[spIPFltGetCountryCode]
AS
 SET NOCOUNT ON
 SELECT CountryCode3, CountryName
 FROM CountryCode(NOLOCK)
 ORDER BY CountryCode3 ASC
GO

--
-- Definition for stored procedure spIPFltGetCustomIP : 
--
GO
CREATE PROC [dbo].[spIPFltGetCustomIP]
 @IP varchar(15)
AS
 SET NOCOUNT ON
 DECLARE @TmpIP bigint

 SET @TmpIP = dbo.inet_aton( @IP )

 SELECT IPFrom, IPTo, IsBlock, Comment, RegDate
 FROM CustomIP(NOLOCK)
 WHERE IPFrom <= @TmpIP AND IPTo >= @TmpIP
GO

--
-- Definition for stored procedure spIPFltGetCustomIPList : 
--
GO
CREATE PROC [dbo].[spIPFltGetCustomIPList]
AS
 SET NOCOUNT ON
 SELECT IPFrom, IPTo, IsBlock, CountryCode3, Comment FROM CustomIP(NOLOCK)
 ORDER BY IPFrom
GO

--
-- Definition for stored procedure spIPFltGetIPtoCountry : 
--
GO
CREATE PROC [dbo].[spIPFltGetIPtoCountry]
 @IP char(15)
AS
 SET NOCOUNT ON
 DECLARE @IPNumber BIGINT
 SET @IPNumber = dbo.inet_aton( @IP )

 SELECT IPFrom, IPTo, CountryCode3 FROM IPtoCountry(NOLOCK)
 WHERE IPFrom <= @IPNumber AND IPTo >= @IPNumber
GO

--
-- Definition for stored procedure spIPFltGetIPtoCountryCode : 
--
GO
CREATE PROC [dbo].[spIPFltGetIPtoCountryCode]
 @IP char(15)
AS
 SET NOCOUNT ON
 DECLARE @IPNumber BIGINT
 SET @IPNumber = dbo.inet_aton( @IP )

 SELECT CountryCode3 FROM IPtoCountry(NOLOCK)
 WHERE IPFrom <= @IPNumber AND IPTo >= @IPNumber
GO

--
-- Definition for stored procedure spIPFltGetIPtoCountryList : 
--
GO
CREATE PROC [dbo].[spIPFltGetIPtoCountryList]
AS
 SET NOCOUNT ON
 SELECT IPFrom, IPTo, CountryCode3
 FROM IPtoCountry(NOLOCK)
 ORDER BY IPFrom
GO

--
-- Definition for stored procedure spIPFltInsertCustomIP : 
--
GO
/*
 * @Ret(0:Fail, 1:Success, 2:Duplicate, 3:Invers range)
 */
CREATE PROC [dbo].[spIPFltInsertCustomIP]
 @IPFrom varchar(15)
, @IPTo varchar(15)
, @IsBlock tinyint
, @CountryCode3 char(3)
, @Comment varchar(128)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DECLARE @DupRet int
 DECLARE @TmpIPFrom BIGINT
 DECLARE @TmpIPTo BIGINT

 SET @TmpIPFrom = dbo.inet_aton( @IPFrom )
 SET @TmpIPTo = dbo.inet_aton( @IPTo )
 IF @TmpIPFrom > @TmpIPTo BEGIN
  SET @Ret = 3
  RETURN @Ret
 END

 EXEC spIPFltCheckIsDuplicateRange @TmpIPFrom, @TmpIPTo, @DupRet OUTPUT
 IF 1 = @DupRet BEGIN
  SET @Ret = 2
  RETURN @Ret
 END

 INSERT INTO CustomIP(IPFrom, IPTo, CountryCode3, IsBlock, Comment, RegDate)
 VALUES (@TmpIPFrom, @TmpIPTo, @CountryCode3, @IsBlock, @Comment, GETDATE() )
 IF 0 <> @@ERROR SET @Ret = 0
 ELSE SET @Ret = 1
 RETURN @Ret
GO

--
-- Definition for stored procedure spIPFltUpdateCustomIP : 
--
GO
/*
 * @Ret(0:Fail, 1:Success, 2:Duplicate, 3:Invers range)
 */
CREATE PROC [dbo].[spIPFltUpdateCustomIP]
 @IPFrom varchar(15)
, @IPTo varchar(15)
, @NewIPFrom varchar(15)
, @NewIPTo varchar(15)
, @IsBlock tinyint
, @CountryCode3 char(3)
, @Comment varchar(128)
, @Ret int OUTPUT
AS
 SET NOCOUNT ON
 DECLARE @DupRet bigint
 DECLARE @TmpIPFrom BIGINT
 DECLARE @TmpIPTo BIGINT
 DECLARE @TmpNewIPFrom bigint
 DECLARE @TmpNewIPTo bigint

 SET @TmpIPFrom = dbo.inet_aton( @IPFrom )
 SET @TmpIPTo = dbo.inet_aton( @IPTo )

 IF @TmpIPFrom > @TmpIPTo BEGIN
  SET @Ret = 3
  RETURN @Ret
 END

 SET @TmpNewIPFrom = dbo.inet_aton( @NewIPFrom )
 SET @TmpNewIPTo = dbo.inet_aton( @NewIPTo )

 IF @TmpNewIPFrom > @TmpNewIPTo BEGIN
  SET @Ret = 0
  RETURN @Ret
 END

 -- ?? IP??? ??? IP?? ?? ?? ???? ???? ??.
 IF (@TmpIPFrom <> @TmpNewIPFrom) OR (@TmpIPTo <> @TmpNewIPTo) BEGIN
  EXEC spIPFltCheckIsDuplicateRange @TmpNewIPFrom, @TmpNewIPTo, @DupRet OUTPUT
  IF 1 = @DupRet BEGIN
   SET @Ret = 2
   RETURN @Ret
  END
 END

 UPDATE CustomIP
 SET IPFrom = @TmpNewIPFrom, IPTo = @TmpNewIPTo,
  IsBlock = @IsBlock, CountryCode3 = @CountryCode3,
  Comment = @Comment
 WHERE IPFrom = @TmpIPFrom AND IPTo = @TmpIPTo
 IF 0 <> @@ERROR OR 0 = @@ROWCOUNT SET @Ret = 0
 ELSE SET @Ret = 1
 RETURN @Ret
GO

-- ??? ?? ?? ??
CREATE PROC [dbo].[spIsExistCharName]
	@CharName	varchar(24)
AS
SET NOCOUNT ON
IF EXISTS (SELECT TOP 1 CID FROM Character(nolock) where (Name=@CharName) AND (DeleteFlag=0))
BEGIN
	SELECT 1 AS Ret
END
ELSE
BEGIN
	SELECT 0 AS Ret
END
GO

--
-- Definition for stored procedure spItemList : 
--
GO
create procedure [dbo].[spItemList]
	@ItemType	int,
	@ResSex		int,
	@ResLevel	int,
	@ResText	nvarchar(100),
	
	@Page		int,
	@PageSize	int,
	@PageCount	int output
AS
set NoCount On

declare @Rows int
declare @ViewCount int
select @Rows = @Page * @PageSize
declare @PageHead INT
declare @RowCount INT


if @ItemType = -1																/* ITEMTYPE  = -1 */
	begin
		if @ResSex = -1														/* ITEMTYPE  = -1  RESSEX  = -1 */
			begin
				if @ResLevel = -1												/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL  = -1 */
					begin
						if @ResText = ''										/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL  = -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								order by cs.csid desc
							end
						else													/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL  = -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
				else															/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL <> -1 */
					begin
						if @ResText = ''										/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL <> -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								order by cs.csid desc
							end
						else													/* ITEMTYPE  = -1  RESSEX  = -1  RESLEVEL <> -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
			end
		else																	/* ITEMTYPE  = -1  RESSEX <> -1 */
			begin
				if @ResLevel = -1												/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL  = -1 */
					begin
						if @ResText = ''										/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL  = -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								order by cs.csid desc
							end
						else													/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL  = -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
				else															/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL <> -1 */
					begin
						if @ResText = ''										/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL <> -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								order by cs.csid desc
							end
						else													/* ITEMTYPE  = -1  RESSEX <> -1  RESLEVEL <> -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
			end
	end
else
	begin
		if @ResSex = -1														/* ITEMTYPE <> -1  RESSEX  = -1 */
			begin
				if @ResLevel = -1												/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL  = -1 */
					begin
						if @ResText = ''										/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL  = -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								order by cs.csid desc
							end
						else													/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL  = -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
				else															/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL <> -1 */
					begin
						if @ResText = ''										/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL <> -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								order by cs.csid desc
							end
						else													/* ITEMTYPE <> -1  RESSEX  = -1  RESLEVEL <> -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
			end
		else																	/* ITEMTYPE <> -1  RESSEX <> -1 */
			begin
				if @ResLevel = -1												/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL  = -1 */
					begin
						if @ResText = ''										/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL  = -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								order by cs.csid desc
							end
						else													/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL  = -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
				else															/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL <> -1 */
					begin
						if @ResText = ''										/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL <> -1  RESTEXT  = '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								order by cs.csid desc
							end
						else													/* ITEMTYPE <> -1  RESSEX <> -1  RESLEVEL <> -1  RESTEXT <> '' */
							begin
								select @PageCount = (COUNT(*) + (@PageSize-1)) / @PageSize
								from CashShop cs(nolock), viewItem i(nolock)
								where i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								
								select @RowCount = ((@Page -1) * @PageSize + 1)
								set rowcount @RowCount
								select @PageHead = cs.csid from CashShop cs(NOLOCK), viewItem i(nolock) 
								where cs.ItemID=i.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc

								set rowcount @PageSize
								select cs.csid AS CSID, i.name AS Name, i.Slot AS Slot,
								cs.CashPrice AS Cash, cs.WebImgName As WebImgName,
								i.ResSex as ResSex, i.ResLevel as ResLevel, i.Weight as Weight,
								i.Description as Description, cs.RegDate as RegDate, cs.NewItemOrder as IsNewItem,
								cs.RentType as RentType
								from CashShop cs(nolock), viewItem i(nolock)
								where csid <= @PageHead and i.ItemID = cs.ItemID and cs.Opened=1
								and i.SlotEx = @ItemType
								and i.ResSex = @ResSex
								and i.ResLevel <= @ResLevel
								and (i.Name like '%' + @ResText + '%' or i.Description like '%' + @ResText + '%')
								order by cs.csid desc
							end
					end
			end
	end
GO

--
-- Definition for stored procedure spLeague_FetchLeagueInfo : 
--
GO
CREATE PROC [dbo].[spLeague_FetchLeagueInfo]
AS
	RETURN
GO

--
-- Definition for stored procedure spLeague_GetCID : 
--
GO
CREATE PROC [dbo].[spLeague_GetCID]
AS
	RETURN
GO

--------------------------------------------------------------------------------



-- ?? ??? ????
CREATE  PROC [dbo].[spPresentCashItem]
	@SenderUserID	varchar(20)
,	@ReceiverUserID	varchar(20)
,	@CSID		int
,	@Cash		int
,	@RentHourPeriod	smallint = NULL
,	@MobileCode char(16) = NULL
AS
	SET NoCount On

	DECLARE	@ItemID		int
	DECLARE @ReceiverAID	int

	SELECT @ReceiverAID = AID FROM Account (NOLOCK) WHERE UserID = @ReceiverUserID
	
	IF @ReceiverAID IS NULL
	BEGIN
		RETURN 0
	END
	ELSE
	BEGIN
		DECLARE @RentDate	datetime
		-- @RentHourPeriod?? ??? ????? ??.
		IF @RentHourPeriod = 0 OR @RentHourPeriod IS NULL
		BEGIN
			-- ??? ???? ?? ?? ??? ?? ?? ??
			DECLARE @RentType 	TINYINT
			DECLARE @RCSPID		INT

				SELECT @RentType = RentType FROM CashShop WHERE CSID=@CSID
			IF @RentType = 1
			BEGIN
				SELECT @RCSPID = RCSPID FROM RentCashShopPrice WHERE CSID=@CSID AND RentHourPeriod is NULL
				IF @RCSPID IS NULL
				BEGIN
					RETURN 0
				END
			END

			-- ?? ???? ??
			SET @RentDate = NULL
		END
		ELSE
		BEGIN
			SET @RentDate = GETDATE()
		END


		SELECT @ItemID = ItemID FROM CashShop (NOLOCK) WHERE CSID = @CSID

		IF @ItemID IS NOT NULL
		BEGIN
			BEGIN TRAN
			
				-- ??? ??.
				INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod)
				VALUES (@ReceiverAID, @ItemID, @RentDate, @RentHourPeriod)
				
				IF @@ERROR <> 0
				BEGIN
					ROLLBACK
					RETURN 0
				END
									
				-- ?? ?? ??.
				INSERT INTO CashItemPresentLog (SenderUserID, ReceiverAID, CSID, Date, Cash, RentHourPeriod, MobileCode)
				VALUES (@SenderUserID, @ReceiverAID, @CSID, GETDATE(), @Cash, @RentHourPeriod, @MobileCode)
				
				IF @@ERROR <> 0
				BEGIN
					ROLLBACK
					RETURN 0
				END
					
			COMMIT TRAN
		END
		ELSE
		BEGIN
			RETURN 0
		END

		
		RETURN 1
	END
GO

--------------------------------------------------------------------------------


CREATE  PROC [dbo].[spPresentCashSetItem]
	@SenderUserID	varchar(20)
,	@ReceiverUserID	varchar(20)
,	@CSSID		int
,	@Cash		int
,	@RentHourPeriod	smallint = NULL
, 	@MobileCode char(16) = NULL
AS
	SET NoCount On

	DECLARE @ReceiverAID	int

	SELECT @ReceiverAID = AID FROM Account WHERE UserID = @ReceiverUserID

	IF @ReceiverAID IS NOT NULL
	BEGIN
		DECLARE @RentDate		datetime			

		-- @RentHourPeriod?? ??? ????? ??.
		IF @RentHourPeriod = 0 OR @RentHourPeriod IS NULL
		BEGIN
			-- ??? ???? ?? ?? ??? ?? ?? ??
			DECLARE @RentType 	TINYINT
			DECLARE @RCSSPID	INT

			SELECT @RentType = RentType FROM CashSetShop WHERE CSSID=@CSSID
			IF @RentType = 1
			BEGIN
				SELECT @RCSSPID = RCSSPID FROM RentCashSetShopPrice WHERE CSSID=@CSSID AND RentHourPeriod is NULL
				IF @RCSSPID IS NULL
				BEGIN
					RETURN 0
				END
			END

			-- ?? ???? ??
			SET @RentDate = NULL
		END
		ELSE
		BEGIN
			SET @RentDate = GETDATE()
		END


		BEGIN TRAN
			DECLARE curBuyCashSetItem 	INSENSITIVE CURSOR

			FOR
				SELECT CSID FROM CashSetItem WHERE CSSID = @CSSID
			FOR READ ONLY

			OPEN curBuyCashSetItem

			DECLARE @varCSID	int
			DECLARE @ItemID		int

			FETCH FROM curBuyCashSetItem INTO @varCSID

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SELECT @ItemID = ItemID FROM CashShop WHERE CSID = @varCSID

				IF @ItemID IS NOT NULL
				BEGIN	
					-- ??? ??.
					INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod)
					VALUES (@ReceiverAID, @ItemID, @RentDate, @RentHourPeriod)
					
					IF @@ERROR <> 0
					BEGIN
						ROLLBACK
						CLOSE curBuyCashSetItem
						DEALLOCATE curBuyCashSetItem
						RETURN 0
					END					
				END
				
				FETCH FROM curBuyCashSetItem INTO @varCSID
			END

		CLOSE curBuyCashSetItem
		DEALLOCATE curBuyCashSetItem

		-- ????? ?? ?? ??.
		INSERT INTO CashItemPresentLog (SenderUserID, ReceiverAID, CSSID, Date, RentHourPeriod, Cash, MobileCode)
		VALUES (@SenderUserID, @ReceiverAID, @CSSID, GETDATE(), @RentHourPeriod, @Cash, @MobileCode)

		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN 0
		END
				
		COMMIT TRAN
		RETURN 1

	END
	ELSE
	BEGIN
		RETURN 0
	END
GO

--
-- Definition for stored procedure spRegularClearFrindList : 
--
GO
CREATE PROC [dbo].[spRegularClearFrindList]    
AS    
BEGIN    
 SET NOCOUNT ON     
    
 DELETE FROM Friend    
 WHERE id IN    
 (    
  SELECT TOP 10000 id    
  FROM Friend(NOLOCK)    
  WHERE DeleteFlag = 1    
 )    
END
GO

--
-- Definition for stored procedure spRegularFetchTableSpace : 
--
GO
CREATE PROC [dbo].[spRegularFetchTableSpace]
AS  
BEGIN  
SET NOCOUNT ON   
  
DECLARE @tmp_space table(
	obj_id BIGINT
	, reserved BIGINT NULL  
	, data BIGINT NULL  
	, used_sum BIGINT DEFAULT(0)
	, row_count INT NULL)
DECLARE @page_size BIGINT  
  
SELECT @page_size = low / 1024.   
FROM master.dbo.spt_values(NOLOCK)   
WHERE number = 1 AND type = 'E'  
  
/*  
reserved & sum of used size. 
*/  
INSERT INTO @tmp_space(obj_id, reserved, used_sum)  
SELECT OBJECT_ID(i.TABLE_NAME) AS 'obj_id'  
	, SUM(ISNULL(s.reserved, 0)) AS 'reserved' 
	, SUM(s.used)	-- ??? ???? ??? ??? ??? ???.
					-- ?? ??? history???? insert?? ??.
FROM sysindexes s(NOLOCK) JOIN INFORMATION_SCHEMA.TABLES i  
	ON s.id = OBJECT_ID(i.TABLE_NAME)  
WHERE s.indid IN (0, 1, 255)  
	AND i.TABLE_CATALOG = 'GunzDB'  
GROUP BY i.TABLE_NAME  
  
/*  
data size & row count 
*/  
UPDATE @tmp_space  
SET data = (  
		SELECT SUM(dpages)  
		FROM sysindexes s(NOLOCK)  
		WHERE s.id = obj_id AND s.indid < 2)  
	- (
		SELECT ISNULL(SUM(used), 0)  
		FROM sysindexes s(NOLOCK)  
		WHERE s.id = obj_id AND s.indid = 255)  
	, row_count = (
		SELECT s.rows  
		FROM sysindexes s(NOLOCK)   
		WHERE s.indid < 2   
		AND obj_id = s.id)
  

INSERT INTO LogDb..table_space_history(name, reserved_KB, data_KB, index_KB, unused_KB, row_count, reg_date)  
SELECT OBJECT_NAME(obj_id)
	, reserved * @page_size
	, data * @page_size  
	, (used_sum - data) * @page_size	-- index size.
	, (reserved - used_sum) * @page_size 	-- unused size.
	, row_count
	, GETDATE()  
FROM @tmp_space  
ORDER BY OBJECT_NAME(obj_id)  

END
GO

--
-- Definition for stored procedure spRegularTranslateServerLog : 
--
GO
CREATE   PROC [dbo].[spRegularTranslateServerLog]
AS 
 SET NOCOUNT ON

 DECLARE @StartTime char(16)
 DECLARE @EndTime char(16)

 SET @StartTime = CONVERT(char(13), DATEADD(hh, -1, GETDATE()), 120) + ':00'
 SET @EndTime = CONVERT(char(13), GETDATE(), 120) + ':00'

 INSERT INTO LogDB.game.ServerLogStorage(ServerID
  , PlayerCount, GameCount, BlockCount, NonBlockCount
  , Time)
 SELECT ServerID, PlayerCount, GameCount, BlockCount, NonBlockCount, Time
 FROM GunzDB.game.ServerLog(NOLOCK)
 WHERE ServerID < 200 AND Time >= @StartTime AND Time < @EndTime
 ORDER BY ServerID, Time
GO

-- ????? ??? ??? ????
CREATE PROC [dbo].[spRegularUpdateAccountPenaltyPeriod]
AS
SET NOCOUNT ON
UPDATE AccountPenaltyPeriod SET DayLeft=DayLeft-1

DECLARE curAccountPenaltyPeriod INSENSITIVE CURSOR
FOR
SELECT AID FROM AccountPenaltyPeriod WHERE DayLeft <= 0
FOR READ ONLY

OPEN curAccountPenaltyPeriod

DECLARE @varAID int
DECLARE @sql varchar(100)

FETCH FROM curAccountPenaltyPeriod INTO @varAID

WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sql = 'UPDATE dbo.Account SET UGradeID=100 WHERE AID=' + CONVERT(varchar(16), @varAID)
	EXEC(@sql)
	SET @sql = 'DELETE FROM dbo.AccountPenaltyPeriod WHERE AID=' + CONVERT(varchar(16), @varAID)
	EXEC(@sql)

	FETCH FROM curAccountPenaltyPeriod INTO @varAID
END

CLOSE curAccountPenaltyPeriod
DEALLOCATE curAccountPenaltyPeriod
GO

-- ?? ?? ??? ???? - ?? ?? 12?? ????
CREATE PROC [dbo].[spRegularUpdateClanRankIncrease]
AS
	SET NOCOUNT ON

	-- ????? ???.
	DECLARE @LowestRank int
	SELECT TOP 1 @LowestRank=Ranking FROM Clan 
	WHERE DeleteFlag=0 AND Ranking>0 
	order by ranking desc

	IF @LowestRank is NULL SELECT @LowestRank = 0

	UPDATE Clan
	SET RankIncrease=(LastDayRanking-Ranking)
	WHERE DeleteFlag=0 AND Ranking>0 AND LastDayRanking != 0

	-- ?? ??? ???? ??
	UPDATE Clan
	SET RankIncrease=@LowestRank-Ranking
	WHERE DeleteFlag=0 AND Ranking>0 AND LastDayRanking = 0

	-- LastDayRanking ????
	UPDATE Clan 
	SET LastDayRanking=Ranking 
	where DeleteFlag=0 and Ranking>0
GO

--
-- Definition for stored procedure spRegularUpdateClanRanking : 
--
GO
CREATE PROC [dbo].[spRegularUpdateClanRanking]
AS
SET NOCOUNT ON

DECLARE @varRanking int
SELECT @varRanking = 0

DECLARE curRankClan INSENSITIVE CURSOR
FOR
	SELECT CLID
	FROM Clan(nolock)
	WHERE DeleteFlag=0 AND ((Wins != 0) OR (Losses != 0)) 
	ORDER BY Point Desc, Wins Desc, Losses Asc

FOR READ ONLY

OPEN curRankClan

DECLARE @varCLID int
DECLARE @sql varchar(100)

FETCH FROM curRankClan INTO @varCLID

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @varRanking = @varRanking + 1

	-- ?? ????
	UPDATE Clan SET Ranking = @varRanking WHERE CLID=@varCLID


	FETCH FROM curRankClan INTO @varCLID
END

CLOSE curRankClan
DEALLOCATE curRankClan
GO

--
-- Definition for stored procedure spRegularUpdateConnLog : 
--
GO
CREATE PROC [dbo].[spRegularUpdateConnLog]
AS
SET NOCOUNT ON
-- ?? ??? ConnLog??? ?? ??.
DECLARE @NewTableName varchar(20)
DECLARE @CreateConnLogQuery varchar( 255 )
DECLARE @NextDate smalldatetime

DECLARE @Month int
DECLARE @Day int

EXEC spGetAgoDay -1, @NextDate OUTPUT

SET @Month = DATEPART(mm, @NextDate)
SET @Day = DATEPART(dd, @NextDate)

SELECT @NewTableName = 'ConnLog_' + 
	CAST( DATEPART(yy, @NextDate) AS varchar(4) ) + 
	CASE WHEN @Month < 10 THEN '0'  ELSE '' END + CAST(@Month AS varchar(4)) +
	CASE WHEN @Day < 10 THEN '0' ELSE '' END + CAST(@Day AS varchar(4))

SELECT @CreateConnLogQuery = 'CREATE TABLE ' + @NewTableName + '(id int identity PRIMARY KEY, AID int NOT NULL, Time smalldatetime NOT NULL, IP char(12) NOT NULL)'

EXEC (@CreateConnLogQuery )



-- ?? ??ConnLog? UV?? ??
DECLARE @TableName varchar(20) 
DECLARE @UVQuery varchar(512)
DECLARE @BefDate datetime


EXEC spGetAgoDay 1, @BefDate OUTPUT

SET @Month = DATEPART(mm, @BefDate)
SET @Day  = DATEPART(dd, @BefDate)

SELECT @TableName = 'ConnLog_' + 
	CAST( DATEPART(yy, @BefDate) AS varchar(4) ) + 
	CASE WHEN @Month < 10 THEN '0' ELSE '' END + CAST(@Month AS varchar(4)) +
	CASE WHEN @Day < 10 THEN '0' ELSE '' END + CAST(@Day AS varchar(4)) 

SELECT @UVQuery = '
DECLARE @Count int
DECLARE @Date smalldatetime

EXEC spGetAgoDay 1, @Date OUTPUT

SELECT @Count = COUNT(*) FROM (SELECT AID FROM ' + @TableName + ' (NOLOCK) GROUP BY AID) A

INSERT INTO UV(Time, Count) VALUES (@Date, @Count)'

EXEC (@UVQuery)

--EXEC ('TRUNCATE TABLE ' + @TableName)
--EXEC ('DROP TABLE ' + @TableName)
GO

--
-- Definition for stored procedure spRegularUpdateDeleteClan : 
--
GO
CREATE proc [dbo].[spRegularUpdateDeleteClan]  
as  
 set nocount on  
  
 declare @DelClanID table( clid int )  
  
 begin tran  
 insert into @DelClanID  
 select CLID from Clan(nolock) where DeleteFlag = 2  
 if (0 <> @@ERROR) or (0 = @@ROWCOUNT) begin  
  rollback tran  
  return  
 end  
  
 delete ClanMember   
 from @DelClanID dci, ClanMember cm(nolock)  
 where cm.CLID = dci.CLID  
 if (0 <> @@ERROR) begin  
  rollback tran  
  return  
 end  
  
 update Clan  
 set MasterCID = null, DeleteFlag = 1, DeleteName = Name, Name = null  
 from @DelClanID dci, Clan c(nolock)  
 where c.CLID = dci.CLID  
 if (0 <> @@ERROR) OR (0 = @@ROWCOUNT) begin  
  rollback tran  
  return  
 end  
   
 commit tran
GO

--
-- Definition for stored procedure spRegularUpdateShopRanking : 
--
GO
CREATE PROC [dbo].[spRegularUpdateShopRanking]
AS
SET NOCOUNT ON
BEGIN
	BEGIN TRAN
		/* ??? ?? ???? */
		IF EXISTS (SELECT name FROM tempdb.dbo.sysobjects WHERE name LIKE '#TempShopRankRange%')
		DROP TABLE #TempShopRankRange
		
	
		SELECT TOP 5 IDENTITY(INT,1,1) Rank, 'range weapon' AS Category, i.Name, COUNT(l.ItemID) AS Count, c.CSID, NULL AS CSSID, i.Slot,
			i.ResSex, i.ResLevel, c.CashPrice
		INTO #TempShopRankRange
		FROM ItemPurchaseLogByCash l(NOLOCK), Item i(NOLOCK), CashShop c(NOLOCK)
		WHERE Date > DATEADD(day, -7, GetDate()) AND i.Slot=2 AND l.ItemID=i.ItemID AND l.ItemID=c.ItemID
		GROUP BY l.ItemID, i.Slot, i.Name, c.CSID, i.ResSex, i.ResLevel, c.CashPrice
		ORDER BY Count DESC
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		/* ?? ?? ???? */
		IF EXISTS (SELECT name FROM tempdb.dbo.sysobjects WHERE name LIKE '#TempShopRankMelee%')
		DROP TABLE #TempShopRankMelee
		
		SELECT TOP 5 IDENTITY(INT,1,1) Rank, 'melee weapon' AS Category, i.Name, COUNT(l.ItemID) AS Count, c.CSID, NULL AS CSSID, i.Slot,
			i.ResSex, i.ResLevel, c.CashPrice
		INTO #TempShopRankMelee
		FROM ItemPurchaseLogByCash l(NOLOCK), Item i(NOLOCK), CashShop c(NOLOCK)
		WHERE Date > DATEADD(day, -7, GetDate()) AND i.Slot=1 AND l.ItemID=i.ItemID AND l.ItemID=c.ItemID
		GROUP BY l.ItemID, i.Slot, i.Name, c.CSID, i.ResSex, i.ResLevel, c.CashPrice
		ORDER BY Count DESC
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		/* ????? ???? */
		IF EXISTS (SELECT name FROM tempdb.dbo.sysobjects WHERE name LIKE '#TempShopRankSpecial%')
		DROP TABLE #TempShopRankSpecial
		
		SELECT TOP 5 IDENTITY(INT,1,1) Rank, 'specail item' AS Category, i.Name, COUNT(l.ItemID) AS Count, c.CSID, NULL AS CSSID, i.Slot,
			i.ResSex, i.ResLevel, c.CashPrice
		INTO #TempShopRankSpecial
		FROM ItemPurchaseLogByCash l(NOLOCK), Item i(NOLOCK), CashShop c(NOLOCK)
		WHERE Date > DATEADD(day, -7, GetDate()) AND i.Slot=3 AND l.ItemID=i.ItemID AND l.ItemID=c.ItemID
		GROUP BY l.ItemID, i.Slot, i.Name, c.CSID, i.ResSex, i.ResLevel, c.CashPrice
		ORDER BY Count DESC
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		/* ??? ???? */
		IF EXISTS (SELECT name FROM tempdb.dbo.sysobjects WHERE name LIKE '#TempShopRankArmor%')
		DROP TABLE #TempShopRankArmor
		
		SELECT TOP 5 IDENTITY(INT,1,1) Rank, 'defence' AS Category, i.Name, COUNT(l.ItemID) AS Count, c.CSID, NULL AS CSSID, 
			CASE i.Slot 
				WHEN 0 THEN 'no limit'
				WHEN 1 THEN 'melee weapon'
				WHEN 2 THEN 'range weapon'
				WHEN 3 THEN 'item'
				WHEN 4 THEN 'haed'
				WHEN 5 THEN 'chest'
				WHEN 6 THEN 'hands'
				WHEN 7 THEN 'legs'
				WHEN 8 THEN 'feet'
				WHEN 9 THEN 'finger'
			END AS Slot, i.ResSex, i.ResLevel, c.CashPrice
		INTO #TempShopRankArmor
		FROM ItemPurchaseLogByCash l(NOLOCK), Item i(NOLOCK), CashShop c(NOLOCK)
		WHERE Date > DATEADD(day, -7, GetDate()) AND 4<=i.Slot AND i.Slot<=9 AND l.ItemID=i.ItemID AND l.ItemID=c.ItemID
		GROUP BY l.ItemID, i.Slot, i.Name, c.CSID, i.ResSex, i.ResLevel, c.CashPrice
		ORDER BY COUNT(l.ItemID) DESC
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		/* ?? ???? */
		IF EXISTS (SELECT name FROM tempdb.dbo.sysobjects WHERE name LIKE '#TempShopRankSet%')
		DROP TABLE #TempShopRankSet
		
		SELECT TOP 5 IDENTITY(INT,1,1) Rank, 'set' AS Category, s.Name, COUNT(l.CSSID) AS Count, NULL AS CSID, l.CSSID, 
			'set' AS Slot, s.ResSex, s.ResLevel, s.CashPrice
		INTO #TempShopRankSet
		FROM SetItemPurchaseLogByCash l(NOLOCK), CashSetShop s(NOLOCK)
		WHERE Date > DATEADD(day, -7, GetDate()) AND l.CSSID=s.CSSID
		GROUP BY l.CSSID, s.Name, s.ResSex, s.ResLevel, s.CashPrice
		ORDER BY Count DESC
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		/* ??? ?? */
		DELETE FROM CashShopRank
		
		INSERT INTO CashShopRank (Rank, Category, Name, Count, CSID, CSSID, Slot, ResSex, ResLevel, CashPrice)
			 SELECT * FROM #TempShopRankRange
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		INSERT INTO CashShopRank (Rank, Category, Name, Count, CSID, CSSID, Slot, ResSex, ResLevel, CashPrice)
			SELECT * FROM #TempShopRankMelee
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		INSERT INTO CashShopRank (Rank, Category, Name, Count, CSID, CSSID, Slot, ResSex, ResLevel, CashPrice)
			SELECT * FROM #TempShopRankSpecial
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		INSERT INTO CashShopRank (Rank, Category, Name, Count, CSID, CSSID, Slot, ResSex, ResLevel, CashPrice)
			SELECT * FROM #TempShopRankArmor
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		INSERT INTO CashShopRank (Rank, Category, Name, Count, CSID, CSSID, Slot, ResSex, ResLevel, CashPrice)
			SELECT * FROM #TempShopRankSet
		IF @@ERROR <> 0
		BEGIN
			ROLLBACK
			RETURN (-1)
		END
		
		DROP TABLE #TempShopRankRange
		DROP TABLE #TempShopRankMelee
		DROP TABLE #TempShopRankSpecial
		DROP TABLE #TempShopRankArmor
		DROP TABLE #TempShopRankSet
	COMMIT TRAN
	RETURN (1)
END
GO

-- ?? ??
CREATE PROC [dbo].[spRemoveClanMember]
	@CLID		int,
	@CID		int
AS
	SET NOCOUNT ON
	DELETE FROM ClanMember WHERE (CLID=@CLID) AND (CID=@CID) AND (Grade != 1)
GO

-- ?? ???? ?? ??
CREATE PROC [dbo].[spRemoveClanMemberFromCharName]
	@CLID				int,
	@AdminGrade			int,		-- ?????? ?? ??? ??
	@MemberCharName		varchar(36)
AS
	SET NOCOUNT ON
	DECLARE @CID				int
	DECLARE @MemberGrade		int


	SELECT @CID=c.cid, @MemberGrade=cm.Grade FROM Character c(nolock), ClanMember cm(nolock)
	WHERE cm.clid=@CLID AND c.cid=cm.cid AND c.Name=@MemberCharName AND (DeleteFlag=0)

	IF (@CID IS NULL)
	BEGIN
		SELECT 0 As Ret
		return (-1)
	END

	IF @AdminGrade >= @MemberGrade
	BEGIN
		SELECT 2 As Ret
		return (-1)
	END


	IF @CID IS NOT NULL
	BEGIN
		BEGIN TRAN
		DELETE FROM ClanMember WHERE (CLID=@CLID) AND (CID=@CID) AND (Grade != 1)
		IF 0 <> @@ERROR BEGIN 
			ROLLBACK TRAN
			SELECT 3 AS Ret -- ??? ??. By SungE
			RETURN
		END
		COMMIT TRAN
		SELECT 1 As Ret
	END

/* Ret? ?? : 1 - ??, 0 - ?????? ??. , 2 - ??? ?? ??. */
GO

-- ?? ??
CREATE PROC [dbo].[spRemoveFriend]
	@CID		int
,	@FriendCID	int
AS
SET NOCOUNT ON
UPDATE Friend 
SET DeleteFlag=1
WHERE CID=@CID AND FriendCID=@FriendCID
GO

--
-- Definition for stored procedure spReserveCloseClan : 
--
GO
CREATE PROC [dbo].[spReserveCloseClan]    
 @CLID  int  
, @ClanName varchar(24)  
, @MasterCID int    
, @DeleteDate smalldatetime  
AS    
 UPDATE Clan SET DeleteFlag=2 WHERE CLID=@CLID AND Name=@ClanName AND MasterCID=@MasterCID
GO

--
-- Definition for stored procedure spResetAccountHackingBlock : 
--
GO
CREATE PROC [dbo].[spResetAccountHackingBlock]
 @AID INT
, @HackingType TINYINT
AS
BEGIN
 SET NOCOUNT ON

 UPDATE Account
 SET HackingType = @HackingType
 WHERE AID = @AID
END
GO

--
-- Definition for stored procedure spSearchCashItem : 
--
GO
/* ??? ?? */
CREATE  PROC [dbo].[spSearchCashItem]
	@Slot		tinyint,
	@ResSex		tinyint,
	@ResMinLevel	int = NULL,
	@ResMaxLevel	int = NULL,
	@ItemName	varchar(256) = '',
	@Page		int = 1,
	@PageCount	int OUTPUT
AS
SET NOCOUNT ON

SELECT @PageCount = 1

SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot, cs.CashPrice AS Cash, 
cs.WebImgName AS WebImgName, i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight, 
i.Description AS Description, cs.NewItemOrder AS IsNewItem, cs.RentType AS RentType FROM CashShop cs(nolock), Item i(nolock) 
WHERE i.ItemID = cs.ItemID AND i.Name=@ItemName AND cs.Opened=1
ORDER BY cs.csid DESC
GO

--
-- Definition for stored procedure spSearchCashItem2 : 
--
GO
/* ??? ?? */
CREATE  PROC [dbo].[spSearchCashItem2]
	@Slot		tinyint,
	@ResSex		tinyint,
	@ResMinLevel	int = NULL,
	@ResMaxLevel	int = NULL,
	@ItemName	varchar(256) = '',
	@Page		int = 1,
	@PageCount	int OUTPUT
AS
SET NOCOUNT ON

SELECT @PageCount = 1

SELECT cs.csid AS CSID, i.name AS Name, i.Slot AS Slot, cs.CashPrice AS Cash, 
cs.WebImgName AS WebImgName, i.ResSex AS ResSex, i.ResLevel AS ResLevel, i.Weight AS Weight, 
i.Description AS Description, cs.NewItemOrder AS IsNewItem, cs.RentType AS RentType FROM CashShop cs(nolock), Item i(nolock) 
WHERE i.ItemID = cs.ItemID AND i.Name=@ItemName AND cs.Opened=1
ORDER BY cs.csid DESC
GO

--
-- Definition for stored procedure spSearchTotalRankingByName : 
--
GO
/* ?? ?? */
CREATE PROC [dbo].[spSearchTotalRankingByName]
	@Name				varchar(24)
AS
SET NOCOUNT ON
-- ????? ?? ??
--SELECT @Name = REPLACE(@Name, '[', '[[]')
--SELECT @Name = REPLACE(@Name, '%', '[%]')
--SELECT @Name = REPLACE(@Name, '_', '[_]')

SELECT Rank, Level, UserID, Name, XP, KillCount, DeathCount 
FROM TotalRanking(nolock)
WHERE Name=@Name
GO

-- ??? ?? ??.
CREATE PROC [dbo].[spSearchTotalRankingByNetmarbleID]
	@UserID varchar(20)
AS
SET NOCOUNT ON
BEGIN
	SELECT Rank, Level, Name, XP, KillCount, DeathCount, UserID 
	FROM TotalRanking (NOLOCK)
	WHERE Name = @UserID
END
GO

--
-- Definition for stored procedure spSelectAccountItem : 
--
GO
/* ???? ??? ?? */
CREATE PROC [dbo].[spSelectAccountItem]
	@AID			int
AS
SET NOCOUNT ON

DECLARE @NowTime DATETIME
SELECT @NowTime = GETDATE()

SELECT AIID, ItemID, (RentHourPeriod*60) - (DateDiff(n, RentDate, @NowTime)) AS RentPeriodRemainder
FROM AccountItem(NOLOCK)
WHERE AID=@AID ORDER BY AIID
GO

--
-- Definition for stored procedure spSelectCharItem : 
--
GO
/* ??? ??? ?? */
CREATE PROC [dbo].[spSelectCharItem]
	@CID		int
AS
SET NOCOUNT ON

DECLARE @NowTime DATETIME
SELECT @NowTime = GETDATE()

SELECT CIID, ItemID, (RentHourPeriod*60) - (DateDiff(n, RentDate, @NowTime)) AS RentPeriodRemainder
FROM CharacterItem (nolock)
WHERE CID=@CID ORDER BY CIID
GO

--
-- Definition for stored procedure spSelectCharItem2 : 
--
GO
CREATE  PROC [dbo].[spSelectCharItem2]  
 @CID  int  
AS  
BEGIN
 SET NOCOUNT ON

 SELECT CIID, ItemID, (RentHourPeriod*60) - (DateDiff(n, RentDate, GETDATE())) AS RentPeriodRemainder
  , ISNULL(RentHourPeriod, 0) as 'RentHourPeriod'
 FROM CharacterItem (nolock)  
 WHERE CID=@CID ORDER BY CIID  
END
GO

--
-- Definition for stored procedure spSelectCharQuestItemInfoByCID : 
--
GO
CREATE  PROC [dbo].[spSelectCharQuestItemInfoByCID]
	@CID	int
AS
BEGIN
	SET NOCOUNT ON
	SELECT QuestItemInfo FROM Character (NOLOCK) WHERE CID = @CID
END
GO

-- ??? ???? ??? ??
CREATE   PROC [dbo].[spSellBountyItem]
	@CID		INT,
	@ItemID		INT,
	@CIID		INT,
	@Price		INT,
	@CharBP		INT
AS
SET NOCOUNT ON
BEGIN
	BEGIN TRAN
		-- Item ??
		UPDATE CharacterItem SET CID=NULL WHERE CID=@CID AND CIID=@CIID
		IF (@@ERROR <> 0) OR (@@ROWCOUNT = 0)
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		-- Bounty ??
		UPDATE Character SET BP=BP+@Price WHERE CID=@CID
		IF (@@ERROR <> 0) OR (@@ROWCOUNT = 0)
		BEGIN
			ROLLBACK
			RETURN (-1)
		END

		-- Item ?? ?? ??
		INSERT INTO ItemPurchaseLogByBounty (ItemID, CID, Date, Bounty, CharBounty, Type)
		VALUES (@ItemID, @CID, GETDATE(), @Price, @CharBP, '??')
		IF 0 <> @@ERROR BEGIN
			ROLLBACK TRAN
			RETURN (-1)
		END

		SELECT 1 as Ret
	COMMIT TRAN

	RETURN 1
END
GO

--
-- Definition for stored procedure spSimpleUpdateChar : 
--
GO
/* ??? ?? ???? - ??? ????? ??????. */
CREATE PROC [dbo].[spSimpleUpdateChar]
	@CID		int,
	@Name		varchar(24),
	@Level		smallint,
	@XP		int,
	@BP		int
AS
SET NOCOUNT ON
UPDATE Character WITH (rowlock)
SET Level=@Level, XP=@XP, BP=@BP
WHERE CID=@CID AND Name=@Name
GO

--
-- Definition for stored procedure spStartUpLocatorStatus : 
--
GO
CREATE PROC [dbo].[spStartUpLocatorStatus]
 @LocatorID int
, @IP varchar(15)
, @Port int
, @UpdateElapsedTime int
AS
 SET NOCOUNT ON 
 IF EXISTS (SELECT LocatorID FROM LocatorStatus(NOLOCK) 
	    WHERE LocatorID = @LocatorID) BEGIN
  UPDATE LocatorStatus 
  SET IP = @IP, Port = @Port, UpdateElapsedTime = @UpdateElapsedTime, 
   LastUpdatedTime = GETDATE()
  WHERE LocatorID = @LocatorID
 END
 ELSE BEGIN
  INSERT INTO LocatorStatus(LocatorID, IP, Port, UpdateElapsedTime, LastUpdatedTime)
  VALUES (@LocatorID, @IP, @Port, @UpdateElapsedTime, GETDATE())
 END
GO

--
-- Definition for stored procedure spUpdateAccountLastLogoutTime : 
--
GO
CREATE PROC [dbo].[spUpdateAccountLastLogoutTime]
 @AID int
AS
BEGIN
 SET NOCOUNT ON

 UPDATE Account SET LastLogoutTime = GETDATE() WHERE AID = @AID
END
GO

-- ??? ??
CREATE PROC [dbo].[spUpdateAccountUGrade]
	@AID		int
,	@UGrade		int
,	@Period		int
AS
BEGIN TRAN
	SET NOCOUNT ON
	UPDATE Account SET UGradeID=@UGrade WHERE AID=@AID
	IF 0 = @@ROWCOUNT BEGIN 
		ROLLBACK TRAN
		RETURN
	END


	IF (@UGrade >= 100) AND (@UGrade<=253) BEGIN
		INSERT INTO PenaltyLog(AID, UGradeID, Date) Values(@AID, @UGrade, GETDATE())
		IF 0 <> @@ERROR BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END

	IF @UGrade = 104 OR @UGrade=105 BEGIN
		INSERT INTO AccountPenaltyPeriod(AID, DayLeft) VALUES(@AID, @Period)
		IF 0 <> @@ERROR	BEGIN
			ROLLBACK TRAN
			RETURN
		END
	END
	ELSE
	BEGIN
		-- ?? ??? ??
		DELETE FROM AccountPenaltyPeriod WHERE AID=@AID
		IF 0 <> @@ERROR BEGIN
			ROLLBACK TRAN
			RETURN
		END	
	END
COMMIT TRAN
GO

--
-- Definition for stored procedure spUpdateChar : 
--
GO
/* ??? ?? ???? - ??? ??? ???? ?? ???. */
CREATE PROC [dbo].[spUpdateChar]
	@Name		varchar(24),
	@CharNum	smallint,
	@Level		smallint,
	@Sex		tinyint,
	@Hair		tinyint,
	@Face		tinyint,
	@XP		int,
	@BP		int,
	@HP		smallint,
	@AP		smallint,
	@FR		smallint,
	@CR		smallint,
	@ER		smallint,
	@WR		smallint
AS
SET NOCOUNT ON
UPDATE Character WITH (rowlock)
SET Name=@Name, Level=@Level, Sex=@Sex, Hair=@Hair, Face=@Face, XP=@XP, BP=@BP, 
  HP=@HP, AP=@AP, FR=@FR, CR=@CR, ER=@ER, WR=@WR
WHERE Name=@Name and CharNum=@CharNum
GO

--
-- Definition for stored procedure spUpdateCharBP : 
--
GO
/* BP ???? */
CREATE PROC [dbo].[spUpdateCharBP]
  @BPInc        int,
  @CID          int
AS
SET NOCOUNT ON
UPDATE Character 
SET BP=BP+(@BPInc) 
WHERE CID=@CID
GO

-- ????? ????
CREATE PROC [dbo].[spUpdateCharClanContPoint]
	@CID		int,
	@CLID		int,
	@AddedContPoint	int
AS
	SET NOCOUNT ON
	Update ClanMember SET ContPoint=ContPoint+@AddedContPoint WHERE CID=@CID AND CLID=@CLID
GO

--
-- Definition for stored procedure spUpdateCharInfoData : 
--
GO
/* ??? ??(XP, BP, KillCount, DeathCount) ???? */
CREATE PROC [dbo].[spUpdateCharInfoData]
  @XPInc        int,
  @BPInc        int,
  @KillInc      int,
  @DeathInc     int,
  @CID          int
AS
SET NOCOUNT ON
  
UPDATE Character 
SET XP=XP+(@XPInc), BP=BP+(@BPInc), KillCount=KillCount+(@KillInc), DeathCount=DeathCount+(@DeathInc)
WHERE CID=@CID
GO

--
-- Definition for stored procedure spUpdateCharLevel : 
--
GO
/* ?? ???? */
CREATE PROC [dbo].[spUpdateCharLevel]
  @Level        smallint,
  @CID          int
AS
SET NOCOUNT ON
UPDATE Character 
Set Level=@Level 
WHERE CID=@CID
GO

--
-- Definition for stored procedure spUpdateCharPlayTime : 
--
GO
/* ??? ??? ?? ???? */
CREATE PROC [dbo].[spUpdateCharPlayTime]
  @PlayTimeInc    int,
  @CID            int
AS
SET NOCOUNT ON

UPDATE Character 
SET PlayTime=PlayTime+(@PlayTimeInc), LastTime=GETDATE() 
WHERE CID=@CID
GO

-- ?? ??
CREATE PROC [dbo].[spUpdateClanGrade]
	@CLID		int,
	@CID		int,
	@NewGrade	tinyint
AS
	SET NOCOUNT ON
	UPDATE ClanMember SET Grade=@NewGrade WHERE CLID=@CLID AND CID=@CID
GO

--
-- Definition for stored procedure spUpdateEquipItem : 
--
GO
/* ??? ?? */
CREATE PROC [dbo].[spUpdateEquipItem]
	@CID			int,
	@ItemParts		int,
	@CIID			int,
	@ItemID			int
AS

SET NoCount ON

DECLARE @Ret int
DECLARE @IF_CIID	int

SELECT @Ret = 1

-- Head
IF @ItemParts = 0
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET head_slot=NULL, head_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET head_slot=@CIID, head_itemid=@ItemID WHERE CID=@CID
	END
END
-- Chest
ELSE IF @ItemParts = 1
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET chest_slot=NULL, chest_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET chest_slot=@CIID, chest_itemid=@ItemID WHERE CID=@CID
	END
END
-- Hands
ELSE IF @ItemParts = 2
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET hands_slot=NULL, hands_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET hands_slot=@CIID, hands_itemid=@ItemID WHERE CID=@CID
	END
END
-- Legs
ELSE IF @ItemParts = 3
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET legs_slot=NULL, legs_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET legs_slot=@CIID, legs_itemid=@ItemID WHERE CID=@CID
	END
END
-- Feet
ELSE IF @ItemParts = 4
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET feet_slot=NULL, feet_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET feet_slot=@CIID, feet_itemid=@ItemID WHERE CID=@CID
	END
END
-- FingerL
ELSE IF @ItemParts = 5
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET fingerl_slot=NULL, fingerl_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = fingerr_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET fingerl_slot=@CIID, fingerl_itemid=@ItemID WHERE CID=@CID
		END
	END
END
-- FingerR
ELSE IF @ItemParts = 6
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET fingerr_slot=NULL, fingerr_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = fingerl_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET fingerr_slot=@CIID, fingerr_itemid=@ItemID WHERE CID=@CID
		END
	END
END
-- Melee
ELSE IF @ItemParts = 7
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET melee_slot=NULL, melee_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		UPDATE Character SET melee_slot=@CIID, melee_itemid=@ItemID WHERE CID=@CID
	END
END
-- Primary
ELSE IF @ItemParts = 8
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET primary_slot=NULL, primary_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = secondary_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET primary_slot=@CIID, primary_itemid=@ItemID WHERE CID=@CID
		END
	END
END
-- Secondary
ELSE IF @ItemParts = 9
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET secondary_slot=NULL, secondary_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = primary_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET secondary_slot=@CIID, secondary_itemid=@ItemID WHERE CID=@CID
		END
	END
END
-- Custom1
ELSE IF @ItemParts = 10
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET custom1_slot=NULL, custom1_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = custom2_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET custom1_slot=@CIID, custom1_itemid=@ItemID WHERE CID=@CID
		END
	END
END
-- Custom2
ELSE IF @ItemParts = 11
BEGIN
	IF @CIID = 0
	BEGIN
		UPDATE Character SET custom2_slot=NULL, custom2_itemid=NULL WHERE CID=@CID
	END
	ELSE
	BEGIN
		SELECT @IF_CIID = custom1_slot FROM Character(nolock) WHERE CID=@CID
		IF (@IF_CIID IS NOT NULL) AND (@IF_CIID = @CIID)
		BEGIN
			SELECT @Ret = 0
		END
		ELSE
		BEGIN
			UPDATE Character SET custom2_slot=@CIID, custom2_itemid=@ItemID WHERE CID=@CID
		END
	END
END



SELECT @Ret AS Ret
GO

--
-- Definition for stored procedure spUpdateLastConnDate : 
--
GO
/* LastConn, IP? ????. */
CREATE PROC [dbo].[spUpdateLastConnDate]
	@IP		varchar(20),
	@UserID		varchar(20)
AS
SET NOCOUNT ON
UPDATE Login SET LastConnDate=GETDATE(), LastIP=@IP WHERE UserID = @UserID
GO

--
-- Definition for stored procedure spUpdateLocatorStatus : 
--
GO
CREATE PROC [dbo].[spUpdateLocatorStatus]
 @LocatorID int
, @RecvCount int
, @SendCount int
, @BlockCount int
, @DuplicatedCount int
AS 
 SET NOCOUNT ON 
 UPDATE LocatorStatus 
 SET RecvCount = @RecvCount, SendCount = @SendCount, 
  BlockCount = @BlockCount, DuplicatedCount = @DuplicatedCount,
  LastUpdatedTime = GETDATE()
 WHERE LocatorID = @LocatorID
GO

--
-- Definition for stored procedure spUpdateServerStatus : 
--
GO
/* ?? ??? ?? */
CREATE PROC [dbo].[spUpdateServerStatus]
  @CurrPlayer   smallint,
  @ServerID     int
AS
SET NOCOUNT ON
UPDATE ServerStatus 
Set CurrPlayer=@CurrPlayer, Time=GETDATE() 
WHERE ServerID=@ServerID
GO

--
-- Definition for stored procedure spWebCheckRegisteredUser : 
--
GO
CREATE   PROC [dbo].[spWebCheckRegisteredUser]  
 @UserID VARCHAR(20),  
 @Ret int Output  
AS  
 SET NOCOUNT ON  
 DECLARE @AID INT  
 SELECT @AID = AID FROM Account(NOLOCK) WHERE UserID = @UserID  
 IF @@ERROR <> 0 BEGIN  
  SET @Ret = 0  
  RETURN @Ret -- ????  
 END  
  
 IF @AID IS NULL BEGIN  
  SET @Ret = -1  
  RETURN @Ret  -- ????  
 END  
   
 SET @Ret = 1   
 RETURN @Ret -- ??? ??
GO

-- ??? ?? ??.
CREATE PROC [dbo].[spWebDeleteClan]
	@MasterName varchar(24)	/* ??? ?? */
,	@ClanName varchar(24)	/* ??? ??? ?? */
AS
SET NOCOUNT ON
BEGIN TRAN
	SET NOCOUNT ON

	DECLARE @MasterCID int
	DECLARE @CLID int

	SELECT @MasterCID = c.MasterCID, @CLID = c.CLID
	FROM Clan c (NOLOCK), Character ch(NOLOCK)
	WHERE ch.Name = @MasterName AND c.MasterCID = ch.CID

	-- ?? ?? ??.
	IF (@MasterCID IS NULL) OR (@CLID IS NULL)
	BEGIN
		SELECT 0 AS Ret
		ROLLBACK TRAN
		SET NOCOUNT OFF
		RETURN
	END

	-- Clan Member ??.
	DELETE ClanMember WHERE CLID = @CLID
	IF 0  <> @@ERROR
	BEGIN
		SELECT 0 AS Ret
		ROLLBACK TRAN
		SET NOCOUNT OFF
		RETURN
	END

	-- Clan? ???? ?? ??? ??.
	UPDATE Clan SET DeleteFlag = 1, MasterCID = NULL, DeleteName = Name WHERE CLID = @CLID
	IF 0 = @@ROWCOUNT BEGIN 
		SELECT 0 AS Ret
		ROLLBACK TRAN
		SET NOCOUNT OFF
		RETURN
	END

	UPDATE Clan SET Name = NULL WHERE CLID = @CLID
	IF 0 = @@ROWCOUNT BEGIN 
		SELECT 0 AS Ret
		ROLLBACK TRAN
		SET NOCOUNT OFF
		RETURN
	END

	SELECT 1 AS Ret

	SET NOCOUNT OFF
COMMIT TRAN
GO

----------------------------------------------------------------------------

-- ??? ??
CREATE PROC [dbo].[spWebDeleteClanAdsBoard]
 @Seq int
AS
 SET NOCOUNT ON
 BEGIN TRAN
 DELETE ClanAdsBoard  WHERE Seq = @Seq
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 DECLARE @SEQCOUNT int

 SELECT @SEQCOUNT = COUNT(Seq) FROM ClanAdsComment(NOLOCK) WHERE Seq = @Seq

 IF ( @SEQCOUNT > 0) BEGIN
  DELETE ClanAdsComment  WHERE Seq = @Seq
  IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
   ROLLBACK TRAN
   RETURN 
  END
 END
 COMMIT TRAN
GO

----------------------------------------------------------------------------

-- ??? ??? ??
CREATE PROC [dbo].[spWebDeleteClanAdsComment]
 @ID int
AS
 SET NOCOUNT ON
 DECLARE @Seq    int

 SELECT @Seq = Seq FROM ClanAdsComment(NOLOCK) WHERE ID = @ID

 BEGIN TRAN
 DELETE ClanAdsComment WHERE ID = @ID
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanAdsBoard SET CommentCount = CommentCount - 1 WHERE Seq = @Seq
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 COMMIT TRAN
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??

CREATE PROC [dbo].[spWebDeleteClanBoard]
 	@Seq int
AS
 SET NOCOUNT ON
 BEGIN TRAN
 DELETE ClanBoard  WHERE Seq = @Seq
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 DECLARE @SEQCOUNT int

 SELECT @SEQCOUNT = COUNT(Seq) FROM ClanBoardComment(NOLOCK) WHERE Seq = @Seq

 IF ( @SEQCOUNT > 0) BEGIN
  DELETE ClanBoardComment  WHERE Seq = @Seq
  IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
   ROLLBACK TRAN
   RETURN 
  END
 END
 COMMIT TRAN
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??? ??

CREATE PROC [dbo].[spWebDeleteClanBoardComment]
 @ID int
AS
 SET NOCOUNT ON
 DECLARE @Seq    int

 SELECT @Seq = Seq FROM ClanBoardComment(NOLOCK) Where ID = @ID

 BEGIN TRAN
 DELETE ClanBoardComment WHERE ID = @ID
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 Update ClanBoard Set CommentCount = CommentCount - 1 WHERE Seq = @Seq
 IF (0 <> @@ERROR) BEGIN
  ROLLBACK TRAN
  RETURN
 END
 COMMIT TRAN
GO

-- CID? ?? ??.
CREATE  PROC [dbo].[spWebDeleteClanByCID]
	@MasterCID int /* ??? CID */
AS
SET NOCOUNT ON
BEGIN TRAN

	DECLARE @CLID int

	SELECT @CLID = c.CLID
	FROM Clan c(NOLOCK)
	WHERE c.MasterCID = @MasterCID

	-- ?? ?? ??.
	IF (@MasterCID IS NULL) OR (@CLID IS NULL)
	BEGIN
		SELECT 0 AS Ret
		ROLLBACK TRAN
--		SET NOCOUNT OFF
		Select 0
		RETURN
	END

	-- Clan Member ??.
	DELETE ClanMember WHERE CLID = @CLID
	IF 0  <> @@ERROR
	BEGIN
		SELECT 0 AS Ret
		ROLLBACK TRAN
--		SET NOCOUNT OFF
		Select 0
		RETURN
	END

	-- Clan? ???? ?? ??? ??.
	UPDATE Clan SET DeleteFlag = 1, MasterCID = NULL, DeleteName = Name WHERE CLID = @CLID
	-- UPDATE Clan SET DeleteName = Name WHERE CLID = @CLID
	IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN -- ?? ??.
		SELECT 0 AS Ret
		ROLLBACK TRAN
		Select 0
		RETURN
	END
	UPDATE Clan SET Name = NULL WHERE CLID = @CLID
	IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN -- ?? ??.
		SELECT 0 AS Ret
		ROLLBACK TRAN
		Select 0
		RETURN
	END

	SELECT 1

	
COMMIT TRAN
SET NOCOUNT OFF
GO

-- ???? ??? ??.
CREATE PROC [dbo].[spWebFireClanMember]
	@Master varchar(24) 	/* ?? ??? CID */
,	@ClanMem varchar(24) 	/* ??? ??? ??? CID */
AS
SET NOCOUNT ON
BEGIN TRAN
	DECLARE @MasterCID int
	DECLARE @CLID int
	DECLARE @ClanMemCID int

	-- ?? ??? ?? ?????? ??? ???? ??.
	SELECT @CLID = cl.CLID, @MasterCID = cl.MasterCID
	FROM Character ch(NOLOCK), Clan cl(NOLOCK)
	WHERE ch.Name = @Master AND cl.MasterCID = ch.CID

	-- ????? ?? ??.
	SELECT @ClanMemCID = ch.CID
	FROM Character ch(NOLOCK)
	WHERE ch.Name = @ClanMem

	-- ??? ???? ????? ???? ?? ???? ??? ???? ???? ?.
	IF (@CLID IS NULL) OR (@ClanMemCID IS NULL) OR (@MasterCID = @ClanMemCID)
	BEGIN
		ROLLBACK TRAN
		SELECT 0
		RETURN
	END

	DELETE ClanMember 
	WHERE CLID = @CLID AND 	CID = @ClanMemCID
	IF 0 <> @@ERROR
	BEGIN
		ROLLBACK TRAN
		SELECT 0
		RETURN
	END

	SELECT 1
COMMIT TRAN
SET NOCOUNT OFF
GO

--
-- Definition for stored procedure spWebGetAccountMaxLevel : 
--
GO
CREATE PROC [dbo].[spWebGetAccountMaxLevel]
	@UserID varchar(20)
AS
BEGIN
	SET NOCOUNT ON
	SELECT MAX(c.Level) FROM Account a(NOLOCK), Character c(NOLOCK)
	WHERE a.UserID=@UserID AND a.AID=c.AID AND c.DeleteFlag=0
END
GO

-- ??? ?? ??? ??? ??? ???.
CREATE PROC [dbo].[spWebGetCashItemImageFile]
	@CSID int
,	@RetImageFileName varchar(64) OUT
,	@RetItemName varchar(256) OUT
AS
BEGIN
	SET NOCOUNT ON
	SELECT @RetImageFileName = cs.WebImgName, @RetItemName = i.Name
	FROM CashShop cs(NOLOCK), Item i(NOLOCK)
	WHERE cs.CSID = @CSID AND i.ItemID = cs.ItemID

	RETURN 1
END
GO

-- ?? ????? ?????? ??? ?? ????.
CREATE PROC [dbo].[spWebGetCashSetItemImageFile]
 	@CSSID   int  
, 	@RetImageFileName varchar(64) OUTPUT  
,	@RetSetItemName varchar(64) OUTPUT
AS  
SET NOCOUNT ON
BEGIN
	SELECT @RetImageFileName = css.WebImgName, @RetSetItemName = css.Name
	FROM CashSetShop css(NOLOCK)
	WHERE css.CSSID=@CSSID  
  
	RETURN 1  
END
GO

--
-- Definition for stored procedure spWebGetCharClan : 
--
GO
CREATE PROC [dbo].[spWebGetCharClan] 
 @CID   int  
AS  
 SET NOCOUNT ON
 SELECT cl.CLID AS CLID, cl.Name AS ClanName FROM ClanMember cm(nolock), Clan cl(nolock) WHERE cm.cid=@CID AND cm.CLID=cl.CLID
GO

----------------------------------------------------------------------------

-- ??? ?? ??
CREATE PROC [dbo].[spWebGetClanAdsBoardContent]
 @Seq int
AS
 SET NOCOUNT ON
 SELECT Seq, Userid, Subject, Content, RegDate, ReadCount, Recommend, FileName, 
  Link, HTML, CommentCount, GR_ID, GR_Depth, GR_Pos, Thread
 FROM ClanAdsBoard 
 WHERE Seq = @Seq
 ORDER BY Thread DESC
GO

----------------------------------------------------------------------------

-- ??? ??
CREATE PROC [dbo].[spWebGetClanAdsBoardList]
AS
 SET NOCOUNT ON
 SELECT Seq, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanAdsBoard(NOLOCK)
 ORDER BY Thread DESC
GO

----------------------------------------------------------------------------

-- ??? ??? ?? ??
CREATE PROC [dbo].[spWebGetClanAdsCommentContent]
 @Seq int
AS
 SET NOCOUNT ON
 SELECT ID, Userid, Content, RegDate
 FROM ClanAdsComment(NOLOCK)
 WHERE Seq = @Seq
 ORDER BY RegDate
GO

----------------------------------------------------------------------------

CREATE PROC [dbo].[spWebGetClanAdsCommentContentByID]
 @ID int
AS
 SET NOCOUNT ON
 SELECT ID, Userid, Content, RegDate
 FROM ClanAdsComment(NOLOCK)
 WHERE ID = @ID
 ORDER BY RegDate
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??? ?? ??

CREATE PROC [dbo].[spWebGetClanBoardCommentContent]
 @Seq int
AS
 SET NOCOUNT ON
 SELECT ID, Userid, Content, RegDate
 FROM ClanBoardComment (NOLOCK)
 WHERE Seq = @Seq
 ORDER BY RegDate
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??? ?? ?? By ID

CREATE PROC [dbo].[spWebGetClanBoardCommentContentByID]
 @ID int
AS
 SET NOCOUNT ON
 SELECT ID, Userid, Content, RegDate
 FROM ClanBoardComment(NOLOCK)
 WHERE ID = @ID
 ORDER BY RegDate
GO

--------------------------------------------------------------------------------------------------------

-- ??? ?? ??

CREATE PROC [dbo].[spWebGetClanBoardContent]
 @Seq int
AS
 SET NOCOUNT ON
 SELECT Seq, CLID, Userid, Subject, Content, RegDate, ReadCount, Recommend, FileName,
  Link, HTML, CommentCount, GR_ID, GR_Depth, GR_Pos, Thread
 FROM ClanBoard (NOLOCK)
 WHERE Seq = @Seq
 ORDER BY Thread DESC
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??

CREATE PROC [dbo].[spWebGetClanBoardList]
 @CLID int
AS
 SET NOCOUNT ON
 SELECT Seq, CLID, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanBoard(NOLOCK)
 WHERE CLID = @CLID
 ORDER BY Thread DESC
GO

--
-- Definition for stored procedure spWebGetClanList : 
--
GO
CREATE PROC [dbo].[spWebGetClanList]  
 @Page INT,  
 @Backward INT  = 0  
AS  
SET NOCOUNT ON
BEGIN  
 DECLARE @PageHead INT  
 DECLARE @RowCount INT  
  
 IF @Backward = 0  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 15 + 1)  
    
  SET ROWCOUNT @RowCount  
  SELECT @PageHead = CLID FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY CLID DESC  
    
  SET ROWCOUNT 15  
  SELECT cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point  
  FROM Clan cl(NOLOCK), Character c(nolock)  
  WHERE cl.MasterCID=c.CID AND cl.DeleteFlag=0 AND cl.CLID<@PageHead   
  ORDER BY cl.CLID DESC  
 END  
 ELSE  
 BEGIN -- ??  
  SELECT @RowCount = ((@Page -1) * 15 + 1)  
    
  SET ROWCOUNT @RowCount  
  SELECT @PageHead = CLID FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY CLID  
    
  SET ROWCOUNT 15  
  SELECT CLID, ClanName, Master, RegDate, EmblemUrl, Point  
  FROM  
  (  
   SELECT TOP 15 cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point  
   FROM Clan cl(NOLOCK), Character c(nolock)  
   WHERE cl.MasterCID=c.CID AND cl.DeleteFlag=0 AND cl.CLID>=@PageHead ORDER BY cl.CLID  
  ) AS t  
  ORDER BY CLID DESC  
 END  
END
GO

--
-- Definition for stored procedure spWebGetClanListSearchByMaster : 
--
GO
/* ?? ???? (???????)  
    Arg1 : @CharName (?? ??? ??) */  
CREATE PROC [dbo].[spWebGetClanListSearchByMaster]  
 	@CharName VARCHAR(24)  
AS  
SET NOCOUNT ON
BEGIN  
  	SELECT TOP 1 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, c.Name AS Master, cl.RegDate
	FROM Clan cl(NOLOCK), Character c(nolock)  
  	WHERE c.Name = @CharName AND cl.DeleteFlag = 0 AND cl.MasterCID = c.CID
END
GO

--
-- Definition for stored procedure spWebGetClanListSearchByName : 
--
GO
CREATE PROC [dbo].[spWebGetClanListSearchByName]
 @Name VARCHAR(24)  
AS  
SET NOCOUNT ON
BEGIN  
 SELECT TOP 20 cl.CLID AS CLID, cl.Name as ClanName, c.Name AS Master, cl.RegDate AS RegDate, cl.EmblemUrl AS EmblemUrl, cl.Point AS Point  
 FROM Clan cl(NOLOCK), Character c(NOLOCK)  
 WHERE cl.MasterCID=c.CID AND c.DeleteFlag=0 AND cl.Name=@Name   
 ORDER BY cl.CLID  
END
GO

--
-- Definition for stored procedure spWebGetClanMember : 
--
GO
CREATE PROC [dbo].[spWebGetClanMember]  
 @CLID  int  
AS  
 SET NOCOUNT ON
 SELECT cm.clid AS CLID, cm.Grade AS ClanGrade, c.cid AS CID, c.name AS CharName  
 FROM ClanMember cm(nolock), Character c(nolock)  
 WHERE CLID=@CLID AND cm.cid=c.cid
GO

--
-- Definition for stored procedure spWebGetClanMembers : 
--
GO
CREATE PROC [dbo].[spWebGetClanMembers]
 @CLID int
AS
 SET NOCOUNT ON
 SELECT cm.CLID, cm.Grade, c.Name, c.Level, c.XP, cm.RegDate
 FROM ClanMember cm(NOLOCK) JOIN Character c(NOLOCK)
 ON cm.CLID = @CLID AND c.CID = cm.CID
 ORDER BY cm.RegDate DESC
GO

-- ?? ??? ??? ??? ???? ??.
CREATE PROC [dbo].[spWebGetClanRankByMaster]
	@MasterName varchar(24)
AS
SET NOCOUNT ON
BEGIN
	SELECT cl.CLID, cl.Name AS ClanName, cl.Point, cl.Wins, cl.Losses, cl.EmblemUrl, cl.Ranking, cl.RankIncrease, c.Name AS Master, cl.RegDate
	FROM Clan cl(NOLOCK) JOIN Character c(NOLOCK) 
	ON c.Name = @MasterName AND cl.MasterCID = c.CID AND cl.Ranking > 0
END
GO

-- Master??? RegDate??.
/* ?? ???? : ???? 20?? ??  
    Arg1 : @Page (?????)  
    Arg2 : @Backward (???? ????, 1??? ?? */  
CREATE PROC [dbo].[spWebGetClanRanking]  
 @Page INT,  
 @Backward INT  = 0  
AS  
SET NOCOUNT ON
BEGIN  
 /* ????? 20?? ???? (????? ?? ??) */  
 DECLARE @RowCount INT  
 DECLARE @PageHead INT  
  
 IF @Backward = 0  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
  SELECT TOP 20 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, ch.Name AS Master, cl.RegDate
  FROM Clan cl(NOLOCK), Character ch(NOLOCK)
  WHERE cl.DeleteFlag=0 AND cl.Ranking>0 AND cl.Ranking >= @RowCount  AND ch.CID = cl.MasterCID
  ORDER BY cl.Ranking  
 END  
 ELSE  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
   
  SET ROWCOUNT @RowCount  
  SELECT @PageHead = Ranking FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY Ranking DESC  
   
  SET ROWCOUNT 20  
  SELECT Ranking, RankIncrease, ClanName, Point, Wins, Losses, CLID, EmblemUrl, Master, RegDate FROM  
  (  
  -- SELECT TOP 20 Ranking, RankIncrease, Name as ClanName, Point, Wins, Losses, CLID, EmblemUrl 
   SELECT TOP 20 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, ch.Name AS Master, cl.RegDate
   FROM Clan cl(NOLOCK), Character ch(NOLOCK)
   WHERE cl.DeleteFlag=0 AND cl.Ranking>0 AND cl.Ranking <= @PageHead AND ch.CID = cl.MasterCID
   ORDER BY cl.Ranking DESC  
  ) AS t ORDER BY Ranking  
 END  
END
GO

--
-- Definition for stored procedure spWebGetClanRankingHistory : 
--
GO
CREATE  PROC [dbo].[spWebGetClanRankingHistory]  
 @Year INT,  
 @Month INT,  
 @Page INT,  
 @Backward INT = 0  
AS  
SET NOCOUNT ON
BEGIN  
 /* ????? 20?? ???? (????? ?? ??) */  
 DECLARE @RowCount INT  
 DECLARE @PageHead INT  
  
 IF @Backward = 0  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
  SELECT TOP 20 Ranking, ClanName as ClanName, Point, Wins, Losses, CLID FROM ClanHonorRanking(NOLOCK)   
  WHERE Year=@Year AND Month=@Month AND Ranking>0 AND Ranking >= @RowCount ORDER BY Ranking  
 END  
 ELSE  
 BEGIN  
  SELECT @RowCount = ((@Page -1) * 20 + 1)  
   
  SET ROWCOUNT @RowCount  
  SELECT @PageHead = Ranking FROM Clan(NOLOCK) WHERE DeleteFlag=0 ORDER BY Ranking DESC  
   
  SET ROWCOUNT 20  
  SELECT  Ranking, RankIncrease=0, ClanName, Point, Wins, Losses, CLID, EmblemUrl=NULL FROM  
  (  
   SELECT TOP 20 Ranking, ClanName, Point, Wins, Losses, CLID FROM ClanHonorRanking(NOLOCK)   
   WHERE Year=@Year AND Month=@Month AND Ranking>0 AND Ranking <= @PageHead ORDER BY Ranking DESC  
  ) AS t ORDER BY Ranking  
 END  
END
GO

--
-- Definition for stored procedure spWebGetClanRankingMaxPage : 
--
GO
CREATE PROC [dbo].[spWebGetClanRankingMaxPage]  
AS  
SET NOCOUNT ON
BEGIN  
 DECLARE @MaxPage INT  
 SELECT TOP 1 @MaxPage = Ranking / 20 + 1 FROM Clan(NOLOCK) WHERE DeleteFlag=0 AND Ranking>0 ORDER BY Ranking DESC  
-- SELECT @MaxPage  
 RETURN @MaxPage  
END
GO

-- ?? ???? ??.
CREATE PROC [dbo].[spWebGetClanRankingSearchByName]  
 	@Name VARCHAR(24)  /* ?? ?? */
AS  
SET NOCOUNT ON
BEGIN  
 	SELECT TOP 1 cl.Ranking, cl.RankIncrease, cl.Name as ClanName, cl.Point, cl.Wins, cl.Losses, cl.CLID, cl.EmblemUrl, ch.Name AS Master, cl.RegDate
	FROM Clan cl(NOLOCK), Character ch(NOLOCK)
 	WHERE ch.CID = cl.MasterCID AND cl.Ranking>0 AND cl.DeleteFlag=0 AND cl.Name=@Name
END
GO

--
-- Definition for stored procedure spWebGetClanRankingSearchByRanking : 
--
GO
CREATE PROC [dbo].[spWebGetClanRankingSearchByRanking]  
 @Ranking INT  
AS  
SET NOCOUNT ON
BEGIN  
 SELECT TOP 20 Ranking, RankIncrease, Name as ClanName, Point, Wins, Losses, CLID, EmblemUrl FROM Clan(NOLOCK)   
 WHERE DeleteFlag=0 AND Ranking>0 AND Ranking=@Ranking ORDER BY Ranking  
END
GO

--
-- Definition for stored procedure spWebGetCLIDbyUserID : 
--
GO
CREATE PROC [dbo].[spWebGetCLIDbyUserID]  
 @UserID varchar(20)  
AS  
 SET NOCOUNT ON
 SELECT cm.CLID  
 FROM Account ac(NOLOCK), Character ch(NOLOCK), ClanMember cm(NOLOCK)  
 WHERE ac.UserID = @UserID AND ch.AID = ac.AID AND cm.CID  = ch.CID
GO

-- My????.
CREATE PROC [dbo].[spWebGetMyClanInfo]
	@CharName varchar(24) /* ??? ?? */
AS
SET NOCOUNT ON
BEGIN
	DECLARE @CLID int

	SELECT @CLID = cm.CLID 
	FROM Account a (NOLOCK), Character c (NOLOCK), ClanMember cm (NOLOCK)
	WHERE c.Name = @CharName AND a.AID = c.AID AND cm.CID = c.CID

	IF @CLID IS NOT NULL
	BEGIN
		SELECT cl.Name, ch.Name AS Master, cl.IntroDuction, cl.RegDate, cl.Homepage, cl.EmblemUrl, cl.Ranking
		FROM Clan cl(NOLOCK), Character ch(NOLOCK)
		WHERE cl.CLID = @CLID AND cl.DeleteFlag = 0 AND ch.CID = cl.MasterCID
	END
END
GO

-- My????? CID? ???.  
CREATE PROC [dbo].[spWebGetMyClanInfoByCID]  
 	@CID int /* ??? CID */  
AS  
SET NOCOUNT ON
BEGIN  
	SELECT t.Name, t.Name AS Master, t.IntroDuction, t.RegDate, t.Homepage, t.EmblemUrl, t.Ranking
	FROM 
	(
	 	SELECT cl.Name, cl.MasterCID, cl.IntroDuction, cl.RegDate, cl.Homepage, cl.EmblemUrl, cl.Ranking
	 	FROM ClanMember cm(NOLOCK), Clan cl(NOLOCK), Character ch(NOLOCK)  
	 	WHERE cm.CID = @CID AND cl.CLID = cm.CLID AND ch.CID = @CID  
	) AS t, Character ch(NOLOCK)
	WHERE t.MasterCID = ch.CID
END
GO

--
-- Definition for stored procedure spWebGetMyClanInfoByCLID : 
--
GO
CREATE PROC [dbo].[spWebGetMyClanInfoByCLID]
	@CLID int
AS
SET NOCOUNT ON
BEGIN
	SELECT cl.Name, ch.Name AS Master, cl.IntroDuction, cl.RegDate, cl.Homepage, cl.EmblemUrl, cl.Ranking
	FROM Clan cl(NOLOCK), Character ch(NOLOCK)
	WHERE cl.CLID = @CLID AND cl.DeleteFlag = 0 AND ch.CID = cl.MasterCID
END
GO

-- ??? ?? ???? Ranking?? ???? ???. ??? ???? ??? ??.
CREATE PROC [dbo].[spWebGetMyClanList]
	@UserID varchar(20) /* ??? ??? */
AS
SET NOCOUNT ON
BEGIN
	SELECT t.Ranking, t.RankIncrease, t.ClanName, t.Point, t.Wins, t.Losses, t.CLID, t.EmblemUrl, ch.Name AS Master, t.RegDate
	FROM 
	(
		SELECT cl.CLID, cl.Name AS ClanName, cl.Point, cl.Wins, cl.Losses, cl.EmblemUrl, cl.Ranking, cl.RankIncrease, cl.MasterCID, cl.RegDate
		FROM Account ac (NOLOCK), Character ch(NOLOCK), ClanMember cm(NOLOCK), Clan cl(NOLOCK)
		WHERE ac.UserID = @UserID AND ac.AID = ch.AID AND cm.CID = ch.CID AND cl.CLID = cm.CLID
	) AS t, Character ch(NOLOCK)
	WHERE t.MasterCID = ch.CID ORDER BY t.Ranking DESC
END
GO

-------------------------------------------------------------------

 CREATE    PROC [dbo].[spWebInsertAccount]   
 @UserID varchar(20)  
, @Password varchar(20)  
, @Cert tinyint  
, @Name varchar(30)  
, @Age smallint  
, @Country char(3)  
, @Sex tinyint  
, @Email varchar(50)=NULL  
, @Ret int OutPut  
AS  
 SET NOCOUNT ON  
 DECLARE @AIDIdent int  
  
 BEGIN TRAN  
 INSERT INTO Account (UserID, Cert, Name, Age, Sex, UGradeID, PGradeID, RegDate, Email,  Country)  
 VALUES (@UserID, @Cert, @Name, @Age, @Sex, 0, 0, GETDATE(), @Email,  @Country)  
 IF @@ERROR <> 0 BEGIN  
  ROLLBACK TRAN  
  SET @Ret = 0  
  RETURN @Ret   
 END  
  
 SET @AIDIdent = @@IDENTITY  
 INSERT INTO login(UserID, AID, Password)  
 VALUES (@UserID, @AIDIdent, @Password)  
 IF @@ERROR <> 0 BEGIN  
  ROLLBACK TRAN  
  SET @Ret = 0  
  RETURN @Ret   
 END  
 COMMIT TRAN  
  
 SET @Ret = 1  
 RETURN @Ret
GO

--
-- Definition for stored procedure spWebInsertClanAdsBoard : 
--
GO
CREATE PROC [dbo].[spWebInsertClanAdsBoard]
 @UserID	varchar(20),
 @Subject	varchar(50),
 @Content	varchar(2000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint
AS
 SET NOCOUNT ON
 DECLARE @NewThread int
 SELECT @NewThread = ISNULL(MAX(Thread), 0) + 1000 FROM ClanAdsBoard(NOLOCK) 

 BEGIN TRAN
 INSERT INTO ClanAdsboard (UserID, Subject, Content,  Regdate, ReadCount, FileName, Link, HTML, GR_ID, GR_Depth,GR_Pos,Thread)
 VALUES (@UserID, @Subject, @Content,  GetDate(), 0, @FileName, @Link, @HTML, 0,0,0,@NewThread)
 IF 0 <> @@ERROR BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanAdsBoard SET GR_ID = seq where GR_ID = 0
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 COMMIT TRAN
GO

----------------------------------------------------------------------------

-- ??? ??? ??
CREATE PROC [dbo].[spWebInsertClanAdsComment]
 @Seq int,
 @Userid varchar(20),
 @Content varchar(500)
AS
 SET NOCOUNT ON

 BEGIN TRAN
 INSERT INTO ClanAdsComment (Seq, UserID, Content, RegDate)
 VALUES(@Seq,  @UserID, @Content, GetDate())
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanAdsBoard SET CommentCount = CommentCount + 1 WHERE Seq = @Seq
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 COMMIT TRAN
GO

--------------------------------------------------------------------------------------------------------

/***************************************************************************/
/****			??  ??? ?? ????			****/
/***************************************************************************/


-- ??? ??

CREATE   PROC [dbo].[spWebInsertClanBoard]
 @CLID		int,
 @UserID		varchar(20),
 @Subject	varchar(50),
 @Content	varchar(4000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint
AS
 SET NOCOUNT ON
 DECLARE @NewThread int
 SELECT @NewThread = ISNULL(MAX(Thread),0) + 1000 FROM ClanBoard(NOLOCK)

 BEGIN TRAN
 INSERT INTO ClanBoard (CLID, UserID, Subject, Content,  Regdate, ReadCount, FileName, Link, HTML, GR_ID, GR_Depth,GR_Pos,Thread)
 VALUES	(@CLID, @UserID, @Subject, @Content,  GetDate(), 0, @FileName, @Link, @HTML, 0,0,0,@NewThread)
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanBoard SET GR_ID = seq where GR_ID = 0
 IF( 0 <> @@ERROR) BEGIN
  ROLLBACK TRAN
  RETURN
 END
 COMMIT TRAN
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??? ??

CREATE PROC [dbo].[spWebInsertClanBoardComment]
 @Seq int,
 @UserID varchar(20),
 @Content varchar(500)
AS
 SET NOCOUNT ON
 BEGIN TRAN
 INSERT INTO ClanBoardComment (Seq, UserID, Content, RegDate)
 VALUES(@Seq,  @UserID, @Content, GetDate())
 IF (@@ERROR <> 0)  BEGIN
  ROLLBACK TRAN
  RETURN
 END

 Update ClanBoard Set CommentCount = CommentCount + 1 WHERE Seq = @Seq
 IF (0 <> @@ERROR) BEGIN
  ROLLBACK TRAN
  RETURN
 END
 COMMIT TRAN
GO

-- ????? ????
CREATE     PROC [dbo].[spWebItemUseLog]
	@UserID		VARCHAR(32)
AS
SET NOCOUNT ON
BEGIN

	DECLARE @TargetAID INT
	SELECT @TargetAID = AID FROM Account(NOLOCK) WHERE UserID=@UserID

	SELECT l.AID, l.CID, c.Name AS CharName, i.ItemID, i.Name AS ItemName, l.Date, c.DeleteName 
	FROM BringAccountItemLog l(NOLOCK), Item i(NOLOCK), Character c(NOLOCK)
	WHERE l.AID=@TargetAID AND l.CID=c.CID AND l.ItemID=i.ItemID
	ORDER BY  Date DESC
END
GO

-- ??? ?? ??.
CREATE PROC [dbo].[spWebLeaveClan]
	@CharName varchar(24) /* ??? ?? */
AS
BEGIN TRAN
	SET NOCOUNT ON

	DECLARE @CLID int
	DECLARE @CID int
	DECLARE @MasterCID int

	-- ???? ??????
	SELECT @CLID = cm.CLID, @CID = c.CID, @MasterCID = cl.MasterCID
	FROM Account a (NOLOCK), Character c (NOLOCK), Clan cl(NOLOCK), ClanMember cm (NOLOCK)
	WHERE c.Name = @CharName AND a.AID = c.AID AND cm.CID = c.CID AND cl.CLID = cm.CLID

	-- ?????? ??? ??? ??? ?? ???.
	IF (@CID IS NULL) OR (@MasterCID = @CID) OR (@CLID IS NULL)
	BEGIN
		ROLLBACK TRAN
		SET NOCOUNT OFF 
		RETURN
	END
		
	DELETE ClanMember WHERE CID = @CID
	IF 0 <> @@ERROR
	BEGIN
		ROLLBACK TRAN
		SET NOCOUNT OFF 
		RETURN
	END

	SET NOCOUNT OFF 
COMMIT TRAN
GO

-- CID? ?? ??.
CREATE  PROC [dbo].[spWebLeaveClanByCID]
	@CID int /* ???? ??? CID */
AS
SET NOCOUNT ON
BEGIN TRAN
	

	DECLARE @CLID int
	DECLARE @MasterCID int

	-- ???? ??????
	SELECT @CLID = cm.CLID, @MasterCID = cl.MasterCID
	FROM Clan cl(NOLOCK), ClanMember cm (NOLOCK)
	WHERE cm.CID = @CID AND cl.CLID = cm.CLID

	-- ?????? ??? ??? ??? ?? ???.
	IF (@CID IS NULL) OR (@MasterCID = @CID) OR (@CLID IS NULL)
	BEGIN
		ROLLBACK TRAN
		SELECT 0
		RETURN
	END
		
	DELETE ClanMember WHERE CID = @CID
	IF 0 <> @@ERROR
	BEGIN
		ROLLBACK TRAN
		SELECT 0
		RETURN
	END

	SELECT 1	
COMMIT TRAN
SET NOCOUNT OFF
GO

----------------------------------------------------------------------------

-- ??? ??
CREATE PROC [dbo].[spWebReplyClanAdsBoard]
 @Seq		int,
 @UserID	varchar(20),
 @Subject	varchar(50),
 @Content	varchar(2000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint,
 @GR_ID		int,
 @GR_Depth	int,
 @GR_Pos	int
AS
 SET NOCOUNT ON
 DECLARE @ParentThread       int
 DECLARE @PrevThread          int

 SELECT @ParentThread = Thread FROM ClanAdsBoard(NOLOCK) WHERE Seq = @Seq
 SELECT @PrevThread = @ParentThread -1000 FROM ClanAdsBoard(NOLOCK) WHERE GR_ID =@GR_ID and GR_Depth = '0'

 BEGIN TRAN
 UPDATE ClanAdsBoard 
 SET Thread = Thread - 1
 WHERE Thread < @ParentThread and Thread > @PrevThread
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanAdsBoard SET GR_Pos =GR_Pos+1
 WHERE GR_ID = @GR_ID and GR_Pos = @GR_Pos
 IF (0 <> @@ERROR) OR (0 = @@ROWCOUNT) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 SET @GR_Depth = @GR_Depth+1;
 SET @GR_Pos = @GR_Pos + 1;

 INSERT INTO ClanAdsBoard (UserID, Subject, Content,  Regdate, ReadCount,  FileName, Link, HTML, GR_ID, GR_Depth, GR_Pos, Thread)
 VALUES	(@UserID, @Subject, @Content,  GetDate(), 0, @FileName, @Link, @HTML, @GR_ID, @GR_Depth, @GR_Pos, @ParentThread-1)
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 COMMIT TRAN
GO

--------------------------------------------------------------------------------------------------------

-- ??? ??

CREATE   PROC [dbo].[spWebReplyClanBoard]
 @Seq		int,
 @UserID	varchar(20),
 @Subject	varchar(50),
 @Content	varchar(4000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint,
 @GR_ID		int,
 @GR_Depth	int,
 @GR_Pos	int
AS
 SET NOCOUNT ON
 DECLARE @CLID	int
 DECLARE @ParentThread       int
 DECLARE @PrevThread          int

 SELECT @CLID = CLID FROM ClanBoard(NOLOCK) Where Seq = @Seq
 SELECT @ParentThread = Thread FROM ClanBoard(NOLOCK) Where Seq = @Seq
 SELECT @PrevThread = @ParentThread -1000 FROM ClanBoard(NOLOCK) where GR_ID =@GR_ID and GR_Depth = '0'

 BEGIN TRAN
 UPDATE ClanBoard 
 SET Thread = Thread - 1
 Where Thread < @ParentThread and Thread > @PrevThread
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 UPDATE ClanBoard SET GR_Pos =GR_Pos+1
 WHERE GR_ID = @GR_ID and GR_Pos = @GR_Pos
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END

 SET @GR_Depth = @GR_Depth+1;
 SET @GR_Pos = @GR_Pos + 1;

 INSERT INTO ClanBoard (CLID, UserID, Subject, Content,  Regdate, ReadCount,  FileName, Link, HTML, GR_ID, GR_Depth, GR_Pos, Thread)
 VALUES (@CLID, @UserID, @Subject, @Content,  GetDate(), 0, @FileName, @Link, @HTML, @GR_ID, @GR_Depth, @GR_Pos, @ParentThread-1)
 IF (@@ERROR <> 0) BEGIN
  ROLLBACK TRAN
  RETURN
 END
 COMMIT TRAN
GO

-- ??? ???
CREATE   PROC [dbo].[spWebResetChar]
	@CID		INT
AS
SET NOCOUNT ON

BEGIN
	-- ?? ???
	UPDATE Character SET Level=1, XP=0, BP=0, 

	head_slot=NULL, chest_slot=NULL, hands_slot=NULL, legs_slot=NULL, feet_slot=NULL,
	fingerl_slot=NULL, fingerr_slot=NULL, melee_slot=NULL, primary_slot=NULL, secondary_slot=NULL,
	custom1_slot=NULL, custom2_slot=NULL,
	GameCount=0, KillCount=0, DeathCount=0, 
	head_itemid=NULL, chest_itemid=NULL, hands_itemid=NULL, legs_itemid=NULL, feet_itemid=NULL,
	fingerl_itemid=NULL, fingerr_itemid=NULL, melee_itemid=NULL, primary_itemid=NULL, secondary_itemid=NULL,
	custom1_itemid=NULL, custom2_itemid=NULL, QuestItemInfo=NULL

	WHERE CID=@CID

	-- ??? ??(?? ???? ??)
	UPDATE CharacterItem SET CID=NULL WHERE CID=@CID AND ItemID < 500000

END
GO

----------------------------------------------------------------------------

-- ??? ?? by Subject 
CREATE PROC [dbo].[spWebSearchClanAdsBoardbySubject]
 @Subject	varchar(30)
AS
 SET NOCOUNT ON
 SELECT Seq, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanAdsBoard(NOLOCK)
 WHERE Subject like @Subject
 ORDER BY Thread DESC
GO

----------------------------------------------------------------------------

CREATE PROC [dbo].[spWebSearchClanAdsBoardbyUserID]
 @UserID	varchar(20)
AS
 SET NOCOUNT ON
 SELECT Seq, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanAdsBoard (NOLOCK)
 WHERE UserID = @UserID
 ORDER BY Thread DESC
GO

--------------------------------------------------------------------------------------------------------

-- ??? ?? by Subject 

CREATE PROC [dbo].[spWebSearchClanBoardbySubject]
 @CLID int
, @Subject varchar(30)
AS
 SET NOCOUNT ON
 SELECT Seq, CLID, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanBoard(NOLOCK)
 WHERE CLID = @CLID and Subject like @Subject
 ORDER BY Thread DESC
GO

--------------------------------------------------------------------------------------------------------

-- ??? ?? by UserID 

CREATE PROC [dbo].[spWebSearchClanBoardbyUserID]
 @CLID int
, @UserID varchar(20)
AS
 SET NOCOUNT ON
 SELECT Seq, CLID, Userid, Subject, RegDate, ReadCount, Recommend, CommentCount
 FROM ClanBoard(NOLOCK)
 WHERE CLID = @CLID and UserID = @UserID
 ORDER BY Thread DESC
GO

---------------------------------------------------------------------------

CREATE PROC [dbo].[spWebSearchClanMemberByCharName]  
 @CLID int  
, @CharName varchar(20)  
AS  
 SET NOCOUNT ON  
 SELECT cm.CLID, cm.Grade, c.Name, c.Level, c.XP, cm.RegDate  
 FROM ClanMember cm(NOLOCK) JOIN Character c(NOLOCK)  
 ON cm.CLID = @CLID AND c.CID = cm.CID AND c.Name = @CharName  
 ORDER BY cm.RegDate DESC
GO

--
-- Definition for stored procedure spWebSearchTotalRankingByName : 
--
GO
/* ??? ???? ?? ?? */    
CREATE PROC [dbo].[spWebSearchTotalRankingByName]    
  @Name    varchar(24)    
AS  
SET NOCOUNT ON
BEGIN    
 SELECT Rank, Level, Name, XP, KillCount, DeathCount, UserID  
 FROM TotalRanking(NOLOCK)    
 WHERE Name = @Name    
END
GO

-- ??? ?? ??.
CREATE PROC [dbo].[spWebSearchTotalRankingByNetmarbleID]
	@UserID varchar(20)
AS
SET NOCOUNT ON
BEGIN
	SELECT Rank, Level, Name, XP, KillCount, DeathCount, UserID 
	FROM TotalRanking (NOLOCK)
	WHERE UserID = @UserID
END
GO

--
-- Definition for stored procedure spWebUndeleteChar : 
--
GO
CREATE  PROC [dbo].[spWebUndeleteChar]
	@CID INT
AS
SET NOCOUNT ON
BEGIN
	DECLARE @AID INT
	DECLARE @Name VARCHAR(64)
	SELECT @Name = DeleteName, @AID=AID FROM Character(NOLOCK) WHERE CID=@CID
	
	IF @AID IS NULL
	BEGIN
		SELECT 'It is not exist character.' AS ERROR, @CID AS CID
		GOTO label_finish
	END
	
	--SELECT @Name AS Name
	IF @Name IS NULL
	BEGIN
		SELECT 'already exist character' AS ERROR, @CID AS CID
		GOTO label_finish
	END
	
	-- find empty slot.
	DECLARE @CharNum INT
	SELECT @CharNum=a.CharNum FROM
	(
		SELECT 0 AS CharNum UNION 
		SELECT 1 AS CharNum UNION 
		SELECT 2 AS CharNum UNION 
		SELECT 3 AS CharNum
	) a WHERE NOT EXISTS
	(
		SELECT CharNum FROM Character(NOLOCK) 
		WHERE AID=@AID AND DeleteFlag=0 AND CharNum=a.CharNum
	)
	IF @CharNum IS NULL
	BEGIN
		SELECT 'no more empty slot' AS ERROR, @CID AS CID
		GOTO label_finish
	END
	
	DECLARE @ExistName VARCHAR(64)
	SELECT @ExistName = Name FROM Character(NOLOCK) WHERE AID=@AID AND CharNum=@CharNum
	IF @ExistName IS NOT NULL
	BEGIN
		SELECT 'already exist slot.' AS ERROR, @CID AS CID
		GOTO label_finish
	END
	
	DECLARE @Count int
	SELECT @Count=COUNT(*) FROM Character(NOLOCK) WHERE Name=@Name
	
	--SELECT @Name AS UndeleteTarget
	
	IF ( @Count <= 0 )
	BEGIN
		Update Character Set Name=@Name WHERE CID=@CID
		Update Character Set CharNum=@CharNum WHERE CID=@CID
		Update Character Set DeleteFlag=0 WHERE CID=@CID
		Update Character Set DeleteName=NULL WHERE CID=@CID
	
		SELECT 'completed restore' AS ERROR, @Name AS 'Name'
	END
	ELSE
	BEGIN
		SELECT 'already exist name' AS ERROR, @Name AS 'Name', @Count AS 'Count'
	END
		
label_finish:
END
GO

--
-- Definition for stored procedure spWebUpdateAccount : 
--
GO
CREATE    PROC [dbo].[spWebUpdateAccount]     
 @UserID varchar(20)    
, @Password varchar(20)=NULL    
, @Cert tinyint    
, @Name  varchar(30)    
, @Age smallint    
, @Country char(3)    
, @Sex tinyint    
, @Email varchar(50)=NULL    
, @Ret int OutPut    
AS    
 SET NOCOUNT ON    
 BEGIN TRAN    
 UPDATE Account SET  Cert = @Cert, Name = @Name, Age = @Age, Sex = @Sex, Email = @Email,     
  Country = @Country    
 WHERE UserID = @UserID    
 IF 0 = @@ROWCOUNT BEGIN    
  ROLLBACK TRAN    
  SET @Ret = 0    
  RETURN @Ret     
 END    
    
 IF (@Password <> '') AND (@Password IS NOT NULL) BEGIN    
  UPDATE  login SET Password = @Password    
  WHERE UserID = @UserID    
  IF 0 = @@ROWCOUNT BEGIN    
   ROLLBACK TRAN    
   SET @Ret = 0    
   RETURN @Ret     
  END    
 END    
  
 COMMIT TRAN    
    
 SET @Ret = 1    
 RETURN @Ret
GO

----------------------------------------------------------------------------

-- ??? ??
CREATE PROC [dbo].[spWebUpdateClanAdsBoard]
 @Seq		int,
 @Subject	varchar(50),
 @Content	varchar(2000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint
AS
 SET NOCOUNT ON
 UPDATE ClanAdsBoard
 SET Subject= @Subject, Content=@Content, FileName=@FileName, Link=@Link, HTML=@HTML
 WHERE Seq = @Seq
GO

----------------------------------------------------------------------------

CREATE PROC [dbo].[spWebUpdateClanAdsBoardReadCount]
 @Seq int
AS
 SET NOCOUNT ON
 UPDATE ClanAdsBoard SET ReadCount = ReadCount + 1 WHERE Seq = @Seq
GO

--------------------------------------------------------------------------------------------------------


-- ??? ??

CREATE   PROC [dbo].[spWebUpdateClanBoard]
 @Seq		int,
 @Subject	varchar(50),
 @Content	varchar(4000),
 @FileName	varchar(128),
 @Link		varchar(255),
 @HTML		smallint
AS
 SET NOCOUNT ON
 UPDATE ClanBoard
 SET Subject= @Subject, Content=@Content,
   FileName=@FileName, Link=@Link, HTML=@HTML
 WHERE Seq = @Seq
GO

--------------------------------------------------------------------------------------------------------

-- ??? ?? 

CREATE PROC [dbo].[spWebUpdateClanBoardReadCount]
 @Seq int
AS
 SET NOCOUNT ON
 Update ClanBoard Set ReadCount = ReadCount + 1 WHERE Seq = @Seq
GO

-- ??? ?? ????  
CREATE  PROC [dbo].[spWinTheClanGame]  
 @WinnerCLID  int,  
 @LoserCLID  int,  
 @IsDrawGame  tinyint,  
 @WinnerPoint  int,  
 @LoserPoint  int,  
 @WinnerClanName  varchar(24),  
 @LoserClanName  varchar(24),  
 @RoundWins  tinyint,  
 @RoundLosses  tinyint,  
 @MapID   tinyint,  
 @GameType  tinyint,  
 @WinnerMembers  varchar(110),  
 @LoserMembers  varchar(110)  
AS  
 SET NOCOUNT ON -- ??.  
  
 IF @IsDrawGame = 0  
 BEGIN  
  BEGIN TRAN  
  -- ??? Wins+1  
  UPDATE Clan SET Wins=Wins+1, Point=Point+@WinnerPoint, TotalPoint=TotalPoint+@WinnerPoint WHERE CLID=@WinnerCLID  
  IF 0 = @@ROWCOUNT BEGIN -- ?? ??.  
   ROLLBACK TRAN  
   RETURN  
  END  
  
  -- ?? Losses+1  
  UPDATE Clan SET Losses=Losses+1, Point= dbo.fnGetMax(0, Point+(@LoserPoint)) WHERE CLID=@LoserCLID    
  IF 0 = @@ROWCOUNT BEGIN -- ?? ??.  
   ROLLBACK TRAN  
   RETURN  
  END  
--  UPDATE Clan SET Point=0 WHERE CLID=@LoserCLID AND Point<0  
  
  -- ?? ??? ???.  
  INSERT INTO ClanGameLog(WinnerCLID, LoserCLID, WinnerClanName, LoserClanName, RoundWins, RoundLosses, MapID, GameType, RegDate, WinnerMembers, LoserMembers, WinnerPoint, LoserPoint)  
  VALUES (@WinnerCLID, @LoserCLID, @WinnerClanName, @LoserClanName, @RoundWins, @RoundLosses, @MapID, @GameType, GETDATE(), @WinnerMembers, @LoserMembers, @WinnerPoint, @LoserPoint)  
  IF 0 <> @@ERROR BEGIN -- ?? ??.  
   ROLLBACK TRAN  
   RETURN  
  END  
  COMMIT TRAN  
 END  
 ELSE  
 BEGIN  
  UPDATE Clan SET Draws=Draws+1 WHERE CLID=@WinnerCLID OR CLID=@LoserCLID  
 END
GO

--
-- Definition for stored procedure USP_sjr_TableSizeIncr : 
--
GO
create proc [dbo].[USP_sjr_TableSizeIncr]

as
begin 
	SET NOCOUNT ON

	select identity(int,1,1) idx ,' insert sjr_TableSizeIncr (name,rows,reserved,date,index_size,unused) ' +char(10)+
	'exec sp_spaceused '+name  as sql  into #spaceusedTb
	from Gunzdb.dbo.sysobjects where xtype = 'U'
	 
	
	DECLARE @sql varchar(400) 
	DECLARE SQL_cursor CURSOR FOR 
	SELECT  sql
	FROM #spaceusedTb
	ORDER BY idx
	OPEN SQL_cursor
	FETCH NEXT FROM SQL_cursor 
	INTO @sql
	WHILE @@FETCH_STATUS = 0
	BEGIN
	   exec (@sql)
	   FETCH NEXT FROM SQL_cursor 
	   INTO @sql
	END
	CLOSE SQL_cursor
	DEALLOCATE SQL_cursor

end
GO

