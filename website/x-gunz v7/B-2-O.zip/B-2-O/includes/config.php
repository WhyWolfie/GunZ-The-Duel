<?
if (!($connection = @ mssql_connect('USUARIO-7D01F86\SQLEXPRESS','sa','007007')))
      die("SHIT WTF IS WRONG");


mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Server Undergoing maintenance";
}

?>
