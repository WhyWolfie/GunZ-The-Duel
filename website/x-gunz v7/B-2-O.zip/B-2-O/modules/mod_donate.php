<?
if ($_SESSION['AID'] == ""){
re_dir("index.php?do=login");
}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="348">
											<img border="0" src="images/inf/buycoins.jpg" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">
											&nbsp;</td>
										</tr>
	
										<tr>
											<td width="432">
											<form action="https://www.paypal.com/cgi-bin/webscr" method="post""><table border="0" style="border-collapse: collapse" width="100%" id="table13">
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
											</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#FF0000">
												Use this form to Get B2o Coins<br />Please Fill in the Correct details to recieve B2o coins<br />You Will Be Redirected to Paypal in Next Step<br /><br />Dont Have A Paypal Account ?<br />Its free Go to <a href="http://www.paypal.com/">PayPal</a></font></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
												</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#00FF00">
												1 USD = 15 Coins<br /></font></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16">
												Donate from:</td>
												<td width="441" height="16" colspan="3">
												<form name="itemtype2"><select size="1" name="asunto" onchange="SwitchPayment()">
												<option value="1">Paypal</option>
												<option value="2">Alert-Pay</option>
												</select></form></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">&nbsp;</td>
												<td width="441" colspan="3">&nbsp;</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16">
												Coins:</td>
												<td width="441" height="16" colspan="3">
												<input type="hidden" name="cmd" value="_s-xclick">
												<input type="hidden" name="hosted_button_id" value="4123395">
												<input type="hidden" name="on0" value="Coins"><select name="os0">
												<option value="15 Coins">15 Coins $1.00
										                <option value="30 Coins">30 Coins $2.00
										                <option value="45 Coins">45 Coins $3.00
										                <option value="60 Coins">60 Coins $4.00
										                <option value="75 Coins">75 Coins $5.00
										                <option value="150 Coins">150 Coins $10.00
										                <option value="225 Coins">225 Coins $15.00
										                <option value="300 Coins">300 Coins $20.00
										                <option value="375 Coins">375 Coins $25.00
										                <option value="450 Coins">450 Coins $30.00
												</option>
												</select></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">&nbsp;</td>
												<td width="441" colspan="3">&nbsp;</td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">Game ID:</td>
												<td width="441" colspan="3">
												<input type="hidden" name="on1" value="Game ID" size="20">
												<input type="text" name="os1" value="<?=$_SESSION['UserID']?>"/>
												<input type="hidden" name="currency_code" value="USD"></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16"></td>
												<td width="441" height="16" colspan="3"></td>
												</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#00FF00">
												The Coins will be added to Your account within 24 hrs after the payment<br />Thank You for donating the server<br /><br /></font></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="50" height="16" colspan="3">
												<center><input type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG_global.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
												<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
												</td>
												</tr>
												</table></form>
											</td>
										</tr>
	
										<tr>
											<td width="432">
											&nbsp;</td>
										</tr>
	
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			