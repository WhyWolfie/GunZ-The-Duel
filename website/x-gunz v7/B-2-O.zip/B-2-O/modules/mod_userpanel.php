<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<table border="0" align="left" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="left">
						</div>
						</td>
						<td valign="top">
						<div align="left">
							<table border="1" align="left" style="border-collapse: collapse" width="480" bordercolor="#000000">
								<tr>
<div align="left">
									<td background="images/content_bar.jpg"  height="24" align="left" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Character Information</font></b></td>
								</tr>
								<td bgcolor="#232122">							
							<div align="center">
								<table border="0"  style="border-collapse: collapse" align="left" width="480" height="100%">

										<tr>
										
												<div align="center">
												<table border="1" style="border-collapse: collapse" width="141" height="100%">
<?
echo '  <font face="Arial" color="#ffffff">My Characters:</font>';
        $query = mssql_query("SELECT * FROM Character(nolock) WHERE AID = '" . antisql($_SESSION['AID']) . "' AND DeleteFlag = 0 ORDER BY CharNum ASC");
        if ( mssql_num_rows($query) < 1 ){
        echo '<font face="Arial" color="#ff0000"><br>You have no character yet. Create one</br>';
        }else{

        echo '
        <table border="1" style="border-collapse: collapse" width="95%" id="table1">
	    <tr>
		<td><font face="Arial" color="#ffffff">Name</font></td>
		<td><font face="Arial" color="#ffffff">Lvl</font></td>
		<td><font face="Arial" color="#ffffff">Experience</font></td>
                <td><font face="Arial" color="#ffffff">Bounty</font></td>
                <td><font face="Arial" color="#ffffff">Kill/Death</font></td>
	    </tr>';

        $i = 1;
        while ( $i <= mssql_num_rows($query) ){
        $chars = mssql_fetch_assoc($query);

        echo '<tr>
		<td><font face="Arial" color="#ffffff"><a href="index.php?do=charinfo&id='.$chars['CID'].'">'.FormatCharName($chars['CID']).'</a></font></td>
		<td><font face="Arial" color="#ffffff">'.$chars['Level'].'</font></td>
		<td><font face="Arial" color="#ffffff">'.$chars['XP'].'</font></td>
        <td><font face="Arial" color="#ffffff">'.$chars['BP'].'</font></td>
		<td><font face="Arial" color="#ffffff">'.GetKDRatio($chars['KillCount'], $chars['DeathCount']).'</font></td>
	    </tr>';

        $i++;
        }
        echo '</table>';
        }
        echo'</br>
      

        <font face="Arial" color="#ffffff">My Clans:<br />
        <table border="1" style="border-collapse: collapse" width="95%" id="table1">
	    <tr>
                <td><font face="Arial" color="#ffffff">Clan Picture</font></td>
                <td><font face="Arial" color="#ffffff">Clan Name</font></td>
		<td><font face="Arial" color="#ffffff">Clan Leader</font></td>
		<td><font face="Arial" color="#ffffff">Clan Rank</font></td>

	    </tr>';
        $query2 = mssql_query("SELECT * FROM Character(nolock) WHERE AID = '" . antisql($_SESSION['AID']) . "' ORDER BY CharNum ASC");
        if (mssql_num_rows($query2) > 0){
        while ($chars2 = mssql_fetch_assoc($query2)){


        $clanq = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$chars2['CID']."'");
            if (mssql_num_rows($clanq) != 0){
            $clanq2 = mssql_fetch_assoc($clanq);
                if($clanq2['Grade'] == 9){
                $rango = "Member  ";
                $admin = "No";
                }elseif($clanq2['Grade'] == 2){
                $rango = "Admin";
                $admin = "No";
                }elseif($clanq2['Grade'] == 1){
                $rango = "Master";
                $clid = $clanq2['CLID'] + 1990;
                $cid = $clanq2['CID'] + 2000;

                }else{
                $rango = "Error";
                }
            $claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '". antisql($clanq2['CLID']) ."'");
            $claninfo = mssql_fetch_assoc($claninfoq);

            $emblemurl = $claninfo['EmblemUrl'];
            if ($emblemurl == ''){
                $emblemurl = '<IMG SRC="images/no_emblem.png" WIDTH=50 HEIGHT=50>';
            }else{
                $emblemurl = '<img width="50" height="50" src="clanemblem/'.$emblemurl.'">';
                }

                echo '<tr>
                <td align="center" valign="center">'.$emblemurl.'</td>
                <td><font face="Arial" color="#ffffff"><a href="index.php?do=claninfo&id='.$claninfo['CLID'].'">'.$claninfo['Name'].'</a></font></td>
		        <td><font face="Arial" color="#ffffff"><a href="index.php?do=charinfo&id='.$chars2['CID'].'">'.FormatCharName($chars2['CID']).'</a></font></td>
		        <td><font face="Arial" color="#ffffff">'.$rango.'</font></td>

             
	           </tr>';
                }
            }
        }

?>
										</table></form>
								</div>
								&nbsp;</td>
							</tr>

						</table>


	</div>
						</td>
					</tr>
				</table>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			