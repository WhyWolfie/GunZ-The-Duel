<?php
//This file has been edited by Wizkid. All rights reserved.
include "authadmin.php";
//What the fux? No offensive, but a GM should be able to post shit like that.
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $itemid = antisql($_POST['ITEMID']);
    $AID1 = antisql($_POST['AID1']);
    $AID2 = antisql($_POST['AID2']);
    $AID3 = antisql($_POST['AID3']);
    $AID4 = antisql($_POST['AID4']);
    $AID5 = antisql($_POST['AID5']);
    $period = antisql($_POST['period']);
    $rentperiod = $period*24;

    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$AID1', '$itemid', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$AID2', '$itemid', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$AID3', '$itemid', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$AID4', '$itemid', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$AID5', '$itemid', GETDATE(), '$rentperiod', 1)");


    msgbox("Added correctly","index.php?do=add2storagebyaid");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=add2storagebyaid"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="431" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="112" align="right">
											ITEMID</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="ITEMID" size="40"></td>
										</tr>

										<tr>
											<td width="112" align="right">
											AID 1</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="AID1" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											AID 2</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="AID2" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											AID 3</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="AID3" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											AID 4</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="AID4" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											AID 5</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="AID5" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											Period</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="period" size="40"></td>
										</tr>
										<tr>
											<td width="112">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			