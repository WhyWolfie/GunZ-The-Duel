<table border="0" style="border-collapse: collapse" width="177">
								<tr>
									<td height="141" style="background-image: url('images/md_ir.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="175" height="100%">
											<tr>
												<td width="9" height="39">&nbsp;</td>
												<td width="149" height="39">&nbsp;</td>
												<td width="11" height="39">&nbsp;</td>
											</tr>
											<tr>
												<td width="9">&nbsp;</td>
												<td width="149" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="149">
                                                    <?
                                                    $queryrank01 = mssql_query("SELECT TOP 5 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
                                                    $count = 0;
						    if(mssql_num_rows($queryrank01) <> 0)
                                                    {
                                                          while($char = mssql_fetch_assoc($queryrank01))
                                                          {
							$count++;
                                                        $indrank .= '
  														<tr>
  															<td width="7" align="left">
  															<img border="0" src="images/rank-'.$count.'.jpg" width="9" height="9"></td>
  															<td width="104" align="left">
  															&nbsp;<a href="index.php?do=charinfo&id='.$char['CID'].'">'.$char['Name'].'</a></td>
  															<td width="27" align="left">
  															'.$char[Level].'&nbsp;LvL</td>
  														</tr>';
                                                          }
                                                      }
                                                      else
                                                      {
                                                        $indrank = '
														<tr>
                                                            <center>No data</center>
														</tr>';
                                                      }
                                                      echo $indrank;
                                                    ?>
													</table>
												</div>
												</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="9" height="23">&nbsp;</td>
												<td width="149" height="23">&nbsp;</td>
												<td width="11" height="23">&nbsp;</td>
											</tr>
										</table>
									</div>
									<p>&nbsp;</td>
								</tr>
								<tr>
									<td height="0">&nbsp;</td>
								</tr>
								<tr>
									<td height="141" style="background-image: url('images/md_cr.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="175" height="100%">
											<tr>
												<td width="9" height="39">&nbsp;</td>
												<td width="149" height="39">&nbsp;</td>
												<td width="11" height="39">&nbsp;</td>
											</tr>
											<tr>
												<td width="9">&nbsp;</td>
												<td width="149" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="149">
                                                    <?
                                                    $queryrank02 = mssql_query("SELECT TOP 5 * FROM Clan WHERE DeleteFlag = 0 AND Wins != 0 OR DeleteFlag = 0 AND Losses != 0 ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                                  	$countc = 0;
							if(mssql_num_rows($queryrank02) <> 0)
                                                    {
                                                        while($char = mssql_fetch_assoc($queryrank02))
                                                        {
							$countc++;
                                                        $clanrank2 .= '
														<tr>
															<td width="7" align="left">
															<img border="0" src="images/rank-'.$countc.'.jpg" width="9" height="9"></td>
															<td width="104" align="left">
															&nbsp;<a href="index.php?do=claninfo&id='.$char['CLID'].'">'.$char['Name'].'</a></td>
															<td width="27" align="left">
															'.$char[Point].'&nbsp;Pt</td>
														</tr>';
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $clanrank2 = '
														<tr>
                                                            <center>No data</center>
														</tr>';
                                                    }
                                                    echo $clanrank2;



                                                ?>
													</table>
												</div>
												</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="9" height="23">&nbsp;</td>
												<td width="149" height="23">&nbsp;</td>
												<td width="11" height="23">&nbsp;</td>
											</tr>
										</table>
									</div>
									<p>&nbsp;</td>
								</tr><tr>
									<td height="0">&nbsp;</td>
								</tr>
							</table>
