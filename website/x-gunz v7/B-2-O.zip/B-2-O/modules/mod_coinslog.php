<?php

include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
$query = mssql_query ("SELECT * FROM CoinsLog") or die(mssql_error());

?>
<table width="442" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Admin Coins logs</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="50" scope="row"><span class="style28"><strong>From</strong></span></th>
    <td width="61"><span class="style28"><strong>To</strong></span></td>
   <td width="61"><span class="style28"><strong>Coins</strong></span></td>
   <td width="200"><span class="style28"><strong>Date</strong></span></td>
   <td width="61"><span class="style28"><strong>Paid in $</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
        <td><span class="style28"><?php echo "$row[3]";?></span></td>
<td><span class="style28"><?php echo "$row[4]";?></span></td>
</tr>
  <?
  $i++;
  }
   ?>
</table></div>
</body>

</html>

			