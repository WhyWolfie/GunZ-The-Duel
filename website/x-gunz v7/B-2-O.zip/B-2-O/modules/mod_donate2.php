<?
if ($_SESSION['AID'] == ""){
re_dir("index.php?do=login");
}
msgbox ("The AlertPay Payments are not being accepted currently. It will be available soon, Please Check back later.","index.php?do=donate");
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="348">
											<img border="0" src="images/inf/buycoins.jpg" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">
											&nbsp;</td>
										</tr>
	
										<tr>
											<td width="432">
											<form action="https://www.alertpay.com/PayProcess.aspx" method="post""><table border="0" style="border-collapse: collapse" width="100%" id="table13">
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
											</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#FF0000">
												Use this form to Get B2o Coins<br />Please Fill in the Correct details to recieve B2o coins<br />You Will Be Redirected to Paypal in Next Step<br /><br />Dont Have A Paypal Account ?<br />Its free Go to <a href="http://www.paypal.com/">PayPal</a></font></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
												</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#00FF00">
												1 USD = 15 Coins<br /></font></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16">
												Donate from:</td>
												<td width="441" height="16" colspan="3">
												<form name="itemtype2"><select size="1" name="asunto" onchange="SwitchPayment2()">
												<option value="2">AlertPay</option>
												<option value="1">Paypal</option>
												</select></form></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">&nbsp;</td>
												<td width="441" colspan="3">&nbsp;</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16">
												Coins:</td>
												<td width="441" height="16" colspan="3">
												 <input type="hidden" name="ap_purchasetype" value="item"/>
												 <input type="hidden" name="ap_merchant" value="b2ogaming@gmail.com"/>
												 <input type="hidden" name="ap_itemname" value="B2O Gunz Reloaded Donation"/>
												  <input type="hidden" name="ap_currency" value="USD"/>
												 <input type="hidden" name="ap_returnurl" value=""/>
												 <input type="hidden" name="ap_quantity" value="1"/>
												 												<select name="ap_amount">
												<option value="1">15 Coins $1.00
										                <option value="2">30 Coins $2.00
										                <option value="3">45 Coins $3.00
										                <option value="4">60 Coins $4.00
										                <option value="5">75 Coins $5.00
										                <option value="10">150 Coins $10.00
										                <option value="15">225 Coins $15.00
										                <option value="20">300 Coins $20.00
										                <option value="25">375 Coins $25.00
										                <option value="30">450 Coins $30.00
												</option>
												</select></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">&nbsp;</td>
												<td width="441" colspan="3">&nbsp;</td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">Game ID:</td>
												<td width="441" colspan="3">
												<input type="hidden" name="ap_description" value="Game ID" size="20">
												<input type="text" name="ap_description" value="<?=$_SESSION['UserID']?>"/>
												</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16"></td>
												<td width="441" height="16" colspan="3"></td>
												</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#00FF00">
												The Coins will be added to Your account within 24 hrs after the payment<br />Thank You for donating the server<br /><br /></font></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="50" height="16" colspan="3">
												<center> <input type="image" name="ap_image" src="https://www.alertpay.com//PayNow/72E27B740A0C427D83DF82D9F811AF35c.gif"/>
												</td>
												</tr>
												</table></form>
											</td>
										</tr>
	
										<tr>
											<td width="432">
											&nbsp;</td>
										</tr>
	
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			