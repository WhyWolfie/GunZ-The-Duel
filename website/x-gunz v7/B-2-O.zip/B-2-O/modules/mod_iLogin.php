<?
if($_SESSION[AID] == "")
{
?>
                        <body onload="FP_preloadImgs(/*url*/'images/btn_login_on.jpg', /*url*/'images/btn_editclan_on.jpg')">

                        <form name="login" method="POST" action="index.php?do=login&header=1">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_login.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
								<tr>
									<td width="5" height="175">&nbsp;</td>
									<td width="156" valign="top" height="175">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="156">
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="83">
												<input name="userid" size="12" class="textLogin" style="float: left" tabindex="1"></td>
												<td width="69" rowspan="3">
												<div align="center">
												<input border="0" src="images/btn_login_off.jpg" id="img812" name="submit" width="57" height="47" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img812',/*url*/'images/btn_login_on.jpg')" type="image"></div></td>
											</tr>
											<tr>
												<td width="83">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="83">
												<input name="pasw" size="12" class="textLogin" style="float: left" type="password" tabindex="2"></td>
											</tr>
											<tr>
												<td width="152" colspan="2">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="152" colspan="2" height="50" valign="middle">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%">
														<tr>
															<td width="2"></td>
															<td width="10">
															<img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img1783"></td>
															<td width="134" align="left">
															<span style="font-size: 7pt">
															<a href="index.php?do=register">New user? Register now</a></span></td>
														</tr>
														<tr>
															<td width="2"></td>
															<td width="10">
															<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
															<td width="134" align="left">
															<span style="font-size: 7pt">
															<a href="http://gunz.b2ogaming.co.in/index.php?do=login&action=resetpwd">Forgot your pass?</a></span></td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
										</table>
									</div>
									<p>&nbsp;</td>
									<td width="8" height="175">&nbsp;</td>
								</tr>

								<tr>
									<td width="169" colspan="3" "><a href="http://click.linksynergy.com/fs-bin/click?id=7q*UlbVbTXQ&offerid=165025.10000015&type=4&subid=0"><IMG alt="Razer. For Gamers. By Gamers." border="0" src="http://www2.razerzone.com/downloads/affiliates/generic/Razer180x150-01.gif"></a><IMG border="0" width="1" height="1" src="http://ad.linksynergy.com/fs-bin/show?id=7q*UlbVbTXQ&bids=165025.10000015&type=4&subid=0"></td>
								</tr>
								<tr>
									<td width="169" colspan="3" ">
									<a href="http://gunz.b2ogaming.co.in/event/May_10_1337POTM/index.html" target="_blank">
									<img border="0" src="images/potmroster.jpg" width="160" height="80"></a>&nbsp;</td>
								</tr>

								</table>
							<input type="hidden" name="submit" value="1">
							</form>

<?
}else{
//And again.
$res = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$d = mssql_fetch_assoc($res);

//No shit?
$res2 = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$numitems = mssql_num_rows($res2);
?>

<body bgcolor="#362F31" onload="FP_preloadImgs(/*url*/'images/af_viewmyitems_hover.jpg', /*url*/'images/af_editaccountinfo_hover.jpg')">

<div align="center">
<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account.jpg" height="36" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
																	<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<font size="2" face="Tahoma">
											Welcome, <?=$_SESSION['UserID']?>!</font></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=addmobile">
											<i><font color="#FF0000">B2O Mobile system.</font></i></a></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=userpanel">
											<b><font color="#FF0000">UserPanel .-<img src="http://www.freeiconsweb.com/Icons/16x16_New_icons/New_icons_24.gif" alt="New" /></font></b></a></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=login&action=logout&header=1">
											Logout?</a></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="center">
												<table border="0" width="171" height="169" style="border-collapse: collapse; background-image: url('images/accountframe.jpg')">
													<tr>
														<td height="29" width="12">&nbsp;</td>
														<td height="29" width="155" colspan="2">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_coin.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['euCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_totalitems.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$numitems?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														<?=$d['GuestPasses']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_viewmyitems.jpg'); background-repeat: no-repeat; background-position-x: left">
														<a href="index.php?do=myaccount&act=viewmyitems">
														<img border="0" src="images/af_viewmyitems.jpg" id="img3" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img3',/*url*/'images/af_viewmyitems_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_editaccountinfo.jpg'); background-repeat: no-repeat; background-position-x: left">
														<a href="index.php?do=myaccount&act=editinfo">
														<img border="0" src="images/af_editaccountinfo.jpg" width="138" height="22" id="img4" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img4',/*url*/'images/af_editaccountinfo_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12">&nbsp;</td>
														<td width="155" colspan="2">
														<p align="center">
														&nbsp;</td>
													</tr>
												</table>
											</div>
											</td>
										</tr>
										</table>
								
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22">&nbsp;</td>
							</tr>
								<tr>
									<td width="169" colspan="3" >&nbsp;</td>
								</tr>
								<tr>
									<td width="169" colspan="3" "><a href="http://click.linksynergy.com/fs-bin/click?id=7q*UlbVbTXQ&offerid=165025.10000015&type=4&subid=0"><IMG alt="Razer. For Gamers. By Gamers." border="0" src="http://www2.razerzone.com/downloads/affiliates/generic/Razer180x150-01.gif"></a><IMG border="0" width="1" height="1" src="http://ad.linksynergy.com/fs-bin/show?id=7q*UlbVbTXQ&bids=165025.10000015&type=4&subid=0">&nbsp;</td>
								</tr>
								<tr>
									<td width="169" colspan="3" ">
									<a href="http://gunz.b2ogaming.co.in/event/May_10_1337POTM/index.html" target="_blank">
									<img border="0" src="images/potmroster.jpg" width="160" height="80"></a>&nbsp;</td>
								</tr>

						</table>

<?
}
?>
