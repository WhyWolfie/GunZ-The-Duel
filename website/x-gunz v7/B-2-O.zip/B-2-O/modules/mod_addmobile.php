<?php
if ($_SESSION['AID'] == ""){
    msgbox("Please Login First","index.php?do=login");
}
if(isset($_POST['submit'])){
$aid = antisql($_SESSION['AID']);
$Name = antisql($_POST['Name']);
$Mobile = antisql($_POST['Mobile']);
if(!is_numeric($Mobile)){
msgbox("Please Enter 10 digit number not a string","index.php?do=addmobile");
exit();
}
$nochk = strlen($Mobile);
if($nochk != 10){
msgbox("Please Enter 10 digit number","index.php?do=addmobile");
exit();
}
$query = mssql_query ("SELECT * FROM Mobile where AID = $aid");
$query2 = mssql_query ("SELECT * FROM Mobile where Mobile = $Mobile");
$num_rows = mssql_num_rows($query);
$num_rows2 = mssql_num_rows($query2);
if($num_rows >= 1){
msgbox("You Have added Mobile number already","index.php?do=addmobile");
exit();
}
if($num_rows2 >= 1){
msgbox("Mobile number already added to database","index.php?do=addmobile");
exit();
}
mssql_query("INSERT INTO Mobile ([AID], [Name], [Mobile], [done])VALUES('$aid', '$Name', '$Mobile', 1)");
mssql_query("UPDATE [Account] SET [mobile] = $Mobile WHERE AID = '$aid'");
$logc = fopen("logs/b2ocontacts.txt", "a+");
fprintf($logc, "%s,%s\r\n", $Name, $Mobile );
fclose($logc);
msgbox("Added correctly","index.php?do=addmobile");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=addmobile"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												<font color="#FFABAF">
												Use this form to Add Your Mobile number<br />What are the Benefits ?<br />You will be able to recieve important announcements through SMS<br /><br /></font></td>
										</tr>
										<tr>
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="214" align="right">
											Name [No ASCII's][EX:Musashi]</td>
											<td width="10">
											&nbsp;</td>
											<td width="214">
											<input type="text" name="Name" size="20"></td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>
										<tr>
											<td width="-14" colspan="3"></td>
										</tr>
										<tr>
											<td width="-14" colspan="3"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											Mobile[10-Digit][Ex-996XXXXXXX]</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="Mobile" size="20"></td>
										</tr>
										<tr>
											<td width="112">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											&nbsp;</td>
										</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<p align="center">
													<font color="#FF0000"><b>
													NOTE: You can Add the MOBILE Number only once, Once added it cannot be edited.</b></font></td>
												</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			