   <?
if($_SESSION['AID'] == ""){
    msgbox("Please login first.","index.php?do=login");
exit();
}
?>
<?php
if (isset($_POST['submit']))
{
    if ($_POST['UserID'] == "")
    {
        msgbox ("Please enter a UserID.","index.php?do=gift");
    }
    
    if ($_POST['B2OCoins'] == "")
    {
        msgbox ("Please enter a B2O Coins .","index.php?do=gift");
    }
    
    $ip = ''.($_SERVER['REMOTE_ADDR']);
    $userid = antisql($_POST['UserID']);
    $b2ocoins = antisql($_POST['B2OCoins']);
    $useridby = $_SESSION['UserID'];

/////////////////////////////////////////////////////
// Insuficent Coins.
$res2 = mssql_query("SELECT euCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
$acc = mssql_fetch_assoc($res2);
$result = $acc['euCoins']-$item['CashPrice'];
if(!is_numeric($b2ocoins)){
msgbox ("Enter the number of B2O Coins","index.php?do=gift");
exit();
}
if($result < $b2ocoins){
msgbox ("Insufficent B2O Coins","index.php?do=gift");
exit();
}

// Insuficent Coins END.
////////////////////////////////////////////////////
$res3 = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");   /*getter AID*/
$aaid = mssql_fetch_assoc($res3);
$abid = antisql($_SESSION['AID']);  /*Current AID*/
$result2 = $aaid['AID'];  /*getter AID*/

if($result2 != $abid){

    $result1 = mssql_query("SELECT euCoins FROM Login WHERE UserID = '$useridby'");  /*s*/
    $result2 = mssql_query("SELECT euCoins FROM Login WHERE UserID = '$userid'");
if (mssql_num_rows($result2) == 0)
{
msgbox ("Error, UserID not found.","index.php?do=gift");
return;
}
    
    $row1 = mssql_fetch_assoc($result1); /*s*/
    $row2 = mssql_fetch_assoc($result2);
    
    $coins1 = $row1['euCoins']; /*s*/
    $coins2 = $row2['euCoins'];
    
    //if ($coins1 < $b2ocoins)
    //{
    //    return;
    //}

    $coins1 = $coins1 - $b2ocoins; /*s*/
    $coins2 = $coins2 + $b2ocoins;

    mssql_query("UPDATE [Login] SET [euCoins] = $coins1 WHERE UserID = '$useridby'");
    mssql_query("UPDATE [Login] SET [euCoins] = $coins2 WHERE UserID = '$userid'");
    mssql_query("INSERT INTO [GiftLog] ([From], [To], [Date], [Coins])VALUES('$useridby', '$userid', GETDATE(), '$b2ocoins')");
  			msgbox("Thank you $useridby, $b2ocoins B2O Coins has been sent to $userid Sucessfully .","index.php?do=gift");

}
if($result2 == $abid){
msgbox ("Omg, You can't Gift to yourself","index.php?do=gift");
exit();
}
}
else gift();

?>
<?php
function gift()
{
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#000000">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
								<form name="reg" method="POST" action="index.php?do=gift"><table border="0" style="border-collapse: collapse" width="454" height="100%">					                        
										<tr>
											<td width="1" rowspan="10">&nbsp;</td>
											<td colspan="3">
											<img border="0" src="images/inf/giftcoins.jpg" width="413" height="17"></td>
											<td width="4">&nbsp;</td>
										</tr>

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>

											<td width="289">
											<font size="1" color="#4D4D4D">The fields marked with an * are required</font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>
											<td width="289">&nbsp;

											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145" valign="middle">
											�<span lang="es">
											User ID to which coins must be gifted<font color="#FF9933">*</font></span></td>

											<td width="289">
											<input type="text" name="UserID" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145">
											�<span lang="es">
											B2O Coins<font color="#FF9933">*</font></span></td>
											<td width="289">
											<input type="text" name="B2OCoins" size="20"></td>
											<td width="8">&nbsp;</td>

										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<p align="center">
													<font color="#FF0000"><b>
													NOTE: If you Gift a coin and then do not want, or is mistaken, we are not responsible<br><br></font><font color="#00FF00"> CLick on Gift button to Send coin now</b></font></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
										<tr>
											<td colspan="3">
											<p align="center">
											<font color="#FFFFFF">
											<input type="submit" value="Gift" name="submit"></font></td>
										</tr>

										<tr>
											<td colspan="3"></td>
										</tr>
										</table>
									</form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

  </form>
<?php
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			