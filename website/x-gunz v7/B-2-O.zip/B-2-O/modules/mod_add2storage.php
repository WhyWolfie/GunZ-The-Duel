<?php
//This file has been edited by Wizkid. All rights reserved.
include "authadmin.php";
//What the fux? No offensive, but a GM should be able to post shit like that.
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $XAID = antisql($_POST['XAID']);
    $item1 = antisql($_POST['item1']);
    $item2 = antisql($_POST['item2']);
    $item3 = antisql($_POST['item3']);
    $item4 = antisql($_POST['item4']);
    $item5 = antisql($_POST['item5']);
    $period = antisql($_POST['period']);
    $rentperiod = $period*24;

    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$XAID', '$item1', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$XAID', '$item2', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$XAID', '$item3', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$XAID', '$item4', GETDATE(), '$rentperiod', 1)");
    mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt)VALUES('$XAID', '$item5', GETDATE(), '$rentperiod', 1)");


    msgbox("Added correctly","index.php?do=add2storage");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=add2storage"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="431" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="112" align="right">
											AID</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="XAID" size="40"></td>
										</tr>

										<tr>
											<td width="112" align="right">
											ITEM 1</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="item1" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											ITEM 2</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="item2" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											ITEM 3</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="item3" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											ITEM 4</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="item4" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											ITEM 5</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="item5" size="40"></td>
										</tr>
										<tr>
											<td width="112" align="right">
											Period</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="period" size="40"></td>
										</tr>
										<tr>
											<td width="112">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			