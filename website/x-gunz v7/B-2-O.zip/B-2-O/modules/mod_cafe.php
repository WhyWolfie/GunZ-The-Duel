<div class="download_box">
	<div class="game_img"><img src="images/ele/download_gunz.jpg" alt="" width="460" height="95"><p>Game Feature : Gun &amp; Sword Fighting | Fast 3-D Action | Quest Modes</p></div>
	<!-- download/link -->
	<div class="down_url">
	<p class="download"><strong>Cafe Locator</strong><br></p>
	<p class="download"><strong>India</strong></p>

	<ul>
	<li>Cafe Name:BASELINE DIGITAL SPORTS<br>
	    Cafe Owner:Vinod Kumar<br>
	    Address:No.42, Mahalakshmi Complex, Mount Joy Road, Hanumanthnagar,<br>
	    LandMark : Next to Bus Stop<br>
	    City:Bangalore<br>
	    Ph : 080-26611770,26616184 / Mobile : 09538452365<br>
	    State:Karnataka<br></li><br>
	<li>Cafe Name: Ashish Cyber Zone<br>
	    Cafe Owner: Haiderali A Asamdi<br>
	    Address: Shop No. 1, Lovely Home Apts., Vaishali Nagar, Nr. Ruby Hospital,     Jogeshwari (W), Mumbai 400102<br>
	    City: Mumbai<br>
	    State: Maharashtra<br></li><br>
	<li>Cafe Name: Care Systems<br>
	    Cafe Owner: Mr.Boopathy<br>
	    Address: Address: No 18,1st Cross Street, Near Velan Theatre, Nanganallur, 600061 <br>
	    City: Chennai <br>
	    State: Tamil Nadu <br></li><br>
	<li>Cafe Name: Sai Krupa Cyber Cafe<br>
	    Cafe Owner: Sanjay kalwar<br>
	    Address: Plot No B-14/32 Sai Krupa Row House Sector-12 Kharghar-410210<br>
	    City: Mumbai<br>
	    State: Maharashtra<br></li><br>
	<li>Cafe Name:------------<br>
	    Cafe Owner:------------<br>
	    Address:------------<br>
	    City: ------------<br>
	    State: ------------<br></li><br>
	<li>Cafe Name:------------<br>
	    Cafe Owner:------------<br>
	    Address:------------<br>
	    City: ------------<br>
	    State: ------------<br></li><br>
	</ul>&nbsp;
<br>
Want Your cafe to be listed Out here ?<br>
Please Send the Following Details to <strong>info.b2ogaming@gmail.com</strong><br><br>
<strong>In Addition too the cafe must have the b2ogunz client installed in the cafe</strong><br><br>
Subject: Cafe Partnership<br><br>
Cafe Name:[*]<br>
Cafe Owner:<br>
Address:[*]<br>
City:[*]<br>
State:[*]<br><br>
Also attach a photo of your cafe<br><br><br><br>
Fields marked with [*] are required<br>


	</div>
	<!-- //download/link -->
</div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			