<?php
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Account WHERE UGradeID = 255 or UGradeID = 254 or UGradeID = 252") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 500; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Account where AID not in (select top $max AID from Account order by AID asc) and UGradeID = 255 or UGradeID = 254 or UGradeID = 252 order by AID asc");
echo "<p>"; 
echo " --Page $pagenum of $last-- <p>";
if ($pagenum == 1) { }
else
{
echo " <a href='index.php?do=adminlist&pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='index.php?do=adminlist&pagenum=$previous'> <-Previous</a> ";
}
echo " ---- ";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=adminlist&pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='index.php?do=adminlist&pagenum=$last'>Last ->></a> ";
}

?>
<table width="442" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Account List</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="19" scope="row"><span class="style28"><strong>AID</strong></span></th>
    <td width="61"><span class="style28"><strong>UserID</strong></span></td>
    <td width="54"><span class="style28"><strong>UGradeID</strong></span></td>
    <td width="61"><span class="style28"><strong>E-Mail</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
    <td><span class="style29"><?php echo "$row[6]";?></span></td>

</tr>
  <?
  $i++;
  }
   ?>
</table></div>
</body>

</html>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			