<?
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}else{

	if(isset($_POST['submit'])){
   		$cuenta = antisql($_POST['cuenta']);
    	$coins = antisql($_POST['coins']);   
    	$r=mssql_query("SELECT * FROM Login WHERE UserID= '$cuenta'");
		if(mssql_num_rows($r) == 0){
			msgbox("The Account $id dont exist!!!","index.php?do=changecoin");
		}else{
            $s = mssql_query("SELECT * FROM Login WHERE UserID= '$cuenta'");
            $data = mssql_fetch_assoc($s);
			$UserAID = $data['AID'];
			mssql_query("UPDATE Login SET euCoins = '$coins' WHERE AID = '$UserAID'");
  			msgbox("Coins Added!!!","index.php?do=changecoin");
		}
		}
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#000000">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=changecoin"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="1" rowspan="10">&nbsp;</td>
											<td colspan="3">
											<img border="0" src="images/inf/addshopitem.jpg" width="413" height="17"></td>
											<td width="4">&nbsp;</td>
										</tr>

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>

										<tr>
											<td width="204">
											  <p align="right">
                                              <font color="#FFFFFF">Account</font></td>
											<td width="5"><font color="#FFFFFF">&nbsp;
                                            </font>											</td>
											<td width="218">
                                            <font color="#FFFFFF"><input name="cuenta" type="text" id="cuenta" size="20"></font></td>
										</tr>

										<tr>
											<td width="204" align="right" valign="top">
                                            <font color="#FFFFFF">Coins</font></td>
											<td width="5">&nbsp;</td>
										  <td width="218"><font color="#FFFFFF"><input name="coins" type="text" id="coins" size="20"></font></td>
										</tr>


										<tr>
											<td colspan="3">
											<p align="center">
											<font color="#FFFFFF">
											<input type="submit" value="Add Coins" name="submit"></font></td>
										</tr>

										<tr>
											<td colspan="3"></td>
										</tr>
										</table>
									</form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			