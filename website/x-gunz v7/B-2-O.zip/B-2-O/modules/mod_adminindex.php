<?
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}

?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="clanranking.jpg" height="31" width="195" style="background-image: url('images/adminpanel.jpg')">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="additem" checked name="do">Add Item to Shop<br>
										<input type="radio" name="do" value="addindexcontent">Add content to Index<br>
										<input type="radio" name="do" value="accountlist">Account List<br>
										<input type="radio" name="do" value="adminlist">Admin List<br>
										<input type="radio" name="do" value="banlist">Banned List<br>
										<input type="radio" name="do" value="normallist">Normal List<br>
										<input type="radio" name="do" value="Silencelist">Silence List<br>
                                                                                <input type="radio" name="do" value="giftlog">Gift List<br>
                                                                                <input type="radio" name="do" value="charnamelog">Charname change List<br>
										<input type="radio" name="do" value="coinslog">Coin's Logs<br>
										<input type="radio" name="do" value="addlegender">Add Legender<br>
										<input type="radio" name="do" value="itemdb">Item Database<br>
										<input type="radio" name="do" value="additem2db">Add item 2 Database<br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Go" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22"></td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							