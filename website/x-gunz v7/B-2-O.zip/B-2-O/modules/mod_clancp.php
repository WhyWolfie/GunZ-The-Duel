<?
if ($_GET['expand'] == 1){
?>
				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('images/subbar.png'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=clancp&sub=delete&expand=1">
					<img border="0" src="images/subbar/deleteclan.jpg" width="128" height="13"></a><a href="index.php?do=clancp&sub=emblem&expand=1"><img border="0" src="images/subbar/emblem.jpg" width="110" height="13"></a><a href="index.php?do=clancp&sub=member&expand=1"><img border="0" src="images/subbar/clanmembers.jpg" width="93" height="13"></a></td>
				</tr>

<?  }
  if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "delete";
        Showdelete();
    break;
    case "emblem";
        Showemblem();
    break;
    case "member";
        Showmember();
    break;
}
}


if(!function_exists("Showdelete")){
function Showdelete(){
  
if($_SESSION['AID'] == ""){
    msgbox("Please login first.","index.php?do=login");
exit();
}else{
if(isset($_POST['submit'])){
		$ClanName = antisql($_POST['ClanName']);
		$DelCLan = antisql($_POST['DelCLan']);
    $query1 = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$ClanName'");
		$result1 = mssql_fetch_assoc($query1);
		$query2 = mssql_query("SELECT * FROM Clan WHERE CLID = '$ClanName' AND Name != NULL");
		$result2 = mssql_fetch_assoc($query2);
    		if( $result1['Grade'] != 1 ){
    		msgbox("You Are Not Clan Master.","index.php?do=clancp&sub=delete&expand=1");
				exit();
				}
				else
				{
	if ($DelCLan != 'YES') {
msgbox("Wrong Input","index.php?do=clancp&sub=delete&expand=1"); 
              }else{
mssql_query("DELETE FROM ClanMember WHERE CLID = '$ClanName'");
mssql_query("UPDATE Clan SET Name = NULL, DeleteFlag = 1, DeleteName = '".$result2['Name']."' WHERE CLID = '$ClanName'");
msgbox("Clan Deleted Sucessfully.","index.php?do=clancp&sub=delete&expand=1");            	
            }}}
                }
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

        <body bgcolor="#000000">

                                        <div align="center">
                                                <table border="0" width="456" style="border-collapse: collapse">
                                                        <tr>
                                                                <td background="images/cont_up.jpg">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                                <td background="images/cont_bg.jpg">
                                                                <div align="center">
                                                                        <form method="POST" action="index.php?do=clancp&sub=delete&expand=1"><table border="0" style="border-collapse: collapse" width="454" height="100%">
                                                                                <tr>
                                                                                        <td width="1" rowspan="10">&nbsp;</td>
                                                                                        <td colspan="3">
                                                                                        <img border="0" src="images/inf/delclan.jpg" width="413" height="17"></td>
                                                                                        <td width="4">&nbsp;</td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3">&nbsp;                                                                                        </td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204">
                                                                                          <p align="right">
                                              <font color="#FFFFFF">Clan Name</font></td>
                                                                                        <td width="5"><font color="#FFFFFF">&nbsp;
                                            </font>                                                                                        </td>
                                                                                        <td width="218">
                                            <font color="#FFFFFF"><select name="ClanName">
    <?php
     $res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
		$a=mssql_fetch_assoc($res9);
		$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
		$d=mssql_fetch_assoc($res);
		$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query5 = mssql_query("SELECT Login.AID, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.AID = '".$_SESSION['AID']."' and ClanMember.Grade = '1' ");
if (mssql_num_rows($query5) >= '1'){
	for($i='';$i < @mssql_num_rows($query5);++$i){
							$result5 = @mssql_fetch_row($query5);
							$ClanName = $result5[4];
							echo '<option value="'.$result5[4].'">'.$result5[3].'</option>' ;
							}
}else{
								echo '<option value="">No Clans Owned</option>' ;
							}
    ?>
</select></font></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204" align="right" valign="top">
                                            <font color="#FFFFFF">Type "YES" to Confirm</font></td>
                                                                                        <td width="5">&nbsp;</td>
                                                                                  <td width="218"><font color="#FFFFFF"><input name="DelCLan" type="text" id="DelCLan" size="20"></font></td>
                                                                                </tr>
                                                                                                                                                                               <tr>
                                                                                                        <td width="200" valign="top">&nbsp;</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">&nbsp;</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td colspan="3"><p align="center"><font color="#FF0000"><b><center>NOTE: If you Delete Clan and then do not want, or is mistaken, we are not responsible</b></center></font></td>
                                                                                                </tr>
                                                                                		<tr>
                                                                                        		<td colspan="3">
                                                                                        		<p align="center">
                                                                                        		<font color="#FFFFFF">
                                                                                        		<input type="submit" value="Delete Clan" name="submit"></font></td>
                                                                                		</tr>
                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>
                                                                                </table>
                                                                        </form>
                                                                </div>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td background="images/cont_top.jpg" height="27">&nbsp;</td>
                                                        </tr>
                                                </table>
                                        </div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
<?
}}
if(!function_exists("Showemblem")){
function Showemblem(){
if($_SESSION['AID'] == ""){
    msgbox("Please login first.","index.php?do=login");
exit();
}else{
if(isset($_POST['submit'])){ 				  
	$emblem = antisql($_POST['uploaded']) ;
	$CLID = antisql($_POST['clan']) ;
$target = "clanemblem/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$target2 = basename( $_FILES['uploaded']['name']) ;
$target3 = $target2 . basename( $_FILES['uploaded']['name']) ;
$ok=1;
    		if( $CLID == "" ){
    		msgbox("You Are Not Clan Master.","index.php?do=clancp&sub=emblem&expand=1");
				exit();
				}else{
						if (!($_FILES['uploaded']['size']  > '9500'))
								{
									//echo "Your file is too large.<br>";
									$ok=1;
													if(($_FILES['uploaded']['type'] == "image/jpeg"))
																{ 
																	$ok=1;
																																}
													if(($_FILES['uploaded']['type'] == "image/GIF"))
																{ 
																	$ok=1;
																																	}
													if(($_FILES['uploaded']['type'] == "image/PNG"))
																{ 
																$ok=1;
																}
								}
								else 
								{ 
									$ok=0;
								}
					if ($ok==0)
								{
									msgbox("Sorry your file was not uploaded, Please check the file size or file type.","index.php?do=clancp&sub=emblem&expand=1");
								}
								else
								{
										if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
														{
																mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE CLID = '$CLID'");
																mssql_query ("UPDATE Clan SET EmblemUrl = '/".$target2."' WHERE CLID = '$CLID'");
																msgbox("Clan Emblem Added Sucessfully, How ever it may take some time for the clan emblem to be displayed in the game","index.php?do=clancp&sub=emblem&expand=1");
														}
														else
														{
																							msgbox("Sorry, there was a problem uploading your file.","index.php?do=clancp&sub=emblem&expand=1");
														}
								}}
};
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

        <body bgcolor="#000000">

                                        <div align="center">
                                                <table border="0" width="456" style="border-collapse: collapse">
                                                        <tr>
                                                                <td background="images/cont_up.jpg">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                                <td background="images/cont_bg.jpg">
                                                                <div align="center">
                                                                        <form method="POST" enctype="multipart/form-data" action="index.php?do=clancp&sub=emblem&expand=1"><table border="0" style="border-collapse: collapse" width="454" height="100%">
                                                                                <tr>
                                                                                        <td width="1" rowspan="10">&nbsp;</td>
                                                                                        <td colspan="3">
                                                                                        <img border="0" src="images/inf/emblem.jpg" width="413" height="17"></td>
                                                                                        <td width="4">&nbsp;</td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3">&nbsp;                                                                                        </td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204">
                                                                                          <p align="right">
                                              <font color="#FFFFFF">Clan Name</font></td>
                                                                                        <td width="5"><font color="#FFFFFF">&nbsp;
                                            </font>                                                                                        </td>
                                                                                        <td width="218">
                                            <font color="#FFFFFF"><select name="clan">
    <?php
     $res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
		$a=mssql_fetch_assoc($res9);
		$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
		$d=mssql_fetch_assoc($res);
		$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query5 = mssql_query("SELECT Login.AID, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.AID = '".$_SESSION['AID']."' and ClanMember.Grade = '1' ");
if (mssql_num_rows($query5) >= '1'){
	for($i='';$i < @mssql_num_rows($query5);++$i){
							$result5 = @mssql_fetch_row($query5);
							$ClanName = $result5[4];
							echo '<option value="'.$result5[4].'">'.$result5[3].'</option>' ;
							}
}else{
								echo '<option value="">No Clans Owned</option>' ;
							}
    ?>
</select></font></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204" align="right" valign="top">
                                            <font color="#FFFFFF">Select Clan Emblem</font></td>
                                                                                        <td width="5">&nbsp;</td>
                                                                                  <td width="218"><font color="#FFFFFF"><input name="uploaded" type="file" /></font></td>
                                                                                </tr>
                                                                                                                                                                               <tr>
                                                                                                        <td width="200" valign="top">&nbsp;</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">&nbsp;</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td colspan="3"><p align="center"><font color="#FF0000"><b><center>NOTE: Do Not add abusive/naked emblems, It may lead to clan Disband</b></center></font></td>
                                                                                                </tr>
                                                                                		<tr>
                                                                                        		<td colspan="3">
                                                                                        		<p align="center">
                                                                                        		<font color="#FFFFFF">
                                                                                        		<input type="submit" value="Upload Emblem" name="submit"></font></td>
                                                                                		</tr>
                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>
                                                                                </table>
                                                                        </form>
                                                                </div>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td background="images/cont_top.jpg" height="27">&nbsp;</td>
                                                        </tr>
                                                </table>
                                        </div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
<?
}}}
if(!function_exists("Showmember")){
function Showmember(){
if($_SESSION['AID'] == ""){
    msgbox("Please login first.","index.php?do=login");
exit();
}else{
	 	if (isset($_POST['submit']))
{
	$CLID = antisql($_POST['ClanName2']);
	 if($CLID == ""){
$query12 = mssql_query("SELECT TOP 1000 ch.CID, ch.AID, ch.Name, ch.Level, ch.XP, ch.BP, ch.KillCount, ch.DeathCount FROM Character ch INNER JOIN ClanMember cm
                            ON ch.CID = cm.CID WHERE cm.CLID = '0'");
                          }else{
    $query12 = mssql_query("SELECT TOP 1000 ch.CID, ch.AID, ch.Name, ch.Level, ch.XP, ch.BP, ch.KillCount, ch.DeathCount FROM Character ch INNER JOIN ClanMember cm
                            ON ch.CID = cm.CID WHERE cm.CLID = '$CLID'");
                  
    $count = 0;
    
  }
}

    ?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">
<form method="POST" action="index.php?do=clancp&sub=member&expand=1">
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/clanmembers.jpg"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
																				<tr>
											<td width="449" colspan="2">
											<select size="1" name="ClanName2" onchange="Submit()">											
<?php
     $res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
		$a=mssql_fetch_assoc($res9);
		$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
		$d=mssql_fetch_assoc($res);
		$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query5 = mssql_query("SELECT Login.AID, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.AID = '".$_SESSION['AID']."' ");
if (mssql_num_rows($query5) >= '1'){
	for($i='';$i < @mssql_num_rows($query5);++$i){
							$result5 = @mssql_fetch_row($query5);
							$ClanName = $result5[4];
							echo '<option value="'.$result5[4].'">'.$result5[3].'</option>' ;
							}
}else{
								echo '<option value="">No Clans Owned</option>' ;
							}
 
    ?>
											</select></form><input type="submit" value="Go" name="submit">
											<?php
												 	if (!isset($_POST['submit']))
{        
                                                  
exit();
}
?>
																							</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/rankinglist.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/rankinlist_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                                <?

                                                                    while($r = mssql_fetch_assoc($query12)){
                                                                    $count++;
                                                                    ?>
																	<tr>
																		<td width="45">
																		<p align="center">
																		<?=$count?></td>
																		<td width="88">
																		<p align="center">
																		<b>
																		<span class="guild_name">
																		<?=$r['Name']?></span></b>
																		</td>
																		<td width="33">
																		<p align="center">
																		<?=$r['Level']?></td>
																		<td width="127">
																		<p align="center">
																		<?=number_format($r['XP'],0,'','.');?></td>
																		<td width="114">
																		<p align="center">
																		<span style="font-size: 7pt">
																		<?=$r['KillCount']?>/<?=$r['DeathCount']?>
																		(80%)</span></td>
																	</tr> <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>

			
    <?
} }}