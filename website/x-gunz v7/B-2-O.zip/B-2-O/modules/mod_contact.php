<?
if (isset($_POST['submit'])){
$asunto = antisql($_POST['asunto']);
$email = antisql($_POST['email']);
$texto = antisql($_POST['text']);
if (!$asunto == "" or $email == "" or $texto == ""){
        $cabeceras = "Content-type: text/html\r\n";
        $mensaje = "Posted on: ".date("j F, Y")."<br>_________________<br>".$texto."<br>_________________<br><br><b>Sender: $email</b>";
        if (@mail("info@b2ogunz.co.in",$asunto,$mensaje,$cabeceras)) {
            $error = "<b>The message was sent. </b> </br> Thank you for contacting us, we will respond as soon as possible";
        }else{
            $error = "<b>Failed to send message</b>";
        }
}else{
    $error = "You must fill in all fields";
}}

?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="348">
											<img border="0" src="images/inf/contactstaff.jpg" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">
											&nbsp;</td>
										</tr>
	
										<tr>
											<td width="432">
											<form method="POST" action="index.php?do=contact"><table border="0" style="border-collapse: collapse" width="100%" id="table13">
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
											</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												Use this form to contact the Staff of GunZone</td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16">
												Subject:</td>
												<td width="441" height="16" colspan="3">
												<select size="1" name="asunto">
												<option value="Problem with the Web">Website Problem
												</option>
												<option value="Bug">Bug
												</option>
												<option value="Suggestion">Suggestion
												</option>
												<option value="Other...">Other...
												</option>
												</select></td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">&nbsp;</td>
												<td width="441" colspan="3">&nbsp;</td>
												</tr>
											<tr>
												<td width="16">&nbsp;</td>
												<td width="89">Your email:</td>
												<td width="441" colspan="3">
												<input type="text" name="email" size="20"></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16"></td>
												<td width="441" height="16" colspan="3"></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16" valign="top">
												Content:</td>
												<td width="441" height="16" colspan="3">
												<textarea rows="13" name="text" cols="40"></textarea></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="89" height="16"></td>
												<td width="100" height="16"></td>
												<td width="147" height="16"></td>
												<td width="190" height="16"></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="526" height="16" colspan="4">
												<font face="Tahoma" size="2" color="#FF0000">
												<? echo @$error ?></font></td>
												</tr>
											<tr>
												<td width="16" height="16"></td>
												<td width="526" height="16" colspan="4">
												<p align="center">
												<input type="submit" value="Send E-Mail" name="submit"></td>
												</tr>
										</table></form>
											</td>
										</tr>
	
										<tr>
											<td width="432">
											&nbsp;</td>
										</tr>
	
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			