<?php
//This file has been edited by Wizkid. All rights reserved.
include "authadmin.php";
//What the fux? No offensive, but a GM should be able to post shit like that.
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $Character = antisql($_POST['Character']);
    $Donated = antisql($_POST['Donated']);
   
	//Once again. Sessions spoofers are FTW.
    $user = antisql($_SESSION['UserID']);
    mssql_query("INSERT INTO DonationLog ([Character], [Donated], [paidon])VALUES('$Character', '$Donated', GETDATE())");
    msgbox("Added correctly","index.php?do=addlegender");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=addlegender"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="431" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="112" align="right">
											Character Name</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="Character" size="40"></td>
										</tr>

										<tr>
											<td width="112" align="right">
											Donated in $ [numeric value]</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="Donated" size="40"></td>
										</tr>
										<tr>
											<td width="112">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			