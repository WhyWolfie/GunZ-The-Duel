<?php
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
$query = mssql_query ("SELECT * FROM charnamelog") or die(mssql_error());

?>
<table width="442" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Char name change List</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="19" scope="row"><span class="style28"><strong>OldCharname</strong></span></th>
    <td width="61"><span class="style28"><strong>NewCharName</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
</tr>
  <?
  $i++;
  }
   ?>
</table></div>
</body>

</html>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			