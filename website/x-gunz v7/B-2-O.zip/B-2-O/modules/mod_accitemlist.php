<?php

$query = mssql_query("SELECT * FROM AccountItem WHERE itemID = 521533");

?>
<table width="442" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Account List</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="19" scope="row"><span class="style28"><strong>AID</strong></span></th>
    <td width="61"><span class="style28"><strong>itemID</strong></span></td>
    <td width="54"><span class="style28"><strong>rent date</strong></span></td>
    <td width="61"><span class="style28"><strong>period</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$row[0]";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
    <td><span class="style28"><?php echo "$row[3]";?></span></td>
    <td><span class="style29"><?php echo "$row[4]";?></span></td>

</tr>
  <?
  $i++;
  }
   ?>
</table></div>
</body>

</html>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			