<?
    $res = mssql_query("SELECT TOP 50 * FROM DonationLog ORDER BY Donated DESC");
    $count = 0;
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Legend Donators List</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#232122">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											 <? while($r = mssql_fetch_assoc($res)){
                          $count++;   ?>
											<tr>
																		<td width="45">
																		<p align="center">
																		<?=$count?></td>
																		<td width="90">
																		<p align="center">
																		<b><?=$r['Character']?></b></td>
											</tr><?}?>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">
												&nbsp;<p align="center">The Users who donate more than 20$'s will be displayed in this page</td>
												<td width="13" >
												&nbsp;</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
						</div>
						</td>
					</tr>
				</table>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			

    <?
  