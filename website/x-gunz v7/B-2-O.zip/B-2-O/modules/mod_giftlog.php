<?php
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
$query = mssql_query ("SELECT * FROM GiftLog") or die(mssql_error());


if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM GiftLog") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 100; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from GiftLog where ID not in (select top $max ID from GiftLog order by ID asc) order by ID asc");
echo "<p>"; 
echo " --Page $pagenum of $last-- <p>";
if ($pagenum == 1) { }
else
{
echo " <a href='index.php?do=giftlog&pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='index.php?do=giftlog&pagenum=$previous'> <-Previous</a> ";
}
echo " ---- ";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=giftlog&pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='index.php?do=giftlog&pagenum=$last'>Last ->></a> ";
}


?>
<table width="500" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Gift function logs</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="71" scope="row"><span class="style28"><strong>From</strong></span></th>
    <td width="81"><span class="style28"><strong>To</strong></span></td>
   <td width="61"><span class="style28"><strong>Coins</strong></span></td>
   <td width="300"><span class="style28"><strong>Date</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
        <td><span class="style28"><?php echo "$row[3]";?></span></td>
</tr>
  <?
  $i++;
  }
   ?>
</table></div>
</body>

</html>
			