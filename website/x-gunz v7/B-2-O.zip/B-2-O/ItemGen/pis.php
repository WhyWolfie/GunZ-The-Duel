<?php 
ini_set("magic_quotes_gpc", "0"); 
set_magic_quotes_runtime(0);
$itemid = $_POST["itemid"];
$itemname = $_POST["itemname"];
$quote='"';
$weight= $_POST["weight"];
$lvl = $_POST["lvl"];
$bounty=$_POST["bounty"];
$delay = $_POST["delay"];
$damage = $_POST["dmg"];
$range=$_POST["range"];
$hp=$_POST["hp"];
$ap=$_POST["ap"];
$maxwt=$_POST["maxwt"];
$sf=$_POST["sf"];
$fr=$_POST["fr"];
$cr=$_POST["cr"];
$lr=$_POST["lr"];
$desc=$_POST["desc"];

$mags=$_POST["mags"];
$maxb=$_POST["maxb"];
$reloadt=$_POST["reloadt"];
?>
<!DOCTYPE html>
<html>
<head>
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="index,follow" name="robots" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="icon.png" rel="apple-touch-icon" />
<meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" />
<script src="javascript/functions.js" type="text/javascript"></script>
<title>Thank You!</title>
<link media="screen" href="css/style.css" type= "text/css" rel="stylesheet" />
 <link media="screen" href="comments.css" type= "text/css" rel="stylesheet" />
</head>

<body>
<div id="topbar">
	<div id="title">Finished!</div>
</div>
	<div id="leftnav">
		<a href="menu.html">Back</a></div>
</div>
<div id="content">
<?php
if (empty($itemid) or empty($itemname))
{
	if (empty($itemid) && empty($itemname))
	{
	echo "<ul class=\"pageitem\">";
	echo "<li class=\"textbox\">";
	echo "you didn't fill out the item id/itemname.";
	echo "</li>";
	echo "</ul>";
	}
	elseif (empty($itemid))
	{
	echo "<ul class=\"pageitem\">";
	echo "<li class=\"textbox\">";
	echo "tou didn't fill out the item id.";
	echo "</li>";
	echo "</ul>";
	} 
	elseif (empty($itemname))
	{
	echo "<ul class=\"pageitem\">";
	echo "<li class=\"textbox\">";
	echo "no item name..";
	echo "</li>";
	echo "</ul>";
	} else {
	echo "<ul class=\"pageitem\">";
	echo "<li class=\"textbox\">";
	echo "Sorry, there was an internal system error, your comment was not posted.";
	echo "</li>";
	echo "</ul>";
	}
} else {
include 'replace.php';
$itemid = strip_tags($itemid, '<b><i><u></b></i></u><p></p>');
$itemname = strip_tags($itemname, '<b><i><u></b></i></u><p></p>');
$itemname = filterBadWords($itemname);
$itemid = filterBadWords($itemid);
$myFile = "itemcode.txt";
$fh = fopen($myFile, 'a') or die("<ul class='pageitem'><li class='textbox>Sorry, there was an internal system error, your comment was not posted.</li></ul>");
fwrite($fh, "	<ITEM id=$quote");
fwrite($fh, $itemid);
fwrite($fh, "$quote name=$quote");
fwrite($fh, $itemname);
fwrite($fh, "$quote");
fwrite($fh, " mesh_name=$quote");
fwrite($fh, "pistol01");
fwrite($fh, "$quote");
fwrite($fh, " totalpoint=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " type=$quote");
fwrite($fh, "range");
fwrite($fh, "$quote");
fwrite($fh, " res_sex=$quote");
fwrite($fh, "a");
fwrite($fh, "$quote");
fwrite($fh, " res_level=$quote");
fwrite($fh, "$lvl");
fwrite($fh, "$quote");
fwrite($fh, " slot=$quote");
fwrite($fh, "range");
fwrite($fh, "$quote");
fwrite($fh, " weapon=$quote");
fwrite($fh, "pistol");
fwrite($fh, "$quote");
fwrite($fh, " weight=$quote");
fwrite($fh, "$weight");
fwrite($fh, "$quote");
fwrite($fh, " bt_price=$quote");
fwrite($fh, "$bounty");
fwrite($fh, "$quote");
fwrite($fh, " delay=$quote");
fwrite($fh, "$delay");
fwrite($fh, "$quote");
fwrite($fh, " damage=$quote");
fwrite($fh, "$damage");
fwrite($fh, "$quote");
fwrite($fh, " magazine=$quote");
fwrite($fh, "$mags");
fwrite($fh, "$quote");
fwrite($fh, " maxbullet=$quote");
fwrite($fh, "$maxb");
fwrite($fh, "$quote");
fwrite($fh, " reloadtime=$quote");
fwrite($fh, "$reloadt");
fwrite($fh, "$quote");
fwrite($fh, " range=$quote");
fwrite($fh, "$range");
fwrite($fh, "$quote");
fwrite($fh, " ctrl_ability=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " magazine=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " reloadtime=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " slug_output=$quote");
fwrite($fh, "true");
fwrite($fh, "$quote");
fwrite($fh, " limitspeed=$quote");
fwrite($fh, "90");
fwrite($fh, "$quote");
fwrite($fh, " limitwall=$quote");
fwrite($fh, "1");
fwrite($fh, "$quote");
fwrite($fh, " gadget_id=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " hp=$quote");
fwrite($fh, "$hp");
fwrite($fh, "$quote");
fwrite($fh, " ap=$quote");
fwrite($fh, "$ap");
fwrite($fh, "$quote");
fwrite($fh, " maxwt=$quote");
fwrite($fh, "$maxwt");
fwrite($fh, "$quote");
fwrite($fh, " sf=$quote");
fwrite($fh, "$sf");
fwrite($fh, "$quote");
fwrite($fh, " fr=$quote");
fwrite($fh, "$fr");
fwrite($fh, "$quote");
fwrite($fh, " cr=$quote");
fwrite($fh, "$cr");
fwrite($fh, "$quote");
fwrite($fh, " page ranking=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " lr=$quote");
fwrite($fh, "$lr");
fwrite($fh, "$quote");
fwrite($fh, " color=$quote");
fwrite($fh, "#FFFFFFFF");
fwrite($fh, "$quote");
fwrite($fh, " image_id=$quote");
fwrite($fh, "1");
fwrite($fh, "$quote");
fwrite($fh, " bullet_image_id=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " magazine_image_id=$quote");
fwrite($fh, "0");
fwrite($fh, "$quote");
fwrite($fh, " snd_reload=$quote");
fwrite($fh, "we_pistol_reload");
fwrite($fh, "$quote");
fwrite($fh, " snd_fire=$quote");
fwrite($fh, "we_pistol_fire");
fwrite($fh, "$quote");
fwrite($fh, " snd_dryfire=$quote");
fwrite($fh, "357magrevolver_dryfire");
fwrite($fh, "$quote");
fwrite($fh, " desc=$quote");
fwrite($fh, "$desc");
fwrite($fh, "$quote");
fwrite($fh, " effect_id=$quote");
fwrite($fh, "3");
fwrite($fh, "$quote");
fwrite($fh, " />");
fclose($fh);
echo "<ul class=\"pageitem\">";
echo "<li class=\"textbox\">";
echo "your code has been created!";
echo " click to view:"; 
echo "</li>";
echo "</ul>";
}
?>
<ul class="pageitem">
<p></P>
<a href="itemcode.txt">View the codes!</a>
<p></p>
<li></li>
</ul>
</div>
</body>
</html>

