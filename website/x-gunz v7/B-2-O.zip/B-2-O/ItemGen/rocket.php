<?php
ini_set("magic_quotes_gpc", "0"); 
set_magic_quotes_runtime(0);
?>
<!DOCTYPE html>
<html>
<head>
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="index,follow" name="robots" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="icon.png" rel="apple-touch-icon" />
<meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" />
<script src="javascript/functions.js" type="text/javascript"></script>
<title>ItemGen</title>
<link media="screen" href="css/style.css" type= "text/css" rel="stylesheet" />
 <link media="screen" href="comments.css" type= "text/css" rel="stylesheet" />
</head>
<body>
<div id="topbar">
	<div id="leftnav">
		<a href="range.php">Back</a></div>
</div>
	<div id="title">
		Rocket Launcher Gen</div>
<div id="content">
<?php

?>
<form action="roc.php" method="post">
<ul class="pageitem">
<li class="bigfield"><input placeholder="Item #" type="text" name="itemid"/></li>
<li class="bigfield"><input placeholder="Item Name" type="text" name="itemname" /></li>
<li class="bigfield"><input placeholder="Required lvl" type="text" name="lvl" /></li>
<li class="bigfield"><input placeholder="weight" type="text" name="weight" /></li>
<li class="bigfield"><input placeholder="hp" type="text" name="hp" /></li>
<li class="bigfield"><input placeholder="ap" type="text" name="ap" /></li>
<li class="bigfield"><input placeholder="maxwt" type="text" name="maxwt" /></li>

<li class="bigfield"><input placeholder="Magazines" type="text" name="mags" /></li>
<li class="bigfield"><input placeholder="Max bullet" type="text" name="maxb" /></li>
<li class="bigfield"><input placeholder="reload time; default 10" type="text" name="reloadt" /></li>


<li class="bigfield"><input placeholder="sf; default: 0" type="text" name="sf" /></li>
<li class="bigfield"><input placeholder="fr; default: 0" type="text" name="fr" /></li>
<li class="bigfield"><input placeholder="cr; default: 0" type="text" name="cr" /></li>
<li class="bigfield"><input placeholder="lr; defaukt: 0" type="text" name="lr" /></li>
<li class="bigfield"><input placeholder="item description" type="text" name="desc" /></li>
<li class="bigfield"><input placeholder="bounty; cost" type="text" name="bounty" /></li>
<li class="bigfield"><input placeholder="weapon damage" type="text" name="dmg" /></li>
<li></li>
<li class="button"><input name="name" type="submit" value="Generate!"/></li>
</ul>
</form>
</div>
</body>

</html>
