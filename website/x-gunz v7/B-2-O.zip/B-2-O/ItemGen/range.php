<?php
ini_set("magic_quotes_gpc", "0"); 
set_magic_quotes_runtime(0);
?>
<!DOCTYPE html>
<html>
<head>
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="index,follow" name="robots" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="icon.png" rel="apple-touch-icon" />
<meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" />
<script src="javascript/functions.js" type="text/javascript"></script>
<title>ItemGen</title>
<link media="screen" href="css/style.css" type= "text/css" rel="stylesheet" />
 <link media="screen" href="comments.css" type= "text/css" rel="stylesheet" />
</head>
<body>
<div id="topbar">
	<div id="leftnav">
		<a href="index.php">Back</a></div>
</div>
<div id="tributton">
	<div class="links">
		<a id="pressed" href="#">Item Gen</a><a href="shop.php">Shop Gen</a><a href="clothes.php">Clothes Gen</a></div></div>
	<div id="title">
		Item Generator</div>
<div id="content">
<?php


?>
<ul class="pageitem">
<li class="menu"><a href="sg.php">
<img alt="list" src="thumbs/shotgun.png" /><span class="name">Shotgun's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="machine.php">
<img alt="list" src="thumbs/machine.jpg" /><span class="name">Machine Gun's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="pistol.php">
<img alt="list" src="thumbs/pistol.jpg" /><span class="name">Pistols's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="pistol2.php">
<img alt="list" src="thumbs/pistol.jpg" /><span class="name">Dbl Pistols's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="rocket.php">
<img alt="list" src="thumbs/rocket.png" /><span class="name">Rocket Launcher's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="smg.php">
<img alt="list" src="thumbs/smg.png" /><span class="name">SMG's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="smg2.php">
<img alt="list" src="thumbs/smg.png" /><span class="name">Dbl SMG's</span><span class="arrow"></span></a></li>
</ul>
</form>
</div>
</body>

</html>
