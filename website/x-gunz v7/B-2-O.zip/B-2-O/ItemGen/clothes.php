<?php
ini_set("magic_quotes_gpc", "0"); 
set_magic_quotes_runtime(0);
?>
<!DOCTYPE html>
<html>
<head>
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="index,follow" name="robots" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="icon.png" rel="apple-touch-icon" />
<meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" />
<script src="javascript/functions.js" type="text/javascript"></script>
<title>ItemGen</title>
<link media="screen" href="css/style.css" type= "text/css" rel="stylesheet" />
 <link media="screen" href="comments.css" type= "text/css" rel="stylesheet" />
</head>
<body>
<div id="topbar">
	<div id="leftnav">
		<a href="index.php">Back</a></div>
</div>
<div id="tributton">
	<div class="links">
		<a href="index.php">Item Gen</a><a href="shop.php">Shop Gen</a><a id="pressed" href="#">Clothes Gen</a></div></div>
	<div id="title">
		Item Generator</div>
<div id="content">
<?php


?>
<ul class="pageitem">
<li class="menu"><a href="hats.php">
<img alt="list" src="thumbs/hats.jpg" /><span class="name">Hat's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="jackets.php">
<img alt="list" src="thumbs/jackets.jpg" /><span class="name">Jacket's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="gloves.php">
<img alt="list" src="thumbs/gloves.jpg" /><span class="name">Glove's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="pants.php">
<img alt="list" src="thumbs/pants.jpg" /><span class="name">Pant's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="shoes.php">
<img alt="list" src="thumbs/shoes.jpg" /><span class="name">Shoes's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="rings.php">
<img alt="list" src="thumbs/rings.jpg" /><span class="name">Ring's</span><span class="arrow"></span></a></li>
<li class="menu"><a href="orbs.php">
<img alt="list" src="thumbs/orb.gif" /><span class="name">orb's</span><span class="arrow"></span></a></li>
</ul>
</form>
</div>
</body>

</html>
