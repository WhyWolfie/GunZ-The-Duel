<?php
function filterBadWords($str){

 // words to filter
 $badwords=array();

 // replace filtered words with
 $replacements=array();

 for($i=0;$i < sizeof($badwords);$i++){
  srand((double)microtime()*1000000); 
  $rand_key = (rand()%sizeof($replacements));
  $str=eregi_replace($badwords[$i], $replacements[$rand_key], $str);
 }
 return $str;
}
?>