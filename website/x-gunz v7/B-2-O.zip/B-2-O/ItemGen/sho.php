<?php 
ini_set("magic_quotes_gpc", "0"); 
set_magic_quotes_runtime(0);
$itemid = $_POST["itemid"];
$quote='"';
?>
<!DOCTYPE html>
<html>
<head>
<meta content="yes" name="apple-mobile-web-app-capable" />
<meta content="index,follow" name="robots" />
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
<link href="icon.png" rel="apple-touch-icon" />
<meta content="minimum-scale=1.0, width=device-width, maximum-scale=0.6667, user-scalable=no" name="viewport" />
<script src="javascript/functions.js" type="text/javascript"></script>
<title>Thank You!</title>
<link media="screen" href="css/style.css" type= "text/css" rel="stylesheet" />
 <link media="screen" href="comments.css" type= "text/css" rel="stylesheet" />
</head>

<body>
<div id="topbar">
	<div id="title">Finished!</div>
</div>
	<div id="leftnav">
		<a href="menu.html">Back</a></div>
</div>
<div id="content">
<?php
{
include 'replace.php';
$itemid = strip_tags($itemid, '<b><i><u></b></i></u><p></p>');
$itemid = filterBadWords($itemid);
$myFile = "shopcode.txt";
$fh = fopen($myFile, 'a') or die("<ul class='pageitem'><li class='textbox>Sorry, there was an internal system error, your comment was not posted.</li></ul>");
fwrite($fh, "	<SELL itemid=$quote");
fwrite($fh, $itemid);
fwrite($fh, "$quote");
fwrite($fh, " />");
fclose($fh);
echo "<ul class=\"pageitem\">";
echo "<li class=\"textbox\">";
echo "your code has been created!";
echo " click to view:"; 
echo "</li>";
echo "</ul>";
}
?>
<ul class="pageitem">
<p></P>
<a href="shopcode.txt">View the codes!</a>
<p></p>
<li></li>
</ul>
</div>
</body>
</html>

