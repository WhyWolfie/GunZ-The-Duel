i got bored so i created this little web item generator. just fill in the fields with your
options press generate and there you go! there might be future updates, but you can pretty 
much view the codes and figure it out yourself. example:
Katana.php has all the empty boxes when generate is clicked if the empty boxes are filled then
it would be send to kat.php and posted in itemcode.txt.

credits to iwebkit because i used their site for this.