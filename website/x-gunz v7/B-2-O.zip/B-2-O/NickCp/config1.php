<?php

   ///////////////////////////////////
  // Emisand's Gunz Admin Panel /////
 /// -- Configuration File  -- /////
///////////////////////////////////

$mssql_user = "sa";    //Enter here the MSSQL User for your Gunz Database
                    //If the MSSQL Server is in the same server as the web, leave it blank

$mssql_pass = "007007";    //Enter here the MSSQL Password for your Gunz Database
                    //If the MSSQL Server is in the same server as the web, leave it blank

$mssql_database = 'GunzDB'; //Enter here the Name of your Gunz Database

//Host. IP If working remotely
$mssql_host = 'USUARIO-7D01F86\SQLEXPRESS'; //Enter here the name of your SQL Server

$conn = mssql_connect($mssql_host, $mssql_user, $mssql_pass); //Don't touch this
mssql_select_db($mssql_database);                            //Don't touch this

?>
