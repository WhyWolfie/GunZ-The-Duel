<p><b><font face="Arial">Controles de Personajes (Characters)</font></b></p>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Nome De Char </strong></em></td>
     </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=cambiarchar">
     Character Actual:
     <input name="charact" type="text" id="charact" />
     Character Nuevo:
     <input name="ncharact" type="text" id="ncharact" />
     <input type="submit" name="Submit99" value="Mudar Nome de Char" />
    </form>     </td>
  </tr>
  <tr>
  <td width="730" bordercolor="#FF6633">Resultados:
    <?php
    include "config.php";
    include "functions.php";
		if ($_GET['do'] == 'cambiarchar')
{
    $charact = sqlseguro($_POST['charact']);
    $ncharact = sqlseguro($_POST['ncharact']);
	if (valida($charact) == true and valida($ncharact) == true)
    {
    $query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$charact'");
    			if(mssql_num_rows($query)<1){
			echo "Esse Char Nao Existe";
				} else {
                $pre = mssql_query("SELECT * FROM Character(nolock) where Name = '$ncharact'");
                if(mssql_num_rows($pre) != 0){
            echo "Ja Existe um Char Com Esse Nome $ncharact";
                } else {
    $cambiar = mssql_query("UPDATE Character SET Name='$ncharact' WHERE Name='$charact'");
            writetolog('O Char '.$charact.' Foi Mudado '.$ncharact);
            echo "Nome De Char Mudado $ncharact";
            }
        }
    }
 }
 ?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Apagar Char </strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=echars&do=deletechar">
      Nome do Char:
          <input name="chartodelete" type="text" id="chartodelete" />
          <input type="submit" name="Submit3" value="Apagar Char" />
    </form>    </td>
  </tr>
  <tr>
    <td>Resultados:
    <?php
		if ($_GET['do'] == 'deletechar')
{
	$usuario = sqlseguro($_POST['chartodelete']);
	if (valida($usuario) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query) <1 ){
			echo "El Personaje no existe";
				} else {
			$sql=mssql_query("DELETE from Character WHERE Name='$usuario'");
            writetolog('El personaje '.$usuario.' ha sido borrado.');
            echo "El personaje $usuario ha sido borrado.";
    }
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Obter CID</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=echars&do=getcid">
      Personaje:
      <input name="personaje" type="text" id="personaje" />
      <input type="submit" name="Submit98" value="Obtener CID" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados: <?php
		if ($_GET['do'] == 'getcid')
{
	$pj = sqlseguro($_POST['personaje']);
	if (valida($pj) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$pj'");
			if(mssql_num_rows($query)<1){
			echo "O Char Nao Existe";
				} else {
            $data = mssql_fetch_assoc($query);
            $cid = $data['CID'];
            writetolog('Obtev a CID De '.$pj.' que e '.$cid);
            echo "La CID de $pj es $cid.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Apagar Todos os Items Equip</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=echars&do=deleteitem">
      CID:
      <input name="itemtodelete" type="text" id="itemtodelete" />
      <input type="submit" name="Submit2" value="Delete Items" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados: <?php
		if ($_GET['do'] == 'deleteitem')
{
	$cid = sqlseguro($_POST['itemtodelete']);
	if (valida($cid) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE CID='$cid'");
			if(mssql_num_rows($query)<1){
			echo "A Cid nao Existe";
				} else {
			$sql=mssql_query("DELETE from CharacterItem WHERE CID='$cid'");
            writetolog('Foi Apagado todos os items desta cid '.$cid);
            echo "Todos Items dessa cid: $cid foi apagados.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Apagar Todos os Item Da Storage</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=echars&do=deleteprems">
      CID:
      <input name="cidstorage" type="text" id="cidstorage" />
      <input type="submit" name="Submitst" value="Delete Items" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados: <?php
		if ($_GET['do'] == 'deleteprems')
{
	$cid = sqlseguro($_POST['cidstorage']);
	if (valida($cid) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE CID='$cid'");
			if(mssql_num_rows($query)<1){
			echo "La CID no existe.";
				} else {
            $aid0 = mssql_fetch_assoc($query);
            $aid = $aid0['AID'];
            $sql=mssql_query("DELETE from AccountItem WHERE AID='$aid'");
            writetolog('Foi Apagado todo os items da storage dessa Cid '.$cid);
            echo "Todos os items dessa CID: $cid Foi Apagado.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Add Item
</em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=additem">
      CID:
      <input name="cid" type="text" id="cid" />
       ID do Item:
      <input name="id" type="text" id="id" />
        <input type="submit" name="Submit4" value="Add Item" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'additem')
{
	$cid = sqlseguro($_POST['cid']);
	$id = sqlseguro($_POST['id']);
	if (valida($cid) == true and valida($id) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE CID='$cid'");
			if(mssql_num_rows($query)<1){
			echo "La CID no existe.";
				} else {
	$query = $sql=mssql_query("INSERT INTO CharacterItem (CID, ItemID) VALUES ('$cid', '$id')");
            writetolog('o item foi ADD '.$id.' a CID '.$cid);
    echo "A CID $cid foi add o item $id.";
        }
    }
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Apagar Item</strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=delitem">
      CID:
      <input name="delcid" type="text" id="delcid" />
     ID do Item:
     <input name="delid" type="text" id="delid" />
     <input type="submit" name="Submit4" value="Deletar Item" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'delitem')
{
	$delcid = sqlseguro($_POST['delcid']);
	$delid = sqlseguro($_POST['delid']);
	if (valida($delcid) == true and valida($delid) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock)Item WHERE CID='$delcid' and ItemID='$delid'");
			if(mssql_num_rows($query)<1){
			echo " CID E ID Estao incorretos";
				} else {
			$sql=mssql_query("DELETE from CharacterItem WHERE CID='$delcid' and ItemID='$delid'");
            writetolog('Items Apagados '.$delid.' de la CID '.$delcid);
            echo "Foi Apagados todos os items $delid de la CID $delcid";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Baixar Nivel, Exp y Bounty Autom�tico para Swappers </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=ownswap">
      Nome de Char:
     <input name="swapper" type="text" id="swapper" />
     <input type="submit" name="Submitswap" value="Ownear o Swapper" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'ownswap')
{
	$swapper = sqlseguro($_POST['swapper']);
	if (valida($swapper) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$swapper'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
			$sql=mssql_query("UPDATE Character SET XP='0', Level='1', BP='1000' WHERE Name='$swapper'");
            writetolog('Foi Abaixado Exp Bountry e mais do Char '.$swapper);
            echo "o Swaper $swapper foi sido owneado (bajado a lvl 1 y 1000 de bounty).";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Exp de Char </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changeexp">
      Nome do Char:
      <input name="charexp" type="text" id="charexp" />
     Exp:
     <input name="newexp" type="text" id="newexp" />
     <input type="submit" name="Submit4" value="Change Exp" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changeexp')
{
	$usuario = sqlseguro($_POST['charexp']);
	$exp = sqlseguro($_POST['newexp']);
	if (valida($usuario) == true and valida($newexp) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
			$sql=mssql_query("UPDATE Character set XP='$exp' WHERE Name='$usuario'");
            writetolog('a exp de '.$usuario.' Foi Mudado '.$exp);
            echo "a exp. de $usuario Foi Mudado $exp.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Nivel de Char. </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changelevel">
      Nome de Char:
      <input name="charlevel" type="text" id="charlevel" />
     Nivel:
     <input name="newlevel" type="text" id="newlevel" />
     <input type="submit" name="Submit4" value="Change Level" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changelevel')
{
	$usuario = sqlseguro($_POST['charlevel']);
	$level = sqlseguro($_POST['newlevel']);
	if (valida($usuario) == true and valida($newlevel) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
			$sql=mssql_query("UPDATE Character set Level='$level' WHERE Name='$usuario'");
            writetolog('El nivel de '.$usuario.' fue cambiado a '.$level);
            echo "El nivel de $usuario fue cambiado a $level.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Bountry de Char </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changebounty">
      Nombre de Personaje:
      <input name="charbp" type="text" id="charbp" />
     Bounty:
     <input name="newbp" type="text" id="newbp" />
     <input type="submit" name="Submit4" value="Mudar Bounty" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changebounty')
{
	$usuario = sqlseguro($_POST['charbp']);
	$bounty = sqlseguro($_POST['newbp']);
	if (valida($usuario) == true and valida($newbp) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "o Personajem nao existe";
				} else {
			$sql=mssql_query("UPDATE Character set BP='$bounty' WHERE Name='$usuario'");
            writetolog('o Bountry '.$usuario.' Foi Mudado '.$bounty);
            echo "o Bountry de $usuario foi mudado a $bounty.";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Cabelo de Chars[ID:0-3]. </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changehair">
      Character Nome:
      <input name="charhair" type="text" id="charhair" />
     Cabelo:
     <input name="newhair" type="text" id="newhair" />
     <input type="submit" name="Submit4" value="Mudar Cabelo" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changehair')
{
	$usuario = sqlseguro($_POST['charhair']);
	$hair = sqlseguro($_POST['newhair']);
	if (valida($usuario) == true and valida($hair) == true)
	{
    if ($hair != 0 and $hair != 1 and $hair != 2 and $hair != 3){
    echo "El valor del pelo tiene que ser de 0 a 3";
    } else {
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
			$sql=mssql_query("UPDATE Character set Hair='$hair' WHERE Name='$usuario'");
            writetolog('El pelo de '.$usuario.' ha sido cambiado a '.$hair);
            echo "El pelo de $usuario a sido cambiado a $hair.";
            }
        }
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Cara de Char[ID:0-3]. </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changeface">
      Nome de Char:
      <input name="charface" type="text" id="charface" />
     Rosto:
     <input name="newface" type="text" id="newface" />
     <input type="submit" name="Submit4" value="Mudar Rosto" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changeface')
{
	$usuario = sqlseguro($_POST['charface']);
	$face = sqlseguro($_POST['newface']);
	if (valida($usuario) == true and valida($newface) == true)
	{
    if ($face != 0 and $face != 1 and $face != 2 and $face != 3){
    echo "El valor de la cara tiene que ser de 0 a 3";
    } else {
    $query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "o Personajem nao existe";
				} else {
			$sql=mssql_query("UPDATE Character set Face='$face' WHERE Name='$usuario'");
            writetolog('A cara de '.$usuario.' foi mudada'.$face);
            echo "a cara de  $usuario foi mudada $face.";
            }
        }
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Sexo de Char 0 Homen 1 Mulher. </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=echars&do=changesex">
      Nome de Char:
      <input name="charsex" type="text" id="charsex" />
     Sexo:
     <input name="newsex" type="text" id="newsex" />
     <input type="submit" name="Submit4" value="Mudar Sexo" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changesex')
{
	$usuario = sqlseguro($_POST['charsex']);
	$sex = sqlseguro($_POST['newsex']);
	if (valida($usuario) == true and valida($newsex) == true)
	{
    if ($sex != 0 and $sex != 1){
    echo "El valor del sexo debe ser 0 o 1";
    } else {
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
			$sql=mssql_query("UPDATE Character set Sex='$sex' WHERE Name='$usuario'");
            writetolog('o Sexo de '.$usuario.' foi mudado'.$sex);
            echo "o sexo de $usuario agora e $sex.";
            }
        }
	}
}
?></td>
  </tr>
</table>


</body>

</html>
