<?php

    if( !ereg("index.php", $_SERVER['PHP_SELF']) )
    {
        header("Location: index.php");
        die();
    }

// Messages System
$_STR[Msg0]     = "Mensagen de:";
$_STR[Msg1]     = "Voce tem que preencher todos os campos.";

// Login Frame
$_STR[Login0]   = "X-GunZ Admin Pannel Login";
$_STR[Login1]   = "User";
$_STR[Login2]   = "Pass";
$_STR[Login3]   = "Login";

// Login Module
$_STR[Login4]   = "Voce tem que preencher todos os campos de login.";
$_STR[Login5]   = "Voce nao tem permissao para acessar o Painel de Controle.";
$_STR[Login6]   = "Usuario/Senha incorretas";

// Menu
$_STR[Menu0]    = "X-GunZ Menu";
$_STR[Menu1]    = "Bem Vindo %s!";
$_STR[Menu2]    = "Home";
$_STR[Menu3]    = "NotePad";
$_STR[Menu4]    = "ASCII Table";
$_STR[Menu11]   = "Lista de Contas";
$_STR[Menu12]   = "Lista de Chars";
$_STR[Menu5]    = "Procurar";
$_STR[Menu6]    = "Editar Contas";
$_STR[Menu7]    = "Editar Chars";
$_STR[Menu8]    = "Logout";
$_STR[Menu9]    = "Editar Clans";
$_STR[Menu10]   = "Bloquear Pais";


// Home
$_STR[Home0]    = "Bem Vindo ao X-Gunz Control Panel";
$_STR[Home1]    = "X-GunZ Admin Pannel (Red Version)<br />Skin designed by Lambda and Nick<br />Support:";
$_STR[Home2]    = "Informa�oes do servidor";
$_STR[Home3]    = "Contas Criadas: ";
$_STR[Home4]    = "- Chars, Criados: ";
$_STR[Home5]    = "- Players online: ";
$_STR[Home6]    = "Status";
$_STR[Home7]    = "Nome";

// NotePad
$_STR[Notepad0] = "Enviar uma mensagen";
$_STR[Notepad1] = "Msg:";
$_STR[Notepad2] = "Enviar Mensagen";
$_STR[Notepad3] = "Ver Mensagens";

// Ascii
$_STR[Ascii1]   = "Ascii Character Table";
$_STR[Ascii2]   = "Symbol";

// Search
$_STR[Search0]  = "Procurar";
$_STR[Search1]  = "Procurar Characters";
$_STR[Search2]  = "Procurar Contas";
$_STR[Search3]  = "Procurar Clans";
$_STR[Search4]  = "Procurar Clan Wins/Losses";
$_STR[Search5]  = "Nome";
$_STR[Search6]  = "Nome do Clan";
$_STR[Search7]  = "Nome do Character";
$_STR[Search8]  = "Lider do Clan:";
$_STR[Search9]  = "Este Clan";
$_STR[Search10] = "Ganhou";
$_STR[Search11] = "Perdeu";
$_STR[Search12] = "Numero maximo de vitorias seguidas";
$_STR[Search13] = "Erro na procura.";
$_STR[Search14] = "Nenhum resultado encontrado.";
$_STR[Search15] = "Procurar resultados";

// Logs

$_STR[Log0]     = "A UserID da %s %s foi mudada para %s";
$_STR[Log1]     = "A Senha de %s %s foi mudada para %s";
$_STR[Log2]     = "O UGrade Rank de %s %s foi mudada para %s";
$_STR[Log3]     = "O Iten %s foi enviada para todas as contas";
$_STR[Log4]     = "O Iten %s foi enviado para a AID %s";

$_STR[Log5]     = "O Nome do Char %s foi mudado para %s";
$_STR[Log6]     = "O Char %s foi deletado";
$_STR[Log7]     = "Todos os itens do character %s foram deletados";
$_STR[Log8]     = "All the account items from the AID %s have been deleted";
$_STR[Log9]     = "O Iten: (ID) %s foi enviado para a (CID) %s";
$_STR[Log10]    = "O Iten: (ID) %s foi deletado da CID %s";
$_STR[Log11]    = "The character %s has been reset";
$_STR[Log12]    = "The EXP from the character %s has been changed to %s";
$_STR[Log13]    = "The Level from the character %s has been changed to %s";
$_STR[Log14]    = "The Bounty from the character %s has been changed to %s";
$_STR[Log15]    = "The Sex from the character %s has been changed";
$_STR[Log16]    = "The Hair from the character %s has been changed";
$_STR[Log17]    = "The Face from the character %s has been changed";

$_STR[Log18]    = "Clan Ranking Updated";
$_STR[Log19]    = "The clan %s has been created with MasterCID %s";
$_STR[Log20]    = "The clan %s has been deleted";
$_STR[Log21]    = "The clan %s has been resetted";
$_STR[Log22]    = "All clans have been resetted";
$_STR[Log23]    = "Emblem removed from the clan %s";
$_STR[Log24]    = "The stats of the clan %s have been changed";
$_STR[Log25]    = "The clanmember %s grade has been changed to %s";

$_STR[Log26]    = "All countries have been allowed";
$_STR[Log27]    = "All countries have been blocked";
$_STR[Log28]    = "The country with countrycode3 %s has been allowed";
$_STR[Log29]    = "The country with countrycode3 %s has been blocked";
$_STR[Log30]    = "A new block message has been set: %s";

// Accounts

$_STR[Acc0]     = "Trocar UserID";
$_STR[Acc1]     = "Nova UserID";
$_STR[Acc2]     = "Trocar";
$_STR[Acc3]     = "Trocar Password";
$_STR[Acc4]     = "Nova Password";
$_STR[Acc5]     = "Trocar Account Rank";
$_STR[Acc6]     = "Banned";
$_STR[Acc7]     = "Normal User";
$_STR[Acc8]     = "GM Escondido";
$_STR[Acc9]     = "GM Normal";
$_STR[Acc10]    = "Administrador";
$_STR[Acc11]    = "Enviar ITEN para TODAS as contas.";
$_STR[Acc12]    = "Periodo de Dura�ao(Dias)";
$_STR[Acc13]    = "Enviar item para os equipamentos";
$_STR[Acc14]    = "Enviar";
$_STR[Acc15]    = "It alredy exists an account with the UserID %s";
$_STR[Acc16]    = "The selected account does not exist";
$_STR[Acc17]    = "UserID Trocada com sucesso.";
$_STR[Acc18]    = "Password Trocada com sucesso.";
$_STR[Acc19]    = "Rank Trocada com sucesso.";
$_STR[Acc20]    = "ItemID ou 'Periodo de Dura�ao' Incorretos.";
$_STR[Acc21]    = "Item enviado para todas as contas";
$_STR[Acc22]    = "Item enviado para a conta selecionada";

// Characters

$_STR[Char0]    = "Trocar nome do Char";
$_STR[Char1]    = "Nome";
$_STR[Char2]    = "Novo Nome";
$_STR[Char3]    = "Trocar";
$_STR[Char4]    = "Deletar Character";
$_STR[Char5]    = "Deletar";
$_STR[Char6]    = "Deletar todos os itens do equipamento.";
$_STR[Char7]    = "Deletar todos os itens do Banco.";
$_STR[Char8]    = "Enviar iten para o equipamento";
$_STR[Char9]    = "Deletar item do equipamento";
$_STR[Char10]   = "Enviar";
$_STR[Char11]   = "Resetar character (Lvl 1, XP: 0, BT: 1000)";
$_STR[Char12]   = "Resetar";
$_STR[Char13]   = "Trocar EXP do char";
$_STR[Char14]   = "Trocar LVL do char";
$_STR[Char15]   = "Trocar Bounty do Char";
$_STR[Char16]   = "Trocar Sexo do Char";
$_STR[Char17]   = "Homem";
$_STR[Char18]   = "Mulher";
$_STR[Char19]   = "Trocar cabelo do Char";
$_STR[Char20]   = "Cabelo";
$_STR[Char21]   = "Trocar Rosto do Char";
$_STR[Char22]   = "Rosto";
$_STR[Char23]   = "Ja existe um char com o nome %s";
$_STR[Char24]   = "Este Char nao existe";
$_STR[Char25]   = "Nome trocado com sucesso";
$_STR[Char26]   = "Char Deletado com sucesso";
$_STR[Char27]   = "Itens deletados com sucesso";
$_STR[Char28]   = "O Char ou conta selecionada nao existe";
$_STR[Char29]   = "Item enviado com sucesso";
$_STR[Char30]   = "Item deletado com sucesso";
$_STR[Char31]   = "Character resetado com sucesso";
$_STR[Char32]   = "Incorrect numeric value";
$_STR[Char33]   = "EXP trocada com sucesso";
$_STR[Char34]   = "LVL trocado com sucesso";
$_STR[Char35]   = "Bounty trocado com sucesso";
$_STR[Char36]   = "Sexo Invalido";
$_STR[Char37]   = "Sexo trocado com sucesso";
$_STR[Char38]   = "Cabelo invalido";
$_STR[Char39]   = "Cabelo trocado com sucesso";
$_STR[Char40]   = "Rosto Invalido";
$_STR[Char41]   = "Rosto trocado com sucesso";

// Clans

$_STR[Clan0]    = "Update Clan Ranking";
$_STR[Clan1]    = "This will update all clan's ranking<br />It may take long if you have many clans<br />";
$_STR[Clan2]    = "Update";
$_STR[Clan3]    = "Create Clan";
$_STR[Clan4]    = "Name";
$_STR[Clan5]    = "Create";
$_STR[Clan6]    = "Delete Clan";
$_STR[Clan7]    = "Delete";
$_STR[Clan8]    = "Reset Clan Score";
$_STR[Clan9]    = "Reset ALL Clans";
$_STR[Clan10]   = "Reset";
$_STR[Clan11]   = "Remove Clan Emblem";
$_STR[Clan12]   = "Remove";
$_STR[Clan13]   = "Change Clan Stats";
$_STR[Clan14]   = "Change";
$_STR[Clan15]   = "Change Member Grade";
$_STR[Clan16]   = "Rank";
$_STR[Clan17]   = "<b>Warning:</b> This cannot be reverted<br /><br />";
$_STR[Clan18]   = "Clan Ranking successfully updated";
$_STR[Clan19]   = "It already exists a clan with the selected name";
$_STR[Clan20]   = "The selected clan Master does not exist";
$_STR[Clan21]   = "The selected clan Master is member of another clan";
$_STR[Clan22]   = "Clan successfully created";
$_STR[Clan23]   = "The selected clan does not exist";
$_STR[Clan24]   = "Clan successfully deleted";
$_STR[Clan25]   = "Clan successfully resetted";
$_STR[Clan26]   = "All Clans successfully resetted";
$_STR[Clan27]   = "Emblem successfully removed";
$_STR[Clan28]   = "The Wins, Losses and Points must be numeric values";
$_STR[Clan29]   = "Stats successfully changed";
$_STR[Clan30]   = "The selected ClanMember does not exist";
$_STR[Clan31]   = "The selected ClanMember Rank is invalid";
$_STR[Clan32]   = "The selected Character is not member of any clan";
$_STR[Clan33]   = "The selected ClanMember is the owner of a clan, and you can't change his grade";
$_STR[Clan34]   = "The ClanMember Rank was successfully changed";

// Country Restriction plugin

$_STR[Country0] = "Allow all countries";
$_STR[Country1] = "Allow";
$_STR[Country2] = "Block all countries";
$_STR[Country3] = "Block";
$_STR[Country4] = "Allow a country";
$_STR[Country5] = "Block a country";

$_STR[Country6] = "All countries have been allowed";
$_STR[Country7] = "All countries have been blocked";
$_STR[Country8] = "Country allowed successfully";
$_STR[Country9] = "Country blocked successfully";
$_STR[Country10]= "Block message set successfully";
$_STR[Country11]= "Set a new blocked country message";
$_STR[Country12]= "Set";



?>
