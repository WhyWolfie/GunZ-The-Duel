<p>Buscadores
<?php
include "config.php";
include "functions.php";
?></p>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Buscador de Personajes</strong></em></td>
  </tr>
  <tr>
    <td height="30">
    <FORM METHOD=POST ACTION="index.php?act=buscador&do=buscarchar">
      Personaje a buscar:
      <input name="charb" type="text" id="charb" />
      <input type="submit" name="Submit" value="Buscar" />
    </form></td>

</td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Buscador de Cuentas </strong></em></td>
  </tr>
  <tr>
    <td height="30">
    <FORM METHOD=POST ACTION="index.php?act=buscador&do=buscaracc">
      Cuenta a buscar:
      <input name="cuentab" type="text" id="cuentab" />
      <input type="submit" name="Submit" value="Buscar" />
    </form></td>
    </td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Buscar Personajes de una AID </strong></em></td>
  </tr>
  <tr>
    <td height="30">
    <FORM METHOD=POST ACTION="index.php?act=buscador&do=buscaraid">
      AID:
      <input name="aid" type="text" id="aid" />
      <input type="submit" name="Submit" value="Buscar" />
    </form></td>
    </td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Buscar Personajes de un Clan </strong></em></td>
  </tr>
  <tr>
    <td height="30">
    <FORM METHOD=POST ACTION="index.php?act=buscador&do=buscarclan">
      Nombre del Clan:
      <input name="clan" type="text" id="clan" />
      <input type="submit" name="Submit" value="Buscar" />
    </form></td>
    </td>
  </tr>
</table>
<p> </p>
<style type="text/css">

.style28 {font-size: 15px}
.style29 {color: #FFFFFF; font-weight: bold; font-size: 15px; }

</style>
<table width="980" border="1">
  	<tr >
    <th colspan="15" scope="row"><span class="style28">Lista de Personajes</span></th>
  </tr>
  <tr>
    <th width="31" scope="row"><span class="style28"><strong>Num</strong></span></th>
    <th width="28" scope="row"><span class="style28"><strong>CID</strong></span></th>
    <td width="61"><span class="style28"><strong>AID</strong></span></td>
    <td width="54"><span class="style28"><strong>Nombre</strong></span></td>
    <td width="61"><span class="style28"><strong>Nivel</strong></span></td>
    <td width="54"><span class="style28"><strong>Sexo</strong></span></td>
    <td width="61"><span class="style28"><strong>EXP</strong></span></td>
    <td width="28"><span class="style28"><strong>Bounty</strong></span></td>
    <td width="64"><span class="style28"><strong>KillCount</strong></span></td>
    <td width="54"><span class="style28"><strong>DeathCount</strong></span></td>
</tr>
    <?php
    	if ($_GET['do'] == 'buscarchar')
{
    $charb = sqlseguro($_POST['charb']);
    if( valida($charb) == true ){
    $query = mssql_query('SELECT * FROM Character(nolock) WHERE Name LIKE "%'.$charb.'%" ORDER BY AID ASC');

    for($i=0;$i < mssql_num_rows($query);)
        {
        $row = mssql_fetch_assoc($query);
        $count = $i+1;
?>
<tr>
    <th scope="row"><span class="style28"><strong><?php echo "$count";?></strong></span></th>
    <td><span class="style28"><?php echo "$row[CID]";?></span></td>
    <td><span class="style28"><?php echo "$row[AID]";?></span></td>
    <td><span class="style28"><?php echo "$row[Name]";?></span></td>
    <td><span class="style29"><?php echo "$row[Level]";?></span></td>
    <td><span class="style29"><?php echo "$row[Sex]";?></span></td>
    <td><span class="style29"><?php echo "$row[XP]";?></span></td>
    <td><span class="style29"><?php echo "$row[BP]";?></span></td>
    <td><span class="style29"><?php echo "$row[KillCount]";?></span></td>
    <td><span class="style29"><?php echo "$row[DeathCount]";?></span></td>
</tr>
  <?php
  $i++;
  }
}
}
  else if ($_GET['do'] == 'buscaraid')
{
    $aid = sqlseguro($_POST['aid']);
    if( valida($aid) == true ){
    $query2 = mssql_query("SELECT * FROM Character WHERE AID = '$aid' ORDER BY CID ASC");

    for($i=0;$i < mssql_num_rows($query2);)
        {
        $row = mssql_fetch_assoc($query2);
        $count = $i+1;
?>
<tr>
    <th scope="row"><span class="style28"><strong><?php echo "$count";?></strong></span></th>
    <td><span class="style28"><?php echo "$row[CID]";?></span></td>
    <td><span class="style28"><?php echo "$row[AID]";?></span></td>
    <td><span class="style28"><?php echo "$row[Name]";?></span></td>
    <td><span class="style29"><?php echo "$row[Level]";?></span></td>
    <td><span class="style29"><?php echo "$row[Sex]";?></span></td>
    <td><span class="style29"><?php echo "$row[XP]";?></span></td>
    <td><span class="style29"><?php echo "$row[BP]";?></span></td>
    <td><span class="style29"><?php echo "$row[KillCount]";?></span></td>
    <td><span class="style29"><?php echo "$row[DeathCount]";?></span></td>
</tr>
  <?php
  $i++;
  }
}
}
else if ($_GET['do'] == 'buscarclan')
{
    $clan = sqlseguro($_POST['clan']);
    if( valida($clan) == true ){
    $query3 = mssql_query("SELECT * FROM Clan(nolock) WHERE Name = '$clan'");
    $CLID0 = mssql_fetch_assoc($query3);
    $CLID = $CLID0['CLID'];
    $query4 = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CLID = '$CLID'");
    $cid0 = mssql_fetch_assoc($query4);
    $cid = $cid0['CID'];
    for($i=0;$i < mssql_num_rows($query4);)
        {
        $query5 = mssql_query("SELECT * FROM Character(nolock) WHERE CID = '$cid'");
        $row = mssql_fetch_assoc($query5);
        $count = $i+1;

  ?>
<tr>
    <th scope="row"><span class="style28"><strong><?php echo "$count";?></strong></span></th>
    <td><span class="style28"><?php echo "$row[CID]";?></span></td>
    <td><span class="style28"><?php echo "$row[AID]";?></span></td>
    <td><span class="style28"><?php echo "$row[Name]";?></span></td>
    <td><span class="style29"><?php echo "$row[Level]";?></span></td>
    <td><span class="style29"><?php echo "$row[Sex]";?></span></td>
    <td><span class="style29"><?php echo "$row[XP]";?></span></td>
    <td><span class="style29"><?php echo "$row[BP]";?></span></td>
    <td><span class="style29"><?php echo "$row[KillCount]";?></span></td>
    <td><span class="style29"><?php echo "$row[DeathCount]";?></span></td>
</tr>
<?php
    $i++;
    }
}
} ?>
</td>
</table>
<p></p>
<table width="980" border="1">
  <tr >
    <th colspan="8" scope="row"><span class="style28">Lista de Cuentas</span></th>
  </tr>
  <tr>
    <th width="19" scope="row"><span class="style28"><strong>Num</strong></span></th>
     <th width="19" scope="row"><span class="style28"><strong>AID</strong></span></th>
    <td width="61"><span class="style28"><strong>UserID</strong></span></td>
    <td width="54"><span class="style28"><strong>UGradeID</strong></span></td>
    <td width="61"><span class="style28"><strong>E-Mail</strong></span></td>
</tr>
    <?php
    	if ($_GET['do'] == 'buscaracc')
{
    $cuentab = sqlseguro($_POST['cuentab']);
    if( valida($cuentab) == true ){
    $query6 = mssql_query('SELECT * FROM Account(nolock) WHERE UserID LIKE "%'.$cuentab.'%" ORDER BY AID ASC');

    for($i=0;$i < mssql_num_rows($query6);)
        {
        $row = mssql_fetch_assoc($query6);
        $count = $i+1;
?>
<tr>
      <th scope="row"><span class="style28"><strong><?php echo "$count";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[AID]";?></span></td>
    <td><span class="style28"><?php echo "$row[UserID]";?></span></td>
    <td><span class="style28"><?php echo "$row[UGradeID]";?></span></td>
    <td><span class="style29"><?php echo "$row[Email]";?></span></td>

</tr>
<?php
    $i++;
    }
}
}
?>
</table></div>
</body>
</html>