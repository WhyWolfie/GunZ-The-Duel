<p><b><font face="Arial">Block de Notas</font></b>
</p>

<form method="POST" action="index.php?act=block&do=mensaje">
<table border="1" width="46%" id="table1" style="border-width: 0px">
	<tr>
		<td style="border-style: none; border-width: medium" width="185"><b>
		<font face="Arial" size="2">Admin</font></b></td>
		<td style="border-style: none; border-width: medium"> <input name="Tnick" size="20" style="float: left"></td>
	</tr>
	<tr>
		<td style="border-style: none; border-width: medium" width="185"><b><em style="font-style: normal">
		<font face="Arial" size="2">Nota</font></em></b></td>
		<td style="border-style: none; border-width: medium">
		<font face="Arial">
		<input name="Ttexto" size="37" style="float: left"></font></td>
	</tr>
	<tr>
		<td style="border-style: none; border-width: medium" colspan="2">
		<p align="center"><input type="submit" name="Taceptar"
      value="Aceptar"></td>
	</tr>
    </form>
    <tr>
    <td style="border-style: none; border-width: medium" colspan="2" align="left">
    <b><font face="Arial" size="2">
    <?php
    if ($_GET['do'] == 'mensaje')
{
    include "functions.php";
    $Tnick = sqlseguro($_POST['Tnick']);
    $Ttexto = sqlseguro($_POST['Ttexto']);
    if (valida($Tnick) == true and valida($Ttexto) == true)
{
    $fileb = fopen("notas.txt","r");
    $escrito= fread($fileb,10000);
    $file = fopen("notas.txt","w+");
    $total= "$Tnick: $Ttexto

$escrito";
    fwrite($file,$total, 10000);
	fclose($fileb);
    fclose($file);
echo "Mensaje Enviado";
}}
?>
    </font></b>
    <br />
    </td>
    </tr>
    <tr>
		<td style="border-style: none; border-width: medium" colspan="2">
		<p align="center">
        <textarea rows="30" cols="60"
            name="mensajecorto"><?php
            include("notas.txt");
            ?></textarea></td>
	</tr>
</table>

</body>

</html>