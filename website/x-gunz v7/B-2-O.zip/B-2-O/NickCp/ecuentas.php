<p><b><font face="Arial">Controles de Cuentas</font></b>
</p>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Registrar Nova Conta</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=ecuentas&do=register">
      Usuario:
      <input name="user" type="text" id="user" />
      Senha:
      <input name="pass" type="text" id="pass" />
      Idade:
      <input name="edad" type="text" id="edad" size="3" />
      Sexo:
      <select name="sexo">
      <option value="0">Homen</option>
      <option value="1">Mulher</option>
      </select>
      <input type="submit" name="Submitreg" value="Criar Conta" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados: <?php
    include "config.php";
    include "functions.php";
    		if ($_GET['do'] == 'register')
{
	$user = sqlseguro($_POST['user']);
    $pass = sqlseguro($_POST['pass']);
    $edad = sqlseguro($_POST['edad']);
    $sexo = sqlseguro($_POST['sexo']);
	if ( valida($user) == true and valida($pass) == true)
	{
        if ( !is_numeric($edad) ){
        die('Temque Ser um Numero');
        }
        if ( !is_numeric($sexo) ){
        die('Op�ao de Sexo Mudada');
        }
            $query = mssql_query("SELECT * FROM Account(nolock) WHERE UserID='$user'");
			if(mssql_num_rows($query)>=1){
			echo "Ya hay una cuenta con el mismo nombre";
            } else {
    $sql = mssql_query("INSERT INTO Account (UserID, Cert, Name, Age, Sex, UGradeID, PGradeID, RegDate)
                        VALUES ('$user', 1, 'Registro Panel', '$edad', '$sexo', 0, 0, GETDATE())");
    $sql02 = mssql_query("SELECT * FROM Account(nolock) WHERE UserID = '$user' AND Age = '$edad'");
    $aid0 = mssql_fetch_assoc($sql02);
    $aid = $sql2['AID'];
    $sql2 = mssql_query("INSERT INTO Login (UserID, AID, Password) VALUES ('$user', '$aid', '$pass')");
    writetolog('Se ha registrado el usuario '.$user.' con la contrase�a '.$pass);
    echo "Se ha registrado el usuario: $user con la contrase�a: $pass";

	    }
    }
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Nome de Conta. </strong></em></td>
  </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=ecuentas&do=changeaccount">
      Conta Atual:
      <input name="characcount" type="text" id="characcount" />
     Nova Conta:
     <input name="newaccount" type="text" id="newlevel" />
     <input type="submit" name="Submit4" value="Mudar Nome de Conta" />
    </form>
    </td>
  </tr>
  <tr>
    <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'changeaccount')
{
	$usuario = sqlseguro($_POST['characcount']);
	$account = sqlseguro($_POST['newaccount']);
	if (valida($usuario) == true and valida($newaccount) == true)
	{
	$query = mssql_query("SELECT * FROM Account(nolock) WHERE UserID='$usuario'");
			if(mssql_num_rows($query) < 1){
			echo "La cuenta no existe";
				} else {
            $pre = mssql_query("SELECT * FROM Account(nolock) WHERE UserID = '$account'");
                if (mssql_num_rows($pre) != 0){
                echo "Ya hay una cuenta con el nombre $account";
                }else{
			$sql = mssql_query("UPDATE Account SET UserID = '$account' WHERE UserID = '$usuario'");
            $sql2 = mssql_query("UPDATE Login SET UserID = '$account' WHERE UserID = '$usuario'");
            writetolog('El nombre de la cuenta '.$usuario.' ha sido cambiado a '.$account);
            echo "El nombre de cuenta $usuario ha sido cambiado a $account.";
            }
        }
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Senha De Usuario </strong></em></td>
  </tr>
  <tr>
    <td height="30">
	<FORM METHOD=POST ACTION="?act=ecuentas&do=changepass">
      Nome:
      <input name="userpasschange" type="text" id="userpasschange" />
      Senha Nova:
  <input name="passpasschange" type="text" id="passpasschange" />
  <input type="submit" name="Submit" value="Mudar Senha" />
    </form></td>
  </tr>
  <tr>
    <td height="23">Resultados:
    <?php require 'config.php';


	if ($_GET['do'] == 'changepass')
{
	$usuario = sqlseguro($_POST['userpasschange']);
	$pass = sqlseguro($_POST['passpasschange']);
	if (valida($usuario) == true and valida($pass) == true)
	{
	$query = mssql_query("SELECT * FROM Login(nolock) WHERE UserID='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "La cuenta no existe";
				} else {
			$sql=mssql_query("UPDATE Login set Password='$pass' WHERE UserID='$usuario'");
            writetolog('La contrase�a de '.$usuario.' fue cambiada a '.$pass);
            echo "La contrase�a de $usuario fue cambiada a $pass";
	} }
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Obter Nome de Conta pelo personagem</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=ecuentas&do=getname">
      Personagem:
      <input name="personaje" type="text" id="personaje" />
      <input type="submit" name="Submit97" value="Obter nome De Conta" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados: <?php
		if ($_GET['do'] == 'getname')
{
	$pj = sqlseguro($_POST['personaje']);
	if (valida($pj) == true)
	{
	$query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$pj'");
			if(mssql_num_rows($query)<1){
			echo "El personaje no existe";
				} else {
            $data = mssql_fetch_assoc($query);
            $aid = $data['AID'];
            $query2 = mssql_query("SELECT * FROM Account(nolock) WHERE AID='$aid'");
            $data2 = mssql_fetch_assoc($query2);
            $name = $data2['UserID'];
            writetolog('Obteve nome de conta '.$pj.' que e '.$name);
            echo "o Nome de Conta $pj es $name";
		}
	}
}
?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Banir Conta Diretamente pelo Char </strong></em></td>
     </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=ecuentas&do=banchar">
     Character:
     <input name="char" type="text" id="char" />
     <input type="submit" name="SubmitBan" value="Banir Conta Pelo Char" />
    </form>     </td>
  </tr>
  <tr>
  <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'banchar')
{
    $char = sqlseguro($_POST['char']);
	if (valida($char) == true)
    {
    $query = mssql_query("SELECT * FROM Character(nolock) WHERE Name='$char'");
    			if(mssql_num_rows($query)<1){
			echo "El character no existe";
				} else {
            $data = mssql_fetch_assoc($query);
            $aid = $data['AID'];
            $query2 = mssql_query("UPDATE Account SET UGradeID='253' WHERE AID='$aid'");
            writetolog('Essa Conta '.$char.' Foi Banido');
            echo "A Conta desse Char $char Foi Banido";
            }
	}
}
 ?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Banir Conta por AID </strong></em></td>
     </tr>
  <tr>
    <td bordercolor="#FF6633"><FORM METHOD=POST ACTION="?act=ecuentas&do=banaid">
     AID:
     <input name="aid" type="text" id="aid" />
     <input type="submit" name="SubmitBan" value="Banir Esta AID" />
    </form>     </td>
  </tr>
  <tr>
  <td width="730" bordercolor="#FF6633">Resultados:
    <?php
		if ($_GET['do'] == 'banaid')
{
    $aid = sqlseguro($_POST['aid']);
	if (valida($aid) == true)
    {
    $query = mssql_query("SELECT * FROM Account(nolock) WHERE AID='$aid'");
    			if(mssql_num_rows($query)<1){
			echo "La AID $aid no existe";
				} else {
            $query2 = mssql_query("UPDATE Account SET UGradeID='253' WHERE AID='$aid'");
            writetolog('A Conta Dessa Aid '.$aid.' Foi Banido.');
            echo "La cuenta con la AID $aid ha sido baneada";
            }
	}
}
 ?></td>
  </tr>
</table>
<table width="980" border="0" bordercolor="#FF6633">
  <tr>
    <td style="border-style: solid; border-width: 2px"><font face="Arial"><em><strong>Mudar Rank de Usuario</strong></em></td>
  </tr>
  <tr>
    <td><FORM METHOD=POST ACTION="?act=ecuentas&do=changeaccess">
      Account:
      <input name="userlvl" type="text" id="userlvl" />
     Level:
     <select name="lvlnumber" style=" background-color:#2A3F55; color:#A0A0A4">
       <option value="255">Administrador</option>
       <option value="254">Moderador</option>
       <option value="252">Moderador Invisivel</option>
       <option value="253">Banido</option>
       <option value="0">Normal</option>
     </select>

     <input type="submit" name="Submit6" value="Mudar Rank" />
    </form>
    </td>
  </tr>
  <tr>
    <td>Resultados:
    <?php require 'config.php';
		if ($_GET['do'] == 'changeaccess')
{
	$usuario = sqlseguro($_POST['userlvl']);
	$nivel = sqlseguro($_POST['lvlnumber']);
	if (valida($usuario) == true and valida($nivel) == true)
	{
        if ($nivel != 0 and $nivel != 255 and $nivel != 254 and $nivel != 253 and $nivel != 252){
        die('Error en el UGradeID');}
	$query = mssql_query("SELECT * FROM Account(nolock) WHERE UserID='$usuario'");
			if(mssql_num_rows($query)<1){
			echo "La cuenta no existe";
				} else {
			$sql = mssql_query("UPDATE Account set UGradeID='$nivel' WHERE UserID='$usuario'");
            writetolog('O Usuario'.$usuario.' Foi Mudado de Rank '.$nivel);
            echo "El usuario $usuario ha sido cambiado a $nivel.";
		}
	}
}
?></td>
  </tr>
</table>
</body>

</html>
