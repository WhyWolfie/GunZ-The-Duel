<p><b><font face="Arial" color="#FF9933">Men� del Panel</font></b></p>
<p>Bienvenido <?
include "config.php";
$aid = $_SESSION['AID'];
$q1 = mssql_query("SELECT * FROM Account(nolock) WHERE AID = $aid");
$q2 = mssql_fetch_assoc($q1);
echo $q2['UserID']; ?>
 !</p>
<table border="0" width="102%" cellspacing="10" id="table1">
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="index.php"><font face="Arial" color="#FF9933">P�gina Principal</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="block"><font face="Arial" color="#FF9933">Block de Notas</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="ascii"><font face="Arial" color="#FF9933">Tabela de
		Caracteres</font></a></td>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="accounts"><font face="Arial" color="#FF9933">
		Lista de Contas</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="buscador"><font face="Arial" color="#FF9933">Buscadores</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="ecuentas"><font face="Arial" color="#FF9933">Controle de contas</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="echars"><font face="Arial" color="#FF9933">Controle de Pjs.</font></td></a>
	</tr>
	<tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<a href="logout"><font face="Arial" color="#FF9933">
		Termina Sessao</font></td></a>
	</tr>
    <tr>
		<td style="border-style: solid; border-width: 2px; padding-left: 4px; padding-right: 4px" bordercolor="#A0A0A4">
		<font face="Arial" color="#FF9933">Donate nos por favor!</font>
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="image" src="https://www.paypal.com/es_XC/i/btn/x-click-but04.gif" border="0" name="submit" alt="Realice pagos con PayPal: es r�pido, gratis y seguro.">
        <img alt="" border="0" src="https://www.paypal.com/es_XC/i/scr/pixel.gif" width="1" height="1">
        <input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHRwYJKoZIhvcNAQcEoIIHODCCBzQCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYByq+ifgJSoa2Ea5vloiNeOlKq1w7Jjm2oaQnEj0WCRs47p29qWl/mVbTUveWbAuVu3bhYVS1PHKKbFyGCp6oBnqI9CTdEK5ZffJ//4+imnkMTbM6QAVs3lF/LpzWctTa5Gr5hpKPabRUbhxiEcswxQs5EhWpD/nKZrv5cP1/hWhzELMAkGBSsOAwIaBQAwgcQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIc5fP6r+4C9eAgaBaTr/gfAt2W1qisKo4o0fy5ypPVHDizjTUdjkeIc7oz4pMy6xi128kYtYnHDlq1Q84xfysrwUwGrnf38107nO+yMb9HQbPRc99zqb+KlSvEXt4jxERdAdtw+ie/w2cQXsA5H/UmosJ4AcAwfARF7XVCJJEA+Pw1ZRqm/YzyJ192ggvzRGoHcgcwin9BCBabeIss5R1gMFu/LKw9pcEDQY5oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMDcxMjEyMDM0NTM4WjAjBgkqhkiG9w0BCQQxFgQUTjsw7u9y1xVSbRdm+pGKI9UMCQYwDQYJKoZIhvcNAQEBBQAEgYA2MP4mpiLsmYg7pn6cqjBI+M7Nu3rNhITQjQwv9aF+w01GXfLurX3AYJpFr2xFU0rqarhrMEAdw4qUcop6t7TZzyKMJ3pm0FsdYNXnvhVRoN6ns5BkzQXMisl8KYONRpmcHFqEE1wWRoSsgI7phw2Xgqx+aK3Lki5J/QfgBY5HKQ==-----END PKCS7-----
        ">
        </form>
        </td>
	</tr>
	</table>


</body>
</html>
