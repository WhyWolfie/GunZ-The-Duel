<?php
/////Lo editamos con nuestros datos
$DBHost = 'KAISER-PC\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = '1';
$DB = 'usage';
?>
