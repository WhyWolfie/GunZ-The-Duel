<?php
SetTitle("AbberyGamerZ - userr");
if ($_SESSION['AID'] == "")
{
    SetURL("index.php?do=delclan");
    SetMessage("Donate", array("Para ver la lista del Staff deve logearse primero."));
    header("Location: index.php?do=login");
    die();
}
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Lista De Staff</font></b></td>
							  </tr>
								<tr>
            <td align="center" class="Estilo1"><table width="450" height="200" border="0" bgcolor="#151515">
              <tr>
                <td width="98" align="left" class="Estilo1"><font color="#D7D21C">&nbsp; </font><font color="#FF8000">Fundadores</font></td>
                <td width="110" align="left" class="Estilo1"><font color="#00FF00"> Administradores</font></td>
                <td width="81" align="left" class="Estilo1"><font color="#00FFFF">GamersMasters</font></td>
                <td width="93" align="left" class="Estilo1"><font color="#FF0000">Moderadores</font></td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#d80606">Usage - Kurama </font></p>
                  <p>&nbsp;</p>
                  </td>
                <td align="left" class="Estilo1">
                  <p> <img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00">Kurama</font></p>
                  <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00">Usage</font></p>
				  <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00">Kurama</font></p>
				   <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00">Usage</font></p>
				    <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00">Kurama</font></p>
                </td>
                <td align="left" class="Estilo1">
                  <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Usage3</font></p>
                  <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Kurama</font></p>
				  <p><img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Usage</font></p>
                </td>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Kurama</font></p>
				  <p align="left">&nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Usage</font></p>
                  <p> &nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FF00"> Usage</font></p>
                  </td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
              <tr>
                <td height="33" align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
            </table>
			</td>          
          </tr>
									
									</div>
								</tr>
							</table>
							</table>
						</div>
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
				</table>