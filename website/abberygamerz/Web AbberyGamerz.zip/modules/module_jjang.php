<?php
SetTitle("AbberyGamerZ - Comprar Jjang");
$precio = 100;			// Aqui el precio es decir el costo que tendra  el Grado.
$coins	= "Coins";  // Aqui el tipo de Coins que usas Como DonatorCoins, EventCoins

// SI QUIERES VENDER JJANG es 2 y si quieres vender MOD es 254 y si quieres vender BAN es 253 XDDDDDD
$grado = 2;



///////////////////////////////////////////









/*  NO TOCAR.  */
	if($_SESSION['AID'] == ""){
					msgbox("Logueate antes de entrar aqui.","index.php?do=login");
					die();
					}
					$g = (int)$grado;
					$p = (int)$precio;
					$aid = (int)$_SESSION['AID'];
				if(!isset($_POST['submit'])){
					
?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Compra de jjang</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
                                    <form method="post" name="xd">
								<table align="center">
                                <tr>
                                <td width="266" align="center">
                                Bienvenido a la Tienda De EuroGamers Gunz. en esta tienda podra Comprar Un Jjang.<br />
                                <br />								
								ahy otra manera de Conseguirlo y es por medio de un evento pero Creo Que sera Dificil Conseguirlo por eso les traigo esta Tienda de Jjang.<br />
                                  <br />
								Espero Que les guste El Jjang Cuesta 100 Coins y en el Event Se da por lo menos 200 Coins..<br />							
								<br />
								<span style="color:#00FF00; background: transparent url(http://tinyurl.com/outgum)"><b>Comprar Jjang</b></span> <br />
								<br />
								<b>Precio: </b><?=$precio?><br />
                                <input type="submit" name="submit" value="Comprar Jjang" />
                                </td>
                                </tr>
                                
                                </table>
                                </form>   
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
                
                <?PHP
								
					}else{
						$q = "SELECT $coins From Account WHERE AID='$aid'";
						$r = mssql_fetch_row(mssql_query($q));
						if($r[0] < $precio){
							$asd = $r[0];
							msgbox("No tiene Coins suficientes para hacer la compra.","index.php?do=donate");
							die();
							}
						$res = "UPDATE Account SET UGradeID='2', $coins=$coins-$precio WHERE AID='$aid'";
						mssql_query($res);
						msgbox("Su Compra se a realizado con exito Gracias por su compra By Staff.","index.php");
						die();
						}
				
				?>
				
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
<? //					 Coding By SackerZ
//						http://sackerz.blogspot.com/
?>