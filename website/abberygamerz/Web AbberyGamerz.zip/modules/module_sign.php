<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
if($_SESSION[AID] == "")
{
    SetMessage("Mensaje de AbberyGunz", array("Porfavor, Logueate primero."));
    SetURL("index.php?do=sign");
    header("Location: index.php?do=login");
    die();
}

if(isset($_POST[Checksubmit]))
{
    $pass = clean($_POST[CheckPass]);
    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Login(nolock) WHERE UserID = '{$_SESSION[UserID]}' AND Password = '$pass'")) == 1)
    {
        $_SESSION[Modify] = $_SESSION[AID];
    }else{
        SetMessage("Por Favor Verifique La Informacion", array("Contrase�a incorrecta."));
        $_SESSION[Modify] = 0;
        header("Location: index.php?do=sign");
        die();
    }
}

if($_SESSION[Modify] != $_SESSION[AID])
{
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">
										Login</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
										<form method="POST" action="index.php?do=sign" name="Firna Dinamica">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<div align="center">Porfavor, Coloca tu Contrase�a</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="177" style="background-repeat: no-repeat; background-position: center top">
												<div align="right">Contrase�a</td>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="209" style="background-repeat: no-repeat; background-position: center top">
												<input name="CheckPass" size="20" class="textLogin" style="float: left" type="password"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<div align="center">
												<input border="0" src="images/btn_continue_off.jpg" name="I1" width="136" height="22" id="img1337" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1337',/*url*/'images/btn_continue_on.jpg')" type="image"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
											<input type="hidden" name="Checksubmit" value="1"></form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<?
}else{



if(isset($_POST[submit]) && $_SESSION[Modify] == $_SESSION[AID])
{
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);

    $errors = array();

    if($pass[0] <> $pass[1])
        array_merge($errors, array("La contrase�a no Existe"));

    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'")) <> 0)
        array_merge($errors, array("El email esta en uso"));

    if($pass[0] <> "" || $pass[1] <> "")
        array_merge($errors, array("Porfavor Introduce tu contrase�a"));

    if($email <> "")
        array_merge($errors, array("Porfavor Introduce tu e-mail"));

    if($sq <> "")
        array_merge($errors, array("Porfavor Introduce tu Pregunta Secreta"));

    if($sa <> "")
        array_merge($errors, array("Porfavor Introduce tu Respuesta Secreta"));

    if(strlen($pass[0]) < 6)
        array_merge($errors, array("La Contrase�a debe ser minimo de 6 caracteres"));

    if(count($errors) == 0)
    {
        mssql_query_logged("UPDATE Account SET Email = '$email' WHERE AID = '{$_SESSION[AID]}'");

        if($_POST[C1] == "ON")
        {
	                  
	    mssql_query_logged("UPDATE Login SET Password = '".$pass[0]."' WHERE AID = '{$_SESSION[AID]}'");
            $_SESSION['Password'] = $pass[0];
        }
        if($_POST[C2] == "ON")
        {
            mssql_query_logged("UPDATE Account SET sq = '$sq', sa = '$sa' WHERE AID = '{$_SESSION[AID]}'");
        }
        SetMessage("Message De Sa GunZ", array("Cuenta Actualizada Perfectamente"));
        header("Location: index.php?do=sign");
        die();
    }else{
        SetMessage("Por Favor Verifique La Informacions", $errors);
        header("Location: index.php?do=sign");
        die();
    }
}else{
    SetTitle("AbberyGunz - Firma Dinamica");
    $europe = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

    $p = GetCountryCodeByIP($_SERVER[REMOTE_ADDR]);
    if(in_array(strtoupper($p), $europe))
    {
        $country = sprintf("[<font color='#00FF00'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }else{
        $country = sprintf("[<font color='#FF0000'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }

    $r = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));
    $a = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Login(nolock) WHERE AID = {$_SESSION[AID]}"));

    $_MEMBER[UserID]        = $r[UserID];
    $_MEMBER[EMail]         = $r[Email];
    $_MEMBER[SA]            = $r[sa];
    $_MEMBER[SQ]            = $r[sq];
}


?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Firma Dinamica </font></b></td>
								</tr>
								<tr>
								  <td bgcolor="#2C2A2A"><table width="439" border="0">
                                        <tr>
                                          <td width="433" valign="top"><?
if ($_SESSION['AID'] == ""){
    alertbox("Login first!","index.php");
    die();
	}
	    $signing = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."'AND CharNum != '-1'");

    if( mssql_num_rows($signing) < 1 )
    {
    alertbox("You dont have any Character.","index.php");
        die();
    }
?>
<script type="text/javascript">
    function UpdateSign()
    {
        var cid = document.signature.charlist.value;
        var sign = document.getElementById("sign");
        sign.innerHTML = '<img src="sign.php?cid='+ cid + '" />';
        document.signature.forumcode.value = '[URL="http://AbberyGunz.com/index.php?module=sign"][IMG]AbberyGunz.com/sign.php?cid=' + cid + '[/IMG][/URL]';
        document.signature.directlink.value = "http://AbberyGunz.com/sign.php?cid=" + cid + "";
    }

</script>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="433" height="265" border="0" align="center">
  <tr>
    <td width="10" height="261" align="center" valign="top">&nbsp;</td>
    
    <td width="564" align="center" valign="top"><table width="422" height="214" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="214" align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27">&nbsp;</td>
                  <td height="30" class="estilo6"><strong>Firma Dinamica de AbberyGunz</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><form name="signature"><table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td class="Estilo1" align="center">Seleccione su Personaje <select size="1" name="charlist" onchange="UpdateSign()" class="login">
                                                <?
                                                while( $data = mssql_fetch_row($signing) )
                                                {
                                                ?>
                                                    <option value="<?=$data[0]?>"><?=$data[1]?></option><br />';
                                                <?
                                                }
                                                ?>
												</select></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center"><span id="sign"></span></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center">Codigo para foro<br><input type="text" name="forumcode" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;" class="login"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center">Link directo<br><input type="text" name="directlink" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;" class="login"></td>
              </tr> <script type="text/javascript">
                                            UpdateSign();
                                            </script>
            </table></form></td>
          </tr>
          <tr>
            <td height="22" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</td>
                                        </tr>
                                        
                                      </table></td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table></td>    <?}?>&nbsp;