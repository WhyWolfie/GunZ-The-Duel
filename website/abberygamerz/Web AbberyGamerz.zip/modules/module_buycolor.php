<?
SetTitle("AbberyGamerZ- Cambiar Name Color");
if(empty($_SESSION['AID'])){
	?>
	<script>
	alert('Necesitas Iniciar Sesion para acceder a este modulo');
	</script>
	<meta http-equiv="refresh" content="0;url=index.php"/>
	<?
	die();
}
$selectu = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
$rowc = mssql_fetch_array($selectu);

if($rowc['UGradeID'] == 0){
	$color = "Noob";
}elseif($rowc['UGradeID'] == 2){
	$color = "<font color='lightblue'>Jjang</font>";
}elseif($rowc['UGradeID'] == 3){
	$color = "<font color='#FF00FF'>Rosa</font>";
}elseif($rowc['UGradeID'] == 4){
	$color = "<font color='#FFFF00'>Amarillo</font>";
}elseif($rowc['UGradeID'] == 5){
	$color = "<font color='#8000FF'>Morado</font>";
}elseif($rowc['UGradeID'] == 6){
	$color = "<fotn color='#0000FF'>Azul</font>";
}elseif($rowc['UGradeID'] == 7){
	$color = "<font color='#000000'>Negro</font>";
}elseif($rowc['UGradeID'] == 255){
	$color = "<font color='#FF0000'>Administrador</font>";
}elseif($rowc['UGradeID'] == 254){
	$color = "<font color='#00FF00'>Moderador</font>";
}elseif($rowc['UGradeID'] == 252){
	$color = "<font color='#FF8000'>GamersMaster</font>";
}



$costo = 70;
if(isset($_POST['submit'])){
$color	= $_POST['colorid'];
$aid 	= $_SESSION['AID'];
$q 		= mssql_query("SELECT Coins From Account WHERE AID='$aid'");
$acc 	= mssql_fetch_object($q);
$coins = $acc->Coins;
$total = $coins - $costo ;
if($coins < $costo){
SetMessage("Compra Name Color", array("No tiene $coins suficiente Coins para realizar la compra."));
	header("Location: index.php?do=shop");
	die();
}
if(!is_numeric($color)){
SetMessage("Compra Name Color", array("Error al hacer la compra"));
	header("Location: index.php?do=shop");
	die();
}
if(!is_numeric($aid)){
	SetMessage("Compra Name Color", array("Error al hacer la compra2"));
	header("Location: index.php?do=shop");
	die();
}else{
mssql_query("UPDATE Account SET Coins='$total' WHERE AID='$aid'");
mssql_query("UPDATE Account SET UGradeID='$color'  WHERE AID='$aid'");
SetMessage("Compra Name Color", array("Compra de name color con exito."));
	header("Location: index.php?do=shop");
	die();
	}
}
?>
<form method="POST">
<html>

<head>
   <link rel="stylesheet" type="text/css" href="style.css">

  </head>

<body style="background: #373737 url('./images/headbg.jpg') no-repeat center top" bgcolor="black">
<div align="center">
    <table style="border: 0px; border-collapse: collapse; width: 90%">
    <tr>
        <td align="center">&nbsp;</td>
    </tr>
    <tr>
        <td>

        <div align="center">
		            
            <table style="border: 0px; padding: 0px; width: 800px">
            
            <tr>
                <td width="10">&nbsp;</td>
                <td width="778">
                    <table border="0" style="border-collapse: collapse" width="778">

<tr>
    <td width="164" valign="top">
    <table border="0" style="border-collapse: collapse" width="164">
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;</td>
    </tr>
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
        <div align="center">

            <table border="0" style="border-collapse: collapse" width="164">
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shop">
                        
                        <img alt="home" name="home" border="0" src="images/btn_newestitems_off.jpg" width="132" height="22" onMouseOut="document.home.src='images/btn_newestitems_off.jpg'" onMouseOver="document.home.src='images/btn_newestitems_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopdonator">
                        
                        <img alt="donator" border="0" src="images/btn_donatoritems_off.jpg" width="132" height="26">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopevent">
                        
                        <img alt="event" name="event" border="0" src="images/btn_eventitems_off.jpg" width="132" height="26" onMouseOut="document.event.src='images/btn_eventitems_off.jpg'" onMouseOver="document.event.src='images/btn_eventitems_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopsets">
                        
                        <img alt="sets" name="sets" border="0" src="images/btn_completeset_off.jpg" width="132" height="26" onMouseOut="document.sets.src='images/btn_completeset_off.jpg'" onMouseOver="document.sets.src='images/btn_completeset_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopitem&amp;cat=3">
                        
                        <img alt="armor" name="armor" border="0" src="images/btn_armor_off.jpg" width="132" height="25" onMouseOut="document.armor.src='images/btn_armor_off.jpg'" onMouseOver="document.armor.src='images/btn_armor_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopitem&amp;cat=2">
                        
                        <img alt="melee" name="melee" border="0" src="images/btn_meleeweapons_off.jpg" width="132" height="25" onMouseOut="document.melee.src='images/btn_meleeweapons_off.jpg'" onMouseOver="document.melee.src='images/btn_meleeweapons_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopitem&amp;cat=1">
                        
                        <img alt="ranged" name="ranged" border="0" src="images/btn_rangedweapons_off.jpg" width="132" height="27" onMouseOut="document.ranged.src='images/btn_rangedweapons_off.jpg'" onMouseOver="document.ranged.src='images/btn_rangedweapons_on.jpg'">
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopitem&amp;cat=5">
                        
                        <img alt="special" name="special" border="0" src="images/btn_specialitems_on.jpg" width="132" height="23" >
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            </table>
        </div>
        </td>
    </tr>
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
            <div align="center"><br><br><br><br><br><br><br><br></div>
        </td>

    </tr>
    </table>
    </td>
	<td width="599" valign="top">
	<div align="center">
    <table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
<tr>
	<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
</tr>
<tr>

	<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
	<td width="7">&nbsp;</td>
	<td width="583" valign="top">
	<div align="center">
		<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%">
    	<tr>
    		<td>
    		<div align="center">

    			                <table border="0" style="border-collapse: collapse" width="579">
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="458" colspan="2">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>

  					<td width="104" valign="top">
                        <STYLE type="text/css">
                        OPTION{ background-color: #202020 }
                        OPTION.rose{color:#af00b2; font-weight: bold }
                        OPTION.pink{color:#9900FF; font-weight: bold }
                        OPTION.blue{color:#0066FF; font-weight: bold }
                        OPTION.green{ color:#00CC00; font-weight: bold }
						OPTION.gold{color:#15b1ec; font-weight: bold }
						OPTION.blanco{color:#FFFFFF; font-weight: bold }
                        </STYLE>
                        <div align="center">
      					    <img alt="" border="0" src="images/shop/changeclanname.gif" width="100" height="100" style="border: 2px solid #1D1B1C">
                        </div>
                    </td>
  					<td width="458" colspan="2">
  					<div align="center">

  						<table border="0" style="border-collapse: collapse" width="458" height="100%">
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="435" colspan="2">
  								<div align="left">
  								    <b><font size="2">Nombre de Color</font></b>
                                </div>
                                </td>

  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="61" align="left"><font color="#ff0000">Tipo:</font></td>
  								<td width="372" align="left">Especial</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>

  								<td width="61" align="left"><font color="#kff000">Precio:</font></td>
  								<td width="372" align="left">
  								    <span id="currentprice"><?=$costo?></span>
                                </td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">

  								<div align="center">
                                    Selecciona el Color para tus Personajes:&nbsp;&nbsp;
                                    
			
                                    <select class="rose" name="colorid">
									<option selected class="blanco" value="0">Sin Color</option>
                                      <option selected class="blue" value="5">Azul</option>
                                      <option class="green" value="3">Verde</option>
                                      <option class="pink" value="4">Morado</option>
                                      <option class="rose" value="6">Fucsia</option>
                                      <option class="gold" value="7">Celeste</option>
                                    </select>
  								</div>
								<div align="center">
								<tr>
								Tu Actual Name Color Es: <?=$color?>
								<p />
								</tr>
								</div>
  								</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>

  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>

  						</table>
  					</div>
  					</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  					<td width="435" align="left" rowspan="4">

  					<div align="center">
  						<table border="0" style="border-collapse: collapse" width="435" height="66">
  							<tr>
  								<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
  								<div align="center">
  									<table border="0" style="border-collapse: collapse" width="419" height="16%">
  										<tr>
  											<td width="216">&nbsp;</td>
  											<td width="102" align="left">Precio</td>

  											<td width="67" align="left"><?=$costo?> Coins</td>
  											<td width="16">&nbsp;</td>
  										</tr>
  										<tr>
                                        <? $wa = mssql_query("SELECT * From Account WHERE AID='$_SESSION[AID]'");
										$cuen = mssql_fetch_object($wa);
										$coins = $cuen->Coins?>
  											<td width="216">&nbsp;</td>
  											<td width="102" align="left">Despues</td>
  											<td width="67" align="left"><?=$coins- $costo?></td>

  											<td width="16">&nbsp;</td>
  										</tr>
  									
  										<tr>
  											<td colspan="4" height="1"></td>
  										</tr>
  									</table>
  								</div>
  								</td>
  								<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
  							</tr>
  						</table>

  					</div>
  					</td>
  				</tr>
  							
  				<tr>
  					<td width="569" colspan="4">&nbsp;</td>
  				</tr>
    			</table>
    			</form>
    		</div>
    		</td>
    	</tr>
		</table>

	</div>
	</td>
	<td width="7">&nbsp;</td>
</tr>

<tr>
	<td width="597" colspan="3">
	<div align="center">
	  <p>
	    <input name="submit" type="submit" style="background:#999" value="Comprar Name Color">
	   <a href="?do=shop"> <input name="salir" type="button" style="background:#999" value="Salir" ></a>
	    
	    </form>
	    </p>
<!-- BEGIN SMOWTION TAG - 468x60 - DO NOT MODIFY -->
<script type="text/javascript"><!--
smowtion_size = "468x60";
smowtion_section = "2623363";
//-->
</script>
<a href="http://www.linkbucks.com/referral/561748"><img src="http://www.linkbucks.com/tmpl/mint/img/468_60link_bucks.gif" width="468" height="60" border="0"></a>
<!-- END SMOWTION TAG - 468x60 - DO NOT MODIFY -->
	</div>
    </td>
</tr>
<tr>
	<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>

</tr>
</table>
    </div>
    </td>
</tr>
</table>
                </td>
                <td width="12">&nbsp;</td>
            </tr>
           
            </table>
        </div>
        </td>
    </tr>

    </table>
</div>



</body>

</html>

