<?
header("Location: http://forumeurogamersgunz.foro.bz//");
?>