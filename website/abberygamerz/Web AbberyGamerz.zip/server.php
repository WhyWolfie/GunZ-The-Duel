<table width="400" height="360" border="0" align="center" background="images/bg_serverstat.png" style="background-repeat:no-repeat; background-position:center">
  <tr>
    <td valign="top"><table width="390" height="350" border="0" align="center">
      <tr>
        <td height="21">&nbsp;</td>
      </tr>
      <tr>
        <td><div align="center">
          <table width="380" border="0">
            <tr>
              <th colspan="6" class="Estilo6" scope="col">Server Status</th>
              </tr>
            <tr>
              <th width="14" scope="col">&nbsp;</th>
              <th width="102" scope="col" align="left" class="Estilo3">Quest Server :</th>
              <th width="131" scope="col" class="Estilo2"><?php

//Total Players
$query = mssql_query("SELECT * FROM ServerStatus"); 
$row = mssql_fetch_row($query); 
$players = $row[1]; 
echo "$players / 1000"; 

?></th>
              <th width="61" scope="col">&nbsp;</th>
              <th width="29" scope="col">
                <? 
$ip = "127.0.0.1"; 
$port = "6000"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1" face="verdana">Apagado</font>'; 
else{ 
echo '<font color="#00FF00" size="1" face="verdana">Prendido</font>'; 
fclose($sock); 
} 
?></th>
              <th width="17" scope="col">&nbsp;</th>
            </tr>
            <tr>
              <th scope="col">&nbsp;</th>
              <th height="20" scope="col" align="left" class="Estilo3">Clan Server :</th>
              <th scope="col"  class="Estilo1">&nbsp;</th>
              <th scope="col">&nbsp;</th>
              <th scope="col"><font face: "verdana">
                <? $ip = "127.0.0.1"; 
$port = "6005"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1" face="verdana">Apagado</font>'; 
else{ 
echo '<font color="#00FF00" size="1" face="verdana">Prendido</font>'; 
fclose($sock); 
} 
?>
              </font></th>
              <th scope="col">&nbsp;</th>
            </tr>
            <tr>
              <th height="20" colspan="6" scope="col" class="Estilo1"><img src="img/line.png" width="360" height="2"></th>
            </tr>
            <tr>
              <th height="20" colspan="6" class="Estilo6" scope="col">NAT Status</th>
              </tr>
            <tr>
              <th scope="col">&nbsp;</th>
              <th height="20" scope="col" align="left" class="Estilo3">Quest (NAT) : </th>
              <th scope="col">&nbsp;</th>
              <th scope="col">&nbsp;</th>
              <th scope="col"><font face: "verdana">
                <? 
$ip = "127.0.0.1"; 
$port = "7777"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1" face="verdana">Apagado</font>'; 
else{ 
echo '<font color="#00FF00" size="1" face="verdana">Prendido</font>'; 
fclose($sock); 
} 
?>
              </font></th>
              <th scope="col">&nbsp;</th>
            </tr>
            <tr>
              <th scope="col">&nbsp;</th>
              <th height="20" scope="col" align="left" class="Estilo3">Clan (NAT) : </th>
              <th scope="col">&nbsp;</th>
              <th scope="col">&nbsp;</th>
              <th scope="col"><font face: "verdana">
                <? $ip = "127.0.0.1"; 
$port = "7778"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1" face="verdana">Apagado</font>'; 
else{ 
echo '<font color="#00FF00" size="1" face="verdana">Prendido</font>'; 
fclose($sock); 
} 
?>
              </font></th>
              <th scope="col">&nbsp;</th>
            </tr>
            <tr>
              <th height="20" colspan="6" scope="col"><span class="Estilo1"><img src="img/line.png" width="360" height="2"></span></th>
            </tr>
            <tr>
              <th height="14" colspan="6" scope="col" class="Estilo3"><? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Total De Cuentas: ".$num_rows."<n>
<p>"; 
 
?></th>
            </tr>
            <tr>
              <th height="14" colspan="6" scope="col" class="Estilo3"><?php
 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Total De Personajes: ".$num_rows."<n><p>";

?></th>
            </tr>
            <tr>
              <th height="14" colspan="6" scope="col" class="Estilo3">Rate Exp: 25x | Rate Bounty: 25x</th>
            </tr>
          </table>
        </div></td>
      </tr>
    </table></td>
  </tr>
</table>
