<?
$res = mssql_query("SELECT TOP 5 * FROM Account a, Character b WHERE b.AID=a.AID AND a.UGradeID !=255|254|253|252 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo1 {color: #090912}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
<table background="images/md_ir.jpg"  width="176" height="141" border="0">
<tr>
    <td><table width="158" height="96" border="0" style="border-collapse: collapse">
      <tr>
        <td width="14" rowspan="6">&nbsp;</td>
        <td height="33" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No Data &laquo; </div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="7" align="left">
  															<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
  															<td width="104" align="left">
         <?=$user['Name']?></td>
       <td width="27" align="left">
           <?=$user['Level']?></td>
      </td>
      </tr>
      <?}}?>
    </table>    <td height="35"></tr>
</table>
