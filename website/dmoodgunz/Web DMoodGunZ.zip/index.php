<?
include("secure/config.php");
include("secure/functions.php");
include("secure/include.php");
include("secure/banneduser.php");
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";
include "IpBan/ipban.php";
checar_baneo_ip($_SERVER['REMOTE_ADDR']);

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Invalid Access "," Invalid Account Access");
        redirect("index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Invalid Access", "Invalid Account Access");
            redirect("index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "DMood Gamers Gunz", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>%TITLE%</title>
<link href="/favicon/SpetGz.ico" rel="shortcut icon" />
<script language="Javascript">
function disableselect(e){
return false
}

function reEnable(){
return true
}

document.onselectstart=new Function ("return false")

if (window.sidebar){
document.onmousedown=disableselect
document.onclick=reEnable
}

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
loadImage0 = new Image();
loadImage0.src = "images/nav-home_on.png";
staticImage0 = new Image();
staticImage0.src = "images/nav-home.png";

loadImage1 = new Image();
loadImage1.src = "images/nav-reg_on.png";
staticImage1 = new Image();
staticImage1.src = "images/nav-reg.png";

loadImage2 = new Image();
loadImage2.src ="images/nav-down_on.png";
staticImage2 = new Image();
staticImage2.src = "images/nav-down.png";

loadImage3 = new Image();
loadImage3.src = "images/nav-logo_on.png";
staticImage3 = new Image();
staticImage3.src = "images/nav-logo.png";

loadImage4 = new Image();
loadImage4.src = "images/nav-clan_on.png";
staticImage4 = new Image();
staticImage4.src = "images/nav-clan.png";

loadImage5 = new Image();
loadImage5.src = "images/nav-mark_on.png";
staticImage5 = new Image();
staticImage5.src = "images/nav-mark.png";

loadImage6 = new Image();
loadImage6.src = "images/nav-com_on.png";
staticImage6 = new Image();
staticImage6.src = "images/nav-com.png";

loadImage7 = new Image();
loadImage7.src = "images/donate_on.png";
staticImage7 = new Image();
staticImage7.src = "images/donate.png";

loadImage8 = new Image();
loadImage8.src = "images/ranking_on.png";
staticImage8 = new Image();
staticImage8.src = "images/ranking.png";

loadImage9 = new Image();
loadImage9.src = "images/login_btn_on.png";
staticImage9 = new Image();
staticImage9.src = "images/login_btn.png";

loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";
// En

//-->
</script>
<link rel="stylesheet" type="text/css" href="e_style.css">
<style type="text/css">
#header .nav .hide-scrollbars a strong {
	font-size: 12pt;
}
</style>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/bg40.jpg') no-repeat center top; font-size: 18px;">
<tr>
	<td width="800"><p align="center">
  <html>
	  <head>
	  <title>Menu Desplegable</title>
	  <style type="text/css">
			
			* {
				margin:0px;
				padding:0px;
			}
			
			#header {
				margin:auto;
				width:500px;
				font-family:Arial, Helvetica, sans-serif;
			}
			
			ul, ol {
				list-style:none;
			}
			
			.nav > li {
				float:left;
			}
			
			.nav li a {
				background-color:#000;
				color:#fff;
				text-decoration:none;
				padding:10px 12px;
				display:block;
			}
			
			.nav li a:hover {
				background-color:#434343;
			}
			
			.nav li ul {
				display:none;
				position:absolute;
				min-width:140px;
			}
			
			.nav li:hover > ul {
				display:block;
			}
			
			.nav li ul li {
				position:relative;
			}
			
			.nav li ul li ul {
				right:-140px;
				top:0px;
			}
			
		</style>
	  </head>
	  <body>
	  <div id="header">
	  <ul class="nav">
      <li class="fondo"><a href="index.php"><strong>INICIO</strong></a></li>
		<li class="fondo"><a href="index.php?do=register"><strong>REGISTRO</strong></a></li>
        <li class="fondo"><a href="index.php?do=register"><strong>FORO</strong></a></li>
		<li><a href="" class="fondo"><strong>DESCARGAS</strong></a>
			<ul>
				<li><a href="" class="fondo"><strong>MEDIA FIRE</strong></a></li>
				<li><a href="" class="fondo"><strong>MEGA</strong></a>						</li>
		  </ul>
	  </li>
		<li><a href="" class="fondo"><strong>RANKING</strong></a>
			<ul class="fondo">
			  <li><a href="index.php?do=individualrank"><strong>PLAYERS</strong></a></li>
				<li><strong><a href="index.php?do=clanrank">CLAN</a></strong></li>
		  </ul>
      <li><strong><span class="fondo"><a href="">ITEMS SHOP</a>
		  </span>
      </strong>
        <ul>
			<li class="fondo"><strong><a href="index.php?do=shopitem&cat=1">ITEMS DONATOR</a></strong></li>
            <li class="fondo"><strong><a href="index.php?do=shopitem&cat=5">ITEMS SPECIAL</a></strong></li>
            <li class="fondo"><strong><a href="index.php?do=shopsets">SET COMPLENTES</a></strong></li>
		  <li class="fondo"><strong><a href="index.php?do=shopevent">ITEMS EVENT</a></strong></li>
          <li class="fondo"><strong><a href="index.php?do=nicks">NICK NAMES</a></strong></li>
        </ul>
	  <p>&nbsp;</p>
	  </div>
</body>
</html>&nbsp;</p>

              
          </td>
		</tr>
			
	<tr>
			<td>
		<div align="center">
		</p>
		<table border="0" cellpadding="0" cellspacing="0" width="800">
		<td height="259">&nbsp;</td>
        <tbody>
		  
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {   
                SetMessage("", array("DMood Gamers Gunz es un Servidor completamente gratis!",
                "<a href=\"index.php?do=register\"><b>Click aqui </b>para el registro</a>"));
                
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("An error has ocurred", array("Module '$do' not found"));
                    redirect("index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>
			<?
        if(empty($_GET['do'])){
            ?>
            <?
$selectF = "SELECT TOP 5 * FROM ClanGameLog ORDER BY id DESC";
$queryF = mssql_query($selectF);
$rowsF = mssql_num_rows($queryF);
            ?>
            <section style="background:#000000;color:white;"> </section> 
            <?
        }
        ?> 
			</td>
            
                  
            </tbody></table>
          </div>
          	</td>
	</tr>
  </table>
</div>
<p><?
if(empty($_GET['do'])){
?>
<?
$selectF = "SELECT TOP 5 * FROM ClanGameLog ORDER BY id DESC";
$queryF = mssql_query($selectF);
$rowsF = mssql_num_rows($queryF);
?>
<section style="text-align:center;background:#2c2cc;color:white;text-shadow:0px 0px 5px black;padding:20px;font-weight:bold;"> 
  <p>.:: <span class="default">Ultimos Clan Wars de DMood Gamers Gunz</span>::.</p></section>
<section style="background:#000000;color:white;">
<center>
<style>
#cw tr td{
background:#333;
padding:5px;
}
#cw tr th{
padding:10px;
background:#555;
}
</style>
<table id="cw" style="padding:10px;font-weight:bold;font-size:16px;display:inline-block;">
<tr>
<th>Clan Winner</th>
<th>Points Won</th>
<th>|</th>
<th>Clan Loser</th>
<th>Lost points</th>
</tr>
<?if($rowsF>0){while($rowF = mssql_fetch_array($queryF)){?>
<tr>
<td align="center"><a href="index.php?do=claninfo&id=<?=$rowF['WinnerCLID']?>"><?=$rowF['WinnerClanName']?></a></td>
<td align="center"><font color="green">+ <?=$rowF['WinnerPoint']?></font></td>
<td align="center">|</td>
<td align="center"><a href="index.php?do=claninfo&id=<?=$rowF['LoserCLID']?>"><?=$rowF['LoserClanName']?></a></td>
<td align="center"><font color="red">- <?=$rowF['LoserPoint']?></font></td>
</tr>
<?}}else{?><tr><td colspan="2">No Hay Datos</td></tr><?}?>
</table>
<p><img src="images/j.jpg" border="0" alt="Utech Gunz" width="400" height="300"></p>
</center>
</section>
<?
}
?>&nbsp; </p>
<script language="JavaScript">
	function tecla() 
	{
	if (event.keyCode==123)
	{
	event.keyCode=0;
	event.returnValue=false;
	}
	} document.onkeydown=tecla;
  </script>
</html>