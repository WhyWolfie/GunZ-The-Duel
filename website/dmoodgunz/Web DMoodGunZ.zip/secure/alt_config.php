<?php
require('functions.php');
class connect
{
  var $host = "WIN-IK5BN0C64ND\SQLEXPRESS";
  var $user = "sa";
  var $pass = "noce123!aA";
  var $dbn  = "GunzDB";

  public function __construct()
  {
    $con = mssql_connect($this->host, $this->user, $this->pass) or die("<center><font color='red'>Failed to connect to the database!</font></center>");
    mssql_select_db($this->dbn, $con) or die("<center><font color='red'>Failed to select the database!</font></center>");
  }
}
new connect();
?>