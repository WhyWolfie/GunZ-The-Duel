<?php
    header('Content-type: text/html; charset=iso-8859-1');
    require('alt_config.php');
?>

                        <table border="0" class="rankingtbl">
                            <tr height="40px"><td width="80px" class="titlestrong">Name</td><td width="80px" class="titlestrong">Leader</td><td width="60px" class="titlestrong">Points</td><td width="60px" class="titlestrong">Wins</td><td class="titlestrong">Losses</td></tr>
                        <?php
                        $name = clean($_GET['name']);
                        $query = mssql_query("SELECT TOP 18 Clan.Name, Clan.Point, Clan.Wins, Clan.Losses, Character.Name AS Leader FROM Clan INNER JOIN Character ON Clan.MasterCID = Character.CID WHERE (Clan.DeleteFlag = 0) AND (Character.DeleteFlag = 0) AND(Clan.Name LIKE '%".$name."%') ORDER BY Clan.Point DESC");
                        while($row = mssql_fetch_row($query))
                        {
                            echo '<tr><td><a href="?page=claninfo&name='.$row[0].'">'.$row[0].'</a></td><td><a href="?page=charinfo&name='.$row[4].'">'.convertcolor($row[4]).'</a></td><td>'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td></tr>';
                        }
                        ?>
                        </table>