<p><strong><font size="6">Baneado</font></strong><br>
  <br>
El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP.<br>
</p>
<hr>
<p> 
  <em>Usted ah sido baneado Por el equipo de staff de Utech Gunz.</em></p>
