<?php

function setmsg($msg)
{
	echo ''.$msg.'';
}

?>