<?php
if( !session_start() )
{
    session_start();
}
require "config/config.php";
include "config/functions.php";
$langfile = "config/{$_CONFIG[Language]}.php"; 
include $langfile;

$connection = connect();
?>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?=$bienvenidos ?></title> 
<style type="text/css">
<!--
body
{
	background:url("http://img194.imageshack.us/img194/4671/interfacegatito1fw.jpg") #000;
	color: #CCC; 
	font-family:Arial;
	margin:0px; 
	padding:0px;
}
td,th
{
	color: #FFFFFF;
	font-family:Arial;
}
a {
	color: #FFFFFF; font-family:Arial;
}

input {
    border: 1px solid #666;
    color: #999;
    background: #333;
    font-family:Trebuchet MS;
    font-size: 11pt
}
.cred {
	color: #FFF300;
	font-size: 16px;
	font-family: "Trebuchet MS";
	font-weight: bold;
	text-decoration: underline;
}
.bg1{ background: #333 repeat;width:200px;mini-height:400px;opacity: 0.7; filter:alpha(opacity = 70)}
.bg2{ background: #333 repeat;width:470px;mini-height:400px;opacity: 0.7; filter:alpha(opacity = 70)}
</style>
<script type="text/javascript" src="config/functions.js"></script>

<body topmargin="0">
<table width="1000" height="40" align="center">
			  <tr>
					<td height="2" align="center"></td>
	</tr>
				<tr>
					<td height="30" align="center"></td>
    				<td align="center" style="background:url(images/bg_textmove.png) no-repeat; height:30px;">
					
					<marquee scrolldelay="100" width="998" dir="ltl" style="vertical-align:text-top;"><font color="#FFFFFF" size="+1" style="font:Helvetica, Arial, sans-serif;">BIENVENIDOS AL PANEL CREADO POR GATITO - SKIHGAMERZ 2013.2014�  </font></marquee> 
					
					</td>
  				</tr>
</table>

		 
		 </div>
	</center>	

    <?php
// Panel By SkihGamerZ - jorgin__@hotmail.com

if( $_SESSION['AID'] == "" )
{
    if( isset($_POST['login']) )
    {
        login();
    }
    else
    {

?>
   
    <center>
    
    <form name="login" method="POST" action="index.php">
    <?php showmessage(); ?>
        <table width="30%" border="0" style="border-collapse: collapse; margin-top:250px" id="login">
        <tr>
        <td><p><b><? echo $_STR[CSACKER1]; ?></b></p></td>
        </tr>
        </table>
        <table width="30%" border="0" style="border-collapse: collapse; margin-top:0px" id="login">
            <tr>
                <td colspan="2" align="center"><b><?php printf( $_STR[Login0] ); ?></b></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td width="40%" align="center"><?php printf( $_STR[Login1] ); ?>:</td>
                <td align="center"><input type="text" name="userid" /></td>
            </tr>
            <tr>
                <td align="center"><?php printf( $_STR[Login2] ); ?>:</td>
                <td align="center"><input type="password" name="password" /></td>
            </tr>
            <tr>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <input type="submit" name="login" value="<?php printf( $_STR[Login3] ); ?>" />
                </td>
            </tr>
        </table>
    </form>
</center>

<?php
    }
}

if( $_SESSION['AID'] != "" )
{
    check_ugradeid();

    switch($_GET['do'])
    {
        case "notepad":
            $includefile = "sacker/notepad.php";
            $title = $_STR[SACKER3];
            break;
        case "ascii":
            $includefile = "sacker/ascii.php";
            $title = $_STR[SACKER4];
            break;
		case "topdcoins":
            $includefile = "sacker/topdcoins.php";
            $title = $_STR[SACKER30];
            break;
		case "topecoins":
            $includefile = "sacker/topecoins.php";
            $title = $_STR[SACKER31];
            break;
	case "account":
            $includefile = "sacker/account.php";
            $title = $_STR[SACKER11];
            break;
	case "login":
            $includefile = "sacker/login.php";
            $title = $_STR[SACKER20];
            break;
	case "character":
            $includefile = "sacker/character.php";
            $title = $_STR[SACKER12];
            break;
        case "search":
            $includefile = "sacker/search.php";
            $title = $_STR[SACKER5];
            break;
		case "buscarid":
            $includefile = "sacker/buscarid.php";
            $title = $_STR[SACKER29];
            break;
        case "accounts":
            $includefile = "sacker/accounts.php";
            $title = $_STR[SACKER6];
            break;
        case "characters":
            $includefile = "sacker/characters.php";
            $title = $_STR[SACKER7];
            break;
        case "clans":
            $includefile = "sacker/clans.php";
            $title = $_STR[SACKER9];
            break;
        case "additem":
            $includefile = "sacker/additem.php";
            $title = $_STR[SACKER15];
            break;
        case "additem2":
            $includefile = "sacker/additem2.php";
            $title = $_STR[SACKER16];
            break;
		case "additem3":
            $includefile = "sacker/additem3.php";
            $title = $_STR[SACKER24];
            break;
		case "additem4":
            $includefile = "sacker/additem4.php";
            $title = $_STR[SACKER26];
            break;
		case "namecolor":
            $includefile = "sacker/namecolor.php";
            $title = $_STR[SACKER27];
            break;
        case "banuser":
            $includefile = "sacker/banormal.php";
            $title = $_STR[SACKER17];
            break;
        case "banip":
            $includefile = "sacker/banip.php";
            $title = $_STR[SACKER18];
            break;
        case "evcoins":
            $includefile = "sacker/darevcoins.php";
            $title = $_STR[SACKER19];
            break;
		case "dcoins":
            $includefile = "sacker/dcoins.php";
            $title = $_STR[SACKER25];
            break;
        case "char":
            $includefile = "sacker/character.php";
            $title = $_STR[SACKER20];
            break;
        case "scoins":
            $includefile = "sacker/scoins.php";
            $title = $_STR[SACKER22];
            break;
		case "news":
            $includefile = "sacker/news.php";
            $title = $_STR[SACKER23];
          	break;
		case "enews":
            $includefile = "sacker/enews.php";
            $title = $_STR[SACKER28];
            break;			
        case "logout":
            logout();
            break;
        default:
            $includefile = "sacker/panel.php";
            $title = $_STR[SACKER2];
            break;

    }
?>

<div align="center">
<table border="0" width="85%" style="border-collapse: collapse;margin-top:190px;" id="main" cellspacing="0" cellpadding="0" align="center">
	<tr>
		
		
	  <td ></td>
	</tr><!-- Panel By Gatito - jorgin__100@hotmail.com -->
	<tr>
		<td valign="top" width="220" background="images/panel_l_d.jpg">
			<table border="0" width="250" cellspacing="0" cellpadding="0">
			<tr>
            <!-- Imagen del SACKER --> 
		<td valign="top" height="535" class="bg1"> </center>
        <table width="250" cellpadding="0" cellspacing="1">
				<tr>
						<td valign="top" height="2"></td>
					</tr>
					<tr>
						<td height="25" colspan="2" align="center"><?=$_SESSION[UserID]?>, <a href="index.php?do=logout">cerrar</a></td>
					  </tr>
					<tr>
					  <td></td>
					  <td width="189"><a href="index.php?do=account"><font size="2"><?php echo $_STR[SACKER11]; ?></font></a></td>
					  </tr>
                    <tr>
					  <td></td>
					  <td><a href="index.php?do=topdcoins"><font size="2"><?php echo $_STR[SACKER30]; ?></font></a></td>
					  </tr>
                     <tr>
					  <td></td>
					  <td><a href="index.php?do=topecoins"><font size="2"><?php echo $_STR[SACKER31]; ?></font></a></td>
					  </tr>
					<tr>
					  <td></td>
					  <td><a href="index.php?do=char"><font size="2"><?php echo $_STR[SACKER21]; ?></font></a></td>
					  </tr>					
					<tr>
					  <td></td>
					  <td><a href="index.php?do=login"><font size="2"><?php echo $_STR[SACKER20]; ?></font></a></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td><a href="index.php?do=news"><font size="2"><?php echo $_STR[SACKER23]; ?></font></a></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td><a href="index.php?do=enews"><font size="2"><?php echo $_STR[SACKER28]; ?></font></a></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td><a href="index.php?do=banuser"><font size="2"><?php echo $_STR[SACKER17]; ?></font></a></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td><a href="index.php?do=namecolor"><font size="2"><?php echo $_STR[SACKER27]; ?></font></a></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td>//Type DCoins</td>
					  </tr>                      
					<tr>
					  <td>
                      </td>
					  <td><a href="index.php?do=scoins"><font size="2"><?php echo $_STR[SACKER22]; ?></font></a></td>					  </tr>
                      <tr>
					  <td></td>
					  <td><a href="index.php?do=evcoins"><font size="2"><?php echo $_STR[SACKER19]; ?></font></a></td>
					  </tr><!-- Panel By SkihGamerZ - jorgin__100@hotmail.com -->
                      <tr>
					  <td></td>
					  <td></td>
					  </tr>
                      <tr>
					  <td></td>
					  <td>//Add Items Shop</td>
					  </tr> 
                      <tr>
					<td width="26"></td>
					<td><a href="index.php?do=additem"><font size="2"><?php echo $_STR[SACKER15]; ?></font></a></td>
					</tr>                     
					<tr>
					  <td><!-- Panel By SkihGamerZ - jorgin__100@hotmail.com -->
                      </td>
					  <td><a href="index.php?do=additem2"><font size="2"><?php echo $_STR[SACKER16]; ?></font></a></td>
					  </tr>					
                    <tr>
					<td width="26"></td>
					<td><a href="index.php?do=additem3"><font size="2"><?php echo $_STR[SACKER24]; ?></font></a></td>
					</tr>
                    <tr>
					<td width="26"></td>
					<td><a href="index.php?do=additem4"><font size="2"><?php echo $_STR[SACKER26]; ?></font></a></td>
					</tr>
                    <tr>
					  <td></td>
					  <td>//Otros</td>
					  </tr><!-- Panel By SkihGamerZ - jorgin__100@hotmail.com -->
					<tr>
					<td width="26"></td>
					<td><a href="index.php?do=accounts"><font size="2"><?php echo $_STR[SACKER6]; ?></font></a></td>
					</tr>
					<tr>
					<td width="26"></td>
					<td><a href="index.php?do=characters"><font size="2"><?php echo $_STR[SACKER7]; ?></font></a></td>
					</tr>
					<tr>
					<td width="26" height="18"></td>
					<td><a href="index.php?do=clans"><font size="2"><?php echo $_STR[SACKER9]; ?></font></a></td>
					</tr>
                    <?php
                    if( $_CONFIG[CountryBlock] == 1 )
                    {
                    ?>
				
                    <!-- PPanel By SkihGamerZ - jorgin__100@hotmail.com -->
					
                    <?php
                    }
                    ?>					
					</table>
				</td>
        	</tr>
			</table>		
		</td>
		<td width="6"></td>

<td valign="top" height="535" class="bg2" > 
			<table width="100%" style="padding-left:5px">
			<tr>
				<td width="10"></td>
				<td><?php include $includefile; ?></td>
			</tr>
			</table>
		 <!-- Panel By SkihGamerZ - jorgin__100@hotmail.com -->
		</td>
	</tr>
</table>
</div>
<span class="cred">
<?php
}
?>
</span>
</body>
</html>

