<?php
    header('Content-type: text/html; charset=iso-8859-1');
    require('alt_config.php');
?>

                        <table border="0" class="rankingtbl">
                            <tr height="40px"><td width="80px" class="titlestrong">Name</td><td width="50px" class="titlestrong">Lvl</td><td width="80px" class="titlestrong">XP</td><td width="80px" class="titlestrong">Kills</td><td class="titlestrong">Deaths</td></tr>
                        <?php
                        $query = mssql_query("SELECT TOP 18 Name, Level, XP, KillCount, DeathCount FROM Character WHERE DeleteFlag = 0 ORDER BY XP DESC");
                        while($row = mssql_fetch_row($query))
                        {
                            echo '<tr><td><a href="?page=charinfo&name='.$row[0].'">'.convertcolor($row[0]).'</a></td><td>'.$row[1].'</td><td>'.$row[2].'</td><td>'.$row[3].'</td><td>'.$row[4].'</td></tr>';
                        }
                        ?>
                        </table>