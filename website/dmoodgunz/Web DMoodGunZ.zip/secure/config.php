<?
@session_start();
//MSSQL Server configuration
$_MSSQL[Host]               = "KRISMAGLY-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "1234";
$_MSSQL[DBNa]               = "GunzDB";
$r = mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mssql_select_db($_MSSQL[DBNa], $r);
// Here you set the language for the panel
// If you set this to english, the panel will try to load lang/english.php
$_CONFIG[Language]  = "english";
// Gunz Database Configuration
$_CONFIG[AccountTable]  = "Account";
$_CONFIG[LoginTable]    = "Login";
$_CONFIG[CharTable]     = "Character";
$_CONFIG[CItemTable]    = "CharacterItem";
$_CONFIG[AItemTable]    = "AccountItem";
$_CONFIG[ClanTable]     = "Clan";
$_CONFIG[ClanMembTable] = "ClanMember";
$_CONFIG[ClanLogTable]  = "ClanGameLog";
// Plugins Configuration
// To Disable, set the variable to 0
// To Enable, set the variable to 1
$_CONFIG[CountryBlock]  = 0;        // Add functions to Block / Unblock access to your GunZ Server
//MySQL Server configuration
$_MYSQL[Host]               = "WIN-IK5BN0C64ND\SQLEXPRESS"; // Nombre del Servidor
$_MYSQL[User]               = "sa"; // Usuario del host
$_MYSQL[Pass]               = "noce123!aA"; // Contrase�a de la Base de Datos del Foro
$_MYSQL[DBNa]               = "GunzDB"; // Nombre de laBase de Datos del Foro
//Configuration
$_CONFIG[NewsFID]           = 2; // el numero de la categoria News en el foro
$_CONFIG[EventsFID]         = 0; // El numero de la categoria de Eventos en el foro
$_CONFIG[vBulletinPrefix]   = "";  // si esque llevan una palabra al inicio agregas esa palabra
$_CONFIG[ForumURL]          = "http://EnContrucci�n.com.nu/foro"; // URL del foro
//Offline page
$_CONFIG[OfflinePage]       = "";
// Gunz Database Configuration
$_CONFIG[LoginTable]    = "Login";
$_CONFIG[CharTable]     = "Character";
$_CONFIG[ClanTable]    = "Clan";
$_CONFIG[ClanmemberTable]    = "ClanMember";
$color[255] = array(255,153,51); // Administrator
$color[254] = array(255,153,51); // Developer/Gamemaster
$color[253] = array(255,255,255); // Banned
$color[252] = array(255,153,51); // Hidden GM
$color[2]   = array(0,68,255); // User With Jjang
$color[0]   = array(255,255,255); // Normal User
// Here you set the language for the panel
// If you set this to english, the panel will try to load lang/english.php
$_CONFIG[Language]  = "english";
// Gunz Database Configuration
$_CONFIG[LoginTable]    = "Login";
$_CONFIG[CharTable]     = "Character";
$_CONFIG[ClanTable]    = "Clan";
$_CONFIG[ClanmemberTable]    = "ClanMember";
?>