<?php
if(isset($_POST['banip']))
{
  $ip  = clean($_POST['ip']);

  if($ip != "")
  {
    mssql_query("INSERT INTO Web_IPBans (IP) VALUES ('".$ip."')");
    echo '<font color="red">Successfully banned the IP: '.$ip.'!</font><br /><br />';
  }
  else
  {
    echo '<font color="red">Please fill in the IP address!</font><br /><br />';
  }
}
?>
                    <strong>Write the ip of the character/account you want to ban!</strong>
                    <form action="" method="post">
                        <table border="0">
                            <tr><td>IP Address:</td> <td><input type="text" name="ip" maxlength="50" /></td></tr>
                            <tr><td></td>            <td><input type="submit" name="banip" value="Ban" /></td></tr>
                        </table>
                    </form>
					<br /><a href="?page=admin">Return to Admin Panel</a><br />