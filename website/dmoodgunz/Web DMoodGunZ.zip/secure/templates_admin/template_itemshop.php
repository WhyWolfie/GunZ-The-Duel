<?php
if(isset($_POST['adminadditem']))
{
  $name   = clean($_POST['name']);
  $desc   = clean($_POST['description']);
  $stats  = clean($_POST['stats']);
  $weight = clean($_POST['weight']);
  $gender = clean($_POST['gender']);
  $price  = clean($_POST['price']);
  $cat    = clean($_POST['cat']);
  $itemid = clean($_POST['itemid']);

  if($name != "" && $desc != "" && $stats != "" && $weight != "" && $gender != "" && $price != "" && $cat != "" && $itemid != "" && ctype_digit($weight) && ctype_digit($gender) && ctype_digit($price))
  {
    $images = array("image/jpeg", "image/png", "image/gif");
    if(in_array($_FILES['file']['type'], $images))
    {
      $part = pathinfo($_FILES['file']['name']);
      $ext  = $part['extension'];
      $exts = array("jpg", "jpeg", "png", "gif");

      if(in_array($ext, $exts))
      {
        $file = $_FILES['file']['tmp_name'];
        $size = getimagesize($file);

        if($size[0] < 101 || $size[1] < 101 || $size[0] > 91 || $size[1] > 91)
        {
          $filesize = filesize($file);

          if($filesize < 64001)
          {
            $img = $name . "." . $ext;
            move_uploaded_file($file, "images/items/$img");
            mssql_query("INSERT INTO Web_ItemShop (Name, Description, Stats, Weight, Gender, Price, Cat, Image, ItemId, Active) VALUES ('".$name."', '".$desc."', '".$stats."', '".$weight."', '".$gender."', '".$price."', '".$cat."', '".$img."', '".$itemid."', 1)");
            echo '<br />Successfully added the item: "'.$name.'".<br /><br />';
          }
          else
          {
            echo '<br />Image file size must be less than 501KB.<br /><br />';
          }
        }
        else
        {
          echo '<br />Size of the image must be 92x92 / 100x100<br /><br />';
        }
      }
      else
      {
        echo '<br />Images only!<br /><br />';
      }
    }
    else
    {
      echo '<br />Images only!<br /><br />';
    }
  }
  else
  {
    echo '<br />Please fill in all of the fields!<br /><br />';
  }
}

if(isset($_POST['adminedititem2']))
{
  $name   = clean($_POST['name']);
  $desc   = clean($_POST['description']);
  $stats  = clean($_POST['stats']);
  $weight = clean($_POST['weight']);
  $gender = clean($_POST['gender']);
  $price  = clean($_POST['price']);
  $cat    = clean($_POST['cat']);
  $itemid = clean($_POST['itemid']);
  $id     = clean($_POST['id']);

  if($name != "" && $desc != "" && $stats != "" && $weight != "" && $gender != "" && $price != "" && $cat != "" && $itemid != "" && ctype_digit($weight) && ctype_digit($gender) && ctype_digit($price) && ctype_digit($id))
  {
    $images = array("image/jpeg", "image/png", "image/gif");
    if(in_array($_FILES['file']['type'], $images))
    {
      $part = pathinfo($_FILES['file']['name']);
      $ext  = $part['extension'];
      $exts = array("jpg", "jpeg", "png", "gif");

      if(in_array($ext, $exts))
      {
        $file = $_FILES['file']['tmp_name'];
        $size = getimagesize($file);

        if($size[0] < 101 || $size[1] < 101 || $size[0] > 91 || $size[1] > 91)
        {
          $filesize = filesize($file);

          if($filesize < 64001)
          {
            $img = $name . "." . $ext;
            move_uploaded_file($file, "images/items/$img");
            mssql_query("UPDATE Web_ItemShop SET Name = '".$name."', Description = '".$desc."', Stats = '".$stats."', Weight = '".$weight."', Gender = '".$gender."', Price = '".$price."', Cat = '".$cat."', Image = '".$img."', Active = '".$active."' WHERE ID = '".$id."'");
            echo '<br />Successfully edited the item: "'.$name.'".<br /><br />';
          }
          else
          {
            echo '<br />Image file size must be less than 501KB.<br /><br />';
          }
        }
        else
        {
          echo '<br />Size of the image must be 92x92 / 100x100<br /><br />';
        }
      }
      else
      {
        echo '<br />Please select an image! (Images are only allowed)<br /><br />';
      }
    }
    else
    {
      echo '<br />Please select an image! (Images are only allowed)<br /><br />';
    }
  }
  else
  {
    echo '<br />Please fill in all of the fields!<br /><br />';
  }
}

if(isset($_POST['adminedititem']))
{
  $id = clean($_POST['id']);
  $query = mssql_query("SELECT * FROM Web_ItemShop WHERE ID = '".$id."'");

  if(mssql_num_rows($query) == 1)
  {
    $row = mssql_fetch_row($query);
    echo '
                    <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" value="'.$row[0].'" name="id" />
                        <table border="0" style="margin-left:25px;">
                            <tr><td>Name:</td>        <td><input type="text" name="name" maxlength="30" value="'.$row[1].'"/> Donation Dagger</td></tr>
                            <tr><td>Item ID(s):</td>  <td><input type="text" name="itemid" maxlength="100" value="'.$row[10].'" /> 1349,1350,1351</td></tr>
                            <tr><td>Description:</td> <td><input type="text" name="description" maxlength="30" value="'.$row[2].'" /> A Donation Dagger</td></tr>
                            <tr><td>Stats:</td>       <td><input type="text" name="stats" maxlength="30" value="'.$row[3].'" /> 10 Damage, +25HP/AP</td></tr>
                            <tr><td>Weight:</td>      <td><input type="text" name="weight" maxlength="30" value="'.$row[4].'" /> 15</td></tr>
                            <tr><td>Gender:</td>      <td><select name="gender"><option value="0">Male</option><option value="1">Female</option><option value="2">Both</option></select></td></tr>
                            <tr><td>Price:</td>       <td><input type="text" name="price" maxlength="30" value="'.$row[6].'" /> 50</td></tr>
                            <tr><td>Category:</td>    <td><select name="cat"><option value="armor">Armor</option><option value="rings">Rings</option><option value="melee">Melee</option><option value="Ranged">Raned</option><option value="Meds">Meds</option><option value="Other">Other</option></select></td></tr>
                            <tr><td>Image:</td>       <td><input type="file" name="file" /></td></tr>
                            <tr><td>Active:</td>      <td><select name="active"><option value="1" SELECTED>Active</option><option value="0">Inactive</option></select></td></tr>
                            <tr><td></td>             <td><input type="submit" name="adminedititem2" value="Edit" /></td></tr>
                        </table>
                    </form>';
  }
  else
  {
    echo '<br />This item (ID) does not exist!<br /><br />';
  }
}
else
{
?>
                    <strong>Add An Item:</strong>
                    <form action="" method="post" enctype="multipart/form-data">
                        <table border="0" style="margin-left:25px;">
                            <tr><td>Name:</td>        <td><input type="text" name="name" maxlength="30" /> Donation Dagger</td></tr>
                            <tr><td>Item ID(s):</td>  <td><input type="text" name="itemid" maxlength="100" /> 1349,1350,1351</td></tr>
                            <tr><td>Description:</td> <td><input type="text" name="description" maxlength="30" /> A Donation Dagger</td></tr>
                            <tr><td>Stats:</td>       <td><input type="text" name="stats" maxlength="30" /> 10 Damage, +25HP/AP</td></tr>
                            <tr><td>Weight:</td>      <td><input type="text" name="weight" maxlength="30" /> 15</td></tr>
                            <tr><td>Gender:</td>      <td><select name="gender"><option value="0">Male</option><option value="1">Female</option><option value="2">Both</option></select></td></tr>
                            <tr><td>Price:</td>       <td><input type="text" name="price" maxlength="30" /> 50</td></tr>
                            <tr><td>Category:</td>    <td><select name="cat"><option value="armor">Armor</option><option value="rings">Rings</option><option value="melee">Melee</option><option value="Ranged">Raned</option><option value="Meds">Meds</option><option value="Other">Other</option></select></td></tr>
                            <tr><td>Image:</td>       <td><input type="file" name="file" /></td></tr>
                            <tr><td></td>             <td><input type="submit" name="adminadditem" value="Add" /></td></tr>
                        </table>
                    </form>
                    <p>
                        Image: 100x100, .jpg / .jpeg / .png / .gif<br /><br />
                        <strong>Edit An Item:</strong><br />
                        <form action="" method="post" style="margin-left:55px;">
                        <select name="id">
                        <?php
                            $query = mssql_query("SELECT * FROM Web_ItemShop ORDER BY ID DESC");

                            while($row = mssql_fetch_row($query))
                            {
                              echo '<option value="'.$row[0].'">'.$row[1].'</option>';
                            }
                        ?>
                        </select><br />
                        <input type="submit" name="adminedititem" value="Edit" />
                        </form>
                    </p>
					<br /><a href="?page=admin">Return to Admin Panel</a><br />
<?php
}
?>
