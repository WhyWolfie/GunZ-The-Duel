                    Dear <?php echo $_SESSION['username']; ?>,<br /><br />
                    Please select one of the following functions to continue:<br /><br />
                    <a href="?page=admin&function=itemshop">-) Add &amp; Manage Item Shop</a><br />
                    <a href="?page=admin&function=ipban">-) Ban an IP Address</a><br />