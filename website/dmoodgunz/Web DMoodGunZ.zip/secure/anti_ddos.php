&lt;?php
  /*
  Posted @ http://www.w3tools.info/2011/12/anti...hp-script.html
  */
   function getIP () {
   if (getenv (&quot;HTTP_CLIENT_IP&quot;) and preg_match (&quot;/^[ 0-9 \ .]*?[ 0-9 \ .]+$/ is &quot;, getenv (&quot; HTTP_CLIENT_IP &quot;)) and getenv (&quot; HTTP_CLIENT_IP &quot;) ! = &#039;127 .0.0.1 &#039;) {
   $ Ip = getenv (&quot;HTTP_CLIENT_IP&quot;);
   } Elseif (getenv (&quot;HTTP_X_FORWARDED_FOR&quot;) and preg_match (&quot;/^[ 0-9 \ .]*?[ 0-9 \ .]+$/ is &quot;, getenv (&quot; HTTP_X_FORWARDED_FOR &quot;)) and getenv (&quot; HTTP_X_FORWARDED_FOR &quot; !) = &#039;127 .0.0.1 &#039;) {
   $ Ip = getenv (&quot;HTTP_X_FORWARDED_FOR&quot;);
   } Else {
   $ Ip = getenv (&quot;REMOTE_ADDR&quot;);
   }
   return $ ip;
   }
   $ Ad_ip = getIP ();
   
   $ Ad_source = file (&quot;{$ ad_dir} / {$ ad_black_file}&quot;);
   $ Ad_source = explode (&#039;&#039;, $ ad_source [0]);
   if (in_array ($ ad_ip, $ ad_source)) {die ();}
   
   $ Ad_source = file (&quot;{$ ad_dir} / {$ ad_white_file}&quot;);
   $ Ad_source = explode (&#039;&#039;, $ ad_source [0]);
   if (! in_array ($ ad_ip, $ ad_source)) {
   
   $ Ad_source = file (&quot;{$ ad_dir} / {$ ad_temp_file}&quot;);
   $ Ad_source = explode (&#039;&#039;, $ ad_source [0]);
   if (! in_array ($ ad_ip, $ ad_source)) {
   $ Ad_file = fopen (&quot;{$ ad_dir} / {$ ad_temp_file}&quot;, &quot;a +&quot;);
   $ Ad_string = $ ad_ip. &#039; &#039;;
   fputs ($ ad_file, &quot;$ ad_string&quot;);
   fclose ($ ad_fp);
   ?&gt;
  &lt;!--
   
   The site is currently subject to DDOS attack, if you&#039;re not a machine, zombie attacking the site, click on the button, otherwise your IP (&lt;?=$ ad_ip?&gt;) Will be blocked!
   &lt;form method=&quot;post&quot;&gt;
   &lt;input type=&quot;submit&quot; name=&quot;ad_white_ip&quot; value=&quot;Knopka&quot;&gt;
   &lt;/ Form&gt;
  --&gt;
   
  &lt;?php
   die ();
   }
   elseif ($ _POST &#91;&#039;ad_white_ip&#039;]) {
   $ Ad_file = fopen (&quot;{$ ad_dir} / {$ ad_white_file}&quot;, &quot;a +&quot;);
   $ Ad_string = $ ad_ip. &#039; &#039;;
   fputs ($ ad_file, &quot;$ ad_string&quot;);
   fclose ($ ad_fp);
   }
   else {
   $ Ad_file = fopen (&quot;{$ ad_dir} / {$ ad_black_file}&quot;, &quot;a +&quot;);
   $ Ad_string = $ ad_ip. &#039; &#039;;
   fputs ($ ad_file, &quot;$ ad_string&quot;);
   fclose ($ ad_fp);
   die ();
   }
   }
   ?&gt;