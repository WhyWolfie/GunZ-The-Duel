<table width="177">
  <tr>
    <td><a href="index.php?do=donate"><img src="images/donate.png" width="175" height="151" /><br />
      <br />
    </a></td>
  </tr>
    <tr>
    <td><a href="index.php?do=individualrank"><img src="images/bann_ranking.jpg" width="175" height="61" /></a></td>
  </tr>
</table>
<br />
<iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Utech-GunZ-Entertainment/839000929479934&amp;width=177&amp;height=280&amp;colorscheme=dark&amp;show_faces=true&amp;border_color=%23000000&amp;stream=false&amp;header=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:177px; height:280px;" allowTransparency="true"></iframe>
