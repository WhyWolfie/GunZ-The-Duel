// JavaScript Document

function showModal( ) {
    
    document.getElementById('modalbox').style.visibility = 'visible';
    document.getElementById('modalcontent').style.visibility = 'visible'; 
    
}

function closeModal( ) {
    
    document.getElementById('modalbox').style.visibility = 'hidden';
    document.getElementById('modalcontent').style.visibility = 'hidden';    
    
}

function showRegister( ) {
    
    document.getElementById('regmodalbox').style.visibility = 'visible';
    document.getElementById('regcontent').style.visibility = 'visible'; 
    
}

function closeRegister( ) {
    
    document.getElementById('regmodalbox').style.visibility = 'hidden';
    document.getElementById('regcontent').style.visibility = 'hidden';    
    
}

function showLost( ) {
    
    document.getElementById('lostbox').style.visibility = 'visible';
    document.getElementById('lostcontent').style.visibility = 'visible'; 
    
}

function closeLost( ) {
    
    document.getElementById('lostbox').style.visibility = 'hidden';
    document.getElementById('lostcontent').style.visibility = 'hidden';    
    
}

function showSupport( ) {
    
    document.getElementById('supportbox').style.visibility = 'visible';
    document.getElementById('supportcontent').style.visibility = 'visible'; 
    
}

function closeSupport( ) {
    
    document.getElementById('supportbox').style.visibility = 'hidden';
    document.getElementById('supportcontent').style.visibility = 'hidden';    
    
}

function showTicket( ) {
    
    document.getElementById('ticketbox').style.visibility = 'visible';
    document.getElementById('ticketcontent').style.visibility = 'visible'; 
    
}

function closeTicket( ) {
    
    document.getElementById('ticketbox').style.visibility = 'hidden';
    document.getElementById('ticketcontent').style.visibility = 'hidden';    
    
}

function showSearch( ) {
    
    document.getElementById('searchbox').style.visibility = 'visible';
    document.getElementById('searchcontent').style.visibility = 'visible'; 
    
}

function closeSearch( ) {
    
    document.getElementById('searchbox').style.visibility = 'hidden';
    document.getElementById('searchcontent').style.visibility = 'hidden';    
    
}

function showInfo( ) {
    
    document.getElementById('infobox').style.visibility = 'visible';
    document.getElementById('infocontent').style.visibility = 'visible'; 
    
}

function closeInfo( ) {
    
    document.getElementById('infobox').style.visibility = 'hidden';
    document.getElementById('infocontent').style.visibility = 'hidden';    
    
}