<?
include("secure/config.php");
include("secure/functions.php");
include("secure/include.php");
include("secure/banneduser.php");
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";
include "IpBan/ipban.php";
checar_baneo_ip($_SERVER['REMOTE_ADDR']);

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        redirect("index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            redirect("index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "Inicio - Utech GunZ Entertainment ", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>%TITLE%</title>
<link href="/favicon/SpetGz.ico" rel="shortcut icon" />
<script language="Javascript">

function disableselect(e){
return false
}

function reEnable(){
return true
}

document.onselectstart=new Function ("return false")

if (window.sidebar){
document.onmousedown=disableselect
document.onclick=reEnable
}

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
loadImage0 = new Image();
loadImage0.src = "images/nav-home_on.png";
staticImage0 = new Image();
staticImage0.src = "images/nav-home.png";

loadImage1 = new Image();
loadImage1.src = "images/nav-reg_on.png";
staticImage1 = new Image();
staticImage1.src = "images/nav-reg.png";

loadImage2 = new Image();
loadImage2.src ="images/nav-down_on.png";
staticImage2 = new Image();
staticImage2.src = "images/nav-down.png";

loadImage3 = new Image();
loadImage3.src = "images/nav-logo_on.png";
staticImage3 = new Image();
staticImage3.src = "images/nav-logo.png";

loadImage4 = new Image();
loadImage4.src = "images/nav-clan_on.png";
staticImage4 = new Image();
staticImage4.src = "images/nav-clan.png";

loadImage5 = new Image();
loadImage5.src = "images/nav-mark_on.png";
staticImage5 = new Image();
staticImage5.src = "images/nav-mark.png";

loadImage6 = new Image();
loadImage6.src = "images/nav-com_on.png";
staticImage6 = new Image();
staticImage6.src = "images/nav-com.png";

loadImage7 = new Image();
loadImage7.src = "images/donate_on.png";
staticImage7 = new Image();
staticImage7.src = "images/donate.png";

loadImage8 = new Image();
loadImage8.src = "images/ranking_on.png";
staticImage8 = new Image();
staticImage8.src = "images/ranking.png";

loadImage9 = new Image();
loadImage9.src = "images/login_btn_on.png";
staticImage9 = new Image();
staticImage9.src = "images/login_btn.png";

loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";
// En
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
//-->
</script>
<link rel="stylesheet" type="text/css" href="e_style.css">
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/bg40.jpg') no-repeat center top">

<div align="center">
  <table border="0" style="border-collapse: collapse" width="90%">
		<tr>
			<td width="800">

			  <p align="center">
              <a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('999','','images/inicio02.png',1)"><img src="images/inicio.png" alt="" name="inicio" width="63" height="36" border="0"></a>        <a href="index.php?do=register" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('999','','images/registro02.png',1)"><img src="images/registro.png" name="descargas" width="160" height="36" border="0"></a><a href="index.php?do=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('999','','images/descargas02.png',00)"><img src="images/descargas.png" name="descargas" width="160" height="36" border="0"></a><a href="index.php?do=individualrank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('999','','images/rank02.png',1)"><img src="images/rank.png" name="ranking clan y personajes" width="206" height="36" border="0"></a><a href="index.php?do=tiendaitemshop" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('999','','images/items02.png',1)"><img src="images/items.png" name="item shop" width="94" height="36" border="0"></a></p>
              
          </td>
		</tr>
			
	<tr>
			<td>
		<div align="center">
		</p>
		<table border="0" cellpadding="0" cellspacing="0" width="800">
		<td height="259">&nbsp;</td>
        <tbody>
		  
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {   
                SetMessage("", array("Utech Gunz Entertainment es un Servidor Completamente Gratuito!",
                "<a href=\"index.php?do=register\"><b>Haz click aqu�</b> para registrarte</a>"));
                
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">&nbsp;</td>
            
                  
            </tbody></table>
          </div>
          	</td>
	</tr>
  </table>
</div>
<p>
<section style="text-align:center;background:#2c2cc;color:white;text-shadow:0px 0px 5px black;padding:20px;font-weight:bold;">
  <p>&nbsp;</p>
</section>
<section style="background:#000000;color:white;">
<center>
  <p><img src="../images/keibert/lunes.jpg" border="0" alt="Utech Gunz" width="1027" height="622"></p>
  <p><img src="../images/keibert/martes.jpg" border="0" alt="Utech Gunz" width="1005" height="733"></p>
  <p><img src="../images/keibert/miercoles.jpg" border="0" alt="Utech Gunz" width="1029" height="714"></p>
  <p><img src="../images/keibert/jueves.jpg" border="0" alt="Utech Gunz" width="955" height="729"></p>
  <p><img src="../images/keibert/viernes.jpg" border="0" alt="Utech Gunz" width="947" height="684"></p>
  <p><img src="../images/keibert/sabado.jpg" border="0" alt="Utech Gunz" width="1015" height="661"></p>
  <p><img src="../images/keibert/domingo.jpg" border="0" alt="Utech Gunz" width="1038" height="772"></p>
</center>
</section>&nbsp; </p>
<script language="JavaScript">
	function tecla() 
	{
	if (event.keyCode==123)
	{
	event.keyCode=0;
	event.returnValue=false;
	}
	} document.onkeydown=tecla;
  </script>
</html>