<?php
$text = "Website Designed and coded by";
$name = "Jurien Hamaker";
?>