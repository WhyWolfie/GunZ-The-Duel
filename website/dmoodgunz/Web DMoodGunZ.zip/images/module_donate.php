<?
SetTitle("EliteGamer Gunz - Donar Al Gunz");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + "Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar al Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="800" height="300%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="376" bgcolor="#000000" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" bgcolor="#000000" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" bgcolor="#000000" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
												<center>
													<p>Gunz Les Da Las Gracias a las 
													donaciones que hacen 
													nuestros usuarios. <br>
													Para mantener los costos de 
													Gunz dinero, por lo que 
													agradecemos su donaci�n </p>
													<p>200 DCoins: 20 Bsf	---	300 Dcoins: 30 Bsf	---	400	Dcoins:	40	Bsf	--	500 Dcoins: 50 Bsf				--- 1000 Dcoins: 100 Bsf ---1300 Dcoins: 120 Bsf</p>
													<p>----Donaciones Por Tarjeta Telefonica DIGITEL (Solo en Venezuela)----</p>
													<p>Envia Un Mensajes al Numero 0412-662-0923	seguido con tu ID, Codigo de la TARJETA y la Cantidad</p>
													<p>Por Ejemplo:</p>
													<p>Mi ID: keibert</p>
													<p>TAJERTA: 0233 300 678 353</p>
													<p>Cantidad: 30 Bsf</p>
													<p>    <br>
												  </p>
                                                 </div>
                                                <p>
                                                <br />
												</center>

                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <center>
                                                </center>
</form>
												<center>
                                                   <p>-----Como donar por SMS (Todos los Paises)-----</p>
												   <p>lo primero es Seleccionar el idioma Si es Que habla otro idioma,luego uvicar su pais yah sea Espa�a,Republica Dominicana,Venezuela,argentina, ECT.</p>
												   <p>Luego seguir los pasos Que te indica avajo que son. Env�a un Mensaje nombre "TEKETEKE" seguido de "TU AID" al 92800</p>
												  <a target='_blank' title='ImageShack - Image And Video Hosting' href='http://imageshack.us/photo/my-images/268/imagenaid.jpg/'><img src='../../../../AppServ/www/images/Sin t&iacute;tulo.jpg' border='0'/></a>
												  <P>Lo Que esta en Serrado en un sirculo Rojo Donde Dice "Tu AID:3" El AID seria "3"</p>
												  <p>Luego lo Envias al numero Que te indica en mi caso Que es mi pais</p>
												  <a target='_blank' title='ImageShack - Image And Video Hosting' href='http://imageshack.us/photo/my-images/39/paisnumber.jpg/'><img src='http://img39.imageshack.us/img39/1337/paisnumber.jpg' border='0'/></a>
												  <P>Lo Que esta en serrado es el numero Que voy a introducir en mi telefono Eso sera todo</P>
												  <P>Estas donaciones son total mente Seguras asi Que no se preocupe por nada. Gracias por su atencion</p>
											      </center>
												   <table>
											   <script src="https://iframes.recursosmoviles.com/v2/?wmid=6396&cid=23177" type="text/javascript"></script>
									            </table>
                                                </p>
                                                </div>
                                              </td>
												<td width="13" bgcolor="#000000" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" bgcolor="#000000" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>