<?
SetTitle("DMood Gamers - GunZ - Donar SMS");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
<link href="index.php?do=donate-tarjetas.css" rel="stylesheet" type="text/css" />
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar a DMood Gamers Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
												  <p>DMood Gamers Gunz: En este medio de Donaiones por SMS en para todos los paises que desea donar a nuestra comunidad por cada SMS va a resibir 100 Dcoins..El	costo	de	SMS	va	a	depender	de	su	pais.</p>
												  <p>Bueno los pasos a seguir son estos:</p>
												  <p>&nbsp;</p>
												  <p>1-Entramos al bonto donde dice PAYGOL</p>
												  <p>&nbsp;</p>
												  <form name="pg_frm" method="post" action="https://www.paygol.com/pay" >
   <input type="hidden" name="pg_serviceid" value="334688">
   <input type="hidden" name="pg_currency" value="EUR">
   <input type="hidden" name="pg_name" value="DonateDMood">
   <input type="hidden" name="pg_custom" value="">
   <input type="hidden" name="pg_price" value="1">
   <input type="hidden" name="pg_return_url" value="http://dmoodgamersgunz.sytes.net/index.php?do=donate-sms">
   <input type="hidden" name="pg_cancel_url" value="http://dmoodgamersgunz.sytes.net/index.php?do=donate-sms">
   <input type="image" name="pg_button" src="https://www.paygol.com/webapps/buttons/es/black.png" border="0" alt="Realiza pagos con PayGol: la forma mas facil!" title="Realiza pagos con PayGol: la forma mas facil!" >     
</form>
&nbsp;</p>
												  <p>2-Una ves que la pagina este cargada selecionamos nuestro pais o la misma empresa le colocar en pais de donde eres.</p>
												  <p>3-Enviamos el SMS con el numero y el codigo que va a salir en la pagina de PAYGOL</p>
												  <p>4-Una ves enviando el SMS la misma empresa le enviara un SMS confirmado su pago	y	hay	le	dara	el	mismo	codigo	en	donde	debe	colocar	en la pagina y dale click en OK	para	que	su	pago	se	confirme.</p>
												  <p>5-Luego vamos a reportar nuestro pago aqui: </p>
												  <p>&nbsp;</p>
												  <p><a href="report.php"><img src="../images/reporteee.png" alt="clan" width="182" height="26" /></a></p>
												  <p>Comentemos con nuestro datos los cuales seria:</p>
												  <p>-Tu ID</p>
												  <p>-El numero de telefono donde enviaste los SMS</p>
												  <p>-Y cuantos SMS fueros</p>
												  <p>&nbsp;</p>
												  <p>NOTA: En menos de 24 horas su Dcoins sera enviados a su cuenta.</p>
												  <p>&nbsp;</p>
												  <p><br>
												    <br />
											      </p>
                                                </div>
                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <center>
                                                  <img alt="" border="0" src="https://www.paypal.com/fr_FR/i/scr/pixel.gif" width="1" height="1">
                                                </center>
                                                </form>

                                                </p>
                                                </div>
                                                </td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>