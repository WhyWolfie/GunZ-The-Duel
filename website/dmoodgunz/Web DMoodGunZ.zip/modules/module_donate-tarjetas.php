<?
SetTitle("DMood Gamers - GunZ - Donar tarjetas");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar a DMood Gamers Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
												  <p>DMood Gamers Gunz: Aqui las donaciones por TARJETAS TELEFONICAS solo es para Venezuela, la cuales aceptamos DIGITEL, MOVISTAR o MOVINET y aqui le presentamos los presion para hacer su compras de DCoins:</p>
												  <p>&nbsp;</p>
												  <p>30 bsf: 300 Dcoins</p>
												  <p>40 bsf: 400 Dcoins</p>
												  <p>50 bsf: 500 Dcoins</p>
												  <p>100 bsf: 1000 Dcoins</p>
												  <p>120 bsf: 1200 Dcoins</p>
												  <p>&nbsp;</p>
												  <p>Por cada 10 bsf son 100 Dcoins...Ahora haremos los siguiente para que tu donaciones:</p>
												  <p>1-Rapemos en codigo de la tarjeta.</p>
												  <p>2-Vamos a enviar un mensaje de texto al este numero: 04141385250</p>
												  <p>3-Y escribimos lo siguientes:</p>
												  <p>&nbsp;</p>
												  <p>Donate DMood Gamers Gunz</p>
												  <p>ID: (su ID)</p>
												  <p>Codigo: ( Aqui debe colocar el codigo de la tarjeta que sea donar)</p>
												  <p>Tipo de Tarjeta: (Aqui debe colocar el tipo de tarjeta que es si es Digitel, Movinet o Movistar)</p>
												  <p>&nbsp;</p>
												  <p>5-Luego le daremos enviar...Y esperemos a que cofirmemos la tarjeta envianda.</p>
												  <p>&nbsp;</p>
												  <p>NOTA: Las entregas de su Dcoins, se confirmara cuando le enviemos un mensaje de texto al numero en donde enviaste los codigos de las tarjetas.....Ojo solo vamos a responde para las donaciones o ayudas.!<br>
											      </p>
												  <p><br>
												    <br />
											      </p>
                                                </div>
                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <center>
                                                  <img alt="" border="0" src="https://www.paypal.com/fr_FR/i/scr/pixel.gif" width="1" height="1">
                                                </center>
                                                </form>

                                                </p>
                                                </div>
                                                </td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>