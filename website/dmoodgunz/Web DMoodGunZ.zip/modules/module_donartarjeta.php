<?
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donartarjeta");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center"><b><font size="2" face="Tahoma">Donate Utech Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
									  <table width="408" height="100%" border="0" style="border-collapse: collapse; float:left">
									    <tbody>
									      <tr>
									        <td style="background-repeat: no-repeat; background-position: center top" width="380"><div style="text-align: left;" id="result_box" dir="ltr">
									          <p><strong>With this type of DONACIONS SMS is safer for YOU and for Gunz</strong></p>
									          <p><strong>For every SMS ARE 80 DCoins</strong></p>
									          <p><strong>VIDEOS EXPLAINING TO MAKE YOUR DONATIONS:</strong></p>
									          <p><strong>EYE: Please note that this type of donation not reach the DCoins automatically .. !!</strong><br />
									            <br />
									            <iframe class="youtube-player" type="text/html" width="640" height="385" src="http://www.youtube.com/embed/1hgEB_RcKcY" frameborder="0"></iframe>
									          </p>
									          <p><form name="pg_frm" method="post" action="https://www.paygol.com/pay" >
   <input type="hidden" name="pg_serviceid" value="331671">
   <input type="hidden" name="pg_currency" value="VEF">
   <input type="hidden" name="pg_name" value="UtechGunz">
   <input type="hidden" name="pg_custom" value="">
   <input type="hidden" name="pg_price" value="10">
   <input type="hidden" name="pg_return_url" value="http://gunz.utechntertainment.esy.es/index.php">
   <input type="hidden" name="pg_cancel_url" value="http://gunz.utechntertainment.esy.es/index.php?do=donartarjeta">
   <input type="image" name="pg_button" src="https://www.paygol.com/micropayment/buttons/es/black.png" border="0" alt="Realiza pagos con PayGol: la forma mas facil!" title="Realiza pagos con PayGol: la forma mas facil!" >     
</form></p>
									          <p><strong>After making what is in the video we will:</strong></p>
<p><strong>-A See sending SMS to contact me at my facebook: <a href="https://www.facebook.com/keibert.urdaneta">Keibert Urdaneta</a></strong></p>
<p><strong>'I must leave your phone number, ID and how many SMS Jurisdiction (Although I very saber all mode)</strong></p>
<p><strong>-After Send the message to my facebook we must wait for an answer .. !!</strong></p>
<p><strong>Your coins Llegara within 24Hours</strong><br />
									          </p>
								            <p>&nbsp;</p></td>
								          </tr>
								        </tbody>
								      </table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
</table>
                <center>
<p><strong><strong><strong></div>
									</td>
								</tr>
							</table>
						</div>
</p>
<p>
<p align="center">&nbsp;</td>
<td width="171" valign="top">
						<div align="center">
							<? include "../../Nueva carpeta/blocks/block_login.php" ?>
						</div>
</td>
					</tr>
				</table>
                
                