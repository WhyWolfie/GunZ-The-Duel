<?php
// No tocar
if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

//
if($_SESSION['AID'] == ""){
	msgbox("Para ingresar debes estar logueado.","http://sackerz.blogspot.com/");
	die();
	}else{
	$very = mssql_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
	$acc = mssql_fetch_object($very);
	if($acc->UGradeID !== 255){
		msgbox("Usted no tiene permiso para ingresar.","http://sackerz.blogspot.com/");
			}
			echo "<table align='center'  style='font-size:12px'><tr><td><b>";
	include "tarjeta.txt";
	echo "</b></td></tr></table>";
		}

?>