<?
include("secure/include.php");
redirect("index.php?do=individualrank");
die();
?>