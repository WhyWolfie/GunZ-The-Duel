<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=296,width=416,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
<? 
include("secure/include.php");

if( $_SESSION [ UserID ] == "" )
{
Setmessage ( "Administracion de Clanes" , Array( "You are not logged in, you need to login first to Administrate or view Clans!" ));
$doxurl = $_SERVER [ 'QUERY_STRING' ];
SetURL ( "index.php? $doxurl " );
Header ( "Location: index.php?do=login" );
Die();
}
$CLID = Clean ( $_GET [ 'CLID' ]);

If (! is_numeric ( $CLID ) || $CLID == "" ){
Setmessage ( "Administracion de Clanes" , Array( "Wrong Clan CLID!" , "You might login and click on your clan in your user info on the index page." ));
Header ( "Location: index.php" );
Die();
}
$query = mssql_query ( "SELECT * FROM Clan WHERE CLID = ' $CLID '" ); //and Name IS NOT NULL");

if ( mssql_num_rows ( $query ) == 0 ){
Setmessage ( "Administracion de Clanes" , Array( "The ClanID: $CLID doesn't exsit!" , "You might login and click on your clan in your user info on the index

page." ));
Header ( "Location: index.php" );
Die();
}else{
$queryinfo = mssql_fetch_object ( $query );
$Name = $queryinfo -> Name ;
$MasterCID = $queryinfo -> MasterCID ;
$MCQuery = Mssql_query ( "SELECT AID, Name FROM Character WHERE CID = $MasterCID " );
$MCQueryinfo = mssql_fetch_object ( $MCQuery );
$MasterName = $MCQueryinfo -> Name ;
if ( $Name == '' || $Name == NULL ){
$Name = $queryinfo -> DeleteName ;
Setmessage ( "Administracion de Clanes" , Array( "The Clan: ' $Name ' is Deleted!" , "Contact: ' $MasterName ' the Leader of the Clan!" ));
Header ( "Location: index.php" );
Die();
}
settitle ( " GalaxiaGamers Gunz - Clan Panel ($Name)" );
$EmblemUrl = $queryinfo -> EmblemUrl ;
if ( $EmblemUrl == NULL ){ $EmblemUrl = 'noemblem.gif' ;}
$ranking = $queryinfo -> Ranking ;
$Wins = $queryinfo -> Wins ;
$Losses = $queryinfo -> Losses ;
$Points = $queryinfo -> Point ;
$TotalPoints = $queryinfo -> TotalPoint ;
$CreationDate = $queryinfo -> RegDate ;
$MasterAID = $MCQueryinfo -> AID ;
$myAID = Clean ( $_SESSION [ AID ]);
If ( $myAID == $MasterAID ){
$isleader = 1 ;
}
}

if ( $_GET [ 'leaveclan' ] != "" ){
$leaveCID = Clean ( $_GET [ 'leaveclan' ]);
if ( $_GET [ 'confirm' ] == "true" ){
$checkcid = mssql_query ( "SELECT Name FROM Character WHERE AID = $myAID and DeleteFlag = 0 and CID = $leaveCID " );
if ( mssql_num_rows ( $checkcid ) == 1 && $isleader != 1 ){
$checkcidinfo = mssql_fetch_assoc ( $checkcid );
$leaveNAME = $checkcidinfo [ 'Name' ];
$checkclan = mssql_query ( "SELECT Grade FROM ClanMember WHERE CLID = $CLID and CID = $leaveCID " );
if ( mssql_num_rows ( $checkclan ) == 1 ){
$checkclaninfo = mssql_fetch_object ( $checkclan );
$checkgrade = $checkclaninfo -> Grade ;
if ( $checkgrade == 2 ){
$checkgradestr = 'Administrador' ;
}else{
$checkgradestr = 'Miembro' ;
}
mssql_query ( "DELETE FROM ClanMember WHERE CLID = $CLID and CID = $leaveCID " );
Setmessage ( "Administracion de Clanes Panel" , Array ( "Your Characrer: $leaveNAME as $checkgradestr in Clan: $Name has left it Successfully!" ));
Header ( "Location: index.php?do=index" );
Die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
$linkconfirm = '<a
href="http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID . '&leaveclan=' . $leaveCID . '&confirm=true">http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID .

'&leaveclan=' . $leaveCID . '&confirm=true</a>

' ;
Setmessage ( "Message From Administration Panel" , Array( "Do you really want to leave Clan: $Name ?" , "If yes, Please Click this link Below!" , " $linkconfirm " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
Die();
}
}elseif ( $_GET [ 'resetclanscore' ] == "true" ){
if ( $isleader == 1 ){
mssql_query ( "UPDATE Clan SET Ranking=0, Wins=0, Losses=0, Point=1000, RankIncrease=0, LastDayRanking=0 WHERE CLID = $CLID " );
Setmessage ( "Administracion de Clanes" , Array( "You have Successfully reseted your Clan $Name " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}
if ( $isleader != 1 ){
$myqueryx = mssql_query ( "SELECT CID FROM Character WHERE AID = $myAID and DeleteFlag = 0" );
While ( $myqueryxinfo = mssql_fetch_object ( $myqueryx )){
$querys = mssql_query ( "SELECT Grade FROM ClanMember WHERE CID = ' $myqueryxinfo -> CID ' and CLID = $CLID " );
$mygradex = mssql_fetch_object ( $querys );
$mygradexx = $mygradex -> Grade ;

if ( $mygradexx == 2 ){
$isleader = 2 ;
break;
}
}
}

if ( $_GET [ 'kick' ] != "" || $_GET [ 'demote' ] != "" || $_GET [ 'promote' ] != "" ){

if( $_GET [ 'kick' ] != "" ){ $CID = Clean ( $_GET [ 'kick' ]); $OS = 1 ;}
elseif ( $_GET [ 'demote' ] != "" ){ $CID = Clean ( $_GET [ 'demote' ]); $OS = 2 ;}
else{ $CID = Clean ( $_GET [ 'promote' ]); $OS = 3 ;}

$query1 = mssql_query ( "SELECT Grade FROM ClanMember Where CLID = $CLID and CID = $CID " );
$query1info = mssql_fetch_object ( $query1 );
$GGrade = $query1info -> Grade ;
$query3 = mssql_query ( "SELECT Name From Character WHERE CID = $CID " );
$query3info = mssql_fetch_assoc ( $query3 );
$GName = $query3info [ 'Name' ];

if ( $isleader < $GGrade ){
if ( $OS == 1 ){
mssql_query ( "DELETE FROM ClanMember Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just kicked $GName out Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}elseif ( $OS == 2 && $GGrade == 2 ){
mssql_query ( "UPDATE ClanMember SET Grade = 9 Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just demoted $GName Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}elseif ( $OS == 3 && $isleader == 1 && $GGrade == 9 ){
mssql_query ( "UPDATE ClanMember SET Grade = 2 Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just promoted $GName Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}elseif ( $_GET [ 'closeclan' ] != "" ){
if ( $_GET [ 'closeclan' ] == 'true' && $isleader == 1 ){
if ( $_GET [ 'confirm' ] == 'true' ){
Mssql_query ( "DELETE FROM ClanMember WHERE CLID = $CLID " ); // and CID != $MasterCID");
Mssql_query ( "UPDATE Clan SET Name = NULL, DeleteFlag = 1, DeleteName = ' $Name ' WHERE CLID = $CLID " );
Setmessage ( "Administracion de Clanes Panel" , Array ( "You have just Deleted (Closed) your Clan: $Name Successfully!" ));
Header ( "Location: index.php?do=index" );
die();
}else{
$linkconfirm = '<a
href="http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID . '&closeclan=true&confirm=true">http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID .

'&closeclan=true&confirm=true</a>

' ;
Setmessage ( "Administracion de Clanes Panel" , Array( "Do you really want to Close (Delete) Clan: $Name ?" , "If yes, Please Click this link Below!" , " $linkconfirm " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}
$membersinlistcount = mssql_num_rows ( Mssql_query ( "SELECT * FROM ClanMember WHERE CLID = ' $CLID '" ));
?>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top"><div align="center">
<table style="border-color: rgb(0, 0, 0); border-collapse: collapse;"
border="1" width="408">
<tbody>
<tr>
<td
style="background-image: url(./images/content_bar.jpg); background-repeat: no-repeat; background-position: center top;"
height="24">
<div align="center"><b><font face="Tahoma"
size="2">Panel de Control Clan <strong><?=$Name?></strong></font></b></div>
</td>
</tr>
<tr>
<td bgcolor="#2c2a2a">
<div align="center">
<table style="border-collapse: collapse; float: left;"
border="0" width="300">
<tbody>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="8">&nbsp;</td>
<td colspan="3" align="center" width="380">
<img alt=""
src="http://i62.servimg.com/u/f62/11/82/86/31/mis_cl10.jpg"
border="0" height="67" width="365"> </td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" align="center" width="376">Clan
Name: <b><big> <?=$Name?> </b></big></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" align="center" width="376">Ranking:
<b> <?=$ranking?> </b></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td align="center" width="600" colspan="3">Wins/Losses: <b> <?=$Wins . '/' . $Losses?> </b></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td width="600" colspan="3">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td align="center" width="600" colspan="3">Puntos: <b> <?=$Points?> </b></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9" height="21">&nbsp;</td>
<td width="600" colspan="3">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td align="center" width="600" colspan="3">Puntos Totales: <b> <?=$TotalPoints?> </b></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td width="600" colspan="3">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td align="center" width="600" colspan="3">Clan Creado: <b> <?=$CreationDate?> </b></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" align="center" width="376">
<img alt="emblem"
style="border: 3px solid rgb(0, 0, 0);"
src="http://gunz.galaxiagamers.net/emblem/upload/<?=$EmblemUrl?> " height="120"
width="120"> 

<p align="center"><a href="JavaScript:newPopup('/emblem');"><input value="Cambiar Emblema" class="textLogin" type="button" /></a></p></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" align="center" width="376"></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" align="center" width="376">Miembros del clan, <strong><?=$Name?> (<?=$membersinlistcount?>)</strong></td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">
<div align="center">
<table border="0" cellpadding="3"
cellspacing="1" width="389">
<tbody>

<? //PHP code here
$ClanMemberquery = Mssql_query ( "SELECT * FROM ClanMember WHERE CLID = $CLID " );
if ( Mssql_num_rows ( $ClanMemberquery ) != 0 ){
echo '<tr>
<td bgcolor="#121212" width="131">Nombre</td>
<td bgcolor="#121212" width="50">Nivel</td>
<td bgcolor="#121212" width="40">Rank</td>
<td bgcolor="#121212" width="25">Puntos</td>
<td bgcolor="#121212" width="100">Opciones</td>
</tr>' ;
While ( $CMemberqueryinfo = mssql_fetch_object ( $ClanMemberquery )){
$CMREGD = $CMemberqueryinfo -> RegDate ;
$CMCWP = $CMemberqueryinfo -> ContPoint ;
$CMCID = $CMemberqueryinfo -> CID ;
$CMNamequery = mssql_query ( "SELECT Name, Level, AID FROM Character WHERE CID = $CMCID " );
$CMNamequeryinfo = mssql_fetch_object ( $CMNamequery );
$CMName = $CMNamequeryinfo -> Name ;
$CMLevel = $CMNamequeryinfo -> Level ;
$CMRank = $CMemberqueryinfo -> Grade ;
$CMAID = $CMNamequeryinfo -> AID ;
$CMANameqq = Mssql_query ( "SELECT UGradeID FROM Account WHERE AID = $CMAID " );
$CMANameinfo = mssql_fetch_assoc ( $CMANameqq );
$CMAUGrade = $CMANameinfo [ 'UGradeID' ];


if ( $isleader == 1 && $CMRank == 9 ){
$Options = '<a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&kick=' . $CMCID . '">Expulsar</a><big> - </big><a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&promote=' . $CMCID . '">Cambiar Rango</a>' ;
}elseif( $isleader == 1 && $CMRank == 2 ){
$Options = '<a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&kick=' . $CMCID . '">Expulsar</a><big> - </big><a
href="http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID . '&demote=' . $CMCID . '">Quitar Rango</a>' ;

}elseif ( $isleader == 2 && $CMRank == 9 ){
$Options = '<a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&kick=' . $CMCID . '">Kick</a>' ;
}elseif ( $isleader == 1 && $CMRank == 1 ){
$Options = '<a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&closeclan=true"><span style="font-weight: bold; color:white;">Cerrar Clan.</span>
<br><a
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&resetclanscore=true"><span style="font-weight: bold; color: rgb(200, 20, 255);">Reiniciar Clan</span>
</a>' ;
}elseif ( $CMAID == $myAID ){
$Options = '<a style="color: rgb(255, 204, 0);"
href="http://gunz.utechntertainment.esy.es/index.php?do=clanpanel&CLID=' . $CLID . '&leaveclan=' . $CMCID . '"><span
style="font-weight: bold;">Leave Clan</span>
</a>' ;
}else{
$Options = '<span style="font-style: italic;">None</span>' ;
}

switch ( $CMRank ){
Case 2 ;
$CMRankstr = '<span style="font-weight: bold; color:#ff0000;">Administrador</span>' ;
Break;
Case 1 ;
$CMRankstr = '<span style="font-weight: bold; color:orange;">Lider</span>' ;
Break;
Default;
$CMRankstr = '<span style="font-weight: bold; color:white;">Miembro</span>' ;
Break;
}
?>
<tr>
<td bgcolor="#232323" width="109"><a href="index.php?do=charinfo&id= <? echo $CMAID ; ?> "> <?=$CMName?> </a></td>
<td bgcolor="#232323" width="50"> <?=$CMLevel?> </td>
<td bgcolor="#232323" width="82"> <?=$CMRankstr?> </td>
<td bgcolor="#232323" width="65"> <?=$CMCWP?> </td>
<td bgcolor="#232323" width="208"> <?=$Options?> </td>
</tr>
<? }}else{
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<div style="text-align: center;" id="box">
<div class="news">
<h2>
<table
style="text-align: left; margin-left: auto; margin-right: auto;"
bgcolor="#151515" width="408">
<tbody>
<tr>
<td><div style="text-align: center;">This Clan does not have
any Clan Members yet!</div>
</td>
</tr>
</h2>
</div>
</div>' ; } ?>
</tbody>
</table>
</div>
</td>
<td width="13">&nbsp;</td>
</tr>
<tr>
<td width="9">&nbsp;</td>
<td colspan="3" width="376">&nbsp;</td>
<td width="13">&nbsp;</td>
</tr>
</tbody>
</table>
</div>
</td>
</tr>
</tbody>
</table>
</body>
</html> <? // Fully Coded by: [email protected]
// -- V3.2 --

if( $_SESSION [ UserID ] == "" )
{
Setmessage ( "Administracion de Clanes" , Array( "You are not logged in, you need to login first to Administrate or view Clans!" ));
$doxurl = $_SERVER [ 'QUERY_STRING' ];
SetURL ( "index.php? $doxurl " );
Header ( "Location: index.php?do=login" );
Die();
}
$CLID = Clean ( $_GET [ 'CLID' ]);

If (! is_numeric ( $CLID ) || $CLID == "" ){
Setmessage ( "Administracion de Clanes" , Array( "Wrong Clan CLID!" , "You might login and click on your clan in your user info on the index page." ));
Header ( "Location: index.php" );
Die();
}
$query = mssql_query ( "SELECT * FROM Clan WHERE CLID = ' $CLID '" ); //and Name IS NOT NULL");

if ( mssql_num_rows ( $query ) == 0 ){
Setmessage ( "Administracion de Clanes" , Array( "The ClanID: $CLID doesn't exsit!" , "You might login and click on your clan in your user info on the index

page." ));
Header ( "Location: index.php" );
Die();
}else{
$queryinfo = mssql_fetch_object ( $query );
$Name = $queryinfo -> Name ;
$MasterCID = $queryinfo -> MasterCID ;
$MCQuery = Mssql_query ( "SELECT AID, Name FROM Character WHERE CID = $MasterCID " );
$MCQueryinfo = mssql_fetch_object ( $MCQuery );
$MasterName = $MCQueryinfo -> Name ;
if ( $Name == '' || $Name == NULL ){
$Name = $queryinfo -> DeleteName ;
Setmessage ( "Administracion de Clanes" , Array( "The Clan: ' $Name ' is Deleted!" , "Contact: ' $MasterName ' the Leader of the Clan!" ));
Header ( "Location: index.php" );
Die();
}
settitle ( " GalaxiaGamers Gunz - Clan Panel ($Name)" );
$EmblemUrl = $queryinfo -> EmblemUrl ;
if ( $EmblemUrl == NULL ){ $EmblemUrl = 'noemblem.gif' ;}
$ranking = $queryinfo -> Ranking ;
$Wins = $queryinfo -> Wins ;
$Losses = $queryinfo -> Losses ;
$Points = $queryinfo -> Point ;
$TotalPoints = $queryinfo -> TotalPoint ;
$CreationDate = $queryinfo -> RegDate ;
$MasterAID = $MCQueryinfo -> AID ;
$myAID = Clean ( $_SESSION [ AID ]);
If ( $myAID == $MasterAID ){
$isleader = 1 ;
}
}

if ( $_GET [ 'leaveclan' ] != "" ){
$leaveCID = Clean ( $_GET [ 'leaveclan' ]);
if ( $_GET [ 'confirm' ] == "true" ){
$checkcid = mssql_query ( "SELECT Name FROM Character WHERE AID = $myAID and DeleteFlag = 0 and CID = $leaveCID " );
if ( mssql_num_rows ( $checkcid ) == 1 && $isleader != 1 ){
$checkcidinfo = mssql_fetch_assoc ( $checkcid );
$leaveNAME = $checkcidinfo [ 'Name' ];
$checkclan = mssql_query ( "SELECT Grade FROM ClanMember WHERE CLID = $CLID and CID = $leaveCID " );
if ( mssql_num_rows ( $checkclan ) == 1 ){
$checkclaninfo = mssql_fetch_object ( $checkclan );
$checkgrade = $checkclaninfo -> Grade ;
if ( $checkgrade == 2 ){
$checkgradestr = 'Administrator' ;
}else{
$checkgradestr = 'Normal Member' ;
}
mssql_query ( "DELETE FROM ClanMember WHERE CLID = $CLID and CID = $leaveCID " );
Setmessage ( "Administracion de Clanes Panel" , Array ( "Your Characrer: $leaveNAME as $checkgradestr in Clan: $Name has left it Successfully!" ));
Header ( "Location: index.php?do=index" );
Die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
$linkconfirm = '<a
href="http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID . '&leaveclan=' . $leaveCID . '&confirm=true">http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID .

'&leaveclan=' . $leaveCID . '&confirm=true</a>

' ;
Setmessage ( "Message From Administration Panel" , Array( "Do you really want to leave Clan: $Name ?" , "If yes, Please Click this link Below!" , " $linkconfirm " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
Die();
}
}elseif ( $_GET [ 'resetclanscore' ] == "true" ){
if ( $isleader == 1 ){
mssql_query ( "UPDATE Clan SET Ranking=0, Wins=0, Losses=0, Point=1000, RankIncrease=0, LastDayRanking=0 WHERE CLID = $CLID " );
Setmessage ( "Administracion de Clanes" , Array( "You have Successfully reseted your Clan $Name " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}
if ( $isleader != 1 ){
$myqueryx = mssql_query ( "SELECT CID FROM Character WHERE AID = $myAID and DeleteFlag = 0" );
While ( $myqueryxinfo = mssql_fetch_object ( $myqueryx )){
$querys = mssql_query ( "SELECT Grade FROM ClanMember WHERE CID = ' $myqueryxinfo -> CID ' and CLID = $CLID " );
$mygradex = mssql_fetch_object ( $querys );
$mygradexx = $mygradex -> Grade ;

if ( $mygradexx == 2 ){
$isleader = 2 ;
break;
}
}
}

if ( $_GET [ 'kick' ] != "" || $_GET [ 'demote' ] != "" || $_GET [ 'promote' ] != "" ){

if( $_GET [ 'kick' ] != "" ){ $CID = Clean ( $_GET [ 'kick' ]); $OS = 1 ;}
elseif ( $_GET [ 'demote' ] != "" ){ $CID = Clean ( $_GET [ 'demote' ]); $OS = 2 ;}
else{ $CID = Clean ( $_GET [ 'promote' ]); $OS = 3 ;}

$query1 = mssql_query ( "SELECT Grade FROM ClanMember Where CLID = $CLID and CID = $CID " );
$query1info = mssql_fetch_object ( $query1 );
$GGrade = $query1info -> Grade ;
$query3 = mssql_query ( "SELECT Name From Character WHERE CID = $CID " );
$query3info = mssql_fetch_assoc ( $query3 );
$GName = $query3info [ 'Name' ];

if ( $isleader < $GGrade ){
if ( $OS == 1 ){
mssql_query ( "DELETE FROM ClanMember Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just kicked $GName out Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}elseif ( $OS == 2 && $GGrade == 2 ){
mssql_query ( "UPDATE ClanMember SET Grade = 9 Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just demoted $GName Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}elseif ( $OS == 3 && $isleader == 1 && $GGrade == 9 ){
mssql_query ( "UPDATE ClanMember SET Grade = 2 Where CLID = $CLID And CID = $CID " );
Setmessage ( "Administracion de Clanes" , Array( "You have just promoted $GName Successfully!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}elseif ( $_GET [ 'closeclan' ] != "" ){
if ( $_GET [ 'closeclan' ] == 'true' && $isleader == 1 ){
if ( $_GET [ 'confirm' ] == 'true' ){
Mssql_query ( "DELETE FROM ClanMember WHERE CLID = $CLID " ); // and CID != $MasterCID");
Mssql_query ( "UPDATE Clan SET Name = NULL, DeleteFlag = 1, DeleteName = ' $Name ' WHERE CLID = $CLID " );
Setmessage ( "Administracion de Clanes Panel" , Array ( "You have just Deleted (Closed) your Clan: $Name Successfully!" ));
Header ( "Location: index.php?do=index" );
die();
}else{
$linkconfirm = '<a
href="http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID . '&closeclan=true&confirm=true">http://gunz.galaxiagamers.net/index.php?do=clanpanel&CLID=' . $CLID .

'&closeclan=true&confirm=true</a>

' ;
Setmessage ( "Administracion de Clanes Panel" , Array( "Do you really want to Close (Delete) Clan: $Name ?" , "If yes, Please Click this link Below!" , " $linkconfirm " ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}else{
Setmessage ( "Administracion de Clanes" , Array( "There was an Error, please check your Clan Grade or your entered Link!" ));
Header ( "Location: index.php?do=clanpanel&CLID= $CLID " );
die();
}
}
$membersinlistcount = mssql_num_rows ( Mssql_query ( "SELECT * FROM ClanMember WHERE CLID = ' $CLID '" ));
?>
</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<?
$filhodaputa = array(";","'","\"","*","uninic","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>