<?
include "secure/config.php";
$select = mssql_query("SELECT TOP 5 * FROM ClanGameLog");

SetTitle("DMood Gamers Gunz- Clanwars");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=clanwar");
    SetMessage("Lista clan war", array("Para ver la lista de clanwar necesitas loguearte"));
    header("Location: index.php?do=login");
    die();
}
?>

<table border="1" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									



<font color="#F1E34D"><h1>Lista Clan Wars</h1>
<table align="center" width="174" border="1">
  <tr>
  	<td align="center" colspan="5">Ultimos Clan War</td>
  </tr>
<?
while($row = mssql_fetch_object($select)){
?>

    
  <tr>
  	<td width="8"><font color="#99FF00">+<?=$row->WinnerPoint?></font></td>
    <td width="8"><font color="#99FF00"><?=$row->WinnerClanName?></td>
    <td width="8" align="center"><font color="#F1E34D"><b>VS</b></td>
    <td width="8"><font color="#FF0000"><?=$row->LoserClanName?></td>
    <td width="8"><font color="#FF0000">-<?=$row->LoserPoint?></font></td>

  </tr>
  <? } ?>
  </table>



