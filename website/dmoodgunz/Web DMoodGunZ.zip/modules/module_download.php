<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?
SetTitle("Utech Gunz Entertainment - Descargas");
?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Descargas</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<p align="center">
												<img border="0" src="images/mis_download.jpg" width="365" height="67"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="https://mega.co.nz/#!OZtXFILQ!aS9kulk8LOcaCExAp4aOH1Tnwi_UClFv5aG8W1S0rJ4">
															<img border="0" src="images/btn_mirror1_off.jpg" width="120" height="21" id="img1764" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_mirror1_on.jpg')"></a></td>
															<td>
															<a href="http://www.mediafire.com/download/n5osu9dp732uu16/Utech+GunZ+Entertainment+installer.rar">
															<img border="0" src="images/btn_mirror2_off.jpg" width="120" height="21" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_mirror2_on.jpg')"></a></td>
															<td>
															<a href="http://www.megaupload.com/?d=T2A574XQ">
															<img border="0" src="images/btn_mirror3_off.jpg" width="120" height="21" id="img1766" onmouseover="FP_swapImg(1,0,/*id*/'img1766',/*url*/'images/btn_mirror3_on.jpg')" onmouseout="FP_swapImgRestore()"></a></td>
														</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" height="180" valign="top">
												<div align="center">
													<table border="0" cellpadding="3" cellspacing="1" width="100%">
														<tr>
															<td bgcolor="#121212" width="80">
															<span style="font-size: 7pt">
															&nbsp;</span></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Minimos</span></b></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Recomendados</span></b></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Compatible con:</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Windows 2000, Windows 7, Windows XP, Windows 8, Vista</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															DirectX</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															DirectX 9.0c</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															CPU</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Pentium III 500 Mhz</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Pentium III 800 Mhz
															</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Memory</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															256 MB</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															512 MB or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Graphic Card</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Direct3D 9.0
															Compatible</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															GeForce 4 MX or higher</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212" height="21">
															<span style="font-size: 7pt">
															Sound Card</span></td>
															<td colspan="2" align="center" bgcolor="#232323" height="21">
															<span style="font-size: 7pt">
															Direct3DSound
															Compatible</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Mouse</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Windows Compatible (Mouse De Ruedita Recomendado)</span></td>
														</tr>
													</table>
												</div>
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>