<?php
////////////////////////////
//			Portal		  //
//		   Created		  //
//			  By		  //
//		Jurien Hamaker	  //
////////////////////////////

$homelink = "index.php"; //Your Home Link - Leave if you just use index.php
$gunzlink = "http://gunz.com"; //Your GunZ Link
$maplelink = "http://maplestory.com"; //Your Maplestory Link
$forumlink = "http://community.com"; //Your community Link
$title = "YourGamerZ Portal"; //Titel for the portal
?>