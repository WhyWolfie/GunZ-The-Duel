<html>
<head>
<?php 
////////////////////////////
//					  //
//		   Created		  //
//			  Portal		 
//			  //
////////////////////////////
require('config.php');
?>
<title>Intro sin header</title>
<link href="css/style.css" rel="stylesheet" type="text/css">
	<!-- SLIDER -->
	<link rel="stylesheet" type="text/css" href="css/advanced-slider.css" media="screen"/>
	<script type="text/javascript" src="js/jquery-1.4.3.min.js"></script>
<script type="text/javascript" src="js/jquery.advancedslider.min.js"></script>

<script type="text/javascript">

	$(document).ready(function(){
		$('.slider').advancedSlider({width:613, height:195, slideProperties:{
														9:{effectType:'fade', horizontalSlices:'10', verticalSlices:'5'}
															}});
	});
	
</script>

</head>
<body>
<div id="wrapper">

<a href="<?php echo $homelink; ?>"><div id="logo"></div></a>

<div id="buttons">

<a href="<?php echo $gunzlink; ?>"><div id="gunz"></div></a>
<a href="<?php echo $maplelink; ?>"><div id="maple"></div></a>
<a href="<?php echo $forumlink; ?>"><div id="forum"></div></a>

</div>

<div id="copyright">
<?php
include('css/assets/images/copyright.php');

echo $text;
?>
<a href="http://jurienhamaker.com"><?php echo " $name"; ?></a>
</div>
</div>
</body>
</html>
