<table width="160" height="724" border="0" cellpadding="0" cellspacing="0" bgcolor="#232124">
      <tr>
        <td width="157" height="496" align="center" valign="top"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" height="15"></td>
          </tr>
          <tr>
            <td align="center"><a href="index.php?gunz=download"><img src="img/l_main_sysreqdl.png" width="150" height="45" border="0"></a></td>
          </tr>
          <tr>
            <td align="center" height="14"></td>
          </tr>
          <tr>
            <td align="center"><a href="index.php?gunz=rules"><img src="img/l_howto_renewal.png" width="150" height="76" border="0"></a></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
          <tr>
            <td height="14" align="center"><? include"other/top5clan.php" ?></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="14" align="center"><? include"other/top5player.php" ?></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="14" align="center"><? include"poll/poll_index.php" ?></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="10" align="center">&nbsp;</td>
          </tr>
          <tr>
            <td height="10" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table>