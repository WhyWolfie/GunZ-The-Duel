<?php
// Config Siganture
$url	=	"http://utechgunz.theduelgz.net/new";
$img 	=	"/images/sing.png";

?>