<?php
/////Lo editamos con nuestros datos
$DBHost = 'WIN-9J9ATFODI3O\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'noce123!aA';
$DB = 'GunzDB';
?>
