<style type="text/css">
<!--
.Estilo39 {
    font-family: verdana;
    font-size: 10px;
    color: #FFFFFF;
}
.Estilo40 {
    color: #FFFF33;
    font-size: 18px;
    font-weight: bold;
    font-family: verdana;
}
.Estilo41 {
    font-family: verdana;
    font-size: 10px;
    color: #99FF66;
}
-->
</style>
<link href="../default.css" rel="stylesheet" type="text/css" />
<?
include ("./config.php");
include ("./sec.php");
$conn = @mssql_connect($DBHost, $DBUser, $DBPass);
@mssql_select_db($DB);
$d = "Ly8vLy8gQ29kZWFkbyBwb3IgRGlvc3o=";
if(!isset($_GET['step'])) {
    $_GET['step'] = 1;
}
  
// 
if (isset($_GET['step'])) {
    $argv = explode('-',$_GET['step']);
    settype($argv,'array');
    $_GET['step'] = @$argv[0];
    $_GET['url'] = @$argv[1];
    $_GET['do'] = @$argv[2];
    $_GET['mess'] = @$argv[3];
}
$step = !isset($_GET['step']) ? home : $_GET['step'] ;
        if ($step == '1') { ?>
  
<title>Subir Emblem - Razer Gunz</title>
  
<style type="text/css">
<!--
.Estilo49 {color: #000000}
.Estilo50 {color: #FF0000}
.Estilo51 {
	color: #CC6600;
	font-family: Arial, Helvetica, sans-serif;
}
.Estilo52 {font-family: Arial, Helvetica, sans-serif}
.Estilo53 {
	color: #FF0000;
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
-->
</style>
<FORM name=regform METHOD=POST ACTION="?emblem=index&step=2">
<TABLE width="400" border="1" align="center" cellPadding="3" cellSpacing="0" bordercolor="#333333">
<TBODY>
                                  <TR bgcolor="#2F3A40">
                                    <TD height="98" colSpan="2" align="right" valign="top" class="txt_gray">
                                      <p align="center" class="Estilo53">Subi Tu Emblem Clan</p>
                                      <p align="center" class="Estilo52 Estilo41 Estilo49"><strong> 1.- Subir imagenes en extensiones &quot;jpeg&quot;, &quot;png&quot;, &quot;jpg&quot;.
                                        
                                        2.- Subir imagenes con las dimensiones maximas de &quot;57x56&quot;.
                                        
                                        3.- El uso de archivos de extension &quot;exe&quot; esta totalmente prohibido.
                                        
                                    4.- Al subir imagenes invalidas para perjucio sera el ban absoluto.</strong></p>                                    </TD>
                                  </TR>
                                  <TR>
                                    <TD width="119" height="29" align="right" class="Estilo39">  <div align="left" class="Estilo49"> ID de Login</div> </TD>
                                    <TD width="263">
                                      <input type="textfield" name="user" />                                    </TD>
      </TR>
                                  <TR>
                                    <TD width="119" height="29" align="right" class="Estilo39"> <div align="left" class="Estilo49"> Contrase�a</div> </TD>
                                      <TD width="263">
                                        <input type="password" name="pass" />                                    </TD>
      </TR>
    </TBODY>
  </TABLE>
                              <tr>
                                <div align="center">
                                <img src="images/imagenes_nuevas/Acept.png" width="402" height="26" class="hand" onClick="regform.submit()"/>                                </div>
                              </tr>
</form>  <?
 } if ($step == '2') {
   
$user1 = clean($_POST['user']);
$pass1 = clean($_POST['pass']);
     
  
 $query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");
            while($r = mssql_fetch_array($query)){
if (mssql_num_rows($query) == 1){
                          
                        $query2 = mssql_query("
SELECT     Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID
FROM         ClanMember INNER JOIN
                      Clan ON ClanMember.CLID = Clan.CLID INNER JOIN
                      Login INNER JOIN
                      Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
                      if (mssql_num_rows($query2)){ ?>
                      <form enctype="multipart/form-data" action="?emblem=index&step=done" method="POST" name="regform">
<TABLE width="400" border="1" align="center" cellPadding="3" cellSpacing="0" bordercolor="#333333">
<TBODY>
                                  <TR bgcolor="#2F3A40">
                                    <TD height="150" colSpan="2" align="right" valign="middle" bgcolor="#666666" class="txt_gray">
                                      <p align="center" class="Estilo53">Subi Tu Emblem Clan</p>
                                      <p align="center" class="Estilo52 Estilo41 Estilo49"><strong> 1.- Subir imagenes en extensiones "jpeg", "png", "jpg".
                                        
                                        2.- Subir imagenes con las dimensiones maximas de "57x56".
                                        
                                        3.- El uso de archivos de extension "exe" esta totalmente prohibido.
                                        
                                        4.- Al subir imagenes invalidas para perjucio sera el ban absoluto.</strong></p>                                    </TD>
                                  </TR>
                                  <TR>
                                    <TD width="119" height="29" align="right" class="Estilo39">  <div align="left" class="Estilo49"> Seleccione la imagen</div> </TD>
                                    <TD width="263" bgcolor="#333333"> <input name="uploaded" type="file" size="18"></TD>
                                 </TR>
                                  <TR>
                                    <TD width="119" height="29" align="right" class="Estilo39"> <div align="left" class="Estilo49"> Seleccione el Clan</div> </TD>
                                      <TD width="263" bgcolor="#333333">
                                        <select name="clan">
<?
                            for($i='';$i < @mssql_num_rows($query2);++$i){
                            $row = @mssql_fetch_row($query2);
                            $ClanName = $row[4]; ?>
                            <option value="<?=$row[4]?> "> <?=$row[4]?> </option>
                              
  
                            <? }?>
</select>                                    </TD>
                                  </TR>
    </TBODY>
                        </TABLE>
                              <tr>
                                <div align="center">
                                <img src="images/imagenes_nuevas/Acept2.png" width="402" height="26" class="hand" onClick="regform.submit()"/>                                </div>
                              </tr>
  
</form>  <?
                            }else { echo " ERROR GEEN CLAN ";} }
                            }
            ;
        }
      
    ;
      
    if ($step == 'done') {                 
    $emblem = $_POST['uploaded'] ;
    $CLID = $_POST['clan'];
$target = "./upload/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$ok=1;
$ext = pathinfo($target);
$EXT1 = strtolower($ext['extension']);
$f = $ext['basename'];
if($EXT1 != "jpg" && $EXT1 != "png" && $EXT1 != "jpeg") {
    $ok = 0; } else { $ok = 1; }
  
  
//
  
  
if ($ok==0)
{
alertbox("Error!!! Tu imagen no ha subido, verifica la extension y el tipo de archivo.","?emblem=index&step=1");
  
}
  
else
{
        $q = mssql_query("SELECT * From Clan Where Name='$CLID'");
$s = mssql_fetch_assoc($q);
if(!empty($s['EmblemUrl'])) { $g = pathinfo($s['EmblemUrl']); unlink("./upload/".$g['basename']); }
if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
{
      
do {
$archivo = Random();
$archivo = $archivo . ".";
$archivo = $archivo . $EXT1;
} while(file_exists($archivo));
  
    rename("./upload/".$f,"./upload/".$archivo);
mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
mssql_query ("UPDATE Clan SET EmblemUrl = '".$archivo."' WHERE Name = '$CLID'");
alertbox("Felicidades!!! Tu imagen ha subido con exito. $EXT1","?emblem=index&step=1");
  
}
else
{
alertbox("Error!!! Ha ocurrido un problema al intentar subir la imagen","emblem=index&step=1");
}
}
};
echo base64_decode(f());
?> 