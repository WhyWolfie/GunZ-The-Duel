<?php
/////Lo editamos con nuestros datos
$DBHost = 'WIN-CBL52RPDQUK\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'RazerGunz022';
$DB = 'RazerGunz';
?>