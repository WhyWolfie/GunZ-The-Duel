<?php
header ("Location: /error404/index.php");
?>