<?
include("secure/config.php");
include("secure/functions.php");
include("secure/anti_inject.php");
include("secure/sql_check.php");
include("secure/shield.php");
include("secure/banneduser.php");
include("secure/checkcookie.php");
include("secure/ctracker.php");
include("secure/equipt.inc.php");
require("criminalteam.php");
#include("GGAntiKoreWeb.dll");
#include("Korean.dll");

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost:8080/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "Avicii Gunz - Home", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost:8080/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>%TITLE%</title>
<script language=JavaScript>m='%3Cscript%20language%3D%22JavaScript%22%3E%0A%3C%21--%0A%3C%21--%0A%0Afunction%20FP_swapImgRestore%28%29%20%7B//v1.0%0A%20var%20doc%3Ddocument%2Ci%3B%20if%28doc.%24imgSwaps%29%20%7B%20for%28i%3D0%3Bi%3Cdoc.%24imgSwaps.length%3Bi++%29%20%7B%0A%20%20var%20elm%3Ddoc.%24imgSwaps%5Bi%5D%3B%20if%28elm%29%20%7B%20elm.src%3Delm.%24src%3B%20elm.%24src%3Dnull%3B%20%7D%20%7D%0A%20%20doc.%24imgSwaps%3Dnull%3B%20%7D%0A%7D%0A%0Afunction%20FP_swapImg%28%29%20%7B//v1.0%0A%20var%20doc%3Ddocument%2Cargs%3Darguments%2Celm%2Cn%3B%20doc.%24imgSwaps%3Dnew%20Array%28%29%3B%20for%28n%3D2%3B%20n%3Cargs.length%3B%0A%20n+%3D2%29%20%7B%20elm%3DFP_getObjectByID%28args%5Bn%5D%29%3B%20if%28elm%29%20%7B%20doc.%24imgSwaps%5Bdoc.%24imgSwaps.length%5D%3Delm%3B%0A%20elm.%24src%3Delm.src%3B%20elm.src%3Dargs%5Bn+1%5D%3B%20%7D%20%7D%0A%7D%0A%0Afunction%20FP_preloadImgs%28%29%20%7B//v1.0%0A%20var%20d%3Ddocument%2Ca%3Darguments%3B%20if%28%21d.FP_imgs%29%20d.FP_imgs%3Dnew%20Array%28%29%3B%0A%20for%28var%20i%3D0%3B%20i%3Ca.length%3B%20i++%29%20%7B%20d.FP_imgs%5Bi%5D%3Dnew%20Image%3B%20d.FP_imgs%5Bi%5D.src%3Da%5Bi%5D%3B%20%7D%0A%7D%0A%0Afunction%20FP_getObjectByID%28id%2Co%29%20%7B//v1.0%0A%20var%20c%2Cel%2Cels%2Cf%2Cm%2Cn%3B%20if%28%21o%29o%3Ddocument%3B%20if%28o.getElementById%29%20el%3Do.getElementById%28id%29%3B%0A%20else%20if%28o.layers%29%20c%3Do.layers%3B%20else%20if%28o.all%29%20el%3Do.all%5Bid%5D%3B%20if%28el%29%20return%20el%3B%0A%20if%28o.id%3D%3Did%20%7C%7C%20o.name%3D%3Did%29%20return%20o%3B%20if%28o.childNodes%29%20c%3Do.childNodes%3B%20if%28c%29%0A%20for%28n%3D0%3B%20n%3Cc.length%3B%20n++%29%20%7B%20el%3DFP_getObjectByID%28id%2Cc%5Bn%5D%29%3B%20if%28el%29%20return%20el%3B%20%7D%0A%20f%3Do.forms%3B%20if%28f%29%20for%28n%3D0%3B%20n%3Cf.length%3B%20n++%29%20%7B%20els%3Df%5Bn%5D.elements%3B%0A%20for%28m%3D0%3B%20m%3Cels.length%3B%20m++%29%7B%20el%3DFP_getObjectByID%28id%2Cels%5Bn%5D%29%3B%20if%28el%29%20return%20el%3B%20%7D%20%7D%0A%20return%20null%3B%0A%7D%0A%0Afunction%20UpdatePrice%28%29%0A%7B%0A%09try%0A%09%7B%0A%09var%20SelectedDays%20%3D%20document.frmBuy.rentdays.value%3B%0A%09var%20PricePerDay%20%3D%20Math.ceil%28document.getElementById%28%22currentprice%22%29.innerHTML%20/%2010%29%3B%0A%09var%20CurrentFounds%20%3D%20document.getElementById%28%22currbalance%22%29.innerHTML%3B%0A%09document.getElementById%28%22dayprice%22%29.innerHTML%20%3D%20PricePerDay%3B%0A%0A%09document.getElementById%28%22Total%22%29.innerHTML%20%3D%20SelectedDays%20*%20PricePerDay%3B%0A%0A%09document.getElementById%28%22afterpur%22%29.innerHTML%20%3D%20CurrentFounds%20-%20%28SelectedDays%20*%20PricePerDay%29%3B%0A%0A%09if%28CurrentFounds%20%3C%20%28SelectedDays%20*%20PricePerDay%29%29%7B%0A%09%09alert%28%22You%20not%20have%20enought%20euCoins%20to%20buy%20%22%20+%20SelectedDays%20+%20%22%20days%22%29%3B%0A%09%09document.frmBuy.rentdays.value%20%3D%20%2210%22%3B%0A%09%09//UpdatePrice%28%29%3B%0A%09%7D%0A%0A%09%7Dcatch%28err%29%7B%0A%0A%09%7D%0A%0A%7D%0A//%20--%3E%0A%0Afunction%20MM_swapImgRestore%28%29%20%7B%20//v3.0%0A%20%20var%20i%2Cx%2Ca%3Ddocument.MM_sr%3B%20for%28i%3D0%3Ba%26%26i%3Ca.length%26%26%28x%3Da%5Bi%5D%29%26%26x.oSrc%3Bi++%29%20x.src%3Dx.oSrc%3B%0A%7D%0A%0Afunction%20MM_preloadImages%28%29%20%7B%20//v3.0%0A%20%20var%20d%3Ddocument%3B%20if%28d.images%29%7B%20if%28%21d.MM_p%29%20d.MM_p%3Dnew%20Array%28%29%3B%0A%20%20%20%20var%20i%2Cj%3Dd.MM_p.length%2Ca%3DMM_preloadImages.arguments%3B%20for%28i%3D0%3B%20i%3Ca.length%3B%20i++%29%0A%20%20%20%20if%20%28a%5Bi%5D.indexOf%28%22%23%22%29%21%3D0%29%7B%20d.MM_p%5Bj%5D%3Dnew%20Image%3B%20d.MM_p%5Bj++%5D.src%3Da%5Bi%5D%3B%7D%7D%0A%7D%0A%0Afunction%20MM_findObj%28n%2C%20d%29%20%7B%20//v4.01%0A%20%20var%20p%2Ci%2Cx%3B%20%20if%28%21d%29%20d%3Ddocument%3B%20if%28%28p%3Dn.indexOf%28%22%3F%22%29%29%3E0%26%26parent.frames.length%29%20%7B%0A%20%20%20%20d%3Dparent.frames%5Bn.substring%28p+1%29%5D.document%3B%20n%3Dn.substring%280%2Cp%29%3B%7D%0A%20%20if%28%21%28x%3Dd%5Bn%5D%29%26%26d.all%29%20x%3Dd.all%5Bn%5D%3B%20for%20%28i%3D0%3B%21x%26%26i%3Cd.forms.length%3Bi++%29%20x%3Dd.forms%5Bi%5D%5Bn%5D%3B%0A%20%20for%28i%3D0%3B%21x%26%26d.layers%26%26i%3Cd.layers.length%3Bi++%29%20x%3DMM_findObj%28n%2Cd.layers%5Bi%5D.document%29%3B%0A%20%20if%28%21x%20%26%26%20d.getElementById%29%20x%3Dd.getElementById%28n%29%3B%20return%20x%3B%0A%7D%0A%0Afunction%20MM_swapImage%28%29%20%7B%20//v3.0%0A%20%20var%20i%2Cj%3D0%2Cx%2Ca%3DMM_swapImage.arguments%3B%20document.MM_sr%3Dnew%20Array%3B%20for%28i%3D0%3Bi%3C%28a.length-2%29%3Bi+%3D3%29%0A%20%20%20if%20%28%28x%3DMM_findObj%28a%5Bi%5D%29%29%21%3Dnull%29%7Bdocument.MM_sr%5Bj++%5D%3Dx%3B%20if%28%21x.oSrc%29%20x.oSrc%3Dx.src%3B%20x.src%3Da%5Bi+2%5D%3B%7D%0A%7D%0A//--%3E%0A%3C/script%3E%0A%0A%3Cscript%20type%3D%22text/javascript%22%20src%3D%22ajax/utilities/utilities.js%22%3E%3C/script%3E%0A%3Cscript%20type%3D%22text/javascript%22%20src%3D%22ajax/container/container.js%22%3E%3C/script%3E%0A%3Clink%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20href%3D%22e_style.css%22%3E';d=unescape(m);document.write(d);</script>

<style type="text/css">
<!--
.Estilo1 {color: #373737}
#Layer1 {
	position:absolute;
	left:427px;
	top:21px;
	width:182px;
	height:70px;
	z-index:1;
}
-->
</style>
</head>
<body bgcolor="FFCECB" background="fondo1.jpg" onLoad="MM_preloadImages('bar/inicioon.png','bar/ranon.png','bar/foroon.png','images/menu/home_on.gif','../gunz/images/menu/foro_on.png','../gunz/images/menu/registro_on.gif','../gunz/images/menu/descarga_on.gif','../gunz/images/menu/ranking_on.gif','../gunz/images/menu/tienda_on.gif')">
<body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('') no-repeat center top" onLoad="MM_preloadImages('bar/inicioon.png','bar/Regon.png','bar/deson.png','bar/ranon.png','bar/sd.png','bar/donon.png','bar/itemson.png','bar/foroon.png')">
<center>
</center><center>

</script>
<div id="fb-root"></div>
<!--Script del Menu -->
<script language=JavaScript>m='%3Cscript%3E%28function%28d%2C%20s%2C%20id%29%20%7B%0A%20%20var%20js%2C%20fjs%20%3D%20d.getElementsByTagName%28s%29%5B0%5D%3B%0A%20%20if%20%28d.getElementById%28id%29%29%20return%3B%0A%20%20js%20%3D%20d.createElement%28s%29%3B%20js.id%20%3D%20id%3B%0A%20%20js.src%20%3D%20%22//connect.facebook.net/es_ES/all.js%23xfbml%3D1%22%3B%0A%20%20fjs.parentNode.insertBefore%28js%2C%20fjs%29%3B%0A%7D%28document%2C%20%27script%27%2C%20%27facebook-jssdk%27%29%29%3B%3C/script%3E%0A%3Cscript%3E%0A%0A%3C%21--%20Begin%20--%3E%0A%0AloadImage0%20%3D%20new%20Image%28%29%3B%0A%0AloadImage0.src%20%3D%20%22images/nav-home_on.png%22%3B%0A%0AstaticImage0%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage0.src%20%3D%20%22images/nav-home.png%22%3B%0A%0A%0A%0AloadImage1%20%3D%20new%20Image%28%29%3B%0A%0AloadImage1.src%20%3D%20%22images/nav-reg_on.png%22%3B%0A%0AstaticImage1%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage1.src%20%3D%20%22images/nav-reg.png%22%3B%0A%0A%0A%0AloadImage2%20%3D%20new%20Image%28%29%3B%0A%0AloadImage2.src%20%3D%22images/nav-down_on.png%22%3B%0A%0AstaticImage2%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage2.src%20%3D%20%22images/nav-down.png%22%3B%0A%0A%0A%0AloadImage3%20%3D%20new%20Image%28%29%3B%0A%0AloadImage3.src%20%3D%20%22images/nav-logo_on.png%22%3B%0A%0AstaticImage3%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage3.src%20%3D%20%22images/nav-logo.png%22%3B%0A%0A%0A%0AloadImage4%20%3D%20new%20Image%28%29%3B%0A%0AloadImage4.src%20%3D%20%22images/nav-clan_on.png%22%3B%0A%0AstaticImage4%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage4.src%20%3D%20%22images/nav-clan.png%22%3B%0A%0A%0A%0AloadImage5%20%3D%20new%20Image%28%29%3B%0A%0AloadImage5.src%20%3D%20%22images/nav-mark_on.png%22%3B%0A%0AstaticImage5%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage5.src%20%3D%20%22images/nav-mark.png%22%3B%0A%0A%0A%0AloadImage6%20%3D%20new%20Image%28%29%3B%0A%0AloadImage6.src%20%3D%20%22images/nav-com_on.png%22%3B%0A%0AstaticImage6%20%3D%20new%20Image%28%29%3B%0A%0AstaticImage6.src%20%3D%20%22images/nav-com.png%22%3B%0A%0A//%20End%20--%3E%0A%0A%3C/script%3E%0A';d=unescape(m);document.write(d);</script>
<!--Fin del Script del Menu -->
<script language=JavaScript>m='%3Cscript%20type%3D%22text/javascript%22%20src%3D%22ajax/utilities/utilities.js%22%3E%3C/script%3E%0A%0A%3Cscript%20type%3D%22text/javascript%22%20src%3D%22ajax/container/container.js%22%3E%3C/script%3E%0A%0A%3Clink%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20href%3D%22e_style.css%22%3E';d=unescape(m);document.write(d);</script>



<!-- Navbar -->

<center>

</head>

<div id="navbar">

<a href="index.php" onMouseOver="image0.src=loadImage0.src;" onMouseOut="image0.src=staticImage0.src;">

<img name="image0" align="top" src="images/nav-home.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="114" width="121"></img></a><a href="index.php?do=register" onMouseOver="image1.src=loadImage1.src;" onMouseOut="image1.src=staticImage1.src;"><img name="image1" align="top" src="images/nav-reg.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="109" width="99"></img></a><a href="index.php?do=download" onMouseOver="image2.src=loadImage2.src;" onMouseOut="image2.src=staticImage2.src;"><img name="image2" align="top" src="images/nav-down.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="95" width="98"></img></a><a href="index.php" onMouseOver="image3.src=loadImage3.src;" onMouseOut="image3.src=staticImage3.src;"><img name="image3" align="top"  src="images/nav-logo.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="92" width="195"></img></a><a href="index.php?do=individualrank" onMouseOver="image4.src=loadImage4.src;" onMouseOut="image4.src=staticImage4.src;"><img name="image4" align="top" src="images/nav-clan.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="95" width="89"></img></a><a href="index.php?do=shop" onMouseOver="image5.src=loadImage5.src;" onMouseOut="image5.src=staticImage5.src;"><img name="image5" align="top" src="images/nav-mark.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="106" width="94"></img></a><a href="http://ggamers.sytes.net/foro" onMouseOver="image6.src=loadImage6.src;" onMouseOut="image6.src=staticImage6.src;"><img name="image6" align="top" src="images/nav-com.png" id="btnFreeGame" alt="" style="cursor: pointer;" onClick="toggleFreeArea();" border="0" height="113" width="134"></img></a></div>

</center>

<!-- End of Navbar -->
	<table border="0" style="border-collapse: collapse" width="90%">
		<tr>
		  <td><p align="center">&nbsp;</p></td>
		</tr>
		<tr>
		  <td><center>
		    <img src="images/banner_2.png" width="780" height="313">
		  </center>
		  
		  </td>
	  </tr>
		<tr>
			<td>
		<div align="center">

		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3"></td>
          </tr>
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {
                
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";
			?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("Se produjo un error", array("Module '$do' No Encontrado"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>			</td>
            <td width="12">&nbsp;</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">&nbsp;			</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">
			<p align="center">&nbsp;<map name="FPMap0">
			  <area href="mailto:Elpapi1112@hotmai.com" shape="rect" coords="535,13,599,87">
			</map><img border="0" src="images/top_bg.jpg" width="626" height="102" usemap="#FPMap0"></td>
          </tr>
        </tbody></table>
          </div>          	</td>
		</tr>
	</table>
</div>


</body>

</html>
</body><body topmargin="o" leftmargin="o" ringhtmargin="0" bottomargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/Fondo.png') no-repeat center top">
<head>
</body><body topmargin="o" leftmargin="o" ringhtmargin="0" bottomargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/Fondo.png') no-repeat center top">
</body>
<head>


</body><body topmargin="o" leftmargin="o" ringhtmargin="0" bottomargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/Fondo.png') no-repeat center top">
</body>

<script language=JavaScript>m='%3Clink%20href%3D%22js/face.css%22%20rel%3D%22stylesheet%22%20type%3D%22text/css%22%20/%3E%0A%3Cscript%20src%3D%27js/jquery2.js%27%20type%3D%27text/javascript%27%3E%3C/script%3E%0A%3Cscript%20src%3D%27js/facebook.js%27%20type%3D%27text/javascript%27%3E%3C/script%3E';d=unescape(m);document.write(d);</script>
<!-- Codigo del Facebook -->
<script language=JavaScript>m='%3Cdiv%20class%3D%27clear%27%3E%3C/div%3E%3C/div%3E%3Cdiv%20class%3D%27widget%20HTML%27%20id%3D%27HTML12%27%3E%3Cdiv%20class%3D%27widget-content%27%3E%3Cdiv%20class%3D%22slide_likebox%22%3E%20%3Cdiv%20style%3D%22color%3A%20rgb%28255%2C%20255%2C%20255%29%3B%20padding%3A%209px%205px%200pt%2050px%3B%22%3E%3Cspan%3E%3Cdiv%20class%3D%27likeboxwrap%27%3E%3Ciframe%20src%3D%22//www.facebook.com/plugins/likebox.php%3Fhref%3Dhttp%253A%252F%252Fwww.facebook.com%252FGunzgalaxia%26amp%3Bwidth%3D238%26amp%3Bheight%3D258%26amp%3Bcolorscheme%3Dlight%26amp%3Bshow_faces%3Dtrue%26amp%3Bborder_color%26amp%3Bstream%3Dfalse%26amp%3Bheader%3Dfalse%22%20scrolling%3D%22no%22%20frameborder%3D%220%22%20style%3D%22border%3Anone%3B%20overflow%3Ahidden%3B%20width%3A238px%3B%20height%3A258px%3B%22%20allowTransparency%3D%22true%22%3E%3C/iframe%3E';d=unescape(m);document.write(d);</script>
<!-- Fin Codigo del Facebook -->