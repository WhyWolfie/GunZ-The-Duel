<? 
$nombregunz			=		"Avicii Gunz";		
$precio			=		"200";  
$coins		=		"EventCoins";
$redirec		=		"nicks"; 
$numjjang	=	"2";
$namejjang	=	"Jjang";
?>