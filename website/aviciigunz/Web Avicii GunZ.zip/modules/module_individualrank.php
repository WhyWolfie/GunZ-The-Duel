<?

SetTitle("Avicii Gunz - Ranking Individual");

?>

<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

//-->
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script><head>
<meta http-equiv="Content-Language" content="es" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<style type="text/css">
<!--
.Estilo7 {font-size: 12px; font-weight: bold; }
-->
</style>
</head>





<table border="0" style="border-collapse: collapse" width="778">
					<tr>
						<td width="164" style="background-image: url('images/md_content_menu.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="164">
								<tr>
									<td width="158" height="36">&nbsp;</td>
									<td width="158" height="36">&nbsp;</td>
									<td width="158" height="36">&nbsp;</td>
								</tr>
								<tr>
									<td width="158">&nbsp;</td>
									<td width="158">
									<img border="0" src="images/btn_individualrank_on.jpg" id = "76176img" width="131" height="21" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_individualrank_on.jpg')" /></td>
									<td width="158">&nbsp;</td>
								</tr>
								<tr>
									<td width="158">&nbsp;</td>
									<td width="158">
									<a href="index.php?do=clanrank">
									<img border="0" src="images/btn_clanranking_off.jpg" id="7816img271" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img271',/*url*/'images/btn_clanranking_on.jpg')" /></a></td>
									<td width="158">&nbsp;</td>
								</tr>
						  </table>
						</div>
						</td>
						<td width="4">&nbsp;<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p></p></td>
						<td width="599" valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-image: url('images/content_title_ranking2.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;<p>&nbsp;</p>
									<p></p></td>
								  <td style="background-repeat: repeat; background-position: center top" width="583" valign="top"><img border="0" src="images/mis_rankinglegend.jpg" width="563" height="30" /></td>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;</td>
								</tr>
								<tr>
									<td width="583" height="5" valign="top" style="background-repeat: repeat; background-position: center top"><div align="center"></td>
								</tr>
								<tr>
								  <td style="background-repeat: repeat; background-position: center top" width="583" valign="top"><?

if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Character") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 20; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Character where Level not in (select top $max Level from Character order by Level desc) order by Level desc");
$name = mssql_fetch_row($result);
?>
        	<div id="wrapper-cent">
             
			 
			 
									
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title"></div>
                	</div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        <div id="ranking-table-title"></div>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" id="ranking-table">
                              <tr class="titles">
                                <td width="4%">R&ordm;</td>
                                <td width="26%"><span class="Estilo7">Nombre</span></td>
                                <td width="8%"><span class="Estilo7">Lvl</span></td>
                                
                                <td width="15%"><span class="Estilo7">Exp</span></td>
                                <td width="17%"><span class="Estilo7">Kill/Death</span></td>
                                <td width="30%"><span class="Estilo7">Ultima Coneccion </span></td>
                              </tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
			       <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
			      </tr>
				  <p><tr>
                                <td><?=$rank?></td>
                                <td><?=FormatCharName($row[0])?></td>
                                <td><?php echo "$row[3]";?></td>
                                <td><?php echo "$row[8]";?></td>
                                <td><?php echo "$row[32]";?>/<?php echo "$row[33]";?></td>
                                <td><?php echo "$row[29]";?></td>
			      </tr>
				  
  <?
  $i++;
  }
   ?>
                            </table>
                            <div id="ranking-table-footer"></div>

<p align="center"><a href="index.php?do=individualrank">[1-20]</a> - <a href="index.php?do=individualrank&pagenum=2">[21-40]</a> - <a href="index.php?do=individualrank&pagenum=3">[41-60]</a>
									- <a href="index.php?do=individualrank&pagenum=4">[61-80]</a> - <a href="index.php?do=individualrank&pagenum=5">[81 - 100]</a></p>
</center>
                           
                            <br class="clear" />
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright"></div>
            </div>								  </td>
								</tr>
								<tr>
								  <td style="background-repeat: no-repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<p></p></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
</table>
<head>
<?
$filhodaputa = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>
</body>