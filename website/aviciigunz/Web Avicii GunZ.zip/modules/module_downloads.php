<?
header("Location: http://aviciigunz.com/");
?>