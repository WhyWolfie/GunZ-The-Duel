<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
if($_SESSION[AID] == "")
{
    SetMessage("Mensaje de Avicii Gamers", array("Porfavor, Logueate primero."));
    SetURL("index.php?do=staff");
    header("Location: index.php?do=login");
    die();
}

if(isset($_POST[Checksubmit]))
{
    $pass = clean($_POST[CheckPass]);
    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Login(nolock) WHERE UserID = '{$_SESSION[UserID]}' AND Password = '$pass'")) == 1)
    {
        $_SESSION[Modify] = $_SESSION[AID];
    }else{
        SetMessage("Por Favor Verifique La Informacion", array("Contrase�a incorrecta."));
        $_SESSION[Modify] = 0;
        header("Location: index.php?do=staff");
        die();
    }
}

if($_SESSION[Modify] != $_SESSION[AID])
{
?>
<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
-->
</style>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
									<b><font face="Tahoma" size="2">Ingrese su contrase�a</font></b></td>
								</tr>
								<tr>
									<td>
									<div align="center">
										<form method="POST" action="index.php?do=staff" name="staff">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<div align="center">
												<span class="Estilo1">Para ver la lista de staff ingrese su contrase�a.</span></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="177" style="background-repeat: no-repeat; background-position: center top">
												<div align="right">
												<span class="Estilo1">Contrase�a</span></td>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="209" style="background-repeat: no-repeat; background-position: center top">
												<input name="CheckPass" size="20" class="textLogin" style="float: left" type="password"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<div align="center">
												<input border="0" src="images/btn_continue_off.jpg" name="I1" width="136" height="22" id="img1337" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1337',/*url*/'images/btn_continue_on.jpg')" type="image"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>
											<input type="hidden" name="Checksubmit" value="1"></form>
									</div>
								  </td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<?
}else{



if(isset($_POST[submit]) && $_SESSION[Modify] == $_SESSION[AID])
{
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);

    $errors = array();

    if($pass[0] <> $pass[1])
        array_merge($errors, array("La contrase�a no Existe"));

    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'")) <> 0)
        array_merge($errors, array("El email esta en uso"));

    if($pass[0] <> "" || $pass[1] <> "")
        array_merge($errors, array("Porfavor Introduce tu contrase�a"));

    if($email <> "")
        array_merge($errors, array("Porfavor Introduce tu e-mail"));

    if($sq <> "")
        array_merge($errors, array("Porfavor Introduce tu Pregunta Secreta"));

    if($sa <> "")
        array_merge($errors, array("Porfavor Introduce tu Respuesta Secreta"));

    if(strlen($pass[0]) < 6)
        array_merge($errors, array("La Contrase�a debe ser minimo de 6 caracteres"));

    if(count($errors) == 0)
    {
        mssql_query_logged("UPDATE Account SET Email = '$email' WHERE AID = '{$_SESSION[AID]}'");

        if($_POST[C1] == "ON")
        {
	                  
	    mssql_query_logged("UPDATE Login SET Password = '".$pass[0]."' WHERE AID = '{$_SESSION[AID]}'");
            $_SESSION['Password'] = $pass[0];
        }
        if($_POST[C2] == "ON")
        {
            mssql_query_logged("UPDATE Account SET sq = '$sq', sa = '$sa' WHERE AID = '{$_SESSION[AID]}'");
        }
        SetMessage("Mensaje del GunZ", array("Cuenta Actualizada Perfectamente"));
        header("Location: index.php?do=staff");
        die();
    }else{
        SetMessage("Por Favor Verifique La Informacions", $errors);
        header("Location: index.php?do=staff");
        die();
    }
}else{
    SetTitle("Avicii Gunz - Lista de Staff");
    $europe = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

    $p = GetCountryCodeByIP($_SERVER[REMOTE_ADDR]);
    if(in_array(strtoupper($p), $europe))
    {
        $country = sprintf("[<font color='#00FF00'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }else{
        $country = sprintf("[<font color='#FF0000'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }

    $r = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));
    $a = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Login(nolock) WHERE AID = {$_SESSION[AID]}"));

    $_MEMBER[UserID]        = $r[UserID];
    $_MEMBER[EMail]         = $r[Email];
    $_MEMBER[SA]            = $r[sa];
    $_MEMBER[SQ]            = $r[sq];
}


?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
								  <td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top"><span style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top"><b><font face="Tahoma" size="2">Personal de AviciiGunz </font></b></td>
								</tr>
								<tr>
								  <td><table width="500" border="0">
                                        <tr>
                                          <td><div align="center"><img src="/images/Modules_image/StaffPersonal.png" alt="Staff" width="500" height="78" /></div></td>
                                        </tr>
                                        <tr>
                                          <td height="100" valign="top"><table width="494">
                                              <tr>
                                                <td width="156"><div align="center" class="Estilo7 Estilo1 Estilo2">
                                                  <div align="left"><span class="Estilo6"><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" /><span class="Estilo10">Avicii </span></span></div>
                                                </div></td>
                                                <td width="181"><div align="center" class="Estilo1">
                                                  <div align="left"><a href=" " class="Estilo6"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" border="0" /></a></div>
                                                </div></td>
                                                <td width="141"><div align="center" class="Estilo3">
                                                  <div align="left"><img src="/images/inconos/admin.png" alt="admin1" width="10" height="10" />Due�o de Avicii GunZ</div>
                                                </div></td>
                                              </tr>
                                              <tr>
                                                <td><div align="center" class="Estilo7 Estilo1 Estilo10">
                                                  <div align="left"><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" />KingRuben</div>
                                                </div></td>
                                                <td><div align="center" class="Estilo1">
                                                  <div align="left"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" /></div>
                                                </div></td>
                                                <td><div align="center" class="Estilo7 Estilo1 Estilo4">
                                                  <div align="left"><span class="Estilo3"><img src="/images/inconos/admin.png" alt="admin1" width="10" height="10" /></span> <span class="Estilo4">Administrador</span></div>
                                                </div></td>
                                              </tr>
                                              <tr>
                                                <td><div align="center" class="Estilo1 Estilo10">
                                                  <div align="left"><span class="Estilo11"><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" />Zerok77</span></div>
                                                </div></td>
                                                <td><div align="center" class="Estilo1">
                                                  <div align="left"><a href=" " class="Estilo6"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" border="0" /></a></div>
                                                </div></td>
                                                <td><div align="center" class="Estilo8 Estilo1">
                                                  <div align="left" class="Estilo2">
                                                    <div align="left"><span class="Estilo1"><img src="/images/inconos/adminmod.png" alt="admin1" width="10" height="10" /></span> <span class="Estilo5">Administrador del Servidor </span></div>
                                                  </div>
                                                </div></td>
                                              </tr>
                                              <tr>
                                                <td height="14"><div align="center" class="Estilo1 Estilo10">
                                                  <div align="left"><span class="Estilo11"><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" />ProXioM</span></div>
                                                </div></td>
                                                <td><div align="center" class="Estilo1">
                                                  <div align="left"><a href=" " class="Estilo6"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" border="0" /></a></div>
                                                </div></td>
                                                <td><div align="center" class="Estilo1 Estilo8">
                                                  <div align="left"><span class="Estilo1"><img src="/images/inconos/mod.png" alt="admin1" width="10" height="10" /></span> <span class="Estilo6">Super Moderador </span></div>
                                                </div></td>
                                              </tr>
                                              <tr>
                                                <td><div align="left" class="Estilo10"><span class="Estilo11 Estilo1 "><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" />Zalish</span></div></td>
                                                <td><div align="left"><a href=" " class="Estilo6"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" border="0" /></a></div></td>
                                                <td><div align="left" class="Estilo9">
                                                  <div align="left"><img src="/images/inconos/mod.png" alt="admin1" width="10" height="10" /> <span class="Estilo6">Moderador </span></div>
                                                </div></td>
                                              </tr>
                                              <tr>
                                                <td><span class="Estilo11 Estilo1 Estilo10"><img src="/images/inconos/staff_personal.png" alt="j" width="10" height="10" />No  hay</span></td>
                                                <td><div align="left"><span class="Estilo1"><a href=" " class="Estilo6"><img src="/images/inconos/E_Mail.png" alt="E" width="10" height="10" border="0" /></a></span></div></td>
                                                <td><div align="left" class="Estilo9">
                                                  <div align="left"><img src="/images/inconos/mod.png" alt="admin1" width="10" height="10" /><span class="Estilo6"></span></div>
                                                </div></td>
                                              </tr>
                                            </table>                                            
                                          </td>
                                        </tr>
                                  </table></td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table></td>    <?}?>&nbsp;