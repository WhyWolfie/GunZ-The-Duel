<?php
// Config Siganture
$url	=	"http://LegendGunz.net";
$img 	=	"images/sing.png";

?>