<? 
/////////////////////////////////////////
//				NO TOCAR				//
//_____________________________________//
/////////////////////////////////////////

include "secure/functions.php";
include "secure/config.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "configsing.php";


    $cid = $_GET['cid'];
    $res = mssql_query("SELECT * FROM Character WHERE CID = '" . ($cid) . "'");  
    $char = mssql_fetch_assoc($res);
    $res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'");
    $clan = mssql_fetch_assoc($res2);
    $res3 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'");
    $claninfo = mssql_fetch_assoc($res3);
    


    if($cid == "")
       $cid = 1;

    if($claninfo == "")
       $claninfo = "-";


header("Content-type: image/png");


$i = imagecreatefrompng($img);


$name = ($char['Name']);
$level = ($char['Level']);
$clan = ($claninfo['Name']);
$nextvariable = $variabletable['table'];

$preto = imagecolorallocate($i, 255,255,255);
$azul = imagecolorallocate($i, 255,255,255);
// Fonte
$fonte = "sacker.ttf";


imagettftext($i, 13, 0, 93, 74,$azul,$fonte,$name);
imagettftext($i, 13, 0, 240, 74,$azul,$fonte,$level);
imagettftext($i, 13, 0, 90, 97,$azul,$fonte,$nextvariable);
imagettftext($i, 13, 0, 83, 111,$azul,$fonte,$clan);



imagepng($i);


imagedestroy($i);

//Coding By Sacker :)
?>