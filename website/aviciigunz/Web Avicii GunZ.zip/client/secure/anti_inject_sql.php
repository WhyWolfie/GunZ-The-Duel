<?

function clean_bad_chars($char)

{

$ban=0;
$char_w_replaced = stripslashes($char);
$hack_array = array("'", '"', ";", "UNION", "union", "DROP", "drop", "table", "TABLE", "SET", "set", "UPDATE", "update", "SELECT", "select", "-", "--", "MEMB_INFO", "memb_info", "memb__pwd", "memb___id");
$hack_replace = "";
$char1=explode(" ",$char);

for($i=0;$i<count($char1);$i++)

{

 if(in_array($char1[$i],$hack_array))

 {

  $ban=1;

 } 

}

 if ($ban==1)

 {

  $add="ESTAS HACKEANDO SI SI"; 
 }

 else 

 {

  $add="NO ESTAS HACKEANDO"; 

 } 
 
$char_replaced = str_replace($hack_array, $hack_replace, $char);
$char_clean=htmlentities(trim($char_replaced));
return $char_clean.$add;

}

?>
