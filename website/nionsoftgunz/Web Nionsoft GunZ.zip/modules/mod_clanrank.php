<? SetTitle("GunZ Nionsoft - Ranking De Clan"); ?>

<script language="JavaScript" type="text/JavaScript">
<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
.Estilo2 {color: #FFFFFF}
-->
</style><body onLoad="MM_preloadImages('img/hallfame_select_on.png','img/playeranking_select_on.png')">
<table width="784" height="100%" border="0" align="center">
  <tr valign="top">
    <td width="160" align="center" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
          </table>
          </td>
      </tr>
      <tr>
        <td align="center"><table width="160" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="top" height="2"></td>
          </tr>
          <tr>
            <td align="center" valign="top" ><a href="index.php?gunz=playerank"><img src="img/ltit_ranking.gif" width="150" height="42" border="0"></a>
                <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" background="img/lbox01_t.png" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat;"><a href="index.php?gunz=playerank"><img src="img/playeranking_select.png" alt="EventShop" name="EventShop1" border="0" id="EventShop1"></a><br>
                        <a href="index.php?gunz=clanrank"><img name="Category" border="0" src="img/clanranking_select.png" alt="Category"></a><br>
                      <a href="index.php?gunz=hallofame"><img src="img/hallfame_select.png" alt="MyItems" name="MyItems1" border="0" id="MyItems1"></a></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat; background-position:bottom" height="6"></td>
                  </tr>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table>	</td>
    <td align="center" valign="top" bgcolor="#151515" class="Estilo1" width="620" height="100%"><table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left" class="Estilo1" height="30"><img src="img/guild03_sub02.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"><?
                                            $res = mssql_query_logged("SELECT TOP 4 * FROM Clan WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND Ranking != 0 ORDER BY POINT DESC, Ranking ASC");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "img/no_emblem.png" : $resa->EmblemUrl;

                                            if($Count == 4)
                                                break;
                                            else
                                                $Count++;
                                            }

                                            $firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "img/no_emblem.png" : $FirstClan[0][EmblemURL];
                                            $firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "img/no_emblem.png" : $FirstClan[1][EmblemURL];
                                            $firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "img/no_emblem.png" : $FirstClan[2][EmblemURL];
                                            $firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "img/no_emblem.png" : $FirstClan[3][EmblemURL];

                                            $firstclanname0 = ($FirstClan[0][Name] == "") ? "No Hay" : $FirstClan[0][Name];
                                            $firstclanname1 = ($FirstClan[1][Name] == "") ? "No Hay" : $FirstClan[1][Name];
                                            $firstclanname2 = ($FirstClan[2][Name] == "") ? "No Hay" : $FirstClan[2][Name];
                                            $firstclanname3 = ($FirstClan[3][Name] == "") ? "No Hay" : $FirstClan[3][Name];
                                            $toprank = '
					<table width="573" height="160" border="0" align="center" background="img/rank_bg_best.png" style="background-position:center; background-repeat:no-repeat;">
    <td width="133" height="10"></td>
  <tr>
    <td width="143" align="center"><img src="./'.$firstclanemb0.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb1.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb2.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb3.'" width="64" height="64" style="border: 1px solid #000000"></td>
  </tr>
  <tr height="12">
    <td class="estilo5"><center><b><font color="#bf1913"><blink> '.$firstclanname0.'</blink></font></b></center></td>
    <td class="estilo5"><center><b> '.$firstclanname1.'</b></center></td>
    <td class="estilo5"><center><b> '.$firstclanname2.'</b></center></td>
	<td class="estilo5"><center><b> '.$firstclanname3.'</b></center></td>
  </tr>
      <td width="133" height="5"></td>
</table> ';
                                echo $toprank; ?></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="15"></td>
      </tr>
      <tr>
        <td align="center"><table width="573" height="45" border="0" align="center" cellpadding="0" cellspacing="0" background="img/box_sch.gif" class="Estilo1" style="background-repeat:no-repeat;">
  <tr>
    <td align="center"><form method="GET" name="rnksearch" action="index.php">
                                    <input type="hidden" name="gunz" value="clanrank" />
                                    <select name="type" class="login">
                                      <option value="1">Nombre del Clan</option>
                                    </select>
                                    <input type="text" name="name" class="login"/>
                                    <input type="submit" value="Buscar" class="login"/>
                </form></td>
  </tr>
</table></td>
      </tr>
      <tr>
        <td height="30" align="left"><img src="img/ranking01_sub02.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td height="30" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="67" height="23" align="center" class="Estilo15"><b>Ranking</b></td>
            <td width="83" height="23" align="center" class="Estilo15"><strong>Emblema</strong></td>
            <td width="134" height="23" align="center" class="Estilo15"><b>Nombre del clan</b></td>
            <td width="70" height="23" align="center" class="Estilo15"><b>Lider</b></td>
            <td width="148" height="23" align="center" class="Estilo15"><b>Victorias/Derrotas %</b></td>
            <td width="68" height="23" align="center" class="Estilo15"><b>Puntos</b></td>
          </tr>
          <tr>
            <td colspan="6" valign="top">
              <table width="570" border="0" align="center" style="border-collapse: collapse">
                <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Ranking ASC";
                                                                }
                                                                else
                                                                {
                                                                    echo'
                                                               <tr>
                                            <td colspan="5" class="estilo5" align="center">
                                              - No Data -</td>
                                          </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if( $search == 0 )
                                                        {
                                                            switch( clean($_GET['page']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 20 AND Ranking <= 40";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 40 AND Ranking <= 60";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 60 AND Ranking <= 80";
                                                                break;
                                                                case "5":
                                                                    $ranks = "Ranking > 80 AND Ranking <= 100";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                            }
                                                            $res = mssql_query_logged("SELECT TOP 20 * FROM Clan(nolock) WHERE Ranking != 0 AND $ranks AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Point DESC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl;
                                                     ?>
                <tr>
                  <td colspan="6" align="center" class="Estilo1" height="6"></td>
                  </tr>
                <tr>
                  <td width="57" align="center" class="Estilo5">
                    <?=$clan->Ranking?>                  </td>
                  <td width="83" align="center" class="Estilo5"><img src="<?=($clan->EmblemUrl == "") ? "./img/no_emblem.png" : $clan->EmblemUrl;?>" width="34" height="30" style="border: 1px solid #000000"></td>
                  <td width="118" align="center" class="Estilo5">
                    <a href="index.php?gunz=clan&info=<?=$clan->Name?>"><font color="#CCCCCC"><b><?=$clan->Name?></b></font></a></td>
                  <td width="80" align="center" class="Estilo5"> <a href="index.php?gunz=player&info=<?=$clan->MasterCID?>">
                    <font color="#CCCCCC"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="132" align="center" class="Estilo5"><?=$clan->Wins . "/" . $clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                    </td>
                  <td width="74" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
                <tr>
                  <td height="35" colspan="6" align="center" class="estilo5">- No hay nada - </td>
                </tr>
                <?
                                                        }
                                                        ?>
            </table></td>
          </tr>
          <tr>
            <td colspan="6" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="35" align="center" class="login5"><?
                                    if( $search == 0 )
					                $name = clean($_GET['name']);
								    $type = clean($_GET['type']);
                                    { ?>
          <table width="500" border="0" cellpadding="0" cellspacing="0" align="center">
            <tr>
              <td height="30" align="center" class="estilo5" valign="baseline"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank" class="Estilo11">1-20</a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=2" class="Estilo11">20-40</a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=3" class="Estilo11">40-60</a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=4" class="Estilo11">60-80</a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=5" class="Estilo11">80-100</a></td>
                      </tr>
                    </table></td>
                  </tr>
                </table>                </td>
            </tr>
          </table>
          <?
                                    }
                                    ?></td>
      </tr>
    </table></td>
  </tr>
</table>
