<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
SetTitle("GunZ Nionsoft - Crear Firma Dinamica");
if ($_SESSION['AID'] == ""){
    alertbox("Entrar primero con tu cuenta.","index.php");
    die();
	}
	    $signing = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."'AND CharNum != '-1'");

    if( mssql_num_rows($signing) < 1 )
    {
    alertbox("Usted no tiene personajes.","index.php");
        die();
    }
?>
<script type="text/javascript">
    function UpdateSign()
    {
        var cid = document.signature.charlist.value;
        var sign = document.getElementById("sign");
        sign.innerHTML = '<img src="sign.php?cid='+ cid + '" />';
        document.signature.forumcode.value = '[URL="http://www.gunz.nionsoft.net/i/index.php?gunz=sign"][IMG]www.gunz.nionsoft.net/sign.php?cid=' + cid + '[/IMG][/URL]';
        document.signature.directlink.value = "http://www.gunz.nionsoft.net/sign.php?cid=" + cid + "";
    }

</script>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>

<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                  
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>CREAR FIRMA DINAMICA</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr bgcolor="#151515">
            <td align="center" class="Estilo1"><form name="signature"><table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td class="Estilo1" align="center"><p>&nbsp;</p>
                  <p>Seleccionar Personaje:
                    <select size="1" name="charlist" onchange="UpdateSign()" class="login">
                      <?
                                                while( $data = mssql_fetch_row($signing) )
                                                {
                                                ?>
                      <option value="<?=$data[0]?>">
                        <?=$data[1]?>
                        </option>
                      <br />
                      ';
                                                
                      <?
                                                }
                                                ?>
                    </select>
                  </p></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center"><span id="sign"></span></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center">Codigo de Foro:<br><input type="text" name="forumcode" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;" class="login"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center" height="10"></td>
              </tr>
              <tr>
                <td class="Estilo1" align="center">Link Directo:<br><input type="text" name="directlink" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;" class="login"></td>
              </tr> <script type="text/javascript">
                                            UpdateSign();
                                            </script>
            </table></form></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
