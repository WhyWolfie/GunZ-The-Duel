<? SetTitle("GunZ Nionsoft - Tienda De Items");
?>

<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body>
<table width="784" height="100" border="0" align="center">
  <tr valign="top">
    <td width="160" align="center" valign="top"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
          </table>
          </td>
      </tr>
      <tr>
        <td align="center" background="img/bg_content_wm.gif" bgcolor="" style="background-repeat:no-repeat; background-position:top;"><table width="160" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="top" height="2"></td>
          </tr>
          <tr>
            <td align="center" valign="top" ><a href="index.php?gunz=shop"><img src="img/ltit_itemshop.gif" width="150" height="42" border="0" /></a>
                <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" background="img/lbox01_t.png" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat;"><a href="index.php?gunz=itemshop&sub=listallitems&type=2"><img src="img/shop_select.jpg" alt="Category" name="Category" border="0" id="Category" /></a><br />
                        <a href="index.php?gunz=eshop&amp;sub=listallitems&amp;type=2"><img src="img/eventshop_select.jpg" alt="EventShop" name="EventShop1" border="0" id="EventShop1" /></a><br />
                        <a href="index.php?gunz=itemshop&amp;sub=listallitems&amp;type=2"><a href="index.php?gunz=buycolorname"><img src="img/name_color_select.jpg" alt="Category" name="Category" border="0" id="Category" /></a></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat; background-position:bottom" height="6"><span style="background-repeat:no-repeat;"><a href="index.php?gunz=myitems"><img src="img/myitems_select.jpg" alt="MyItems" name="MyItems1" border="0" id="MyItems1" /></a></span></td>
                  </tr>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table>	</td>
    <td align="center" valign="top" class="Estilo1" width="620" ><table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="left"><img src="img/gunz_itemshop_image2.png" width="575" height="200">
          <div align="right"></div></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="left" class="Estilo1" height="25"><img src="img/itemshop_00_sub01.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25">
		  <?
$res = mssql_query("SELECT TOP 4 * FROM CashShop WHERE Opened = 1 ORDER BY CSID DESC");
?>

<table width="570" height="100%" border="0" cellpadding="0" cellspacing="0" class="login4">
		<tr>
			<td width="449" height="20" colspan="2"></td>
		</tr>
		<tr>
		<? while($item = mssql_fetch_assoc($res)) 
		{
			if ($count == 2) 
			{
				$count = 1;
				echo "</tr>";
		?>
			<td width="208" align="center">
				<table width="250" border="0">
                  <tr>
                    <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
                    <td colspan="2" class="estilo8" align="left">
                       <b><?=$item['Name']?></b>                    </td>
                  </tr>
                  <tr>
                    <td width="64" class="estilo5" align="left">Tipo:</td>
                    <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Sexo:</td>
                    <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Hombre";
                                                    break;
                                                    case "1";
                                                    $sex = "Mujer";
                                                    break;
                                                    case "2";
                                                    $sex = "Ambos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Nivel:</td>
                    <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Precio:</td>
                    <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
                  </tr>
                  <tr>
                    <td colspan="2"><table width="100%" border="0" align="center">
                        <tr>
                          <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
                          <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
                          <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td colspan="2" height="20"></td>
                  </tr>
                </table></td>
            <? 
			}
			else
			{
            ?>
            <td width="208" height="100" align="center">
			      <table width="250" border="0">
                    <tr>
                      <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
                      <td colspan="2" class="estilo8" align="left">
                         <b><?=$item['Name']?></b>                      </td>
                    </tr>
                    <tr>
                      <td width="64" class="estilo5" align="left">Tipo:</td>
                      <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Sexo:</td>
                      <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Hombre";
                                                    break;
                                                    case "1";
                                                    $sex = "Mujer";
                                                    break;
                                                    case "2";
                                                    $sex = "Ambos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Nivel:</td>
                      <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Precio:</td>
                      <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
                    </tr>
                    <tr>
                      <td colspan="2"><table width="100%" border="0" align="center">
                          <tr>
                            <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
                            <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
                            <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td colspan="2" height="20"></td>
                    </tr>
                  </table></td>
			<?
				$count++;
				}
			}   
			?>
		</tr>
	</table></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="left" class="Estilo1" height="25"><img src="img/itemshop_tt_best.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"><?
$res = mssql_query("SELECT TOP 4 * FROM CashShop WHERE Opened = 1 ORDER BY CSID DESC");
?><table width="570" height="100%" border="0" cellpadding="0" cellspacing="0" class="login4">
		<tr>
			<td width="449" height="20" colspan="2"></td>
		</tr>
		<tr>
		<? while($item = mssql_fetch_assoc($res)) 
		{
			if ($count == 2) 
			{
				$count = 1;
				echo "</tr>";
		?>
			<td width="208" align="center">
				<table width="250" border="0">
                  <tr>
                    <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
                    <td colspan="2" class="estilo8" align="left">
                       <b><?=$item['Name']?></b>                    </td>
                  </tr>
                  <tr>
                    <td width="64" class="estilo5" align="left">Tipo:</td>
                    <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Sexo:</td>
                    <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Hombre";
                                                    break;
                                                    case "1";
                                                    $sex = "Mujer";
                                                    break;
                                                    case "2";
                                                    $sex = "Ambos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Nivel:</td>
                    <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
                  </tr>
                  <tr>
                    <td class="estilo5" align="left">Precio:</td>
                    <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
                  </tr>
                  <tr>
                    <td colspan="2"><table width="100%" border="0" align="center">
                        <tr>
                          <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
                          <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
                          <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
                        </tr>
                    </table></td>
                  </tr>
                  <tr>
                    <td colspan="2" height="20"></td>
                  </tr>
                </table></td>
            <? 
			}
			else
			{
            ?>
            <td width="208" height="100" align="center">
			      <table width="250" border="0">
                    <tr>
                      <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
                      <td colspan="2" class="estilo8" align="left">
                        <b><?=$item['Name']?></b>                      </td>
                    </tr>
                    <tr>
                      <td width="64" class="estilo5" align="left">Tipo:</td>
                      <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Sexo:</td>
                      <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Hombre";
                                                    break;
                                                    case "1";
                                                    $sex = "Mujer";
                                                    break;
                                                    case "2";
                                                    $sex = "Ambos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Nivel:</td>
                      <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo5" align="left">Precio:</td>
                      <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
                    </tr>
                    <tr>
                      <td colspan="2"><table width="100%" border="0" align="center">
                          <tr>
                            <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
                            <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
                            <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
                          </tr>
                      </table></td>
                    </tr>
                    <tr>
                      <td colspan="2" height="20"></td>
                    </tr>
                  </table></td>
			<?
				$count++;
				}
			}   
			?>
		</tr>
	</table></td>
      </tr>
      <tr>
        <td align="right" class="Estilo5" height="25"><div align="center"></div></td>
      </tr>
    </table></td>
  </tr>
</table>
