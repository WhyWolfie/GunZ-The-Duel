<? SetTitle("Gunz Nionsoft - Opciones Para Donar"); ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
.Estilo2 {font-weight: bold; color: #C6C126; }
-->
</style>
<table width="601" height="552" border="0" align="center">
  <tr>
    <td width="160" height="548" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="546" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="546" align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>OPCIONES PARA DONAR</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><p><a href="shopvenezuela/combos.html"><img src="img/donator_3.jpg" width="390" height="90" border="0" /></a></p>
              <p>&nbsp;</p>
              <p><a href="#"><img src="img/donator_1.png" width="390" height="90" border="0" /></a></p>
              <p>&nbsp;</p>
              <p><a href="#"><img src="img/donator_2.JPG" width="390" height="90" border="0" /></a></p>
              </td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
