<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/sql_inject.php";
include "secure/inject.php";
include "secure/antisql.php";
 SetTitle("GunZ Nionsoft - Registro");
 if(!$_SESSION['AID'] == "")
{
alertbox("Usted ya tiene cuenta, si desea crear otra salga de esta cuenta.","index.php");
    die();
} ?>
<?
$alertbox = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user           = clean($_POST['user']);
    $pass1          = clean($_POST['pass1']);
    $pass2          = clean($_POST['pass2']);
    $email          = clean($_POST['email']);
    $country        = clean($_POST['country']);
    $name           = clean($_POST['name']);
    $age            = clean($_POST['age']);
    $sex            = clean($_POST['sex']);
    $sq             = clean($_POST['sq']);
    $sa             = clean($_POST['sa']);
	$address        = clean($_POST['address']);
    $zipcode        = clean($_POST['zipcode']);


        $res = mssql_query("SELECT * FROM Account WHERE email = '".clean($email)."'");
        if (mssql_num_rows($res) >= 1){
alertbox("E-Mail $email en uso.","index.php?gunz=register");
            $er = 1;
        }

        $res = mssql_query("SELECT * FROM Login WHERE UserID = '".clean($user)."'");
        if (mssql_num_rows($res) >= 1){
alertbox("Cuenta ID $userid en uso.","index.php?gunz=register");
            $er = 1;
        }
        if($pass1 == $pass2){
        }else{
alertbox("Las contrase�as no coinciden.","index.php?gunz=register");
            $er = 1;
        }
        if($user == ""){
alertbox("Escriba su nombre de usuario (Cuenta ID).","index.php?gunz=register");
            $er = 1;
        }

        if($email == ""){
alertbox("Escriba su direcci�n de E-mail.","index.php?gunz=register");
            $er = 1;
        }
		        if($name == ""){
alertbox("Escriba su nombre y apellidos.","index.php?gunz=register");
            $er = 1;
        }
				        if($address == ""){
alertbox("Escrib� su direcci�n.","index.php?gunz=register");
            $er = 1;
        }
				        if($zipcode == ""){
alertbox("Escriba su c�digo postal.","index.php?gunz=register");
            $er = 1;
        }

        if(strlen($pass1) < 6){
alertbox("Su contrase�a es demasiado corta (6 digitos es lo minimo).","index.php?gunz=register");
         $er =1;
        }

        if($pass1 == "" Or $pass2 == ""){
alertbox("Escriba la contrase�a.","index.php?gunz=register");
            $er = 1;
        }

        if($sq == ""){
alertbox("Escriba su pregunta secreta.","index.php?gunz=register");
            $er =1;
        }

        if($sa == ""){
alertbox("Escriba su respuesta secreta.","index.php?gunz=register");
            $er = 1;
        }
		require_once('other/recaptcha.php');
        $privatekey = "6LepMAgAAAAAAGQa4_jAZoG-HnX3Jgz2Ut0Ho5YO";
        $resp = recaptcha_check_answer ($privatekey,
                                $_SERVER["REMOTE_ADDR"],
                                $_POST["recaptcha_challenge_field"],
                                $_POST["recaptcha_response_field"]);

        if (!$resp->is_valid) {
alertbox("El c�digo de verificaci�n es incorrecto.","index.php?gunz=register");
            $er =1;
        }

        if($er == 0){
            $registered = 1;
           mssql_query("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, SQ, SA, Address, ZipCode)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$sq', '$sa', '$address', '$zipcode')");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query("INSERT INTO Login ([UserID],[AID],[Password])VALUES('$user','$aid','$pass1')");
        }else{
            $alert = alertbox($text, $url);
die();
        }
}
if ($registered == 0){
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>CREAR CUENTA EN GUNZ NIONSOFT </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1">
			<form name="reg" method="POST" action="index.php?gunz=register">
						<table width="400" border="0" align="center">
                            <tr>
                              <td colspan="2" align="center" class="Estilo1"><? echo @$alertbox ?></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" bgcolor="#151515" class="Estilo1"><font color="#FF0000"> No le des tu contrase�a a nadien. Ningun Staff te la pedira.</font></td>
                            </tr>
                            <tr>
                              <td align="center" class="Estilo1" height="10"></td>
                              <td width="197" align="center" class="Estilo1"></td>
                            </tr>
                            <tr>
                              <td width="193" align="left" class="Estilo1">Cuenta ID:</td>
                              <td class="Estilo1" align="right"><input name="user" type="text" class="Login" size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">E-mail:</td>
                              <td class="Estilo1" align="right"><input name="email" type="text" class="Login" id="email2" size="20" maxlength="30"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Contrase&ntilde;a:</td>
                              <td class="Estilo1" align="right"><input name="pass1" type="password" class="Login" id="pass1" size="20" maxlength="20" ></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Repetir Contrase&ntilde;a:</td>
                              <td class="Estilo1" align="right"><input name="pass2" type="password" class="Login" id="pass2" size="20" maxlength="20" ></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Nombre:</td>
                              <td class="Estilo1" align="right"><input name="name" type="text" class="Login"  size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Pa�s: </td>
                              <td class="Estilo1" align="right"><select id="dropDownCountrySelector" name="country" onchange="refreshCountry(this, false)" class="Login">
                                <option value="Selecciona tu pais" selected="selected">Selecciona tu pais</option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="Andoria">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Anguilla">Anguilla</option>
                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                <option value="Argentina">Argentina </option>
                                <option value="Amenia">Armenia</option>
                                <option value="Aruba">Aruba</option>
                                <option value="Australia">Australia </option>
                                <option value="Austria">Austria</option>
                                <option value="Azerbaijan Republic">Azerbaijan Republic</option>
                                <option value="Bahamas">Bahamas</option>
                                <option value="Bahrain">Bahrain</option>
                                <option value="Barbados">Barbados</option>
                                <option value="Belgium">Belgium</option>
                                <option value="Belize">Belize</option>
                                <option value="Benin">Benin</option>
                                <option value="Bermuda">Bermuda</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Bolivia">Bolivia</option>
                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                <option value="Botswana">Botswana</option>
                                <option value="Brazil">Brazil</option>
                                <option value="British Virgin Islands">British Virgin Islands</option>
                                <option value="Brunei">Brunei</option>
                                <option value="Bulgaria">Bulgaria</option>
                                <option value="Burkina Faso">Burkina Faso </option>
                                <option value="Burundi">Burundi</option>
                                <option value="Cambodia">Cambodia</option>
                                <option value="Canada">Canada</option>
                                <option value="Cape Verde">Cape Verde</option>
                                <option value="Cayman islands">Cayman Islands</option>
                                <option value="Chad">Chad</option>
                                <option value="Chile">Chile</option>
                                <option value="China">China</option>
                                <option value="Colombia">Colombia</option>
                                <option value="Comoros">Comoros</option>
                                <option value="Cook Islands">Cook Islands</option>
                                <option value="Costa Rica">Costa Rica</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Cyprus">Cyprus</option>
                                <option value="Czech Republic">Czech Republic</option>
                                <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Djibouti">Djibouti</option>
                                <option value="Dominica">Dominica</option>
                                <option value="Dominican Republic">Dominican Republic</option>
                                <option value="Ecuador">Ecuador</option>
                                <option value="El Salvador">El Salvador</option>
                                <option value="Eritrea">Eritrea</option>
                                <option value="Estonia">Estonia</option>
                                <option value="Estados Unidos">Estados Unidos</option>
                                <option value="Ethiopia">Ethiopia</option>
                                <option value="Falkland">Falkland Islands </option>
                                <option value="Faroe Islands">Faroe Islands</option>
                                <option value="Federated States of Micronesia">Federated States of Micronesia</option>
                                <option value="Fiji">Fiji</option>
                                <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="French Guiana">French Guiana</option>
                                <option value="French Polynesia">French Polynesia</option>
                                <option value="Gabon Republic">Gabon Republic</option>
                                <option value="Gambia">Gambia</option>
                                <option value="Germany">Germany</option>
                                <option value="Gibraltar">Gibraltar </option>
                                <option value="Greece">Greece</option>
                                <option value="Greenland">Greenland </option>
                                <option value="Grenada">Grenada</option>
                                <option value="Guadeloupe">Guadeloupe</option>
                                <option value="Guatemala">Guatemala </option>
                                <option value="Guinea">Guinea</option>
                                <option value="Guinea Bissau">Guinea Bissau </option>
                                <option value="Guyana">Guyana</option>
                                <option value="Honduras">Honduras</option>
                                <option value="Hong Kong">Hong Kong </option>
                                <option value="Hungary">Hungary</option>
                                <option value="Iceland">Iceland</option>
                                <option value="India">India</option>
                                <option value="Indonesia">Indonesia </option>
                                <option value="Ireland">Ireland</option>
                                <option value="Israel">Israel</option>
                                <option value="Italy">Italy</option>
                                <option value="Jamaica">Jamaica</option>
                                <option value="Japan">Japan</option>
                                <option value="Jordan">Jordan</option>
                                <option value="Kazakhstan">Kazakhstan </option>
                                <option value="Kenya">Kenya</option>
                                <option value="Kiribati">Kiribati</option>
                                <option value="Korea">Korea</option>
                                <option value="Kuwait">Kuwait</option>
                                <option value="Kyrgyztan">Kyrgyzstan</option>
                                <option value="Laos">Laos</option>
                                <option value="Latvia">Latvia</option>
                                <option value="Lesotho">Lesotho</option>
                                <option value="Liechtenstein">Liechtenstein</option>
                                <option value="Lithuania">Lithuania</option>
                                <option value="Luxembourg">Luxembourg</option>
                                <option value="Madagascar">Madagascar</option>
                                <option value="Malawi">Malawi</option>
                                <option value="Malaysia">Malaysia</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Mali">Mali</option>
                                <option value="Malta">Malta</option>
                                <option value="Marshall Islands">Marshall Islands</option>
                                <option value="Martinique">Martinique</option>
                                <option value="Mauritania">Mauritania</option>
                                <option value="Mauritius">Mauritius</option>
                                <option value="Mayotte">Mayotte</option>
                                <option value="Mexico">Mexico</option>
                                <option value="Mongolia">Mongolia</option>
                                <option value="Montserrat">Montserrat</option>
                                <option value="Moroco">Morocco</option>
                                <option value="Mozambique">Mozambique</option>
                                <option value="Namibia">Namibia</option>
                                <option value="Nauru">Nauru</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Netherlands">Netherlands </option>
                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                <option value="New Celedonia">New Caledonia</option>
                                <option value="New Zealand">New Zealand</option>
                                <option value="Nicaragua">Nicaragua</option>
                                <option value="Niger">Niger</option>
                                <option value="Niue">Niue</option>
                                <option value="Norfolk Island">Norfolk Island</option>
                                <option value="Norway">Norway</option>
                                <option value="Oman">Oman</option>
                                <option value="Palau">Palau</option>
                                <option value="Panama">Panama</option>
                                <option value="Papua New Guinea">Papua New Guinea</option>
                                <option value="Peru">Peru</option>
                                <option value="Philippines">Philippines</option>
                                <option value="Pitcairn Islands">Pitcairn Islands</option>
                                <option value="Poland">Poland</option>
                                <option value="Portugal">Portugal</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Republic of the Congo">Republic of the Congo</option>
                                <option value="Reunion">Reunion</option>
                                <option value="Romania">Romania</option>
                                <option value="Russia">Russia</option>
                                <option value="Rwanda">Rwanda</option>
                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                <option value="WS">Samoa</option>
                                <option value="San Marino">San Marino</option>
                                <option value="Sao Tome and Prncipe">Sao Tome and Prncipe</option>
                                <option value="Saudi Arabia">Saudi Arabia</option>
                                <option value="Senegal">Senegal</option>
                                <option value="Seychelles">Seychelles</option>
                                <option value="Sierra Leone">Sierra Leone</option>
                                <option value="Singapore">Singapore</option>
                                <option value="Slovakia">Slovakia</option>
                                <option value="Slovenia">Slovenia</option>
                                <option value="Solomon Islands">Solomon Islands</option>
                                <option value="SO">Somalia</option>
                                <option value="South Africa">South Africa</option>
                                <option value="South Korea">South Korea</option>
                                <option value="Spain">Spain</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="St. Helena">St. Helena</option>
                                <option value="St. Kitts and Nevis">St. Kitts and Nevis</option>
                                <option value="St. Lucia">St. Lucia</option>
                                <option value="St. Pierre and Miquelon">St. Pierre and Miquelon</option>
                                <option value="Suriname">Suriname</option>
                                <option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                                <option value="Swaziland">Swaziland</option>
                                <option value="SE">Sweden</option>
                                <option value="Switzerland">Switzerland</option>
                                <option value="Taiwan">Taiwan</option>
                                <option value="Tajikistan">Tajikistan</option>
                                <option value="Tanzania">Tanzania</option>
                                <option value="Thailand">Thailand</option>
                                <option value="Togo">Togo</option>
                                <option value="Tonga">Tonga</option>
                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                <option value="Tunisia">Tunisia</option>
                                <option value="Turkey">Turkey</option>
                                <option value="Turkmenistan">Turkmenistan</option>
                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                <option value="Tuvalu">Tuvalu</option>
                                <option value="Uganda">Uganda</option>
                                <option value="Ukraine">Ukraine</option>
                                <option value="Venezuela">Venezuela</option>
                                <option value="United Arab Emirates">United Arab Emirates</option>
                                <option value="United Kingdom">United Kingdom </option>
                                <option value="Uruguay">Uruguay</option>
                                <option value="Vanuatu">Vanuatu</option>
                                <option value="Vatican City State">Vatican City State</option>
                                <option value="Vietnam">Vietnam</option>
                                <option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                                <option value="Yemen">Yemen</option>
                                <option value="Zambia">Zambia</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Codigo Postal:</td>
                              <td class="Estilo1" align="right"><input name="zipcode" type="text" class="Login" id="zipcode2"  size="20" maxlength="5"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Direcci&oacute;n:</td>
                              <td class="Estilo1" align="right"><input name="address" type="text" class="Login" id="address2"  size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Edad:</td>
                              <td class="Estilo1" align="right"><select size="1" name="age" class="Login">
                                  <option value='1'>1</option>
                                  <option value='2'>2</option>
                                  <option value='3'>3</option>
                                  <option value='4'>4</option>
                                  <option value='5'>5</option>
                                  <option value='6'>6</option>
                                  <option value='7'>7</option>
                                  <option value='8'>8</option>
                                  <option value='9'>9</option>
                                  <option value='10'>10</option>
                                  <option value='11'>11</option>
                                  <option value='12'>12</option>
                                  <option value='13'>13</option>
                                  <option value='14'>14</option>
                                  <option value='15'>15</option>
                                  <option value='16'>16</option>
                                  <option value='17'>17</option>
                                  <option value='18'>18</option>
                                  <option value='19'>19</option>
                                  <option value='20'>20</option>
                                  <option value='21'>21</option>
                                  <option value='22'>22</option>
                                  <option value='23'>23</option>
                                  <option value='24'>24</option>
                                  <option value='25'>25</option>
                                  <option value='26'>26</option>
                                  <option value='27'>27</option>
                                  <option value='28'>28</option>
                                  <option value='29'>29</option>
                                  <option value='30'>30</option>
                                  <option value='31'>31</option>
                                  <option value='32'>32</option>
                                  <option value='33'>33</option>
                                  <option value='34'>34</option>
                                  <option value='35'>35</option>
                                  <option value='36'>36</option>
                                  <option value='37'>37</option>
                                  <option value='38'>38</option>
                                  <option value='39'>39</option>
                                  <option value='40'>40</option>
                                  <option value='41'>41</option>
                                  <option value='42'>42</option>
                                  <option value='43'>43</option>
                                  <option value='44'>44</option>
                                  <option value='45'>45</option>
                                  <option value='46'>46</option>
                                  <option value='47'>47</option>
                                  <option value='48'>48</option>
                                  <option value='49'>49</option>
                                  <option value='50'>50</option>
                                  <option value='51'>51</option>
                                  <option value='52'>52</option>
                                  <option value='53'>53</option>
                                  <option value='54'>54</option>
                                  <option value='55'>55</option>
                                  <option value='56'>56</option>
                                  <option value='57'>57</option>
                                  <option value='58'>58</option>
                                  <option value='59'>59</option>
                                  <option value='60'>60</option>
                                  <option value='61'>61</option>
                                  <option value='62'>62</option>
                                  <option value='63'>63</option>
                                  <option value='64'>64</option>
                                  <option value='65'>65</option>
                                  <option value='66'>66</option>
                                  <option value='67'>67</option>
                                  <option value='68'>68</option>
                                  <option value='69'>69</option>
                                  <option value='70'>70</option>
                                  <option value='71'>71</option>
                                  <option value='72'>72</option>
                                  <option value='73'>73</option>
                                  <option value='74'>74</option>
                                  <option value='75'>75</option>
                                  <option value='76'>76</option>
                                  <option value='77'>77</option>
                                  <option value='78'>78</option>
                                  <option value='79'>79</option>
                                  <option value='80'>80</option>
                                  <option value='81'>81</option>
                                  <option value='82'>82</option>
                                  <option value='83'>83</option>
                                  <option value='84'>84</option>
                                  <option value='85'>85</option>
                                  <option value='86'>86</option>
                                  <option value='87'>87</option>
                                  <option value='88'>88</option>
                                  <option value='89'>89</option>
                                  <option value='90'>90</option>
                                  <option value='91'>91</option>
                                  <option value='92'>92</option>
                                  <option value='93'>93</option>
                                  <option value='94'>94</option>
                                  <option value='95'>95</option>
                                  <option value='96'>96</option>
                                  <option value='97'>97</option>
                                  <option value='98'>98</option>
                                  <option value='99'>99</option>
                                  <option value='100'>100</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Sexo:</td>
                              <td class="Estilo1" align="right"><select size="1" name="sex" class="Login">
                              <option value="Hombre">Hombre</option>
                              <option value="Mujer">Mujer</option>
                              </select></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="left" class="Estilo1" height="10"></td>
                            </tr>
                            <tr bgcolor="#000000">
                              <td colspan="2" align="center" bgcolor="#151515" class="Estilo1"><font color="#FF0000">Pregunta secreta se usa para recuperar tu contrase&ntilde;a.</font></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="left" class="Estilo1" height="10"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1" height="18"></td>
                              <td class="Estilo1" align="right"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Pregunta secreta: </td>
                              <td class="Estilo1" align="right"><input name="sq" type="text" class="Login" id="sq" size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Respuesta secreta: </td>
                              <td class="Estilo1" align="right"><input name="sa" type="text" class="Login" id="sa" size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="left" class="Estilo1" height="10"></td>
                            </tr>
                            <tr>
                              <td align="left" class="Estilo1">Verificar codigo: </td>
                              <td class="Estilo1" align="right"><? 
											require_once('other/recaptcha.php');
											$publickey = "6LepMAgAAAAAAG8JszlL7PQKy_UsrS6rndEisQjL";
											echo recaptcha_get_html($publickey);
											?></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="Estilo1" height="10"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Crear Cuenta" name="submit" class="Login"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="Estilo1"></td>
                            </tr>
                    </table>
						<?
}else{
alertbox("Cuenta $user a sido creada, Disfruta jugando GunZ Nionsoft :D","index.php");
    die();
}
?>
</form></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
