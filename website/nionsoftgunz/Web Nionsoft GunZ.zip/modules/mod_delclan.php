<? SetTitle("GunZ Nionsoft - Borrar Clan");
if ($_SESSION['AID'] == ""){
    alertbox("Entra primero con tu cuenta.","index.php");
    die();
	} 
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>BORRAR CLAN </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25">
				  <table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center"><iframe class="errorbox" src="delclan/index.php"></iframe></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
