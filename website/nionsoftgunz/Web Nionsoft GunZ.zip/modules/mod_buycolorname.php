<?

if( $_SESSION['AID'] == "" )
{
    alertbox("Introduce tu cuenta y veras el Item Shop completo.","index.php?gunz=shop");
}
$query00 = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION['AID']}' AND CharNum != '-1' AND Name != '' ");
  // Have characters?
  if (mssql_num_rows($query00) < 1) {
    alertbox("Usted no tiene personajes.","index.php?gunz=shop");
        die();
    }
SetTitle("GunZ Nionsoft - Comprar Nombre A Color");

 if (isset($_POST['submit'])) {
      $aid = clean($_SESSION['AID']);
	  $mygrade = clean($_SESSION['UGradeID']);
      $grade = clean($_POST['color']);
      $price = intval(60);
	  $cssid = intval(1);
      
	     
      // Color is valid? 
	  switch($grade){
		case 10;
		$grade = 10;
		break;  
		case 11;
		$grade = 11;
		break; 		  
		case 12;
		$grade = 12;
		break; 	
		default:
    alertbox("Selecciona un color.","index.php?gunz=buycolorname");
        die();
    }
      if (!is_numeric($grade)) {
    alertbox("Nombre del color no v�lido.","index.php?gunz=buycolorname");
        die();
    }
       // Ranks invalids bzz
      elseif($mygrade == 104 || $mygrade == 253 || $mygrade == 255 || $mygrade == 252 )  {
    alertbox("No se puede comprar este item, compruebe su rango.","index.php?gunz=shop");
        die();
    }
	  // The selected grade is the same  actual grade of you account?	  
	  elseif($grade == $mygrade) {
    alertbox("Tu personaje ya tiene este color por favor escoja otro color.","index.php?gunz=buycolorname");
        die();
    }
      // Color empty? useless
      elseif (empty($grade)) {
    alertbox("No seleccione un nombre de color.","index.php?gunz=buycolorname");
        die();
          } else {
          // Suficients coins ?
          $query = mssql_query("SELECT Coins FROM Account(nolock) WHERE AID = '$aid'");
          $info = mssql_fetch_assoc($query);
          $updatecoins = $info['Coins'] - $price;
          
          if ($updatecoins < 0) {
    alertbox("Usted no tiene suficientes Coins parar comprar el item.","index.php?gunz=shop");
        die();
          } else {
              // Update 
              $addcolor = mssql_query_logged("UPDATE Account SET ugradeid = '$grade', Coins = '$updatecoins' WHERE AID = '$aid'");
              // Log
              $logf = fopen("logs/logbuycolor.txt", "a+");
              fprintf($logf, "",$_SERVER['REMOTE_ADDR'],$aid, $grade);
              fclose($logf);
	         
              if ($addcolor) {
				  // Update session name UGradeID
				  $_SESSION[UGradeID] = $grade;
    alertbox("Nombre A Color comprado con exito.","index.php?gunz=shop");
        die();
              } else {
    alertbox("Hubo problemas con el servidor, intente de nuevo.","index.php?gunz=buycolorname");
        die();
              }
          }
      }
  } else {
      // Get some info
     
      $query01 = mssql_query("SELECT Coins, UGradeID FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
      $infoacc = mssql_fetch_object($query01);
	  
	  if ($infoacc->UGradeID == 2) {
    alertbox("No se puede comprar este item, Porque usted tiene Jjang, dile a algun Administrador o Moderador que te quite el Jjang.","index.php?gunz=shop");
        die();
	  }

  }
?>
<style type="text/css">
OPTION.red {
    color:#F00;
    font-weight:bold;
}
OPTION.white {
    color:#000000;
    font-weight:bold;
}
OPTION.blue {
    color:#00F;
    font-weight: bold;
}
.Estilo2 {color: #FFFFFF}
.Estilo5 {
	color: #bf1913;
	font-weight: bold;
	font-size: 12px;
}
</style>

<table border="0" style="border-collapse: collapse" width="778">
					<tr>
                        <td width="160" valign="top">
                            <table border="0" style="border-collapse: collapse" width="160">
                            <tr>
                                <td width="160" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;
                                
                                </td>
                            </tr>
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
                                <div align="center">
                                  <table width="160" height="100" border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tr>
                                      <td align="center" valign="top" height="2"></td>
                                    </tr>
                                    <tr>
                                      <td align="center" valign="top" ><a href="index.php?gunz=shop"><img src="img/ltit_itemshop.gif" width="150" height="42" border="0" /></a>
                                          <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td align="center" background="img/lbox01_t.png" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                                            </tr>
                                            <tr>
                                              <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat;"><a href="index.php?gunz=itemshop&amp;sub=listallitems&amp;type=2"><img src="img/shop_select.jpg" alt="Category" name="Category" border="0" id="Category" /></a><br />
                                                <a href="index.php?gunz=eshop&amp;sub=listallitems&amp;type=2"><img src="img/eventshop_select.jpg" alt="EventShop" name="EventShop1" border="0" id="EventShop1" /></a><br />                                                
                                              <a href="index.php?gunz=itemshop&amp;sub=listallitems&amp;type=2"><a href="index.php?gunz=buycolorname"><img src="img/name_color_select.jpg" alt="Category" name="Category" border="0" id="Category" /></a></td>
                                            </tr>
                                            <tr>
                                              <td align="center" background="img/lbox01_b.png" style="background-repeat:no-repeat; background-position:bottom" height="6"><span style="background-repeat:no-repeat;"><a href="index.php?gunz=myitems"><img src="img/myitems_select.jpg" alt="MyItems" name="MyItems1" border="0" id="MyItems1" /></a></span></td>
                                            </tr>
                                        </table></td>
                                    </tr>
                                  </table>
                                </div>

        						</td>
                        </tr>
                        <tr>
    						<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
                            <div align="center">
                            &nbsp;
                            <p></div></td>
                        </tr>
                            </table>
                        </td>
						<td width="599" valign="top">
						<div align="center">
                        <form method="POST" action="index.php?gunz=buycolorname" name="buycolorname">
							<table width="603" border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y">
								<tr>
									<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%">
											<tr bordercolor="#252525" bgcolor="#151515">
												<td>
												<div align="center">
													
                                                    <table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="458" colspan="2">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104" valign="top">
															<div align="center">
															<img border="0" src="images/shop/shop/Especial/color.png" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
															<td width="458" colspan="2">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="458" height="100%">
																	<tr>
																		<td width="19">
																		<div align="left">&nbsp;</td>
																		<td width="435" colspan="2"><p class="Estilo5">Nombre  A Color</p>
																	    <p class="Estilo5">&nbsp;</p></td>
																	</tr>
																	<tr>
																		<td width="19"><span class="Estilo2"></span></td>
																		<td width="61" align="left"><span class="Estilo1">
																		Tipo:																		</span></td>
																		<td width="372" align="left"><span class="Estilo1">Especial</span></td>
																	</tr>
																	<tr>
																		<td width="19"><span class="Estilo2"></span></td>
																		<td width="61" align="left"><span class="Estilo1">
																		Duracion:</span></td>
																		<td width="372" align="left"><span class="Estilo1">
																		Permanente</span></td>
																	</tr>
																	<tr>																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left"><span class="Estilo1">Info:</span></td>
																		<td width="372" align="left" class="Estilo1">Este item le da nombre de color a tus personajes del GunZ.</td>
																	</tr>
																																		<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">&nbsp;</td>
																		<td width="372" align="left" class="Estilo1">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">
																		<div align="center"><span class="Estilo1">Colores disponibles:</span> 
																		  <select name="color" class="cero">
                                <option selected value="">Seleccionar Color</option>
                                <option class="red" value="10">RED</option>
                                <option class="white" value="11">WHITE</option>
                                <option class="blue" value="12">BLUE</option>
                            </select>
																		</div>																		</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
															<td width="435" align="left" rowspan="4">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="435" height="66">
																	<tr>
																		<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="419" height="100%">
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><span class="Estilo1">Precio:</span></td>
																					<td width="62" align="left"><span class="Estilo1">60 Coins</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><span class="Estilo1">Coins que dispone:</span></td>
																					<td width="62" align="left"><span class="Estilo1">
																				    <?=$infoacc->Coins?>
																					</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><span class="Estilo1">Coins que le Quedaran:</span></td>
																					<td width="62" align="left"><span class="Estilo1">
																				    <?=$infoacc->Coins-60?>
																					</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="413" colspan="4" height="1"></td>
																				</tr>
																		  </table>
																		</div>																		</td>
																		<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="569" colspan="4"><div align="center">
															  <p>
															    <input type="image" id="img1764" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'img/btn_itmshp_buy01.png')" onmouseout="FP_swapImgRestore()" src="img/btn_itmshp_buy01.png" alt="buy color name" width="79" height="23" value="submit" name="submit"/>
															  </p>
															  <p>&nbsp; </p>
															</div></td>
														</tr>
													</table>
											  </div>											  </td>
										  </tr>
									  </table>
									</div>									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3"><div align="center"></div></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">
									<p align="center"><a href="index.php?do=shopitem"></a></p></td>
								</tr>
								<tr>
								</tr>
						  </table>
                          </form>
						</div>
                     
						</td>
					</tr>
				</table>
