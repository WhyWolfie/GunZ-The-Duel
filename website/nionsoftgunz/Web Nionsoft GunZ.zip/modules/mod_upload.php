<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
SetTitle("GunZ Nionsoft - Subir Emblema Al Clan");
if ($_SESSION['AID'] == ""){
    alertbox("Entra primero con tu cuenta.","index.php");
    die();
	}
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>

<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>SUBIR EMBLEMA AL CLAN</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr bgcolor="#151515">
            <td align="center" class="Estilo1"><? 
			include"secure/sec.php";
			include"secure/config.php";
$conn = @mssql_connect($DBHost, $DBUser, $DBPass); 
@mssql_select_db($DB); 



if (isset($_GET['step'])) {
	$argv = explode('-',$_GET['step']);
	settype($argv,'array'); 
	$_GET['step'] = @$argv[0];
	$_GET['url'] = @$argv[1];
	$_GET['do'] = @$argv[2];
	$_GET['mess'] = @$argv[3];
}
$step = !isset($_GET['step']) ? home : $_GET['step'] ;
		if ($step == '1') { echo'
		
<FORM METHOD=POST ACTION="index.php?gunz=upload&step=2">
<table width="350" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
    <td colspan="2" align="center" class="Estilo1">Entra con tu cuenta para subir tu emblema.</td>
    </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left">Cuenta ID:</td>
    <td class="Estilo1" align="right"><input name="user" type="textfield" class="login"/></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left">Contrase�a:</td>
    <td class="Estilo1" align="right"><input name="pass" type="password" class="login"/></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
    <tr>
    <td colspan="2" align="center" class="Estilo1"><input name="submit" type="submit" value="Entrar" class="login"/></td>
    </tr>
</table></form> '; 
 } if ($step == '2') { 

$user1 = clean($_POST['user']);
$pass1 = clean($_POST['pass']);
    if (valida(Array($user1,$pass1)) == TRUE)
{
 
 $query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");
			while($r = mssql_fetch_array($query)){
if (mssql_num_rows($query) == 1){
						$query2 = mssql_query("

SELECT     Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID
FROM         ClanMember INNER JOIN
                      Clan ON ClanMember.CLID = Clan.CLID INNER JOIN
                      Login INNER JOIN
                      Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
					  if (mssql_num_rows($query2) >= '1'){
					  echo '<form enctype="multipart/form-data" action="index.php?gunz=upload&step=done" method="POST">
  <p class="estilo1">Selecciona la imagen para tu emblema:<br>
    <input name="uploaded" type="file" class="login"/>
  </p>
  <p><br />
    <input type="submit" value="Subir Emblema" class="login"/>
    </p><select name="clan" class="login">'
;
							for($i='';$i < @mssql_num_rows($query2);++$i){
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
							echo '<option value="'.$row[4].'">';echo $row[4];echo'</option>' ;
							
							
							}echo'</select></form>';
							}}else { echo " ERROR GEEN CLAN ";} }
							}
			;
		}  
	
	;
	
	if ($step == 'done') { 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = $_POST['clan'];
$target = "./clan/emblem/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$ok=1;
if (!($_FILES['uploaded']['size']  > '104000'))
{
//echo "Tu imagen es muy grande.<br>";
$ok=1;
if(($_FILES['uploaded']['type'] == "image/jpeg"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
if(($_FILES['uploaded']['type'] == "image/GIF"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
if(($_FILES['uploaded']['type'] == "image/PNG"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
}
else { $ok=0;}

//


if ($ok==0)
{
echo "No se pudo subir el emblema<br />";
echo "Por favor revisa el formato e intenta de nuevo.";
}
else
{
if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
{
echo "El Archivo ".basename( $_FILES['uploadedfile']['name']). "Subido con exito<br />";
echo "Se puede ver ahora!";
mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
mssql_query ("UPDATE Clan SET EmblemUrl = '".$target."' WHERE Name = '$CLID'");
}
else
{
echo "La cuenta no existe o no tiene permisos para subir un emblema.";
}}
};
?></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
