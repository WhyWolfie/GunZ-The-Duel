<?
SetTitle("GunZ Nionsoft - Estado Del Servidor");
?>
<table width="724" border="0" align="center" cellspacing="0">
  <tr>
    <td width="722"><table width="722" border="0" align="center" cellspacing="0">
      <tr>
        <td width="182" height="420" valign="top"><? include"other/leftblock.php" ?></td>
        <td width="353" valign="top"><div align="center">
            <table width="0" height="24" border="0" align="center">
              <tr valign="top">
                <td width="28" height="20"><div align="center"><? include"other/server.php" ?>
                  </div></td>
              </tr>
            </table>
        </div></td>
        <td width="181" valign="top"><? include"other/rightblock.php" ?></td>
      </tr>
    </table></td>
  </tr>
</table>
