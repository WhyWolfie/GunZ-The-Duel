<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
SetTitle("GunZ Nionsoft - Recuperar Contrase�a");
if ($_SESSION['AID'] <> ""){
    alertbox("Salga primero de la cuenta.","index.php");
    die();
	}
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="407" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="">
                  <td height="10" colspan="2" bgcolor=""></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>RECUPERAR CONTRASE�A </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#151515" class="login4">
  <tr>
    <td width="360" height="5" bgcolor="#151515"></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#151515" class="estilo1"><?
if($_POST['submit'] == ""){
?>
						<form method="POST" action="index.php?gunz=rstpass" name="newpass">
						<table width="360" border="0" cellpadding="1" cellspacing="0">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1">Ponga su (Cuenta ID) y haga click en Paso 2.</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Cuenta ID:</td>
                            <td class="Estilo1" align="right"><input name="userid" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Paso 2" name="submit" class="Login"></td>
                          </tr>
                        </table>
						</form>  <?
            }elseif ($_POST['submit'] == "Paso 2"){
                $userid = clean($_POST['userid']);
                if($userid == ""){
                    alertbox("Escriba su Cuenta ID.","index.php?rg=resetpass");
                }
                $res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");
                if (mssql_num_rows($res) == 0){
                    alertbox("Cuenta ID ".ucfirst($userid)." no existe.","index.php?rg=rstpass");
                }
                $_SESSION['ResetPwdUser'] = $userid;
                $info = mssql_fetch_assoc($res);
                ?>
				<form method="POST" action="index.php?gunz=rstpass" name="newpass">
                <table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
					     <tr>
                            <td colspan="2" align="center" class="Estilo1">Ponga su E-mail y responda la Respuesta Secreta que usted haya puesto y haga click en Paso 3.</td>
                  </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">E-mail:</td>
                            <td class="Estilo1" align="right"><input name="email" type="text" class="Login" size="20" maxlength="40"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Pregunta secreta:</td>
                            <td class="Estilo1" align="right"><b>
                              <?=$info['SQ']?>
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Respuesta secreta:</td>
                            <td class="Estilo1" align="right"><input name="sa" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Paso 3" name="submit" class="Login"></td>
                          </tr>
                  </table>
				</form>
					 <?
                   }elseif ($_POST['submit'] == "Paso 3"){
                        $sa = clean($_POST['sa']);
                        $email = clean($_POST['email']);
                        $res = mssql_query("SELECT * FROM Account WHERE Email = '$email' AND SA = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
														<form method="POST" action="index.php?gunz=rstpass" name="newpass">
<table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
						    <tr>
                            <td colspan="2" align="center" class="Estilo1">Escoja una nueva contrase�a para su cuenta y haga click en Cambiar Contrase�a.</td>
                            </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Nueva contrase�a:</td>
                            <td class="Estilo1" align="right"><input name="pw1" type="password" class="login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Repita la contrase�a:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="pw2" type="password" class="login" size="20" maxlength="20">
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Cambiar Contrase&ntilde;a" name="submit" class="Login"></td>
                          </tr>
                        </table>
														</form>
					  <?
                            }else{
                                alertbox("E-Mail incorrecto o Respuesta secreta incorrecta.","index.php?gunz=rstpass");
                            }
                    }elseif ($_POST['submit'] == "Cambiar Contrase�a"){
                        if($_POST['pw1'] == $_POST['pw2']){
                            $pw1 = clean($_POST['pw1']);
                            mssql_query("UPDATE Login SET Password = '$pw1' WHERE UserID = '" . clean($_SESSION['ResetPwdUser']) . "'");
                            alertbox("Su contrase�a ha sido cambiada correctamente.","index.php");
                        }else{
                            alertbox("Llene los espacios en vacios.","index.php?gunz=rstpass");
                        }
                    }
							?></td>
  </tr>
  <tr>
    <td height="5" bgcolor="#151515"></td>
  </tr>
</table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>	
  </tr>
</table>
