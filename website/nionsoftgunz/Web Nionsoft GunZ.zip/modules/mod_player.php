<? SetTitle("GunZ Nionsoft - Informaci�n Del Personaje"); ?>
	<?
    $cid = clean($_GET['info']);
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    mssql_query("UPDATE Character SET Views = Views + 1 WHERE CID = $cid");
    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>INFORMACI�N DEL PERSONAJE </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25">
				  <table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0" class="login3">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                                <?=FormatCharName($char['CID'])?> Informaci&oacute;n</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="390" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="190" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Informaci�n Personal</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Nombre:</td>
                                    <td align="left" class="estilo1"><?=$char2['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Sexo:</td>
                                    <td align="left" class="estilo1"><?=$char2['Sex']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Edad:</td>
                                    <td align="left" class="estilo1"><?=$char2['Age']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Rango:</td>
                                    <td align="left" class="estilo1"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Usuario Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GM";
                                                        break;
							case "253";
                                                        $ugradeid = "Banned";
                                                        break;
							case "254";
                                                        $ugradeid = "Moderador";
                                                        break;
							case "255";
                                                        $ugradeid = "Administrador";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Pa&iacute;s:</td>
                                    <td align="left" class="estilo1"><?=$char2['Country']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">N&ordm; Usuario: </td>
                                    <td align="left" class="estilo1"><?=$char['AID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Visitas:</td>
                                    <td align="left" class="estilo1"><?=$char['Views']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Creado: </td>
                                    <td align="left" class="estilo1"><?=$char2['RegDate']?></td>
                                  </tr>
                                </table></td>
                                <td align="center" valign="top"><table width="190" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Informaci�n Del Personaje</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Nombre:</td>
                                    <td align="left" class="estilo1"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Level:</td>
                                    <td align="left" class="estilo1"><?=$char['Level']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ranking:</td>
                                    <td align="left" class="estilo1"><?=$char['Ranking']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Exp:</td>
                                    <td align="left" class="estilo1"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Kill/Death:</td>
                                    <td align="left" class="estilo1"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Clan:</td>
                                    <td align="left" class="estilo1"><?=$claninfo['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">N&ordm; Character:  </td>
                                    <td align="left" class="estilo1"><?=$char['CID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Creado: </td>
                                    <td align="left" class="estilo1"><?=$char['RegDate']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Ultima entrada: </td>
                                    <td align="left" class="estilo1"><?=$char['LastTime']?></td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table></td>
                          </tr>
</table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
