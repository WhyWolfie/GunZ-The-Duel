<? SetTitle("GunZ Nionsoft - Descargar"); ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
.Estilo2 {color: #000000}
-->
</style>
<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>SELECCIONA UN BOT�N DE DESCARGA PARA DESCARGAR GUNZ NIONSOFT</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" border="0">
                <tr>
                  <td align="center" class="Estilo1"><img src="img/descargas.png" width="260" height="109" border="1px" style="border-color:#000000"></td>
                  <td align="center" class="Estilo1" valign="top"> <p>GunZ - La combinacion de las balas y las cuchillas, GunZ ofrece una nueva alternativa disparo experiencia con un tema de anime. La lucha contra la pistola y espada | rapidos modos de accion 3D Quest. </p>                    </td>
                </tr>
                <tr>
                  <td colspan="2" align="center" class="Estilo1"><a href="#"><img src="img/bn_download_mirror1.png" width="100" height="20" border="0"></a><a href="#"><img src="img/bn_download_mirror2.png" width="100" height="20" border="0"></a><a href="#"><img src="img/bn_download_mirror3.png" width="100" height="20" border="0"></a></td>
                  </tr>
                <tr>
                  <td height="10" colspan="2" align="center" class="Estilo1"></td>
                </tr>
                <tr>
                  <td height="10" colspan="2" align="center" class="Estilo1">Requisitos del sistema El equipo debe�cumplir�ciertos requisitos m�nimos�para poder jugar GunZ. Antes de�descargar�e�instalar�GunZ,�por favor,�verifique�las especificaciones del sistema cumplir o�exceder los�siguientes. </td>
                </tr>
                <tr>
                  <td height="5" colspan="2" align="center" class="Estilo1"></td>
                </tr>
                <tr>
                  <td colspan="2" align="center" class="Estilo1"><table width="375" cellpadding="0" class="login3">
                    <tr bgcolor="#000000">
                      <td align="center" bgcolor="#101010" class="Estilo6">Descripci�n</td>
                      <td align="center" class="Estilo6">Minimo</td>
                      <td align="center" class="Estilo6">Recommendado</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Os</td>
                      <td colspan="2" align="center" class="Estilo1">Windows XP</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">DirectX</td>
                      <td colspan="2" align="center" class="Estilo1">DirectX 9.0c or above</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">CPU</td>
                      <td align="center" class="Estilo1">Pentium III 500 MHz</td>
                      <td align="center" class="Estilo1">Pentium III 800 MHz or higher</td>
                    </tr>
                    <tr>
                      <td height="22" align="center" bgcolor="#101010" class="Estilo6">RAM</td>
                      <td align="center" class="Estilo1">256MB</td>
                      <td align="center" class="Estilo1">512 MB or above</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Graphics Card</td>
                      <td align="center" class="Estilo1">Direct 3D 9.0 Compatible (Riva TNT)</td>
                      <td align="center" class="Estilo1">GeForce 4MX or higher</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Sound Card</td>
                      <td colspan="2" align="center" class="Estilo1">Direct3D Sound Compatible</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Mouse</td>
                      <td colspan="2" align="center" class="Estilo1">Windows Compatible (Wheel Mouse recommended)</td>
                    </tr>
                  </table></td>
                </tr>
              </table>
              <p class="Estilo1">Descargar controladores gr�ficos para aumentar la calidad del GunZ.</p>
              <p class="Estilo1"><a href="http://support.amd.com/us/gpudownload/Pages/index.aspx" target="_blank"><img src="img/ati_logo.png" width="90" height="52" border="0" /></a>    <a href="http://downloadcenter.intel.com/default.aspx" target="_blank"><img src="img/intel_logo.png" width="90" height="52" border="0" /></a>    <a href="http://www.nvidia.com/Download/index.aspx?lang=en-us" target="_blank"><img src="img/nvedia_logo.png" width="90" height="52" border="0" />    </a><a href="http://www.matrox.com/graphics/en/support/drivers/" target="_blank"><img src="img/matrox_logo.png" width="90" height="52" border="0" /></a><img src="../img/blank.gif" width="164" height="15" /></p></td>
          </tr>
          <tr>
            <td align="center"><p><img src="img/mc_controls_pic.gif" width="402" height="187"></p>              </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
