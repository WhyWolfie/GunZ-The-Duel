<? SetTitle("Gunz Nionsoft - Lista De Staff"); ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
.Estilo2 {font-weight: bold; color: #C6C126; }
-->
</style>
<table width="601" height="552" border="0" align="center">
  <tr>
    <td width="160" height="548" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="546" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="546" align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>STAFF DE GUNZ NIONSOFT</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="160" border="0" bgcolor="#151515">
              <tr>
                <td width="98" align="left" class="Estilo1"><font color="#D7D21C">&nbsp; </font><font color="#FF8000">Fundadores</font></td>
                <td width="110" align="left" class="Estilo1"><font color="#FF0000"> Administradores</font></td>
                <td width="81" align="left" class="Estilo1"><font color="#00FF00">Moderadores</font></td>
                <td width="93" align="left" class="Estilo1"><font color="#FFFF00">Colaboradores</font></td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img src="img/arrow.gif" alt="" width="10" height="10" /> N4gato</p>
                  <p>&nbsp;</p>
                  </td>
                <td align="left" class="Estilo1">
                  <p> <img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                  <p><img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                </td>
                <td align="left" class="Estilo1">
                  <p><img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                  <p><img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                </td>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                  <p> &nbsp;<img src="img/arrow.gif" alt="" width="10" height="10" /> ........ </p>
                  </td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
              <tr>
                <td height="33" align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
