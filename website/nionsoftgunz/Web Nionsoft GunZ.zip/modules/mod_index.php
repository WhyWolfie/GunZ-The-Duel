<?
SetTitle("GunZ Nionsoft - Inicio");
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>

<table width="601" height="586" border="0" align="center">
  <tr>
    <td width="160" height="582" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="580" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="18" align="center" valign="top"><? include"other/status.php" ?></td>
      </tr>
      <tr>
        <td align="center" height="5"></td>
      </tr>
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="center" valign="top"><table width="400" height="145" border="0" align="center" background="img/bn_news.png" style="background-repeat:no-repeat; background-position:center">
              <tr>
                <td valign="top"><table width="395" height="135" border="0" align="center" valign="top">
                    <tr valign="top">
                      <td width="190"><img src="../img/blank.gif" width="1" height="13" />
                        <table width="185" border="0" align="center">
                          <tr>
                            <td width="2"></td>
                          </tr>
                          <tr>
                            <td></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td width="9"><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td width="160" class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                          <tr>
                            <td></td>
                            <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                            <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                          </tr>
                      </table></td><td width="10"></td>
                      <td width="191" height="134"><img src="../img/blank.gif" width="1" height="13" />
                        <table width="185" border="0" align="center">
                        <tr>
                          <td width="2"></td>
                        </tr>
                        <tr>
                          <td></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td width="9"><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td width="160" class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                        <tr>
                          <td></td>
                          <td><img border="0" src="img/arrow.gif" width="10" height="10" id="img1" /></td>
                          <td class="Estilo1"><a href="#" target="_blank"><strong>GunZ Nionsoft Muy Pronto. </strong></a></td>
                        </tr>
                      </table></td>
                    </tr>
                </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td align="left"><a href="index.php?gunz=shop"><img src="img/mc_tit_prfeatures.png" width="120" height="30" border="0"></a></td>
          </tr>
          <tr>
            <td align="center" valign="top"><?
$res = mssql_query("SELECT TOP 2 * FROM CashShop WHERE Opened = 1 ORDER BY CSID DESC");
?><table width="415" height="100%" bgcolor="#151515" style="border-width: 1px; border-style: solid; border-color:#000000;">
              <tr>
                <? while($item = mssql_fetch_assoc($res)) 
		{
			if ($count == 2) 
			{
				$count = 1;
				echo "</tr>";
		?>
                <td width="449" align="center">
                  <table width="200" border="0">
                    <tr>
                      <td width="68" rowspan="5" valign="top"><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="64" height="64" style="border-width: 1px; border-style: solid; border-color: #000000;"></a></td>
                      <td colspan="2" class="estilo1" align="left"> <b>
                        <a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>">
                        <?=$item['Name']?></a>
                      </b> </td>
                    </tr>
                    <tr>
                      <td width="71" class="estilo1" align="left">Tipo:</td>
                      <td width="47" class="estilo1" align="left"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Sexo:</td>
                      <td class="estilo1" align="left"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Nivel:</td>
                      <td class="estilo1" align="left"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Precio:</td>
                      <td class="estilo1" align="left"><?=$item['CashPrice']?></td>
                    </tr>
                </table></td>
                <? 
			}
			else
			{
            ?>
                <td width="449" height="100" align="center">
                  <table width="200" border="0">
                    <tr>
                      <td width="68" rowspan="5" valign="top"><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="64" height="64" style="border-width: 1px; border-style: solid; border-color: #000000;"></a></td>
                      <td colspan="2" class="estilo1" align="left"><b>
                        <a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>">
                        <?=$item['Name']?></a>
                      </b> </td>
                    </tr>
                    <tr>
                      <td width="71" class="estilo1" align="left">Tipo:</td>
                      <td width="47" class="estilo1" align="left"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Sexo:</td>
                      <td class="estilo1" align="left"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Nivel:</td>
                      <td class="estilo1" align="left"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Precio:</td>
                      <td class="estilo1" align="left"><?=$item['CashPrice']?></td>
                    </tr>
                  </table></td>
                <?
				$count++;
				}
			}   
			?>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="10" align="center"><?php include "slide/slide.html"?></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
