<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
SetTitle("GunZ Nionsoft - Recuperar Personaje");
if ($_SESSION['AID'] == ""){
    alertbox("Entra primero con tu cuenta.","index.php");
    die();
	} 
else
{
    $qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($qchars) == 0 )
    {
	alertbox("Usted no tiene personajes en la cuenta.","index.php");
    die();
	} 
    else
    {
    if( isset($_GET['cid']) )
    {
        $cid = clean($_GET['cid']);
        $qcharinfo = mssql_query_logged("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
        if( mssql_num_rows($qcharinfo) == 0 )
        {
	alertbox("El personaje no existe en la cuenta.","index.php");
    die();
	}
        $info = mssql_fetch_assoc($qcharinfo);

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
        {
	alertbox("El personaje que se va a recuperar, no puede ser recuperado porque ya existe ese nombre.","index.php");
    die();
	}
        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        else
        {
	alertbox("Usted tiene 4 personajes, borre uno para poder recuperar.","index.php");
    die();
	}
	alertbox("Tu personaje seleccionado ha sido recuperado.","index.php");
    die();
	}
    else
    {
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="601" height="500" border="0" align="center">
  <tr>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>RECUPERAR PERSONAJE</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25">Aqu&iacute; se puede tomar personajes que ha eliminado o ha <br />
                  inadvertidamente borrado. <br />
                  Usted debe saber que en una cuenta de GunZ se permite <br />
                  un m&aacute;ximo de 4 caracteres,<br />
                  si tiene 4 personajes activos y <br />
                  desea recuperar uno de los personajes eliminado, <br />
                  Eliminar un car&aacute;cter activo <br />
                  para dar lugar al que se va a recuperar.</td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="10"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25"><table width="350" align="center" class="errorbox" id="table1">
        	<tr>
        	  <td colspan="4" align="center" class="Estilo1">Lista de Personajes </td>
        	  </tr>
        	<tr>
        	  <td height="5" colspan="4" align="center" class="Estilo1"></td>
      	  </tr>
        	<tr>
        		<td align="center" class="Estilo1"><b>Nombre</b></td>
        		<td align="center" class="Estilo1"><b>Level</b></td>
        		<td align="center" class="Estilo1"><b>Tipo</b></td>
        		<td align="center" class="Estilo1"><b>�Recuperar?</b></td>
        	</tr>
            <?

        while( $data = mssql_fetch_assoc($qchars) )
        {
            echo '
            	<tr>
            		<td align="center" class="Estilo1">';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo $data[DeleteName].'</td>';
                    }else{
                        echo $data[Name].'</td>';
                    }

                echo '<td align="center" class="Estilo1">'.$data[Level].'</td>
            		<td align="center" class="Estilo1">';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo 'Borrardo</td>
                    <td align="center" class="Estilo1">';
                    }else{
                        echo 'Activo</td>
                    <td align="center" class="Estilo1">';
                    }
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo '<a href="index.php?gunz=recoverplayer&cid='.$data[CID].'">Recuperar</a></td>
            	</tr>';
                    }else{
                        echo 'Activo</td>
            	</tr>';
                    }

        }
        ?>
        </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
  </tr>
</table>
<?
    }
}
}

?>