<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
SetTitle("GunZ Nionsoft - Entrar");
if($_SESSION[AID] != "")
{
    header("Location: index.php");
    die();
}

if(isset($_POST[submit]))
{
    $user = clean($_POST[userid]);
    $pass = clean($_POST[pass]);

    $ip = $_SERVER['REMOTE_ADDR'];

    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
	
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
	alertbox("Usted ha fallado 5 veces, porfavor intentelo nuevamente en 15 minutos.","index.php");
    die();
}
    $loginquery = mssql_query_logged("SELECT l.UserID, l.AID, c.UGradeID, l.Password FROM Login(nolock) l INNER JOIN Account(nolock) c ON l.AID = c.AID WHERE l.UserID = '$user' AND l.Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];
        $_SESSION[Password] = md5(md5($logindata[3]));

        $url = ($_SESSION[URL] == "") ? "index.php" : $_SESSION[URL];
        $_SESSION[URL] = "";

        header("Location: $url");
        die();
    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
alertbox("Cuenta ID o Contrase�a son incorrectos por favor verifique e intente de nuevo.","index.php");
    die();
	}}
?>