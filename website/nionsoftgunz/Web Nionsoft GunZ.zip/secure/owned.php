<p><strong><font size="6">No Funciona</font></strong><br>
  <br>
Usted no tiene permiso para entrar.<br>
</p>
<hr>
<p> 
  <em>Usted ha sido baneado de GunZ Nionsoft</em></p>
