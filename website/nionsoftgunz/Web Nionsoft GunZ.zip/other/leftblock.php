<table width="160" height="499" border="0" cellpadding="0" cellspacing="0">
<tr>
        <td width="157" height="496" align="center" valign="top"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
          
          <tr>
            <td align="center"><a href="index.php?gunz=download"><img src="img/l_main_sysreqdl.png" width="175" height="50" border="0"></a></td>
          </tr>
           <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>    
            <td height="14" align="center"><? include"other/top5player.php" ?></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="14" align="center"><? include"other/top5clan.php" ?></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="10" align="center"><table width="0" height="135" border="0" align="center">
              <tr>
                <td height="20"><a href="index.php?gunz=sign"><img src="img/firma_dinamica.png" width="175" height="40" border="0" /></a></td>
              </tr>
              <tr>
                <td height="20"><a href="index.php?gunz=status"><img src="img/serverstat.png" width="175" height="40" border="0" /></a></td>
              </tr>
              <tr>
                <td height="42"><div align="center">
                  <p><a href="xat"></a><a href="http://www.facebook.com/GunzNionsoft" target="_blank"><img src="img/facebook.png" width="172" height="40" border="0" /></a></p>
                  </div></td>
              </tr>
              <tr>
                <td height="42">&nbsp;</td>
              </tr>
            </table>
            <p>&nbsp;</p>            </td>
          </tr>
        </table>
        </td>
  </tr>
</table>

<map name="Map" id="Map">
  <area shape="rect" coords="10,50,58,96" href="http://www.facebook.com/GunzNionsoft" target="_blank" />
  <area shape="rect" coords="110,49,156,95" href="#" />
</map>