<?
$res = mssql_query("SELECT TOP 5 * FROM Clan ORDER BY Point DESC");
$count = 0;
?>
<table width="175" height="145" border="0" align="center" id="table4" style="border-collapse: collapse">
  <tr>
    <td background="img/bn_crank_top.png" height="35" width="175"></td>
  </tr>
  <tr>
    <td background="img/bn_rank_content.png">
      <table border="0" style="border-collapse: collapse" width="168" height="100%">
        <tr>
          <td width="1"></td>
          <td width="31"></td>
          <td width="81"></td>
          <td width="37"></td>
        </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
        <tr>
          <td width="1"></td>
          <td width="31"></td>
          <td width="81"><center>
              <span class="Estilo1">No Data //</span>
          </center></td>
        </tr>
        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){
									$count++;

                                    ?>
        <tr>
          <td width="1"></td>
          <td width="31"><center><span class="Estilo6"><?=$count?></span></center></td>
          <td width="81"><span class="Estilo6"> <?=$clan['Name']?></span></td>
          <td width="37">
            <p align="center"><b>
              <span class="Estilo6"><?=$clan['Point']?></span>
          </b></td>
        </tr>
        <?}}?>
        <tr>
          <td width="1" height="2"></td>
          <td width="31"></td>
          <td width="81"></td>
          <td width="37"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td background="img/bn_rank_down.png" style="background-repeat:no-repeat" height="7"></td>
  </tr>
</table>          
   