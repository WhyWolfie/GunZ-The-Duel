<?
                            if( isset($_GET['date']) )
                            {
                                $date = clean($_GET['date']);
                                $date = explode("-", $date);
                                $month = $date[0];
                                $year = $date[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>
<style type="text/css">
<!--
.Estilo1 {color: #CCCCCC}
.Estilo2 {color: #FFFFFF; }
-->
</style>

                            <table border="0" width="575" cellpadding="0" cellspacing="0">
							      <tr valign="top">
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left"><img src="img/tit_hof.gif" width="150" height="23"></td>
      </tr><tr><td align="left" class="estilo5">&nbsp;</td>
      </tr>
								      <tr>
        <td align="center" height="25"></td>
      </tr>
								<tr>
									<td width="575" align="left" valign="top">
                                    <form method="GET" name="honorrank" action="index.php">
                                    <input type="hidden" name="gunz" value="hallofame" />
<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" class="estilo5">  
                                    <input type="hidden" name="gunz" value="hallofame" />
                                    <b><?=$month?>.<?=$year?></b> Hall Of Fame</td>
            <td align="right" class="estilo5"><select name="date" onchange="document.honorrank.submit()" class="login">
                                    <option>Seleccionar una Fecha</option>
                                    <?
                                    $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'.'.$halldata[Year].'</option>';
									}
                                    ?>
                                    </select>
	        </td>
          </tr>
   </table>
									</form>
                                    
                                    </td>

								<tr>
									<td width="575" valign="top">
                                        <table border="0">
											<tr>
												<td width="60" height="21" valign="bottom">
        <td height="20" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="37" height="23" align="center" class="Estilo5"><b>Ranking</b></td>
            <td width="108" height="23" align="center" class="Estilo5"><b>Nombre del Clan</b></td>
            <td width="79" height="23" align="center" class="Estilo5"><b>Lider</b></td>
            <td width="85" height="23" align="center" class="Estilo5"><b>Victorias/Derrotas %</b></td>
            <td width="59" height="23" align="center" class="Estilo5"><b>Puntos</b></td>
          </tr>
                        <?
                                switch( clean($_GET['page']) )
                                {
                                    case "":
                                        $ranks = "Ranking <= 20";
                                    break;
                                    case "2":
                                        $ranks = "Ranking > 20 AND Ranking <= 40";
                                    break;
                                    case "3":
                                        $ranks = "Ranking > 40 AND Ranking <= 60";
                                    break;
                                    case "4":
                                        $ranks = "Ranking > 60 AND Ranking <= 80";
                                    break;
                                    case "5":
                                        $ranks = "Ranking > 80 AND Ranking <= 100";
                                    break;
                                    default:
                                        $ranks = "Ranking <= 20";
                                    break;
                                }
                                $res = mssql_query_logged("SELECT * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                if(mssql_num_rows($res) <> 0)
                                {
                                    while($clan = mssql_fetch_object($res))
                                    {

                                        $clanemburl = ($clan->EmblemUrl == "") ? "no_emblem.jpg" : $clan->EmblemUrl;
                                ?>
                <tr>
                  <td colspan="5" align="center" class="Estilo1" height="6"></td>
          </tr>
                <tr style="background-image:url(img/li_x_01.gif); background-position:bottom; background-repeat:repeat-x;">
                  <td width="64" align="center" class="Estilo5">
                    <b><?=$clan->Ranking?></b>
                  </td>
                  <td width="160" align="center" class="Estilo5">
                    <font color="#505050"><b><?=$clan->ClanName?></b></font></td>
                  <td width="106" align="center" class="Estilo5"> 
                    <font color="#505050"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="133" align="center" class="Estilo5"><?=$clan->Wins?>/<?=$clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                   </td>
                  <td width="85" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                                <?
                                    }
                                }
                                else
                                {
                                ?>
									<tr>
									<td width="575" align="center" colspan="7" class="estilo5">
									-No Data-</td>
									</tr>
                                <?
                                }

                            }
                            else
                            {
                                $querydate = mssql_query("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                $ddata = mssql_fetch_row($querydate);
                                $month = $ddata[0];
                                $year = $ddata[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>

	<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr valign="top">
        <td height="20"></td>
      </tr>							
     			 			<form method="GET" name="honorrank" action="index.php"> <tr>
        <td height="35" align="center">	

						<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" class="estilo5">  
                                    <input type="hidden" name="gunz" value="hallofame" />
                                    <b><?=$month?>.<?=$year?></b> Hall Of Fame</td>
            <td align="right" class="estilo5"><select name="date" onchange="document.honorrank.submit()" class="login">
                                    <option>Seleccionar Fecha</option>
                                    <?
                                    $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'.'.$halldata[Year].'</option>';
									}
                                    ?>
                                    </select>			      </td>
          </tr>
   </table></td>
      </tr></form>
      <tr>
        <td height="30" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="67" height="23" align="center" class="Estilo15"><b>Ranking</b></td>
            <td width="151" height="23" align="center" class="Estilo15"><b>Nombre del Clan</b></td>
            <td width="93" height="23" align="center" class="Estilo15"><p><b>Li</b><b>der</b></p>              </td>
            <td width="169" height="23" align="center" class="Estilo15"><b>Victorias/Derrotas %</b></td>
            <td width="90" height="23" align="center" class="Estilo15"><b>Puntos</b></td>
          </tr>
          <tr>
            <td colspan="5" valign="top">
              <table width="570" border="0" align="center" style="border-collapse: collapse">

                        <?
                                switch( clean($_GET['page']) )
                                {
                                    case "":
                                        $ranks = "Ranking <= 20";
                                    break;
                                    case "2":
                                        $ranks = "Ranking > 20 AND Ranking <= 40";
                                    break;
                                    case "3":
                                        $ranks = "Ranking > 40 AND Ranking <= 60";
                                    break;
                                    case "4":
                                        $ranks = "Ranking > 60 AND Ranking <= 80";
                                    break;
                                    case "5":
                                        $ranks = "Ranking > 80 AND Ranking <= 100";
                                    break;
                                    default:
                                        $ranks = "Ranking <= 20";
                                    break;
                                }
                                $res = mssql_query_logged("SELECT * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                if(mssql_num_rows($res) <> 0)
                                {
                                    while($clan = mssql_fetch_object($res))
                                    {

                                        $clanemburl = ($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl;
                                ?>                       
                <tr>
                  <td colspan="5" align="center" class="Estilo1" height="6"></td>
                  </tr>
                <tr style="background-image:url(img/li_x_01.gif); background-position:bottom; background-repeat:repeat-x;">
                  <td width="64" align="center" class="Estilo5">
                    <b><?=$clan->Ranking?></b>                  </td>
                  <td width="143" align="center" class="Estilo5">
                    <font color="#505050"><b><?=$clan->ClanName?></b></font></td>
                  <td width="93" align="center" class="Estilo5"> 
                    <font color="#505050"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="163" align="center" class="Estilo5"><?=$clan->Wins?>/<?=$clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                   </td>
                  <td width="85" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                                <?
                                    }
                                }
                                else
                                {
                                ?>
                <tr>
                  <td height="35" colspan="5" align="center" class="estilo5">- No Data - </td>
                </tr>
                                <?
                                }

                            }
                        ?>
            </table>          </td>
          </tr>
          <tr>
            <td height="75" colspan="5" align="center"><table width="500" border="0" cellpadding="0" cellspacing="0" align="center">
              <tr>
              <tr>
                <td height="30" align="center" class="estilo5" valign="baseline"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>" class="Estilo11">1-20</a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=2" class="Estilo11">20-40</a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=3" class="Estilo11">40-60</a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=4" class="Estilo11">60-80</a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=5" class="Estilo11">80-100</a></td>
                          </tr>
                      </table></td>
                    </tr>
                </table></td>
              </tr>

          </table></td>
          </tr>
          <tr>
            <td colspan="5" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
    </table>