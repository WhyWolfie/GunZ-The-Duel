<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
if($_SESSION[AID] == "")
{
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>


<form name="login" method="POST" action="index.php?gunz=login"><table width="180" height="130" border="0" align="center" cellpadding="0" cellspacing="0" background="img/loginzone_bg.png" style="background-repeat:no-repeat; background-position:center">
<table width="184" height="174" border="0" cellpadding="0" cellspacing="0" background="img/r_signin01_renewal.gif" align="center" style="background-repeat:no-repeat; background-position:center;">
  <tr>
    <td width="180" height="20" align="center" valign="top" class="estilo1"><table width="174" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="35"></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="69" align="center" valign="top" class="estilo1"><table width="164" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="90" align="left"><input name="userid" type="text" class="Login2" style=" background-image:url(img/usrnm_bg.jpg); background-repeat:no-repeat" tabindex="1" value="" size="15"></td>
        <td width="50" rowspan="3"></td>
        <td width="54" rowspan="3" align="center"><input name="login" type="image" id="login" src="img/r_signin_btnlogin.png" align="right" width="50" height="50" border="0"></td>
      </tr>
      <tr>
        <td height="4"></td>
      </tr>
      <tr>
        <td align="left">
          <input name="pass"  type="password" class="Login2" style="background-image:url(img/pw_bg.jpg); background-repeat:no-repeat" tabindex="2" size="15"></td>
      </tr>
      <input type="hidden" name="submit" value="1">
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="top" class="estilo1"><table width="150" border="0" align="center">
      <tr>
        <td align="center" class="estilo1" height="1"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><a href="index.php?gunz=register"><a href="index.php?gunz=register"><a href="index.php?gunz=register"></a></a><a href="index.php?gunz=register"><img src="img/btn_free_signup.png" width="150" height="25" border="0" /></a></a><a href="index.php?gunz=register"></a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="1"><a href="index.php?gunz=rstpass"><strong>&iquest;Olvidaste Tu Contrase&ntilde;a?</strong></a></td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
<?
}else{
$res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$a=mssql_fetch_assoc($res9);

$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
$d=mssql_fetch_assoc($res);
$items = mssql_num_rows($res9);

$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query2 = mssql_query_logged("SELECT Coins, ECoins FROM Account WHERE AID = '{$_SESSION[AID]}'");
$_PLAYER[Account]   = mssql_fetch_assoc($query2);
?>
<table width="184" height="245" border="0" align="center" cellpadding="0" cellspacing="0" background="img/r_signin02_renewal.gif" style="background-repeat:no-repeat; background-position:top center;">
  <tr valign="top">
    <td align="center" class="estilo1"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="10" align="left" class="estilo7"></td>
      </tr>
      <tr>
        <td align="left" class="estilo7">Bienvenido, <?=$_SESSION[UserID]?></td>
      </tr>
      <tr>
        <td align="left" class="estilo6">(<a href="index.php?gunz=logout">Salir</a>)</td>
      </tr>
      <tr>
        <td align="right" class="estilo6" height="33" valign="bottom"><a href="index.php?gunz=clanrank"></a>&nbsp;&nbsp;&nbsp;</td>
      </tr>
      <tr>
        <td align="right" class="estilo6" height="4" valign="bottom"></td>
      </tr>
      <tr>
        <td align="right" class="estilo6" height="50"><?
		
                                                    if(CheckIfExistClan($_SESSION[AID]))
                                                    {
												?>
                                                <table width="160" height="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
                                          <tr>
                                            <td width="77" align="center" valign="middle"><img id="emblem" src="./clan/emblem/" width="35" height="36" style="border: 1px #000000"></td>
                                            <td width="20" height="10" align="right">
                                                   <select onchange="UpdateClan()" id="clanlist" size="0" name="selclan" class="Login2">
                                                 &nbsp;&nbsp; <?
                                                            $re = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
                                                            if( mssql_num_rows($re) > 0 )
                                                            {
                                                            while($char = mssql_fetch_assoc($re))
                                                            {
                                                                     $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
                                                                     if( mssql_num_rows($queryc) > 0 )
                                                                     {
                                                                        $a = mssql_fetch_assoc($queryc);
                                                                        $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));

                                                                         $_CLAN[Name]       = $b[Name];
                                                                         $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
                                                                         $_CLAN[CLID]       = $a[CLID];
                                                                         $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "./img/no_emblem.png" : $b[EmblemUrl];

                                                                         $info = implode("-|-", $_CLAN);

                                                                         if($_CLAN[Name] <> "")
                                                                            echo "<option value = '$info'>{$_CLAN[Name]}</option>";
                                                                     }
                                                                }
                                                            }
                                                            ?>
                                              </select>
                                              &nbsp;
                                              &nbsp;
                                              &nbsp; 
                                              &nbsp;                                              </td>
                                         <td width="60" align="center" class="estilo6">Lider:&nbsp;
                                         &nbsp;
                                         <br><div id="clanmaster">&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
                                          </tr>
          </table></td>
      </tr>                                        <?
                                                    }else{
                                                    ?>
                                        <table border="0" cellpadding="0" cellspacing="0" width="160" height="100%">
                                          <tr>
                                            <td height="50" align="center" class="Estilo6">No est�s en ning�n clan clan.<br>
�nete a uno o crea el tuyo </td>
                                          </tr>
                                          <td></td>
                                        </table>
                                        <?
                                                    }
                                                    ?>
      <tr>
        <td height="25" align="center" class="estilo6"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td class="estilo1"><strong>Coins:</strong> <strong>(<?=$_PLAYER[Account][Coins]?>)</strong></td>
            <td class="estilo1"><strong>ECoins:</strong> <strong>(<?=$_PLAYER[Account][ECoins]?>)</strong></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="35" align="center" class="estilo6"></td>
      </tr>
      <tr>
        <td height="25" align="center" class="estilo6"><table width="164" height="50" border="0" align="center" cellpadding="0" cellspacing="0" background="img/paneloption.jpg" style="background-repeat:no-repeat; background-position:center;">
            <tr>
              <td align="left"><a href="index.php?gunz=myprofile"><img src="img/blank.gif" width="75" height="16" border="0"></a></td>
              <td align="right"><a href="index.php?gunz=upload&step=1"><img src="img/blank.gif" width="75" height="16" border="0"></a></td>
            </tr>
            <tr>
              <td align="left"><a href="index.php?gunz=game"><img src="img/blank.gif" width="70" height="16" border="0"></a></td>
              <td align="right"><a href="index.php?gunz=myitems"><img src="img/blank.gif" width="82" height="16" border="0" /></a></td>
            </tr>
            <tr>
              <td colspan="2" align="center"><a href="index.php?gunz=delclan"><img src="img/blank.gif" width="82" height="16" border="0" /></a></td>
              </tr>
          </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("emblem");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "" + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>
<script language="javascript">
									UpdateClan();
								</script>
<?
}
?>