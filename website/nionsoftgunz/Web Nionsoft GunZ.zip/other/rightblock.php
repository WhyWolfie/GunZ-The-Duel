<table width="190" height="327" border="0" align="center" cellpadding="0" cellspacing="0">
<tr>
        <td width="190" height="327" align="center" valign="top"><table width="190" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="4"></td>
          </tr>
          <tr>
            <td align="center"><? include"other/userpanel.php" ?></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=recoverplayer"><img src="img/clanrank_banner.jpg" width="175" height="65" border="0"></a></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=staff"><img src="img/playerran_banner.jpg" width="175" height="65" border="0"></a></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=donate"><img src="img/shop_banner.jpg" width="175" height="100" border="0"></a></td>
          </tr>
          </table></td>
  </tr>
    </table>