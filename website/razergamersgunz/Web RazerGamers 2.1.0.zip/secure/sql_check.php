<?
//////////////////////////////////////////////
$bloquiados = array(";","\"","%","'","+","#","$","--","==","z'; U\PDATE Account S\ET ugradeid=char","x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=254;-\-","x';U\PDATE Account D\ROP ","x';U\PDATE Account D\ROP ugradeid=252;-\-","x';U\PDATE Account D\ROP ugradeid=2;-\-"); 
foreach($_POST as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <img src=\" /><br />
    <br />
          <span class=\"textbox style20\">Que Intentas Hacer?</span></p>
	  <META HTTP-EQUIV='Refresh' CONTENT='3; URL=http://razergunz.com'></p>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Regresar</a></p>
</div>");
		}
	}
}
foreach($_GET as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <br />
           <span class=\"textbox style20\">Que Intentas Hacer? </span></p>
	  <META HTTP-EQUIV='Refresh' CONTENT='3; URL=http://razergunz.com'></p>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Regresar</a></p>
</div>");
		}
	}
}
foreach($_COOKIE as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <br />
      <span class=\"textbox style20\">volviendo a razergunz </span></p>
	  <META HTTP-EQUIV='Refresh' CONTENT='3; URL=http://razergamers.net'>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Volver</a></p>
</div>");
		}
	}
} ?>