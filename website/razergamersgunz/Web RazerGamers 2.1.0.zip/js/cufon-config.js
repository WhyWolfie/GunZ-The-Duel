Cufon.replace('a#logo', {
	color: '-linear-gradient(white, #bfbfbf)',
	textShadow: '#2d3031 1px 1px' 
});