<?
$res = mssql_query("SELECT TOP 5 * FROM Account a, Character b WHERE b.AID=a.AID AND a.UGradeID !=255 AND a.UGradeID !=254 AND a.UGradeID !=253 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
?>
<style type="text/css">
<!--
.Estilo6 {
	font-size: 11px;
	color: #FFFFFF;
}
.style1 {color: #FF0000}
-->
</style>

<table background="img/rankU.png"  width="216" height="141" border="0">
<tr>
    <td><table width="198" height="100" border="0" style="border-collapse: collapse">
      <tr>
        <td width="1" rowspan="6">&nbsp;</td>
        <td height="15" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          No hay datos</td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="20" align="left">
  															<div align="center"><img border="0" src="/images/inconos/mod.png" width="20" height="20"></div></td>
  															<td width="74" align="left"><div align="center"><span class="Estilo6">
														    <?=$user['Name']?>
  															  </span>
															                                    </div>
						  <td width="56"><div align="center"><span class="Estilo6">
					      <span class="style1">Lvl:</span>
				          <?=$user['Level']?>
						  </span></div></td>
										<td width="9"></td>
										<td width="12">										</td>
		</tr>
                                    <?}}?>
									<tr>
    </table>    
    <td height="39"></tr>
</table>
