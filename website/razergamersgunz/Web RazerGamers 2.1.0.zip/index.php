<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "RazerGamers Gunz", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<script language="JavaScript">
<!--
<!--

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>
<link rel="stylesheet" type="text/css" href="e_style.css"><style type="text/css">
<!--
body,td,th {
	color: #000000;
}
.style1 {color: #000000}
-->
</style></head>

<div align="center">
	<table border="0" style="border-collapse: collapse" width="90%">
		<tr>
		</tr>
		<tr>
			<td>&nbsp;</td>
					<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3">&nbsp;				</td>
          </tr>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
		</tr>
		<tr>
			<td>
		<div align="center">
          </div>          	</td>
		</tr>
	</table>
</div>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cs" lang="cs">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="content-language" content="en" />
        <meta name="author" lang="en" content="[www.razergunz.com]; e-mail: elmsndeblue@aotlook.com" />
		<script language="JavaScript">
</script>
        
        <link href="css/screen.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link href="css/print.css" type="text/css" rel="stylesheet" media="print" />
        
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript"></script>
        <script src="js/cufon.js" type="text/javascript"></script>
        <script src="js/cufon-config.js" type="text/javascript"></script>
        <script src="js/font.js" type="text/javascript"></script>
        
        <title>RazerGamers Gunz - Version 2.1.0</title>
        </style>
</head>
    <body>
    <div class="wrap">
  <!-- cols end -->
  <table width="806" height="46" border="1">
    <tr>
      <td width="796">		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
          <td width="800" colspan="3">&nbsp;				</td>
            </tr>
          <tr>
            <td width="10">&nbsp;</td>
              <td width="778">
                <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("Error 404", array("La Pagina que selecciono '$do' no existe"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>			</td>
              <td width="12">&nbsp;</td>
            </tr>
          <tr>
            <td width="800" colspan="3">&nbsp;			</td>
            </tr>
          <tr>
            <td width="800" colspan="3">
              </td>
            </tr>
          </tbody></table>
                  <div align="left"></div></td>
    </tr>
    </table>
    </div><hr class="noscreen" />

        <div id="header">
            <div class="wrap">
                
                <!-- Logo RazerGunz -->
                  <a id="logo" href="index.php" title="RazerGunz 2.1.0">RazerGamers<strong> Gunz</strong></a>
        
                <hr class="noscreen noprint" />
        
                <!-- Navigation start -->
                <strong class="noscreen noprint">Navigacion:</strong>
                <ul id="nav">
                    <li class="active"><a href="index.php" title="Noticias de RazerGunz">Inicio</a></li>
                    <li><a href="?do=registro" title="Registraste en RazerGunz">Registro</a></li>
                    <li><a href="?do=descargas" title="Descarga aqui el cliente oficial de RazerGunz">Descargas</a></li>
                    <li><a href="?do=topfama" title="Aqui estan los mejores usuarios y clanes.">Ranking</a></li>
                    <li><a href="?do=foro" title="Nuestro foro soporte oficial de RazerGamers.net">Foro</a></li>
					<li><a href="?do=tienda" title="Aqui encontraras item únicos llamados items donator o si no puedes cambiar tus Event coins por items evento.">Tienda</a></li>
					<li><a href="?do=submenu" title="revisa los nuevos sistema de modulo que tiene nuestro sitio web">Menu</a></li>
                </ul>
           
            </div>
        </div>
        
        <hr class="noscreen" />
  

        
        <p class="footer">
            <span class="floatLeft">&copy; 2012 - <a href="http://gunz.razergamers.net">RazerGamers Gunz Version 2.1.0</a></span>
            

                <span id="dont-delete-this" class="floatRight noprint">Template web creado por : <a href="http://razergamers.net" 
title="Jose Barrios">Jose Barrios</a> | Programacion echa por <a href="http://razergamers.net" class="Jose Barrios">Jose Barrios<span></span></a></span>        </p>
        
		


        <p align="center"><!-- Codigo contadorvisitas.com ver. 4.3 -->
<script language="javascript" src="http://aux01.contadorgratis.com/hitv4.php?digit=scoreboard&page=a412b052920425913d04ae9566f0a39d"></script>
<br><font size=1><a href="http://razergamers.net" target="_blank">RazerGamers Gunz Contador</a></font>
<!-- FIN Codigo contadorvisitas.com -->
                    &nbsp;</p>
    </body>
</html>