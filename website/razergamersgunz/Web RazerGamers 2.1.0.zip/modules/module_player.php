<?php
SetTitle("RazerGamers Gunz - Clan Informacion");
?><style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
}
.Estilo1 {font-size: 10px}
.Estilo2 {color: #FF0000}
.Estilo5 {color: #00FF00; }
.Estilo6 {
	color: #FF0000;
	font-size: 10px;
	font-style: italic;
}
.style7 {color: #999999}
.style8 {
	color: #FFFFFF;
	font-weight: bold;
}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('../images/boton_donar02.png')">
<table width="91%" border="0" align="center" style="border-collapse: collapse">
					<tr>
					  <td width="174" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
					  </div>						<p>&nbsp;</p></td>
						<td width="684" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="87%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Informacion de Usuario</font></b></td>
							  </tr>
								<tr>
								  <td height="358" valign="top" bgcolor="#666666"><?
    $cid = clean($_GET['info']);
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
                                    <style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="460" height="335" border="0" align="center">
  <tr>
    <td width="1" height="331" align="center" valign="top">&nbsp;</td>
    <td width="440" align="center" valign="top"><table width="422" height="329" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="329" align="center" valign="top"><table width="441" border="0">
          <tr>
            <td width="435" align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25">
				  <table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center">
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0" class="login3">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" align="center" class="Estilo2">
                                <?=FormatCharName($char['CID'])?> Informaci&oacute;n</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="413" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td width="194" align="center" valign="top"><table width="190" border="1" align="center" bordercolor="#000000">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Informaci�n Personal</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1">Nombre:</td>
                                    <td width="135" align="left" class="estilo1"><?=$char2['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Sexo:</td>
                                    <td align="left" class="estilo1"><?=$char2['Sex']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Edad:</td>
                                    <td align="left" class="estilo1"><?=$char2['Age']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Rango:</td>
                                    <td align="left" class="estilo1"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Usuario Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GM";
                                                        break;
							case "253";
                                                        $ugradeid = "Banned";
                                                        break;
							case "254";
                                                        $ugradeid = "Moderador";
                                                        break;
							case "255";
                                                        $ugradeid = "Administrador";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Pa&iacute;s:</td>
                                    <td align="left" class="estilo1"><?=$char2['Country']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">N&ordm; Usuario: </td>
                                    <td align="left" class="estilo1"><?=$char['AID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Visitas:</td>
                                    <td align="left" class="estilo1"><?=$char['Views']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Creado: </td>
                                    <td align="left" class="estilo1"><?=$char2['RegDate']?></td>
                                  </tr>
                                </table></td>
                                <td width="217" align="center" valign="top"><table width="212" border="1" align="center" bordercolor="#000000">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Informaci�n Del Personaje</td>
                                  </tr>
                                  <tr>
                                    <td width="93" align="left" class="estilo1">Nombre:</td>
                                    <td width="103" align="left" class="estilo1"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Level:</td>
                                    <td align="left" class="estilo1"><?=$char['Level']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ranking:</td>
                                    <td align="left" class="estilo1"><?=$char['Ranking']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Exp:</td>
                                    <td align="left" class="estilo1"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Kill/Death:</td>
                                    <td align="left" class="estilo1"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Clan:</td>
                                    <td align="left" class="estilo1"><?=$claninfo['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">N&ordm; Character:  </td>
                                    <td align="left" class="estilo1"><?=$char['CID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Creado: </td>
                                    <td align="left" class="estilo1"><?=$char['RegDate']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Ultima entrada: </td>
                                    <td align="left" class="estilo1"><?=$char['LastTime']?></td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table></td>
                          </tr>
</table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="10" align="center" valign="top">&nbsp;</td>
  </tr>
</table></td>
								</tr>
						  </table>
						</div>
					  <p align="center"></td>
						<td width="205" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
					  </td>
					</tr>
</table>
