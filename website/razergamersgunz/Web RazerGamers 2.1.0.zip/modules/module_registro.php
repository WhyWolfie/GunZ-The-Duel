<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style1 {
	font-size: 9px;
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}
.style7 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; }
.style8 {font-family: Arial, Helvetica, sans-serif}
-->
</style>

<table border="0" style="border-collapse: collapse" width="70%">
					<tr>
						<td width="200" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
						</p></td>
						<td width="609" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="66%" bordercolor="#000000">
								<tr>
								  <td height="798" valign="top"><table width="388" height="358" align="center" background="img/Register_bg.png">
                                    <tr>
                                      <td valign="top"><table width="378" height="340">
                                        <tr>
                                          <td width="368" height="23">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td><div align="center"><iframe src="registro.php" name="fx" width="366" height="312" align="middle" scrolling="auto" frameborder="0" allowtransparency="true"></iframe></div></td>
                                        </tr>
                                      </table></td>
                                    </tr>
                                  </table></td>
								</tr>
						  </table>
						</div>					  </td>
					</tr>
</table>
</td>