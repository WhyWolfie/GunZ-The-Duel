<?php
SetTitle("RazerGamers Gunz - Mi Perfil");
?><style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #FFFFFF;
	font-weight: bold;
}
.Estilo1 {font-size: 10px}
.Estilo2 {color: #FF0000}
.Estilo5 {color: #00FF00; }
.Estilo6 {
	color: #FF0000;
	font-size: 10px;
	font-style: italic;
}
.style2 {font-size: 10}
.style3 {font-size: 9px}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('../images/boton_donar02.png')">
<table width="91%" border="0" align="center" style="border-collapse: collapse">
					<tr>
					  <td width="174" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
					  </div>						<p>&nbsp;</p></td>
						<td width="684" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="90%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Mi Perfil Personal</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#666666">
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><table width="422" border="1" bordercolor="#000000">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td class="estilo2" width="10">&nbsp;                     </td>
                  <td width="405" height="30" class="style2"><div align="center" class="style3">Informaci&oacute;n de mi perfil de juego</div></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25">
				<?
echo '  <font class="estilo1">Mis Personajes:</font>';
        $query = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."' AND DeleteFlag = 0 ORDER BY CharNum ASC");
        if ( mssql_num_rows($query) < 1 ){
        echo '<font face="Arial" color="#ff0000"><br>No tienes ningun personaje, Create uno.</br>';
        }else{

        echo '
        <table width="350" align="center" class="errorbox">
	    <tr>
		<td class="estilo1" align="center">Nombre</td>
		<td class="estilo1" align="center">Level</td>
		<td class="estilo1" align="center">Experiencia</td>
        <td class="estilo1" align="center">Bounty</td>
        <td class="estilo1" align="center">Kill/Death</td>
	    </tr>';
        $i = 1;
        while ( $i <= mssql_num_rows($query) ){
        $chars = mssql_fetch_assoc($query);
        echo '<tr>
		<td class="estilo1" align="center">'.FormatCharName($chars['CID']).'</td>
		<td class="estilo1" align="center">'.$chars['Level'].'</td>
		<td class="estilo1" align="center">'.$chars['XP'].'</td>
        <td class="estilo1" align="center">'.$chars['BP'].'</td>
		<td class="estilo1" align="center">'.GetKDRatio($chars['KillCount'], $chars['DeathCount']).'</td>
	    </tr>';
        $i++;
        }
        echo '</table>';
        }
        echo'</br>
     
        <font class="estilo1" align="center">Mis Clanes:<br>
        <table class="errorbox" width="350" align="center">
	    <tr>
        <td align="center" class="estilo1">Emblema del clan</td>
        <td align="center" class="estilo1">Nombre del clan</td>
		<td align="center" class="estilo1">Lider del clan</td>
		<td align="center" class="estilo1">Rango del clan</td>

	    </tr>';
        $query2 = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."' ORDER BY CharNum ASC");
        if (mssql_num_rows($query2) > 0){
        while ($chars2 = mssql_fetch_assoc($query2)){


        $clanq = mssql_query_logged("SELECT * FROM ClanMember WHERE CID = '".clean($chars2['CID'])."'");
            if (mssql_num_rows($clanq) != 0){
            $clanq2 = mssql_fetch_assoc($clanq);
                if($clanq2['Grade'] == 9){
                $rango = "Member  ";
                $admin = "No";
                }elseif($clanq2['Grade'] == 2){
                $rango = "Admin";
                $admin = "No";
                }elseif($clanq2['Grade'] == 1){
                $rango = "Master";
                $clid = $clanq2['CLID'] + 1990;
                $cid = $clanq2['CID'] + 2000;

                }else{
                $rango = "Error";
                }
            $claninfoq = mssql_query_logged("SELECT * FROM Clan WHERE CLID = '".clean($clanq2['CLID'])."'");
            $claninfo = mssql_fetch_assoc($claninfoq);

            $emblemurl = $claninfo['EmblemUrl'];
            if ($emblemurl == ''){
                $emblemurl = '<IMG SRC="images/no_emblem.png" WIDTH=50 HEIGHT=50>';
            }else{
                $emblemurl = '<img width="50" height="50" src="http://127.0.0.1/'.$emblemurl.'">';
                }

                echo '<tr>
                <td align="center" valign="center">'.$emblemurl.'</td>
                <td align="center" valign="center">'.$claninfo['Name'].'</td>
		        <td align="center" valign="center">'.FormatCharName($chars2['CID']).'</td>
		        <td align="center" valign="center">'.$rango.'</td>
             
	           </tr> ';
        }}}
?></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table>
									</form>
									</div>
								  </td>
								</tr>
						  </table>
						</div>
					  <p align="center"></td>
						<td width="205" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
					  </td>
					</tr>
</table>