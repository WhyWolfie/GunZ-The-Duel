<?
header("Location: http://foros.razergamers.net/");
?>