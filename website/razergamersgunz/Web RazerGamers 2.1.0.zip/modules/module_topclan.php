<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style2 {
	font-size: 9px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
.style3 {font-family: Arial, Helvetica, sans-serif}
.style6 {color: #000000}
.style7 {color: #333333}
-->
</style>

<table border="0" style="border-collapse: collapse" width="65%">
					<tr>
						<td width="200" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
					  </p></td>
					  <td width="550" valign="top"><table width="550" height="747" background="../img/topclan_bg.png">
                        <tr>
                          <td height="741"><table border="0" align="center" style="border-collapse: collapse; background-image: url(''); background-repeat: no-repeat; background-position: center top">
											<tr>
												<td width="8" height="21">&nbsp;</td>
												<td width="55" height="21" valign="bottom">
												<div align="center">
													<div align="center" class="style6"><span class="style2">
										      Ranking</span></div></td>
												<td width="36" height="21" valign="bottom">
												<div align="center">
											  <div align="center" class="style6"><span class="style2">Emblem</span></div></td>
												<td width="94" height="21" valign="bottom">
												<div align="center">
													<div align="center" class="style6"><span class="style2">
										      Nombre del Clan</span></div></td>
												<td width="96" height="21" valign="bottom">
												<div align="center">
											  <div align="center" class="style6"><span class="style2">L�der</span></div></td>
												<td width="65" height="21" valign="bottom">
												<div align="center">
											  <div align="center" class="style6"><span class="style2">Win/Losses</span></div></td>
												<td width="86" height="21" valign="bottom">
												<div align="center">
											  <div align="center" class="style6"><span class="style2">Win %</span></div></td>
												<td width="48" height="21" valign="bottom">
												<div align="center">
													<div align="center" class="style6"><span class="style2">
										      Puntos</span></div></td>
												<td width="14" height="21">&nbsp;</td>
											</tr>
											<tr>
												<td width="8">&nbsp;
												  <p>&nbsp;</p>
												<p>&nbsp;</p>
											  <p></td>
											  <td colspan="7" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="102%">
														<tr>
															<td width="64"><div align="center"></div></td>
															<td width="25"><div align="center"><span class="style6"></span></div></td>
															<td width="112"><div align="center"><span class="style3"><span class="style6"></span></span></div></td>
															<td width="57"><div align="center"><span class="style3"><span class="style7"></span></span></div></td>
															<td width="108"><div align="center"><span class="style3"><span class="style7"></span></span></div></td>
															<td width="45"><div align="right"><span class="style3"><span class="style7"></span></span></div></td>
															<td width="63"><div align="center"><span class="style3"><span class="style7"></span></span></div></td>
														</tr>
                                                <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Point DESC";
                                                                }

                                                                else
                                                                {
                                                                    echo '
                                                                <tr>
                                                                    <td width="528" colspan="5">
                                                                    <p align="center">
                                                                    No hay datos</td>
                                                                </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if( $search == 0 )
                                                        {
                                                            switch( clean($_GET['page']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 20 AND Ranking <= 40";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 40 AND Ranking <= 60";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 60 AND Ranking <= 80";
                                                                break;
                                                                case "5":
                                                                    $ranks = "Ranking > 80 AND Ranking <= 100";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                            }
                                                            $res = mssql_query_logged("SELECT TOP 50 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) AND $ranks ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                       if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count = 1;
															
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "noemblem.jpg" : $clan->EmblemUrl;
                                                        $clanrank .= '
                                                        <tr>
															<td width="59" align="center">
															<b>'.$count.'</b></td>
															<td width="43" align="center">
															<div align="center">
													        <img src="http://gunz.razergamers.net/emblem/upload/'.$clanemburl.'" width="34" height="30" style="border: 1px solid #000000"></td>
															<td width="99" align="center">
															'.$clan->Name.'</td>
															<td width="93" align="center">
															'.GetCharNameByCID($clan->MasterCID).'</td>
															<td width="82" align="center">
															'.$clan->Wins . "/" . $clan->Losses.'</td>
															<td width="92" align="center">
															'.GetClanPercent($clan->Wins, $clan->Losses).'</td>
															<td width="69" align="center">
															'.$clan->Point.'</td>
														</tr>';
														$count++;
                                                            }
                                                        }else{
                                                        $clanrank = '
														<tr>
															<td width="537" align="center" colspan="7">
															No data</td>
														</tr>';
                                                        }
                                                echo $clanrank;
                                                     ?>
													</table>
											    </div>
                                                </td>
												<td width="14">&nbsp;</td>
											</tr>
						  </table></td>
                        </tr>
                      </table></td>
  </tr>
</table>
					 					  </td>
					</tr>
</table>
</td>