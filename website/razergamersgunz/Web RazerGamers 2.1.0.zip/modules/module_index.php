<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style1 {
	font-size: 9px;
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}
.style7 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; }
.style8 {font-family: Arial, Helvetica, sans-serif}
-->
</style>

<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onload="MM_preloadImages('img/menurg.png','img/Descargas01.png')"><table border="0" style="border-collapse: collapse" width="70%">
					<tr>
						<td width="200" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
						</p></td>
						<td width="609" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
								  <td height="798" valign="middle"><table width="603" height="575">
                                    <tr>
                                      <td width="595" height="569" valign="top" background="img/demo.png"><table width="591">
                                        <tr>
                                          <td width="583" height="35">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td height="246" valign="top"><table width="583" height="247">
                                            <tr>
                                              <td width="324" height="241"><table width="351" height="238" align="center">
                                                <tr>
                                                  <td width="338" height="226"> &nbsp;&nbsp; 
                                                    <iframe width="318" height="226" src="http://www.youtube.com/embed/ygOW7LZLvVM" frameborder="0" allowfullscreen></iframe>
                                                    <div align="left"></div>
                                                  <div align="center"></div></td>
                                                  <td width="10">&nbsp;</td>
                                                </tr>
                                              </table></td>
                                              <td width="243" valign="top"><table width="209">
                                                <tr>
                                                  <td width="201" height="81"><table width="200" border="0">
            <tr>
              <th width="1" scope="col">&nbsp;</th>
              <th width="60" align="left" class="style1 Estilo8" scope="col">RazerGunz</th>
              <th width="43" scope="col" class="Estilo1"><span class="style1 Estilo8">
                <?php

//Total Players
$query = mssql_query("SELECT * FROM ServerStatus"); 
$row = mssql_fetch_row($query); 
$players = $row[1]; 
echo "$players / 1000"; 

?>
              </span></th>
              <th width="1" scope="col">&nbsp;</th>
              <th width="50" scope="col">
                <span class="style7 Estilo8">
                <? 
$ip = "127.0.0.1"; 
$port = "6000"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1" face="verdana">Apagado</font>'; 
else{ 
echo '<font color="#00FF00" size="1" face="verdana">En Linea</font>'; 
fclose($sock); 
} 
?>
                </span></th>
              <th width="19" scope="col"><span class="style8"></span></th>
            </tr>
          </table></td>
                                                </tr>
                                                

                                              </table>
                                              <p><a href="index.php?do=submenu" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Sub Menu RazerGunz','','img/menurg.png',1)"><img src="img/menurg01.png" name="Sub Menu RazerGunz" border="0" id="Sub Menu RazerGunz" /></a></p>
                                              <p><a href="index.php?do=descargas" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Descarga RazerGunz','','img/Descargas01.png',1)"><img src="img/Descargas.png" name="Descarga RazerGunz" border="0" id="Descarga RazerGunz" /></a></p></td>
                                            </tr>
                                          </table></td>
                                        </tr>
                                      </table>
                                        <table width="595" height="264">
                                          <tr>
                                            <td width="585" height="55">&nbsp;</td>
                                          </tr>
                                          <tr>
                                            <td height="201"><table width="583">
                                              <tr>
                                                <td width="8">&nbsp;</td>
                                                <td width="559"><table width="95%" height="27" border="0" align="center" class="IndexC" style="border-collapse: collapse">
                                                <?
                                                                $res = mssql_query("SELECT TOP 8 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu">
 <a href="<?=$n['Text']?>"><font size="1" face="Verdana">
 
                                                    <img src="images/inconos/foro_alerta.png" alt="a" width="10" height="10" border="0" /> <?=$n['Title']?>
                                                  </font></a></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                              </tr>
                                            </table></td>
                                          </tr>
                                        </table>                                        </td>
                                    </tr>
                                  </table>
							        <table width="595" height="200" align="center">
                                          <tr>
                                            <td width="10">            
                                            <td width="573" height="10" align="center"><?php include "slide/slide.html"?></td>
                                  </table></td>
								</tr>
							</table>
						</div>					  </td>
					</tr>
</table>
</td>