<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style1 {font-size: 9px; font-family: Arial, Helvetica, sans-serif; }
.style2 {font-size: 9px; font-family: Arial, Helvetica, sans-serif; color: #333333; }
.style6 {font-size: 9px; font-family: Arial, Helvetica, sans-serif; color: #FF0000; font-weight: bold; }
.style7 {font-size: 9px; font-family: Arial, Helvetica, sans-serif; color: #FFFF00; font-weight: bold; }
.style8 {font-size: 9px; font-family: Arial, Helvetica, sans-serif; color: #666666; }
.style10 {font-size: 9px; color: #CC6600; }
.style11 {color: #FFFF00}
.style12 {
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #FF0000;
}
.style13 {color: #000000}
.style14 {font-size: 18px; font-family: Arial, Helvetica, sans-serif; font-weight: bold; color: #FF0000; }
.style15 {
	color: #CC6600;
	font-weight: bold;
	font-size: 9px;
	font-family: "Courier New", Courier, monospace;
}
.style16 {font-family: ROCKSTEADY}
.style17 {font-family: Arial, Helvetica, sans-serif}
-->
</style>

<table border="0" style="border-collapse: collapse" width="62%">
					<tr>
						<td width="200" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
						</p></td>
						<td width="516" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
								  <td height="290" valign="top"><table width="498" height="585" border="1" background="../img/staff_bg.png">
                                    <tr>
                                      <td width="488" height="517" valign="top"><p>&nbsp;</p>
                                        <table width="483" border="1">
                                          <tr>
                                            <td width="119"><div align="center" class="style2">Nombre</div></td>
                                            <td width="222"><div align="center" class="style2">Facebook / Email </div></td>
                                            <td width="120"><div align="center" class="style2">Rangos</div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style15">Jose Barrios </div></td>
                                            <td><div align="center" class="style1"><a href="http://www.facebook.com/JoseDeLourdes">Facebook</a> / <a href="mailto:elmsndeblue@hotmail.es ">elmsndeblue@hotmail.es</a></div></td>
                                            <td><div align="center"><span class="style10">Creador de RazerGunz </span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style6">Ale Zapata </div></td>
                                            <td><div align="center"></div></td>
                                            <td><div align="center" class="Estilo4"><span class="Estilo1">Administrador</span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style6">Real DlaRosa</div></td>
                                            <td><div align="center"><span class="style1"><a href="mailto:elmsndeblue@hotmail.es "></a></span></div></td>
                                            <td><div align="center" class="Estilo4"><span class="Estilo1">Administrador</span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style7">Juan Ignacio P�rez</div></td>
                                            <td><div align="center"><span class="style1"><a href="http://www.facebook.com/JoseDeLourdes"></a></span></div></td>
                                            <td><div align="center" class="style11"><span class="Estilo1">Moderador</span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style7">Life</div></td>
                                            <td><div align="center"><span class="style1"><a href="http://www.facebook.com/JoseDeLourdes"></a></span></div></td>
                                            <td><div align="center" class="style11"><span class="Estilo1">Moderador</span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style7">Kurogane</div></td>
                                            <td><div align="center"><span class="style1"><a href="http://www.facebook.com/JoseDeLourdes"></a></span></div></td>
                                            <td><div align="center" class="style11"><span class="Estilo1">Moderador</span></div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style8">no data </div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                          </tr>
                                          <tr>
                                            <td><div align="center" class="style8">no data</div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                          </tr>
                                          <tr>
                                            <td height="16"><div align="center" class="style8">no data</div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                            <td><div align="center" class="style8">no data</div></td>
                                          </tr>
                                        </table>                                        
                                        <p align="center" class="style12">&nbsp;</p>
                                        <p align="center" class="style12">El staff Fue renovado el dia ( <span class="style13">07/09/2012</span> ) - Equipo de RazerGamers Gunz </p>
                                        <p align="center" class="style12">Cualquier consulta <a href="http://foros.razergamers.net/">ingresa aqui</a>.</p>
                                        <p align="center" class="style12">Tiene errores en la web? <a href="http://foros.razergamers.net/">ingresa aqui</a>. </p>
                                        <p align="center" class="style12">Recuerda que estamos buscando 3 puestos en RazerGamers Gunz..Estad�sticas de lo que necesitamos:

                                          <span class="style13">tiempo en el servidor</span>.
                                          <span class="style13">dise�o gr�fico nivel: profesional</span>.
                                        <span class="style13">Programaci�n web</span>. <span class="style13">C++</span> y todo lo que sea de &quot;GunZ&quot; cualquiero cosa contactate con nosotros desde nuestro foro inicial dejaremos un link donde cada uno de los usuarios ara su post para la postulacion.... saludos.</p>
                                        <p align="center" class="style12">&nbsp;</p>
                                        <p align="center" class="style14"><a href="http://foros.razergamers.net/index.php?board=3.0" class="style16"><span class="style17">CLICK AQUI Y SE ADMIN / MOD</span></a></p></td>
                                    </tr>
                                  </table></td>
								</tr>
							</table>
					  </div>					  </td>
					</tr>
</table>
</td>