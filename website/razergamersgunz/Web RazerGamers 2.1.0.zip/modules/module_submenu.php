<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style6 {font-size: 12px; font-family: Arial, Helvetica, sans-serif; }
.style7 {
	color: #FF0000;
	font-size: 10px;
	font-family: Arial, Helvetica, sans-serif;
	font-weight: bold;
}
-->
</style>

<script type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body><table border="0" style="border-collapse: collapse" width="68%">
					<tr>
						<td width="202" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
					  </p></td>
						<td width="598" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
								  <td height="284"><table width="580" height="304" background="../img/submenu.png">
                                    <tr>
                                      <td width="572" height="298" valign="top"><table width="559" align="center">
                                        <tr>
                                          <td width="542" height="34">&nbsp;</td>
                                          <td width="542">&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td height="69"><div align="center">
                                            <table width="443">
                                              <tr>
                                                <td width="413"><div align="center" class="style7">Esta sitio web tiene nuevos sistema en nuestra web como, recuperar tu personaje de juego, borrar clan de tu personaje y muchos mas...</div></td>
                                              </tr>
                                            </table>
                                          </div></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                        <tr>
                                          <td height="180"><table width="544" align="center">
                                            <tr>
                                              <td width="534"><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"><a href="?do=sign"> RazerGamers Gunz - Firma Dinamica </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=recuperar">RazerGamers Gunz - Recuperar Personaje </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=error">RazerGamers Gunz - Panel usuario (Nuevo) </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=emblem">RazerGamers Gunz - Subir Emblem Clan </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=foro">RazerGamers Gunz - Foro</a> </span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=staff">RazerGamers Gunz - Staff List </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=staff">RazerGamers Gunz - Staff List </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=staff">RazerGamers Gunz - Staff List </a></span></div></td>
                                            </tr>
                                            <tr>
                                              <td><div align="center"><span class="style6"><img src="../images/inconos/registrate.png" width="10" height="10"> <a href="?do=staff">RazerGamers Gunz - Staff List </a></span></div></td>
                                            </tr>
                                            
                                          </table></td>
                                          <td>&nbsp;</td>
                                        </tr>
                                      </table>
                                      </td>
                                    </tr>
                                  </table></td>
								</tr>
							</table>
					  </div>					  </td>
					</tr>
</table>
</td>
<map name="Map" id="Map">
<area shape="rect" coords="311,4,547,56" href="?do=topclan" />
</map>
