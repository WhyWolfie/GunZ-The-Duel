<?
header("Location: index.php?do=individualrank");
die();
?>