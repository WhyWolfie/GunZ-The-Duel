<style type="text/css">
<!--
.Estilo1 {font-size: 9px}
.Estilo2 {color: #CC9900}
.Estilo3 {font-size: 9px; color: #FF0000; }
.Estilo4 {color: #FF0000}
.Estilo5 {color: #00FF00}
.Estilo6 {color: #00FFFF}
.Estilo7 {font-size: 9px; color: #00FFFF; }
.Estilo8 {color: #CCCCCC}
.Estilo9 {font-size: 9px; color: #CCCCCC; }
.Estilo10 {color: #FFFFFF}
.style1 {
	font-size: 9px;
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}
.style7 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; }
.style8 {font-family: Arial, Helvetica, sans-serif}
-->
</style>

<table border="0" style="border-collapse: collapse" width="62%">
					<tr>
						<td width="202" valign="top"><table width="200">
                          <tr>
                            <td><div align="center">
						  <p>
						    <? include "Costados/block_login.php" ?>
                          </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
							<? include "Costados/block_rankuser.php" ?>
						  </div></td>
                          </tr>
                          <tr>
                            <td><div align="center">
                          <p>
                          <? include "Costados/block_rankclan.php" ?>&nbsp;</div></td>
                          </tr>
                        </table>
						<p>&nbsp;</p>
					  </p></td>
						<td width="526" valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="87%" bordercolor="#000000">
								<tr>
								  <td height="333" valign="middle"><table width="506" height="332" align="center">
                                        <tr>
                                          <td width="600" height="326" valign="top"><iframe src="emblem/index.php" name="fxframe" width="500" height="322" align="center" scrolling="Auto" frameborder="0" id="FxFrame"></iframe>�</td>
                                        </tr>
                                  </table>
								  �</td>
								</tr>
						  </table>
						</div>					  </td>
					</tr>
</table>
</td>