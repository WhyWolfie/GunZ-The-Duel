<?php
SetTitle("RazerGamers Gunz - Clan Informacion");
?><style type="text/css">
<!--
body,td,th {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9px;
	color: #FFFFFF;
	font-weight: bold;
}
.Estilo1 {font-size: 10px}
.Estilo2 {color: #FF0000}
.Estilo5 {color: #00FF00; }
.Estilo6 {
	color: #FF0000;
	font-size: 10px;
	font-style: italic;
}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('../images/boton_donar02.png')">
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Clan Informacion</font></b></td>
							  </tr>
								<tr>
									<td>
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="506" height="419">
                                        <tr>
                                          <td width="600" height="85"><div align="center"><img src="../images/imagenes_nuevas/clan_emblem.png" alt="promociones" width="498" height="83" border="0" /></div></td>
                                        </tr>
                                        <tr>
                                          <td height="326" valign="top"><iframe src="modules/clanpanel.php" name="fxframe" width="500" height="322" align="center" scrolling="Auto" frameborder="0" id="FxFrame"></iframe>&nbsp;</td>
                                        </tr>
                                      </table>
									</form>
									</div>
								  </td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
</table>
<map name="Map">
  <area shape="rect" coords="212,18,502,52" href="?do=event">
<area shape="rect" coords="348,376,501,415" href="http://foro.muvenezuela.com/showthread.php?2664-Evento-Marzo-Abril-2012."><area shape="rect" coords="63,353,146,375" href="#">
</map>