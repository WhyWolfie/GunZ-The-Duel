<?

@session_start();

//Configurar Config Con Tus datos!!

$_MSSQL[Host]               = "TU-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "sadasd";
$_MSSQL[DBNa]               = "GunzDB";

$r = mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mssql_select_db($_MSSQL[DBNa], $r);

?>