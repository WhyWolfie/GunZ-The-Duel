<?php
SetTitle("Razer GunZ - 2.0 - STAFF LISTA ACTUALIZADA");
?>
<style type="text/css">
<!--
.Estilo12 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #00FF00; }
.Estilo14 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #FF0000; }
.Estilo16 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #0033FF; }
.Estilo18 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #CC6600; }
.Estilo20 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #FFFFFF; }
.Estilo24 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #FFFF00; }
.Estilo26 {font-family: Arial, Helvetica, sans-serif; font-size: 9px; color: #00FFFF; }
-->
</style>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<strong><font size="2" face="Tahoma">Staff Lista </font></strong></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="500" border="0">
                                        <tr>
                                          <td><div align="center">Staff Lista - RazerGunZ 2.0 </div></td>
                                        </tr>
                                        <tr>
                                          <td><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
.Estilo1 {font-family: Geneva, Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body>
<div align="center">
  <p align="center"><strong>VENEZUELA</strong><br />
    <br />

Banco: Banesco<br />
Nombre: Osiris Benitez<br />
N&ordm; de Cuenta: 0134 0087 39 0871041849<br />
Cedula: 7567261<br />
Corriente<br />
  <img src="http://www.viajes.es/america/venezuela/venezuela-bandera-de-venezuela-i2.jpg" width="243" height="113" /></p>
  <p align="center"><br />
    <strong>PERU</strong><br />

    <br />
Banco: Banco de Credito de Peru (BCP)<br />
Nombre: Franklin Rivasplata Padilla<br />
N&ordm; de Cuenta: 191-20198578-0-02<br />
<img src="http://3.bp.blogspot.com/_zQ8aIjl9w4Y/TE9id9q6rGI/AAAAAAAADv0/yJPR0Hapkcg/s1600/BanderaPeru.jpg" width="268" height="145" /></p>
  <p align="center"><br />
    <strong>COLOMBIA</strong><br />
    <br />

Banco: Bancolombia<br />
Nombre: Hernando Molina<br />
Cuenta ahorros: 088 266 654 41</p>
  <p align="center"><img src="http://www.losmejoresdestinos.com/destinos/cartagena/bandera_colombia.gif" width="249" height="128" /></p>
  <p align="center">&nbsp;</p>
  <p align="center"><strong>ARGENTINA</strong></p>
  <p align="center"><img src="http://3.bp.blogspot.com/_dd0CQcGBGqw/S-9iJvn3VMI/AAAAAAAAACM/km4l0tLF_8Y/s1600/Bandera_Argentina.gif" width="268" height="124" /></p>
  <p align="center"><META http-equiv=Content-Type content="text/html; charset=windows-1252">

	
<BODY>
  <div align="center">
    <table width="45%" align="center" style="border:1px solid #999999;">
      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td>
          <table bgcolor="#EFEFEF" width="90%" align="center" style="border:1px solid #999999;">

            <tr>
              <td align="center" height="10"></td>
    </tr>
            <tr>
              <td align="center" style="font-size:14px; font-weight:bold; color:#999999; font-family:Arial, Helvetica, sans-serif;">Ingrese el Monto a Donar a RazerGunZ 1.5 </td>
    </tr>
            <tr>
              <td align="center" height="10"></td>

    </tr>
            <tr>
              <td width="100%" align="center">
                <FORM action=https://www.dineromail.com//Shop/Shop_Ingreso.asp method=post>
                  <INPUT type=hidden value='Compra' name=NombreItem>
                  <input type ="hidden" name="TipoMoneda" id="TipoMoneda" value="1">
                  <INPUT name=PrecioItem > 
                  <INPUT type=hidden value= 1567907 name=E_Comercio> 
                  <INPUT type=hidden value=- name=NroItem> 
                  <INPUT type=hidden value=http:// name=DireccionExito> 
                  <INPUT type=hidden value=http:// name=DireccionFracaso> 
                  <INPUT type=hidden value=1 name=DireccionEnvio> 
                  <INPUT type=hidden value=1 name=Mensaje>

                  <input type='hidden' name='MediosPago' value='4,5,6,14,18,15,16,17,2,7,13'> 
                  <br><br><INPUT type=image 
	 	alt="Pagar con DineroMail" 
		src="https://argentina.dineromail.com/imagenes/botones/donar-medios_c.gif" 
		border=0 
		name=submit>
              </FORM>	</td>
	    </tr>
        </table>	</td>
      </tr>
      <tr>
        <td height="20"></td>

    </tr>
    </table>
  </div>
<p align="center" class="qwasda"><br>
</p>
<p align="center" class="Estilo1 Estilo1">Mas Informacion Sobre Como Donar comunicarse con</p>
<p align="center" class="Estilo1">&quot;foxdnetworks@hotmail.com.ar&quot;</p>
<p align="center" class="Estilo1">Atte: RazerGunz Staff </p>
<p align="center" class="Estilo1">Instrucciones.<br>
</p>

<p align="center" class="Estilo1">1.- Colocar la cantidad y Dar Click al Boton Donar.</p>
<p align="center" class="Estilo1">2.- Seleccionar la Forma de Pago &quot; Pagos en Efectivo &quot; ( Rapi Pago )</p>
<p align="center" class="Estilo1">3.- Rellenar Los Datos &quot; Nombre , Apellido , Sexo , Telfono , Numero de Documento , Correo &quot;</p>
<p align="center" class="Estilo1">4.- Luego de Rellenar los Datos Darle el Boton Pagar e Imprimir el Recibo de Barras </p>
<p align="center" class="Estilo1">5.- Ir a una taquilla de Rapi Pago Y Pagar la Boleta </p>
<p align="center" class="Estilo1">6.- Scanear el Recibo de la boleta pagada y Enviarle Por Correo a &quot;foxdnetworks@hotmail.com.ar&quot;<br>

Especificando Monto de la donacion, id de cuenta y fecha de pago.</p>
</BODY>
</HTML>&nbsp;</p>
</div>
</body>
</html>
&nbsp;</td>
                                        </tr>
                                      </table>
									</form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>