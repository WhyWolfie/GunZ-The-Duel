<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo1 {color: #090912}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
<table background="images/md_cr.png"  width="174" height="174" >
<tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="14" rowspan="6">&nbsp;</td>
        <td height="33" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos &laquo; </div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="7" align="left">
		<img border="0" src="../images/mis_arrow.jpg" width="2" height="1"></td>
  															<td width="77" align="left">
         <?=$user['Name']?></td>
       <td width="27" align="left">
           <?=$user['Point']?></td>
      </td>
      </tr>
      <?}}?>
    </table>    <td height="39"></tr>
</table>
<p><a href="index.php?do=signature"><img src="../images/signature.png" width="167" height="147" /></a></p>

<p>&nbsp;</p>