﻿

<body topmargin="50" leftmargin="50" rightmargin="50" bottommargin="50" marginwidth="50" marginheight="50" style="background: #000000 url('') no-repeat center top">

 
<div id="" align="everywhere">


	

<everywhere> <a href="http://snow.sytes.net:8080"blank" src="<a href="><img src="http://i1071.photobucket.com/albums/u511/GersonDay/Snow/header.png" border="0" alt="Snow Gunz photo header.png"/></a>

 <div align="everywhere">
    <div align="everywhere">
      <table width="500" border="0">
        <tr>
          <th width="100" scope="good"><marquee>
           <span class="Estilo1"><font color="red">Web Elaborada y Cerrada :D! Att:Gerson Araujo  ~SnowGamerZ...
          </marquee></th>
        </tr>
      </table>


<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #ff03f url('') no-repeat center top">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="100%">
		<tr>


<html>

<head>
<title>Privado By:Gerson Araujo</title>
</head>

<body>
<p>SnowGamerz Off</p>
</body>

</html>
