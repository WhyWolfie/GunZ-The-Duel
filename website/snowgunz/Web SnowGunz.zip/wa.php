<?php
if( !session_start() )
{
    session_start();
}
require "config.php";
include "functions.php";
$langfile = "lang/{$_CONFIG[Language]}.php";
include $langfile;

$connection = connect();
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>GunZ Admin Panel v3 - By Emisand</title> 

<style type="text/css">
<!--
body,td,th {
	color: #FFFFFF; font-family:Trebuchet MS
}
a {
	color: #FFFFFF; font-family:Trebuchet MS
}
body {
	background-color: #171717;
}
input {
    border: 1px solid #A0A0A4;
    color: #000000;
    background: #CCCCCC;
    font-family:Trebuchet MS;
    font-size: 10pt
}
-->
</style>
</head>

<body topmargin="0">
<?php

if( $_SESSION['AID'] == "" )
{
    if( isset($_POST['login']) )
    {
        login();
    }
    else
    {

?>
    <center>
    <p><b>Gunz Admin Panel</b></p>
    <form name="login" method="POST" action="index.php">
    <?php showmessage(); ?>
        <table width="30%" border="1" style="border-collapse: collapse" id="login">
            <tr>
                <td colspan="2" align="center"><b><?php printf( $_STR[Login0] ); ?></b></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td width="40%" align="center"><?php printf( $_STR[Login1] ); ?>:</td>
                <td align="center"><input type="text" name="userid" /></td>
            </tr>
            <tr>
                <td align="center"><?php printf( $_STR[Login2] ); ?>:</td>
                <td align="center"><input type="password" name="password" /></td>
            </tr>
            <tr>
                <td colspan="2"></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <input type="submit" name="login" value="<?php printf( $_STR[Login3] ); ?>" />
                </td>
            </tr>
        </table>
    </form>
    </center>
