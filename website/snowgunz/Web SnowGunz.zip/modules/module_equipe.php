<center>

<b><h3>HeadGamer - STAFF</b></h3>

<br><br>

<span style="color:cyan; background: transparent url(http://tinyurl.com/outgum)"><b>Fundadores:</b></span></a><br><br>

<font color="cyan">Afernin -<font color="cyan"></font> Fundador Geral <br><br>
<font color="cyan">David- </font> Fundador Geral<br><br>


<span style="color:red; background: transparent url(http://tinyurl.com/outgum)"><b>Games Masters:</b></span></a><br><br>


<font color="red"> -</font> Disenador & Soporte<br><br>
<font color="red"> -</font> Eventos & beador<br><br>
<font color="red"> -</font> Administrador<br><br>

<span style="color:red; background: transparent url(http://tinyurl.com/outgum)"><b>Games Masters:</b></span></a><br><br>


<font color="lime">aun Nadie -</font> Moderador F�rum Trial </div></td><br>
<br>
</font>

</center>

<html>
<head>
<title>FinalGunz</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.Estilo4 {font-size: 36px; font-weight: bold; color: #999999; font-family: Verdana, Arial, Helvetica, sans-serif; }
.Estilo5 {color: #FFFFFF; font-size: 12px; }
-->
</style>
</head>
<body bgcolor="#000000" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table id="Tabla_01" width="620" height="468" border="0" cellpadding="0" cellspacing="0"><tr><td rowspan="3"><table id="Tabla_" width="620" height="507" border="0" cellpadding="0" cellspacing="0">
					