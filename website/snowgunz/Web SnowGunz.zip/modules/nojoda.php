﻿<?
SetTitle("Snow Gunz - Donacion via SMS");

?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.Estilo1 {
	color: #FF0000;
	font-weight: bold;
	font-style: italic;
}
.Estilo2 {color: #FFFFFF}
.Estilo3 {
	color: #999999;
	font-weight: bold;
}
.Estilo4 {color: #CCCCCC}
.sub {
	color: #F90;
	font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
	font-size: 16px;
}
.sub2 {
	color: #FC0;
	font-family: "Courier New", Courier, monospace;
	font-size: 12px;
}

-->
</style>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar a Snow GunZ</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left; font-family: Georgia, 'Times New Roman', Times, serif; font-size: 14px;" id="result_box" dir="ltr">
													
													<p>&nbsp;</p>
												  <p><span class="Estilo3">Snow Gunz  Les Da Las Gracias a las donaciones que hacen nuestros usuarios.&nbsp;<br />
  Para mantener los gastos de Snow GunZ, por lo que agradecemos su donaci&oacute;n</span><br />
												    <br />
												    <span class="Estilo2"><strong>DONACI&Oacute;N RAPIDA VIA SMS:</strong><br />
											      Por cada mensaje enviado, seras acreditado con 50 DCoins </span></p>
													<ul>
													  <li class="Estilo2">
												      <p class="Estilo2"> Primero debes eligir el país al que pertenescas enviar la palabra que te pide al numero tal . y donde te dice &quot;Tu AID&quot; vas a poner tu AID de tu cuenta que lo encuentras en tu panel cuando te logueas.                                                                                                            
			<center>								      <p class="Estilo2"><img src="images/bcp/02.png" width="170" height="260" />                            </p></center>                                                                                													  </li>
													  <li class="Estilo2">Ejemplo de venezuela <span class="sub">REM SNOWGUNZ</span> "Tu AID"sin las comillas. es importante escribir las palabra tal y cual "REM SNOWGUNZ" (SIN COMILLAS). luego Tu AID que sera en <span class="sub">numero </span>  y envias.</li>
													  <li class="Estilo2">Si el envio como fue correcto <span class="sub">se le enviara 50 DCoin Automaticamente rapido y facil sin nada de esperas.</span></li>
												  </ul>
													<p>&nbsp;</p>
													<ul>
													  <li class="Estilo2">Gracias por Donar espere 1min y se le hara la entrea de sus Dcoins.</li>
													  

													    
												      <iframe src="<iframe src="http://iframes.recursosmoviles.com/index.php?wmid=5266&cid=19255" width="440" height="268" marginwidth="0" marginheight="0" scrolling="no" frameborder="0" allowTransparency="true" ></iframe>"
												  </ul>
													</p>
													<p>
												
													  <br>
													  <span class="sub"></span></p>
										    <p align="center" class="sub"></p>
										    <p align="center" class="sub"></p>
											    <p align="center" class="sub"></p>
													<p align="center">&nbsp;</p>
												  <center>
												    <table width="500" border="0">
                                                      <tr>
                                                     <li class="sub"> Soporte Snow GunZ: Snowggz@hotmail.com</li>
                                                      </tr>
                                                    </table>
												  </center>
												  <p>&nbsp;</p>
                                                </div>
                                                <p>
                                                <br />
                                                </p>
                                                </div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<map name="Map" id="Map">
  <area shape="rect" coords="-3,3,178,204" href="/includesbg/index.php" />
</map>