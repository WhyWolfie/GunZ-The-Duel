﻿


  <div align="center">
    <div align="center">
      <table width="554" border="0">
        <tr>
          <th width="548" scope="col"><marquee>
           <span class="Estilo1">Usted no puede estar aquí por favor as clic en la imagen para  regresa a la Web! Att:Big-Satr  ~SnowGamers...
          </marquee></th>
        </tr>
      </table>


<center> <a href="http://snowgamers.sytes.net:8080/index.php?do=index/"blank"><img src="http://i1160.photobucket.com/albums/q497/SnowGZ/header-2.png" <center/>




<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #ff03f url('') no-repeat center top">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="90%">
		<tr>



