<?php
header ("Location: http://snowgamers.sytes.net:8080/index.php?do=ShopBig-Satr");
?>