<head>
<script type="text/javascript">
    function UpdateSignature()
    {
        var cid = document.signature.charlist.value;
        var firma = document.getElementById("firma");
        firma.innerHTML = '<img src="genericsing.php?cid='+ cid + '" />';
        document.signature.forumcode.value = '[URL="http://s2.subirimagenes.com/privadas/previo/thump_826455head.jpg"][IMG]http://s2.subirimagenes.com/privadas/previo/thump_826455head.jpg' + cid + '[/IMG][/URL]';
        document.signature.directlink.value = "http://s2.subirimagenes.com/privadas/previo/thump_826455head.jpg" + cid + "";
    }

</script>
<style type="text/css">
<!--
.Estilo1 {color: #FF0000}
.Estilo2 {color: #00FF00}
-->
</style>
</head>
<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=signature");
    SetMessage("Mensaje del sistema", array("Tienes que estar logueado para utilizar esta funcion"));
    header("Location: index.php?do=login");
    die();
}

SetTitle("SowGamersGunz-Donacion solo Venezuela");

    $qbt01 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");

    if( mssql_num_rows($qbt01) < 1 )
    {
        SetMessage("Mensaje del sistema", array("No tienes personajes"));
        header("Location: index.php");
        die();
    }

?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<strong><font size="2" face="Tahoma">SnowGamersGunz Donate venezuela con super ofertas</font></strong></td>
							  </tr>
								<tr>
									<td bgcolor="#070001">
									<div align="center"><form name="signature" class="Estilo3">
									  <p>Donoaciones por agentes b.o.d con super ofertonas ( solo Venezuela)</p>
									  <p>datos :</p>
									  <p>por 50 Bolivares = 100 Dcoins</p>
									  <p>por 55 Bolivares = 170 Dcoins</p>
									  <p>por 60 Bolivares = 250 DCOINS</p>
									  <p>por 65 Bolivares = 300Dcoins</p>
									  <p>por 70 Bolivares = 370 Dcoins</p>
									  <p>POR 75 Bolivares = 450 DCOINS</p>
									  <p>POR 80 Bolivars  = 550 DCOINS</p>
									  <p>POR 80 bolivares =680 DCOINS</p>
									  <p class="Estilo2">POR 100 bolivares 800 DCOINS</p>
									  <p>DEPOSITO A </p>
									  <p>ANDREA ARENA  </p>
									  <p>NUMERO DE CUENTA : </p>
									  <table width="500" border="1">
                                        <tr>
                                          <th scope="col"> 0116-0125-16-0196742609 </th>
                                        </tr>
                                      </table>
								      <p><a href="http://www.blastergunz.com/includesbg/index.php">UNA VES ENVIADO CLICK AKI PARA LLENAR UN FORMULARIO</a></p>
									  <p>APUNTARLO CORRECTAMENTE Y IR A UN AGENTE BCP Y DECIRLE EL NOMBRE A QUIEN VA SER DEPOSITADO Y EL NUMERO DE CUENTA ( SIN EQUIVOCARSE) GRACIAS.</p>
									  <p>PUEDEN DEPOSITAR DE 10 A 99 A&Ntilde;OS </p>
									  <p>NO ES NECESARIO SER MAYOR DE EDAD PARA PARA DEPOSITAR .</p>
									  <p>&nbsp;</p>
									  <p>&nbsp;</p>
									</form>
									</div>
								  </td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>