<?
header("Location: index.php?do=download");
?>