<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=buycolorname");
    SetMessage("Message from System", array("You must be logged in to buy Color name"));
    header("Location: index.php?do=login");
    die();
}
$query00 = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION['AID']}' AND CharNum != '-1' AND Name != '' ");
  // Have characters?
  if (mssql_num_rows($query00) < 1) {
    SetMessage("Message from System", array("You don't have any character!"));
    header("Location: index.php");
    die();
  }

SetTitle("SnowGunz - Buy Color Name");

 if (isset($_POST['submit'])) {
      $aid = clean($_SESSION['AID']);
      $grade = clean($_POST['color']);
      $price = intval(50);
      
      // Color is valid? 
      switch($grade){
        case 10;
        $grade = 4;
        break; 
		case 11;
        $grade = 3;
        break;
		case 12;
        $grade = 5;
        break;
		case 13;
        $grade = 6;
        break;
		case 14;
        $grade = 7;
        break;
		case 15;
        $grade = 8;
        break;
		case 16;
        $grade = 9;
        break;		
        default:
        SetMessage("Message from System", array("The color id is invalid!"));
        header("Location: index.php?do=shopdonator");
        die();      
      }
      if (!is_numeric($grade)) {
          SetMessage("Message from System", array("Invalid Color name!"));
          header("Location: index.php?do=buycolorname");
          die();
      }
      // Color empty? useless
      elseif (empty($grade)) {
          SetMessage("Message from System", array("You don't select a Color name!"));
          header("Location: index.php?do=buycolorname");
          die();
      } else {
          // Suficients Donatorcoins ?
          $query = mssql_query("SELECT DonatorCoins FROM Account(nolock) WHERE AID = '$aid'");
          $info = mssql_fetch_assoc($query);
          $updatecoins = $info['DonatorCoins'] - $price;
          
          if ($updatecoins < 0) {
          SetMessage("Message from System", array("You don't have suficient DonatorCoins"));
          header("Location: index.php");
          die();
          } else {
              // Update 
              $addcolor = mssql_query_logged("UPDATE Account SET ugradeid = '$grade', DonatorCoins = '$updatecoins' WHERE AID = '$aid'");
                       
              if ($addcolor) {
                  SetMessage("Message from System", array("Succesfully purchased color name!"));
                  header("Location: index.php");
                  die();
              } else {
                  SetMessage("Message from System", array("There were problems with the server, try later!"));
                  header("Location: index.php");
                  die();
              }
          }
      }
  } else {
      // Get some info
     
      $query01 = mssql_query("SELECT DonatorCoins FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
      $infoacc = mssql_fetch_object($query01);

  }
?>
<style type="text/css">
OPTION {
    background-color:#666;
}
OPTION.rojo {
    color:#F00;
    font-weight:bold;
}
OPTION.Rosado {
    color:#FF009D;
    font-weight:bold;
}
OPTION.Azul {
    color:#00C8FF;
    font-weight: bold;
}
OPTION.Amarillo {
    color:#EAFF00;
    font-weight: bold;
}
OPTION.Roscuro {
    color:#CD05A8;
    font-weight: bold;
}
OPTION.Amoscuro {
    color:#D5D81B;
    font-weight: bold;
}
OPTION.Gris {
    color:#8B8B8B;
    font-weight: bold;
}
</style>
<table border="0" style="border-collapse: collapse" width="100%">
                    <tr>
                        <td width="183" valign="top">
                        <div align="center">
                            <? include "blocks/block_rankingu.php" ?>
                        </div>
                        </td>
                        <td valign="top">
                        <div align="center">
                            <table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
                                <tr>
                                    <td background="http://forum.ragezone.com/images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
                                    <div align="center">
                                        <b><font face="Tahoma" size="2">Comprar Nombre a Color</font></b></td>
                                </tr>
                                <tr>
                                    <td bgcolor="#2C2A2A">
                                    <div align="center"><form method="POST" action="index.php?do=buycolorname" name="buycolorname">
                                        <table border="0" style="border-collapse: collapse" width="414" height="100%">
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="315" colspan="3">&nbsp;</td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="315" colspan="3">You can buy a Color name for Gunz.<br />
El Precio es 60 Donator coins.</td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="315" colspan="3"><br /></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="181">
                                                <p align="right">Seleciona el Color</td>
                                                <td width="13">&nbsp;</td>
                                                <td width="190">
                                            <select name="color" class="cero">
                                <option selected value="">Selecionar Color</option>
								<option class="Rosado" value="10">Rosado</option>
								<option class="Azul" value="11">Azul Claro</option>
								<option class="Amarillo" value="12">Amarillo Oscuro</option>
								<option class="rojo" value="13">Rojo Claro</option>
								<option class="Roscuro" value="14">Rosado Claro</option>
								<option class="Amoscuro" value="15">Amarillo Claro</option>
								<option class="Gris" value="16">Gris</option>
								
                            </select></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="315" colspan="3">&nbsp;</td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="181">
                                                <p align="right">Price:</td>
                                                <td width="13">&nbsp;</td>
                                                <td width="190"><b>60 DonatorCoins</b></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="181">
                                                <p align="right">Actual Donatorcoins:</td>
                                                <td width="13">&nbsp;</td>
                                                <td width="190"><b><?=$infoacc->DonatorCoins?></b></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="181">
                                                <p align="right">DCoins remaining::</td>
                                                <td width="13">&nbsp;</td>
                                                <td width="190"><b><?=$infoacc->DonatorCoins-60?></b></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                          
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td width="315" colspan="3">&nbsp;</td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
                                                <td colspan="3">
                                                <p align="center">
                                                <input type="submit" value="Buy Color Name" name="submit"></td>
                                                <td width="11">&nbsp;</td>
                                            </tr>
                                        </table></form>
                                    </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <p align="center">&nbsp;</td>
                        <td width="171" valign="top">
                        <div align="center">
                            <? include "blocks/block_login.php" ?>
                        </div>
                        </td>
                    </tr>
                </table>