
<?
SetTitle("SnowGamersGunZ - Ranking Individual");
?><head>
<meta http-equiv="Content-Language" content="es" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
</head>


<table border="0" style="border-collapse: collapse" width="778">
					<tr>
						<td width="164" style="background-image: url('images/md_content_menu.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="164">
								<tr>
									<td width="14" height="36">&nbsp;</td>
									<td width="127" height="36">&nbsp;</td>
									<td width="17" height="36">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">
									<img border="0" src="images/btn_individualrank_on.jpg" id = "76176img" width="131" height="21" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_individualrank_on.jpg')" /></td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">
									<a href="index.php?do=clanrank">
									<img border="0" src="images/btn_clanranking_off.jpg" id="7816img271" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img271',/*url*/'images/btn_clanranking_on.jpg')" /></a></td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127"><a href="index.php?do=halloffame"><img src="images/btn_halloffame_off.jpg" alt="" border="0" id="hall" onmouseover="FP_swapImg(1,1,/*id*/'hall',/*url*/'images/btn_halloffame_on.jpg')" onmouseout="FP_swapImgRestore()" /></a>									</td>
								  <td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">&nbsp;</td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">&nbsp;</td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">&nbsp;</td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">&nbsp;</td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="158" colspan="3">&nbsp;</td>
								</tr>
								</table>
						</div>
						</td>
						<td width="4">&nbsp;<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<p></p></td>
						<td width="599" valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-image: url('images/content_title_ranking2.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;<p>&nbsp;</p>
									<p></p></td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="individualrank" />
                                    <p align="center">
                                    &nbsp;&nbsp;&nbsp;
                                    </p>
					                </form>
                                    </td>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
									<img border="0" src="images/mis_rankinglegend.jpg" width="563" height="30" /></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;
									</td>
								</tr>
								<tr>
									<td style="background-repeat: no-repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse; background-image: url('images/content_ranking_data_bg.jpg'); background-repeat: no-repeat; background-position: center top" width="573">
											<tr>
												<td width="14" height="21">&nbsp;</td>
												<td width="60" height="21" valign="bottom" align="center">
												<div align="center">
													<font face="Tahoma"><b>
													Ranking</b></font></td>
												<td width="132" height="21" valign="bottom" align="center">
												<b><font face="Tahoma">Nombre 
												del Personaje</font></b></td>
												<td width="43" height="21" valign="bottom" align="center">
												<b><font face="Tahoma">Nivel</font></b></td>
												<td width="149" height="21" valign="bottom" align="center">
												<b><font face="Tahoma">
												Experiencia</font></b></td>
												<td width="148" height="21" valign="bottom" align="center">
												<font face="Tahoma"><b>Kill / </b></font>
												<b><font face="Tahoma">%</font></b></td>
												<td width="13" height="21">&nbsp;</td>
											</tr>
											<tr>
												<td width="14">&nbsp;</td>
												<td width="538" colspan="5" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="538">
														<tr>
															<td width="59">&nbsp;</td>
															<td width="132">&nbsp;</td>
															<td width="43">&nbsp;</td>
															<td width="149">&nbsp;</td>
															<td width="145">&nbsp;</td>
														</tr>
                                                        
				 <!-- Codigo by Diosz - CryMore - CrazY Y Arreglado por Sacker , Todos los derechos Reservados -->
																  <?
																  															  
															$res = mssql_query("SELECT TOP 100 * FROM Character a, Account b WHERE a.AID=b.AID AND b.UGradeID !=255 AND b.UGradeID !=254 AND b.UGradeID !=253 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");

                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count = 1;
                                                            while($char = mssql_fetch_object($res))
                                                            {

                                                        ?>
                                                                    <tr>
                                                                        <td width="59" align="center">
                                                                        <b><?=$count?></b></td>
                                                                        <td width="132" align="center">
                                                                        <?=FormatCharName($char->CID)?></td>
                                                                        <td width="43" align="center">
                                                                        <?=$char->Level?></td>
                                                                        <td width="149" align="center">
                                                                        <?=number_format($char->XP, 0, ",", ".")?></td>
                                                                        <td width="145" align="center">
                                                                        <?=GetKDRatio($char->KillCount, $char->DeathCount)?></td>
                                                                    </tr>
                                                                  <?
                                                                  $count++;
                                                                  }
                                                              }
                                                              else
                                                              {
                                                              ?>
                                                                <tr>
                                                                    <td width="528" colspan="5">
                                                                    <p align="center">
                                                                    No data</p></td>
                                                                </tr>
                                                              <?
                                                              }
                                                              ?>
													</table>
												</div>
												</td>
												<td width="13">&nbsp;</td>
											</tr>
									  </table>
									</div>
                                    <?
                                    if( $search == 0 )
                                    { ?>
                                    <p align="center"><a href="#"></a></p>
                                    <?
                                    }
                                    ?>
                                    </td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<p></p></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
				</table>