<div id="ststitle">Meus Personagens:</div><p>
<div id="us">
<?php
$query = mssql_query("SELECT TOP 4* FROM Character WHERE AID = '".$_SESSION['AID']."' AND Name != '' AND DeleteFlag = 0 ORDER BY Level DESC");
if ( mssql_num_rows($query) < 1 ){
echo 'Sem personagens';
}else{
?>
<table border='0' style='border-collapse:collapse' width='458'><tr height='23' style='font-weight:bold;'>
<td align="center">Name</td>
<td align="center">Lvl</td>
<td align="center">Experiencia</td>
<td align="center">Sex</td>
<td align="center">Kills</td>
<td align="center">Deaths</td></tr>
<?
$i = 1;
while ( $i <= mssql_num_rows($query) ){
$chars = mssql_fetch_assoc($query);
?>
<tr style="font-size:11px;"><td align="center" width="70"><?=FormatCharName($chars['CID'])?></td>
<td width="30" align="center"><?=$chars['Level']?></td>
<td width="97" align="center"><?=$chars['XP']?></td>
<td width="43" align="center"><?=Sex($chars['Sex'])?></td>
<td width="66" align="center"><?=$chars['KillCount']?></td>
<td width="80" align="center"><?=$chars['DeathCount']?></td></tr>
<?
$i++;
}?>
</table>
<?
}
?>
		
<div class="logged_dline">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

<b>Meus Clans :</b><p>
<?		
$query2 = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND Name != '' ORDER BY CharNum ASC");
if (mssql_num_rows($query2)){
?>
<table border='0' style='border-collapse: collapse' width='458'><tr height='23' style='font-weight:bold;'>
<td align="center">Clan Name</td>
<td align="center">Clan Leader</td>
<td align="center">Wins</td>
<td align="center">Losses</td></tr>
<?
while ($cha = mssql_fetch_assoc($query2)){

$clanq = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$cha['CID']."'");
if (mssql_num_rows($clanq) != 0){
$clanq2 = mssql_fetch_assoc($clanq);
if($clanq2['Grade'] == 9){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><?=$claninfo['Name']?></td>
<td align="center"><?=FormatCharName($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td></tr>
<?
}
}else
if($clanq2['Grade'] == 1){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><?=$claninfo['Name']?></td>
<td align="center"><?=FormatCharName($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td></tr>
<?
}
}else
if($clanq2['Grade'] == 2){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><?=$claninfo['Name']?></td>
<td align="center"><?=Char($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td></tr>
<?
}
}
}
}
}
?>
</table>

</div>
<p>
  </p>
</p>
<p>&nbsp;</p>
