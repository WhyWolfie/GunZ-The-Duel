<?php
if(isset($_POST['cambiar'])){
$pj = clean($_POST['pjs']);
$sex = clean($_POST['sex']);
if(empty($pj) || $sex != 0 && $sex != 1)
{
	msgbox(" Error Inesperado ","index.php");
}
mssql_query("UPDATE Character SET Sex='".$sex."' WHERE AID='".$_SESSION['AID']."' AND CID='".$pj."'");
msgbox("Sexo trocado com sucesso","index.php?do=panel");
}else{
?>
<form name="sex0" method="post">
<div id="title">Trocar Sexo :</div>

<p>&nbsp;</p>
<?php
$q = mssql_query("SELECT * FROM Character WHERE AID ='".$_SESSION['AID']."' AND NAME != '' Order by CharNum ASC");
if(mssql_num_rows($q))
{
	?><select name="pjs"><?
	while($r = mssql_fetch_object($q))
	{
		?>
        
        <option value="<?=$r->CID?>">
        <?=$r->Name?>
        </option>
        
        <?
	} ?>
    </select>
    <select name="sex">
    <option value="0">Masculino</option>
    <option value="1">Feminino</option>
    </select>
    <br /><br />
    <input type="submit" name="cambiar" value="Trocar Sexo" />
    <?
}else{
	?>
    Voce nao possui personagem
 <? }  ?>
</font>
</form>
<? } ?>