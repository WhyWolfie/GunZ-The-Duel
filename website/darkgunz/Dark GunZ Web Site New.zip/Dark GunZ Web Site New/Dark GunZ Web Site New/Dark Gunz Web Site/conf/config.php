<?php
//Act GunZ Online By Sparrow
$link = mssql_connect("MYHOME-3ED9E6A1\SQLEXPRESS","sa","159482637");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Act GunZ Connected

$DBHost = 'MYHOME-3ED9E6A1\SQLEXPRESS'; //Sparrow SQL
$DBUser = 'sa'; //Your DB User 
$DBPass = '159482637'; //Sparrow Senha 
$DB = 'GunzDB'; //Sparrow GunZ DB 


?>