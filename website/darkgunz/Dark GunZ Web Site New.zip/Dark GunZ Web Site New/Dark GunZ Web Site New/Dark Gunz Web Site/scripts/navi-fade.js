$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav li.home a').append('<div class="hover">Home</div>');
 
 
    $('#top-nav li.home a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.download a').append('<div class="hover">Download</div>');
 
 
    $('#top-nav ul li.download a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.register a').append('<div class="hover">Register</div>');
 
 
    $('#top-nav ul li.register a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.usercp a').append('<div class="hover">UserCP</div>');
 
 
    $('#top-nav ul li.usercp a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.logo a').append('<div class="hover"></div>');
 
 
    $('#top-nav ul li.logo a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.forum a').append('<div class="hover">Forum</div>');
 
 
    $('#top-nav ul li.forum a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.shop a').append('<div class="hover">Item Shop</div>');
 
 
    $('#top-nav ul li.shop a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});

$(document).ready(function () {
 
    //Append a div with hover class to all the LI
    $('#top-nav ul li.rankings a').append('<div class="hover">Rankings</div>');
 
 
    $('#top-nav ul li.rankings a').hover(
         
        //Mouseover, fadeIn the hidden hover class  
        function() {
             
            $(this).children('div').stop(true, true).fadeIn('1000');    
         
        }, 
     
        //Mouseout, fadeOut the hover class
        function() {
         
            $(this).children('div').stop(true, true).fadeOut('1000');   
         
    }).click (function () {
     
        //Add selected class if user clicked on it
        $(this).addClass('selected');
         
    });
 
});