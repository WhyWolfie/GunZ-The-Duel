////////////////////////////////////////////////////////////
// RANKINGS JQUERY
////////////////////////////////////////////////////////////


$(document).ready(function () {

		//set the default location (fix ie 6 issue)
		$('.lava').css({left:$('span.item:first').position()['left']});
		
		$('.item').mousedown(function () {
			//scroll the lava to current item position
			$('.lava').stop().animate({left:$(this).position()['left']}, {duration:1000});
			
			//scroll the panel to the correct content
			$('.panel').stop().animate({left:$(this).position()['left'] * (-2)}, {duration:1000});
		});
		
});


////////////////////////////////////////////////////////////
// BUTTON FADES
////////////////////////////////////////////////////////////


$(function() {
// OPACITY OF BUTTON SET TO 50%
$("#download, #support, #forums, #shop-btn, #enter, #register, #usercp, #more-info, .rank-btn, .rank-btn-right, #simplePrevious, #simpleNext, .back, .submit, #add, #donate, .panel-btn, #amount-btn").css("opacity","0.7");
 
// ON MOUSE OVER
$("#download, #support, #forums, #shop-btn, #enter, #register, #usercp, #more-info, .rank-btn, .rank-btn-right, #simplePrevious, #simpleNext, .back, .submit, #add, #donate, .panel-btn, #amount-btn").hover(function () {
 
// SET OPACITY TO 100%
$(this).stop().animate({
opacity: 1.0
}, "slow");
},
 
// ON MOUSE OUT
function () {
 
// SET OPACITY BACK TO 50%
$(this).stop().animate({
opacity: 0.7
}, "slow");
});
});


////////////////////////////////////////////////////////////
// TOGGLES
////////////////////////////////////////////////////////////


$(document).ready(function toggleMenu(){
//Set default open/close settings
jQuery('.s-content').hide(); //Hide/close all containers
jQuery('.heading:first').addClass('active').next().show(); //Add "active" class to first trigger, then show/open the immediate next container
 
//On Click
jQuery('.heading').click(function(){
 if( jQuery(this).next().is(':hidden') ) { //If immediate next container is closed…
  jQuery('.heading').removeClass('active').next().slideUp(); //Remove all "active" state and slide up the immediate next container
  jQuery(this).toggleClass('active').next().slideDown(); //Add "active" state to clicked trigger and slide down the immediate next container
 }
 return false; //Prevent the browser jump to the link anchor
});
});


////////////////////////////////////////////////////////////
// CUROSEL
////////////////////////////////////////////////////////////


jQuery(document).ready(function(){
				jQuery('#slider-stage').carousel('#previous', '#next');
				jQuery('#viewport').carousel('#simplePrevious', '#simpleNext');  
});


/////////////////////////////////////////////////////////////
// CUSTOM SHOP STYLES
////////////////////////////////////////////////////////////


$(document).ready(function(){

	// Blur images on mouse over
	$(".portfolio a").hover( function(){ 
		$(this).children("img").animate({ opacity: 0.75 }, "fast"); 
	}, function(){ 
		$(this).children("img").animate({ opacity: 1.0 }, "slow"); 
	}); 

	// Clone portfolio items to get a second collection for Quicksand plugin
	var $portfolioClone = $(".portfolio").clone();
	
	// Attempt to call Quicksand on every click event handler
	$(".filter a").click(function(e){
		
		$(".filter li").removeClass("current");	
		
		// Get the class attribute value of the clicked link
		var $filterClass = $(this).parent().attr("class");

		if ( $filterClass == "all" ) {
			var $filteredPortfolio = $portfolioClone.find("li");
		} else {
			var $filteredPortfolio = $portfolioClone.find("li[data-type~=" + $filterClass + "]");
		}
		
		// Call quicksand
		$(".portfolio").quicksand( $filteredPortfolio, { 
			duration: 800, 
			easing: 'easeInOutQuad' 
		}, function(){
			
			// Blur newly cloned portfolio items on mouse over and apply prettyPhoto
			$(".portfolio a").hover( function(){ 
				$(this).children("img").animate({ opacity: 0.75 }, "fast"); 
			}, function(){ 
				$(this).children("img").animate({ opacity: 1.0 }, "slow"); 
			}); 
			
		});


		$(this).parent().addClass("current");

		// Prevent the browser jump to the link anchor
		e.preventDefault();
	})
});

