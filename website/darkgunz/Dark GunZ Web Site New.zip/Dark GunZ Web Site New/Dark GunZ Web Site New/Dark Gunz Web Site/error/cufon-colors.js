Cufon('.eror-font span', {
  color: '-linear-gradient(#000, #000)'
});

