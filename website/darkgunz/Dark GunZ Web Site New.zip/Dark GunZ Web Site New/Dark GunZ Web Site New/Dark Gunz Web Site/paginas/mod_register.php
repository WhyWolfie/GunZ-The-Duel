<?
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $country = clean($_POST['country']);
    $name = clean($_POST['name']);
    $age = clean($_POST['age']);
    $sex = clean($_POST['sex']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Email em uso.","index.php?do=register");
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Usuario em uso.","index.php?do=register");
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            msgbox("As senhas n�o coincidem.","index.php?do=register");
            $er = 1;
        }

        if($user == ""){
            msgbox("Por favor digite o nome de Usuario.","index.php?do=register");
            $er = 1;
        }

        if($email == ""){
            msgbox("Por favor digite um email.","index.php?do=register");
            $er = 1;
        }

        if(strlen($pw1) < 4){
            msgbox("Senha deve conter mais de 4 caracteres..","index.php?do=register");
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            msgbox("Por favor digite uma senha.","index.php?do=register");
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins])VALUES('$user','$aid','$pw1',50,70)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>
<form name="reg" method="POST" action="index.php?do=register">
        	<div id="wrapper-cent">
             
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Register</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        <div id="container">
                            
                        
                                <!-- #first_step -->
                                <div id="first_step">
                                    <h1>Crie uma conta gratis no <span>DarKGunZ</span></h1>
                                    <div class="form">
									
																		
							<form name="registerpost" method="post">
                                        <input type="text" name="userid" id="userid" value="Usuario" />
                                        <label for="userid">Pelo menos 4 caracteres. Letras mai�sculas, letras min�sculas e n�meros.</label>
                                        
                                        <input type="password" name="pw1" id="pw1" value="password" />
                                        <label for="pw1">Pelo menos 4 caracteres. Use uma mistura de letras mai�sculas e min�sculas para uma senha forte.</label>
                                        
                                        <input type="password" name="pw2" id="pw2" value="password" />
                                        <label for="pw2">Se as suas senhas n�o s�o iguais, voc� n�o ser� capaz de continuar com a inscri��o.</label>

                                        <input type="text" name="name" id="name" value="Nome Completo" />
                                        <label for="name">Seu nome completo. </label>
										
                                        <input type="text" name="email" id="email" value="Email" />
                                        <label for="email">O seu endere�o de e-mail. N�s enviaremos avisos importantes da administra��o para este endere�o.</label>   
										
                                        <input type="text" name="age" id="age" value="Sua idade" />
                                        <label for="age">Por favor, inserir a sua idade.</label>
										
                                        <input type="text" name="sex" id="sex" value="Seu sexo" />
                                        <label for="sex">Digite seu Sexo: Masculino ou Feminino.</label>
										
                                        <input type="text" name="country" id="country" value="Seu pa�s" />
                                        <label for="country">Por favor, Digite o Pa�s em que voc� mora.</label>
                                
                                        
                                    </div>
                                    <input class="send submit" type="submit" name="submit" id="submit" value="" />      
                                </div>
                                </form>
                            </form>
                        </div>
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012-2013. All Rights Reserved</div>
             
            </div>

<?
}else{
?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form name="reg" method="POST" action="index.php?do=register">

        	<div id="wrapper-cent">
             
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Register</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        <div id="container">
                            
                        
                                <!-- #first_step -->
                                <div id="first_step">
                                    <h1>A conta <span><?=$user?></span> foi criada corretamente<br>
                                        Voc� pode jogar Resistence GunZ Agora</h1>
     
                                </div>
                                </form>
                            </form>
                        </div>
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012-2013. All Rights Reserved</div>
             
            </div>
<?
}
?>