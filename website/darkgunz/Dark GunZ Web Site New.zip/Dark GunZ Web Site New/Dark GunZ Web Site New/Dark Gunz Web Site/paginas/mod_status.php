
                <!-- Server Status Starts -->
                <div id="sidebar">
                	<div id="sidebar-top">
                    	<div id="side-title">Server Status</div>
                    </div>
                    <div id="sidebar-cent">
                    	<div id="side-cont">
                    		<div id="date-status"><font size="2"><script Language="JavaScript">
<!--
mydate = new Date();
myday = mydate.getDay();
mymonth = mydate.getMonth();
myweekday= mydate.getDate();
weekday= myweekday; 

if(myday == 0)
day = " Domingo, " 

else if(myday == 1)
day = " Segunda - Feira, " 

else if(myday == 2)
day = " Ter�a - Feira, " 

else if(myday == 3)
day = " Quarta - Feira, " 

else if(myday == 4)
day = " Quinta - Feira, " 

else if(myday == 5)
day = " Sexta - Feira, " 

else if(myday == 6)
day = " S�bado, " 

if(mymonth == 0)
month = "Janeiro " 

else if(mymonth ==1)
month = "Fevereiro " 

else if(mymonth ==2)
month = "Mar�o " 

else if(mymonth ==3)
month = "Abril " 

else if(mymonth ==4)
month = "Maio " 

else if(mymonth ==5)
month = "Junho " 

else if(mymonth ==6)
month = "Julho " 

else if(mymonth ==7)
month = "Agosto " 

else if(mymonth ==8)
month = "Setembro " 

else if(mymonth ==9)
month = "Outubro " 

else if(mymonth ==10)
month = "Novembro " 

else if(mymonth ==11)
month = "Dezembro " 

document.write("<font face=arial>"+ day);
document.write(myweekday+" de "+month+ "</font>");
// -->
                </script></div>
                            <hr />
                            <div id="server-list">
                            <ul>

<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = $data->ServerName;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<div id='off-icon'></div><li class='offline'>Game Server Offline<br /></li>";
        }
        else
        {
            echo "<div id='on-icon'></div><li class='online'>Game Server Online<br /></li>";
            fclose($fp);
        }
    }
    ?>

<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = $data->ServerName;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<div id='off-icon'></div><li class='offline'>Login Server Offline<br /></li>";
        }
        else
        {
            echo "<div id='on-icon'></div><li class='online'>Login Server Online</li><br />";
            fclose($fp);
        }
    }
    ?>
																						<li class="info"><div id="info-icon"></div>50x EXP Rate</li>
                            <li class="info"><div id="info-icon"></div>50x Bounty Rate</li>
							
                            </ul>
                            </div>
                            <div id="server-render"></div>
                            <br class="clear" />
                            <hr />
                            <div id="players">
                            <span class="players-on"><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "$servercount";
    ?></span> jogadores estao online no momento<br>
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
                            <span class="sub-players">Recorde jogadores on-line foi</span> <span class="count-total"><?=$b['PlayerCount']?></span>
                            </div>
                            
                        </div>
                    </div>
                    <div id="sidebar-bottom"></div>
                </div>
                <!-- Server Status Ends -->