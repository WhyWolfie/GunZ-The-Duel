﻿<?
if(empty($_GET['code']) || empty($_GET['aid']))
{
	msgbox("Codigo Invalido","index.php");
}else{
	$code = clean($_GET['code']);
	$aid = clean($_GET['aid']);
	if(!is_numeric($aid))
	{
		msgbox("Error no AID","index.php");
	}
	$q = mssql_query("SELECT * FROM Login WHERE Code='".$code."' AND AID='".$aid."'");
	if(!mssql_num_rows($q))
	{
		msgbox("O codigo nao existe ou ja foi usado","index.php");
	}else{
		$r = mssql_fetch_object($q);
		if(isset($_POST['reset']))
		{
			$pass = clean($_POST['pass']);
			$npass = clean($_POST['npass']);
			if(empty($pass) || empty($npass))
			{
				msgbox("Nao deixe espacos vazios","index.php");
			}
			if($pass != $npass)
			{
				msgbox("As senhas nao coincidem","index.php");
			}
			
			mssql_query("UPDATE Login SET CodeFecha=GETDATE(), Code='0', Password='".$pass."' WHERE AID='".$aid."'");
			msgbox("Senha redefinida corretamente","index.php");
		}else{
			$nick = $r->UserID;
		?>
		<form name="resetp" method="post">
        <center>
        <font color="#00FF00">
        Bem vindo, <?=$nick?><br />
        Nova Senha: <input type="password" name="pass"><br>
        Repetir Senha: <input type="password" name="npass"><br>
        <input type="submit" name="reset" value="Redefinir Senha">
        </font>
        </center>
        </form>
        <? }  } } ?>