<?php
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Clan") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 50; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Clan where Point not in (select top $max Point from Clan order by Point desc) order by Point desc");
$name = mssql_fetch_row($result);
?>
        	<div id="wrapper-cent">
             
			 
			 
									
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Clan Rankings</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        <div id="ranking-table-title"></div>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" id="ranking-table">
                              <tr class="titles">
                                <td>Rank</td>
                                <td>Name</td>
                                <td>Points</td>
                                <td>Lider</td>
                                <td>Win</td>
                                <td>Losses</td>
                              </tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
			      <tr>
                                <td><?php echo "$rank";?></td>
                                <td><a href="index.php?do=claninfo&id=<?php echo "$row[0]";?>"><?php echo "$row[1]";?></font></a></td>
                                <td><?php echo "$row[4]";?></td>
                                <td><? $res2 = mssql_query("SELECT * FROM Character WHERE CID = '".$row[5]."'");
                                                                            $c = mssql_fetch_assoc($res2);
                                                                            echo $c['Name'];
                                                                        ?></td>
                                <td><?php echo "$row[6]";?></td>
                                <td><?php echo "$row[13]";?></td>
			      </tr>
  <?
  $i++;
  }
   ?>
                            </table>
                            <div id="ranking-table-footer"></div>
<center>
<?
echo "<p>"; 
echo "Pagina $pagenum de $last <p>";
if ($pagenum == 1) { }
else
{
echo "<a href='index.php?do=clanranking&pagenum=1'> <<-Primeira |</a> ";
echo " ";
$previous = $pagenum-1;
echo "<a href='index.php?do=clanranking&pagenum=$previous'> <-Anterior |</a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=clanranking&pagenum=$next'>Proxima -></a> ";
echo " ";
echo " <a href='index.php?do=clanranking&pagenum=$last'>| Ultima ->></a> ";
}
?>
</center>
                            <!--<a href="#"><div class="rank-btn" style="float: left;">Players</div></a>
							
                            <a href="#"><div class="rank-btn-right">Clans</div></a>-->
                            <br class="clear" />
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012-2013. All Rights Reserved</div>
             
            </div>
		