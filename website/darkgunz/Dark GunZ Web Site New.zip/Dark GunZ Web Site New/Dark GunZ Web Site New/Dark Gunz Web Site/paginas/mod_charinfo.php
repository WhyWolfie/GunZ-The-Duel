<?
    $cid = antisql($_GET['id']);
if(!is_numeric($cid)){
msgbox("Not Available","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);

if($num_rows < 1){
msgbox("Account Does not Exist","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "253" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "254" || $char2['UGradeID'] == "255"){
    msgbox("You are not allowed to View this Account Information.","index.php");
exit();
	}
	if ( $char2['DeleteFlag'] != "0"){
    msgbox("Voc� n�o pode ver isso..","index.php");
exit();
	}
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title"><center>Informacoes do Char</center></div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">

                          <tr>
                            <td bgcolor="#232122" class="Estilo1" align="center" valign="top"><table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1"><font color="white">Personal Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Nome:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char2['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Sexo:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char2['Sex']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Idade:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char2['Age']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Rank:</td>
                                    <td align="left" class="estilo1"><font color="white"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Membro";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GM";
                                                        break;
							case "253";
                                                        $ugradeid = "Bannido";
                                                        break;
							case "254";
                                                        $ugradeid = "Developer";
                                                        break;
							case "255";
                                                        $ugradeid = "Admin";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Pais</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char2['Country']?></td>
                                  </tr>
                                </table></td>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1"><font color="white">Character Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Nome:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Level:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char['Level']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Ranking:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=$char['Ranking']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Exp:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Kill/Death:</td>
                                    <td align="left" class="estilo1"><font color="white"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><font color="white">Clan:</td>
                                    <td align="left" class="estilo1"><a href="index.php?do=claninfo&id=<?=$claninfo['CLID']?>"><font color="white"><?=$claninfo['Name']?></td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table>

                          </tr>
</table>

						</td>
					</tr>
				</table></td>

                            
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->