			            <!-- Download Starts -->
            	<a href="#"><div id="download">
                	<div id="btn-text">
                	<p class="title">Download Client</p>
                    <p class="subtitle">Version 6.0</p>
                    </div>
                </div></a>
            <!-- Download Ends -->                <!-- Support Starts -->
                <a href="#"><div id="support">
                	<div id="btn-text">
                	<p class="title">Precisa de Ajuda ?</p>
                    <p class="subtitle">clique aqui suporte</p>
                    </div>
                </div></a>
                <!-- Support Ends -->