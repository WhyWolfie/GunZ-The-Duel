        	<div id="wrapper-cent">
             
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Download</div></div>
                    <div id="cont-body">
                    
                    <!-- Item 1 -->
                    <!-- Title -->
                    <div id="news-wrap">
                    	<div id="main-title" class="heading">
                        	<div id="cont-icon"></div>
                            <div id="news-title">Download Client</div>
                            <div id="news-date">4.4.12</div>
                        </div>
                    <!-- Title Ends -->
                    
                    <!--- Body Text Starts -->
                    <div id="main-cent" class="s-content">
                    <div id="body-wrap">
                    
                    <!-- Download Starts -->
                        <a href="#"><div id="download" class="left" style="margin-right: 10px;">
                            <div id="btn-text">
                            <p class="title">Download Client</p>
                            <p class="subtitle">version 6.0</p>
                            </div>
                        </div></a>
                    <!-- Download Ends -->
                    <div class="frame-text">
                    <p><span style="color: #DDD;">Name:</span> DarkGunZ Full Client</p> 
                    <p><span style="color: #DDD;">Last Update:</span> April 4, 2012</p>
                    <p><span style="color: #DDD;">Size:</span> 512 MB</p>
                    </div>
                    <br class="clear" />
                    <p class="aligncenter">Por favor, d� uma olhada nos requisitos Antes de baixar o nosso cliente</p>
                    
                    </div>
                    </div>
                    <!-- Body Text Ends --->
                    
                    <div id="main-footer"></div>
                    </div>
                    <!-- Item 1  Ends -->

                    	<div id="news-wrap">
                            <hr />
                            
                            <table id="sysrq" width="100%" border="0" cellspacing="0" cellpadding="0">
								<tbody><tr>
									<th scope="col" class="blank">&nbsp;</th>
									<th scope="col" class="sr-min">Minimum Requirements</th>
									<th scope="col" class="sr-rec">Recommended</th>
								</tr>
								<tr>
									<th scope="row" class="row-first">OS</th>
									<td colspan="2">Windows XP, Windows Vista, Windows 7</td>
								</tr>
								<tr>
									<th scope="row" class="row">DirectX</th>
									<td>DirectX 9.0c</td>
									<td>DirectX 9.0c or above</td>
								</tr>
								<tr>
									<th scope="row" class="row">CPU</th>
									<td>Pentium III 500 MHz</td>
									<td>Pentium III 800 MHz+</td>
								</tr>
								<tr>
									<th scope="row" class="row">RAM</th>
									<td>256 MB</td>
									<td>512 MB or above</td>
								</tr>
								<tr>
									<th scope="row" class="row">Graphics Card</th>
									<td>Direct 3D 9.0 Compatible (Riva TNT)</td>
									<td>GeForce 4MX or higher</td>
								</tr>								
								<tr>
									<th scope="row" class="row">Sound Card</th>
									<td colspan="2">Direct3D Sound Compatible</td>
								</tr>								
								<tr>
									<th scope="row" class="row-last">Mouse</th>
									<td colspan="2" class="last">Windows Compatible (Wheel Mouse recommended)</td>
								</tr>								
								
							</tbody></table>	
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012-2013. All Rights Reserved</div>
             
            </div>