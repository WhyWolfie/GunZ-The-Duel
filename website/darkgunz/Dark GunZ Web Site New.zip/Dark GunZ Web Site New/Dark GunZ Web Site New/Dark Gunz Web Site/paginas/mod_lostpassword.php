﻿<?php
if(isset($_POST['reset']))
{
	$user = clean($_POST['user']);
	$tmp = clean($_POST['captch']);
	if(empty($user) || empty($tmp))
	{
		msgbox("Nao deixe espacos vazios","index.php?do=reset");
	}
	if($tmp != $_SESSION['tmptxt'])
	{
		msgbox("O codigo esta incorreto","index.php?do=reset");
	}
	$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	if(!mssql_num_rows($q))
	{
		msgbox("Usuario inexistente","index.php?do=reset");
	}else{
		$r = mssql_fetch_object($q);
		if($r->Code != 0 || $r->Code != ""){
			msgbox("Como nao existe um codigo, disponivel em sua conta, verifique seu e-mail, chque sua caixa de sppam","index.php");
		}
	}
	
	do{
		$code = random1(40);
		$q = mssql_query("SELECT * FROM Login Where Code='".$code."'");
		if(mssql_num_rows($q))
		{
			$y = 1;
		}else{
			$y = 0;
		}
	}while($y == 1);
	mssql_query("UPDATE Login SET CodeFecha=GETDATE(), Code='".$code."' WHERE AID='".$r->AID."'");
	$texto = "Ele enviou um e-mail com o endereço onde você pode alterar sua senha, <br> Este link é válida apenas 1 vez
	http://".getUrl()."index.php?do=lostpassword&code=".$code."&aid=".$r->AID."<br>O código é valido por 15 dias";
	enviarmail($r->Email,"Redefinir Senha",$texto);
	msgbox("Instrucoes para redefinir senha enviadas para seu email, codigo valido por 15 dias.","index.php");
}else{
?>
             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Redefinir Senha</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">

<form name="resetz" method="post">
Digite o UserID: <br>
<input type="text" name="user"><br>
Codigo de Verificacao:<br><br>
<img src="paginas/captcha.php" width="100" height="30" vspace="3"><br>
<input type="text" name="captch"><br><br>
<input type="submit" name="reset" value="Redefinir Senha">
</form>
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->
<? } ?>