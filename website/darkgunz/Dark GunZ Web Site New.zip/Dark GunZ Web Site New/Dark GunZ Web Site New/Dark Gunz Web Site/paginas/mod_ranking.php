             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Rankings</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        
                            <p>Bem vindo, para ir ao ranking basta clickar em cima do que voce preferir.</p><br><br>

                            <center><a onclick="window.location.href='index.php?do=clanranking'">Clan Ranking</a> <a onclick="window.location.href='#'">|</a> <a onclick="window.location.href='index.php?do=playerranking'">Player Ranking</a></center>
                            
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->