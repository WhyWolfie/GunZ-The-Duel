             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">UserPanel</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">

<?php
if(empty($_SESSION['AID']))
{
	alertbox("No estas logueado","index.php");
}
?>

<center><a href="index.php?do=clancp&page=meusclans">Meus Clans</a> | <a href="./index.php?do=clancp&page=meuspedidos">Meus Pedidos</a> | <a href="index.php?do=clancp&page=sair">Sair ou Encerrar um Clan</a><br /> <a href="./index.php?do=clancp&page=mudar">Mudar status de um membro</a></center>
<br />
<font color="#FFFFFF">--------------------------------------------------------------------------</font>
<br><br>
<?
if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	if($page == "meuspedidos")
	{
		?>
		<font color="#FF0000">Para enviar um pedido para algum clan bastar ir ate o ranking<br />
        clickar sobre o nome do clan onde mostra as info e colocar para enviar pedido.</font>
        <br /><br />
        <font color="#FFFFFF">-------------------------------------------------------------------------------</font>
        <?
		include "clan/meuspedidos.php";
	}elseif($page == "meusclans")
	{
		include "./clan/meusclans.php";
	}elseif($page == "sair")
	{
		include "./clan/sair.php";
	}elseif($page == "mudar")
	{
		include "./clan/mudar.php";
	}
}else{ ?>
<p>&nbsp;</p>
<?
}
?>


                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->