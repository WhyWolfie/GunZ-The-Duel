<?php
$q = mssql_query("SELECT * FROM Character a INNER JOIN Clan b ON a.CID=b.MasterCID WHERE a.AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo '<font color="#FFFFFF">No eres master de algun clan.</font>';
	die();
}
if(!isset($_GET['paso']) || !is_numeric($_GET['paso']))
{
	$paso = 1;
}else{
	$paso = clean($_GET['paso']);
}

if($paso == 1){
	?>
    <form name="cambiar" method="post" action="./index.php?do=clan&page=cambiar&paso=2">
<font color="#FFFFFF">
	Clan: <select name="clan">
	<?
	while($r = mssql_fetch_object($q))
	{
	?>
    	<option value="<?=$r->CLID?>"><?=getclan($r->CLID)?></option>
        <?
	}

?>
		</select>
        <br><br>
        <input type="submit" name="cambiar" value="Seleccionar">
        </font></form>
        <? }
		elseif($paso == 2)
		{
			$clid = clean($_POST['clan']);
			if(empty($clid))
			{
				alertbox("No se tiene ningun clan seleccionado");
			}
			$q = mssql_query("SELECT * FROM Character a INNER JOIN Clan b ON a.CID=b.MasterCID WHERE a.AID='".$_SESSION['AID']."' AND CLID='".$clid."'");
if(!mssql_num_rows($q))
{
	echo '<font color="#FFFFFF">No eres master del clan.</font>';

}else{
$q = mssql_query("SELECT * FROM ClanMember WHERE CLID='".$clid."' AND CID != '".getclancid($clid)."'");

if(!mssql_num_rows($q))
{
	echo '<font color="#FFFFFF">No Hay miembros en el Clan</font>';
	
}else{
			?>
			<form name="cambiar" method="post" action="./index.php?do=clan&page=cambiar&paso=3">
<font color="#FFFFFF">
	Miembro: <select name="miembro">
	<?
	while($r = mssql_fetch_object($q))
	{
	?>
    	<option value="<?=$r->CID?>"><?=getcha($r->CID)?></option>
        <?
	}

?>
		</select><br>
        Rango: <select name="grado">
        <option value="2">Administrador</option>
        <option value="9">Normal</option>
        <option value="0">Sacar</option>
        </select><br>
        <input type="submit" value="Cambiar Rango" name="cambiarr">
        </font></form>
            <?
			
}}}elseif($paso == 3){
			
			$rango = clean($_POST['grado']);
			$cid = clean($_POST['miembro']);
			if(!is_numeric($rango))
			{
				alertbox("Error","index.php");
			}
			if(!is_numeric($cid))
			{
				alertbox("Error","index.php");
			}
			if($rango == 0)
			{
				mssql_query("DELETE FROM ClanMember CID='".$cid."'");
				alertbox("Miembro sacado del Clan","index.php?do=clan");
			}else{
				mssql_query("UPDATE ClanMember SET Grade='".$rango."' WHERE CID='".$cid."'");
				alertbox("Rango Cambiado","index.php?do=clan");
			}
		}
			?>