<?php
//Act GunZ Online By Sparrow
$link = mssql_connect("Tu\SQLEXPRESS","sa","pw");
mssql_select_db("DB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Act GunZ Connected

$DBHost = 'Tu\SQLEXPRESS'; //Sparrow SQL
$DBUser = 'sa'; //Your DB User 
$DBPass = 'pw'; //Sparrow Senha 
$DB = 'DB'; //Sparrow GunZ DB 


?>