<font color="#FFFFFF">
<br>
<?php
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo "<br>Voce nao possui nenhum personagem";
}else{
	while($r = mssql_fetch_object($q))
	{
		$qq = mssql_query("SELECT * FROM Pedidos WHERE CID='".$r->CID."'");
		if(mssql_num_rows($qq))
		{			
		?>
			Personagem: <?=$r->Name?><br>
	        <table width="494">
    		<tr>
    		<td align="center">Clan</td><td align="center">Status</td><td align="center">Data</td>
	    	</tr>
        <?
			while($rr = mssql_fetch_object($qq))
			{
				if($rr->Status == 0)
					{
						$status = '<font color="#00FFFF">Esperando</font>';
					}elseif($rr->Status == 1){
						$status = '<font color="#00FF00">Aprovado</font>';
					}else{
						$status = '<font color="#FF0000">Reprovado</font>';
					}
				?>
                <tr>
                <td><?=getclan($rr->CLIDClan)?></td><td><?=$status?></td><td><?=$rr->Fecha?></td>
                </tr>
                <?
			}?>
            </table>
            <?
		}else{
			echo "<br>Voce nao enviou nenhum pedido";
		}
	}
}
?>
</font>