<?
//Script de recuperar character deletado by heart ~
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

if( $_SESSION[AID] == "" )
 msgbox("Por Favor logue-se primeiro !","index.php?do=login");


$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

$seleciona = mssql_query("SELECT DeleteName, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '1'");

if( mssql_num_rows($seleciona) < 1 )
{
msgbox ("Voc� n�o tem personagens deletados","index.php?do=usercp");
die();
}

if($etapa == "")
{
?>
<form id="site_Login" name="site_Login" method="post" action="?do=usercp&page=recuperar&etapa=1">
<font color="#00FF00"><div id="title">Recuperar personagem:</div><p />
<table align="center">
  <tr>
<td>Selecione o personagem:</td>
<td><select name="cid22" class="text">
          
<?
while($busca = mssql_fetch_row($seleciona))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>
          
</select></td></tr>
 �
   <tr>
<td></td><
<td><input type="submit" name="logar" value="Recuperar Personagem" /></td>
  </tr>
</table>
</font>
</form>


<?
}

if($etapa == 1)
{

$cid22 = Filtrrar($_POST['cid22']);

$query1 = mssql_query("SELECT DeleteName FROM Character WHERE CID = '$cid22'");
$query2 = mssql_fetch_row($query1);

$query3 = mssql_query("SELECT TOP 1 CharNum FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0' ORDER BY RegDate DESC");
$query4 = mssql_fetch_row($query3);

$Mais = $query4[0] + 1;

if($Mais >= 3){
msgbox ("Caso voc� tenha 3 ou mais personagens voc� n�o pode usar o sistema de recuperar personagem.","index.php?do=usercp");
}else{

$query5 = mssql_query("UPDATE Character SET Name = '$query2[0]', DeleteFlag = '0', DeleteName = NULL, CharNum = '$Mais' WHERE CID = '$cid22'");

msgbox ("Personagem Recuperado Com Sucesso , relogue .<br>","index.php?do=usercp");
}

}
?>