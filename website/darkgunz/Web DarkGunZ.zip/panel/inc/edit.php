<?php
$q = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
if(isset($_POST['update']))
{
	$nome = clean($_POST['nome']);
	$idade = clean($_POST['idade']);
	$email = clean($_POST['email']);
	if(!is_numeric($idade))
	{
		msgbox("A idade deve ser somente n�meros","index.php");
	}
	
	mssql_query("UPDATE Account SET Name='".$nome."', Age='".$idade."', Email='".$email."' WHERE AID='".$_SESSION['AID']."'");
	
	msgbox("Dados Alterados com sucesso","index.php?do=usercp");
	
}else{

?>
<form name="datos" method="post">
<div id="title">Editar Datos :</div>
<p>&nbsp;</p>
<table align="center">
  <tr>
    <td><b>Nombre :</b></td>
    <td><input type="text" name="nome" value="<?=$r->Name?>" /></td>
  </tr>
  <tr>
    <td><b>Idade :</b></td>
    <td><input type="number" name="idade" value="<?=$r->Age?>" /></td>
  </tr>
  <tr>
    <td><b>Email :</b></td>
    <td><input type="email" name="email" value="<?=$r->Email?>" /></td>
  </tr>
  <tr>
    <td></td>
    <td><input type="submit" name="update" value="Atualizar" /></td>
  </tr>
</table>
</form>
<? } ?>