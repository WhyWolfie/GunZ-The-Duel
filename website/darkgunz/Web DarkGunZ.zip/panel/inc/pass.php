﻿<?php
if(isset($_POST['changepassword']))
{
	$opass = clean($_POST['oldpassword']);
	$npass = clean($_POST['newpassword']);
	$npass1 = clean($_POST['repeatnewpassword']);
	if(empty($opass) || empty($npass) || empty($npass1))
	{
		msgbox("Preencha os campos obrigatorios","index.php?do=usercp&page=pass");
	}
	if($npass != $npass1)
	{
		msgbox("Senhas nao correspondem","index.php?do=usercp&page=pass");
	}
	$q = mssql_query("SELECT * FROM Login WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
	if($r->Password != $opass)
	{
		msgbox("La Contraseña Actual Esta Incorrecta","index.php?do=usercp&page=pass");
	}
	mssql_query("UPDATE Login SET Password='".$npass."' WHERE AID='".$_SESSION['AID']."'");
	msgbox("Senha trocada  corretamente","index.php?do=usercp");
}else{
	?>
    <form name="pass" method="post">
<div id="title">Mudar Senha:</div><p />
<p>&nbsp;</p>
<table align="center">
  <tr>
    <td><b>Senha Atual:</b></td>
    <td><input type="password" name="oldpassword" /></td>
  </tr>
  <tr>
    <td><b>Nova Senha:</b></td>
    <td><input type="password" name="newpassword" /></td>
  </tr>
  <tr>
    <td><b>Repita a nova senha:</b></td>
    <td><input type="password" name="repeatnewpassword" /></td>
  </tr>
  <tr>
    <td></td>
    <td><input type="submit" name="changepassword" value="Mudar Senha" /></td>
  </tr>
</table>
</form>
<? } ?>