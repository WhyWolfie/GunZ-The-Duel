<?
$res = mssql_query("SELECT TOP 5 Name, Level FROM Character WHERE Name != '' ORDER BY Level DESC");
    $count = 0;
    ?>
			                <!-- Rankings Starts -->
                <div id="sidebar">
                	<div id="sidebar-top">
                    	<div id="side-title">Ranking</div>
                    </div>
                    <div id="sidebar-cent">
                    	<div id="side-cont">
                        <div id="moving_tab">
                        	<div class="content">
                         	<div class="panel">
                            <ul>
                            	<li>
                                	<table width="174" height="180" border="0" cellspacing="0" cellpadding="0">
                                      <tr>
                                        <td class="main-text">#</td>
                                        <td class="main-text">Player Name</td>
                                        <td class="main-text">Lvl.</td>
                                      </tr>
<?
while($r = mssql_fetch_assoc($res)){
$count++;
?>									  
				     <tr>
                                        <td><?=$count?></div></td>
                                        <td><?=$r['Name']?></td>
                                        <td><?=$r['Level']?></td>
                                      </tr>
<?}?>
									  									  
                                    </table>
                                </li>
                            </ul>
<?
$res = mssql_query("SELECT TOP 5 Name, Point FROM Clan WHERE Name != '' ORDER BY Point DESC");
	$rank = 0;
?>
                            <ul>
                            	<li>
                                	<table width="174" border="0" cellspacing="0" cellpadding="0">
                                      <tr>
                                        <td class="main-text">#</td>
                                        <td class="main-text">Clan Name</td>
                                        <td class="main-text">Pts.</td>
                                      </tr>
<? while($r = mssql_fetch_assoc($res)){
$rank++;  
?>
				      <tr>
                                        <td><?=$rank?></div></td>
                                        <td><?=$r['Name']?></td>
                                        <td><?=$r['Point']?></td>
                                      </tr>
<?}?>
									  
									  
									  
                                    </table>
                                </li>
                            </ul>												
                           </div>
                           </div>
                           
                           <div class="tabs">
                           		<span class="item"><div class="rank-btn">Players</div></span>
                           		<span class="item"><div class="rank-btn-right">Clans</div></span>
                        	</div>
                           
                           </div>
                              
                        </div>
                    </div>
                    <div id="sidebar-bottom"></div>
                </div>
                <!-- Rankings Ends -->                
            </div>