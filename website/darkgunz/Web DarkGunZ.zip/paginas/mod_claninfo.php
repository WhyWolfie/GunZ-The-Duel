<?
$cinfo = antisql($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan Does not Exist","index.php");
exit();
}

$clid = $clan->CLID;
?> 
             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title"><center>Informacoes do Clan</center></div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">

                          <tr>
                            <td height="35" class="Estilo2" align="center">
                               <center><?=$clan->Name?></br>
&nbsp;</br>
<img src="<?=($clan->EmblemUrl == "") ? "images/no_emblem.png" : $clan->EmblemUrl?>" width="100" height="100" BORDER=5 ></center></br>
&nbsp;</td>
</tr>
                          <tr>
                            <td bgcolor="#232122" class="Estilo1" align="center" valign="top">
<table width="447" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top">

<table border="2" style="border-collapse: collapse" width="447" height="100%">
<div align="center">
&nbsp;
                         <tr>			    
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Rank: </td>
                                    <td align="left" class="estilo1"><?=$clan->Ranking?></td>

                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Pontos: </td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Win:</td>
                                    <td align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Losses:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Draw:</td>
                                    <td align="left" class="estilo1"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Criado:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Membros:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="448" border="0" cellpadding="0" cellspacing="0">
&nbsp;
                                  <tr>
                                    <td align="center" class="estilo1"><u>Char</u></td>
                                    <td align="center" class="estilo1"><u>Rank</u></td>
                                    <td align="center" class="estilo1"><u>Entrou</u></td>
                                    <td align="center" class="estilo1"><u>Pontos</u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><a href="index.php?do=charinfo&id=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
<center><a href="index.php?do=enviarpedido&clid=<?=$clan->CLID?>"><input type="submit" name="enviarpedido" value="Enviar pedido" /></a></center>
                            </table></td>
                          </tr>
						</td>
					</tr>
			
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->