        <!-- Colum 2 Starts -->
        	<div id="wrapper-cent">
            
             <!-- Featured Slider Starts -->
                 <div id="slider-main">
                    <div id="slider-frame">
                            <div id="slider">
                                <a href="#"><img src="slides/slide1.png" alt="" title="" /></a>
                                <a href="#"><img src="slides/slide2.png" alt="" title="" /></a>
                                <a href="#"><img src="slides/slide3.png" alt="" title="" /></a>
                                <a href="#"><img src="slides/slide4.png" alt="" title=""/></a>
                            </div>
                        </div>
                 </div>
             <!-- Featured Slider Ends -->
             
             <!-- News Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Recent News</div></div>
                    <div id="cont-body">

										
                    <!-- Item 3 -->
                    <!-- Title -->
<?
//Script created by Yakow

$busca1 = mssql_query("SELECT TOP 5 ID, Titulo, Noticia, Data, autor FROM Noticias ORDER BY ID DESC");
while ($busca2 = mssql_fetch_row($busca1)){
?>
                    <div id="news-wrap">
                    	<div id="main-title" class="heading">
                        	<div id="news"></div>
                            <div id="news-title"><?=$busca2[1]?></div>
                            <div id="news-date"><font size="-4"><?=$busca2[3]?></font></div>

                        </div>
                    <!-- Title Ends -->
                    
                    <!--- Body Text Starts -->
                    <div id="main-cent" class="s-content">
                    <div id="body-wrap">
                    <p><?=$busca2[2]?>. &nbsp;&nbsp;&nbsp;<u><i>Powered by <?=$busca2[4]?></u></p></i>
                    </div>
                    </div>

                    <!-- Body Text Ends --->
                    
                    <div id="main-footer"></div>
                    </div>
                    <!-- Item 3  Ends -->
<?
}
?>
					

					                    
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- News Ends -->
					
             
             <!-- Ad Starts --><!-- Ad Ends -->
             
             <!-- Item Scroller Starts -->
           	  <div id="cont-frame">
                	<div id="cont-top"><div id="cont-title"><span id="result_box" lang="pt" xml:lang="pt">Itens em Destaque</span></div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                           
                        	<a id="simplePrevious"></a>
                                <div id="viewport">
                                    <ul>
									                                        <li>
                                        <a href="indexf026.html?do=shopitem&amp;id=145"><img src="images/shop/bedkit.png" width="70" height="70" /></a>
                                        <p class="itemname">BedKit</p>
                                        </li>
									                                        <li>
                                        <a href="indexf1ae.html?do=shopitem&amp;id=26"><img src="images/shop/tensarebirth.png" width="70" height="70" /></a>
                                        <p class="itemname">Tensa Rebirth</p>
                                        </li>
									                                        <li>
                                        <a href="indexd926.html?do=shopitem&amp;id=22"><img src="images/shop/dds.png" width="70" height="70" /></a>
                                        <p class="itemname">Dark Dragon Sword</p>
                                        </li>
									                                        <li>
                                        <a href="index25b2.html?do=shopitem&amp;id=138"><img src="images/shop/ring3.png" width="70" height="70" /></a>
                                        <p class="itemname">Ultra Ring</p>
                                        </li>
									                                        <li>
                                        <a href="indexb743.html?do=shopitem&amp;id=79"><img src="images/shop/blunder.png" width="70" height="70" /></a>
                                        <p class="itemname">Blunderbuss</p>
                                        </li>
									                                        <li>
                                        <a href="indexa09d.html?do=shopitem&amp;id=78"><img src="images/shop/pioneer.png" width="70" height="70" /></a>
                                        <p class="itemname">Pioneer</p>
                                        </li>
									                                        <li>
                                        <a href="indexe584.html?do=shopitem&amp;id=77"><img src="images/shop/scattergun.png" width="70" height="70" /></a>
                                        <p class="itemname">The Scattergun</p>
                                        </li>
									                                        <li>
                                        <a href="index2b02.html?do=shopitem&amp;id=143"><img src="images/shop/medkithp.png" width="70" height="70" /></a>
                                        <p class="itemname">Medkit HP</p>
                                        </li>
									                                        <li>
                                        <a href="index66b8.html?do=shopitem&amp;id=144"><img src="images/shop/medkitap.png" width="70" height="70" /></a>
                                        <p class="itemname">Medkit AP</p>
                                        </li>
									                                        <li>
                                        <a href="indexd2ab.html?do=shopitem&amp;id=19"><img src="images/shop/vampiref.png" width="70" height="70" /></a>
                                        <p class="itemname">Vampire Avatar (F)</p>
                                        </li>
									                                    </ul>
                                </div>
                                <a id="simpleNext"></a>
                             
                        <br class="clear" />
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Item Scroller Ends -->

             <!-- Whats Going On Starts -->
			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">O que esta acontecendo ?</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        
                            <p><?php 
$perso = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY CID DESC"));
?>Ultimo char criado foi: <span style="color: #c3d9ea"><? echo $perso[0]; ?></span></p>	
							<p><?php
 
//Total Contas
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Total de Contas: ".$num_rows."<n>";

?> | <?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Total de Clans: ".$num_rows."<n>";

?> | <?php
 
//Total Personagens
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Total de Personagens: ".$num_rows."<n>";

?></p>
							<br />
                            
                            <div id="legend">
                            <p><span class="legend">Legend</span> <span style="color: #e3440b">Administrator</span> | <span style="color: #00ffb6">GameMaster</span> | <span style="color: #4772b8; text-decoration: line-through;">Banned Player</span> | <span style="color: #c3d9ea">Regular Player</span> | <span style="color: #ffcc00">Donator</span></p>
                            </div>
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Whats Going On Ends -->

             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012. All Rights Reserved</div>
             
            </div>
        <!-- Colum 2 Ends -->