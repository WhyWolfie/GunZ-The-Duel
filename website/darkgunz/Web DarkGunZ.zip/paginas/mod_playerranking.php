<?php
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Character") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 50; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Character where Level not in (select top $max Level from Character order by Level desc) order by Level desc");
$name = mssql_fetch_row($result);
?>
        	<div id="wrapper-cent">
             
			 
			 
									
             <!-- Content Box Starts -->
             	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">Player Rankings</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">
                        <div id="ranking-table-title"></div>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" id="ranking-table">
                              <tr class="titles">
                                <td>Rank</td>
                                <td>Name</td>
                                <td>Level</td>
                                <td>Sex</td>
                                <td>Kill</td>
                                <td>Death</td>
                              </tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
			      <tr>
                                <td><?php echo "$rank";?></td>
                                <td><a href='index.php?do=charinfo&id=<?php echo "$row[0]";?>'><?=FormatCharName($row[0])?></font></a></td>
                                <td><?php echo "$row[3]";?></td>
                                <td><?
                                                    switch ( $row[4] ){
                                                        case "0";
                                                        $row[4] = "Masculino";
                                                        break;
                                                        case "1";
                                                        $row[4] = "Feminino";
                                                        break;
                                                    } echo $row[4];

                                                        ?></td>
                                <td><?php echo "$row[32]";?></td>
                                <td><?php echo "$row[33]";?></td>
			      </tr>
  <?
  $i++;
  }
   ?>
                            </table>
                            <div id="ranking-table-footer"></div>
<center>
<?
echo "<p>"; 
echo "Pagina $pagenum de $last <p>";
if ($pagenum == 1) { }
else
{
echo "<a href='index.php?do=playerranking&pagenum=1'> <<-Primeira |</a> ";
echo " ";
$previous = $pagenum-1;
echo "<a href='index.php?do=playerranking&pagenum=$previous'> <-Anterior |</a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=playerranking&pagenum=$next'>Proxima -></a> ";
echo " ";
echo " <a href='index.php?do=playerranking&pagenum=$last'>| Ultima ->></a> ";
}
?>
</center>
                            <div id="legend">
                            <p><span class="legend">Legend</span> <span style="color: #e3440b">Administrator</span> | <span style="color: #00ffb6">GameMaster</span> | <span style="color: #4772b8; text-decoration: line-through;">Banned Player</span> | <span style="color: #c3d9ea">Regular Player</span> | <span style="color: #ffcc00">Donator</span></p>
                            </div>
                            <!--<a href="#"><div class="rank-btn" style="float: left;">Players</div></a>
							
                            <a href="#"><div class="rank-btn-right">Clans</div></a>-->
                            <br class="clear" />
                  
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright">Copyright <a href="#">DarkGunZ</a> 2012-2013. All Rights Reserved</div>
             
            </div>
		