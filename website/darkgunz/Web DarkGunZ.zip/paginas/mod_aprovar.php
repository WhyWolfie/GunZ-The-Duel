﻿<?php
if(!isset($_SESSION['AID']))
{
	msgbox("Quem e voce? -.-!","index.php");
}

if(!isset($_GET['id']) && !isset($_GET['cid']) && !isset($_GET['clid']))
{
	msgbox("Error","index.php");
}
if(!is_numeric($_GET['id']) && !is_numeric($_GET['cid']) && !is_numeric($_GET['clid']))
{
	msgbox("Error","index.php");
}

$id = clean($_GET['id']);
$cid = clean($_GET['cid']);
$clid = clean($_GET['clid']);

$q = mssql_query("SELECT * FROM Clan a INNER JOIN Character b ON a.MasterCID=b.CID WHERE b.AID='".$_SESSION['AID']."' AND a.CLID='".$clid."'");
if(!mssql_num_rows($q))
{
	msgbox("Voce nao e nada do clan ¬¬","index.php");
}

mssql_query("DELETE FROM Pedidos WHERE CID ='".$cid."' AND ID != '".$id."'");
mssql_query("UPDATE Pedidos SET Status='1' WHERE CID='".$cid."' AND ID='".$id."'");
mssql_query("INSERT INTO ClanMember (CLID, CID, Grade, RegDate, ContPoint) VALUES ('".$clid."', '".$cid."', '9', GETDATE(), '0')");
msgbox("Pedido Aprovado","index.php?do=clan");
?>

