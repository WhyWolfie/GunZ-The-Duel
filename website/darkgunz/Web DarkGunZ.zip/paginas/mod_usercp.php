             <!-- Whats Going On Starts -->
        	<div id="wrapper-cent">			 			 
			              	<div id="cont-frame">
                	<div id="cont-top"><div id="cont-title">UserPanel</div></div>
                    <div id="cont-body">
                    	<div id="news-wrap">

<center><a href="index.php?do=usercp&page=edit">Editar Datos</a> | <a href="index.php?do=usercp&page=pass">Alterar Senha</a> | <a href="index.php?do=usercp&page=sex">Trocar Sexo</a> | <a href="index.php?do=usercp&page=stats">Status</a> <br><a href="index.php?do=usercp&page=recuperar">Recuperar Personagem Deletado</a> | <a href="index.php?do=usercp&page=criarclan">Criar Clan</a></center>

<? if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "edit")
	{
		include "./panel/inc/edit.php";
	}elseif($page == "pass"){
		include "./panel/inc/pass.php";
	}elseif($page == "sex"){
		include "./panel/inc/sex.php";
	}elseif($page == "stats"){
		include "./panel/inc/stats.php";
	}elseif($page == "recuperar"){
		include "./panel/inc/recuperar.php";
	}elseif($page == "criarclan"){
		include "./panel/inc/criarclan.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=panel&page=".$page);
		msgbox("A pagina que voce esta procurando nao existe","index.php?do=usercp");
	}
	
}else{
}?>

                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
                </div>
             <!-- Whats Going On Ends -->