<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if($_SESSION[AID] == "")
{
?>
                <!-- Login Starts -->

                        <form name="login" method="POST" action="index.php?do=login&header=1">
                <div id="sidebar">
				
                	<div id="sidebar-top">
                    	<div id="side-title">Painel de usuario</div>
                    </div>
                    <div id="sidebar-cent">
                    	<div id="side-cont">
											                            <div id="username-feild">
                                <input class="bar" type="text" name="userid" onfocus="if(this.value=='username') this.value='';" onblur="if(this.value=='') this.value='username';" value="username">
                                </div>
                                <div id="password-feild">
                                    <input class="bar" type="password" name="pasw" onfocus="if(this.value=='Password') this.value='';" value="Password">
                                </div>

                                <input id="enter" type="submit" name="submit" class="submit" value="ENTER">
							</form>

                                <input id="register" type="submit" name="register" class="submit" value="REGISTER">
								
                                <div id="more-info"><div id="bullet"></div><a href="index.php?do=lostpassword">Esqueceu sua senha ?</a></div>
                                <div id="more-info"><div id="bullet"></div><a href="http://www.iplayogforums.com/forumdisplay.php?53-Account-Support">Tem algum problema ?</a>
                                </div>
                        </div>
                    </div>
                    <div id="sidebar-bottom"></div>
                </div>

							<input type="hidden" name="submit" value="1">
							</form>

<?
}else{
//And again.
$res = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$d = mssql_fetch_assoc($res);

//No shit?
$res2 = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$numitems = mssql_num_rows($res2);
?>

                <div id="sidebar">
                	<div id="sidebar-top">
                    	<div id="side-title">USER PANEL</div>
                    </div>
                    <div id="sidebar-cent">
                    	<div id="side-cont">
                    		<div id="date-status">Bem vindo <?=$_SESSION['UserID']?> !</div>
                            <hr />
                        <div class="options">
                        	<div class="g-coin">Voce tem <span><?=$d['RZCoins']?></span> DG Coins.</div>
                            <div class="s-coin">Voce tem <span><?=$d['EVCoins']?></span> Event Coins.</div>
                        </div>

                        <a href="index.php?do=usercp"><div class="panel-btn">User - Painel de Controle</div></a>
                        <a href="index.php?do=clancp"><div class="panel-btn">Clan - Painel de Controle</div></a>
                        <a href="settings.php"><div class="rank-btn" style="float: left; margin-top: 12px;">OPCOES</div></a>
                        <a href="index.php?do=login&action=logout&header=1"><div class="rank-btn-right" style="margin-top: 12px;" >SAIR</div></a>
							
                       <br class="clear" />
                        
                        </div>
                    </div>
                    <div id="sidebar-bottom"></div>
                </div>
                <!-- Login Ends -->

<?
}
?>