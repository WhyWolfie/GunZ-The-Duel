<div id="column3">
        <div class="itemday">
		<?php
	 $getnedksfs = mssql_query("SELECT TOP 1* FROM ShopDonator ORDER BY CSSID DESC");
	 $newitmed = mssql_fetch_object($getnedksfs);
	?>
             <div class="img_itemday"><img src="images/shop/<?php echo $newitmed->ImageURL; ?>" width="119" height="99"></div>
             <div class="ver_itemday"> <a href="index.php?do=buydonator&itemid=<?php echo $newitmed->CSSID; ?>&cat=">View</a></div>
          </div>
		  
		  <br /> 
          <div class="video"><iframe width="270" height="160" src="//www.youtube.com/embed/MWtFZ_2TDdQ" frameborder="0" allowfullscreen></iframe></div>
          <a href="index.php?do=donator" target="_blank"><img src="images/donate.png" width="295" height="99"></a>
		  <a href="" target="_blank"><img src="images/forum.png" width="295" height="99"></a>
 </div><!-- end col 3-->