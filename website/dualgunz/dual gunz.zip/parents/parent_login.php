        <div id="column1">
		<?
if($_SESSION[AID] == "")
{
?>
<form name="login" method="POST" action="index.php?do=login">
<!--Login-->
<table class="login" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="180"><div>&nbsp;&nbsp;<input name="userid" tabindex="1" required="required" 
	style=" margin-top:7px; margin-left:6px; border: 0pt none ; background-color: transparent; height: 20px; width: 170px; color: rgb(202, 202, 202); text-shadow: 0px 1px 0px #ffffff; font-size:11px; outline:none;" size="25" maxlength="16"></div></td>
	
	 <td width="86" rowspan="2"><input style="margin-top:8px;" id="img812" name="img812" alt="Login" title="Login" src="images/panel_entrar_off.jpg" height="59" type="image" width="85"></td>
  </tr>
    <tr>
    <td>&nbsp;&nbsp;<input name="pass" type="password" tabindex="2" required="required" size="25" style="margin-top:12px; margin-left:3px; border: 0pt none ; background-color: transparent; height: 20px; width: 170px; color: rgb(202, 202, 202); text-shadow: 0px 1px 0px #ffffff; font-size:11px; outline:none;" maxlength="16"></td>
    </tr>
	 <tr>

    <td colspan="2">&nbsp;&nbsp;<input name="" value="remember" type="checkbox"> <span style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-weight: bold;font-size:12px;">Keep me logged in</span></td>
    </tr>


	<tr>
   <td colspan="2"> 
&nbsp;&nbsp; <a href="index.php?do=register"><img style="border: 0px solid ; width: 128px; height: 40px;" alt=" " src="images/register.png"></a> &nbsp; 
<a href="index.php?do=resetpwd"><img style="border: 0px solid ; width: 128px; height: 40px;" alt="" src="images/recover.png"></a>
</td>
    </tr>
	<input type="hidden" name="submit" value="1" />
</table>
</form>
<?
}else{

    $query2 = mssql_query_logged("SELECT Coins, EventCoins FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
    $_MEMBER[AccountData]   = mssql_fetch_assoc($query2);
?>
<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("imageclan");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "/emblems/upload/" + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>
<table class="UPanelBox" width="192" border="0" cellspacing="0" cellpadding="0" style="font-family:Arial;color:#646464; font-size: 13px;">
  <tr>
    <td>
<p style="margin-top:-20px;">&nbsp; <font style="color:#fff;"><b>Welcome, </font><font style="color:#2E9AFE;"><?=$_SESSION[UserID]?></font><a href="index.php?do=logout"><font style="color:#7c7c7c;font-size:11px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Exit</font></a></b></p>

	<br />
	&nbsp;&nbsp;<a href="index.php?do=editaccount"><font style="color:#FFFF00; font-size: 11px;" >Edit Data</font></a> - <a target="_blank" href="/emblems/"><font style="color:#FFFF00; font-size: 11px;" >EmblemsClan</font></a><br />

	<br />
	<font style="color:#FFFF00; font-size: 11px;"> <b> &nbsp;&nbsp; Event Coins:</b> </font><font style="color:#fff;" ><strong> <?=$_MEMBER[AccountData][Coins]?> </strong></font> <br /> 
	<font style="color:#FFFF00; font-size: 11px;"><b>&nbsp;&nbsp; Donator Coins:</b> </font><font style="color:#fff;" ><strong> <?=$_MEMBER[AccountData][EventCoins]?> </strong></font> <br />
	<br />	<br /><br />	

	&nbsp;&nbsp;<?if($_SESSION['UGradeID'] == 255) {
	  
	  echo '  <a style="color:#fff;font-size:11px;" target="_blank" href="/owner/">CPanel Owner </a> ';
	  echo"-"; 
	}
	if($_SESSION['UGradeID'] == 255 OR $_SESSION['UGradeID'] == 254){
	  
	  echo '  <a style="color:#fff;font-size:11px;" target="_blank" href="/administrador/">CPanel Admin</a> '; 
	}?>
	</td>


	                                                <?
                                                    if(CheckIfExistClan($_SESSION[AID]))
                                                    {
                                                    ?>
															<td class="clanpositionnumber">
															<img id="imageclan" src="images/noemblem.png" width="70" height="70" style="border: 1px solid #000000"></td>

<td class="namemasterclan">
															<select class="iptbox2" onChange="UpdateClan()" id="clanlist" size="1" name="selclan" style="color: #000; font-family: Verdana; font-size: 7pt; border: 1px solid #000000;">
															<option>Select the clan</option>
															<?
                                                            $qr = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
                                                            if( mssql_num_rows($qr) > 0 )
                                                            {
                                                            while($char = mssql_fetch_assoc($qr))
                                                            {
                                                                     $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
                                                                     if( mssql_num_rows($queryc) > 0 )
                                                                     {
                                                                        $a = mssql_fetch_assoc($queryc);
                                                                        $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));

                                                                         $_CLAN[Name]       = $b[Name];
                                                                         $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
                                                                         $_CLAN[CLID]       = $a[CLID];
                                                                         $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "/emblems/upload/noemblem.jpg" : $b[EmblemUrl];

                                                                         $info = implode("-|-", $_CLAN);

                                                                         if($_CLAN[Name] <> "")
                                                                            echo "
																			<option value = '$info'>{$_CLAN[Name]}</option>
																			";
                                                                     }
                                                                }
                                                            }
                                                            ?>
															</select>


<span style="font-size: 7pt; color:#fff;"> <br />M: </span><span style="font-size: 11pt; color:#2E9AFE;"><span id="clanmaster"></span></span>
																
															</td>	
													 <?
                                                    }else{
                                                    ?>
 
                                                    <?
                                                    }
                                                    ?>

	
	</td>
    <td align="right" valign="top"></td>
  </tr>
</table>
<?
}
?>
                	<!-- end login-->
            <div class="toprankBox">
            	<div class="moretop">
                <a href="index.php?do=individualrank"><img src="images/more_btn.png" align="right" style="margin-top:9px; margin-right: 17px;"></a>
                </div>
                <table width="261" border="0" align="center">
           <tbody>
		     <tr>
               <td height="29" align="right" valign="middle" class="center">#</td>
               <!--<td valign="middle">DT</td>-->
			   <td valign="middle">NAME</td>
               <td valign="middle">LV.</td>
             </tr> 
<?
$query = mssql_query("SELECT TOP 7 * FROM Account a, Character b WHERE b.AID=a.AID AND a.UGradeID !=255|254|253|252 AND  DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");



									$count = 1;
while($query2 = mssql_fetch_assoc($query))
{
 

 
 /*
$rgbcolor = mssql_query("SELECT RedColor, GreenColor, BlueColor FROM Account");
$rgbcolorname = mssql_fetch_row($rgbcolor );


$r = $rgbcolorname['RedColor'];
$g = $rgbcolorname['GreenColor'];
$b = $rgbcolorname['BlueColor'];
*/

?>			 
             <tr>
               <td align="right" class="cntr"><?=$count?></td>
			   <!--<td><img src="<?=$dtquery3?>" width="15" height="15"></td>-->
			   
               <td><?=$query2['Name']?></td>
               
               <td><?=$query2['Level']?>&nbsp;Lv.</td>
             </tr>
			 <?
			 $count++;
			 }
			 ?>	
           </tbody></table>
		   </div><!-- top rank-->
          <div class="toprankClanBox">
            	<div class="moretop">
                <a href="index.php?do=clanrank"><img src="images/more_btn.png" align="right" style="margin-top:9px; margin-right: 17px;"></a>
                </div>
                <table width="261" border="0" align="center">
           <tbody>
		     <tr>
               <td height="29" align="right" valign="middle" class="cntr">#</td>
               <td valign="middle">EM</td>
			   <td valign="middle">NAME</td>
               <td valign="middle">POINT.</td>
             </tr> 	
 <?
$res = mssql_query("SELECT TOP 7 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");


                                    if(mssql_num_rows($res) == 0){
?>

<div align="left" class="Estilo2">No data</div></td>
<?
                                    }else{
                                    
   $count = 1;
                                    while($clan = mssql_fetch_assoc($res)){
?>              
                     	 
             <tr>
               <td align="right" class="cntr"><?=$count?></td>
		<td><img width="15" height="15" src="http://www.gunz.dualgames.net/emblems/upload/<?=($clan['EmblemUrl'] == "") ? 'noemblem.png' : $clan['EmblemUrl']?>"></td>
               <td><?=$clan['Name']?></td>
               <td><?=number_format($clan['Point'],0,'','');?>Pts.</td>
             </tr>
			 <?
			 $count++;
			 }}
			 ?>
           </tbody></table>
            </div>
        </div><!--  end Columna 1-->