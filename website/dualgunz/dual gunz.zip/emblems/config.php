<?php
include("secure/anti_inject.php");
include("secure/sql_check.php");
include("secure/anti_sql.php");
include("secure/anti_inject_sql.php");
include("secure/inject.php");
include("secure/banneduser.php");
include("secure/checkcookie.php");
include("secure/ctracker.php");
include("secure/equipt.inc.php");
require("secure/criminalteam.php");

/////Lo editamos con nuestros datos
$DBHost = "76.73.59.75";
$DBUser = 'miguel_23';
$DBPass = 'camila18%%**';
$DB = 'DualST';
?>