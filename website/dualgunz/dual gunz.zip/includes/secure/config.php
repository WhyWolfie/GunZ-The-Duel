<?
@session_start();
//Mssql config Web HG
$_MSSQL[Host]               = "TU-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "Pass";
$_MSSQL[DBNa]               = "GunzDB";
@$r = mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
@mssql_select_db($_MSSQL[DBNa], $r);


//Staff UGradeID's
$admin  = 255;  //Administrator
$gm     = 254;  //GameMaster
$dev    = 252;  //Developer
$member = 0;    //Member
$banned = 253;  //Banned

//Color Names
$admin_col  = "#FF0019";  //Administrator
$gm_col     = "#FF9900";  //GameMaster
$fm_col     = "#11D618";  //Forum Moderator
$dev_col    = "#33FFFF";  //Developer
$don_col    = "#FFEA00";  //Donator
$member_col = "#d5d4d4";  //Member
$banned_col = "#000000";  //Banned
?>