<?
include 'includes/secure/config.php';
include "includes/secure/functions.php";
include "includes/secure/sql_check.php";
include "includes/secure/anti_sql.php";  

if(!empty($_SESSION['AID']))
{
$_SESSION['AID'] = limpiar($_SESSION['AID']);

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{

$chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");
						
    if( mssql_num_rows($chkq) != 1 )
    {

        session_unset();
        session_destroy();
		msgbox ("Invalid Account Access","index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
			msgbox ("Invalid Account Access","index.php");
            die();
        }
    }
}
}

	$ipusuario = $ip;
	$select = "SELECT * FROM WebIpBan WHERE ip = '".$ipusuario."'";
	$query = mssql_query($select);
	$rows = mssql_num_rows($query);
	if($rows<1)
	{
		
	}else{
		$row = mssql_fetch_array($query);
		?>
			<h1>
		You IP: <b>(<?=$_SERVER['REMOTE_ADDR']?></b>) is banned from <?echo $server_name;?><br></h1>
		<h2>Reason: <b><?=$row['razon']?></b><br>
		Banned Time: <b><?=$row['fecha']?></b><br>
		Plase Contacte to Administrador! <a href="gunz.dualgames.net"></a></h2>
		<?
		die("");
	    }
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" lang="ES">
<head>
<meta http-equiv="Content-Type" content="charset=utf-8" />
<meta name="description" content="Have fun on the server of Gunz: The Duel, is completely free!" />
       <title>:: DualGames::</title>
<link href="favicon.png" rel="shortcut icon" />
<link rel="stylesheet" type="text/css" href="css/main.css" /> 
<base href="/" /> 
<script src="js/shop.js" type="text/javascript"></script>
<style type="text/css">
.cntr {
	text-align: center;
}
</style>
</head>
<body>
	<div class="headbg">
    <div>
	<div>Online User: <span style="color:#0080FF; font-size:25px;">&nbsp;<?
$uTime = 5;
$data = file_get_contents("logs/playercount.txt");

$asd = explode("/", $data);
$time = $asd[0]; // Valor de tiempo en el txt
$players = $asd[1]; // Valor de Jugadores Online en el txt

$currtime = time();

if(($currtime - $time) > $uTime)
{

    $res = mssql_query_logged("SELECT * FROM serverstatus(nolock) WHERE Opened = 1");
    $countplayers = 0;

    while($a = mssql_fetch_assoc($res))
    {
        $countplayers = $countplayers + $a[CurrPlayer];
    }

    $towrite = sprintf("%s/%s", time(), $countplayers);

    $a = fopen("logs/playercount.txt", "w+");
    fwrite($a, $towrite); // Se escribe el archivo con los nuevos datos
    fclose($a); // Se cierra el archivo

    echo "$countplayers";
}else{

    echo "$players";
}
?></span> &nbsp;(<span style="color:#FF0000; font: 70% sans-serif; ">RECORD</span> <span style="color:#0080FF;">
	        <?
			$query2 = mssql_query("SELECT TOP 1 * FROM ServerLog ORDER BY PlayerCount DESC");
			$r = mssql_fetch_row($query2);
			echo $query2 = $r[2];
			?></span>)</div>
	<div><span>Server Status: <span style="color:#03F503;">Online</span></span></div>
     </div>
	</div>
<div class="headimage"></div>

    <div class="navbar">
    	<a href="index.php">
    	<img src="images/nav/home_off.jpg" onmouseover="javascript:this.src='images/nav/home_on.jpg';" onmouseout="javascript:this.src='images/nav/home_off.jpg';">
    	</a>
    	<a href="index.php?do=register">
    	<img src="images/nav/register_off.jpg" onmouseover="javascript:this.src='images/nav/register_on.jpg';" onmouseout="javascript:this.src='images/nav/register_off.jpg';">
    	</a>
    	<a href="index.php?do=download">
    	<img src="images/nav/download_off.jpg" onmouseover="javascript:this.src='images/nav/download_on.jpg';" onmouseout="javascript:this.src='images/nav/download_off.jpg';">
    	</a>
    	<a href="index.php?do=shopdonator">
    	<img src="images/nav/shop_off.jpg" onmouseover="javascript:this.src='images/nav/shop_on.jpg';" onmouseout="javascript:this.src='images/nav/shop_off.jpg';">
    	</a>
    	<a href="index.php?do=clanrank">
    	<img src="images/nav/ranking_off.jpg" onmouseover="javascript:this.src='images/nav/ranking_on.jpg';" onmouseout="javascript:this.src='images/nav/ranking_off.jpg';">
    	</a>
   	<a href=" ">
   	<img src="images/nav/forums_off.jpg" onmouseover="javascript:this.src='images/nav/forums_on.jpg';" onmouseout="javascript:this.src='images/nav/forums_off.jpg';">
   	</a>
    </div>
   <div id="wrapper">
<div id="main">
<?
            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }
                if(file_exists("enigma/enig_$do.php"))
                {
                    include "enigma/enig_$do.php";
					//Check IPBan and ban();
                    CheckIsBanned();
                }else{
                   Error_do();
                }

            }else{
                include "enigma/enig_off.php";
            }
?>
</div>
	<br /><br /><br />
    <div id="footer"></div>
	<br /><br />
</div>
<script type="text/javascript" src="http://www.jimdo.com/l/usersnippets/snowfall.min.js"></script>
</body></html>