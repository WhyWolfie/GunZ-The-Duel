<?

if ($_GET[sex] == ""){

$sexq = "";

}else{

$sexq = "WHERE Sex = '".strtolower(clean($_GET[sex]))."'";

}

$sex = strtolower(clean($_GET[sex]));

$res = mssql_query_logged("SELECT * FROM ShopSets(nolock) ".$sexq." ORDER BY SSID DESC");

$count = 1;
$page = 1;
while( $a = mssql_fetch_object( $res ) ){
    $set[$count][$page]['SSID']         =  $a->SSID;
    $set[$count][$page]['Name']         =  $a->Name;
    $set[$count][$page]['Level']        =  $a->Level;
    $set[$count][$page]['Price']        =  $a->Price;
    $set[$count][$page]['Sex']          =  $a->Sex;
    $set[$count][$page]['ImageURL']     =  $a->ImageURL;

    if ( $count == 6 ){
        $count = 1;
        $page++;
    }else{
        $count++;
    }
}

$cpage = ($_GET[page] == "") ? 1 : $_GET[page];

if($cpage > $page)
{
           msgbox ("Incorrect page number","index.php?do=shopsets");
    die();
}else if(!is_numeric($cpage))
{
           msgbox ("Incorrect page number","index.php?do=shopsets");
    die();
}

for ($i = 1; $i <= $page; $i++) {
    if($cpage == $i){
        $prefix = "<font color='#00FF00'><b>";
        $sufix = '</b></font>';
    }else{
        $prefix = "";
        $sufix = '';
    }
    $pagelinks.="[<a href='index.php?do=shopsets&page=$i&sex=$sex'>$prefix$i$sufix</a>] ";
}

$Type ="Set Complete";

include "parents/parent_login.php";
?>
<div id="column2">
                 <div class="importantann">
          <div class="RankingBox">

<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; color:#fff;" width="603">
								<tbody><tr>
									<td height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-position: center; background-color:#585858; width:100%; height:0px; border-radius:10px;" width="583" valign="top">
										<p align="Center">
                                            <ul class="group" id="example-one" align="center">
                                                <li><a href="index.php?do=shopdonator"><h2>SHOPDONATOR</h2></a></li>
                                                <li><a href="index.php?do=shopevent"><h2>SHOPEVENT</h2></a></li>
                                                <li><a href="index.php?do=shopsets" style="color:#fff;"><h2>COMPLETESETS</h2></a></li>
                                                <li><a href="index.php?do=shopspecial"><h2>SHOPSPECIAL</h2></a></li>
                                            </ul>
                                        </p>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
									<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" width="100%" height="100%">
											<tbody><tr>
												<td>
												<div align="center">
							<table border="0" width="603">
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse;" width="100%" height="100%">
											<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                    <?
                                                                    if($set[1][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[1][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[1][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[1][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[1][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[1][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center"> 

<a href="index.php?do=buyset&setid=<?=$set[1][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1773111" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1773111',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                     </td>
																					 </div>
																				</tr>
																			</table>
																			</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                    <?
                                                                    if($set[2][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[2][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[2][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[2][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[2][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[2][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center"> 

<a href="index.php?do=buyset&setid=<?=$set[2][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1a7723" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1a7723',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                   </div>
                                                                                </td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                    <?
                                                                    if($set[3][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[3][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[3][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[3][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[3][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[3][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">

<a href="index.php?do=buyset&setid=<?=$set[3][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img177xDD3" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img177xDD3',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                     </div>
																					 </td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                     <?
                                                                    if($set[4][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[4][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[4][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[4][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[4][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[4][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center"> 

<a href="index.php?do=buyset&setid=<?=$set[4][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1asdasddasd22773" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1asdasddasd22773',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                 </div>
																				 </td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                     <?
                                                                    if($set[5][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[5][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[5][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[5][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[5][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[5][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">

<a href="index.php?do=buyset&setid=<?=$set[5][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="im2XDDg1773" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'im2XDDg1773',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                         </div>
																						 </td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                     <?
                                                                    if($set[6][$cpage]['Name'] <> "")
                                                                    {
                                                                    ?>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$set[6][$cpage]['ImageURL']?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span style="Font-size:25px; color:#585858;"><?=$set[6][$cpage]['Name']?></span></b></div></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Type:</td>
																					<td width="111"><?echo $Type?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Sex:</td>
																					<td width="111"><?=$set[6][$cpage]['Sex']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left">Level:</td>
																					<td width="111"><?=$set[6][$cpage]['Level']?></td>
																				</tr>
																				<tr>
																					<td width="55" align="left" style="color:#00FF00;">Price:</td>
																					<td width="111" style="color:#00FF00;">$<?=$set[6][$cpage]['Price']?></td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">

<a href="index.php?do=buyset&setid=<?=$set[6][$cpage]['SSID']?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="im2XDDg1773" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'im2XDDg1773',/*url*/'images/btn_buyset_on.jpg')"></a>
                                                                                         </div>
																						 </td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
                                                                    <?
                                                                    }
                                                                    ?>
																</table>
															</div>
															</td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
										</table>
									</div>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center"><br /><?=$pagelinks?></div></td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
							</table>
						</div>
						</td>
								</tr>
								
								
								
								
								
										</tbody></table>

									</div></tr></tbody></table></div></div></div></div>
									
<?
include "parents/parent_login2.php";
?>