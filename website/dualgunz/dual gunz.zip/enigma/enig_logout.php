<?
include "includes/secure/anti_sql.php";
include "includes/secure/sql_check.php";

if($_SESSION[AID] <> "")
{
    $u = $_SESSION[UserID];

    session_unset();
    session_destroy();
msgbox ("User $u Properly Offline","index.php");
    die();
}else{
msgbox ("Can not Let You Go offline No These Online!","index.php");
    die();
}
?>