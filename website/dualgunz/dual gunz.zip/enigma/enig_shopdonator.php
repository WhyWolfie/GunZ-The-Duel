<?
$sex = ($_GET[sex] == "") ? "2" : strtolower(clean($_GET[sex]));
$sex = ($sex < 0 || $sex > 2) ? "0" : $sex;

$sort = ($_GET[sort] == "") ? "0" : strtolower(clean($_GET[sort]));

$bodypart = ($_GET[bodypart] == "") ? "0" : strtolower(clean($_GET[bodypart]));
$bodypart = ($bodypart < 0 || $bodypart > 4) ? "0" : $bodypart;

if($sex == 2 && $bodypart == 0)
{
    $conditions = "";
}
elseif($sex == 2 && $bodypart != 0)
{
    $conditions = "WHERE BodyPart = $bodypart";
}
elseif($sex != 2 && $bodypart == 0)
{
    $conditions = "WHERE Sex = $sex";
}
elseif($sex != 2 && $bodypart != 0)
{
    $conditions = "WHERE Sex = $sex AND BodyPart = $bodypart";
}

switch ($sort)
{
    case 0:
    $sortq = "ORDER BY CSSID DESC";
    break;
    case 1:
    $sortq = "ORDER BY CSSID ASC";
    break;
    case 2:
    $sortq = "ORDER BY Level ASC";
    break;
    case 3:
    $sortq = "ORDER BY Level DESC";
    break;
    case 4:
    $sortq = "ORDER BY Price ASC";
    break;
    case 5:
    $sortq = "ORDER BY Price DESC";
    break;
    default:
    $sortq = "ORDER BY CSSID DESC";
    break;
}

$res = mssql_query_logged("SELECT * FROM ShopDonator(nolock) $conditions $sortq");
$count = 1;
$page = 1;
while( $a = mssql_fetch_object( $res ) ){

    $set[$count][$page]['SSID']         =  $a->CSSID;
    $set[$count][$page]['Name']         =  $a->Name;
    $set[$count][$page]['Level']        =  $a->Level;
    $set[$count][$page]['Price']        =  $a->Price;
    $set[$count][$page]['Sex']          =  $a->Sex;
    $set[$count][$page]['ImageURL']     =  $a->ImageURL;

    if ( $count == 4 ){
        $count = 1;
        $page++;
    }else{
        $count++;
    }

}

$cpage = ($_GET[page] == "") ? 1 : $_GET[page];

if($cpage > $page)
{
        msgbox ("Incorrect page number","index.php?do=shopdonator");
}else if(!is_numeric($cpage))
{
        msgbox ("Incorrect page number","index.php?do=shopdonator");
}

for ($i = 1; $i <= $page; $i++) {
    if($cpage == $i){
        $prefix = "<font color='#00FF00'><b>";
        $sufix = '</b></font>';
    }else{
        $prefix = "";
        $sufix = '';
    }
    $pagelinks.="[<a href='index.php?do=shopdonator&page=$i&sex=$sex&sort=$sort&bodypart=$bodypart'>$prefix$i$sufix</a>] ";
}

$type = "Donator Coins";

include "parents/parent_login.php";
?>
<div id="column2">
                 <div class="importantann">
          <div class="RankingBox">

<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; color:#fff;" width="603">
								<tbody><tr>
									<td height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-position: center; background-color:#585858; width:100%; height:0px; border-radius:10px;" width="583" valign="top">
										<p align="Center">
                                            <ul class="group" id="example-one" align="center">
                                                <li><a href="index.php?do=shopdonator" style="color:#fff;"><h2>SHOPDONATOR</h2></a></li>
                                                <li><a href="index.php?do=shopevent"><h2>SHOPEVENT</h2></a></li>
                                                <li><a href="index.php?do=shopsets"><h2>COMPLETESETS</h2></a></li>
                                                <li><a href="index.php?do=shopspecial"><h2>SHOPSPECIAL</h2></a></li>
                                            </ul>
                                        </p>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" width="100%" height="100%">
											<tbody><tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tbody><tr>
															<td width="289" valign="top"><div align="center">
															  <table border="0" style="border-collapse: collapse" width="287" height="100%">
															    <tbody><tr>
															      <td width="8">&nbsp;</td>
															      <td width="95">&nbsp;</td>
															      <td width="178">&nbsp;</td>
														        </tr>
																<?
                                                                    if($set[1][$cpage]['Name'] <> "")
                                                                    {
                                                                ?>
															    <tr>
															      <td width="8">&nbsp;</td>
															      <td width="95" valign="top"><img border="0" src="images/shop/<?=$set[1][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516" /></td>
															      <td width="178" valign="top"><div align="center">
															        <table border="0" style="border-collapse: collapse" width="170">
															          <tbody>
															          <tr>
															            <td width="168" colspan="2"><div align="left">
															              <b><span style="Font-size:25px; color:#585858;"><?=$set[1][$cpage]['Name']?></span></b></div></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Cash: </td>
															            <td width="111"><?=$type?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Sex: </td>
															            <td width="111"><?=GetSexByID($set[1][$cpage]['Sex']);?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Level: </td>
															            <td width="111"><?=$set[1][$cpage]['Level'] ?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left" style="color:#00FF00;">Price: </td>
															            <td width="111" style="color:#00FF00;">$<?=$set[1][$cpage]['Price'] ?></td>
														              </tr>
															          <tr>
															            <td width="166" colspan="2">&nbsp;</td>
														              </tr>
															          <tr><td width="166" colspan="2"><div align="center">
															            <table style="width: 166px; height: 100%" cellpadding="0">
															              <tbody>
																		  <tr>
<!--<td style="width: 55px"><a href="index.php?do=giftdonator&itemid=<?=$set[1][$cpage]['SSID']?>&cat=<?=$cat?>"><img border="0" id="76286ns7b2" src="images/btn_giftitem_off.jpg" width="50" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b2',/*url*/'images/btn_giftitem_on.jpg')"></a></td>-->
<td style="width: 55px"> <a href="index.php?do=buydonator&itemid=<?=$set[1][$cpage]['SSID']?>&cat=<?=$cat?>"> <img border="0" id="76286ns7b4" src="images/btn_buyitem3_off.jpg" width="52" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b4',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>				
																		  </tr>
														                </tbody></table>
															            &nbsp;</div></td>
															            </tr>
															          <tr>
															            <td width="55">&nbsp;</td>
															            <td width="111">&nbsp;</td>
														              </tr>
														            </tbody></table>
															        </div></td>
														        </tr>
																<?
                                                                    }
                                                                ?>
														      </tbody></table>
														    </div></td>
															<td width="290" valign="top">
															<div align="center">
															  <table border="0" style="border-collapse: collapse" width="287" height="100%">
															    <tbody><tr>
															      <td width="8">&nbsp;</td>
															      <td width="95">&nbsp;</td>
															      <td width="178">&nbsp;</td>
														        </tr>
																<?
                                                                    if($set[2][$cpage]['Name'] <> "")
                                                                    {
                                                                ?>
															    <tr>
															      <td width="8">&nbsp;</td>
															      <td width="95" valign="top"><img border="0" src="images/shop/<?=$set[2][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516" /></td>
															      <td width="178" valign="top"><div align="center">
															        <table border="0" style="border-collapse: collapse" width="170">
															          <tbody><tr>
															            <td width="168" colspan="2"><div align="left">
															              <b><span style="Font-size:25px; color:#585858;"><?=$set[2][$cpage]['Name']?></span></b></div></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Cash: </td>
															            <td width="111"><?=$type?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Sex: </td>
															            <td width="111"><?=GetSexByID($set[2][$cpage]['Sex']);?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Level: </td>
															            <td width="111"><?=$set[2][$cpage]['Level']?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left" style="color:#00FF00;">Price: </td>
															            <td width="111" style="color:#00FF00;">$<?=$set[2][$cpage]['Price']?></td>
														              </tr>
															          <tr>
															            <td width="166" colspan="2">&nbsp;</td>
														              </tr>
															          <tr><td width="166" colspan="2"><div align="center">
															            <table style="width: 166px; height: 100%" cellpadding="0">
															              <tbody>
																		 <tr>
<!--<td style="width: 55px"><a href="index.php?do=giftdonator&itemid=<?=$set[2][$cpage]['SSID']?>&cat=<?=$cat?>"><img border="0" id="76286ns7b2" src="images/btn_giftitem_off.jpg" width="50" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b2',/*url*/'images/btn_giftitem_on.jpg')"></a></td>-->
<td style="width: 55px"> <a href="index.php?do=buydonator&itemid=<?=$set[2][$cpage]['SSID']?>&cat=<?=$cat?>"> <img border="0" id="76286ns7b4" src="images/btn_buyitem3_off.jpg" width="52" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b4',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>						
																		  </tr>
														                </tbody></table>
															            &nbsp;</div></td>
															            </tr>
															          <tr>
															            <td width="55">&nbsp;</td>
															            <td width="111">&nbsp;</td>
														              </tr>
														            </tbody>
																	</table>
															        </div></td>
														        </tr>
																<?
                                                                    }
                                                                ?>
														      </tbody></table>
														    </div>
															</td>
														     </tr>
																</tbody></table>
															</div>
															</td>
														</tr>
														<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tbody><tr>
															<td width="289" valign="top"><div align="center">
															  <table border="0" style="border-collapse: collapse" width="287" height="100%">
															    <tbody><tr>
															      <td width="8">&nbsp;</td>
															      <td width="95">&nbsp;</td>
															      <td width="178">&nbsp;</td>
														        </tr>
															    <?
                                                                    if($set[3][$cpage]['Name'] <> "")
                                                                    {
                                                                ?>
															    <tr>
															      <td width="8">&nbsp;</td>
															      <td width="95" valign="top"><img border="0" src="images/shop/<?=$set[3][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516" /></td>
															      <td width="178" valign="top"><div align="center">
															        <table border="0" style="border-collapse: collapse" width="170">
															          <tbody><tr>
															            <td width="168" colspan="2"><div align="left">
															              <b><span style="Font-size:25px; color:#585858;"><?=$set[3][$cpage]['Name']?></span></b></div></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Cash: </td>
															            <td width="111"><?=$type?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Sex: </td>
															            <td width="111"><?=GetSexByID($set[3][$cpage]['Sex']);?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Level: </td>
															            <td width="111"><?=$set[3][$cpage]['Level']?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left" style="color:#00FF00;">Price: </td>
															            <td width="111" style="color:#00FF00;">$<?=$set[3][$cpage]['Price']?></td>
														              </tr>
															          <tr>
															            <td width="166" colspan="2">&nbsp;</td>
														              </tr>
															          <tr><td width="166" colspan="2"><div align="center">
															            <table style="width: 166px; height: 100%" cellpadding="0">
															              <tbody>
																		 <tr>
<!--<td style="width: 55px"><a href="index.php?do=giftdonator&itemid=<?=$set[3][$cpage]['SSID']?>&cat=<?=$cat?>"><img border="0" id="76286ns7b2" src="images/btn_giftitem_off.jpg" width="50" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b2',/*url*/'images/btn_giftitem_on.jpg')"></a></td>-->
<td style="width: 55px"> <a href="index.php?do=buydonator&itemid=<?=$set[3][$cpage]['SSID']?>&cat=<?=$cat?>"> <img border="0" id="76286ns7b4" src="images/btn_buyitem3_off.jpg" width="52" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b4',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>						
																		  </tr>
														                </tbody></table>
															            &nbsp;</div></td>
															            </tr>
															          <tr>
															            <td width="55">&nbsp;</td>
															            <td width="111">&nbsp;</td>
														              </tr>
														            </tbody>
																	</table>
															        </div></td>
														        </tr>
																<?
                                                                    }
                                                                ?>
														      </tbody></table>
														    </div></td>
															<td width="290" valign="top">
															<div align="center">
															  <table border="0" style="border-collapse: collapse" width="287" height="100%">
															    <tbody><tr>
															      <td width="8">&nbsp;</td>
															      <td width="95">&nbsp;</td>
															      <td width="178">&nbsp;</td>
														        </tr>
															     <?
                                                                    if($set[4][$cpage]['Name'] <> "")
                                                                    {
                                                                ?>
															    <tr>
															      <td width="8">&nbsp;</td>
															      <td width="95" valign="top"><img border="0" src="images/shop/<?=$set[4][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516" /></td>
															      <td width="178" valign="top"><div align="center">
															        <table border="0" style="border-collapse: collapse" width="170">
															          <tbody><tr>
															            <td width="168" colspan="2"><div align="left">
															              <b><span style="Font-size:25px; color:#585858;"><?=$set[4][$cpage]['Name']?></span></b></div></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Cash: </td>
															            <td width="111"><?=$type?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Sex: </td>
															            <td width="111"><?=GetSexByID($set[4][$cpage]['Sex']);?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left">Level: </td>
															            <td width="111"><?=$set[4][$cpage]['Level']?></td>
														              </tr>
															          <tr>
															            <td width="55" align="left" style="color:#00FF00;">Price: </td>
															            <td width="111" style="color:#00FF00;">$<?=$set[4][$cpage]['Price']?></td>
														              </tr>
															          <tr>
															            <td width="166" colspan="2">&nbsp;</td>
														              </tr>
															          <tr><td width="166" colspan="2"><div align="center">
															            <table style="width: 166px; height: 100%" cellpadding="0">
															              <tbody>
																		 <tr>
<!--<td style="width: 55px"><a href="index.php?do=giftdonator&itemid=<?=$set[4][$cpage]['SSID']?>&cat=<?=$cat?>"><img border="0" id="76286ns7b2" src="images/btn_giftitem_off.jpg" width="50" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b2',/*url*/'images/btn_giftitem_on.jpg')"></a></td>-->
<td style="width: 55px"> <a href="index.php?do=buydonator&itemid=<?=$set[4][$cpage]['SSID']?>&cat=<?=$cat?>"> <img border="0" id="76286ns7b4" src="images/btn_buyitem3_off.jpg" width="52" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76286ns7b4',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>
																		  </tr>
														                </tbody></table>
															            &nbsp;</div></td>
															            </tr>
															          <tr>
															            <td width="55">&nbsp;</td>
															            <td width="111">&nbsp;</td>
														              </tr>
														            </tbody>
																	</table>
															        </div></td>
														        </tr>
																<?
                                                                    }
                                                                ?>
														      </tbody></table>
														    </div>
															</td>
														</tr>
																</tbody></table>
															</div>
															</td>
														</tr>
                                                        <tr>
												<td>
												<div align="center"><?=$pagelinks?></div>
															</td>
														</tr>
													</tbody></table>
												</div>
												</td>
											</tr>
										</tbody></table>

									</div></div></div></div>
									
<?
include "parents/parent_login2.php";
?>