<?
include "includes/secure/anti_sql.php";
include "includes/secure/sql_check.php";

if($_SESSION[AID] != "")
{
    re_dir("index.php");
    die();
}

if(isset($_POST[submit]))
{
    $user = limpiar($_POST[userid]);
    $pass = limpiar($_POST[pass]);
    $ip = $_SERVER['REMOTE_ADDR'];
    // Borrar fails antiguos tablas de esto son  IP, UserID, Time las 3 en varchar(500)
    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
    // Buscar fails para la ip actual
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
	msgbox ("You have failed to login 5 times in the last 15 minutes","index.php");
        die();
    }

    $loginquery = mssql_query_logged("SELECT l.UserID, l.AID, c.UGradeID, l.Password FROM Login(nolock) l INNER JOIN Account(nolock) c ON l.AID = c.AID WHERE l.UserID = '$user' AND l.Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];
        $_SESSION[Password] = md5(md5($logindata[3]));

        $url = ($_SESSION[URL] == "") ? "index.php" : $_SESSION[URL];
        $_SESSION[URL] = "";

        re_dir("$url");
        die();
    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
			msgbox ("Incorrect User ID or Password","index.php?do=login");
        die();
    }
}
include "parents/parent_login.php";
?>
<div id="column2">
<form method="POST" action="index.php?do=login" name="login">
<!-- MODULO ERROR LOGIN -->
<table class="login" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="180"><div>&nbsp;&nbsp;<input name="userid" tabindex="1" required="required" 
	style=" margin-top:7px; margin-left:6px; border: 0pt none ; background-color: transparent; height: 20px; width: 170px; color: rgb(202, 202, 202); text-shadow: 0px 1px 0px #ffffff; font-size:11px; outline:none;" size="25" maxlength="16"></div></td>
	
	 <td width="86" rowspan="2"><input style="margin-top:8px;" id="img812" name="img812" alt="Login" title="Login" src="images/panel_entrar_off.jpg" height="59" type="image" width="85"></td>
  </tr>
    <tr>
    <td>&nbsp;&nbsp;<input name="pass" type="password" tabindex="2" required="required" size="25" style="margin-top:12px; margin-left:3px; border: 0pt none ; background-color: transparent; height: 20px; width: 170px; color: rgb(202, 202, 202); text-shadow: 0px 1px 0px #ffffff; font-size:11px; outline:none;" maxlength="16"></td>
    </tr>
	 <tr>

    <td colspan="2">&nbsp;&nbsp;<input name="" value="remember" type="checkbox"> <span style="font-family:Arial, Helvetica, sans-serif;color:#fff;font-weight: bold;font-size:12px;">Keep me logged in</span></td>
    </tr>


	<tr>
    <td colspan="2"> 
&nbsp;&nbsp; <a href=" "><img style="border: 0px solid ; width: 128px; height: 40px;" alt=" " src="images/register.png"></a> &nbsp; 
<a href=" "><img style="border: 0px solid ; width: 128px; height: 40px;" alt="" src="images/recover.png"></a>
</td>
    </tr>
	<input type="hidden" name="submit" value="1" />
</table>
<input type="hidden" name="submit" value="1" />
</form>
</div>
<?
include "parents/parent_login2.php";
?>