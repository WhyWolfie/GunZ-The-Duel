<?
include "parents/parent_login.php";

function ranking_update()
{
mssql_query("UPDATE Character SET Ranking='0'");
$r = mssql_query("SELECT TOP 174 CID From Character WHERE DeleteFlag='0' Order By Level Desc, XP Desc");
$i = 1;
while($rank = mssql_fetch_row($r)){
	mssql_query("UPDATE Character SET Ranking='$i' WHERE CID='$rank[0]'");
	$i++;
}
}
ranking_update();
?>
<div id="column2">
<table width="429px" border="0" class="bxrankall" cellspacing="0" cellpadding="0">
  <form method="GET" name="indsearch" action="index.php">
  <tr>
    <td height="25" colspan="3" align="left" valign="middle"><font color="#FFFFFF">Sort by: </font></td>
    <td height="26" colspan="5" align="right" valign="middle"><a style="color:#2E9AFE;">Individual</a> - <a href="index.php?do=clanrank" style="color:#FFF;">Clan </a> &nbsp;&nbsp;
<input type="hidden" name="do" value="individualrank" />
<input type="hidden" name="type" Value="1"/>
<input type="text" name="name" class="bxrankbuscar"> <input name="submit" type="submit"  value="Search">
	</td>
    </tr>
	</form>
    <tr align="center" valign="middle" >
  	<td width="20"  height="26" align="center" valign="middle">#</td>
    <td width="95" align="left" valign="middle">Name</td>
    <td width="80" align="left" valign="middle">LV</td>
    <td width="110" align="left" valign="middle">Experience</td>
    <td width="106" align="left" valign="middle">Kill/Death &nbsp;&nbsp;&nbsp;%</td>
  </tr>
  <tr>
    <td colspan="8">
<table width="424px" border="0" cellspacing="0" cellpadding="0" class="bxranklist">
                                       <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE Name = '$name'";
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {
                                                        switch( clean($_GET['page']) )
                                                        {
                                                            case "":
                                                                $ranks = "Ranking >= 1 AND Ranking <= 34";
                                                            break;
                                                            case "2":
                                                                $ranks = "Ranking > 35 AND Ranking <= 69";
                                                            break;
                                                            case "3":
                                                                $ranks = "Ranking > 70 AND Ranking <= 104";
                                                            break;
                                                            case "4":
                                                                $ranks = "Ranking > 105 AND Ranking <= 139";
                                                            break;
															 case "5":
                                                                $ranks = "Ranking > 140 AND Ranking <= 174";
                                                            break;
                                                            default:
                                                                $ranks = "Ranking <= 34";
                                                            break;
                                                        }

                    $res = mssql_query_logged("SELECT TOP 34 Name, CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE  $ranks AND  (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY  Level Desc, XP Desc, Ranking DESC");
                    
					
                                                            }
                                                            else
                                                            {
                                                                $res = mssql_query_logged($squery);
                                                            }
                                                              if(mssql_num_rows($res) <> 0)
                                                              {
                                                                while($char = mssql_fetch_object($res))
                                                                  {


?>


                                                                    <tr>
<td width="20"  height="18" valign="middle"><?=$char->Ranking?></td>
<td width="110" align="left" valign="middle"> <?=$char->Name?></td>
<td width="110" align="left" valign="middle"><?=$char->Level?></td>
 <td width="140" align="left" valign="middle"><?=number_format($char->XP, 0, ",", ".")?></td>
<td width="150" align="left" valign="middle"><?=GetKDRatio($char->KillCount, $char->DeathCount)?></td>
                                                                    </tr>
<?
                                            $count++;
                                                           }
                                                        }else{
                                                        ?>
                    <tr>
                      <td height="35" colspan="5" align="center" class="estilo5">- No Data - </td>
                    </tr>
                    <?
                                                        }
                                                        ?>



</table>	</td>
  </tr>
  <tr>
    <td height="27" colspan="8">
	
	
<table width="100%" border="0" class="bxrankall" cellspacing="0" cellpadding="0">
                                     <?
                                    if( $search == 0 )
					                $name = clean($_GET['name']);
								    $type = clean($_GET['type']);
                                    { ?>
  <tr>
    <td width="20%"></td>
    <td width="48%"><span>
	<br />
	<a href="index.php?do=individualrank">1 - 34</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php?do=individualrank&page=2">35 - 69</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php?do=individualrank&page=3">70 - 104</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php?do=individualrank&page=4">105 - 139</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="index.php?do=individualrank&page=5">140 - 174</a>
	</span> </td>
  </tr>
</table>
	                                <?
                                    }
                                    ?>

	</td>
    </tr>
</table>
</div>

<?
include "parents/parent_login2.php";
?>