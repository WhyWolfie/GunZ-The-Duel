<?

include "parents/parent_login.php";

?>

<div id="column2">

			  <table  border="0" cellspacing="0" cellpadding="0" class="msgbar1" style="margin-top: 5px;">

			  <?

 $res = mssql_query("SELECT TOP 1 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");

 while($n = mssql_fetch_assoc($res)){

?>

                    <tr>

                     <td width="28" align="center" valign="middle"><img src="images/anunceim.png" alt="alert" width="31" height="24" /></td>

                     <td width="397" align="left" valign="middle">SPECIAL ANNOUNCEMENT::<span style="color:#fff;"><b> <a href="<?=$n['Text']?>"> <?=$n['Title']?></a> <?=$n['Date']?></b></span></td>

                    </tr>

					<?}?>

              </table>

            <div class="news">

<?

 $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");

 while($n = mssql_fetch_assoc($res)){

?>

              <div class="contenido_new">

               <div style="margin-top: 5px; display: inline-table;">&nbsp;<img src="images/<?=$n['ImageURL']?>" width="51" height="17" ><span class="whit"><a href="<?=$n['Text']?>"> <?=$n['Title']?></a> <?=$n['Date']?></span></div>

                </div>

<?}?> 

            </div>

			

			<!-- end news-->

            <div class="clanwards">

            <div class="moretop">

                <a href=" "><img src="images/more_btn.png" align="right" style="margin-top:9px; margin-right: 17px;"></a>

                </div>         

                <div class="contenido_cw">

				<?
        /*Fix SackerZ*/
function img_clan($clid)
{
  $clan = mssql_fetch_array(mssql_query("SELECT EmblemUrl From Clan WHERE CLID='".$clid."' "));
  return ($clan[0] == "") ? "noemblem.png" : $clan[0];
}
$select = mssql_query("SELECT TOP 1 * FROM ClanGameLog ORDER BY id DESC");





                                    if(mssql_num_rows($select) == 0){

?>



<div align="left" class="Estilo2">No Data</div></td>

<?

                                    }while($row = mssql_fetch_object($select)){

?>

               <div class="imgcw1">

               <img width="70" height="70" style="float:left;" src="../emblems/upload/<?=img_clan($row->WinnerCLID)?>">

                    <div class="yel2"><?=$row->WinnerClanName?></div>

               </div>

               <div class="imgcw2">

                  <img width="70" height="70" style="float:right;" src="../emblems/upload/<?=img_clan($row->LoserCLID)?>">

                    <div class="yel3"><?=$row->LoserClanName?></div>

               </div>

               <div class="versus"><span style="color:#00FF00;"><?=$row->RoundWins?></span> - <span style="color:#FF0000;"><?=$row->RoundLosses?></span></div>

                <?}?>

                </div>

                </div>

				

               <div class="infoserver">

            	<div class="info">

                <div style="margin-bottom:5px; margin-top:1px;">

                <b>Last character created: <span style="color:#ff9710;">

   <?php

      //Newest Character

      $sqlnewestchar = mssql_query("SELECT * FROM Character ORDER BY CID DESC");

      $newestchar = mssql_fetch_object($sqlnewestchar);

	  

	  echo $newestchar->Name;

   ?>

				</span><br>

                </b>

                </div>

                <b>Last clan created: <span style="color:#ff9710;">

				<?php

      //Newest Clan

      $sqlnewestclan = mssql_query("SELECT * FROM Clan ORDER BY CLID DESC");

      $newestclan = mssql_fetch_object($sqlnewestclan);

	  

	  echo $newestclan->Name;

   ?>

				</span><br>

                </b>

             <b>Last account registered: <span style="color:#ff9710;">

			    <?php

      //Newest Accounts

      $sqlnewestacc = mssql_query("SELECT * FROM Account ORDER BY AID DESC");

      $newestacc = mssql_fetch_object($sqlnewestacc);

	  

	  echo $newestacc->UserID;

   ?>

			 </span><br>

                </b>

                <b>Registered Users: <span style="color:#ff9710;">

				<? 

//Total Accounts

$query = mssql_query("SELECT * FROM Account"); 

$num_rows = mssql_num_rows($query); 

echo $num_rows; 

 

?>

				</span><br>

                </b>

                </div>

                <div class="fb"><iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FDualgames&amp;width=268&amp;height=290&amp;colorscheme=dark&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:268px; height:290px;" allowTransparency="true"></iframe></div>

            </div> 

			

        </div>
<?

include "parents/parent_login2.php";

?>