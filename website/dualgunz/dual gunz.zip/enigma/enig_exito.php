
<?
	msgbox("Thank you for your donation","index.php");

   
?>