<?
include "parents/parent_login.php";
?>

<?
include "parents/parent_login2.php";
?>