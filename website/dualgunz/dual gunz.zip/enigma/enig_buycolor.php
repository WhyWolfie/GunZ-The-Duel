<?
 include "includes/secure/sql_check.php";

 if($_SESSION[AID] == "")
{
    msgbox ("Please login first","index.php?do=login");
}

//Precio del module
$price = 	70; // precio
$typedecoins = "EventCoins"; // Typo de table

$q		=	mssql_query("SELECT * From Account WHERE AID='".$_SESSION[AID]."'");
$acc = mssql_fetch_object($q);
$dcoins = $acc->$typedecoins;
$total	= $dcoins - $price;

	if($dcoins < $price){
	msgbox ("You do not have enough Donator Coins$total.","index.php?do=donator");
	}

include "parents/parent_login.php";
?>
<div id="column2">
                <div class="importantann">
                <p align="Center">
                                        <ul class="group" id="example-one" align="center">
                                            <li><a href="index.php?do=shopdonator"><h2>SHOPDONATOR</h2></a></li>
                                            <li><a href="index.php?do=shopevent"><h2>SHOPEVENT</h2></a></li>
                                            <li><a href="index.php?do=shopsets"><h2>COMPLETESETS</h2></a></li>
                                            <li><a href="index.php?do=shopspecial" style="color:#fff;"><h2>SHOPSPECIAL</h2></a></li>

                                       </ul>

                                        </p>
                                       <table border="0">
                                       <tr>
                                       <td>
	<form method='post'>
		<table border='0'>
		<tr>
			<td><img src="../images/shop/buycolor.png" width="100" height="100"></td>
		</tr>
			<tr><td><span>Please Pick: </span></td><td><span><input type='readonly' class="color" name='hexcolor' /></span></td>
             <td style="color:#00FF00;">Precio: <? echo $price;?>$</td>
			</tr>
			<tr><td><span style='margin-left:20px;'><input type='image' src='../images/change_button.png' name='changevipc' /></span></td></tr>

		</table>
		<?
			if(isset($_POST['changevipc_x'])) {
				$clientcolor = CleanIt($_POST['hexcolor']);
				if(CharNum($clientcolor) == 6) {
					VIPColorSystem($clientcolor);
					msgbox ("VIP Color had changed !","index.php");
					die();
				}
				else {
					msgbox ("You did something ...","index.php?do=buycolor");
					die("You did something ...");
				}
			}
		?>
		<script type="text/javascript" src="js/jscolor.js"></script>
	</form>
	</td>
	</tr>
	</table>
    </div>
    </div>
	<?
        include "parents/parent_login2.php";
	?>