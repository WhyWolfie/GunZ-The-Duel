<?
include "parents/parent_login.php";
?>
<div id="column2">
           <div class="DownloadBox">
            <table width="618" border="0">
              <tbody><tr>
                <td width="612" height="38">&nbsp;</td>
                </tr>
              <tr>
                <td height="27" align="center" class="whit">Únete a los DualGames: La experiencia Duelo en su mejor servidor privado, DualGames V2!</td>
              </tr>
              <tr>
                <td height="27" align="center" valign="top" class="whit"><p>No tienes una cuenta todavía?<a href="http://gunz.dualgames.net/index.php?do=register">REGISTRATE</a></p></td>
              </tr>
			  <tr>
                <td height="27" align="center" valign="top" class="whit"><p>Ejecuta Gunz.Exe Como administrador <a href="http://gunz.dualgames.net/123.jpg">VER EJEMPLO</a></p></td>
              </tr>
              <tr>
                <td height="144" align="center" valign="middle"><img src="images/bannerdl.png"></td>
              </tr>
              <tr>
                <td height="66" align="center" valign="middle">
                <a href=" https://mega.co.nz/#!y5NhyQTb!9H4KknqGSuvBR77OHuzPcoM66qI5WdfLdIPMYVL39yE "><img src="images/mirror1.png"></a>
                <a href=" https://mega.co.nz/#!TxUx0C6Z!oml2JkvKIUG8XPElKD6vjUQjydI-oRfest3SitPnOIY "><img src="images/mirror2.png"></a>
                <a href="http://www.mediafire.com/download/rabpg4rs6s61dic/DualGames+V2.exe"><img src="images/mirror3.png"></a>
                <a href="http://www.mediafire.com/download/ham8h1x95nv9js3/DualGames+V2.rar "><img src="images/news.png"></a>
                </td>
                </tr>
            </tbody></table>
          </div>
                	
</div>
<?
include "parents/parent_login2.php";
?>