<?
msgbox("Error - Donation :( ","index.php");
?>