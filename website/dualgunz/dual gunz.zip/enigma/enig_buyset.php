<?
include "includes/secure/sql_check.php";

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buyset&setid={$_GET[setid]}");
	msgbox ("Login first, Please","index.php?do=login");
    die();
}

if(!isset($_POST[SetID]))
{
    if($_GET[setid] == "" || !is_numeric($_GET[setid]))
    {
	msgbox ("Incorrect item information","index.php");
        die();
    }
}

if(isset($_POST[SetID]))
{
    $setid  = clean($_POST[SetID]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopSets (nolock) WHERE SSID = $setid");

    if(mssql_num_rows($ires) == 0)
    {
	msgbox ("Item not found","index.php?do=shopsets");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account  WHERE AID  = $accid"));

    $totalprice      = $ires->Price;
    $accountbalance = $ares->EventCoins;
    $afterbalance   = $accountbalance - $totalprice;


    if($afterbalance < 0)
    {
	msgbox ("You do not have enough coins to do this.","index.php?do=buyset&setid=$setid");
        die();

    }else{
        mssql_query_logged("UPDATE Account SET EventCoins = EventCoins - $totalprice WHERE AID = {$_SESSION[AID]}");

        if( $ires->HeadItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->HeadItemID}, GETDATE(), 1)");
        }
        if( $ires->ChestItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->ChestItemID}, GETDATE(), 1)");
        }
        if( $ires->HandItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->HandItemID}, GETDATE(), 1)");
        }
        if ( $ires->LegItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->LegItemID}, GETDATE(), 1)");
        }
        if ( $ires->FeetItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->FeetItemID}, GETDATE(), 1)");
        }
	msgbox ("The Set was successfully purchased. Please review the storange.","index.php?do=shopsets");
    }
}else{
    $setid  = clean($_GET[setid]);

    $ires = mssql_query_logged("SELECT * FROM ShopSets(nolock) WHERE SSID = $setid");

    if(mssql_num_rows($ires) == 0)
    {
		msgbox ("Error From Shop.","index.php?do=shopsets");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));	$Eventcoins =$acd->EventCoins;
		
	
    $data = mssql_fetch_object($ires);
	$itemp = $data->Price;
	$balan = $Eventcoins-$itemp;
	
}

$type ="Complete Set";
include "parents/parent_login.php";
?>
<div id="column2">
                 <div class="importantann">
          <div class="RankingBox">
<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; color:#fff;" width="603">
								<tbody><tr>
									<td height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-position: center; background-color:#585858; width:100%; height:0px; border-radius:10px;" width="583" valign="top">
										<p align="Center">
<ul class="group" id="example-one" align="center">
<li><a href="index.php?do=shopdonator"><h2>SHOPDONATOR</h2></a></li>
<li><a href="index.php?do=shopevent"><h2>SHOPEVENT</h2></a></li>
<li><a href="index.php?do=shopsets" style="color:#fff;"><h2>COMPLETESETS</h2></a></li>
<li><a href="index.php?do=shopspecial"><h2>SHOPSPECIAL</h2></a></li>
</ul>
                                        </p>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" width="100%" height="100%">
											<tbody>
											
											
											
											
											<td width="599" valign="top">
						<div align="center">
							<table border="0" width="603">
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="1" style="border-collapse: collapse;" width="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<form method="POST" action="index.php?do=buyset" name="frmBuy"><table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="458" colspan="2">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104" valign="top">
															<div align="center">
															<img border="0" src="images/shop/<?=$data->ImageURL?>" width="100" height="150" style="border: 2px solid #1D1B1C"></td>
															<td width="458" colspan="2">
															<div align="center">
 																<table border="0" style="border-collapse: collapse" width="458" height="100%">
																	<tr>
																		<td width="19">
																		<div align="left">&nbsp;</td>
																		<td width="435" colspan="2">
																		<div align="left">
																		<b>
																		<span size="2" style="font-size:25px; color:#585858;">
																		<?=$data->Name?></span></b></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Type:
																		</td>
																		<td width="372" align="left"><?echo $type?></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Sex:</td>
																		<td width="372" align="left">
																		<?=$data->Sex?></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Level:</td>
																		<td width="372" align="left">
																		<?=$data->Level?></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left" style="color:#00FF00;">
																		Price:</td>
																		<td width="372" align="left">
																		<span id="currentprice" style="color:#00FF00;"><?=$data->Price?>$</span></td>
																	</tr>
 																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="100%" colspan="2" rowspan="5" style="background-color:#585858; background-position: center; border-radius:10px;" valign="middle">
																		<div align="center">
																							<span style="color:#1C1C1C; font-size:20px;"><b>Set Permanente</b></span>
																	<input type="hidden" name="SetID" value="<?=$_GET[setid]?>"></div>
																		</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
															<td width="435" align="left" rowspan="4">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="435" height="66">
																	<tr>
																		<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="419" height="100%">
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left" style="color:#00FF00;">Total:</td>
																					<td width="62" align="left"><span style="color:#00FF00;"><?=$itemp?>$</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left" style="color:#00FF00;">Current Balance:</td>
																					<td width="62" align="left"><span style="color:#00FF00;"><?=$Eventcoins?>$</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left" style="color:#00FF00;">After:</td>
																					<td width="62" align="left"><span style="color:#00FF00;"><?=$balan?>$</span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="413" colspan="4" height="1"></td>
																				</tr>
																			</table>
																		</div>
																		</td>
																		<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="569" colspan="4">&nbsp;</td>
														</tr>
													</table>

												</div>
												</td>
											</tr>
										</table>
									</div>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;
									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3" align="center">

<a href="javascript:document.frmBuy.submit();"><img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1764" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyset_on.jpg')"></a>

<a href="index.php?do=shopsets"><img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="dale1872" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'dale1872',/*url*/'images/btn_cancel_on.jpg')"></a></td>
								</tr>
							</table>
						</div>
						</td>
											
											
											
											
											
											
											</tbody></table>
												</form></div>
												</td>
											</tr>
										</tbody></table>

									</div></div></div></div>
									
<?
include "parents/parent_login2.php";
?>