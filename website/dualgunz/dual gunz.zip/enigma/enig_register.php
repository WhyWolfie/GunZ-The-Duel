<?
include "includes/secure/sql_check.php";
include "includes/secure/anti_sql.php";

if($_SESSION[UserID] <> "")
{
msgbox ("!Log out first before making an account!","index.php");
    die();
}

require_once('aregistercodechatcharparalaweb.php');
$publickey = "6Ld3jvISAAAAAKtn9_5lPesZcerIs-0HTRS6Hpvx"; //llave publica
$privatekey = "6Ld3jvISAAAAAHmpGytjU2nz3MZ25SKgmGQ4IWeN"; //lave privada
$error = null;
$resp = null;

if(isset($_POST[submit]))
{
    $user           = clean($_POST[userid]);
    $names          = clean($_POST[namea]);
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);
	$resp = recaptcha_check_answer ($privatekey, 
                            $_SERVER["REMOTE_ADDR"],
                            $_POST["recaptcha_challenge_field"],
                            $_POST["recaptcha_response_field"]);
							
    if($pass[0] != $pass[1]){
	msgbox ("password do not match","index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE UserID = '$user'") ) <> 0 ){
	msgbox ("The UserID $userid is already in use","index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'") ) <> 0 ){
	msgbox ("The Email $email is already in use","index.php?do=register");
        die();
    }
    elseif ($user == ""){
	msgbox ("Please enter a UserID","index.php?do=register");
        die();
    }
    elseif ($pass[0] == "" || $pass[1] == ""){
	msgbox ("Please enter a password","index.php?do=register");
        die();
    }
    elseif ($email == ""){
	msgbox ("Please enter an email address","index.php?do=register");
        die();
    }
    elseif ($sq == ""){
	msgbox ("Please enter a secret question","index.php?do=register");
        die();
    }
    elseif ($sa == ""){
	msgbox ("Please enter a secret answer","index.php?do=register");
        die();
    }
    elseif (strlen($user) < 3){
	msgbox ("The user ID is too short (6 characters min)","index.php?do=register");
        die();
    }
    elseif (strlen($pass[0]) < 3){
	msgbox ("Password is too short (6 characters min to 16)","index.php?do=register");
        die();
    }
    else{	
		if ($resp->is_valid) {
           $registered = 1;
           mssql_query("INSERT INTO Account (UserID, Name, Email, UGradeID, PGradeID, RegDate, sa, sq, Coins, EventCoins)Values ('$user', '$names','$email', 0, 0, GETDATE(), '$sa', '$sq', 0, 0)");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
		//Items al registrarce
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650051', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650052', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650053', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650054', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650055', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650056', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650057', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650058', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650059', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '650060', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '1121314004', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '1121314006', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '6600004', GETDATE(), '120', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '1000034', GETDATE(), '600', '1')");
		mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '9999918', GETDATE(), '600', '1')");
		
		mssql_query("INSERT INTO Login ([UserID], [AID], [Password])Values ('$user', '$aid', '$pass[0]')");
		  msgbox ("$user Creado Correctamente!! Welcome to DualGames","index.php");
        die();
		}else
		 msgbox ("Error REcaptcha","index.php");
        die();
		}
    }

include "parents/parent_login.php";
?>

<div id="column2">

<form method="POST" action="index.php?do=register" name="register">
<table width="200" border="0" cellpadding="0" cellspacing="0" align="center"> <tr><td>
<tr>
	<td>
<table  border="0" cellspacing="0" cellpadding="0" class="msgbar1" style="margin-top: 5px;">
  <tr>
    <td width="28" align="center" valign="middle"><img src="images/iconalert.png" alt="alert" width="20" height="20" /></td>
    <td width="397" align="left" valign="middle">Remember never reveal your data and use a valid email. </td>
  </tr>
</table>

<table width="100%" border="0" cellspacing="0" cellpadding="0" style="margin-top:10px;">
  <tr>
    <td width="26%" valign="middle"><b>User: </b></td>
    <td valign="middle"><input type="text" name="userid" size="10" maxlength="25" required="required"/></td>
  </tr>
  <tr>
    <td valign="middle"><b>Name: </b></td>
    <td  valign="middle"><input name="namea" type="text" size="10" maxlength="25" required="required"/></td>
  </tr>
  	<tr>
    <td valign="middle"></td>
    <td valign="middle"><font style="Font-size:12px; color:#6E6E6E;">You can only enter maximum 16 characters</font></td>
    </tr>
  <tr>
    <td valign="middle"><b>Password: </b></td>
    <td valign="middle"><input type="password" name="pass1" maxlength="16" size="16" required="required"/></td>
  </tr>
  <tr>
     <td valign="middle"><b>Repeat password: </b></td>
    <td valign="middle"><input type="password" name="pass2" maxlength="16" size="16" required="required"/></td>
  </tr>
     <tr>
    <td valign="middle"></td>
    <td valign="middle"><font style="Font-size:12px; color:#6E6E6E;">Please, use a valid email. </font></td>
    </tr>
    <tr>
    <td valign="middle"><b>E-mail: </b></td>
    <td valign="middle"><input type="text" name="email" class="iptbox3" size="" required="required"/></td>
    </tr>
	<tr>
    <td valign="middle"></td>
    <td valign="middle"><font style="Font-size:12px; color:#6E6E6E;">Never reveal your secret answer. Maximum digits 20</font></td>
    </tr>
  <tr>
  	<td valign="middle"><b>Secret Question : </b></td>
    <td valign="middle"> <input type="text" name="sq" maxlength="20" size="20" required="required"/></td>
  </tr>
  <tr>
	<td valign="middle"><b>Secret Answer : </b></td>
    <td valign="middle"><input type="text" name="sa" maxlength="20" size="20" required="required"/></td>
  </tr>
  <tr>
    <td colspan="4" align="center" valign="middle"><input name="I accept" type="checkbox" required="required" />I have read and accept the <a href=" " target="_blank">Terms of Use </a></td>
    </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    <td colspan="2">&nbsp;</td>
  </tr>
  <div align="center">
   <tr>
    <td colspan="4" align="center" valign="middle">
	<div align="center"><? echo recaptcha_get_html($publickey, $error); ?></div><br>
	<input name="img123" type="submit" class="iptsub1" value=" ">
	</td>
    </tr></div>
</table>
	</td>
</tr>
</table>
<input type="hidden" name="submit" value="1"></form>



	 
        </div>	
<?
include "parents/parent_login2.php";
?>