<?
include "parents/parent_login.php";
?>
<div id="column2">
<!-- Fin Tabla Ranking Individual -->
<table width="429px" border="0" class="bxrankall" cellspacing="0" cellpadding="0">
  <tr>
    <td height="25" colspan="3" align="left" valign="middle"><font color="#FFFFFF">&nbsp;&nbsp;&nbsp;Sort by: </font></td>
    <td height="26" colspan="4" align="right" valign="middle"><a style="color:#FFF;" href="index.php?do=individualrank">Individual</a> - <a style="color:#2E9AFE;">Clan </a>&nbsp;&nbsp;&nbsp;&nbsp;
    </tr>
  <tr align="center" valign="middle">
  	<td width="33"  height="26" align="center" valign="middle">#</td>
    <td width="35" align="left" valign="middle">EM</td>
    <td width="91" align="left" valign="middle">Name</td>
    <td width="82" align="left" valign="middle">Leader</td>
    <td width="78" align="left" valign="middle">Win/Lose</td>
    <td width="61" align="left" valign="middle">G/P Ratio </td>
    <td width="65" align="left" valign="middle"> Points </td>
  </tr>
<tr>
<td colspan="7" align="center">
	
<table width="424px" border="0" cellspacing="0" cellpadding="0" class="bxranklist">
                                    <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Point DESC";
                                                                }
                                                                else
                                                                {
                                                                    echo '
                                                                <tr>
                                                                    <td width="528" colspan="5">
                                                                    <p align="center">
                                                                    No Data</p></td>
                                                                </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if( $search == 0 )
                                                        {
                                                            switch( clean($_GET['page']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 34";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 1 AND Ranking <= 34";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 35 AND Ranking <= 69";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 70 AND Ranking <= 104";
                                                                break;
                                                                case "5":
                                                                    $ranks = "Ranking > 105 AND Ranking <= 139";
                                                                break;
																case "6":
                                                                    $ranks = "Ranking > 140 AND Ranking <= 174";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 34";
                                                                break;
                                                            }
                                                            $res = mssql_query_logged("SELECT TOP 34 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) AND $ranks ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                       if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count = 1;
															
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "noemblem.png" : $clan->EmblemUrl;
														$linkclan = ($clan->CLID == "") ? "noemblem.png" : $clan->CLID;
                                                        $clanrank .= '
                                                        <tr>
										   <td width="40"  height="18" align="center" valign="middle">'.$count.'</td>
<td width="30" align="left" valign="middle"><img src="/emblems/upload/'.$clanemburl.'" width="14" height="13" style="border: 1px solid #000000"></td>
					 <td width="110" align="left" valign="middle"><a href="index.php?do=clanadmin&CLID='.$linkclan.'">'.$clan->Name.'</a></td>
											<td width="130" align="left" valign="middle">'.GetCharNameByCID($clan->MasterCID).'</td>
											 <td width="79" align="left" valign="middle">'.$clan->Wins . "/" . $clan->Losses.'</td>
											<td width="60" align="left" valign="middle">'.GetClanPercent($clan->Wins, $clan->Losses).'</td>
										<td width="63" align="left" valign="middle">'.$clan->Point.'</td>
														</tr>';
														$count++;
                                                            }
                                                        }else{
                                                        $clanrank = '
														<tr>
															<td width="537" align="center" colspan="7">
															No data</td>
														</tr>';
                                                        }
                                                echo $clanrank;
                                                     ?>
													</table>
												</div>
                                            <?
                                            if( $search == 0 )
                                            {
                                            ?>
                                                <p align="center"><a href="index.php?do=clanrank"></a></p>
                                            <?
                                            }
                                            ?>
</table></td>
  </tr>
<tr align="center">
<td height="27" colspan="7" align="center">
<table width="100%" border="0" class="bxrankall" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="20%"></td>
    <td width="48%">
	<br />
	<span align="center">
	<a href="">1 - 34</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="">35 - 69</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="">70 - 104</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="">105 - 139</a> &nbsp;&nbsp;&nbsp;&nbsp;
	<a href="">140 - 174</a> &nbsp;&nbsp;&nbsp;&nbsp;
	</span> </td>
  </tr>
</table>	</td>
    </tr>
<!-- Fin Tabla Ranking Individual -->
</div>
<?
include "parents/parent_login2.php";
?>