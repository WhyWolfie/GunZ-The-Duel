<?

include "parents/parent_login.php";
?>
<div id="column2">
                <div class="importantann" align="center">
                
                
                
                <form name="pg_frm" method="post" action="https://www.paygol.com/pay" >
 UserID<p>
   <input type="text" name="pg_custom" value="UserID" onclick="this.value=&quot;&quot;;"><p>
   <input type="hidden" name="pg_serviceid" value="105186">
   <input type="hidden" name="pg_currency" value="USD">
   <input type="hidden" name="pg_name" value="DualCoins">

 <!-- With Option buttons -->
    <input type="radio" name="pg_price" value="1"checked>Donator Coins 25 2$<p>
    <!--<input type="radio" name="pg_price" value="2">DonatorCoins 40 4$ 4<p> -->
    <!--<input type="radio" name="pg_price" value="3">DonatorCoins 120 10$ 10<p> -->
   <input type="hidden" name="pg_return_url" value="http://www.gunz.dualgames.net/index.php?do=exito">
   <input type="hidden" name="pg_cancel_url" value="http://www.gunz.dualgames.net/index.php?do=error">
   <input type="image" name="pg_button" src="https://www.paygol.com/micropayment/buttons/es/white.png" border="0" alt="Realiza pagos con PayGol: la forma mas facil!" title="Realiza pagos con PayGol: la forma mas facil!" >     
</form>
                
                
                
                
                </div>
                </div>
<?
include "parents/parent_login2.php";
?>