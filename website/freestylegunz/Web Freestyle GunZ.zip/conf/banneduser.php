<?
if($_SESSION['UGradeID'] == 253){
?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=windows-1252" />
    <title>GunzCore - Usuario Banido</title>
	<link rel="stylesheet" type="text/css" href="error/css/html5reset.css" />
    <link rel="stylesheet" type="text/css" href="error/css/master.css" />
    <link rel="stylesheet" type="text/css" href="error/css/moz-master.css" />
	<link rel="stylesheet" type="text/css" href="error/css/o-master.css" />

	<script src="error/js/jquery-1.7.1.min.js"></script>
	<script src="error/js/jquery.easing.1.3.js"></script>
	<script src="error/js/cufon-yui.js"></script>
	<script src="error/js/Aller_700.font.js"></script>
	<script src="error/js/cufon-colors.js"></script>
	<script src="error/js/jquery.path.js"></script>
	<script src="error/js/jquery.transform2d.js"></script>
	<script src="error/js/script.js"></script>
</head>
<body>

    <div id="wraper">
		<div class="content">    
		<div id="head">
		 <div class="head-move">
			<div id="wing-one"><span></span></div>
			
			<div id="skull">
      
				<div id="left-eye" class="background">
	  				<div class="eyebrow"><span></span></div>
        				<div class="eyeball">
          					<div class="eye-pupil">
            				<div class="pupil-one"></div>
            				<div class="pupil-two"></div>
          				</div>
        			</div>
      			</div>
				
      			<div id="right-eye" class="background">
	  				<div class="eyebrow"><span></span></div>
        			<div class="eyeball">
          				<div class="eye-pupil">
            				<div class="pupil-one"></div>
            				<div class="pupil-two"></div>
          				</div>
        			</div>
      			</div>
				
	  		</div>
			
			<div id="wing-two"><span></span></div>
			
		 	<div id="legs" class="background">
	  			<div class="legs-a"><span></span></div>
       	 		<div class="legs-b"><span></span></div>
      		</div>
			
	  	</div>	 
		</div> 
		
		<div class="eror-font">
			<span class="four-four"></span>
			<span class="info-one">Voce foi banido</span>
			<span class="info-two">Sua conta foi banida pela equipe do GunZCore!</span>
			<span class="info-two">Caso o ban foi injusto informe-nos no nosso forum!</span>
		</div>
		
	</div>

    </div>
	
	<div id="bottom">
			<div id="nav">
				<ul>
					<li class="act"><a href="index.php">Home</a></li>
				</ul>
			</div>
	
	</div>
</body>
</html>

    <?
    die();
}

?>