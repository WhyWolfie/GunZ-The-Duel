<?
//Script Resetar Kill's e Deaths By Pablo
$errorcode = "";
$er = 0;
$registered = 0;

$aid2 = $_SESSION['AID'];
$query2 = mssql_query("SELECT * FROM Character WHERE AID = '$aid' ORDER BY Level DESC");
$busca2 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid' AND DeleteFlag = '0'");

if (isset($_POST['resetar'])){
     $cid1 = clean($_POST['cid1']);
     $death = clean($_POST['0']);
     $kill = clean($_POST['0']);

        if($er == 0){
            $registered = 1;
	  mssql_query_logged("UPDATE Character SET KillCount='0' WHERE AID='".$_SESSION['AID']."' AND CID='$cid1'");
	  mssql_query_logged("UPDATE Character SET DeathCount='0' WHERE AID='".$_SESSION['AID']."' AND CID='$cid1'");
        }else{
            msgbox("Error","index.php?do=account-home");
        }
}



if ($registered == 0){
?>
<form name="reg" method="POST" action="index.php?do=account-character">
<input type="hidden" name="request" value="reset"/>
<table border="0">
<tr><span class="title">Resetar Kill's &amp; Death's</span></tr>
<tr><td>Char:</td><td><select name="cid1">
<?
while($personagens2 = mssql_fetch_assoc($query2)){
?>
<option value="<?=$personagens2['CID']?>"><?=$personagens2['Name']?></option><? } ?></select></td></tr>
<tr><td></td><td><input type="submit" name="resetar" class="button" value="Resetar" onclick="javascript: var t = confirm('Are you sure you want to reset the K/D of this character?'); if(t == true){ return true; } else{ return false;}"/></td></tr>
</table>
</form>
<?
}else{
    msgbox("O personagem foi resetado corretamente","index.php?do=account-character");
}
?>