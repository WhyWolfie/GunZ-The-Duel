<?php
include "conf/config.php";
include "conf/_functions.php";
include "conf/checkcookie.php";
include "conf/shield.php";
include "conf/antisql.php";
include "conf/anti_sql.php";
include "conf/sql_check.php";
include "conf/sqlcheck.php";
include "conf/banneduser.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("modulos/mod_" . $_GET['do'] . ".php")) {
        include "modulos/mod_" . $_GET['do'] . ".php";
	}
} }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="description" content="Freestyle GunZ Home Page; charset=iso-8859-1"/>
<title>Shota Gunz - Web Site</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
</head>
<body>
 <?
if($_SESSION[AID] == "")
{
?>
<div id="top">
<div id="top_content">
<a href="index.php?do=account-home" class="myacc"></a><a href="index.php?do=recuperar">Esqueceu a sua senha?</a><a href="index.php?do=login" class="login"></a><a href="index.php?do=registro" class="register"></a> </div>
</div>
<div id="container">
<?
}else{

$login22 = $_SESSION['login'];

$ugrade1 = mssql_query("SELECT UgradeID FROM Account WHERE UserID = '$login22'");
$ugrade2 = mssql_fetch_row($ugrade1);

$query1 = mssql_query("SELECT * FROM Login WHERE UserID = '$login22'");
$query2 = mssql_fetch_assoc($query1);

$query3 = mssql_query("SELECT * FROM Account WHERE UserID = '$login22'");
$query4 = mssql_fetch_assoc($query3);

?>
 <div id="top">
<div id="top_content">
<a href="index.php?do=account-home" class="myacc"></a><a href="page/donation-page">Cash: <span><?=$query2['RZCoins']?></span> | EV: <span><?=$query2['EVCoins']?></span></a><p>Welcome, <span> <?=$login22?></span></p> <a href=index.php?do=deslogar class="logout">Sair</a> </div>
</div>
<div id="container">
 <?
}
?>
<div id="logo"></div>
<div id="container_wrapper">
 
<div id="navbar">
 
<div id="mainmenu">
<ul>
<li class="active"><a href="index.php">Inicio</a></li><li><a href="index.php?do=registro">Registro</a></li><li><a href="index.php?do=download" id="a_download" class="download">Download</a></li><li><a href="http://kinggamer.com.br/forum" target="_blank">F�rum</a></li><li><a href="index.php?do=ranking-individual">Ranking</a></li><li><a href="index.php?do=itemshop&sub=normalset&expand=1&type=1">Item Shop</a></li><li><a href="index.php?do=account-home" id="a_myaccount" class="myaccount">Minha conta</a></li></ul>
</div>
 
<div id="submenu">
<ul class="tab_download" style="display:none;">
<li><a href="http://www1.freestylersgunz.com/downloads/Freestyle-GunZ-Version-7-Installer-FULL.exe" target="_blank">freestylersgunz.com (1)</a></li>
<li><a href="http://www2.freestylersgunz.com/downloads/Freestyle-GunZ-Version-7-Installer-FULL.exe" target="_blank">freestylersgunz.com (2)</a></li>
<li><a href="http://uploading.com/files/thankyou/3c9amcbb/Freestyle+GunZ+Version+7+Installer+FULL.exe" target="_blank">Uploading.com</a></li>
<li><a href="http://depositfiles.com/files/jmmtlsdef" target="_blank">Depositfiles.com</a></li>
<li><a href="http://www.gamefront.com/files/22172224/Freestyle+GunZ+Version+7+Installer+FULL.exe" target="_blank">Gamefront.com</a></li>
<li><a href="http://www.filedropper.com/freestylegunzversion7installerfull" target="_blank">FileDropper.com</a></li>
<li><a href="game5/gunz/Freestyle GunZ Version 7 Installer FULL.torrent" target="_blank">Torrent</a></li>
</ul>
</div>
 
<span class="status">
<span class="count"><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "$servercount";
    ?></span> Players Online </span>
</div>
 
<div id="content_wrapper">
<div id="content-top"></div>
<div id="content">
<div id="content-left">
 
<div id="download">
<a href="index.php?do=download"></a>
</div>
 
<div id="ranking">
 
<div id="indranking">
<?
$res = mssql_query("SELECT TOP 7 Name, Level, CID FROM Character WHERE Name != '' ORDER BY Level DESC");
$count = 0;
    ?>  
<table>
<?
if(mssql_num_rows($res) == 0){
?>
<tr><td class="rank"></td><td class="name"><a href="#">Sem personagens</a></td><td></td></tr>
<a href="index.php?do=ranking-individual" class="button">expand</a>
</div>
</table>
<?
}else{
?>
<table>
<?
while($r = mssql_fetch_assoc($res)){
$count++;
?>
<tr><td class="rank"><?=$count?></td><td class="name"><a href="index.php?do=character-view&id=<?=$r['CID']?>"><?=$r['Name']?></a></td><td>Lv <?=$r['Level']?></td></tr>
<?}}?> </table>
<a href="index.php?do=ranking-individual" class="button">expand</a>
</div>
 <?
$res = mssql_query("SELECT TOP 7 Name, Point, CLID FROM Clan WHERE Name != '' ORDER BY Point DESC");
$count = 0;
?>
<div id="clanranking">
<table>
<?
if(mssql_num_rows($res) == 0){
?>
<tr><td class="rank"></td><td class="name"><a href="#">Sem clans</a></td><td></td></tr>
<a href="index.php?do=ranking-individual" class="button">expand</a>
</div>
</table>
<table>
<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++; 
?>
<tr><td class="rank"><?=$count?></td><td class="name"><a href="index.php?do=clan-view&id=<?=$r['CLID']?>"><?=$r['Name']?></a></td><td><?=$r['Point']?> pts</td></tr>
<?}}?> </table>
<a href="index.php?do=ranking-clan" class="button">expand</a>
</div>
</div>
 
<div id="facebook">
<iframe src="https://www.facebook.com/plugins/likebox.php?api_key=113869198637480&sdk=joey&height=245&header=true&show_faces=true&stream=false&width=194&href=http%3A%2F%2Fwww.facebook.com%2Ffreestylegunz&colorscheme=light" scrolling="no" frameborder="0" style="border: medium none; overflow: hidden; height: 245px; width: 188px;" allowTransparency="true"></iframe>
</div>
</div>
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("modulos/mod_" . $_GET['do'] . ".php")) {
							    include "modulos/mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "modulos/mod_home.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("modulos/mod_" . $_GET['do'] . ".php")) {
        					include "modulos/mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
		} ?>
<div id="items">
<a href="#" class="arrow-left" id="item-list1" onclick="return false;"></a>
<a href="#" class="arrow-right" id="item-list2" onclick="return false;"></a>
<ul class="item-list1"><li class="tooltip" title="Cost: 200 Coins" onclick="window.location = 'http://fgunz.net/item/Spacey-SMGs'"><img src="images/items/Spacey SMGs.png" width="92" height="92"/><div id="item-name"><span class="name">Spacey SMGs</span></div></li><li class="tooltip" title="Cost: 100 Coins" onclick="window.location = 'http://fgunz.net/item/Donation-Shotgun'"><img src="images/items/Donation Shotgun.png" width="92" height="92"/><div id="item-name"><span class="name">Donation Shotgun</span></div></li><li class="tooltip" title="Cost: 300 Coins" onclick="window.location = 'http://fgunz.net/item/Ghost-Set-(M)'"><img src="images/items/Ghost Set (M).png" width="92" height="92"/><div id="item-name"><span class="name">Ghost Set (M)</span></div></li><li class="tooltip" title="Cost: 200 Coins" onclick="window.location = 'http://fgunz.net/item/Donation-Sniper'"><img src="images/items/Donation Sniper.png" width="92" height="92"/><div id="item-name"><span class="name">Donation Sniper</span></div></li></ul><ul class="item-list2"><li class="tooltip" title="Cost: 100 Coins" onclick="window.location = 'http://fgunz.net/item/Donation-Dagger'"><img src="images/items/Donation Dagger.png" width="92" height="92"/><div id="item-name"><span class="name">Donation Dagger</span></div></li><li class="tooltip" title="Cost: 100 Coins" onclick="window.location = 'http://fgunz.net/item/Donators-Starshooter'"><img src="images/items/Donators Starshooter.png" width="92" height="92"/><div id="item-name"><span class="name">Donators Starshooter</span></div></li><li class="tooltip" title="Cost: 300 Coins" onclick="window.location = 'http://fgunz.net/item/Extreme-Meds-Pack'"><img src="images/items/Extreme Meds Pack.png" width="92" height="92"/><div id="item-name"><span class="name">Extreme Meds Pack</span></div></li><li class="tooltip" title="Cost: 200 Coins" onclick="window.location = 'http://fgunz.net/item/Donation-XYZ-Set-(M)'"><img src="images/items/Donation XYZ Set (M).png" width="92" height="92"/><div id="item-name"><span class="name">Donation XYZ Set (M)</span></div></li></ul><ul class="item-list2"></ul>
</div>
</div>
<div id="content-right">
 
<div id="faq">
<a href="index.php?do=frequently-asked-questions"></a>
</div>
 
<div id="donate">
<a href="donate" class="button"></a>
<div class="links">
<a href="page/about-donations">> About Donations</a><br/>
<a href="donate">> How To Donate?</a>
</div>
</div>
 
<div id="recent-activity">
<ul>
<li><span class="title">Most Online Today:</span> <span class="content">278</span></li><li><span class="title">Newest Character:</span> <span class="content"><a href="character/view/RandomHat">RandomHat</a></span></li><li><span class="title">Newest Clan:</span> <span class="content"><a href="clan/view/Lysian">Lysian</a></span></li><li><span class="title">Last CW:</span> <span class="content"><a href="clan/view/Bonafide" title="Winner">Bonafide</a> vs <a href="clan/view/BodySenses" title="Loser">BodySenses</a></span></li><li><span class="title">Last Lvl. Up:</span> <span class="content"><a href="character/view/Simrat">Simrat</a> (Lv. 10)</span></li> </ul>
</div>
<?
$res = mssql_query("SELECT TOP 15 Name, CID FROM Character WHERE Name != '' ORDER BY PlayTime ASC");
?> 
<div id="recent-players">
<p class="players">
<?
if(mssql_num_rows($res) == 0){
?>
Sem players recentes
<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++;
?>
<a href="index.php?do=character-view&id=<?=$r['CID']?>"><?=$r['Name']?></a>&nbsp;<?}}?></span></p>
<p class="legend">
<span class="admin">Admin</span> - <span class="gm">GM</span> - <span class="dev">Dev</span> - <span class="vip">VIP</span> - <span class="banned">Banned</span>
</p>
</div>
 
<div id="trailer">
<a href="page/trailer"></a>
</div>
</div>
</div>
<div id="content-bottom"></div>
</div>
</div>
 
<div id="footer">
<span class="left">
Copyright &copy; <a href="#">kinggamer.com.br</a> 2012 - 2013. Todos os direitos reservados. Website designed by <a href="http://freestylersworld.com/member.php?94-McSic">McSic</a>. Codada por <a href="http://freestylersworld.com/member.php?56-SuperWaffle">Pablo</a>.
<a class="logo" id="left-logo" title="Where The Best Come Together"></a>
</span>
<span class="right">
<a href="/">Home</a> � <a href="page/privacy-policy">Privacy Policy</a> � <a href="index.php?do=frequently-asked-questions">Disclaimer</a>
<a href="http://freestylersworld.com" class="logo" title="Freestylers World" target="_blank"></a>
</span>
</div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
</body>
</html>