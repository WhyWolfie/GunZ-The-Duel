<?
if ($_GET['expand'] == 1){
?>
<? }

if(!function_exists("normalset")){
function normalset(){
    if(!isset($_GET['type'])){
        $type = "";
    }else{
        $type = "Slot = '".clean($_GET['type'])."' AND";
    }

    $res = mssql_query_logged("SELECT * FROM RZSetShop WHERE ".$type." Opened = '1'");

    ?>
<div id="content-center"><div id="main">
<h1>Donation Shop</h1>
<div class="content">
<div class="menu">
<ul class="itemshop">
<li><a href="itemshop/newest">Newest</a></li><li><a href="itemshop/armor" class="active" id="armor">Armor</a></li><li><a href="itemshop/rings">Rings</a></li><li><a href="itemshop/melee-weapons" id="melee-weapons">Melee Weapons</a></li><li><a href="itemshop/ranged-weapons" id="ranged-weapons">Ranged Weapons</a></li><li><a href="itemshop/meds">Meds</a></li><li><a href="itemshop/other">Other</a></li> </ul>
</div>
<div class="submenu">
<ul class="shop_armor"><li><a href="itemshop/armor/normal-set" class="active">Normal Set</a></li><li><a href="itemshop/armor/heads">Heads</a></li></ul><ul class="shop_melee-weapons"style="display:none;"><li><a href="itemshop/melee-weapons/sword">Sword</a></li><li><a href="itemshop/melee-weapons/dagger">Dagger</a></li></ul><ul class="shop_ranged-weapons"style="display:none;"><li><a href="itemshop/ranged-weapons/shotgun">Shotgun</a></li><li><a href="itemshop/ranged-weapons/rocket-launcher">Rocket Launcher</a></li><li><a href="itemshop/ranged-weapons/pistol-revolver">Pistol / Revolver</a></li><li><a href="itemshop/ranged-weapons/rifle">Rifle</a></li><li><a href="itemshop/ranged-weapons/sniper">Sniper</a></li></ul>	</div>
		<div class="contents">
			<ul class="items">
<?
while($item = mssql_fetch_assoc($res)) {
if ($count == 3) {
$count = 1;
?>
				<li class="tooltip" onclick="window.location = 'index.php?do=itemshop-normal-set&sub=details&id=<?=$item['CSID']?>'" title="Pre�o: <?=$item['CashPrice']?> coins">
                                <img src="images/items/<?=$item['WebImgName']?>" width="92" height="92" />
                                <div id="item-name"><span class="name"><?=$item['Name']?></span></div></li>
<?
}else{
?>
				<li class="tooltip" onclick="window.location = 'index.php?do=itemshop-normal-set&sub=details&id=<?=$item['CSID']?>'" title="Pre�o: <?=$item['CashPrice']?> coins">
                                <img src="images/items/<?=$item['WebImgName']?>" width="92" height="92" />
                                <div id="item-name"><span class="name"><?=$item['Name']?></span></div></li>

<?
$count++;
} }
?>
			</ul>
			<div style="clear:both;"></div>
			<br />
		</div>
		<br />
	</div>
	<div class="footer"></div>
</div>						<!--// Latest Items \\-->

<?
}  }

if(!function_exists("ShowItemsDetails")){
    function ShowItemsDetails(){
    if($_GET['id'] == ""){
        re_dir("index.php");
    }
    $itemz = clean($_GET['id']);
    $res = mssql_query_logged("SELECT * FROM RZSetShop WHERE CSID = '$itemz'");
    $item = mssql_fetch_assoc($res);
    $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
    $acc = mssql_fetch_assoc($res2);
    ?>
<div id="content-center"><div id="main">
<h1>Item</h1>
<div class="content">
<div class="contents">
<div class="itemview">
<div class="left">
<img src="images/items/<?=$item['WebImgName']?>" width="92" height="92"/><br/>
<?
$result = $acc['RZCoins']-$item['CashPrice'];
if($result < 0){
$boton = "<a href=''>&nbsp;&nbsp;&nbsp;No Coins&nbsp;&nbsp;</a>";
}else{
$boton = "<a href='index.php?do='>&nbsp;&nbsp;&nbsp;No Coins&nbsp;&nbsp;</a>";
}?>
<?
if ($_SESSION['AID'] == ""){
?>
<a class="login" title="Login First!">Login!</a>
<? }else{ ?>
<?
$result = $acc['RZCoins']-$item['CashPrice'];
if($result < 0){
?>
<a href=''>&nbsp;&nbsp;&nbsp;No Coins&nbsp;&nbsp;</a>
<? }else{ ?>
<a href="index.php?do=itemshop-normal-set&sub=buyitem&expand=1&itemid=<?=$item['CSID']?>">&nbsp;&nbsp;&nbsp;Comprar&nbsp;&nbsp;</a>
<? }} ?>
</div>
<div class="left">
<h2><?=$item['Name']?></h2>
<table>
<tr height="15"></tr>
<tr><td>Type:</td><td><?
                      switch ( $item['Slot'] ){
                      case "1";
                      $slot = "SET";
                      break;
                      case "2";
                      $slot = "SET";
                      break;
                      case "3";
                      $slot = "SET";
                      break;
                      case "4";
                      $slot = "SET";
                      break;
                      case "5";
                      $slot = "SET";
                      break;
                      case "6";
                      $slot = "SET";
                      break;
                      case "7";
                      $slot = "SET";
                      break;
                      case "8";
                      $slot = "SET";
                      break;
                      case "9";
                      $slot = "SET";
                      break;
                      case "10";
                      $slot = "SET";
                      break;
                      case "11";
                      $slot = "SET";
                      break;
                      case "12";
                      $slot = "SET";
                      break;
                      } echo $slot;

                      ?></td></tr>
<tr><td>Sex:</td><td><?
                     switch ($item['ResSex']){
                     case "0";
                     $sex = "Masculino";
                     break;
                     case "1";
                     $sex = "Feminino";
                     break;
                     case "2";
                     $sex = "Todos";
                     break;
                     } echo $sex;
                     ?></td></tr>
<tr><td>Level:</td><td><?=$item['ResLevel']?></td></tr>
<tr><td>Weight:</td><td><?=$item['Weight']?></td></tr>
<tr height="12"></tr>
<tr><td>Price:</td><td><?=$item['CashPrice']?> FCoins</td></tr>
</table>
</div>
<div class="stats" style="clear:both;">
<h3><?=$item['Description']?></h3>
<table>
<tr>
<td class="type">Damage</td>
<td class="val"><?=$item['Damage']?></td>
<td class="type">HP</td>
<td class="val"><?=$item['HP']?></td>
<td class="type">FR</td>
<td class="val"><?=$item['FR']?></td>
</tr>
<tr>
<td class="type">Delay</td>
<td class="val"><?=$item['Delay']?></td>
<td class="type">AP</td>
<td class="val"><?=$item['AP']?></td>
<td class="type">CR</td>
<td class="val"><?=$item['CR']?></td>
</tr>
<tr>
<td class="type">Magazine</td>
<td class="val"><?=$item['Magazine']?></td>
<td class="type">Max Weight</td>
<td class="val"><?=$item['MaxWeight']?></td>
<td class="type">PR</td>
<td class="val"><?=$item['PR']?></td>
</tr>
<tr>
<td class="type">Max Bullet</td>
<td class="val"><?=$item['MaxBullet']?></td>
<td class="type">Reload Time</td>
<td class="val"><?=$item['ReloadTime']?></td>
<td class="type">LR</td>
<td class="val"><?=$item['LR']?></td>
</tr>
</table>
</div>
</div>
<div style="clear:both;"></div>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>
<?
} }


if(!function_exists("ShowBuyItem")){
    function ShowBuyItem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php?do=login");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM RZSetShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
       if(isset($_POST['submit'])){
            $itemid = clean($_POST['ItemID']);
            $res = mssql_query_logged("SELECT * FROM RZSetShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $item1 = $item['ItemID1'];
            $item2 = $item['ItemID2'];
            $item3 = $item['ItemID3'];
            $item4 = $item['ItemID4'];
            $item5 = $item['ItemID5'];
            $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['RZCoins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By LaMbDa FrOm SpAiN!!! :)");
            }
            mssql_query_logged("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '".$item['ItemID1']."', GETDATE(), 0)");
            mssql_query_logged("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '".$item['ItemID2']."', GETDATE(), 0)");
            mssql_query_logged("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '".$item['ItemID3']."', GETDATE(), 0)");
            mssql_query_logged("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '".$item['ItemID4']."', GETDATE(), 0)");
            mssql_query_logged("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '".$item['ItemID5']."', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET RZCoins = '$updatecoins' WHERE AID = '$aid'");
            msgbox("Item Enviado para seu banco","index.php?do=itemshop-normal-set&sub=listallitems&expand=1&type=1");
       }
       ?>
<div id="content-center"><div id="main">
<h1>Comprar Item</h1>
<div class="content">
<div class="contents">
<p>
Voc� tem certeza que deseja comprar o: <span class="ignore"><?=$item['Name']?></span><br/>
Voc� possui <?=$acc['RZCoins']?> Coins<br/><br/>
<form method="POST" action="index.php?do=itemshop-normal-set&sub=buyitem">
<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
<input type="submit" name="submit" value="Comprar" class="button" style="color:green;"/> 
<input type="submit" class="button" style="color:red;" onclick="window.location = 'index.php?do=itemshop-normal-set&sub=details&id=<?=$item['CSID']?>'; return false;" value="Cancel"/>
</form>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  
<?
} }

if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "normalset";
        normalset();
    break;
    case "details";
        ShowItemsDetails();
    break;
    case "buyitem";
        ShowBuyItem();
    break;
}
}



?>