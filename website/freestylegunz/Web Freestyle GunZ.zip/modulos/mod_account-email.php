<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
     $email = clean($_POST['newemail']);

        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Email em uso.","index.php?do=account-email");
            $er = 1;
        }

        if($email == ""){
            msgbox("Por favor digite o Email.","index.php?do=account-email");
            $er = 1;
        }

        if($er == 0){
            $registered = 1;
	  mssql_query_logged("UPDATE Account SET Email='$email' WHERE UserID='".$_SESSION['UserID']."'");
        }else{
            msgbox("Error","index.php?do=account-home");
        }
}



if ($registered == 0){
?>
<div id="content-center"><div id="main">
<h1>Conta</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc" class="active">Minha conta</a></li><li><a href="index.php?do=account-character">Meus Chars</a></li><li><a href="index.php?do=account-clan">Meus clans</a></li></ul></div><div class="submenu"><ul class="tab_myacc"><li class="first"><a href="index.php?do=account-home">Info da Conta</a></li><li><a href="index.php?do=account-email" class="active">Editar Email</a></li><li><a href="index.php?do=account-senha">Alterar Senha</a></li></ul></div> <div class="contents">
<form name="reg" method="POST" action="index.php?do=account-email">
<input type="hidden" name="request" value="email"/>
<table border="0">
<tr><span class="title">Editar Email</span></tr>
<tr><td>Novo Email</td><td><input type="text" name="newemail"/></td></tr>
<tr><td></td><td><input type="submit" name="submit" class="button" value="Alterar"/></td></tr>
</table>
</form>
<br/><br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  
<?
}else{
    msgbox("O email foi alterado corretamente","index.php?do=account-home");
}
?>