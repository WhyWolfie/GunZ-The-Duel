<?
$errorcode = "";
$er = 0;
$registered = 0;
$simbolo1 = �;
$simbolo2 = �;
$simbolo3 = �;
$simbolo4 = �;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $sq = clean($_POST['sq']);
    $sa = clean($_POST['sa']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Email em uso.","index.php?do=registro");
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Usuario em uso.","index.php?do=registro");
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            msgbox("As senhas n�o coincidem.","index.php?do=registro");
            $er = 1;
        }


        if($user == ""){
            msgbox("Por favor digite o nome de Usuario.","index.php?do=registro");
            $er = 1;
        }

        if($email == ""){
            msgbox("Por favor digite o nome de Email.","index.php?do=registro");
            $er = 1;
        }

        if(strlen($pw1) < 6){
            msgbox("Por favor insira uma senha com seis ou mais caracteres.","index.php?do=registro");
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            msgbox("Por favor insira uma senha.","index.php?do=registro");
            $er = 1;
        }

        if($sq == ""){
            msgbox("Por favor insira uma pergunta secreta.","index.php?do=registro");
            $er =1;
        }

        if($sa == ""){
            msgbox("Por favor insira uma resposta secreta.","index.php?do=registro");
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, UGradeID, PGradeID, RegDate, sa, sq)Values ('$user', NULL, '$name','$email', 0, 0, GETDATE(), '$sa', '$sq')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins])VALUES('$user','$aid','$pw1',0,0)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>
<div id="content-center"><div id="main">
<h1>Registrar Conta</h1>
<div class="content">
<div class="contents">
<p>
<form name="reg" method="POST" action="index.php?do=registro">
<p class="notify">A sua privacidade � importante para n�s. N�o d� sua senha para ninguem.</p><br/>
<table>
<tr><td width="110">Username</td><td><input type="text" name="userid" onchange="sendrequest('registerAPI', 'user', this.value);" value="" autocomplete="off"/></td></tr>
<tr><td>Senha</td><td><input type="password" name="pw1" onblur="sendrequest('registerAPI', 'pw1', this.value);" value="" autocomplete="off"/></td></tr>
<tr><td>Confirme sua senha</td><td><input type="password" name="pw2" onblur="sendrequest('registerAPI', 'pw2', this.value);" value="" autocomplete="off"/></td></tr>
</table>
<br/><p class="notify">Por favor insira um endere�o de e-mail v�lido.</p><br/>
<table>
<tr><td width="110">Endere�o de Email.</td><td><input type="text" name="email" onchange="sendrequest('registerAPI', 'email', this.value);" value="" autocomplete="off"/></td></tr>
</table>
<br/><p class="notify">A pergunta e a resposta de seguran�a � usada para recuperar sua senha.</p><br/>
<table>
<tr><td width="110">Pergunta Secreta</td><td><select name="sq"><option>---</option><option value="0">Qual � o nome do seu primeiro animal de estima��o?</option><option value="1">Qual era o seu apelido de inf�ncia?</option><option value="2">Qual � o seu filme favorito?</option><option value="3">Qual � o primeiro nome da sua av�?</option><option value="4">Qual era o nome da sua primeira escola?</option><option value="5">Quem foi o seu her�i de inf�ncia?</option><option value="6">Qual � o nome do seu amigo de inf�ncia preferido(a)?</option></select></td></tr>
<tr><td>Resposta Secreta</td><td><input type="text" name="sa" autocomplete="off"/></td></tr>
</table>
</noscript> <br/><p class="notify">Ao se registrar, voc� concorda com nossos <a href="index.php?do=terms-of-service">Termos de Servi�o</a></p><br/>
<input type="submit" class="button" value="Registrar" name="submit"/>
</form>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  
<?
}else{
?>
<div id="content-center"><div id="main">
<h1>Registrar Conta</h1>
<div class="content">
<div class="contents">
<p>
<img src="images/success.png" class="code1">;&nbsp;&nbsp;&nbsp;&nbspA conta foi criada com sucesso! Divirta-se jogando Flah GunZ!<br/><br/>
Convide seus amigos para jogar o Flash Gunz.
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  
<? } ?>