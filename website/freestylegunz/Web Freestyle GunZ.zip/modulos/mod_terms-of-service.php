<div id="content-center"><div id="main">
<h1>Termos de Servi�o</h1>
<div class="content">
<div class="contents">
<p>
Qualquer membro da equipe de MAIET Entertainment, Inc., seus s�cios, afiliados, etc, e qualquer pessoa que pretenda fornecer disse que os partidos com informa��es s�o expressamente proibidos de acessar o nosso servidor e nosso site. Fazer isso seria uma viola��o direta das leis de privacidade de informa��o, e poderia ter repercuss�es legais.
<br/><br/>
Ao jogar neste servidor e visitar o nosso site, voc� concorda em n�o fornecer MAIET Entertainment, Inc., seus s�cios, afiliados, etc, e qualquer pessoa que pretenda fornecer disse partidos com informa��es sobre o nosso servidor e nosso site. Se o fizer, � motivo para expuls�o imediata do servidor e site.
<br/><br/>
<span class="ignore">Ao visualizar este site, voc� concorda com os seguintes Termos de Servi�o e Regras:</span>
<br/><br/>
<span class="ignore">1.</span> Voc� n�o est� de forma alguma relacionado, contratada ou ao servi�o de Maiet, ijji, Aeria Games ou qualquer organiza��o de governo de qualquer pa�s.<br/>
<span class="ignore">2.</span> Voc� n�o registrara em nome de um grupo anti-pirataria.<br/>
<span class="ignore">3.</span> Gunz Mundial � uma comunidade estrita privado para os jogadores apenas, qualquer outro tipo de indiv�duo n�o � permitido para se cadastrar.<br/>
<span class="ignore">4.</span> Este GunZ � um servi�o gratuito que n�o requer qualquer tipo de pagamento, este � um servi�o aberto para todos que se registrou e concordou com este acordo de licen�a.<br/>
<span class="ignore">5.</span> Este GunZ oferece um servi�o gratuito, mas n�s n�o aceitamos doa��es para apoiar o nosso servi�o a partir de um usu�rios francas passar�o, de devolver o seu efeito e suporte para o servidor ser� recompensado com itens de doa��o. Todas as doa��es feitas para o servidor n�o s�o reembols�veis??.<br/>
<span class="ignore">6.</span> Presentes de doa��o n�o ser� restaurada se perdeu de forma alguma.<br/>
<span class="ignore">7.</span> Este GunZ reserva pleno direito de n�o enviar presentes doa��o.<br/>
<span class="ignore">8.</span> Este GunZ � um servi�o gratuito. N�s s� temos os usu�rios, n�o clientes.<br/>
<span class="ignore">9.</span> Este GunZ reserva-se o direito de remover qualquer um o seu acesso ao servi�o GunZ Freestyle por qualquer motivo.<br/>
<span class="ignore">10.</span> Qualquer usu�rio deve respeitar todos os membros da equipe e outros usu�rios.<br/>
<span class="ignore">11.</span> O uso de programas n�o autorizados, diretamente / indiretamente interferem com a jogabilidade do servidor, o que permite ao usu�rio obter uma vantagem de qualquer maneira, ir� resultar em uma proibi��o.<br/>
<span class="ignore">12.</span> Este GunZ n�o carrega nenhuma responsabilidade da seguran�a de sua conta, se voc� fornece sua senha, voc� est� colocando sua conta em risco de ser roubado.<br/>
<span class="ignore">13.</span> Em qualquer caso de qualquer usu�rio o acesso a ser removida do servidor, os funcion�rios t�m o direito de restaurar ou n�o para restaurar sua conta qualquer um / dados de sua livre vontade.<br/>
<br/><br/><br/>
<span class="ignore">Este GunZ reserva-se o direito de alterar os Termos e Condi��es a qualquer momento, por qualquer motivo, sem aviso pr�vio.</span>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  