<?
if($_SESSION[AID] == "")
{
?>
<div id="content-center"><div id="main">
<h1>Login</h1>
<div class="content">
<div class="contents">
<br/>
<p>
Por favor logue-se para acessar sua conta.<br/><br/>
</p>
<form name="login" method="POST" action="index.php?do=logar">
<table>
<tr><td>Ususario</td><td><input type="text" name="userid" autocomplete="off"/></td></tr>
<tr><td>Senha</td><td><input type="password" name="pass" autocomplete="off"/></td></tr>
<tr><td></td><td><input type="submit" name="submit" value="Login"/></td></tr>
</table>
</form>
<p>
<br/><a href="recovery">Esqueceu sua senha?</a>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  
<? 
}else{
 msgbox("Voc� ja est� logado.","index.php?do=account-home");
}
 ?>