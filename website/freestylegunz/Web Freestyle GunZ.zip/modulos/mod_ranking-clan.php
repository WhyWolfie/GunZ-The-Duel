<?
$errorcode = "";
$er = 0;
$registered = 0;
$res = mssql_query("SELECT TOP 100 Name, Point, CLID, Wins, Losses, MasterCID FROM Clan WHERE Name != '' ORDER BY Wins DESC");
$count = 0;
if (isset($_POST['submit'])){
     $name = clean($_POST['name']);


        $busca = mssql_query_logged("SELECT * FROM Clan WHERE Name = '".$name."'");
        if (mssql_num_rows($busca) <= 0){
            msgbox("Clan inexistente","index.php?do=ranking-clan");
            $er = 1;
        }

        if($er == 0){
            $registered = 1;
	  mssql_query_logged("SELECT * FROM Clan WHERE Name='$name' ORDER BY Level DESC");
        }else{
            msgbox("Error","index.php?do=account-home");
        }
}



if ($registered == 0){
?>
<div id="content-center">
<div id="main">
<h1>Clan Ranking</h1>
<div class="content">
<div class="menu"><ul class="ranking"><li><a href="index.php?do=ranking-individual">Individual Ranking</a></li><li><a>|</a></li><li><a href="index.php?do=ranking-clan" class="active">Clan Ranking</a></li></ul></div>
<div class="contents">
<form name="reg" method="POST" action="index.php?do=ranking-clan">
<input type="hidden" name="type" id="rType" value="1"/>
<p>
Procurar um clan: <input type="text" name="name"/> <input type="submit" name="submit" class="button" value="Procurar"/>
</p>
</form>
<br />
<center>
  <div id="rankingtable">
<table width="450" style="margin-left:5px;"><tbody><tr class="rank_head"><td style="text-align: left">#</td><td width="80" style="text-align: left">Name</td><td style="text-align: left">Wins</td><td style="text-align: left">Losses</td><td style="text-align: left">Leader</td><td style="text-align: left">Points</td></tr>
<?
if(mssql_num_rows($res) == 0){
?>
	<tr>
	<td width="25"></td>
	<td width="50" align="center"></a></td>
	<td width="200" align="center">Nenhum clan foi encontrado</td>
	<td width="60" align="center"></td>
	<td width="40" align="center"></td>
	<td width="42" align="center"></td>
	</tr>
<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++;
?>
	<tr>
	<td width="25"><?=$count?></td>
	<td width="80" align="left"><a href="index.php?do=clan-view&id=<?=$r['CLID']?>"><?=utf8_encode($r['Name'])?></a></td>
	<td width="60" align="left"><?=$r['Wins']?></td>
	<td width="60" align="left"><?=$r['Losses']?></td>
<?
$query = mssql_query("SELECT Name From Character WHERE CID='".$r['MasterCID']."'");
while($f = mssql_fetch_assoc($query)){
?>
	<td width="200" align="left"><?=$f['Name']?></td>
<? } ?>
	<td width="42" align="left"><?=$r['Point']?></td>
	</tr>
<?}}?>
</tbody>
</table>
<br/>
<p style="margin:0px 0px 0px 118px;" id="navigation">
<br/></center>
</span>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div> 
<?
}else{
?>
<div id="content-center">
<div id="main">
<h1>Clan Ranking</h1>
<div class="content">
<div class="menu"><ul class="ranking"><li><a href="index.php?do=ranking-individual" class="active">Individual Ranking</a></li><li><a>|</a></li><li><a href="index.php?do=ranking-clan" class="active">Clan Ranking</a></li></ul></div>
<div class="contents">
<form name="reg" method="POST" action="index.php?do=ranking-clan">
<input type="hidden" name="type" id="rType" value="1"/>
<p>
Procurar um clan: <input type="text" name="name"/> <input type="submit" name="submit" class="button" value="Procurar"/>
</p>
</form>
<br />
<center>
  <div id="rankingtable">
<table width="450" style="margin-left:5px;"><tbody><tr class="rank_head"><td style="text-align: left">#</td><td width="80" style="text-align: left">Name</td><td style="text-align: left">Wins</td><td style="text-align: left">Losses</td><td style="text-align: left">Leader</td><td style="text-align: left">Points</td></tr>
<?
while($s = mssql_fetch_assoc($busca)){
$count++;
?>
	<tr>
	<td width="25"><?=$count?></td>
	<td width="80" align="left"><?=utf8_encode($s['Name'])?></a></td>
	<td width="60" align="left"><?=$s['Wins']?></td>
	<td width="60" align="left"><?=$s['Losses']?></td>
<?
$query1 = mssql_query("SELECT Name From Character WHERE CID='".$s['MasterCID']."'");
while($t = mssql_fetch_assoc($query1)){
?>
	<td width="200" align="left"><?=$t['Name']?></td>
<? } ?>
	<td width="42" align="left"><?=$s['Point']?></td>
	</tr>
<?}?>
</tbody>
</table>
<br/>
<p style="margin:0px 0px 0px 118px;" id="navigation">
<br/></center>
</span>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div> 
<? } ?>