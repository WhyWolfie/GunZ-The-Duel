<?
$query2 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '".$_SESSION['UserID']."' and Login.Password = '".$_SESSION['Pass']."' and ClanMember.Grade = '1' "); 
if (mssql_num_rows($query2) >= '1') 
{  
?> 
<div id="content-center"><div id="main">
<h1>Upload Emblem</h1>
<div class="content">
<div class="contents">
<p>
<form action="index.php?do=emblem" method="post" enctype="multipart/form-data"> 
<span class="title">Upload Emblem</span><br/>
<p>Clan: <select name="clid">
<?  
for($i=''; $i < @mssql_num_rows($query2); $i++) 
{ 
$row = @mssql_fetch_row($query2); 
$ClanName = $row[4]; 
?>
<option value="<?=$row[4]?>"><?=$row[4]?></option><? } ?></select></p>
<p>Emblem: <input type="file" name="foto"></p>
<input type="submit" name="submit" class="button" value="Enviar"> 
</form>
<?  
} 
else  
{  
echo "<span class='ignore'>Voc� n�o � o L�der do Clan</span>"; 
}
$erro = $config = array(); 

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE; 

$config["tamanho"] = 106883; 

$config["largura"] = 150; 

$config["altura"]  = 150; 

if (isset($_POST['submit'])){
     $clid = clean($_POST['clid']);  
    if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $arquivo["type"])) { 
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; 
    } else { 
        if ($arquivo["size"] > $config["tamanho"]) { 
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo"; 
        } 
         
        $tamanhos = getimagesize($arquivo["tmp_name"]); 
         
        if ($tamanhos[0] > $config["largura"]) { 
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels"; 
        } 

        if ($tamanhos[1] > $config["altura"]) { 
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels"; 
        } 
    } 
     
    if (sizeof($erro)) { 
        foreach ($erro as $err) { 
            echo " - " . $err . "<BR>"; 
        } 
        echo '<span class="ignore">Error, nao foi possivel fazer o upload do Emblema.</span>'; 
        echo "<span class='ignore'>$err</span>"; 
    } 

    else 
    { 
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext); 

        $imagem_nome = md5(uniqid(time())) . "." . $ext[1]; 

        $imagem_dir = "emblemas/" . $imagem_nome; // IMPORTANTE DEFINIR A PASTA DA IMAGEM 

        move_uploaded_file($arquivo["tmp_name"], $imagem_dir); 
         
        $query = mssql_query("UPDATE Clan Set EmblemURL='$imagem_dir' WHERE Name='$clid'"); 
        if($query){ 
        echo "<span class='ignore'>Seu emblema foi enviado com sucesso!</span>"; 
        } 

    } 
} 
?>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>