<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

$login22 = $_SESSION['login'];

$ugrade1 = mssql_query("SELECT UgradeID FROM Account WHERE UserID = '$login22'");
$ugrade2 = mssql_fetch_row($ugrade1);

$query1 = mssql_query("SELECT * FROM Login WHERE UserID = '$login22'");
$query2 = mssql_fetch_assoc($query1);

$query3 = mssql_query("SELECT * FROM Account WHERE UserID = '$login22'");
$query4 = mssql_fetch_assoc($query3);
?>
<div id="content-center"><div id="main">
<h1>Conta</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc" class="active">Minha conta</a></li><li><a href="index.php?do=account-character">Meus Chars</a></li><li><a href="account/clan">Meus clans</a></li></ul></div><div class="submenu"><ul class="tab_myacc"><li class="first"><a href="index.php?do=account-home" class="active">Info da conta</a></li><li><a href="index.php?do=account-email">Editar Email</a></li><li><a href="index.php?do=account-senha">Alterar senha</a></li></ul></div> <div class="contents">
<p>
<span class="ignore">Informa��es de sua conta:</span>
</p>
<table id="accinfo"><tr><td width="80">Ultimo Login:</td><td class="value"><?=$query4['LastLoginTime']?></td></tr><tr width="80"><td>Ultimo IP:</td><td class="value"><?=$query2['LastIP']?></td></tr><tr width="80"><td>E-mail:</td><td class="value"><?=$query4['Email']?></td></tr><tr width="80"><td>Rank:</td><td class="value"><?
                                                    switch ( $query4['UGradeID'] ){
                                                        case "0";
                                                        $ugradeID = "Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeID = "Event Winner";
                                                        break;
                                                        case "3";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "4";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "5";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "6";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "7";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "8";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "9";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "10";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "11";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "12";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Mute";
                                                        break;
                                                        case "252";
                                                        $ugradeID = "Moderador";
                                                        break;
                                                        case "254";
                                                        $ugradeID = "Game Master";
                                                        break;
                                                        case "255";
                                                        $ugradeID = "Administrador";
                                                        break;
                                                    } echo $ugradeID;

                                                        ?></td></tr><tr width="80"><td>Event Points:</td><td class="value"><?=$query2['EVCoins']?></td></tr><tr width="80"><td>Coins:</td><td class="value"><?=$query2['RZCoins']?></td></tr></table>
 <br/>
<p>
<span class="ignore">Quer mais Coins? Donate Agora, <a href="page/donation-page" style="font-weight:bold;">Clicar Aqui!</a></span><br/><br/>
Click <a href="index.php?do=account-avatar">aqui</a> para trocar o avatar da sua conta.
</div>
<br/>
</div>
<div class="footer"></div>
</div> 