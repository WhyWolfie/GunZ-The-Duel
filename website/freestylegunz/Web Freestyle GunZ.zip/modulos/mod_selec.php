<div id="content-center"><div id="main">
<h1>Download</h1>
<div class="content">
<div class="contents">
<p>

</p>
<br/>
<div class="download_mirrors">
<p>
<a href=/index.php?do=rzitemshop><img src="http://i.imgur.com/5sJpgJM.png" border="0"></a> <a href=/index.php?do=selec><img src="http://i.imgur.com/HbAoXqj.png" border="0"></a> <a href=/index.php?do=selec><img src="http://i.imgur.com/HbAoXqj.png" border="0"></a>
</p>
</div>
<p>
<br/><br/>
<br/>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  