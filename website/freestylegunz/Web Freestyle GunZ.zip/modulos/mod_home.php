<div id="content-center">  
<div id="slider">
<ul>
<li class="slider1"><a href="http://freestylersworld.com/showthread.php?45823-Merry-Christmas!-New-Website-Lucky-Box-New-Shotgun&p=494702&viewfull=1#post494702" target="_blank"><img src="images/slider/1.jpg" width="523" height="133"/></a></li>
<li class="slider2"><a href="http://freestylersworld.com/showthread.php?42090-Freestylers-Book-of-Records-Function" target="_blank"><img src="images/slider/2.jpg" width="523" height="133"/></a></li>
<li class="slider3"><a href="gamble/lucky-box"><img src="images/slider/3.jpg" width="523" height="133"/></a></li>
<li class="slider4"><a href="page/referrals"><img src="images/slider/4.jpg" width="523" height="133"/></a></li>
</ul>
<div class="bullets">
<a href="#" onclick="return false;" class="bullet1"></a>
<a href="#" onclick="return false;" class="bullet2"></a>
<a href="#" onclick="return false;" class="bullet3"></a>
<a href="#" onclick="return false;" class="bullet4"></a>
</div>
</div>
<div id="news">
<div id="news-items">
<div id="news-title"><span class="date">11 Dec 2012</span> <span class="title">New Update: Tons of Fixes, New Content, Free Avatars</span> <a href="#" onclick="return false;" class="active" id="news1"></a></div><div id="news-content" class="news1"><p>A big new update has been applied today!<br/><br/>This includes:<br/>- A lot of <b>bugfixes</b> and <b>game improvements</b><br/>- <b>New Content</b> (Items, Clothes)<br/>- All Avatars are now <b>free</b>!<br/>- New CTF Flag (By HellSniper)<br/>- Multiple custom crosshair support<br/>- Collision issue fixed<br/><br/>...and much more!<br/><br/><b>Click <a href="http://freestylersworld.com/showthread.php?45273-Update-10-December-2012&p=488191&viewfull=1#post488191">here</a> for details.</b></p></div><div id="news-title"><span class="date">19 Sep 2012</span> <span class="title">New Server, New Host &amp; New Update!</span> <a href="#" onclick="return false;" class="active" id="news2"></a></div><div id="news-content" class="news2"><p>We are happy to announce a few great changes at Freestyle GunZ.<br/><br/>
- New <b>Dedicated Highspeed Server</b>, much better and much faster! (4x 3.2 GHz, 16 GB RAM, SSD, 1 GBit Connection) - Speedtest: <a href="http://puu.sh/15fT6">Click here.</a><br/>
- <b>New</b> Custom <b>Scoreboard</b><br/>
- <b>Bugfixes</b><br/>
- New Map: <b>Darker</b><br/>
...and much more! <b>Click <a href="http://freestylersworld.com/showthread.php?42721-New-Server-Host-New-Update!-%28September-19th-2012%29">here</a> for details. :)</b></p></div><div id="news-title"><span class="date">22 Aug 2012</span> <span class="title">The Big Bang Update (CTF, DamageMeter, better Anti-Lead, more)</span> <a href="#" onclick="return false;" class="active" id="news3"></a></div><div id="news-content" class="news3"><p>A new update has been released today. This includes:<br/>
- New game mode: <b>Capture The Flag (CTF)</b><br/>
- <b>Damage Meter</b><br/>
- <b>Optimized anti-lead</b><br/>
- <b>New Interface</b><br/>
...new map, (crash-)bugfixes, and much more!<br/><br/>
Click <a href="http://freestylersworld.com/showthread.php?41723-FGunZ-Big-Bang-Update!-%28August-21st-2012%29&p=449234#post449234">here</a> and <a href="http://freestylersworld.com/showthread.php?41723-FGunZ-Big-Bang-Update!-%28August-21st-2012%29/page7&p=451020#post451020">here</a> for details. :)</p></div> </div>
</div>  