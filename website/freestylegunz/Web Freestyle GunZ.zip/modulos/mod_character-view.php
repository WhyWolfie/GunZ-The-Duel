<?
    $cid = antisql($_GET['id']);
if(!is_numeric($cid)){
msgbox("Not Available","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);


if($num_rows < 1){
msgbox("Account Does not Exist","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "253" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "254" || $char2['UGradeID'] == "255"){
    msgbox("You are not allowed to View this Account Information.","index.php");
exit();
	}

	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

$query = mssql_query("SELECT * FROM Account WHERE AID = '".$char2['AID']."'");
$avatar = mssql_fetch_object($query);

?>
<div id="content-center"><div id="main">
<h1>Character View</h1>
<div class="content">
<div class="contents">
<div class="charview">
<div class="left">
<img src="<?=($avatar->AvatarUrl == '') ? 'images/avatars/no-avatar.png' : $avatar->AvatarUrl?>" width="92" height="92"><br/>
</div>
<div class="left">
<h2 style="color:gray;"><?=utf8_encode(FormatCharName($char['CID']))?></h2>
<table>
<tr height="20"></tr>
<tr><td>Level:</td><td><?=$char['Level']?></td></tr>
<tr><td>K/D:</td><td><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td></tr>
<tr><td>Clan:</td><td> <?=$claninfo['Name']?> </td></tr>
</table>
</div>
<div class="stats" style="clear:both;">
<br/>
<table>
<tr>
<td class="type">Kill's</td>
<td class="val"><?=$char['DeathCount']?></td>
<td class="type">Pa�s</td>
<td class="val"><img src="images/countryflag/Brasil.png" title="Brasil"/></td>
</tr>
<tr>
<td class="type">Death's</td>
<td class="val"><?=$char['KillCount']?></td>
<td class="type">Playtime</td>
<td class="val"><?=$char['PlayTime']?></td>
</tr>
<tr>
<td class="type">Sexo</td>
<td class="val"><?
		switch ( $char['Sex'] ){
		case "0";
		$char['Sex'] = "Masculino";
		break;
		case "1";
		$char['Sex'] = "Feminino";
		break;
		} echo $char['Sex'];
                ?></td>
<td class="type">Criado</td>
<td class="val"><?=$char['RegDate']?></td>
</tr>
<tr>
<td class="type">XP</td>
<td class="val"><?=$char['XP']?></td>
<td class="type">Ultimo Login</td>
<td class="val"><?=$char['LastTime']?></td>
</tr>
</table>
</div>
</div>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>