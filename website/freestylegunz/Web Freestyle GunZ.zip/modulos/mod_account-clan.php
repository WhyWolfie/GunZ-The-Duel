<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$aid = $_SESSION['AID'];
$query = mssql_query("SELECT * FROM Character WHERE AID = '$aid'");
$query1 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$query['CID']."' AND Grade = '1'");
$query2 = mssql_query("SELECT *  FROM Clan WHERE CLID = '".$query1['CLID']."'");
?>
<div id="content-center"><div id="main">
<h1>Account</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc">Minha Conta</a></li><li><a href="index.php?do=account-character">Meus Chars</a></li><li><a href="index.php?do=account-clan" class="active">My Clan(s)</a></li></ul></div><div class="submenu"><ul class="tab_myacc" style="display:none;"><li class="first"><a href="account/home">Account Information</a></li><li><a href="account/email">Edit Email</a></li><li><a href="account/password">Change Password</a></li></ul></div> <div class="contents">
<p>
<span class="title">Seus clans:</span><br/><br/><div id="rankingtable"><table>
<tr class="rank_head">
<td width="85">Name</td>
<td width="85">Character</td>
<td>Points</td>
<td>Wins</td>
<td>Losses</td>
<td>Draws</td>
<td>Emblem</td>
<td>Manage</td></tr>
<?
while($clans = mssql_fetch_assoc($query2)){
?>
<tr><td><a href="clan/view/Bang"><?=$clans['Name']?></a></td>
<td><a href="character/view/Chimpanze" class="ignore">Chimpanze</a></td>
<td><?=$clans['Point']?></td>
<td><?=$clans['Wins']?></td>
<td><?=$clans['Losses']?></td>
<td><?=$clans['Draws']?></td>
<td>&nbsp;</td>
<td><a href="account/clan/manage/41416">Manage</a></td></tr><?}?>
</table></div>
<?
$query3 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '".$_SESSION['UserID']."' and Login.Password = '".$_SESSION['Pass']."' and ClanMember.Grade = '1' "); 
if (mssql_num_rows($query3) >= '1') 
{  
?> 
<br/><span class="title">Upload Emblem</span>
<form action="index.php?do=account-clan" method="post" enctype="multipart/form-data"> 
<table border="0">
<tr><td>Clan</td><td><select name="clid">
<?  
for($i=''; $i < @mssql_num_rows($query3); $i++) 
{ 
$row = @mssql_fetch_row($query3); 
$ClanName = $row[4]; 
?>
<option value="<?=$row[4]?>"><?=$row[4]?></option><? } ?></select></td></tr>
<tr><td>Image</td><td><input name="foto" type="file"/></td></tr>
<tr><td></td><td><input type="submit" name="submit" class="button" value="Enviar"> </td></tr>
</table>
<?  
} 
else  
{  
echo "<span class='ignore'>Voc� n�o � o L�der do Clan</span>"; 
}
$erro = $config = array(); 

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE; 

$config["tamanho"] = 106883; 

$config["largura"] = 150; 

$config["altura"]  = 150; 

if (isset($_POST['submit'])){
     $clid = clean($_POST['clid']);  
    if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $arquivo["type"])) { 
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; 
    } else { 
        if ($arquivo["size"] > $config["tamanho"]) { 
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo"; 
        } 
         
        $tamanhos = getimagesize($arquivo["tmp_name"]); 
         
        if ($tamanhos[0] > $config["largura"]) { 
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels"; 
        } 

        if ($tamanhos[1] > $config["altura"]) { 
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels"; 
        } 
    } 
     
    if (sizeof($erro)) { 
        foreach ($erro as $err) { 
            echo " - " . $err . "<BR>"; 
        } 
        echo '<span class="ignore">Error, nao foi possivel fazer o upload do Emblema.</span>'; 
        echo "<span class='ignore'>$err</span>"; 
    } 

    else 
    { 
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext); 

        $imagem_nome = md5(uniqid(time())) . "." . $ext[1]; 

        $imagem_dir = "emblem_beta/" . $imagem_nome; // IMPORTANTE DEFINIR A PASTA DA IMAGEM 

        move_uploaded_file($arquivo["tmp_name"], $imagem_dir); 

        $query1 = mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$clid'");
        $query = mssql_query("UPDATE Clan Set EmblemURL='$imagem_dir' WHERE Name='$clid'"); 
        if($query){ 
        echo "<span class='ignore'>Seu emblema foi enviado com sucesso!</span>"; 
        } 

    } 
} 
?>
</form><br/>
<br/>
<form action="" method="post" id="delclan" onsubmit="postform('accountAPI', 'delclan'); return false;">
<input type="hidden" name="request" value="delclan"/>
<table border="0">
<tr><span class="title">Delete Own Clan</span></tr>
<tr><td>Clan</td><td><select name="clid"><option value="41416">Bang</option></select></td></tr>
<tr><td></td><td><input type="submit" name="declan" class="button" value="Delete" onclick="javascript: var t = confirm('Are you sure you want to delete this clan?'); if(t == true){ return true; } else{ return false;}"/></td></tr>
</table>
</form><br/>
<br/>
<form action="" method="post" id="resetclan" onsubmit="postform('accountAPI', 'resetclan'); return false;">
<input type="hidden" name="request" value="resetclan"/>
<table border="0">
<tr><span class="title">Reset Clan Score</span></tr>
<tr><td>Clan</td><td><select name="clid"><option value="41416">Bang</option></select></td></tr>
<tr><td></td><td><input type="submit" name="resetclan" class="button" value="Reset" onclick="javascript: var t = confirm('Are you sure you want to reset the clan score of this clan?'); if(t == true){ return true; } else{ return false;}"/></td></tr>
</table>
</form><br/>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>