<?
$usr = $_SESSION['login'];
mssql_query("DELETE FROM LoggedUsers WHERE UserID = '$usr'");
unset($_SESSION['UserID']);
unset($_SESSION['Login']);
unset($_SESSION['AID']);
unset($_SESSION['UGradeID']);
unset($_SESSION['Senha']);
unset($_SESSION['Pass']);
session_unset();
$_SESSION = array();
msgbox ("Deslogado!","index.php");
?>