<div id="content-center"><div id="main">
<h1>FAQ</h1>
<div class="content">
<div class="contents">
<p>
<font color="red">Client e Launcher</font><br/>
<a href="#">1.0) Falta de arquivos? Baix�-los aqui.</a><br/>
<a href="index.php?do=frequently-asked-questions#1.1">1.1) Meu Gunz Launcher est� desaparecido.</a><br/>
<a href="index.php?do=frequently-asked-questions#1.2">1.2) Meu Gunz Launcher n�o est� atualizando meus arquivos.</a><br/>
<a href="index.php?do=frequently-asked-questions#1.3">1.3) Eu n�o posso ver nenhum servidor no jogo.</a><br/>
<a href="index.php?do=frequently-asked-questions#1.4">1.4) FGunZ n�o inicia.</a><br/>
<a href="index.php?do=frequently-asked-questions#1.5">1.5) Quando eu inicializei o FGunZ diz "Falha ao inicializar o Direct X"<br/>
<a href="index.php?do=frequently-asked-questions#1.6">1.6) Eu vejo "nomsg" em todos os lugares - OU - o jogo n�o se encaixa minha tela?<br/>
<a href="index.php?do=frequently-asked-questions#1.7">1.7) Eu recebo o "Game Launch Error!" mensagem.<br/><br/>
<font color="red">Account and Characters</font><br/>
<a href="index.php?do=frequently-asked-questions#2.0">2.0) Eu n�o consigo entrar. Aparece 'password errada "- OU - Eu esqueci a senha da minha conta.</a><br/>
<a href="index.php?do=frequently-asked-questions#2.1">2.1) Eu acidentalmente apaguei o meu char.</a><br/>
<a href="index.php?do=frequently-asked-questions#2.2">2.2) O site diz que eu tenho um cl�, mas eu n�o tenho um no jogo.</a><br/>
<a href="index.php?do=frequently-asked-questions#2.3">2.3) Posso partilhar a minha conta?</a><br/>
<a href="index.php?do=frequently-asked-questions#2.4">2.4) Eu posso ver o meu emblema no site, mas n�o no jogo.</a><br/><br/>
<font color="red">Donations</font><br/>
<a href="index.php?do=frequently-asked-questions#3.1">3.1) Eu n�o estou jogando FGunZ mais, posso ter meu dinheiro de volta?</a><br/>
<font color="red">- - -</font><br/><br/>
<a name="1.1">1.1) Meu Gunz Launcher est� desaparecido.</a><br/>
Seu anti-virus provavelmente excluiu.<br/>
Desative o software de anti-v�rus e baixe o Gunz Launcher <a href="#">aqui</a>, mova para a pasta do Gunz e add
o Gunz Launcher � lista de exce��es do seu software anti-v�rus para evitar problemas futuros.</a><br/><br/>

<a name="1.2">1.2) Meu Gunz Launcher n�o est� atualizando meus arquivos.</a><br/>
O seu software anti-v�rus ou firewall est� bloqueando.<br/>
Desabilite o seu anti-v�rus e firewall, ou adicionar o Gunz Launcher � lista de exce��es do seu software anti-v�rus e firewall. Tamb�m n�o se esque�a que voc� tem a �ltima launcher.exe. <br/>
Voc� pode baixar a �ltima launcher.exe <a href="#">aqui</a>.<br/><br/>

<a name="1.3">1.3) Eu n�o posso ver nenhum servidor no jogo.</a><br/>
O software de firewall ou anti-v�rus est� bloqueando o tr�fego de entrada e sa�da do Flash GunZ.<br/>
Adicione sua theduel.exe (dentro da sua pasta FGunZ) � lista de exce��es do seu firewall e anti-virus software e reiniciar o GunZ.<br/><br/>

<a name="1.4">1.4) FGunZ n�o inicia.</a><br/>
Seu firewall ou software anti-v�rus est� bloqueando o Launcher e o FGunZ.<br/>
Desative o seu anti-v�rus e firewall, ou adicione sua theduel.exe e launcher.exe (dentro da sua pasta FGunZ) � lista de exce��es do seu firewall e anti-virus software e reinicie o FGunZ.<br/><br/>

<a name="1.5">1.5) Quando eu inicializei o FGunZ diz "Falha ao inicializar o Direct X"</a><br/>
Apague o arquivo config.xml na pasta FGunZ e recomece o FGunZ.<br/><br/>

<a name="1.6">1.6) Eu vejo "nomsg" em todos os lugares - OU - o jogo n�o se encaixa minha tela?</a><br/>
Fix: Abra o arquivo config.xml (localizado na sua pasta FGunZ) com bloco de notas e alterar o seguinte:
<br/>&lt;WIDTH&gt;XXXX&lt;/WIDTH&gt;<br/>&lt;HEIGHT&gt;XXXX&lt;/HEIGHT&gt;<br/>Para:<br/>&lt;WIDTH&gt;800&lt;/WIDTH&gt;<br/>&lt;HEIGHT&gt;600&lt;/HEIGHT&gt;<br/><br/>Agora salve o arquivo e reinicie  o GunZ.<br/><br/>

<a name="1.7">1.7) Eu recebo o "Game Launch Error!" mensagem.</a><br/>
Voc� tem que desativar o DEP. <br/>Click <a href="index.php?do=desabilitar-dep" target="_blank">aqui</a> para um tutorial sobre como desativ�-lo. (Confira uma op��o)<br/><br/>
<font color="red">- - -</font><br/><br/>
<a name="2.0">2.0) Eu n�o consigo entrar. Aparece 'password errada "- OU - Eu esqueci a senha da minha conta.</a><br/>
Voc� pode recuperar sua conta <a href="index.php?do=recuperar">aqui</a>.<br/><br/>
<a name="2.1">2.1) Eu acidentalmente apaguei o meu char.</a><br/>
Voc� pode recuperar seu char <a href="#">aqui</a>.<br/><br/>
<a name="2.2">2.2) O site diz que eu tenho um cl�, mas eu n�o tenho um no jogo.</a><br/>
Voc� deve contatar um administradou ou moderador no forum.<br/><br/>
<a name="2.3">2.3) Posso partilhar a minha conta?</a><br/>
N�o apoiamos conta de partilha.
Se voc� perder sua conta porque voc� decidiu dar a sua senha, n�s n�o iremos recupera-la.<br/><br/>
<a name="2.4">2.4) Eu posso ver o meu emblema no site, mas n�o no jogo.</a><br/>
Leva algum tempo para emblemas a serem exibidos em jogo. <br/> Espere 2-3 dias depois de envi�-lo.<br/><br/>
<font color="red">- - -</font><br/><br/>
<a name="3.1">3.1) Eu n�o estou jogando FGunZ mais, posso ter meu dinheiro de volta?</a><br/>
N�o, voc� n�o pode. Doa��es s�o utilizadas para cobrir as despesas de hospedagem.<br/>
Se voc� abrir uma disputa, ent�o voc� ser� banido permanentemente do FGunZ.<br/><br/>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  