<?
$cinfo = antisql($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan n�o encontrado","index.php");
exit();
}

$clid = $clan->CLID;
?> 
<div id="content-center"><div id="main">
<h1>Clan View</h1>
<div class="content">
<div class="contents">
<div class="clanview">
<div class="left">
<img src="<?=($clan->EmblemUrl == "") ? "emblem_beta/noimage.png" : $clan->EmblemUrl?>" width="92" height="92" BORDER=5 ><br/>
</div>
<div class="left">
<h2><?=utf8_encode($clan->Name)?></h2>
<table>
<tr height="15"></tr>
<tr><td>Points:</td><td><?=$clan->Point?></td></tr>
<tr><td>Total Points:</td><td><?=$clan->TotalPoint?></td></tr>
<tr><td>Wins:</td><td><?=$clan->Wins?></td></tr>
<tr><td>Losses:</td><td><?=$clan->Losses?></td></tr>
</table>
</div>
<?
$grade1 = 1;
$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID ='$clid' AND Grade ='$grade1'");
$busca = mssql_fetch_assoc($query2);
$query3 = mssql_query("SELECT * FROM Character WHERE CID='".$busca['CID']."'");
$busca1 = mssql_fetch_assoc($query3);
?>
<div class="stats" style="clear:both;">
<table>
<tr class="rank"><td><font color="red">Leader</font></td></tr><tr height="5"></tr>
<tr><td><a href="index.php?do=character-view&id=<?=$busca1['CID']?>"><font color="gray"><?=$busca1['Name']?></font></a></td></tr><tr height="20"></tr>
<?
$grade2 = 2;
$query4 = mssql_query("SELECT * FROM ClanMember WHERE CLID ='$clid' AND Grade ='$grade2'");
$busca2 = mssql_fetch_assoc($query4);
$query5 = mssql_query("SELECT * FROM Character WHERE CID='".$busca2['CID']."'");
?>
<?
if(mssql_num_rows($query4) == 0){
?>
<?
}else{
?>
<tr class="rank"><td><font color="orange">Administrator</font></td></tr><tr height="5"></tr>
<?
while($busca3 = mssql_fetch_assoc($query5)){
?>
<tr><td><a href="index.php?do=character-view&id=<?=$busca3['CID']?>"><font color="gray"><?=$busca3['Name']?></font></a></td></tr><tr height="20"></tr><?}}?>
<?
$grade3 = 9;
$query6 = mssql_query("SELECT * FROM ClanMember WHERE CLID ='$clid' AND Grade ='$grade3'");
$busca4 = mssql_fetch_assoc($query4);
$query7 = mssql_query("SELECT * FROM Character WHERE CID='".$busca2['CID']."'");
?>
<?
if(mssql_num_rows($query6) == 0){
?>
<?
}else{
?>
<tr class="rank"><td>Regular Member</td></tr><tr height="5"></tr>
<?
while($busca5 = mssql_fetch_assoc($query7)){
?>
<tr><td><a href="index.php?do=character-view&id=<?=$busca5['CID']?>"><font color="gray"><?=$busca5['Name']?></font></a></td></tr><?}}?>
</table>
</div>
</div>
<div style="clear:both;"></div>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  