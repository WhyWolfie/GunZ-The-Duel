<?php 
if($_SESSION['userid']) 
{ 
redirect("/", 0); 
die(); 
} 
?>
<div id="content-center"><div id="main">
<h1>Recuperar Senha</h1>
<div class="content">
<div class="contents">
<p>
<form action='index.php?do=recuperar' method='post'> 
<table>
<tr><td>Email:</td><td><input type="text" name="email"/></td></tr>
<tr><td></td><td><input type="submit" value="Recuperar" name="submit" class="button" style="color:yellowgreen;"/></td></tr>
</table>
</form>
<br/>
<p>
A fun��o de recupera��o de conta ir� enviar um e-mail para o seu endere�o de e-mail.<br/>
O e-mail cont�m seu nome de usu�rio e um link para definir uma nova senha.
</p>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div>
<?php 
$fet =($_POST['fet']); 
$senha=($_POST['senha']); 
$email = ($_POST['email']); 
$fet2 =($_POST['fet2']); 
if (isset($_POST['submit'])){ 
if ( $email == ""){ 
msgbox ("Enter","index.php?do=recuperar"); 
} 
else { 
$res = mssql_query(" 
                            SELECT a.AID, a.UserID, a.Email, l.password 
                            FROM Account a INNER JOIN Login l ON a.AID = l.AID 
                            WHERE a.Email = '$email' 
"); 
$row = mssql_fetch_row($res); 
$userid = $row[1]; 
$senha = $row[3]; 
        if (!$row){ 
            msgbox ("Email inexistente.","index.php"); 
        } 
        else { 
$Nome = "Recupera��o de Senha"; 
$emailremetente = "email que ira enviar para o email do cara(ex: kinggunz@hotmail.com)"; 
$header = "De: ". $Nome . " <" . $emailremetente . ">\r\n"; 
$cabecalho = "Content-type: text/html\r\n"; 
$mensagem ="Detalhes da Sua Conta <br>______________<br>Login = ".$userid." <br>Senha = ".$senha." <br>______________<br>Por favor, n�o passe sua senha para ningu�m.<br>A administra��o jamais ir� pedir sua senha.<br>______________<br>Equipe Gunz<br>______________<br>Altere sua senha aqui: <a href='index.php?do=changepass'>"; 
ini_set('sendmail_from', 'Netheris@hotmail.com'); 
            mail("$email", "Recupera��o Senha Gunz Online",$mensagem,$cabecalho,$header); 
msgbox ("Enviado. Verifique seu email.","index.php");     
        } 
    } 
} 
/**Programado por Netheris - 
Netheris@hotmail.com**/  

?>