<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$aid = $_SESSION['AID'];
$query = mssql_query("SELECT * FROM Character WHERE AID = '$aid' ORDER BY Level DESC");
$busca = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid' AND DeleteFlag = '0'");

if( mssql_num_rows($busca) < 1 )
{
            msgbox("Voce nao possui nenhum personagem.","index.php?do=account-home");
}
?>
<div id="content-center"><div id="main">
<h1>Conta</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc">Minha Conta</a></li><li><a href="index.php?do=account-character" class="active">Meus Chars</a></li><li><a href="index.php?do=account-clan">Meus Clans</a></li></ul></div><div class="submenu"><ul class="tab_myacc" style="display:none;"><li class="first"><a href="index.php?do=account-home">Info da Conta</a></li><li><a href="index.php?do=account-email">Editar Email</a></li><li><a href="index.php?do=account-senha">Alterar senha</a></li></ul></div> <div class="contents">
<p>
<center>
<div id="load_ranking">
  <div id="rankingtable">
<table width="460" style="margin-left:5px;"><tbody><tr class="rank_head"><td style="text-align: left">#</td><td width="80" style="text-align: left">Name</td><td style="text-align: left">Level</td><td style="text-align: left">Kills</td><td style="text-align: left">Deaths</td><td style="text-align: left">Last Login</td><td style="text-align: left">PlayTime</td></tr>
<?
while($personagens = mssql_fetch_assoc($query)){
?>
	<tr>
	<td width="25"><?php echo "$rank";?></td>
	<td width="80" align="left"><?=$personagens['Name']?></a></td>
	<td width="38" align="left"><?=$personagens['Level']?></td>
	<td width="60" align="left"><?=$personagens['KillCount']?></td>
	<td width="60" align="left"><?=$personagens['DeathCount']?></td>
	<td width="160" align="left"><?=$personagens['LastTime']?></td>
	<td width="42" align="left"><?=$personagens['PlayTime']?></td>
	</tr>
<? } ?>
</tbody>
</table>
</center>
<?
//Script Alterar Sexo By Pablo
$errorcode = "";
$er = 0;
$registered = 0;

$aid1 = $_SESSION['AID'];
$query1 = mssql_query("SELECT * FROM Character WHERE AID = '$aid' ORDER BY Level DESC");
$busca1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid' AND DeleteFlag = '0'");

if (isset($_POST['submit'])){
     $cid = clean($_POST['cid']);
     $sex = clean($_POST['sex']);

        if($er == 0){
            $registered = 1;
	  mssql_query_logged("UPDATE Character SET Sex='$sex' WHERE AID='".$_SESSION['AID']."' AND CID='$cid'");
        }else{
            msgbox("Error","index.php?do=account-home");
        }
}



if ($registered == 0){
?>
<br/>
<form name="reg" method="POST" action="index.php?do=account-character">
<input type="hidden" name="request" value="changegender"/>
<table border="0">
<tr><span class="title">Alterar Sexo</span></tr>
<tr><td>Char:</td><td><select name="cid">
<?
while($personagens1 = mssql_fetch_assoc($query1)){
?>
<option value="<?=$personagens1['CID']?>"><?=$personagens1['Name']?></option><? } ?></select></td></tr>
<tr><td>Sexo:</td><td><select name="sex"><option value="0">Masculino</option><option value="1">Feminino</option></select></td></tr>
<tr><td></td><td><input type="submit" name="submit" class="button" value="Alterar"/></td></tr>
</table>
</form><br/>
<p>Nota: N�s <u>N�O</u>  alteramos o conjunto de doa��o para o outro sexo!</p>
<?
}else{
    msgbox("O sexo foi alterado corretamente","index.php?do=account-character");
}
?>
<span class="break"></span>
<? include "character/account-character-resetar.php"; ?>
<span class="break"></span>
<form name="reg" method="POST" action="index.php?do=account-character">
<input type="hidden" name="request" value="rebirth"/>
<table border="0">
<tr><span class="title">Rebirth Character</span></tr>
<tr><td>Char:</td><td><select name="cid2">
<option value="54">LOL</option></select></td></tr>
<tr><td></td><td><input type="submit" name="resetarlv" class="button" value="Rebirth" onclick="javascript: var t = confirm('Are you sure you want to rebirth this character?'); if(t == true){ return true; } else{ return false;}"/></td></tr>
</table>
</form><br/>
<p>Rebirth a character of level 99 and get 100 coins in return!</p>';
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  