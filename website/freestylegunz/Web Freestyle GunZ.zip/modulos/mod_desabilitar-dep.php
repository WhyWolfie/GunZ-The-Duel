<div id="content-center"><div id="main">
<h1>Desabilitando o DEP</h1>
<div class="content">
<div class="contents">
<p>
<font color="red">Desabilitando e ativando a DEP do Windows Vista pelo Prompt de Comandos utilizando o BCDEdit</font><br/><br/>
Inicie o Prompt de Comandos elevando o provil�gios (clique com o bot�o direito do mouse sobre o atalho e escolha � Executar como Administrador�, ap�s isto digite o seguinte comando e aguarde a mensagem de conclus�o da opera��o.<br/><br/>

bcdedit /set {current} nx AlwaysOff ( Desativa )<br/>

bcdedit /set {current} nx Optin ( Ativa )
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  