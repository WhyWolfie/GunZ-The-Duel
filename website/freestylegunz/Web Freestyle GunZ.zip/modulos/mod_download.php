<div id="content-center"><div id="main">
<h1>Download</h1>
<div class="content">
<div class="contents">
<p>
Por favor, <span class="ignore">pegue um link de download</span>, qualquer link!<br/>
Temos muitos sites de download para escolher.<br/><br/>
Tamanho do Client: <span class="ignore">430.20mb</span><br/>
Vers�o: <span class="ignore">1.0</span><br/>
</p>
<br/>
<div class="download_mirrors">
<p>
Full Client <a href="http://www1.freestylersgunz.com/downloads/Freestyle-GunZ-Version-7-Installer-FULL.exe" target="_blank">| Link 1 - www1.freestylersgunz.com</a><br/>
Full Client <a href="http://www2.freestylersgunz.com/downloads/Freestyle-GunZ-Version-7-Installer-FULL.exe" target="_blank">| Link 2 - www2.freestylersgunz.com</a><br/><br/>
Full Client <a href="http://uploading.com/files/thankyou/3c9amcbb/Freestyle+GunZ+Version+7+Installer+FULL.exe" target="_blank">| Link 3 - Uploading.com</a><br/>
Full Client <a href="http://depositfiles.com/files/jmmtlsdef" target="_blank">| Link 4 - Depositfiles.com</a><br/>
Full Client <a href="http://www.gamefront.com/files/22172224/Freestyle+GunZ+Version+7+Installer+FULL.exe" target="_blank">| Link 5 - Gamefront.com</a><br/>
Full Client <a href="http://www.filedropper.com/freestylegunzversion7installerfull" target="_blank">| Link 6 - FileDropper.com</a><br/>
Full Client <a href="game5/gunz/Freestyle GunZ Version 7 Installer FULL.torrent" target="_blank">| Link 7 - Torrent</a><br/>
</p>
</div>
<p>
<br/><br/>
<img src="images/system-requirements.png" style="margin:0px 0px 0px 40px;"/><br/><br/>
Se voc� enfrentar qualquer problema do cliente ou precisa de ajuda com outras coisas, por favor leia o <a href="index.php?do=frequently-asked-questions">FAQ</a><br/>
ou postar um t�pico sobre o <a href="http://freestylersworld.com" target="_blank">forum.</a>  A nossa grande <a href="http://freestylersworld.com" target="_blank">comunidade</a> vai te ajudar concerteza!
<br/>
</p>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  