<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
if ($_POST['submit']){
echo '<div class="errmessage">';
$oldpassword = clean($_POST['pw']);
$newpassword = clean($_POST['pw1']);
$repeatnewpassword = clean($_POST['pw2']);

$select_pass = mssql_query("SELECT Password FROM Login WHERE UserID='".$_SESSION['UserID']."'");
$row_pass = mssql_fetch_assoc($select_pass);
$old_pass = $row_pass['Password'];

if($oldpassword&&$newpassword&&$repeatnewpassword){
  if($oldpassword==$old_pass){
    if($newpassword==$repeatnewpassword){
	
	  $change_pass = mssql_query("UPDATE Login SET Password='$newpassword' WHERE UserID='".$_SESSION['UserID']."'");
      msgbox("A senha foi alterada corretamente","index.php");
	  session_destroy();
      redirect("index.php");
	  
	}else{
      msgbox("As novas senhas n�o conincidem","index.php?do=account-senha");
	}
  }else{

      msgbox("A senha antiga est� incorreta","index.php?do=account-senha");
  }
}else{
   msgbox("Por favor, preencha todos os campos!","index.php?do=account-senha");
}

}
?>
<div id="content-center"><div id="main">
<h1>Conta</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc" class="active">Minha conta</a></li><li><a href="index.php?do=account-character">Meus Chars</a></li><li><a href="index.php?do=account-clans">Meus clans</a></li></ul></div><div class="submenu"><ul class="tab_myacc"><li class="first"><a href="index.php?do=account-home">Info da Conta</a></li><li><a href="index.php?do=account-email">Editar Email</a></li><li><a href="index.php?do=account-senha" class="active">Alterar Senha</a></li></ul></div> <div class="contents">
<form name="reg" method="POST" action="index.php?do=account-senha">
<input type="hidden" name="request" value="password"/>
<table>
<tr><span class="title">Alterar Senha</span></tr>
<tr><td>Senha Antiga</td><td><input type="password" name="pw"/></td></tr>
<tr><td>Nova Senha</td><td><input type="password" name="pw1"/></td></tr>
<tr><td>Confirme sua Senha</td><td><input type="password" name="pw2"/></td></tr>
<tr><td></td><td><input type="submit" class="button" name="submit" value="Alterar"/></td></tr>
</table>
</form>
</div>
<br/>
</div>
<div class="footer"></div>
</div>