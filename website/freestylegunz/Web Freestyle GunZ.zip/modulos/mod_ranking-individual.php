<?
$errorcode = "";
$er = 0;
$registered = 0;
$res = mssql_query("SELECT TOP 100 Name, Level, CID, KillCount, DeathCount, PlayTime, LastTime FROM Character WHERE Name != '' ORDER BY Level DESC");
$count = 0;
if (isset($_POST['submit'])){
     $name = clean($_POST['name']);


        $busca = mssql_query_logged("SELECT * FROM Character WHERE Name = '".$name."'");
        if (mssql_num_rows($busca) <= 0){
            msgbox("Personagem inexistente.","index.php?do=ranking-individual");
            $er = 1;
        }

        if($er == 0){
            $registered = 1;
	  mssql_query_logged("SELECT * FROM Character WHERE Name='$name' ORDER BY Level DESC");
        }else{
            msgbox("Error","index.php?do=account-home");
        }
}



if ($registered == 0){
?>
<div id="content-center">
<div id="main">
<h1>Individual Ranking</h1>
<div class="content">
<div class="menu"><ul class="ranking"><li><a href="index.php?do=ranking-individual" class="active">Individual Ranking</a></li><li><a>|</a></li><li><a href="index.php?do=ranking-clan">Clan Ranking</a></li></ul></div>
<div class="contents">
<form name="reg" method="POST" action="index.php?do=ranking-individual">
<input type="hidden" name="type" id="rType" value="1"/>
<p>
Procurar por um personagem: <input type="text" name="name"/> <input type="submit" name="submit" class="button" value="Procurar"/>
</p>
</form>
<br />
<center>
  <div id="rankingtable">
<table width="480" style="margin-left:5px;"><tbody><tr class="rank_head"><td style="text-align: left">#</td><td width="80" style="text-align: left">Name</td><td style="text-align: left">Level</td><td style="text-align: left">Kills</td><td style="text-align: left">Deaths</td><td style="text-align: left">Last Login</td><td style="text-align: left">PlayTime</td></tr>
<?
if(mssql_num_rows($res) == 0){
?>
	<tr>
	<td width="25"></td>
	<td width="40" align="center"></a></td>
	<td width="30" align="center"></a></td>
	<td width="200" align="center">Nenhum personagem foi encontrado</td>
	<td width="40" align="center"></td>
	<td width="30" align="center"></td>
	<td width="42" align="center"></td>
	</tr>

<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++;
?>
	<tr>
	<td width="25"><?=$count?></td>
	<td width="80" align="left"><a href="index.php?do=character-view&id=<?=$r['CID']?>"><?=utf8_encode($r['Name'])?></a></td>
	<td width="38" align="left"><?=$r['Level']?></td>
	<td width="60" align="left"><?=$r['KillCount']?></td>
	<td width="60" align="left"><?=$r['DeathCount']?></td>
	<td width="200" align="left"><?=$r['LastTime']?></td>
	<td width="42" align="left"><?=$r['PlayTime']?></td>
	</tr>
<?}}?>
</tbody>
</table>
<br/>
<p style="margin:0px 0px 0px 118px;" id="navigation">
<br/></center>
</span>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div> 
<?
}else{
?>
<div id="content-center">
<div id="main">
<h1>Individual Ranking</h1>
<div class="content">
<div class="menu"><ul class="ranking"><li><a href="index.php?do=ranking-individual" class="active">Individual Ranking</a></li><li><a>|</a></li><li><a href="index.php?do=ranking-clan">Clan Ranking</a></li></ul></div>
<div class="contents">
<form name="reg" method="POST" action="index.php?do=ranking-individual">
<input type="hidden" name="type" id="rType" value="1"/>
<p>
Procurar por um personagem: <input type="text" name="name"/> <input type="submit" name="submit" class="button" value="Procurar"/>
</p>
</form>
<br />
<center>
  <div id="rankingtable">
<table width="480" style="margin-left:5px;"><tbody><tr class="rank_head"><td style="text-align: left">#</td><td width="80" style="text-align: left">Name</td><td style="text-align: left">Level</td><td style="text-align: left">Kills</td><td style="text-align: left">Deaths</td><td style="text-align: left">Last Login</td><td style="text-align: left">PlayTime</td></tr>
<?
while($s = mssql_fetch_assoc($busca)){
$count++;
?>
	<tr>
	<td width="25"><?=$count?></td>
	<td width="80" align="left"><?=utf8_encode($s['Name'])?></a></td>
	<td width="38" align="left"><?=$s['Level']?></td>
	<td width="60" align="left"><?=$s['KillCount']?></td>
	<td width="60" align="left"><?=$s['DeathCount']?></td>
	<td width="200" align="left"><?=$s['LastTime']?></td>
	<td width="42" align="left"><?=$s['PlayTime']?></td>
	</tr>
<?}?>
</tbody>
</table>
<br/>
<p style="margin:0px 0px 0px 118px;" id="navigation">
<br/></center>
</span>
</p>
<br/>
</div>
<br/>
</div>
<div class="footer"></div>
</div> 
<? } ?>