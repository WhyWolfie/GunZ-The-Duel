<? 
//coded by:Pablo
$xa = getenv('REMOTE_ADDR');
$badwords = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--");

foreach($_POST as $value)
foreach($badwords as $word)
if(substr_count($value, $word) > 0)
die("<script>alert('Error , Inject Fail.'); location='javascript:history.back()'</script>");

$query = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION['AID']."'");
$avatar = mssql_fetch_object($query);
?>
<div id="content-center"><div id="main">
<h1>Upload Avatar</h1>
<div class="content">
<div class="menu"><ul><li class="first"><a href="index.php?do=account-home" id="a_myacc" class="active">Minha Conta</a></li><li><a href="index.php?do=account-character">Meus Chars</a></li><li><a href="index.php?do=account-clan">Meus Clans</a></li></ul></div><div class="submenu"><ul class="tab_myacc"><li class="first"><a href="index.php?do=account-home">Info da Conta</a></li><li><a href="index.php?do=account-email">Editar Email</a></li><li><a href="index.php?do=account-senha">Alterar Senha</a></li></ul></div> <div class="contents">
<br/>
<form enctype="multipart/form-data" action="index.php?do=account-avatar" method="POST">
<span class="title">Upload Avatar</span><br/>
<p>Image <input type="file" name="foto"></p>
<input type="submit" name="submit" class="button" value="Enviar"> 
</form><br/>
<p>
<span class="ignore">Requerido:</span> .jpg .png .gif<br/><br/>
<span class="ignore">Current avatar:</span></p><br/>
<img src="<?=($avatar->AvatarUrl == '') ? 'images/avatars/no-avatar.png' : $avatar->AvatarUrl?>" width="92" height="92"> </p>
<?php 
$erro = $config = array(); 

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE; 

$config["tamanho"] = 106883; 

$config["largura"] = 92; 

$config["altura"]  = 92; 

if (isset($_POST['submit'])){  
    if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $arquivo["type"])) { 
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; 
    } else { 
        if ($arquivo["size"] > $config["tamanho"]) { 
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo"; 
        } 
         
        $tamanhos = getimagesize($arquivo["tmp_name"]); 
         
        if ($tamanhos[0] > $config["largura"]) { 
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels"; 
        } 

        if ($tamanhos[1] > $config["altura"]) { 
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels"; 
        } 
    } 
     
    if (sizeof($erro)) { 
        foreach ($erro as $err) { 
            echo " - " . $err . "<BR>"; 
        } 
        echo '<span class="ignore">Error, nao foi possivel fazer o upload do Avatar.</span><br>'; 
        echo "<span class='ignore'>$err</span>"; 
    } 

    else 
    { 
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext); 

        $imagem_nome = md5(uniqid(time())) . "." . $ext[1]; 

        $imagem_dir = "avatar/" . $imagem_nome; // IMPORTANTE DEFINIR A PASTA DA IMAGEM 

        move_uploaded_file($arquivo["tmp_name"], $imagem_dir); 
         
        $query = mssql_query("UPDATE Account Set AvatarUrl='$imagem_dir' WHERE AID='".$_SESSION['AID']."'"); 
        if($query){ 
        echo "<span class='ignore'>Seu emblema foi enviado com sucesso!</span>"; 
        } 

    } 
} 
?>
</div>
<br/>
</div>
<div class="footer"></div>
</div>  