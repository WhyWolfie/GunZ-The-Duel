<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Sitemap</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Sitemap</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
					<ul align="left">
						<li><a href="index.php">Home</a></li><br />
						<ul>
							<li><a href="http://forums.insanitygamers.net/">Forums</a></li><br />
							<li><a href="register.php">Register</a></li><br />
							<li><a href="plranking.php">Ranking</a></li>
								<ul>
									<li><a href="clranking.php">Clan Ranking</a></li><br />
								</ul>
							<li><a href="shop.php">Shop</a></li><br />
							<li><a href="download.php">Download</a></li><br />
						</ul>
						<li><a href="rules.php">Rules</a></li><br />
						<li><a href="stafflist.php">Staff list</a></li><br />
						<li><a href="sitemap.php">Sitemap</a></li><br />
						<li><a href="contact.php">Contact</a></li>
					</ul>
                </table>
            </div>
            <img src="images/contact.png" height="500" width="458" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
