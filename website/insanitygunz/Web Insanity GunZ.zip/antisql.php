<?php
//Anti SQL Injection
$otinane = "Just kill yourself already!";

$input  = urldecode($_SERVER['QUERY_STRING']);
$bads = array('union' , 'select' , '<script>' , 'substring' , 'having' , '--' , 'drop' , 'create' , 'rename' , 'insert' , 'load data' , 'replace' , 'revoke' , 'update' , 'join' , 'kill' , 'flush' , 'procedure', 'like' , 'order by' , 'group by' , 'concat' , 'group_concat');

for($i=0;$i<=count($bads);$i++)
{
$pos = strripos($input, $bads[$i]);
if ($pos) { echo"$otinane"; exit; }
}
?>