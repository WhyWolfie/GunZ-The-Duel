<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Staff list</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Staff list</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
					<br />
					<font style="color:#FF0000">Owner:</font><br />
					
					<font style="color:#0000FF">Developers:</font><br />
                    
					<font style="color:#32CD32">Coders:</font><br />
					
					<font style="color:#FF0099">Game Masters:</font><br />
					
					<font style="color:#006600">Forum Moderators:</font><br />
					
					<font style="color:#00FFFF">GFX Artists:</font><br />
                
				</table>
            </div>
            <img src="images/contact.png" height="550" width="498" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
