<?php
@session_start();

/*Connect to MSSQL Server */

$_MSSQL['Server']  	= "TU-PC\SQLEXPRESS";
$_MSSQL['User']   	= "sa";
$_MSSQL['Password']	= "asdasd";
$_MSSQL['Database']	= "GunzDB";


/*Server info*/

$srvip			= "Server IP";
$srvport		= "Server Port";


$connect = mssql_connect($_MSSQL['Server'],$_MSSQL['User'],$_MSSQL['Password']) or die ("Connection to the database has failed");
mssql_select_db($_MSSQL['Database'],$connect) or die ("Couldn't find the database");

/* Log out */
 if(isset($_GET['action']) && $_GET['action'] == "logout")
{
	session_destroy();
	echo '<script type="text/javascript">
			<!--
			alert("You have successfully logged out");
			window.location = "index.php"
			//-->
		  </script>';
}
 

?>