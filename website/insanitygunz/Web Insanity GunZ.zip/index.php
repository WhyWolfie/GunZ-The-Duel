﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ</title>
<script type="text/javascript" src="http://konami-js.googlecode.com/svn/trunk/konami.js"></script>
<script type="text/javascript">
	konami = new Konami()
	konami.load("http://gunz.insanity-gamers.com/cosmosishawt.html");
</script>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/easySlider1.7.js"></script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-22634654-3']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</head>

<?php
	include "header.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center"><table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center"><table height="100%" border="0">
          <tr>
            <td width="515" height="214" valign="middle">
            <div id="slideshow">            	
            	<div id="slider">
            		<ul>
            	    	<li><a href=""><img src="images/slide1.png" alt="Slider 1" /></a></li>
            	    	<li><a href=""><img src="images/slide2.png" alt="Slider 2" /></a></li>
				    	<li><a href=""><img src="images/slide3.png" alt="Slider 3" /></a></li>
					</ul>
            	</div>
			</div>

            </td>
          </tr>
          <tr>
            <td valign="top"><p class="news"> <b>News & Announcements</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
                  <tr><br />
                    <td align="center"><a href="http://forum.insanity-gamers.com/showthread.php?tid=55"><img src="images/news_v1.png" /></a></td>
                  </tr>
                  <tr>
                    <td align="center"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"><img src="images/news_v2.png" /></a></td>
                  </tr>
                  <tr>
                    <td align="center"><a href="http://top200.top-site-list.com/vote594.html"><img src="images/news_v3.png" /></a></td>
                  </tr>
                </table>

            </div>
              <img src="images/news.png" /></td>
          </tr>
        </table></td>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table></td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
