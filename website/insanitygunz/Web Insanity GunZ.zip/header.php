<head>
	<link rel="shortcut icon" href="images/favicon.ico" />	
</head>

<?php
	echo '<div id="header">
	    <table width="100%" height="49px">
	    	<tr class="headertext">
	    		<td bordercolor="#FF0000"><b>&nbsp;&nbsp; Insanity Gamers</b></td>
	    		<td align="right"><b>Local Server Time: '.$date.'&nbsp;&nbsp;'.$time.'&nbsp;&nbsp;</b></td>
	 	 	</tr>
	    </table>
	</div>';
?>
<div id="logo"></div>

<div id="stripes"></div>

<div id="navbar_bg"></div>

<div id="navbar">   
	<ul>
	 <li><a href="index.php">Home</a></li>
	 <li><a href="http://forum.insanity-gamers.com/">Forums</a></li>
	 <li><a href="register.php">Register</a></li>
	 <li><a href="plranking.php">Ranking</a></li>
	 <li><a href="shop.php">Shop</a></li>
	 <li><a href="download.php">Download</a></li>
	</ul>
</div>