<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - My Panel</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center"><table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center"><table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>My Panel</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0" align="center">
                    <?php
						include ('config/config.php');
						$user = $_SESSION['UserID'];
						
						$query = mssql_query("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
						$ugrade = mssql_result($query, 0, 'UGradeID');	

						//Functions
						//Change UserGrade
						function changeugrade($usermame) {
							$username = $_POST['username'];
							$grade = $_POST['UGrade'];
							$exist = mssql_query("SELECT UserID FROM Login WHERE UserID = '".$username."'");
							$checkrank = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '".$username."'");
							$banned = 253;
							$unbanned = 0;
							$jjang = 2;
							if(!$username){
								alert("Please fill in a username!");
								redirect("panel.php");
							}
							elseif(mssql_num_rows($exist)==0){
								alert("Username doesn't exist!");
								redirect("panel.php");
							}
							else{
								if($grade == $banned){
									$ban = mssql_query("UPDATE Account SET UGradeID = '$banned' WHERE UserID = '$username'");
									alert("'".$username."' has been banned!");
									redirect("panel.php");
								}
								elseif($grade == $unbanned){
									$unban = mssql_query("UPDATE Account SET UGradeID = '$unbanned' WHERE UserID = '$username'");
									alert("'".$username."' has been unbanned!");
									redirect("panel.php");
								}
								elseif($grade == $jjang){
									$unban = mssql_query("UPDATE Account SET UGradeID = '$jjang' WHERE UserID = '$username'");
									alert("Jjang given to '".$username."'!");
									redirect("panel.php");
								}
							}
						}
						//Search
						function search($username) {
							$value = $_POST['searchvalue'];
							$string = $_POST['searchid'];
							if(!$string){
								alert("Please enter a string!");
								redirect("panel.php");
							}
							else{
								if($value == "name"){
									$exist2 = mssql_query("SELECT Name FROM Character WHERE Name = '".$string."'");
									if(mssql_num_rows($exist2)==0){
										alert("Character Name doesn't exist.");
										redirect("panel.php");
									}
									else{
										$query = mssql_query("SELECT AID FROM Character WHERE Name = '".$string."'");
										$character = mssql_fetch_row($query);
										$query = mssql_query("SELECT UserID,Email FROM Account WHERE AID = '".$character[0]."'");
										$account = mssql_fetch_row($query);
										$query = mssql_query("SELECT LastIP FROM Login WHERE AID ='".$character[0]."'");
										$login = mssql_fetch_row($query);
										
										$query = mssql_query("SELECT AID FROM Account WHERE UserID = '".$account[0]."'");
										$aid = mssql_result($query, 0, 'AID');
										$query = mssql_query("SELECT Name, CID, Level FROM Character WHERE AID = '".$aid."' AND DeleteFlag = 0 AND Name IS NOT NULL");
										$counter = 1;
										echo "<br />AID: ".$character[0];
										echo "<br />User ID: ".$account[0];
										echo "<br />Email: ".$account[1];
										echo "<br />IP: ".$login[0].'<hr width="250px" />';
										while($row = mssql_fetch_row($query))
										{
											echo '<br />Character'.$counter.': '.$row[0].' (CID: '.$row[1].' / Level: '.$row[2].')';
											$counter++;
										}
									}
								}
								elseif($value == "aid"){
									$exist2 = mssql_query("SELECT AID FROM Character WHERE AID = '".$string."'");
									if(mssql_num_rows($exist2)==0){
										alert("AID doesn't exist");
										redirect("panel.php");
									}
									else{
										$query = mssql_query("SELECT UserID,Email FROM Account WHERE AID = '".$string."'");
										$account = mssql_fetch_row($query);
										$query = mssql_query("SELECT LastIP FROM Login WHERE AID = '".$string."'");
										$login = mssql_fetch_row($query);	

										$query = mssql_query("SELECT AID FROM Account WHERE UserID = '".$account[0]."'");
										$aid = mssql_result($query, 0, 'AID');
										$query = mssql_query("SELECT Name, CID, Level FROM Character WHERE AID = '".$aid."' AND DeleteFlag = 0 AND Name IS NOT NULL");
										$counter = 1;									
										echo "<br />AID: ".$string;
										echo "<br />User ID: ".$account[0];
										echo "<br />Email: ".$account[1];
										echo "<br />IP: ".$login[0].'<hr width="250px" />';
										while($row = mssql_fetch_row($query))
										{
											echo '<br />Character'.$counter.': '.$row[0].' (CID: '.$row[1].' / Level: '.$row[2].')';
											$counter++;
										}		
									}
								}
								elseif($value == "userid"){
									$exist2 = mssql_query("SELECT UserID FROM Account WHERE UserID = '".$string."'");
									if(mssql_num_rows($exist2)==0){
										alert("UserID doesn't exist");
										redirect("panel.php");
									}
									else{
										$query = mssql_query("SELECT AID,Email FROM Account WHERE UserID = '".$string."'");
										$account = mssql_fetch_row($query);
										$query = mssql_query("SELECT LastIP FROM Login WHERE UserID = '".$string."'");
										$login = mssql_fetch_row($query);	

										$query = mssql_query("SELECT AID FROM Account WHERE UserID = '".$string."'");
										$aid = mssql_result($query, 0, 'AID');
										$query = mssql_query("SELECT Name, CID, Level FROM Character WHERE AID = '".$aid."' AND DeleteFlag = 0 AND Name IS NOT NULL");
										$counter = 1;									
										echo "<br />AID: ".$account[0];
										echo "<br />User ID: ".$string;
										echo "<br />Email: ".$account[1];
										echo "<br />IP: ".$login[0].'<hr width="250px" />';
										while($row = mssql_fetch_row($query))
										{
											echo '<br />Character'.$counter.': '.$row[0].' (CID: '.$row[1].' / Level: '.$row[2].')';
											$counter++;
										}		
									}
								}
								elseif($value == "email"){
									$exist2 = mssql_query("SELECT Email FROM Account WHERE Email = '".$string."'");
									if(mssql_num_rows($exist2)==0){
										alert("Email doesn't exist");
										redirect("panel.php");
									}
									else{
										$query = mssql_query("SELECT AID,UserID FROM Account WHERE Email = '".$string."'");
										$account = mssql_fetch_row($query);
										$query = mssql_query("SELECT LastIP FROM Login WHERE AID = '".$account[0]."'");
										$login = mssql_fetch_row($query);	

										$query = mssql_query("SELECT AID FROM Account WHERE Email = '".$string."'");
										$aid = mssql_result($query, 0, 'AID');
										$query = mssql_query("SELECT Name, CID, Level FROM Character WHERE AID = '".$aid."' AND DeleteFlag = 0 AND Name IS NOT NULL");
										$counter = 1;									
										echo "<br />AID: ".$account[0];
										echo "<br />User ID: ".$account[1];
										echo "<br />Email: ".$string;
										echo "<br />IP: ".$login[0].'<hr width="250px" />';
										while($row = mssql_fetch_row($query))
										{
											echo '<br />Character'.$counter.': '.$row[0].' (CID: '.$row[1].' / Level: '.$row[2].')';
											$counter++;
										}		
									}
								}
							}
						}
						//Send Event item
						function eventitem($username){
							$value = $_POST['eventitems'];
							$aid = $_POST['aid'];
							$exist = mssql_query("SELECT AID FROM Account WHERE AID = '".$aid."'");
							$date = date("m/d/y H:i");
							$query = mssql_query("SELECT UserID FROM Account WHERE AID = '".$aid."'");
							$userid = mssql_fetch_row($query);
							if (!$aid){
								alert("Please enter an AID!");
								redirect("panel.php");
							}
							elseif (mssql_num_rows($exist)==0){
								alert("AID doesn't exist!");
								redirect("panel.php");
							}
							else {
								if($value == "male"){
									$send = mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod) VALUES('".$aid."', '20001', '".$date."', '168')");
									alert("Event hat has been sent to ".$userid[0]."!");
									redirect("panel.php");
								}
								elseif($value == "female"){
									$send = mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod) VALUES('".$aid."', '20501', '".$date."', '168')");
									alert("Event hat has been sent to ".$userid[0]."!");
									redirect("panel.php");
								}
							}
						}
						//Alert
						function alert($msg){
							echo "<script language=\"javascript\">alert(\"".$msg."\");</script>";
						}
						//Redirect
						function redirect($url){
							echo "<body><script>document.location = '$url'</script></body>";
						}						
						
						if($ugrade == 255 ){
							//Search information (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Search</td></tr><tr><td><select name='searchvalue'><option value='name'>Character name</option><option value='aid'>AID</option><option value='userid'>UserID</option><option value='email'>E-Mail</option></select>";
							echo "<input type='text' name='searchid' />";
							echo "<input type='submit' name='search' value='Search' /></td></tr></form>";
							//Change User Grade (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Change User Grade</td></tr><tr><td>User ID: <input type='text' name='username' />";
							echo "<select name='UGrade'><option value='253'>Ban</option><option value='0'>Unban</option><option value='2'>Jjang</option></select>";
							echo "<input type='submit' name='send' value='Submit' /></td></tr></form>";
							//Sent Event item (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Send Items</td></tr><tr><td>AID: <input type='text' name='aid' />";
							echo "<select name='eventitems'><option value='male'>Event Crown (Male)</option><option value='female'>Event Crown (Female)</option></select>";
							echo "<input type='submit' name='sendevent' value='Send' /></td></tr></form>";
							
							//Change User Grade
							if (isset($_POST['send'])){
								changeugrade($_POST['username']);
							}
							//Search
							if (isset($_POST['search'])){
								search($_POST['username']);
							}
							//Send Event item
							if (isset($_POST['sendevent'])){
								eventitem($_POST['username']);
							}
						}
						else if($ugrade == 254){
							//Search information (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Search</td></tr><tr><td><select name='searchvalue'><option value='name'>Character name</option><option value='aid'>AID</option><option value='userid'>UserID</option><option value='email'>E-Mail</option></select>";
							echo "<input type='text' name='searchid' />";
							echo "<input type='submit' name='search' value='Search' /></td></tr></form>";
							//Change User Grade (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Change User Grade</td></tr><tr><td>User ID: <input type='text' name='username' />";
							echo "<select name='UGrade'><option value='253'>Ban</option><option value='0'>Unban</option><option value='2'>Jjang</option></select>";
							echo "<input type='submit' name='send' value='Submit' /></td></tr></form>";
							//Sent Event item (HTML)
							echo "<form action='' method='post'>";
							echo "<tr><td>&nbsp;</td></tr><tr><td align='center'>Send Items</td></tr><tr><td>AID: <input type='text' name='aid' />";
							echo "<select name='eventitems'><option value='male'>Event Crown (Male)</option><option value='female'>Event Crown (Female)</option></select>";
							echo "<input type='submit' name='sendevent' value='Send' /></td></tr></form>";
							
							//Change User Grade
							if (isset($_POST['send'])){
								changeugrade($_POST['username']);
							}
							//Search
							if (isset($_POST['search'])){
								search($_POST['username']);
							}
							//Send Event item
							if (isset($_POST['sendevent'])){
								eventitem($_POST['username']);
							}
						}
						else {
							echo "<center>You do not have permissions to access this page.</center>";
						}
					?>     
				</table>
            </div>
            <img src="images/contact.png" height="500" width="458" /></td>
          </tr>
        </table></td>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table></td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>

