<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Contact</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Contact</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
					<br /><br />
					<b><u>Got questions or suggestions?</u></b><br /><br />
					
					<img src="http://www.clker.com/cliparts/1/f/b/0/1195445403831271262liftarn_Lightbulb_2.svg.med.png" width="150px" height="140" /><br /><br /><br />
					
					Feel free to contact us by sending an email to:<br /><br />
					
					<a href="mailto:e1o14@insanity-gamers.com">e1o14@insanity-gamers.com</a>
                </table>
            </div>
            <img src="images/contact.png" height="500" width="458" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
