<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Shop</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Shop</b><br /></p>
            <div class="news_table">
				<table width="100%" border="0">
					<tr>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="shop.php">[All]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="sets.php">[Sets]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="armor.php">[Armor]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="melee.php">[Melee]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="ranged.php">[Ranged]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="special.php">[Special]</a></td>
					</tr>
				</table>
            	<table width="100%" border="0" id="shop">
					<br />
					<tr>
						<td width="60"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"><img src="images/shop/male_ninja.png"></a></td>
							<td>
							<font color="#CCCCCC" size="-1">
								Name: Ninja Set<br/>
								Sex: Male <br/>
								Level: 1 <hr/>
								HP: 40 <br>
								AP: 125 <br>
								Weight: 22 <br />
								Price: 100
							</font>
							</td>
						<td width="60"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"><img src="images/shop/female_ninja.png" ></a></td>
							<td>
							<font color="#CCCCCC" size="-1">
								Name: Ninja<br/>
								Sex: Female <br/>
								Level: 1 <hr/>
								HP: 40 <br>
								AP: 125 <br>
								Weight: 22 <br />
								Price: 100
							</font>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
							<td>
							&nbsp;
						</td>
						<td>&nbsp;</a></td>
							<td>
							&nbsp;
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
							<td>
							&nbsp;
						</td>
						<td>&nbsp;</a></td>
							<td>
							&nbsp;
						</td>
					</tr>
                </table>
				<table width="100%" border="0">
					<tr>&nbsp;</tr>
					<tr>
						<td align="center"><a href="sets.php">[1]</a> <a href="sets_p2.php">[2]</a></td>
					</tr>
				</table>
            </div>
            <img src="images/shop_main.png" height="635" width="458" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
