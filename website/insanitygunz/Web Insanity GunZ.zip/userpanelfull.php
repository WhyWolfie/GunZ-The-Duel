<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - My Account</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center"><table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center"><table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>My Account</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0" align="center">
				<div style="overflow-y: scroll; height:420px; width:420px; margin-top: 15px;">
                    <?php
						include ('config/config.php');
						$user = $_SESSION['UserID'];	
						if($_SESSION['UserID'] == ""){
							echo "<center>Login Is Required To View This Page</center>";
						}
						else{
							echo "<br><br>Welcome <font color='#c15516'>".$user."</font>. Nice to see you here.<br> Below you can see some information about your in game characters.<br /><br />";
							
							$query = mssql_query("SELECT Coins FROM DonationList WHERE AID = '".$_SESSION['AID']."'");
							$coins = mssql_result($query, 0, 'Coins');
							echo "You currently have <b>".$coins."</b> IG Coins.<br />Click <a href='https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=L389PGW98LVAN'>here</a> to donate.<hr width='250px' />";
							
							function chars($accname){
								$query = mssql_query("SELECT AID FROM Account WHERE UserID = '".$accname."'");
								$aid = mssql_result($query, 0, 'AID');
			
								$query = mssql_query("SELECT Name, Level, KillCount, DeathCount FROM Character WHERE AID = '".$aid."' AND DeleteFlag = 0 AND Name IS NOT NULL");
			
								while($row = mssql_fetch_row($query))
								{
									if ($row[2]+$row[3]==0) {
										$ratio = 0.00;
									}
									else {
										$ratio = round ((100*($row[2]/($row[2]+$row[3]))),2);
									}
									echo '<b>Name:</b> '.$row[0].'<br><b>Level:</b> '.$row[1].'<br><b>Kill/Death:</b> '.$row[2].'/'.$row[3].' ('.$ratio.'%)<br><br><br><br>';
								}
							}
							echo chars($_SESSION['UserID']);
						}
					$query = mssql_query("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
					$ugrade = mssql_result($query, 0, 'UGradeID');	
					if ($ugrade == 255 || $ugrade == 254 || $ugrade == 252){
						echo "<center><a href='panel.php'>Enter Control Panel</a></center>";
					}
					else {
						echo "";
					}
					?>
				</div>
				</table>
            </div>
            <img src="images/contact.png" height="500" width="458" /></td>
          </tr>
        </table></td>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table></td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>

