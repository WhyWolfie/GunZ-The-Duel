<?php
	include"config/config.php";
?>


<table width="100%" height="100%" border="0">
	<tr>
		<td width="100%" valign="middle">

<!-- Player Ranking -->
			 <div style="margin-top:-10px">
			 <p class='ranking'><b><font color='#323232'>Player Ranking</font></b></p>
			 <table width='100%' height='146' border='0' class='ranking_table' style='color:#CCC;'>
				<tr style='font-weight:bold;'>
					<td width='30%' height='23' align='left'>Rank</td>
					<td>Name</td>
					<td width='20%' align='right'>Level</td>
				</tr>
				<tr>
					 <?php   
							$plrank = "SELECT TOP 5 CID, Name, Level FROM Character WHERE DeleteFlag=0 ORDER BY Level DESC";
							$result = mssql_query($plrank);
							while($row = mssql_fetch_array($result))
							
						echo "<tr><td></td><td>" . $row["Name"] . "</td>" . "<td align='right'>" . $row["Level"]."</tr>";
					 ?>
				</tr>
			 <table width='100%' height='170' border='0' class='ranking_table' style='color:#CCC;'>
                 <tr valign="bottom">
					<td></td><td></td><td align="right"><a href="plranking.php"><img src="images/more.png" /></a></td>					
    			 </tr>
			</table>
			<img src="images/ranking.png" />
			</div>
		</td>
	</tr>
	<tr>
		<td valign="top">


<!-- Clan Ranking -->
			<p class="ranking"><b><font color="#323232">Clan Ranking</font></b>
			<table width="100%" height="146" border="0" class="ranking_table" style="color:#CCC">
			  <tr style="font-weight:bold;">
				<td width="30%" height="23" align="left">Rank</td>
				<td>Name</td>
				<td width="20%" align="right">Points</td>
			  </tr>
			  <tr>
			 <?php   
					$plrank2 = "SELECT TOP 5 CLID, Name, Point FROM Clan WHERE DeleteFlag=0 ORDER BY Point DESC";
					$result2 = mssql_query($plrank2);
					while($row2 = mssql_fetch_array($result2))
					
				echo "<tr><td></td><td>" . $row2["Name"] . "</td>" . "<td align='right'>" . $row2["Point"]."</tr>";
			 ?>
		    </tr>
		   	<tr valign="bottom">
				<td></td><td></td><td align="right"><a href="clranking.php"><img src="images/more.png" /></a></td>
			 </tr>
			</table>
			<img src="images/ranking.png" />
		</td>
	</tr>
</table>