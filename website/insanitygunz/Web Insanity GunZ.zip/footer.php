<div id="stripes_bottom"></div>

<div id="navbar_bg_bottom" align="center">
	<ul>
		<li><a href="index.php">Home</a> | </li>
		<li><a href="rules.php">Rules</a> | </li>
		<li><a href="stafflist.php">Staff List</a> | </li>
		<li><a href="sitemap.php">Sitemap</a> | </li>
		<li><a href="contact.php">Contact</a></li>
	</ul>
</div>

<br /><br /><br /><br /><br /><br /><br /><br />

<div id="footer">
	<div class="footertext">
    	<p><font size="-1">Copyrights &copy; 2011 <a href="index.php">Insanity Gamers</a>. Website designed and coded by <a href="http://www.fabianbaum.com">e1o14</a>. All rights reserved.</font></p>
    </div>
</div>