<?php
	include "config/config.php";
?>

<div class="ranking"><b><font color="#323232">User Panel</font></b><br /><br />
  <table width="100%" height="100%" border="0">
			<tr>
				<td width="68%" height="64">
			  <table width="164" border="0" align="center">
						<tr>
							<td width="158">
								<?php
								$user = $_SESSION['UserID'];
									echo "<font color='#c15516'>Welcome Back, <b><a href='userpanelfull.php'>".$user."</a></b>!</font>";
								?>
								<br /><a href="index.php?action=logout"><img src="images/logout.png" /></a>
							</td>
						</tr>
				  </table>
			  </td>
			</tr>
	  </table>
</div>