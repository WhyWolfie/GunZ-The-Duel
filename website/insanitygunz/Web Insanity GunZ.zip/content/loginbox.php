<div class="ranking"><b><font color="#323232">Login</font></b><br /><br />
  <table width="100%" height="100%" border="0">
			<tr>
				<td width="68%" height="64">
			  <table width="164" border="0" align="center">
						<tr>
							<td width="158">
							<form action="login.php" method="post">
								<input name="userid" type="text" value="username" onFocus="clearText(this)" onBlur="clearText(this)" style="float: left; background:url(images/login_input.png) no-repeat; color:#C60;" width="110px" tabindex="1" size="12" border="0" />
								<input name="pasw" type="password" value="password" onFocus="clearText(this)" onBlur="clearText(this)" style="float: left; background:url(images/login_input.png) no-repeat; color:#C60" width="110px" tabindex="2" size="12" border="0" />
								<input type="submit" value="Login" style="background:url(images/login_button.png); width:50px;" /><font color="#FFFFFF"> or </font><a href="register.php">Register</a>
							</form>
							</td>
						</tr>
				  </table>
			  </td>
			</tr>
	  </table>
</div>
