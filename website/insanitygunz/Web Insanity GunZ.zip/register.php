<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Register</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Register</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
					<br />
					   <form action="" method="post">
						  <tr><td height="30">Username : </td><td><input type="text" name="username" /></td></tr>
						  <tr><td height="28">Password : </td><td><input type="password" name="password" /></td></tr>
						  <tr><td height="29">Repeat password : </td><td><input type="password" name="repeatpassword" /></td></tr>
						  <tr><td height="29">Email : </td><td><input type="text" name="email" /></td></tr>
						  <tr><td height="29">Name : </td><td><input type="text" name="name" /></td></tr>
						  <tr><td height="29">Age : </td><td><input type="text" name="age" /></td></tr>
						  <tr><td height="29">Referrer : </td><td><input type="text" name="refer" /></td></tr>
						  <tr><td></td><td><input type="submit" name="register" value="Register" /></td></tr>
					   </form>
					   
					 <?php
					 //Accounts Created
					 $query = "SELECT COUNT(*) FROM Account";
					 $result = mssql_query($query);
					 $row = mssql_fetch_row($result);

					 echo '<tr><td>&nbsp;</td></tr><tr><tr><td colspan="2"><hr width="200px" /></td></tr><td colspan="2">Accounts Created : <font color="#CC0000">'.$row[0].'</font></td></tr>';
					 //Characters Created
					 $query1 = "SELECT COUNT(*) FROM Character";
					 $result1 = mssql_query($query1);
					 $row1 = mssql_fetch_row($result1);

					 echo '<tr><td colspan="2">Characters Created : <font color="#CC0000">'.$row1[0].'</font></td></tr>';
					 //Clans Created
					 $query2 = "SELECT COUNT(*) FROM Clan";
					 $result2 = mssql_query($query2);
					 $row2 = mssql_fetch_row($result2);

					 echo '<tr><td colspan="2">Clans Created : <font color="#CC0000">'.$row2[0].'</font></td></tr>';
					 
					function mssql_query_z($query){
						return mssql_query($query);
					}
					 if(isset($_POST['register'])){
					   $username = anti_injection($_POST['username']);
					   $password = anti_injection($_POST['password']);
					   $repeatpassword = anti_injection($_POST['repeatpassword']);
					   $email = anti_injection($_POST['email']);
					   $name = anti_injection($_POST['name']);
					   $age = anti_injection($_POST['age']);
					   $refer = anti_injection($_POST['refer']);
					   $coins = anti_injection(0);
					   
					   $query = mssql_query("SELECT UserID FROM Login WHERE UserID = '".$username."'");
					   $query2 = mssql_query_z("SELECT Email FROM Account WHERE Email = '".$email."'");
					   if(!$username OR !$password OR !$repeatpassword OR !$email OR !$name OR !$age){
						$msg = "Please fill in all the fields!"; alert($msg);
						redirect("register.php");
					   }elseif(mssql_num_rows($query)>0){
						$msg = "Username already exists!"; alert($msg);
						redirect("register.php");
					   }elseif(strlen($username)>15){
						$msg = "Username length is too long!"; alert($msg);
						redirect("register.php");
					   }elseif($password != $repeatpassword){
						$msg = "Passwords do not match!"; alert($msg);
						redirect("register.php");
					   }elseif(strlen($password)>20){
						$msg = "Password length is too long!"; alert($msg);
						redirect("register.php");
					   }elseif(mssql_num_rows($query2)>0){
						$msg = "E-Mail already exists!"; alert($msg);
						redirect("register.php");
					   }elseif(strlen($email)>35){
					    $msg = "E-Mail length is too long!"; alert($msg);
						redirect("register.php");
					   }elseif(strlen($name)>12){
					    $msg = "Name length is too long!"; alert($msg);
						redirect("register.php");
					   }elseif(strlen($refer)>15){
						$msg = "Referrer name length is too long!"; alert($msg);
						redirect("register.php");
					   }else{
						$date = date("Y-m-d H:i:s");
						$insert2 = mssql_query("INSERT INTO Account (UserID, UGradeID, PGradeID, RegDate, Email, Name, Age, Referrer) VALUES('$username', '0', '0', '$date', '$email', '$name', '$age', '$refer')");
						$caid = mssql_query("SELECT AID FROM Account WHERE UserID='".$username."'");
					   if ($caid <> 0){
						$i=1;
						while ($ad = mssql_fetch_assoc($caid)){
						 $aid = $ad['AID'];
						 $i++;
						$insert = mssql_query("INSERT INTO Login (UserID, AID, Password) VALUES('".$username."', '".$aid."', '".$password."')");
						$test = mssql_query("INSERT INTO DonationList (AID, UserID, Coins) VALUES('".$aid."', '".$username."', '".$coins."')");
						 $msg = "Account Created!"; alert($msg);
						 redirect("register.php");
						}
					   }
					   }
					 }
					//Alert
					function alert($msg){
					  echo "<script language=\"javascript\">alert(\"".$msg."\");</script>";
					}
					//Redirect
					function redirect($url){
						echo "<body><script>document.location = '$url'</script></body>";
					}
					//Anti Injection
					function anti_injection($sql) {
					  $sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|'|\"|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
					  $sql = trim($sql);
					  $sql = strip_tags($sql);
					  $sql = addslashes($sql);
					return $sql;
					}
					?>

                </table>
            </div>
            <img src="images/contact.png" height="500" width="458" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
