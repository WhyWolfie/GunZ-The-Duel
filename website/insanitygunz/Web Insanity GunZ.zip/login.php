<?php	
include "config/config.php";
function SafeString($value)
{
	$newValue = stripslashes($value);
	return str_replace("'", "''", $newValue);
}
function redirection($link, $sec){
echo "<script type=\"text/javascript\">
window.setTimeout(\"location=('" . $link. "');\",$sec)
</script><noscript><a href=\"" . $link . "\"></a></noscript>";
}

function SafeOutput($value)
{
	return htmlspecialchars(stripslashes($value));
}
function sanitize ( $data )
{
 if ( ! get_magic_quotes_gpc ( ) ) // If sanitizing for databasing isn't done..
   $data = preg_replace ( Array ( '/[\\\[\]]/', '/\'/', '/"/' ), Array ( '\\', '\\\'', '\"' ), $data ); // ..do so

 $data = preg_replace ( Array ( '/[\>]/', '/[\<]/' ), Array ( '&gt;', '&lt;' ), $data ); // Escape tags to prevent tag-injection

 return $data;
}
function antisql($sql) {
    $ssql = preg_replace(sql_regcase("(select|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables)"),"",$sql);
	
    return ( str_replace( "'", "''", $ssql ) );
}
		$user = $_REQUEST['userid'];
		$pwd = $_REQUEST['pasw'];

		$sql = mssql_query("SELECT * FROM Login WHERE UserID = '".antisql(SafeString($user))."' AND Password = '".antisql(SafeString($pwd))."'");
		if ($row = mssql_fetch_assoc($sql))
		{
			$sqlacc = mssql_query("SELECT * FROM Account WHERE UserID = '".$row['UserID']."'");
			$accdata = mssql_fetch_assoc($sqlacc);
		
			if(!isset($_SESSION)) 
			{ 
				session_start();
			} 
		
			$accountid = $row['AID'];
			$accountuserid = $row['UserID'];
			$_SESSION['AID'] =  $accountid;
			$_SESSION['UserID'] = $accountuserid;
              	        $ip = $_SERVER['REMOTE_ADDR'];
			$expire = time() + 60;
			$checklogged = mssql_query("SELECT * FROM LoggedOn WHERE ip = '$ip'");
			
			if (mssql_num_rows($checklogged) != 1)
			{
				mssql_query("INSERT [LoggedOn] ([accountid], [ip], [expire]) VALUES ('$accountuserid', '$ip', $expire)");
			}					
					print '<script type="text/javascript">';					
					print 'alert("Welcome '.SafeOutput($accountuserid).', nice to see you again!")';
					print '</script>';
					redirection("userpanelfull.php","0");
		}
else
{
print '<script type="text/javascript">'; 
print 'alert("Wrong username or password!")';
print '</script>';
redirection("index.php","0");
}
?>