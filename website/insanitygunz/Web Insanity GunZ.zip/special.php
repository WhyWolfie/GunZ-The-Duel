<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Shop</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center">
	<table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center">
		<table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Shop</b><br /></p>
            <div class="news_table">
				<table width="100%" border="0">
					<tr>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="shop.php">[Home]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="sets.php">[Sets]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="armor.php">[Armor]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="melee.php">[Melee]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="ranged.php">[Ranged]</a></td>
						<td align="center" style="background-color:#1a1a1a; height:30px; width:50px"><a href="special.php">[Special]</a></td>
					</tr>
				</table>
            	<table width="100%" border="0" id="shop">
					<br />
					<tr>
						<td width="60"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"><img src="images/shop/statue.png" width="100px" height="100px" /></a></td>
						<td>
							<font color="#CCCCCC" size="-1">
								Name: Statue<br/>
								Type: Medikit <br/>
								Level: 1 <hr/>
								Heals: 20 HP/AP <br />
								Delay: 900 <br />
								Weight: 5 <br />
								Amount: 5/5<br />
								Price: 15
							</font>
						</td>
						<td width="60"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"><img src="images/shop/.png" width="100px" height="100px" /></a></td>
						<td>
							<font color="#CCCCCC" size="-1">
								<b><u>Account Colors:</u></b><hr/>
								<font color="#00FF00">Blue</font> <br/>
								<font color="#0000FF">Green</font> <br/>
								<font color="#FF0000">Red</font> <br />
								<font color="#FFFF00">Yellow</font> <br />
								<font color="#000000">Black</font><br />
								Price: 25<br /> (Black: 50)
							</font>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>
							&nbsp;
						</td>
						<td>&nbsp;</td>
						<td>
							&nbsp;
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
							<td>
							&nbsp;
						</td>
						<td>&nbsp;</td>
						<td>
							&nbsp;
						</td>
					</tr>
                </table>
				<table width="100%" border="0">
					<tr>&nbsp;</tr>
					<tr>
						<td align="center"><a href="melee.php">[1]</a></td>
					</tr>
				</table>
            </div>
            <img src="images/shop_main.png" height="635" width="458" />
			</td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table>
	</td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>
