<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Insanity GunZ - Clan Ranking</title>
	<link rel="stylesheet" href="css/style.css" type="text/css"  />	
</head>

<?php
	include "header.php";
	include "config/config.php";
?>

<div id="frame">
  <table width="900" height="648" border="0" align="center">
  <tr>
    <td width="50%" align="center"><table width="900" height="612" border="0" align="center">
      <tr>
        <td width="25%" height="608" align="left">
        	<?php
				include "left.php";
			?>
        </td>
        <td width="50%" align="center"><table height="100%" border="0">
          <tr>
            <td valign="top"><p class="news"> <b>Ranking</b><br /></p>
            <div class="news_table">
            	<table width="100%" border="0">
                <tr style="font-weight:bold"><td>Rank:</td><td>Name:</td><td>Master:</td><td>Wins:</td><td>Losses:</td><td>Points:</td></tr>
                <tr><td>&nbsp;</td></tr>
				 <?php   
					function c($value)
					{
					return($value);
					}
 					function Char($cid)
					{
					$ncid = c($cid);
					$res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));
					$name = $res[1];

					switch($res[0])
					{
					case 255:
						return "<font color='#FF7FF0'>$name</font>";
					break;
					case 254:
						return "<font color='#E066FF'>$name</font>";
					break;
					case 253:
						return "<font color='#000000'><strike>$name</strike></font>";
					break;
					default:
						return "<font color='#FFFFFF'>$name</font>";
					break;
					}
					}
				 
 					$clrank = "SELECT TOP 15 CLID, Name, MasterCID, Wins, Losses, Point FROM Clan WHERE DeleteFlag=0 ORDER BY Point DESC";
					$result = mssql_query($clrank);
					$count = 1;
					
					while($row = mssql_fetch_array($result)){
					
					$MCID = "SELECT * FROM Clan WHERE Name='".$row["Name"]."'";
					$asd = mssql_query($MCID);
					$lol = mssql_fetch_assoc($asd);
					
					$clnmaster = "SELECT * FROM Character WHERE CID='".$lol['MasterCID']."'";
					$q = mssql_query($clnmaster);
					$master = mssql_fetch_assoc($q); 
					echo "<tr><td>".$count++."</td><td>" .$row["Name"]. "</td><td>" .Char($row["MasterCID"]). "</td><td>".$row["Wins"]."</td><td>".$row["Losses"]."<td align='right'>" . $row["Point"]."</td></tr>";	
					}
					?>
                </table>
                <table width="100%" align="center">
                	<tr><td>&nbsp;</td></tr>
                	<tr valign="middle">
                    	<td><a href="plranking.php"><img src="images/player.png" /></a></td>
                        <td><a href="clranking.php"><img src="images/clan.png" /></a></td>
                    </tr>
                </table>

            </div>
            <img src="images/contact.png" height="500" width="458" /></td>
          </tr>
        </table>
        <td width="25%" align="right">
			<?php
				include "right.php";
			?>
		</td>
      </tr>
    </table></td>
  </tr>
  </table>
</div>

<br /><br />

<?php
	include "footer.php";
?>

</body>

</html>