<script type="text/javascript">
	$(document).ready(function(){	
		$("#slider").easySlider({
			auto: true, 
			continuous: true,
			numeric: true
		});
	});	
</script>
<script type="text/javascript">
function clearText(field){
	if (field.defaultValue == field.value) field.value = '';
	else if (field.value == '') field.value = field.defaultValue;
}
</script>
	
<?php
	include "config/config.php";
?>

				<table height="100%" border="0">
			 		<tr>
    					<td width="250" height="167" valign="middle"><div style="margin-top:30px">
						<?php
							if(!isset($_SESSION['UserID']) && !isset($_SESSION['AID']))
							{
								include "content/loginbox.php";
							}
							else
							{
								include "content/userpanel.php";
							}
						?>


                        	<img src="images/login.png" /></div>
                        </td>
					</tr>
  					<tr>
    					<td height="81" valign="top">
                        <p class="ranking"><b><font color="#323232">Server Status</font></b><br /><br />
                        <font color="#FFFFFF">
                        
                	<?php 
						$fp = @fsockopen($srvip, $srvport, $errno, $errstr, 1);
						// Player Stats
						$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
						while($srv = mssql_fetch_assoc($res)){
						$playercount = $srv['CurrPlayer'];
						}

						if (!$fp) {
							echo "<div id='server_off'></div>";
						} else {
							echo ' ';
								if ($playercount == 1) {
									echo "<div id='server_on'><br /><br /><br /><div style='margin-top:-5px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $playercount . " Player online!</d></p></div>";
								} else {
									echo "<div id='server_on'><br /><br /><br /><div style='margin-top:-5px'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $playercount . " Players online!</d></p></div>";
								}
						fclose($fp);
					    }						
						?>
                         

                        </td>
  					</tr>
  					<tr>
    					<td valign="top">
                        	<p class="ranking"><b><font color="#323232">Item Shop</font></b></p>
								<div class="news_table">
									<table border="0" width="185px" height="170px">
										<tr align="center">
											<td><a href="armor.php"><img src="images/shop/rabbitmask.png" width="80px" height="80px" style="border:#666 solid 1px" /></a></td>
											<td><a href="melee.php"><img src="images/shop/batarang.png" width="80px" height="80px" style="border:#666 solid 1px" /></a></td>
										</tr>
										<tr>
											<td><a href="ranged.php"><img src="images/shop/enforcer.png" width="80px" height="80px" style="border:#666 solid 1px" /></a></td>
											<td><a href="special.php"><img src="images/shop/statue.png" width="80px" height="80px" style="border:#666 solid 1px" /></a></td>
										</tr>
									</table>
									<table border="0" width="185px" height="50px">
										<tr align="center">
											<td>
												<div id="donate"><a href="http://forum.insanity-gamers.com/showthread.php?tid=54"></a></div>
											</td>
										</tr>
									</table>
								</div>
                        	<img src="images/shop.png" />
                        </td>
  					</tr>
			  </table>