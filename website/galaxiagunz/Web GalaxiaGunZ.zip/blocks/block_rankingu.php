<?
$fire = mssql_query_logged("SELECT TOP 5 * FROM Character a, Account b WHERE a.AID=b.AID AND b.UGradeID !=255|254|253|252 AND DeleteFlag=0 ORDER BY Level DESC, XP ASC");
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.Estilo3 {color: #414141}
-->

</style>
</style>
<table background="images/md_ir.png"  width="174" height="144" border="0">
<tr>
    <td><table width="169" height="100" border="0" style="border-collapse: collapse">
      <tr>
        <td width="11" rowspan="6">&nbsp;</td>
        <td height="15" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($fire) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos</div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($fire)){

                                    ?>
      <tr>
	  <td width="12" align="left">  															</td>
  															<td width="93" align="left"><span class="Estilo3"></span><?=FormatCharName($user['CID'])?>
         			      <td width="27"><strong><?=$user['Level']?><span class="Estilo3">.</span>Lvl.</strong></td>
										<td width="0"></td>
										<td width="0">
										</td>
		</tr>
                                    <?}}?>
									<tr>
    </table>    <td height="39"></tr>
</table>
