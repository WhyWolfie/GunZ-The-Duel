<?php
// Config Siganture
$url	=	"http://gunz.galaxiagamers.net";
$img 	=	"images/sign.png";

?>