﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN">
<html>
<head>
	<meta charset="iso-8859-1"/>
	<title>Galaxia Gunz</title>
	<style>
	body {
		background: url("front.png") #000000 no-repeat;
		background-size:100%;
		background-position:top;
		overflow:hidden;
		padding:2px;
		margin: 0;
		margin-left: 0.5em;
		overflow: hidden;
		color: #FFFFFF;
		font-size: 12px;
		font-family:arial;
		text-shadow:2px 2px 2px white;
	}
	
	a{
		color: #08f;
		text-decoration: underline;
	}
	
	a:active{
		color: #FF0000;
		text-decoration: none;
	}
	a:hover{
		color:#0af;
	}
	
	h1 {
		font-size: 18px;
		font-weight: bold;
	}
	
	h2 {
		font-size: 15px;
		font-weight: bold;
		text-decoration: underline;
	}
	
	img {
		border:0;
		}
		

	.quote {
		background-color: #202020;
		font-family:"Courier New","Courier";
		border: #ffffff solid 0.05em;
		width: 85%;
		padding: 1px;
		filter:alpha(opacity=80);
		-moz-opacity:.80;
		opacity:.80;
	}

	a.quote2:link, a.quote2:visited{
		text-decoration: none;
	}

	a.quote2:hover, a.quote2:active{
		text-decoration: underline;
	}
    </style>
</head>
	<body>
	 <table height="92" width="237" style="background:rgba(00,00,00,0.6); color:#ffffff; border-radius:10px 10px 10px 10px;">
      <tr>	   <td>
	   &nbsp;<strong><span style="text-shadow:2px 2px 2px black;">Estado del Servidor:</span></strong> <?php
$srvip = "37.59.88.61";
$srvport = "3525";
$mssql_user = "sa";
$mssql_pass = "04246684533Pgjunior2012";
$mssql_database = "GunzDB";
$mssql_host = "WIN-DQ1TFO2YVVO\SQLEXPRESS";
$conn = mssql_connect($mssql_host, $mssql_user, $mssql_pass);
mssql_select_db($mssql_database);
echo "";
$fp = @fsockopen($srvip, $srvport, $errno, $errstr, 1);
if (!$fp) {
echo "<font style='font-weight:bold; color:#FF3300'><B> OFFLINE</B></font></br>";
} else {
echo "<font style='font-weight:bold; color:#2cb407'><B> ONLINE</B></font></br>";
fclose($fp);
}
?></td>
      </tr>
	  <tr>
	   <td>
	   &nbsp;<strong><span style="text-shadow:2px 2px 2px black;">Usuarios Conectados:</strong> <strong><?php

$con = mssql_connect("WIN-DQ1TFO2YVVO\SQLEXPRESS","Sa","04246684533Pgjunior2012");
if (!$con)
    {
    die('Couldnt not connect: ' . mssql_error());
    }
    
mssql_select_db("GunzDB");

$getcurp = mssql_query("SELECT CurrPlayer,MaxPlayer FROM ServerStatus");
$getcur = mssql_fetch_array($getcurp);
echo $getcur['CurrPlayer'];


?></strong>
	   </td>
      </tr>
	  <tr>
	   <td width="400">
	   &nbsp;<strong>Ultima Actualizacion:</strong> <strong><font color="#0099FF">Martes, 04-12-2012</font></strong>
	   </td>
      </tr>
    </table><br>
    <table height="92" width="237" style="background:rgba(00,00,00,0.6); color:#ffffff; border-radius:10px 10px 10px 10px;">
      <tr>
        <td>&nbsp;<strong>URL Pagina web:</strong> <a href="http://gunz.galaxiagamers.net/index.php" target="_blank" style=" text-decoration:none;"><strong>Entrar Ahora</strong></a> </td>
      </tr>
      <tr>
        <td>&nbsp;<strong>URL Pagina de Registro:</strong> <a href="http://gunz.galaxiagamers.net/index.php?do=register" target="_blank" style=" text-decoration:none;"><strong>Entrar Ahora</strong></a> </td>
      </tr>
      <tr>
        <td>&nbsp;<strong>URL Pagina de Descarga:</strong> <a href="http://gunz.galaxiagamers.net/index.php?do=download" target="_blank" style=" text-decoration:none;"><strong>Entrar Ahora</strong></a> </td>
      </tr>
    </table>
	<p>
	<p>
	<table align=""height="21" width="541">
	<tr>
		<?
		$selectc = "SELECT TOP 3 * FROM Account a,Character b WHERE a.AID=b.AID AND a.AID != 254|255|253|252 AND DeleteFlag = 0 ORDER BY GML DESC,Level DESC,XP DESC";
		$queryc = mssql_query($selectc);
		$rank = 0;
		?>
        <td style="background:rgba(00,00,00,0.6); color:#ffffff; border-radius:10px 10px 10px 10px;"></td>
      </tr>
    </table><center>
    <table style="background:black;display:inline-block;width:20%">
    	<tr>
    		<th style="padding:5px;background:#08f;color:white;" colspan="200">Los 3 Mas Destacados</th>
    	</tr>
    	<tr>
    		<th style="padding:5px;background:#555;coplor:white;">Rank</th>
    		<th style="padding:5px;background:#555;color:white;">Nombre</th>
    		<th style="padding:5px;background:#555;color:white;">Level [<font color="red"> GML </font>]</th>
    		<th style="padding:5px;background:#555;color:white;">EXP</th>
    	</tr>
    	<?
    	while($row = mssql_fetch_array($queryc))
    	{
    		$rank++;
    		?>
    	<tr>
    		<td width="1%" style="text-align:center;background:#ccc;color:white;font-weight:bold;"><img src="ranks/<?=$rank?>.png"/></td>
    		<td style="text-align:center;background:#222;color:white;font-weight:bold;"><?=$row['Name']?></td>
    		<td style="text-align:center;background:#222;color:white;font-weight:bold;"><?=$row['Level']?> [<font color="red"> <?=$row['GML']?> </font>]</td>
      		<td style="text-align:center;background:#222;color:white;font-weight:bold;"><?=$row['XP']?></td>
    	</tr>
    		<?
    	}
    	?>
    	<tr>
    		<th style="padding:5px;background:#08f;color:white;" colspan="4">&nbsp;</th>
    	</tr>
    </table>
    <strong><span style="text-shadow:2px 2px 2px black;">Contacto Via Telefonica: - 0424-6133688 (<font color="#0099FF"> Pedro Gonzalez </font>) </strong>
    <center>
	</body>
	                                                                               
</html>
