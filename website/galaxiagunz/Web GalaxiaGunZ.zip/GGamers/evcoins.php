<? 
///////////////////////////////////////// 
//// Coded By Gaspar //// 
//////////////////////////////////////// 

//Configura��es Do SQL Server 
$host = "WIN-DQ1TFO2YVVO\SQLEXPRESS"; //Servidor do SQL Server (Exemplo:SEU-PC\SQLEXPRESS) 
$user = "sa"; //Login do SQL Server (Padr�o:sa) 
$pass = "04246684533Pgjunior2012"; //Senha do SQL Server 
$dbname = "GunzDB"; //Database do seu servidor (Padr�o:GunzDB)

$msconnect=mssql_connect("$host","$user","$pass") or die ('N�o � possivel estabelecer uma conec��o com o SQL Server'); 
$msdb=mssql_select_db("$dbname",$msconnect); 

$IP = $_SERVER["REMOTE_ADDR"]; 
$nick = $_GET['Character']; 
$coins = $_GET['Value']; 
$status = "on"; 

if($nick == "") 
{ 
echo "Erro"; 
die(); 
} 

if($coins == "") 
{ 
echo "Erro"; 
die(); 
} 

$admins = mssql_query("SELECT AID FROM Account WHERE UGradeID >= 254");

while($admins2 = mssql_fetch_row($admins))
{ 

$busca1 = mssql_query("SELECT LastIP FROM Login WHERE AID = '$admins2[0]'"); 
$busca2 = mssql_fetch_row($busca1); 

if($busca2[0] == $IP) 
{ 

if($status == "on") 
{ 

$query1 = mssql_query("SELECT AID FROM Character WHERE Name = '$nick'"); 
$query2 = mssql_fetch_row($query1); 

if (!(isset($query2[0]))) 
{ 
die ("Personaje Inexistente"); 
} 

$query3 = mssql_query("UPDATE Account SET EventCoins=EventCoins+$coins WHERE AID = '$query2[0]'"); 

$status = "off"; 
} 

} 

switch($status) { 
case on: $status_final = "En Error de autenticaci�n"; break; 
case off: $status_final = "EvCoins Enviados!"; break; 
} 

} 

echo $status_final; 
?>