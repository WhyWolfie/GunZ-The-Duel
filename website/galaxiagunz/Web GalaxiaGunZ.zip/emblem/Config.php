<?php
include("secure/anti_inject.php");
include("secure/sql_check.php");
include("secure/anti_sql.php");
include("secure/anti_inject_sql.php");
include("secure/inject.php");
include("secure/banneduser.php");
include("secure/checkcookie.php");
include("secure/ctracker.php");
include("secure/equipt.inc.php");
require("secure/criminalteam.php");

/////Lo editamos con nuestros datos
$DBHost = "WIN-DQ1TFO2YVVO\SQLEXPRESS";
$DBUser = 'sa';
$DBPass = '04246684533Pgjunior2012';
$DB = 'GunzDB';
?>