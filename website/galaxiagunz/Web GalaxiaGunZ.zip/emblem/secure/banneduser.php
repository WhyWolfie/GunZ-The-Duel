<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>War GunZ - conta Banned</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg2.jpg);
}
-->
</style></head>
										<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>Querido <?=$_SESSION['UserID']?>,</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

                                                                                           Sua conta foi banida pela equipe War GunZ.
											<p>Eu acho que voc� j� sabe como chegou a esse ponto.</p>
                                                                                        <p>Voc� sempre pode fazer uma nova conta a partir da p�gina de cadastro.</p>
                                                                                        <p>Voc� pode sempre tentar obter unbanned na se��o sobre o unban <a href="http://www.orkut.com.br/Main#Community?cmm=105740102">forum</a>.</p>
                                                                                        <p>Ent�o, desta vez n�o se esque�a de ler e seguir as <a href="http://www.orkut.com.br/Main#Community?rl=cpn&cmm=81897441">Regras</a>.</p>
                                                                                        <p>Tenha um bom dia.</p>
											<p>Obrigado, equipe War GunZ</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


    <?
    die();
}

?>