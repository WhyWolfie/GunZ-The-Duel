<?

header("Location: /error404/");
?>