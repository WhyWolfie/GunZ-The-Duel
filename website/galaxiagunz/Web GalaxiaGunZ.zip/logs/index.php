<?
header("Location: /error404/");
?>