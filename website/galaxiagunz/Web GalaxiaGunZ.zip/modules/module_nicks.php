<?
include("secure/include.php");

SetTitle("GalaxiaGamers Gunz - Tienda Nombres");
?>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('../images/btn_buyitem3_on.jpg')">

<table border="0" style="border-collapse: collapse" width="778">
					<tr>
                      <td width="164" valign="top"><table border="0" style="border-collapse: collapse" width="164">
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;
                                
                                </td>
                            </tr>
                            <tr>
                              <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top"><div align="center">
        							<table border="0" style="border-collapse: collapse" width="164">
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127">
                                            <a href="index.php?do=shop">
                                            <img border="0" src="images/btn_newestitems_off.jpg" id = "76176img" width="132" height="22" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_newestitems_on.jpg')"></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopevent"><img border="0" src="images/btn_eventitems_off.jpg" id="eventitems37" width="132" height="26" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'eventitems37',/*url*/'images/btn_eventitems_on.jpg')" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopsets"><img src="images/btn_completeset_off.jpg" alt="" width="132" height="26" border="0" id="7816imgxD271" onMouseOver="FP_swapImg(1,1,/*id*/'7816imgxD271',/*url*/'images/btn_completeset_on.jpg')" onMouseOut="FP_swapImgRestore()" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=3"><img border="0" src="<?=($_GET[cat] <> 3) ? "images/btn_armor_off.jpg" : "images/btn_armor_on.jpg"?>" id="7816img272" width="132" height="25" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'7816img272',/*url*/'images/btn_armor_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=2"><img border="0" src="<?=($_GET[cat] <> 2) ? "images/btn_meleeweapons_off.jpg" : "images/btn_meleeweapons_on.jpg"?>" id="7816img273" width="132" height="25" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'7816img273',/*url*/'images/btn_meleeweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=1"><img border="0" src="<?=($_GET[cat] <> 1) ? "images/btn_rangedweapons_off.jpg" : "images/btn_rangedweapons_on.jpg"?>" id="7816img274" width="132" height="27" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'7816img274',/*url*/'images/btn_rangedweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=5"><img border="0" src="<?=($_GET[cat] <> 5) ? "images/btn_specialitems_off.jpg" : "images/btn_specialitems_on.jpg"?>" id="7816img275" width="132" height="23" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'7816img275',/*url*/'images/btn_specialitems_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        								  <td>&nbsp;</td>
        								  <td><a href="index.php?do=nicks" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','images/btn_nameitems_on.jpg',1)"><img src="images/btn_nameitems_off.jpg" name="Image11" width="132" height="27" border="0" id="Image11" /></a></td>
        								  <td>&nbsp;</td>
      								  </tr>
   								  </table>
        						</div></td>
                        </tr>
                        <tr>
    						<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
                            <div align="center">
                            &nbsp;<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p></div></td>
                        </tr>
                      </table></td>
						<td width="599" valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-image: url('images/content_title_shop_home.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601" colspan="3" height="5"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
								    <table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" height="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="../images/shop/donador/changename.gif" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left">Nombre a  Color</span></b></td>
																				</tr>
																				<tr>
																					<td width="43" align="left">Tipo:</td>
                                                                          <td width="125">Donador</td>
                                                                        </tr>
                                                                        <tr>
																		<td width="43" align="left">Sexo:</td>
                                                                          <td width="125">Todos</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Nivel:</td>
                                                                          <td width="125">0</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Precio:</td>
                                                                          <td width="125">250 DonadorCoins </td>
																			  </tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="55"><a href="index.php?do=buycolorname"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1791',/*url*/'images/btn_buyitem3_on.jpg')" /></a></td>
																									<td width="55">&nbsp;</td>
																								  <td width="56">&nbsp;</td>
																								</tr>
																							</table>
																						</div>																					</td>
																				</tr>
																				<tr>
																					<td width="43">&nbsp;</td>
																					<td width="125">&nbsp;</td>
																				</tr>
																			</table>
																		</div>																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>															</td>
															<td width="290" valign="top"><div align="center">
                                                              <table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95">&nbsp;</td>
                                                                  <td width="178">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95" valign="top"><img src="../images/shop/donador/changename.gif" alt="d" width="100" height="100" border="0" style="border: 2px solid #171516" /></td>
                                                                  <td width="178" valign="top"><div align="center">
                                                                      <table border="0" style="border-collapse: collapse" width="170">
                                                                        <tr>
                                                                          <td colspan="2"><div align="left">
                                                                            Jjang</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Tipo:</td>
                                                                          <td width="125">Evento</td>
                                                                        </tr>
                                                                        <tr>
																		<td width="43" align="left">Sexo:</td>
                                                                          <td width="125">Todos</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Nivel:</td>
                                                                          <td width="125">0</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Precio:</td>
                                                                          <td width="125">250 EventCoins </td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td colspan="2">&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td colspan="2"><div align="center">
                                                                              <div align="center">
                                                                                <table border="0" style="border-collapse: collapse" width="166" height="100%">
                                                                                  <tr>
                                                                                    <td width="55"><a href="index.php?do=jjang"></a><a href="index.php?do=jjang" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('sdsadasdasdasdasdasd','','../images/btn_buyitem3_on.jpg',1)"><img src="../images/btn_buyitem3_off.jpg" name="sdsadasdasdasdasdasd" width="52" height="23" border="0" id="sdsadasdasdasdasdasd" /></a></td>
                                                                                    <td width="55">&nbsp;</td>
                                                                                    <td width="56">&nbsp;</td>
                                                                                  </tr>
                                                                                </table>
                                                                              </div></td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43">&nbsp;</td>
                                                                          <td width="125">&nbsp;</td>
                                                                        </tr>
                                                                      </table>
                                                                  </div></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95">&nbsp;</td>
                                                                  <td width="178">&nbsp;</td>
                                                                </tr>
                                                              </table>
														    </div></td>
													  </tr>
														<tr>
														  <td width="289" valign="top"><table border="0" style="border-collapse: collapse" width="287" height="100%">
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95">&nbsp;</td>
                                                                  <td width="178">&nbsp;</td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95" valign="top"><img src="../images/shop/donador/changename.gif" alt="d" width="100" height="100" border="0" style="border: 2px solid #171516" /></td>
                                                                  <td width="178" valign="top"><div align="center">
                                                                      <table border="0" style="border-collapse: collapse" width="170">
                                                                        <tr>
                                                                          <td colspan="2"><div align="left">
                                                                            Cambiar Nombre </td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Tipo:</td>
                                                                          <td width="125">Donador</td>
                                                                        </tr>
                                                                        <tr>
																		<td width="43" align="left">Sexo:</td>
                                                                          <td width="125">Todos</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Nivel:</td>
                                                                          <td width="125">0</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43" align="left">Precio:</td>
                                                                          <td width="125">250 DonadorCoins</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td colspan="2">&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td colspan="2"><div align="center">
                                                                              <div align="center">
                                                                                <table border="0" style="border-collapse: collapse" width="166" height="100%">
                                                                                  <tr>
                                                                                    <td width="55"><a href="index.php?do=cambiodename"></a><a href="index.php?do=cambiodename" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('sdsadasdasdasdasdasd2','','../images/btn_buyitem3_on.jpg',1)"><img src="../images/btn_buyitem3_off.jpg" name="sdsadasdasdasdasdasd2" width="52" height="23" border="0" id="sdsadasdasdasdasdasd2" /></td>
                                                                                    <td width="55">&nbsp;</td>
                                                                                    <td width="56">&nbsp;</td>
                                                                                  </tr>
                                                                                </table>
                                                                              </div></td>
                                                                        </tr>
                                                                        <tr>
                                                                          <td width="43">&nbsp;</td>
                                                                          <td width="125">&nbsp;</td>
                                                                        </tr>
                                                                      </table>
                                                                  </div></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="8">&nbsp;</td>
                                                                  <td width="95">&nbsp;</td>
                                                                  <td width="178">&nbsp;</td>
                                                                </tr>
                                                              </table></td>
														  <td width="290" valign="top">&nbsp;</td>
														</tr>
												  </table>
												</div>												</td>
											</tr>
									  </table>
									</div>									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601" colspan="3" height="5"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="601">&nbsp;</td>
								  <td style="background-repeat: repeat; background-position: center top" width="583">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;									</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
</table>