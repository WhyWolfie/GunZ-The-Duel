<?
include("secure/include.php");

SetTitle("GalaxiaGamers Gunz - Informacion");
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table width="100%" height="429" border="1" bordercolor="#000000" style="border-collapse: collapse">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Informacion de clanes</td>
							  </tr>
								<tr>
								  <td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top"><?
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("El Clan no Existe","index.php");
exit();
}

$clid = $clan->CLID;
?> 
                                                  <div align="center"><br>Clan: <strong>
                                                  <?=$clan->Name?>
                                                  </strong>
                                                    </center>
												  </div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											  <td width="380" style="background-repeat: no-repeat; background-position: center top"><div align="center"><br><img src="http://gunz.galaxiagamers.net/emblem/upload/<?=($clan->EmblemUrl == "") ? "uploadnoemblem.jpg" : $clan->EmblemUrl?>" width="100" height="100" BORDER=2 ></div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">	<table border="2" style="border-collapse: collapse" width="447" height="100%">
<div align="center">
&nbsp;
                         <tr>			    
                                    <td align="left"><strong>Rank:</strong></td>
                                    <td align="left"><?=$clan->Ranking?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Puntos:</strong> </td>
                                    <td align="left"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Win:</strong></td>
                                    <td align="left"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Losses:</strong></td>
                                    <td align="left"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Draw:</strong></td>
                                    <td align="left"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Creado:</strong></td>
                                    <td align="left"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Membros:</strong></td>
                                    <td align="left"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table>											</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top"><br><table width="448" cellpadding="0" cellspacing="0">
&nbsp;
                                  <tr>
                                    <td align="left"><u><strong>Personajes</strong></u></td>
                                   <td align="left"><u><strong>Rango</strong></u></td>
                                    <td align="left"><u><strong>Ultima Coneccion</strong></u></td>
                                    <td align="left"><u><strong>Pts</strong></u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "<font color='white'>Miembro";
    break;
    case "2";
       $grade = "<font color='red'>Administrador";
    break;
    case "1";
       $grade = "<font color='orange'>Lider";
    break;
}


?>
                                  <tr>
                                    <td align="left"><a href="index.php?do=charinfo&id=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="left"><? echo $grade; ?></td>
                                    <td align="left"><?=$char->RegDate?></td>
                                    <td align="left"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											</table>
									</div></td>
								</tr>
						  </table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<?
$filhodaputa = array(";","'","\"","*","uninic","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>