<? 
$nombregunz			=		"GalaxiaGamers Gunz";		
$precio			=		"250";  
$coins		=		"EventCoins";
$redirec		=		"nicks"; 
$numjjang	=	"2";
$namejjang	=	"Jjang";
?>