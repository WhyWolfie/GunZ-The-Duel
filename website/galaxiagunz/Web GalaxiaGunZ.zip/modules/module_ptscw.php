<?
/*Todos los Derechos Reservados a FireWork�
  Sistema de Cambio de puntos de clan war por Event Coins, Programado Por FireWork�
  Publicado en www.portalxd.com/foro/gunz-online-72/*/

include("secure/include.php");


SetTitle("GalaxiaGamers Gunz - Cambiar Puntos Clan War");
?>
<script type="text/javascript">
var r={'special':/[\W]/g} 

function valid(o,w)

{

  o.value = o.value.replace(r[w],''); <!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->

}

function isAlphaNumeric(value)

{

  if (value.match(/^[a-zA-Z0-9]+$/))

    return true;

  else

    return false;

}

</script>
<?
if ($_SESSION['AID'] == ""){
     header("Location: index.php?do=login");
    die();
    }
$setember = clean($_SESSION['AID']);
$q2chars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '$setember'");
    if( mssql_num_rows($q2chars) == 0 )
    {
    alertbox("Create a character first.","index.php");
    die();
    }
function sonumeros($btbt) {
$string = $btbt;

$btbt = eregi_replace('([^0-9])','',$btbt);

if( $string != $btbt )
        {           
alertbox("Only numbers.","index.php");
die();
        }

        return( $btbt );

}    
?> 
<body onLoad="FP_preloadImgs(/*url*/'../images/btn_register_on.jpg')"><!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>						</div>						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="../images/content_bar.jpg" height="24" style="background-image: ../images/content_bar.jpg); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<font face="Tahoma" size="2"><b>&nbsp;Cambiar Puntos de Clan War - EventCoins </b></font></td>
								</tr>
								<tr>
								  <td bgcolor="#2C2A2A"><div align="center"></br>
								    <table width="484" border="0">
                                      <tr>
                                        <td>
                                          
                                          <div align="justify"><!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->
                                            <?
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$user = Filtrrar($_SESSION['UserID']);
$etapa22 = Filtrrar($_GET["etapa"]);


if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

$personagem = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($personagem) < 1 )
{
            msgbox("Usted no Posee Ningun Personaje.","index.php");
die();
}

$query2 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query2) < 1 )
{
            msgbox("Usted no Posee Ningun Personaje.","index.php");
die();
}

if($etapa22 == 0){
?>
                                            </div>
                                            <form id="ptscw" name="ptscw" method="post" action="index.php?do=ptscw&etapa=1">
                                              
                                              <div align="center">Personaje:
                                                <select name="cid" class="text"><!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->
                                                  <?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
                                                </select>
                                             
                                                <br>
                                                <input class="go" type="submit" name="ptscw" value="Siguiente" />
                                              </div>
                                          </form></td>
                                      </tr>
                                      <tr>
                                        <td><div align="justify"></div></td>
                                      </tr>
                                      <tr>
                                        <td>
                                          
                                          <div align="justify"><!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->
                                            <?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

$ptscw = mssql_query("SELECT Name FROM Character WHERE CID = '$cid22'");
$buscapts = mssql_fetch_row($ptscw);

if (!(isset($busca2[0])))


{
echo 'Este Personaje no pertenece a ningun clan';
}else{

$_SESSION["CID"] = $cid22;
echo '

Atencion: Cada 2 Puntos que Cambies es 1 EventCoins. 
<form id="ptscw" name="ptscw" method="post" action="?do=ptscw&etapa=2">';
echo "$buscapts[0] Tienes $busca2[0] Pts, Escoja la cantidad de Puntos a Cambiar por EventCoins";
echo '<br>Pon la Cantidad de Puntos que quieras Cambiar: <input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3">';
echo ' <input class="go" type="submit" name="ptscw" value="Cambiar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pts = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$ptscw = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'"); 
$buscapts = mssql_fetch_row($ptscw);

if($buscapts[0] < $pts){
echo "Voc&ecirc; bebeu? Voc&ecirc; tem $buscapts[0] pontos e quer trocar por $pts EvCoins -.-'";
}else{

if ( !is_numeric($cid23) )
{
echo "Identificaci�n de caracteres emitida";
die();
}

if ( !is_numeric($pts) )
{
echo "Intenta poner un numero mayor de 1";
die();
}

if ($pts == 0)
{
echo "No puedes comprar esta cantidad de Eventcoins";
die();		
}

if($pts < 1)
{
echo "�No Tienes Suficientes Puntos?";
die();
}

$divisao = $pts / 2;

mssql_query("update Account set EventCoins=EventCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pts where CID='$cid23'");

msgbox("Puntos Cambiados Exitosamente, Gracias...","index.php?do=ptscw");


}

}


?>
                                          </div></td>
                                      </tr>
                                      <tr>
                                        <td><div align="center"></div></td>
                                      </tr>
                                    </table></td>
								</tr>
							</table>
						</div>						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>						</td>
					</tr>
				</table>
<!--- Todos los Derechos Reservados a FireWork� - FireWorkGG@Gmail.com - ReeCodde By FireWork�--->

<?
//Esta Prohibido Vender este Sistema ya que se ha hecho con el fin de que lo obtenga gratuitamente...!!!
//Si Necesitas Ayuda, Tienes Dudas Contactame a en las Redes Sociales

//Facebook: FB/FireWorkG
//MSN:Elpapi1112@hotmail.com
//Gmail:FireWorkG@Gmail.com
?>