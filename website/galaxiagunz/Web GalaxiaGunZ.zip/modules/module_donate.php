<?
include("secure/include.php");

SetTitle("GalaxiaGamers Gunz - Donar");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.Estilo1 {font-size: 11px}
.Estilo4 {font-size: 14px}
-->
</style>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top;">
									<div align="center">
										<b><font face="Tahoma" size="2">Donaciones GalaxiaGamers Gunz</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											  <td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="left">
                                                <div style="text-align: left;" id="result_box" dir="ltr">
													<p><center><strong>DONACI�N VIA SMS:</strong>



<p>Por cada mensaje enviado, seras acreditado con 90 DonadorCoins, Recuerda esperar a que te llegue el mensaje diciendo que la compra fue un exito para poder enviar otro mensaje, para asi evitar problemas.
<p>Envian la palabra RMX GUNZGALAXIA <strong>"Tu AID"</strong> sin las comillas al n�mero que corresponda a tu a pa�s.
<p>Ejemplo de tu Cuenta: RMX GUNZGALAXIA <strong><?=$_SESSION[AID]?></strong>
<p>Recuerda Que tienes que enviar el Mensaje Todo en Mayuscula ya que si lo Envias en minuscula no se hara la compra.
<p>Si no te llegaron los DonadorCoins a tu Cuenta y te llego el mensaje, diciendo que la compra fue un exito, Deberas entrar a nuestro foro ir a la seccion de Donaciones y hacer un Nuevo Tema Con el siguiente titulo.
<p><strong>[Reporte]</strong> mas el Titulo que vas a poner tu
<p>Deberas poner en el Tema los siguientes datos
<p><strong>Tu AID:
<p>Tu Pais:</strong>

<p>Recuerda Poner bien los datos para haci evitar problemas.</p></center>

													<p>
													  <script src="https://iframes.recursosmoviles.com/v2/?wmid=3853&cid=15781" type="text/javascript"></script>
												  </p>
                                                  <center>
													<p><img src="../images/aid.PNG" width="159" height="68" /></p>
												  </center>
												  </div>
                                                </div>                                                </td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top"><center>
												</center>											</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											 <td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top"><center>
												</center>											</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top"><table width="408" height="100%" border="0" style="border-collapse: collapse; float:left">
									    <tbody>
									      <tr>
									        <td style="background-repeat: no-repeat; background-position: center top" width="380"><div style="text-align: left;" id="result_box" dir="ltr">
									          <p> <strong><center>DONACIONES VIA TARJETA TELEFONICA:</center></strong><br />
											  
									            <br />
									            <strong>Instrucciones:&nbsp;</strong><br />
									            <br />
									            1. Una vez obtenida la tarjeta debes enviar el c&oacute;digo 
									            que raspaste, junto los numeros correspondientes, Ya que esto nos ayuda a saber a que linea telefonica pertenece el codigo que raspaste.
												<br />
												<br />
												Movistar: <strong>0414 o 0424</strong><br />
									            <br />
									            <strong>Imagenes Explicativas:</strong><br />
									            <br />
								              </p>
									          <div align="center"><img src="/images/movistar.png" alt="" /><br />
									          </div>
									          <p><br />
									            2. Observa muy bien el codigo que raspastes, para que no tengas inconvenientes al hacer una donacion.<br />
									            <br />
									            3. No debes botar tu tarjeta hasta que se haya confirmado el pago, 
									           GalaxiaGamers no se hace responsable por tarjetas que env&iacute;es y ya hayan 
									            sido usadas, en caso de presentarse este problema se cancelar&aacute;n 
									            las&nbsp;<span id="IL_AD10">transacciones</span>.&nbsp;<br />
									            <br />
									            4. El precio de los DonadorCoins por este medio es el siguiente:<br />
								              </p>
									          <p></p>
									          <div align="center">
									            <form action="index.php?do=tarjeta" method="post" name="formT" id="formT" style="border: 1px solid #CECECE;padding-left: 10px;">
									              <p>
									                <input name="mmonto" value="15" type="hidden" />
								                  </p>
									              <center>
									                <br />
									                Comprar DonadorCoins <br />
									                <br />
									                <select name="ccoins" onchange="updateForm2();">
		<option selected="selected">Seleccione la cantidad de DonadorCoins</option>
		<option><strong>Movistar</strong></option>
		<option value="250">250 DonadorCoins - 20bs</option>
		<option value="350">350 DonadorCoins - 30bs</option>
		<option value="450">450 DonadorCoins - 40bs</option>
		<option value="600">600 DonadorCoins - 50bs</option>
		<option value="850">850 DonadorCoins - 60bs</option>
		<option value="950">950 DonadorCoins - 80bs</option>
		<option value="1500">1500 DonadorCoins - 100bs</option>
								                    </select>
									                
									                <p></p>
									                <p><span class="Estilo1"><font color="#00FF00" face="Verdana, Geneva, sans-serif">Por favor verifique digito por 
									                  digito y envie correctamente la tarjeta, evite enviar tarjetas falsas 
									                  esto trae como consecuencia suspensi&oacute;n permanente de su cuenta en 
									                  nuestro servidor.</font></span></p>
									                <table border="0" width="100%">
                                                      <tbody>
                                                        <tr>
                                                          <td align="center">C&oacute;digo que raspaste</td>
                                                          <td align="center">Tipo de Tarjeta</td>
                                                        </tr>
                                                        <tr>
                                                          <td align="center" width="72%"><input name="c1" id="c1" size="4" maxlength="4" class="textLogin2" type="text" />
                                                            -
                                                            <input name="c2" id="c2" size="4" maxlength="4" class="textLogin2" type="text" />
                                                            -
                                                            <input name="c3" id="c3" size="4" maxlength="4" class="textLogin2" type="text" />
                                                            -
                                                            <input name="c4" id="c4" size="4" maxlength="4" class="textLogin2" type="text" /></td>
                                                          <td align="center" width="28%"><input name="c5" id="c5" size="10" maxlength="4" class="textLogin3" type="text" />
                                                              <label></label></td>
                                                        </tr>
                                                      </tbody>
                                                    </table>
									                <p>
									                  <input border="0" src="images/comprar.png" name="submit" width="158" height="52" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img123',/*url*/'images/comprar_on.png')" type="image">
									                </p>
									                <p class="Estilo1">  <font color="#0099FF" face="Verdana, Geneva, sans-serif"><span class="Estilo4">Atenci&oacute;n</span>: no env&iacute;e tarjetas falsas, usadas o que usted no sea de <strong>Venezuela</strong> de lo contrario su cuenta ser&aacute; baneada.</font></p>
									                <p></p>
								                  </center>
								                </form>
								              </div>
									          <p></p>
									          <p class="Estilo1"></p>
									          <span class="Estilo1"><font color="#0099FF" face="Verdana, Geneva, sans-serif"> 5. A los pocos minutos deben ser 
									            recargados tus coins, no envies 2 veces la misma tarjeta solo ten 
									            paciencia a que te recarguen, las tarjetas malas o usadas no proceden.</font><font color="#FFFF00"></font></span></td>
								          </tr>
								        </tbody>
								      </table></td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top"><center><img src="/images/EJEMPLO.png" /></center></td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											  <tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top"><center><img src="/images/preview.png" /></center></td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											  <tr>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
<?
$filhodaputa = array(";","'","\"","*","uninic","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>