<?
session_start();
include "secure/config.php";
?>
<?
if($_SESSION['UGradeID'] != 255)
{
	echo "<font color='red' size='40'><center>No Tienes Permiso By Faragon</center>";
}else{
$id = $_GET['id'];
$delete = "DELETE FROM LogItems WHERE id ='".$id."'";
mssql_query($delete);
header("Location: log.php");
}
?>