<p><strong><font size="6">Baneado</font></strong><br>
  <br>
El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP.<br>
</p>
<hr>
<p> 
  <em>Has sido baneado temporalmente de GalaxiaGamers Gunz por el equipo de staff de GalaxiaGamers Gunz.</em></p>
