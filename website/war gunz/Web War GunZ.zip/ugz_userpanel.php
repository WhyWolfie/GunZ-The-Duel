<?php
include "secure/banned.php";
include "secure/banneduser.php";
include "secure/checkcookie.php";
include "secure/title.php";
include 'counter/counter.php';
include 'secure/anti_injectx.php';
include 'secure/inject.php';
?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="15">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/userpanel.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="-14" colspan="3"></td>
										</tr>
										<tr>
											<td width="3">
											</td>
											<td width="141">
											&nbsp;</td>
											<td width="287">
											&nbsp;</td>
										</tr>
										<tr>
											<td width="3" rowspan="6">
											</td>
											
											<div align="center">
												<table border="0" style="border-collapse: collapse" width="141" height="100%">
<?
echo '  <font face="Arial" color="#ffffff">My Personagens:</font>';
        $query = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0 ORDER BY CharNum ASC");
        if ( mssql_num_rows($query) < 1 ){
        echo '<font face="Arial" color="#ff0000"><br>You have no character yet. Create one</br>';
        }else{

        echo '
        <table border="1" style="border-collapse: collapse" width="95%" id="table1">
	    <tr>
		<td><font face="Arial" color="#ffffff">Nome</font></td>
		<td><font face="Arial" color="#ffffff">Lvl</font></td>
		<td><font face="Arial" color="#ffffff">Experiencia</font></td>
                <td><font face="Arial" color="#ffffff">Bounty</font></td>
                <td><font face="Arial" color="#ffffff">Wins / Loses</font></td>
	    </tr>';

        $i = 1;
        while ( $i <= mssql_num_rows($query) ){
        $chars = mssql_fetch_assoc($query);

        echo '<tr>
		<td><font face="Arial" color="#ffffff">'.FormatCharName($chars['CID']).'</font></td>
		<td><font face="Arial" color="#ffffff">'.$chars['Level'].'</font></td>
		<td><font face="Arial" color="#ffffff">'.$chars['XP'].'</font></td>
        <td><font face="Arial" color="#ffffff">'.$chars['BP'].'</font></td>
		<td><font face="Arial" color="#ffffff">'.GetKDRatio($chars['KillCount'], $chars['DeathCount']).'</font></td>
	    </tr>';

        $i++;
        }
        echo '</table>';
        }
        echo'</br>
      

        <font face="Arial" color="#ffffff">My Clans:<br />
        <table border="1" style="border-collapse: collapse" width="95%" id="table1">
	    <tr>
                <td><font face="Arial" color="#ffffff">Clan Picture</font></td>
                <td><font face="Arial" color="#ffffff">Nome do Clan</font></td>
		<td><font face="Arial" color="#ffffff">Lider do Clan</font></td>
		<td><font face="Arial" color="#ffffff">Clan Rank</font></td>

	    </tr>';
        $query2 = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."' ORDER BY CharNum ASC");
        if (mssql_num_rows($query2) > 0){
        while ($chars2 = mssql_fetch_assoc($query2)){


        $clanq = mssql_query_logged("SELECT * FROM ClanMember WHERE CID = '".$chars2['CID']."'");
            if (mssql_num_rows($clanq) != 0){
            $clanq2 = mssql_fetch_assoc($clanq);
                if($clanq2['Grade'] == 9){
                $rango = "Member  ";
                $admin = "No";
                }elseif($clanq2['Grade'] == 2){
                $rango = "Admin";
                $admin = "No";
                }elseif($clanq2['Grade'] == 1){
                $rango = "Master";
                $clid = $clanq2['CLID'] + 1990;
                $cid = $clanq2['CID'] + 2000;

                }else{
                $rango = "Error";
                }
            $claninfoq = mssql_query_logged("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
            $claninfo = mssql_fetch_assoc($claninfoq);

            $emblemurl = $claninfo['EmblemUrl'];
            if ($emblemurl == ''){
                $emblemurl = '<IMG SRC="images/no_emblem.png" WIDTH=50 HEIGHT=50>';
            }else{
                $emblemurl = '<img width="50" height="50" src="'.$emblemurl.'">';
                }

                echo '<tr>
                <td align="center" valign="center">'.$emblemurl.'</td>
                <td><font face="Arial" color="#ffffff">'.$claninfo['Name'].'</font></td>
		        <td><font face="Arial" color="#ffffff">'.FormatCharName($chars2['CID']).'</font></td>
		        <td><font face="Arial" color="#ffffff">'.$rango.'</font></td>
             
	           </tr> ';
                }
            }
        }
if($clanq2['Grade'] == 1){
echo '
 <table border="1" style="border-collapse: collapse" width="95%" id="table3">
 <br /></tr>';
}
?>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>


	
