<?php
//NighT GamerZ Spain Config
$link = mssql_connect("LGV-473151E9-16\SQLEXPRESS","sa","tiago123");
mssql_select_db("WarGunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'LGV-473151E9-16\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = 'tiago123'; //Your DB Password 
$DB = 'WarGunzDB'; //Your GunZ DB 


?>