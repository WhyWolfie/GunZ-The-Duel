<script language="javascript" type="text/javascript">
location.replace("www")
</script>

<!-- <meta http-equiv="refresh" content="5; URL=www" /> -->


<!-- <h1>VOC� SER� REDIRECIONADO PARA O SITE EM 5 SEGUNDOS</h1> -->