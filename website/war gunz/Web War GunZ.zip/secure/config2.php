<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("TIAGO-PC\SQLEXPRESS","sa","tiago123");
mssql_select_db("UnitedDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'TIAGO-PC\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'tiago123';
$DB = 'UnitedDB';
?>