<?
if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 242 and !$_SESSION['AID'] == ""){
    $userid = $_SESSION['UserID'];
    $aid = $_SESSION['AID'];
    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid' AND AID = '$aid'");
    $data = mssql_fetch_assoc($res);
    if(!$data['UGradeID'] == $_SESSION['UGradeID']){
        echo "Admin Session Invalid";
    }
}else{
    die("You do not have permission to perform this action");
}
?>