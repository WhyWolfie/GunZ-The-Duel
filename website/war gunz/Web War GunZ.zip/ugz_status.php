<? 
include 'secure/anti_injectx.php';
include 'secure/inject.php';

?>
<?

function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Pragma" content="no-cache" />
</head><style type="text/css">
@import "final.css";
</style>
<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'War Gunz';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;� $name: <font style='color: #00FF00'>Online</font>";
        }
        else
        {
            echo "&nbsp;� $name: <font style='color: #00FF00'>Online</font>";
            fclose($fp);
        }
    }
    ?>
&nbsp;� Jogadores Online:<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
    $max = $srv['MaxPlayer'];
    $porcentagem = PorcentPlayers($srv['CurrPlayer'], $srv['MaxPlayer']);
}
?> <font style='color: #00FF00'><?=$servercount?></font>/<?=$max?> - <?=$porcentagem?></li>
    </strong>

�<font style='color: FFFFFFFFF'></font>� Recorde Online: 
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<font style='color: #00FF00'><?=$b['PlayerCount']?></font>
 	
									


&nbsp;<font style='color: FFFFFFFFF'>�</font> <?php 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Personagens: ".$num_rows."<n>";

?>

&nbsp;<font style='color: FFFFFFFFF'>�</font> <?php 
//Total Contas
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Contas: ".$num_rows."<n>";

?>

&nbsp;<font style='color: FFFFFFFFF'>�</font> <?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Clans: ".$num_rows."<n>";

?>