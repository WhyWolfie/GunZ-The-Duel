<?php
header("Location: http://www.wargunz.com/site/");
?>