
<?
//Criar Cl� By CAP


//ANTI BUG CL� FUNC
Function foder($str){


 $caracters = array("'", " ", "?", "�", "0x", "!", "^", "-", "*", "&", "@", "#", "�", "�", "+", "~", "<", ">", ":", ";", "�", "`", "%", "update", "select", "drop table", "delete table");
 $blank = "0";
return str_replace($caracters, $blank, $str);
}
?>
<?
if ($_SESSION['AID'] == ""){
    msgbox("Logue-se primeiro!","index.php?do=login");
    die();
 }
$q2chars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($q2chars) == 0 )
    {
 msgbox("Sem personagens.","index.php?do=criarcla");
    die();
 } 
?> 
<br /><div id="ststitle"><center><h2><font color=cyan>Criar Cl�</font></h2></center></div><br />
<font color=cyan>� </font>N�o Tente criar cl� com <font color=red>digitos proibidos,</font> se n�o o cl� ser� deletado.</br>
<font color=cyan>� </font>M�nimo <font color=red>4</font> letras.</br>
<font color=cyan>� </font>M�ximo <font color=red>10</font> letras.</br>
<br>
<br>
<div align="center">
<font color='white'>Dono do Cl�</font></br>
<form action="?do=criarcla" method="post">
<?php
$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0");
echo '<select name="CID">';
 if(mssql_num_rows($query)<>0){
   while($char = mssql_fetch_assoc($query)){
    echo '<option value="'.$char['CID'].'">';
     echo $char['Name'];
    echo '</option>';
   }
 }else{
   echo '<option></option>';
 }
echo '</select>';
?>
<br>
<br>
<font color='white'>Nome do Cl� </font><br>
<input name="NOME" type="text" class="Login" onkeyup="valid(this,'special')" onblur="valid(this,'special')" size="20" maxlength="10">
</br>
</br><input type="submit" class="logon" name="criaraf" value="Criar" />
</form>
<?php
if (isset($_POST['criaraf'])){
$NOME = clean($_POST['NOME']);
$CID = clean($_POST['CID']);


if(strlen($NOME) > 10){
            msgbox("Esse Nome muito grande, somente at� 10 letras","index.php?do=criarcla");
    die(); 
        }
if(strlen($NOME) < 4){
            msgbox("Esse nome � muito curto, coloque maior que 4 letras","index.php?do=criarcla");
    die(); 
        }
$lil = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$CID'");
$trin = mssql_query("SELECT Name FROM Clan WHERE Name = '$NOME'");
$otario = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$CID'");


if (mssql_num_rows($trin) >= 1){
msgbox("Cl� em uso","index.php");
    die(); 
        }
if (mssql_num_rows($lil) >= 1){
msgbox("Voc� j� possui um cl�.","index.php?do=criarcla");
    die(); 
        }
if (mssql_num_rows($otario) == 0 )
        {
 msgbox("Esse personargem pertence a outra conta.","index.php?do=criarcla");
    die();
 }
$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$NOME', '$CID', GETDATE())");
$res = mssql_query_logged("SELECT * FROM Clan(nolock) WHERE Name = '$NOME' AND MasterCID = '$CID'");
     $usr = mssql_fetch_assoc($res);
     $clid = $usr['CLID'];
$zuei = mssql_query("DELETE FROM ClanMember WHERE CLID = '$clid'");
mssql_query_logged("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$CID', 1, GETDATE())");
if($sql){
 msgbox("Cl� criado com sucesso!","index.php?do=criarcla");
    die(); 
}else{
 msgbox("Ocorreu um erro, reporte esse erro para o Dono do Jogo","index.php?do=criarcla");
    die(); 
}
}
?>
</div>
</br>
</br>

