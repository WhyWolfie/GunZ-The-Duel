
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/">&nbsp;</td>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/">
								<div align="center">
<?
//Comprar Jjang by SayntPark '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

$busca57 = mssql_query("SELECT EVCoins FROM Login WHERE AID = '$aid22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<span style="color:#00FF00; background: transparent url(http://tinyurl.com/outgum)"><b>Comprar Jjang</b></span></a></br><br>

<br><font color="#88h154a">Qual utilidade do jjang?</font><br>

Nada, apenas um adere�o para seu personagem.<br><br>

<font color="#00CD00">Qual o valor?</font><br>

Para ter um jjang voc� gastar� 30 Ev coins.<br><br>

<font color="#FF34B3">Qual e a cor do jjang ?</font><br>

O jjang tem a cor : <font color="#4EEE94">Jjang</font><br><br>

<a href="?do=jjang&step=1">Comprar Jjang</a><br><br>

Voce tem um total de <?=$busca58[0]?>
Ev Coins , apos fazer essa compra ira sobrar 
<?=$busca58[0]-30
?>
<?
}else{

$buscanome = "SELECT EVCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 30) 
{
	echo "Desculpe, seus EVCoins n�o s�o suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE AID = '$aid22'");
mssql_query("update Login set EVCoins=EVCoins-30 where AID='$aid22'");
echo "Compra realizada, relogue.<br>";
}


}
}

$date = date("d-m-y - H:i:s");
$logfile = fopen("Logs Jjang.txt","a+");
$logtext = "$date - IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou Jjang. \r\n";
fputs($logfile, $logtext);
fclose($logfile);


?>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>