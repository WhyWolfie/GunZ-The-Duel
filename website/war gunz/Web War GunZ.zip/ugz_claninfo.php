<? 
include 'secure/anti_injectx.php';
include 'secure/inject.php';
?>
<?
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan Does not Exist","index.php");
exit();
}

$clid = $clan->CLID;
?> 
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="490" bordercolor="#000000">
								<tr>
									<td background="image/content_bar.jpg" height="24" style="background-image: url('image/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Clan Info</font></b></td>
								</tr>

                          <tr>
                            <td bgcolor="#232129" height="35" class="Estilo2" align="center">
                               <?=$clan->Name?></br>
&nbsp;</br>
<img src="<?=($clan->EmblemUrl == "") ? "images/no_emblem.png" : $clan->EmblemUrl?>" width="100" height="100" BORDER=5 ></br>
&nbsp;</td>
</tr>
                          <tr>
                            <td bgcolor="#232122" class="Estilo1" align="center" valign="top">
<table width="447" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top">

<table border="2" style="border-collapse: collapse" width="447" height="100%">
<div align="center">
&nbsp;
                         <tr>			    
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Rank: </td>
                                    <td align="left" class="estilo1"><?=$clan->Ranking?></td>

                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Pontos: </td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Win:</td>
                                    <td align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Losses:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Draw:</td>
                                    <td align="left" class="estilo1"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Criado:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">&nbsp;&nbsp;&nbsp;Membros:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="448" border="0" cellpadding="0" cellspacing="0">
&nbsp;
                                  <tr>
                                    <td align="center" class="estilo1"><u>Char</u></td>
                                    <td align="center" class="estilo1"><u>Rank</u></td>
                                    <td align="center" class="estilo1"><u>Entrou</u></td>
                                    <td align="center" class="estilo1"><u>Pontos</u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                            </table></td>
                          </tr>
</table>
	</div>
						</td>
					</tr>
				</table>
			