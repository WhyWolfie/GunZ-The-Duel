<?

include 'secure/anti_injectx.php';
include 'secure/inject.php';

?>
<span style="color:#CD2990; background: transparent url(http://tinyurl.com/outgum)">Name color que troca de cor e Gradientes</b></span></a><br><br>
<?
//Name color By:AimSoled


// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}


$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
Voc� ir� gastar <font color=red>100</font> WGCoins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="3">Troca De Cor 1</option>
<option value="10">Troca De Cor 2</option>
<option value="8">Gradiente Preto 3</option>
<option value="9">Gradiente Azul Claro 4</option>
</select>
<br><br>
<font color="#00EE00"> Troca De Cor 1 -> Verde,Vermelho,Branco,Rosa,Azul,roxo.</font><br><br>
<font color="#FF0000"> Troca De Cor 2 -> Vermelho,Preto</font><br><br>
<font color="#4F4F4F"> Gradiente Preto 3 -> Gradiente Preto</font><br><br>
<font color="#3A5FCD"> Gradiente Azul Claro 4 -> Gradiente Azul Claro</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
<br>
<br>
<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Voc� comprou Nick Color com sucesso";
die ();  

}

$buscanome = "SELECT WGCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 100) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  WGCoins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set WGCoins=UGCoins -100 where AID='$aid22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Obrigado !!";
}
}
}






?>