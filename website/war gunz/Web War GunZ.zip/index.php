<?php
include "secure/config.php";
include "secure/_functions.php";
include "secure/inject.php";
include "secure/banned.php";
include "secure/banneduser.php";
include "secure/checkcookie.php";
include "secure/title.php";
include 'secure/sqlcheck.php';
include 'secure/sql_check.php';
include 'secure/anti_injectx.php';




if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("ugz_" . $_GET['do'] . ".php")) {
        include "ugz_" . $_GET['do'] . ".php";
	}
} }
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.ico" type="image/ico"/>
<title>War GunZ - Web<?=$pagetitle?></title>
<link rel="stylesheet" type="text/css" href="image/style.css">
<link rel="stylesheet" type="text/css" href="frontpage.css" />
<script type="text/javascript">var _siteRoot='index.php',_root='index.php';</script>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
<script type='text/javascript' src='js/presentationCycle.js'></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/nav.js"></script>
<script language="JavaScript" src="js/functions.js"> </script>
<link rel="shortcut icon" href="favicons.ico" />
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg.png);
}
-->
</style></head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" background="http://i47.tinypic.com/x2vs4i.jpg">
<div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr><td bgcolor="">
<div id="scroller">
	<div class="l"></div>
  <div class="c" >
	<marquee color="#00FFFF" scrollamount="0"><? include "ugz_status.php" ?></marquee>
	</div>
	<div class="r"></div>
</div>
</td>
</tr>
<div align="center">
	<table border="0" style="border-collapse: collapse" width="900" id="table1">


	
</div>
</td>
</tr>
		<tr>
			

<img src="images/war.jpg" width="913" height="250" alt="Tamanho original" border="0"> 
		</tr>
		<tr>
<td bgcolor="#000000">
<ul class="topnav">  
     <li><a href="index.php">In�cio</a></li>  
     <li>  
      <li><a href="index.php?do=register">Registro</a></li>      
     </li>  
     <li>  
         <a href="index.php?do=download">Download</a>  
         <ul class="subnav">  
             <li><a href="index.php?do=downloads&expand=1&sub=client">War GunZ</a></li>  
              
         </ul>  
     <li><a href="index.php?do=ranking&sub=individual&expand=1">Ranking</a>
         <ul class="subnav">  
             <li><a href="index.php?do=ranking&sub=individual&expand=1">Player Ranking</a></li>  
             <li><a href="index.php?do=ranking&sub=clan&expand=1">Cl� Ranking</a></li>
  
         </ul>  
       </li>  

     <li><a href="index.php?do=cashshop&sub=listallitems&expand=1&type=1">Lojas</a>
         <ul class="subnav">  
             <li><a href="index.php?do=cashshop&sub=listallitems&expand=1&type=1">Loja Donater</a></li>  
             <li><a href="index.php?do=shopcoins&sub=listallitems&expand=1&type=1">Loja Evento</a></li> 
             
           

         </ul>
<li><a href="index.php?do=emblemas">Painel de controle</a>
         <ul class="subnav">  
             <li><a href=UserPainel>Painel Geral</a></li>
             
               
         </ul> </li> 

     <li><a href="doacao/index.html">Donater</a></li>
     <li><a href="index.php?do=equipe">Equipe WG</a></li> 
     <li><a href="index.php?do=regras"><font color="pink">Regras Do Server!</font></a></li> 
     <li><a href="http://www.wargunz.com/forum/">Forum</a></li>
     
     
     
     
  
 </ul></td></tr><tr>
			<td background="image/main_bg.png">
			
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("ugz_" . $_GET['do'] . ".php")) {
        					include "ugz_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					  <td width="208" valign="top">
					    <div align="center">
                                                                                           <div align="center"><? include "ugz_ilogin.php" ?><br><? include "ugz_playerranking.php" ?><br>
<span style="color:black"></span><a href="index.php?do=donate"><img src="images/donate.png"><a/>
 <br><span style="color:black"></span><a/>
<br>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<br>

					</div>				  
					<br>
					<br>
					<div align="center">
                    </div></td>
					<td width="481" valign="top">
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("ugz_" . $_GET['do'] . ".php")) {
							    include "ugz_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "ugz_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>
					<td width="206" valign="top">
					<div align="center"><? include "ugz_clanranking.php" ?>
					</div>
					<br>
					<div align="center">
					<? include "ugz_cw.php" ?>
					</div>
                                        <br>
					<div align="center">

	<? include "ugz_trailer.php" ?><?
                                                           
                                               if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254){
                                             ?> <? include "ugz_255adminindex.php" ?>
                                                                                <?
                                                                                 }
                                                                                 ?>
	
			
					
					</div>
					<br>
				  <p></td>
				  <td width="12">&nbsp;</td>
				</tr>
				</table>
<tr>



</td>
</tr>

		                        <td></td>                        <td></td>				</tr>				</table>
</div>
</body>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> 
</script>

<div align="center" style="z-index:9;visibility:visible;"></div><style>HTML,BODY{cursor: url("http://i44.tinypic.com/viaah.png"), url("http://i44.tinypic.com/viaah.png"), auto;}</style>

<a style="display:scroll;position:fixed;bottom:5px;right:5px;" href="index.php?do=donate" title="Fazer uma doa��o"><img src="http://4.bp.blogspot.com/--n-zS_Eimmk/TwyRTjmGyII/AAAAAAAAANI/vlJgWYKl_lQ/s1600/aaaaaaaaa.png"/></a>

<center><font color="white"><p>Copyright &copy; 2013-2014 War GunZ Todos os direitos reservados.<br />
 War GunZ &eacute; uma marca registrada pela <em><u><b>Maiet Entertainment.</u></b></em><br />
  War GunZ um servidor totalmente gratuito e independente, as doa&ccedil;&otilde;es<br />
  s&atilde;o utilizadas para cobrir os gastos do servido

