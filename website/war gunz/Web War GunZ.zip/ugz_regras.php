<center><b><u><h2><blink>Regras</blink><p></h2></b></u><p><br>
 Obede�a a todas as regras do jogo para n�o ser punido/prejudicado.</center>
<p><br>
<p>
<b><center>Regras do Servidor</center></b>
<p><br>
Siga todas as regras do servidor para n�o correr o risco de ser punido.
<p>
1 - Se passar por Staff, Hacker, divulgar Programas, outros servidores ou amea�ar algu�m com falsas informa�oes.
<p><b>Puni��o</b>: 07 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.
<p>
2 - Hackear, auxiliar Hack, divulgar Sites com Keylogger, Trojan, V�rus.
<p><b>Puni��o</b>: Bloqueio permanente de conta.
<p>
3 - Utilizar-se de programas ilegais Ex: BOT.
<p><b>Puni��o</b>: Bloqueio permanente das contas dos envolvidos.
<p>
4 - Praticar Swap, Free-kill ou algo do g�nero.
<p><b>Puni��o</b>: Bloqueio permanente das contas dos envolvidos.
<p>
5 - Oferecer ou aceitar Programas ilegais.
<p><b>Puni��o</b>: Bloqueio permanente das contas dos envolvidos.
<p>
6 - N�o � permitido o aproveitamento de BUGs do jogo e/ou divulga��o de Bugs a outros players. Qualquer Player que tirar proveito ser� considerado um Hacker. � obrigat�rio ao Jogador informar a Staff sobre qualquer anormalidade no Knight GunZ que possa beneficiar algu�m de forma incorreta e injusta.
<p><b>Puni��o</b>: Bloqueio permanente de conta.
<p>
7 - Usar Glithes de maneira que traga vantagem ou prejudique outro Jogador.
<p><b>Puni��o</b>: Bloqueio permanente de conta.
<p>
8 - Ofensa Pesada a outro Usu�rio, que atinjam diretamente a pessoa, difamando ascendentes, descendentes, etc.
<p><b>Puni��o</b>: 05 dias de Bloqueio de conta, podendo ser cumulativo.
<p>
9 - Ofensa Leve, que atinjam diretamente a pessoa, atormentar, aborrecer ou perseguir outro usu�rio. Diz respeito tamb�m a linguagens obscenas, pequenos palavr�es. Palavras, sinais, nomes, gestos obscenos.
<p><b>Puni��o</b>: 05 dias de Bloqueio de Chat, podendo ser cumulativo. 
<p>OBS: Em casos de Ofensa Leve, dentro das Salas de PvP os casos ser�o desconsiderados.
<p>
10 - Ofensa, Preconceito, Discrimina��o Racial e Religiosa ou Xenofobia que atinjam diretamente a pessoa
<p><b>Puni��o</b>:05 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.

<p>11 - Nome de personagem de apelo sexual e palavras de baixo cal�o.
<p><b>Puni��o</b>: Personagem apagado pela Staff. 
<p>OBS: Esta Regra tamb�m se aplica aos individual nos quais, o nome venha a constituir uma palavra de baixo cal�o, mesmo se implicitamente ou em outro Idioma.
<p>
12 - Difama��o (declara��o p�blica) no F�rum, Comunidade ou em Jogo, forjar algo que prejudique publicamente a imagem de uma pessoa ou formalizar uma den�ncia para prejudicar outro player (forjar den�ncia).
<p><b>Puni��o</b>: 30 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.
<p>
13 - Amea�ar a integridade F�sica de outro Player ou Staff. Amea�ar outra pessoa declarando que vai ferir ou matar a pessoa (amea�as fora das quest�es de jogo).
<p><b>Puni��o</b>: 30 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.
<p>
14 - Atormentar, perseguir, amea�ar, ou causar afli��o e/ou aten��o indesejada a outros jogadores e/ou utilizar-se de linguagem obscena.
<p><b>Puni��o</b>: 05 dias de Bloqueio de conta.
<p>
15 - Insistir em contestar julgamentos referentes a casos j� encerrados pela Staff.
<p><b>Puni��o</b>: 07 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta. 
<p>OBS: Usu�rio n�o envolvidos em Den�ncia assumindo um papel de Advogado do r�u, tamb�m receber�o 07 dias de Bloqueio em sua conta ou a mesma pena aplicada ao infrator, caso n�o prove a inoc�ncia do mesmo dentro de um prazo estipulado pela Staff.
<p>
16 - Dizer-se amigo, parente ou �ntimo de qualquer membro da Staff, dizer ser ex-membro da Staff ou dar tal impress�o para tirar proveito, provocar, ou se proteger.
<p><b>Puni��o</b>: 03 dias de Bloqueio de conta.
<p>
17 - Ofensas pesadas a fim de atingir aos membros da Staff
<p><b>Puni��o</b>: 20 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.
<p>
18 - � proibido se passar por um membro da Equipe KnightGunz ou, sendo membro, revelar sua identidade como jogador, ou deixar transparecer algo do g�nero. Em seu nome s�o proibidos: [GM], [GM-H], [GM-C], [GM-D], Test, Tester, [Admin], [MOD] ou qualquer termo que simbolize a Equipe KnightGunz, seja do jogo, seja do Forum ou Comunidade.
<p><b>Puni��o</b>: Bloqueio permanente de conta e Bloqueio de outras contas, mediante investiga��o.
<p>
19 - Exigir itens ou Exp de algum membro da Staff, isso inclui exigir a entre�a das doa��es que ainda esteja no prazo determinado de 48 horas.
<p><b>Puni��o</b>: 1 dia de Bloqueio de conta.
<p>
20 - Ficar especulando sobre informa��es pessoais dos membros da Staff, ficar perguntando identidade (nome, MSN pessoal, etc..), ficar perguntando dados pessoais ou sabendo estas informa��es divulga-las etc.
<p><b>Puni��o</b>: 05 dias de bloqueio de conta, podendo acarretar em Bloqueio permanente da conta
<p>
21 - Fazer-se passar por outro jogador, para tirar vantagens de amigos ou difamar o mesmo, isso inclui plagio de nick.
<p><b>Puni��o</b>: Bloqueio permanente da conta.
<p>
22 - � proibida a divulga��o das informa��es pessoais (nome, telefone, etc) de um jogador sem o seu consentimento.
<p><b>Puni��o</b>: Bloqueio permanente de conta.
<p>
23 - Abuso de habilidades, de modo que prejudique a jogabilidade de outro usu�rio.
<p><b>Puni��o</b>: 02 dias de Bloqueio de conta.
<p>
24 - Usar repetidamente a mesma mensagem, ou semelhante (mais de 4 vezes) no Lobby, Sala de Espera, No jogo, ou qualquer outro chat.
<p><b>Puni��o</b>: 05 dias Bloqueio do Chat
<p>
25 - � proibido fazer propaganda de produtos que n�o pertencem ao jogo. Isso inclui bens materiais e propagandas sobre outros jogos.
<p><b>Puni��o</b>: Bloqueio permanente da conta.
<p>
26 - Toda esp�cie de an�ncio ilegal, fazendo propaganda de outros servidores, de sites inadequados, e an�ncios enganosos.
<p><b>Puni��o</b>: Bloqueio permanente de conta.
<p>
27 - Falso Com�rcio, como estar anunciando um item e vendendo outro ou oferecer item que seja diferente do que foi ofertado, que esteja visivelmente induzindo a uma compra ou troca errada! Mediante comprova��o com Screen Shot com a conversa da negocia��o ou com o t�tulo da loja e o item que foi ofertado no lugar do que deveria ser, ou flagrante da Staff.
<p><b>Puni��o</b>: 05 dias de Bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.
<p>
28 - � proibido negociar dinheiro real, bens materiais ou contas de jogo no Knight GunZ. A negocia��o de Itens pode ser feita contando que voc� saiba com quem est� fazendo a negocia��o para evitar poss�veis roubos. A Staff n�o se responsabiliza.
<p><b>Puni��o</b>: Bloqueio permanente de conta.

<p>29 - Utilizar imagem indevida para o emblema do cl�, imagem que outro cl� esteja usando, ou criar nome de um cl� que seja absurdamente parecido. Ser� necess�rio 3 caracteres consider�veis para diferenciar os nomes.
<p><b>Puni��o</b>: Cl� desfeito e seu L�der ter� Bloqueio de conta por 03 dias.
<p>
30 - Jogadores que estiverem lagados ser�o kikados da sala para n�o atrapalhar a jogabilidade dos outros jogadores.
<p><b>Puni��o</b>: Kick da Sala!
<p>
31 - Ser� proibida qualquer tipo de troca de Itens de Eventos, portanto escolha bem o Item dispon�vel para receber para n�o haver transtornos.
<p><b>Puni��o</b>: Se insitir na troca ter� seu invent�rio deletado (Remo��o de todos Itens da conta).
<p>
32 - Antes de Comprar os Itens, seja eles da Loja Donate ou da Loja Event, verifique se � realmente o Item que voc� quer comprar. A troca de Itens n�o � permitida, portando tome cuidado antes de comprar o Item.
<p><b>Puni��o</b>: Se insitir na troca ter� seu invent�rio deletado (Remo��o de todos Itens da conta).
<p>
33 - N�o aceite qualquer Item Enviado por estranhos ou por algu�m que simplesmente estava oferecendo Itens. Essas pessoas podem ter descoberto algum Bug no site e tenha abusado deste Bug a afim de conseguir vantagem.
<p><b>Puni��o</b>: A conta de quem enviou ser� banida e a de quem recebeu perder� todos os Itens.
<p><br>


			<center><a href="index.php?do=index">Voltar</a></center>