<div align="center">

<b><h3>EQUIPE</b></h3>

<br><br>

<font color=Cyan>Administra��o</font><br><br>

<font color=Cyan>AimSoled</font><br><br>
<font color=Cyan>Roberto</font><br><br>
<font color=Cyan>Cristian</font><br><br>



</font>

</center>

					<td width="206" valign="top">
					
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>