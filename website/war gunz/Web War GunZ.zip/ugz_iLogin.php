
<? include 'secure/inject.php'; ?>

<?
if ($_SESSION['AID'] == ""){
?>
<style type="text/css">
<!--
.style2 {font-size: xx-small}
-->
</style>

<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account.png" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<form method="POST" action="index.php?do=login&header=1" name="login">
									<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="4">&nbsp;</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="text" name="userid" size="14" style="background-image: url('images/usernamebg.jpg'); background-position: left center" class="login"></td>
											<td width="62" rowspan="2">
											<p align="center">
											<input type="submit" value="Login" name="submit"></td>
											<td width="8" rowspan="2">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="password" name="pasw" size="14" style="background-image: url('images/passwordbg.jpg'); background-position: left center" class="login" id="input"></td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">
											<input type="checkbox" name="cookie" value="ON" checked>Manter-me logado</td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2" bgcolor="#1A1A1A">&nbsp;
											</td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="3" bgcolor="#1A1A1A">
											<span style="font-size: 11pt">&nbsp;
											<a href="index.php?do=register">
											Registre-se!</a></span></td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="3" bgcolor="#1A1A1A">
											<span style="font-size: 11pt">&nbsp;
											<a href="index.php?do=recuperar">
											Recuperar Conta.</a></span></td>
											<td width="8">&nbsp;
											</td>
										</tr>
									</table>
								</form>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
						</table>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
?>

<div align="center">
<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account6M.gif" height="30" width="195">&nbsp;</td>
						  </tr>
							<tr>
								<td background="images/menu_bg.jpg">
																	<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<font size="2" face="Tahoma">
											Bem Vindo, <?=$_SESSION['UserID']?> !</font></td>
										</tr>
<tr>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										<tr>
											<td width="8" rowspan="5">&nbsp;</td>
											<td width="181">&nbsp;&nbsp; <a href="index.php?do=player">
<font style='color: #551A8B'><b>� </b></font> <font color="	Purple2">Painel de Jogador - <img src="http://www.freeiconsweb.com/Icons/16x16_New_icons/New_icons_24.gif" alt="Exclusivo" /></font></a>
</a></td></td>									<tr>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										  <td>&nbsp;&nbsp; <a href="index.php?do=login&amp;action=logout&amp;header=1">Sair?</a></td>
										  </tr>
										<tr>
										</tr>

										<tr>
											<td colspan="2">
											<div align="center">
												<table border="0" width="171" height="169" style="border-collapse: collapse; background-image: url('images/accountframe.jpg')">
													<tr>
														<td height="29" width="12">&nbsp;</td>
														<td height="29" width="155" colspan="2">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url(''); background-repeat: no-repeat; background-position-x: left">
														<p align=""><b><span style="font-size: 7pt">�ltima data de conex�o<br>
														<b><?=$d['LastConnDate']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
										                                <td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/wgcoins.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['WGCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
												  </tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_evcoins98Z.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['EVCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url(''); background-repeat: no-repeat; background-position-x: left">
														<a href="/UserPainel/Index.php">
														<img border="0" src="images/af_editaccountinfo.jpg" width="138" height="22" id="img3" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img3',/*url*/'images/af_editaccountinfo_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12">&nbsp;</td>
														<td width="155" colspan="2">
														<p align="center">														</td>
													</tr>
												</table>
											</div>											</td>
										</tr>
										</table>
								
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
						  </tr>
						</table>

<?
}
?>