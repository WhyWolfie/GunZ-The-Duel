<?
re_dir("index.php?do=downloads&sub=client&expand=1");
die();
?>