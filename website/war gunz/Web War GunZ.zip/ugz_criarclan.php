<? 
include 'secure/anti_injectx.php';
include 'secure/inject.php';
?>
<?
//Criar Clan Edi��o Shockwave

//ANTI BUG CLAN FUNC
Function foder($str){

	$caracters = array("'", " ", "?", "�", "0x", "!", "^", "-", "*", "&", "@", "#", "�", "�", "+", "~", "<", ">", ":", ";", "�", "`", "%", "update", "select", "drop table", "delete table");
	$blank = "0";
return str_replace($caracters, $blank, $str);
}
?>
<?
if ($_SESSION['AID'] == ""){
    msgbox("Logue-se primeiro!","index.php");
    die();
	}
$q2chars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($q2chars) == 0 )
    {
	msgbox("Sem personagens.","index.php");
    die();
	} 
?> 
<div align="center">
<br /><div id="ststitle">Criar Cl&atilde;:</div><br />
N�o Tente criar clan com digitos proibidos, Seja mais cuidadoso com sua conta.</br>
<font color='white'>Personagem a ser dono do cl&atilde;:</font></br>
<form action="index.php?do=criarclan" method="post">
<?php
$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0");
echo '<select name="CID">';
 if(mssql_num_rows($query)<>0){
   while($char = mssql_fetch_assoc($query)){
    echo '<option value="'.$char['CID'].'">';
     echo $char['Name'];
    echo '</option>';
   }
 }else{
   echo '<option></option>';
 }
echo '</select>';
?>
<font color='white'>Nome do cl&atilde;</font><input name="NOME" type="text" class="Login" onkeyup="valid(this,'special')" onblur="valid(this,'special')" size="20" maxlength="10">
</br>
</br><input type="submit" class="logon" name="criaraf" value="Criar" />
</form>
<?php
if (isset($_POST['criaraf'])){
$NOME = clean($_POST['NOME']);
$CID = clean($_POST['CID']);

if(strlen($NOME) > 10){
            msgbox("Esse Nome muito grande, somente ate 10 letras","index.php");
    die(); 
        }
if(strlen($NOME) < 4){
            msgbox("Esse Nome muito curto, coloque maior que 4 letras","index.php");
    die(); 
        }
$lil = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$CID'");
$trin = mssql_query("SELECT Name FROM Clan WHERE Name = '$NOME'");
$otario = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$CID'");

if (mssql_num_rows($trin) >= 1){
msgbox("Clan em uso","index.php");
    die(); 
        }
if (mssql_num_rows($lil) >= 1){
msgbox("Ja possui um clan","index.php");
    die(); 
        }
if (mssql_num_rows($otario) == 0 )
        {
	msgbox("Esse Personargem pertence a outra conta.","index.php");
    die();
	}
$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$NOME', '$CID', GETDATE())");
$res = mssql_query_logged("SELECT * FROM Clan(nolock) WHERE Name = '$NOME' AND MasterCID = '$CID'");
	    $usr = mssql_fetch_assoc($res);
	    $clid = $usr['CLID'];
$zuei = mssql_query("DELETE FROM ClanMember WHERE CLID = '$clid'");
mssql_query_logged("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$CID', 1, GETDATE())");
if($sql){
	msgbox("Clan Criado Com sucesso!","index.php");
    die(); 
}else{
	msgbox("Ocorreu um erro, Reporte esse Erro para Algum Administrador ou GameMaster, prefirenciar reportar para <b>�M�t�d�r�</b> !","index.php");
    die(); 
}
}
?>
</div>
</br>
</br>