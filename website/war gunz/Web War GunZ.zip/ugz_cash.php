    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								
								<div align="center">

									<table border="0" style="border-collapse: collapse" width="454" height="100%">
									
										<tr>
											<td width="12" colspan="2"></td>
										</tr>

										<tr>
											<td width="449" colspan="2">
											&nbsp;</td>
										</tr>
										<tr>
<center>
<b><font color="#FFFF00">Obrigado por olhar a pagina de doa��es.<br>Planos disponiveis :</font><br><br>

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="34C9552B7D7D5B41143F5FADCF921797" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
15 Cash - 10Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="234E2D9DE4E43C9AA4BF6F864499E052" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
30 Cash - 20Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="15B543E49090F0A774139FB678EBB43E" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
45 Cash - 30Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="79B9F8F70A0A9027745B1F86CF773800" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
60 Cash - 40Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="5B8FDC03ABABA299947ECF9973FA29DC" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
75 Cash - 50Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="7121B5BAFBFBB16444915F8AAD12827E" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
90 Cash - 60Reais

<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<!-- N�O EDITE OS COMANDOS DAS LINHAS ABAIXO -->
<input type="hidden" name="code" value="91BCCB33AAAA25122484FF8C118673AD" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/99x61-comprar-laranja-assina.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
105 - 70Reais<p><br><br>

<font color="#FFFF00">
United Gunz e um servidor totalmente independente, as doa��es sao para cobrir os gastos gastados no servidor. Para receber Seus Cash mande seu Login - nick do personagem- quantidade de cash comprada - email - foto do comprovante para vinicius.silva.44@hotmail.com
</b>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>

