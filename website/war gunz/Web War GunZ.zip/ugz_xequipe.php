<?php
include 'secure/antisql.php';
include 'secure/anti_inject.php';
include 'secure/anti_injectx.php';
include "secure/banned.php";
include "secure/bannedip.php";
include "secure/banneduser.php";
include 'secure/inject.php';
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
<span><h1><font color=cyan>
Informa��es
</font></span></h1>

<br>
<span><h2>
Contatos e Redes sociais:
</span></h2>
 <a href="" target="_blank"><img src="icones/facebook.png" width="30" height="30"></a></a></a>



</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

