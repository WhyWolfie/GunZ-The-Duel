<?php
//Cod By>CICO
include "secure/config.php";
$res = mssql_query("SELECT WGCoins, EVCoins, UserID FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
$sql = mssql_query("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$r = mssql_fetch_assoc($sql);
$coins_resetados = "Seus Coins foram resetados por ultrapassar o limite permitido.Entre em contato com ADM";
if ( $r['UGradeID'] == 255){
echo "";
}else{
if ( $d['WGCoins'] > "400"){
mssql_query("UPDATE Login SET RZCoins = '0', EVCoins = '0' WHERE AID = '".$_SESSION['AID']."'");
$file = 'logs/ips.txt' ;
$current = file_get_contents ( $file );
$current .= "IP: $REMOTE_ADDR - Login: ".$d['UserID']." " ;
file_put_contents ( $file , $current );
echo "
<center><table width='919' border='0' bgcolor='red'>
<tr><td>
<font size='2' face='Arial' color='white'><center>".$coins_resetados."</center></font>
</td></tr>
</table></center>";
}
elseif ( $d['EVCoins'] > "400"){
mssql_query("UPDATE Login SET WGCoins = '0', EVCoins = '0' WHERE AID = '".$_SESSION['AID']."'");

$file = 'logs/ips.txt' ;
$current = file_get_contents ( $file );
$current .= "IP: $REMOTE_ADDR - Login: ".$d['UserID']." " ;
file_put_contents ( $file , $current );
echo "
<center><table width='919' border='0' bgcolor='red'>
<tr><td>
<font size='2' face='Arial' color='white'><center>".$coins_resetados."</center></font>
</td></tr>
</table></center>";
}
}
?> 