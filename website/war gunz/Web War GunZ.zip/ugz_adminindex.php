<? include "secure/authadmin.php" ?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
					                        <br>
								<td background="images/adminpanel.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr><br>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="enviarevugg" name="do">Enviar EV Coins<br>
										
										
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Concluir" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
								</td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							