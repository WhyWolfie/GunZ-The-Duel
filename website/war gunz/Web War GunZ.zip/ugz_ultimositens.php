<script type="text/javascript" src="tooltip.js"></script>	
    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								
								<div align="center">

									<table border="0" style="border-collapse: collapse" width="454" height="100%">
									
										<tr>
											<td width="12" colspan="2"></td>
										</tr>

										<tr>
											<td width="449" colspan="2">
											&nbsp;</td>
										</tr>
										<tr>
<div align="center">
<b><font color="red">Itens Donater Mais Comprados</font><br><br>
<?
    $res = mssql_query("SELECT TOP 4 * FROM wGCash WHERE Opened = '1' ");

    ?>
	 <?
                                        while($item = mssql_fetch_assoc($res)) {
                                                ?>
												
<a title="<?=$item['CashPrice']?>" href="index.php?do=cashshop&sub=details&id=<?=$item['CSID']?>" target="_while" onMouseOver="toolTip('<b>Nome: </b> <?=$foda['Name']?> <br />  <b>Sexo:</b> <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Masculino";
                                                    break;
                                                    case "1";
                                                    $sex = "Feminino";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?> <br />  <b>Pre&ccedilo:</b> <?=$item['CashPrice']?> WGCoins <br />  <b>Level:</b> <?=$item['ResLevel']?> <br />  <b>HP:</b> <?=$item['HP']?>&nbsp&nbsp&nbsp&nbsp&nbsp<b>AP:</b> <?=$item['AP']?>', '300:120', 60)" onMouseOut="toolTip()">
<img style="border: #696969 Solid 2px;" width="100" height="100" src="images/shop/<?=$item['WebImgName']?>"></img></a>
       <?
    }

?><br><a href="index.php?do=cashshop&sub=listallitems&expand=1&type=1" target="_blanck"><font size="1">Clique aqui para ir a loja Donater.</a></font><br><br>
<tr>
<div align="center">
<b><font color="blue">Itens Donater Mais Comprados</font><br><br>
<?
    $res = mssql_query("SELECT TOP 4 * FROM WGShop WHERE Opened = '1' ");

    ?>
	 <?
                                        while($item = mssql_fetch_assoc($res)) {
                                                ?>
												
<a title="<?=$item['CashPrice']?>" href="index.php?do=cashshop&sub=details&id=<?=$item['CSID']?>" target="_while" onMouseOver="toolTip('<b>Nome: </b> <?=$foda['Name']?> <br />  <b>Sexo:</b> <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Masculino";
                                                    break;
                                                    case "1";
                                                    $sex = "Feminino";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?> <br />  <b>Pre&ccedilo:</b> <?=$item['CashPrice']?> WGCoins <br />  <b>Level:</b> <?=$item['ResLevel']?> <br />  <b>HP:</b> <?=$item['HP']?>&nbsp&nbsp&nbsp&nbsp&nbsp<b>AP:</b> <?=$item['AP']?>', '300:120', 60)" onMouseOut="toolTip()">
<img style="border: #696969 Solid 2px;" width="100" height="100" src="images/shop/<?=$item['WebImgName']?>"></img></a>
       <?
    }

?><br><a href="index.php?do=shopcoins&sub=listallitems&expand=1&type=1" target="_blanck"><font size="1">Clique aqui para ir a loja Evento.</a></font><br><br>

									
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>