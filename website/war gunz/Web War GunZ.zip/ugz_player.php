<?php
session_start();
include("secure/config.php");
include("secure/functions.php");


if($_SESSION['UGradeID'] == 253){
  echo "Your Account is Banned";
  die();
}
$page = sql($_GET['page']);
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
<center><!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>//Title</title>
<?php
Title("UserPanel");
?>
</head>
<body>
<?php if ($_SESSION['UserID']){ ?>
<br />
<div id="table_header">
 <div class="table_h">
<?php
  echo 'Bem Vindo, <b><a>'.$_SESSION['UserID'].'</a>!</b>';
?><br>
<div id="link_home"><a href="index.php"><b></b></a></div>
 </div>
</div>

<div id="table_body">
 <div class="table_b">
<?php
if($page == ""){
echo "
<div class='ap'>
<table>
<tr><br>
<tr>
<br>  <a href='index.php?do=criarclan'><font color='#551A8B'>Cria Cl�</font></a> | <a href='index.php?do=emblemas'><font color='#551A8B'>Cla Emblema</font></a> | <a href='index.php?do=UserPanel'><font color='#551A8B'>Meu Char</font></a> | <a href='/UserPainel'><font color='#551A8B'>Painel Geral</font></a> | <a href='index.php?do=color'><font color='#551A8B'>Name Color Comum</font></a> | <a href='index.php?do=color2'><font color='#551A8B'>Name Color Especial</font></a> | <a href='index.php?do=recuperarchar'><font color='#551A8B'>Recuperar Personagem</font></a> | <a href='index.php?do=editardados'><font color='#551A8B'>Editar Dados</font></a> |
</tr> 
      
</tr> 
</table>
</div>

";
}elseif($do == "changepassword"){
  include("inc/changepassword.php");
  Title("UserPanel &bull; Change Password");
}elseif($do == "stats"){
  include("inc/stats.php");
  Title("UserPanel &bull; User Stats");
}elseif($do == "changesex"){
  include("mod_sex.php");
  Title("UserPanel &bull; Change Sex");
}elseif($do == "clan"){
  include("inc/clan.php");
  Title("UserPanel &bull; Delete Clan");
}elseif($do == "logout"){
  include("inc/logout.php");
  Title("UserPanel &bull; Logout");
}elseif($do == "editinfo"){
  include("inc/editinfo.php");
  Title("UserPanel &bull; Edit Info");
}
?> 
 </div>
</div>

<div id="table_footer"></div>
<div id="footer">
  <!-- Please to not remove credits --><br>
  Copyright &copy; 2015 Painel de Jogador <span style="color:#0000CD; background: transparent url(http://tinyurl.com/outgum)">War Gunz</span></a>
</div>
<?php
}else{
  include("inc/login.php");
}
?>
</body>
</html></center>


</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
