<?
include "secure/anti_inject.php";
include "secure/anti_inject_sql.php";

if($_SESSION[UserID] <> "")
{
    SetMessage("Mensaje de ExplosionGunz", array("�Deslogueate Primero Para Crear Otras Cuentas!"));
    header("Location: index.php");
    die();
}

if(isset($_POST[submit]))
{
    $user           = clean($_POST[userid]);
    $names          = clean($_POST[namea]);
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);

    if($pass[0] != $pass[1]){
        SetMessage("Register", array("la contrase�a no coinciden"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE UserID = '$user'") ) <> 0 ){
        SetMessage("Register", array("EL UserID $userid ya est� en uso"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'") ) <> 0 ){
        SetMessage("Register", array("EL Email $email ya est� en uso"));
        header("Location: index.php?do=register");
        die();
    }
	
    elseif ($user == ""){
        SetMessage("Register", array("Por favor, introduzca un UserID"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($pass[0] == "" || $pass[1] == ""){
        SetMessage("Register", array("Por favor, introduzca una contrase�a"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($email == ""){
        SetMessage("Register", array("Por favor, introduzca una direcci�n de correo electr�nico"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($sq == ""){
        SetMessage("Register", array("Por favor, introduzca una pregunta secreta"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($sa == ""){
        SetMessage("Register", array("Por favor, introduzca una respuesta secreta"));
        header("Location: index.php?do=register");
        die();
    }
    elseif (strlen($user) < 3){
        SetMessage("Register", array("El ID de usuario es demasiado corto (6 min caracteres)"));
        header("Location: index.php?do=register");
        die();
    }
    elseif (strlen($pass[0]) < 3){
        SetMessage("Register", array("La contrase�a es demasiado corta (6 min caracteres)"));
        header("Location: index.php?do=register");
        die();
    }
    else{

            $registered = 1;
           mssql_query("INSERT INTO Account (UserID, Name, Email, UGradeID, PGradeID, RegDate, sa, sq, Coins, EventCoins, DonatorCoins)Values ('$user', '$names','$email', 0, 0, GETDATE(), '$sa', '$sq', 0, 0, 0)");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];

          mssql_query("INSERT INTO Login ([UserID], [AID], [Password])Values ('$user', '$aid', '$pass[0]')"); 
	SetMessage("Register", array("Ya puedes jugar ExplosionGunz Tu Cuenta $user a sido creada con exito.!!","Recibiste Varios Items Donantor por 4 Dias de regalo!"));
        header("Location: index.php");
        die();
    }

}else{
    SetTitle("ExplosionGunz - Registro");
	
/*    $europe = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

    $p = GetCountryCodeByIP($_SERVER[REMOTE_ADDR]);
    if(in_array(strtoupper($p), $europe))
    {
        $country = sprintf("[<font color='#00FF00'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }else{
        $country = sprintf("[<font color='#FF0000'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }*/
}



?>
<body onLoad="FP_preloadImgs(/*url*/'../images/btn_register_on.jpg')">

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
									<font color="#kff000">
										<font face="Tahoma" size="2"><b>&nbsp;</b></font><b><font face="Tahoma" size="2Not a user? Register now!</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
										<form method="POST" action="index.php?do=register" name="register">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
											<tr>
                                                <td width="11">&nbsp;</td>
                                                <td width="9">&nbsp;</td>
                                                <td width="183" align="left">&nbsp;</td>
                                                <td width="183" align="left">&nbsp;</td>
                                                <td width="16">&nbsp;</td>
                                              </tr>
											<tr>
                                                <td width="8">&nbsp;</td>
	                                            <td align="center" width="410" colspan="3">
		                                        <img alt="" border="0" src="images/mis_register.jpg" width="365" height="67">
                                                </td>
	                                            <td width="13">&nbsp;</td>
                                              </tr>
												<tr>
                                                <td width="11">&nbsp;</td>
                                                <td width="9">&nbsp;</td>
                                                <td width="183" align="left">&nbsp;</td>
                                                <td width="183" align="left">&nbsp;</td>
                                                <td width="16">&nbsp;</td>
                                                </tr>
												<td width="401" colspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center top" height="62">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="404" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="378">
															<p align="center">
															<font color="#FF0000">
															Recuerden Que 
															Ninguno Del Staff Te 
															Pedira Tu 
															Contrase�a! Asi Que 
															De Ninguna Manera 
															Nunca Se La Digas A 
															Nadie!</font></td>
															<td width="9">&nbsp;</td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img13"></td>
												<td width="183" align="left">
												<font color="#DF0101">
												<div align="left">UserID</td>
												<td width="183" align="left">
												<input type="text" name="userid" size="19" class="textLogin"></td>
												
												<td width="16">&nbsp;</td>
												
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9"><img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img13"></td>
												<td width="183" align="left">Nombre</td>
												<td width="183" align="left"><input name="namea" type="text" class="textLogin" id="namea" size="19"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												<font color="#DF0101">
												Contrase�a</td>
												<td width="183" align="left">
												<input type="password" name="pass1" size="19" class="textLogin"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												<font color="#DF0101">
												Repita Contrase�a</td>
												<td width="183" align="left">
												<input type="password" name="pass2" size="19" class="textLogin"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												E-Mail</td>
												<td width="183" align="left">
												<input type="text" name="email" size="19" class="textLogin"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">
												<div align="left">
												<font color="#575353">
												<font color="#6E6E6E">Por 
												Favor Introduzca Un Email 
												Valido!</span></font></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="402" colspan="5">
												<p align="center">
												<img border="0" src="images/mis_sepline.jpg" width="391" height="2"></td>
											</tr>
											<tr>
												<td width="402" colspan="5" background="images/mis_eumember.jpg" height="62" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="404" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="378">
															<p align="center">
															<font color="#FFFF00">
															Recuerden Que La 
															Pregunta Y Respuesta 
															Secreta Los Ayuda A 
															Recuperar Su Cuenta 
															Si Se Les Ah 
															Olvidado!</td>
															<td width="9">&nbsp;</td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												Pregunta Secreta</td>
												<td width="183" align="left">
												<input type="text" name="sq" size="19" class="textLogin"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												Respuesta Secreta</td>
												<td width="183" align="left">
												<input type="text" name="sa" size="19" class="textLogin"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="366" colspan="2">
												<p align="center">
												<input border="0" src="images/btn_register_off.jpg" name="img123" width="136" height="22" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img123',/*url*/'images/btn_register_on.jpg')" type="image"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												
												<td width="16"><p><br />
												  <br />
												  </p>
                                              </td>
											</tr>
										</table>
									  <input type="hidden" name="submit" value="1"></form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>