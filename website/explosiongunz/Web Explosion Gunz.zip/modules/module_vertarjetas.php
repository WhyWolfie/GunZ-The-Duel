<?
?>
<style type="text/css">
<!--
.Estilo3 {color: #373737}
.Estilo4 {color: #464646}

.boton{
  background-image:-moz-linear-gradient(top,#438CE7 0%,#438CE7 50%,#1E76E1 100%); 
  background-image:-webkit-linear-gradient(top,#438CE7 0%,#438CE7 50%,#1E76E1 100%); 
  border:3px #ffffff;
  border-radius:.5em;
  width:130px;
  height:54px;
  color:#B9B9B9;
  font-size:17px;
  -webkit-transition:.5s;
  -moz-transition:.5s;
}
.boton:hover{
  background-image:-moz-linear-gradient(top,#5799EA 0%,#5799EA 50%,#3C88E6 100%); 
  background-image:-webkit-linear-gradient(top,#5799EA 0%,#5799EA 50%,#3C88E6 100%); 
  color:#f1f1f1;
}

-->
</style>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
						  <div align="center">
						    <? include "blocks/block_rankingu.php" ?>
                          </div>
						  <div align="center">
                            <p>
                              <? include "blocks/block_rankingc.php" ?>
                              <center>
						</p>
					      </div>
						  </div>
						</div>					  </td>
						<td valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-repeat:no-repeat" width="419">
								<tr>
									<td background="images/mn_info.jpg" height="76" style="background-image: url(''); background-repeat: no-repeat; background-position: center top" width="417"><table width="417" height="76" style="background-image:-moz-linear-gradient(top,#464646 0%,#464646 50%,#3C3C3C 100%); background-image:-webkit-linear-gradient(top,#464646 0%,#464646 50%,#3C3C3C 100%); border-radius:5px 5px 5px 5px; border:#333333 ">
									
									<tr>
									<td><table width="415" height="74">
                                      <tr>
                                        
                                       
                                      </tr>
                                    </table><?php
// No tocar
if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

//
if($_SESSION['AID'] == ""){
	msgbox("Para ingresar debes estar logueado.","index.php?do=login");
	die();
	}else{
	$very = mssql_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
	$acc = mssql_fetch_object($very);
	if($acc->UGradeID !== 255){
		msgbox("Usted no tiene permiso para ingresar.","index.php");
			}
			echo "<table align='center'  style='font-size:12px'><tr><td><b>";
	include "tarjetasdiariasdegalaxiaentertainment2013.txt";
	echo "</b></td></tr></table>";
		}

?></td>
									</tr>
									
									</table></td>
							  </tr>
								<tr>
									<td height="4" width="417"></td>
								</tr>
							</table>
						</div>						</td>
						<td width="171" valign="top">
						<div align="center">
						  <? include "blocks/block_login.php";
                        ?>
						</div></td>
					</tr>
</table>