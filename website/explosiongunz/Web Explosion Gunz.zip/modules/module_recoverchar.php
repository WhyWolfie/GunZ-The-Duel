<?php
include "secure/anti_inject.php";
SetTitle("ExplosionGunz 1.5 - Recorver");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=recoverchar");
    SetMessage("Recuperar Personajes", array("Inicie secion antes de Recuperar el personaje"));
    header("Location: index.php?do=login");
    die();
}
else
{
    $qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($qchars) == 0 )
    {
        SetMessage("Recover Character", array("Usted no tiene ning�n personaje en esta cuenta"));
        header("Location: index.php");
        die();
    }
    else
    {

    if( isset($_GET['cid']) )
    {
        $cid = clean($_GET['cid']);
        $qcharinfo = mssql_query_logged("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
        if( mssql_num_rows($qcharinfo) == 0 )
        {
            SetMessage("Recover Character", array("El car�cter seleccionado no existe o no pertenece a su cuenta"));
            header("Location: index.php");
            die();
        }

        $info = mssql_fetch_assoc($qcharinfo);

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
        {
            SetMessage("Recover Character", array("El personaje seleccionado yah existe", "Desafortunadamente, este car�cter no puede ser recuperado"));
            header("Location: index.php?do=recoverchar");
            die();
        }

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        else
        {
            SetMessage("Recover Character", array("Su cuenta tiene 4 caracteres activas, que es el m�ximo permitido", "Hay que eliminar uno de tus personajes para recuperar el seleccionado"));
            header("Location: index.php?do=recoverchar");
            die();
        }

        SetMessage("Recover Character", array("El car�cter seleccionado se ha recuperado con �xito"));
        header("Location: index.php?do=recoverchar");
        die();
    }
    else
    {


    ?>
    <table border="0" style="border-collapse: collapse" width="100%">
    <tr>
        <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
    	<td valign="top">
        <div align="center">
		<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
		<tr>
		    <td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
			<div align="center">
			<b><font face="Tahoma" size="2">Recuperaci�n de Personajes</font></b></td>
		</tr>
        <tr>
        <td align="center" width="75%">
        <p>
        <br /><br />
		<span style="font-size: 8pt"><font color="#FFFFFF">
        Aqu� podr�s recuperar personajes que has borrado<br />o te han
        borrado involuntariamente.<br>Debes de saber que en una cuenta de ExplosionExplosionGunz 1.5 1.5 se permite<br />
        un m�ximo de 4 personajes, por lo tanto<br>si ya tienes 4 personajes activos y
        deseas recuperar<br /> uno de los personajes borrados, <br><b>deber�s borrar un personaje
        activo</b><br /> para dar lugar al que recuperar�s.</p></font></span>

        Lista de personajes:<br /><br />
        <table align="center" border="3" width="90%" style="border-collapse: collapse" id="table1">
        	<tr>
        		<td><b><span style="font-size: 8pt"><font color="#FFFFFF">Nombre</span></font></b></td>
        		<td><b><span style="font-size: 8pt"><font color="#FFFFFF">Level</span></font></b></td>
        		<td><b><span style="font-size: 8pt"><font color="#FFFFFF">Tipo</span></font></b></td>
        		<td><b><span style="font-size: 8pt"><font color="#FFFFFF">�Recuperar?</span></font></b></td>
        	</tr>
            <?

        while( $data = mssql_fetch_assoc($qchars) )
        {
            echo '
            	<tr>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo $data[DeleteName].'</td>';
                    }else{
                        echo $data[Name].'</td>';
                    }

                echo '<td>'.$data[Level].'</td>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo 'Borrado</td>
                    <td>';
                    }else{
                        echo 'Activo</td>
                    <td>';
                    }
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo '<a href="index.php?do=recoverchar&cid='.$data[CID].'">Recuperar!</a></td>
            	</tr>';
                    }else{
                        echo 'Activo</td>
            	</tr>';
                    }

        }
        ?>
        </table><br /><br /></td></tr></table></div>
						</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
        <?
    }
}
}

?>