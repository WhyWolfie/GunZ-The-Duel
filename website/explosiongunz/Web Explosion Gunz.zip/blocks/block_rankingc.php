<?php
include ('secure/config.php')
?>
<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.Estilo3 {color: #414141}
-->

</style>
<table>
<td></td>
</table>
<table background="images/md_cr.png"  width="170" height="142" border="0">
<tr>
    <td><table width="169" height="100" border="0" style="border-collapse: collapse">
      <tr>
        <td width="11" rowspan="6">&nbsp;</td>
        <td height="15" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos</div></td>
      </tr>
     <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="12" align="left"> <img src="http://www.explosiongunz.com/emblems/upload/<?=($clan['EmblemUrl'] == "") ? 'uploadnoemblem.jpg' : $clan['EmblemUrl']?>" width="15" height="15"> 															</td>
  															<td width="93" align="left"><span style="font-size: 8pt"><font color="#FFFFFF"><?=$clan['Name']?></span></font>
         			      <td width="27"><span style="font-size: 8pt"><font color="#FFFFFF"><?=number_format($clan['Point'],0,'','');?>Pts.</span></font></td></span>
										<td width="0"></td>
										<td width="0">
										</span></font>
										</td>
		</tr>
                                    <?}}?>
									<tr>
    </table>    <td height="39"></tr>
</table>
<p><a href="UserPanel"><img src="images/litemshop.png" width="175" height="175" border="0" /></a></p>
<p><a href="index.php?do=signature"><img src="images/signature.png" width="175" height="175" border="0" /></a></p>
<p><a href="index.php?do=contact"><img src="../images/ventrilo.png" width="175" height="175" /></a>