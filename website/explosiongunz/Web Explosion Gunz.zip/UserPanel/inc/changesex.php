<div id="pos">
<br /><div id="ststitle">Change Sex :</div><br />
<form action="index.php?page=changesex" method="post">
<?php
$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0");
echo '<select name="username">';
 if(mssql_num_rows($query)<>0){
   while($char = mssql_fetch_assoc($query)){
    echo '<option value="'.$char['Name'].'">';
     echo $char['Name'];
    echo '</option>';
   }
 }else{
   echo '<option></option>';
 }
echo '</select>';
?>
<select name="sex">
    <option value="0">Male</option>
    <option value="1">Female</option>
</select>
<input type="submit" name="changesex" value="Change" />
</form>
<?php
if (isset($_POST['changesex'])){
$sex = sql($_POST['sex']);
$name = sql($_POST['username']);

$sql = "UPDATE Character SET Sex ='$sex' WHERE Name='$name'";
$result = mssql_query($sql);

if($result){
  $msg = "Sex Changed!"; alert($msg); 
  redirect("index.php");
}else{
  $msg = "Sex Change Failed"; alert($msg);
  redirect("index.php?page=changesex");
}
}
?>
</div>