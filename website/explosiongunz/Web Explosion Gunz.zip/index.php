<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";
include "IpBan/ipban.php";
checar_baneo_ip($_SERVER['REMOTE_ADDR']);
if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "ExplosionGunz - Inicio", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>%TITLE%</title>
<link href="/favicon/miguel_23.ico" rel="shortcut icon" />
<script language="JavaScript">
<!--
&lt;?php
   
   $ Ad_ddos_query = 10, / / ??number of requests per second to detect DDOS attacks
   $ Ad_check_file = &#039;check.txt&#039;; / / file to write the current state during the monitoring
   $ Ad_temp_file = &#039;all_ip.txt&#039;; / / temporary file
   $ Ad_black_file = &#039;black_ip.txt&#039;; / / will be entered into a zombie machine ip
   $ Ad_white_file = &#039;white_ip.txt&#039;; / / ip logged visitors
   $ Ad_dir = &#039;anti_ddos&#039;; / / directory with scripts
   $ Ad_num_query = 0, / / ??current number of requests per second from a file $ check_file
   $ Ad_sec_query = 0, / / ??second from a file $ check_file
   $ Ad_end_defense = 0, / / ??end while protecting the file $ check_file
   $ Ad_sec = date (&quot;s&quot;); / / current second
   $ Ad_date = date (&quot;mdHis&quot;); / / current time
   $ Ad_defense_time = 10000 / / ddos ??attack detection time in seconds at which stops monitoring
   
   
   
   if (! file_exists (&quot;{$ ad_dir} / {$ ad_check_file}&quot;) or! file_exists (&quot;{$ ad_dir} / {$ ad_temp_file}&quot;) or! file_exists (&quot;{$ ad_dir} / {$ ad_black_file}&quot;) or ! file_exists (&quot;{$ ad_dir} / {$ ad_white_file}&quot;) or! file_exists (&quot;{$ ad_dir} / anti_ddos.php&quot;)) {
   die (&quot;Not enough files.&quot;);
   }
   
   require (&quot;{$ ad_dir} / {$ ad_check_file}&quot;);
   
   if ($ ad_end_defense and $ ad_end_defense&gt; $ ad_date) {
   require (&quot;{$ ad_dir} / anti_ddos.php&quot;);
   } Else {
   if ($ ad_sec == $ ad_sec_query) {
   $ Ad_num_query + +;
   } Else {
   $ Ad_num_query = &#039;1 &#039;;
   }
   
   if ($ ad_num_query&gt; = $ ad_ddos_query) {
   $ Ad_file = fopen (&quot;{$ ad_dir} / {$ ad_check_file}&quot;, &quot;w&quot;);
   $ Ad_end_defense = $ ad_date + $ ad_defense_time;
   $ Ad_string = &#039;&lt;? Php $ ad_end_defense =&#039;. $ Ad_end_defense. &#039;;?&gt;&#039;;
   fputs ($ ad_file, $ ad_string);
   fclose ($ ad_fp);
   } Else {
   $ Ad_file = fopen (&quot;{$ ad_dir} / {$ ad_check_file}&quot;, &quot;w&quot;);
   $ Ad_string = &#039;&lt;? Php $ ad_num_query =&#039;. $ Ad_num_query. &#039;; $ Ad_sec_query =&#039;. $ Ad_sec. &#039;;?&gt;&#039;;
   fputs ($ ad_file, $ ad_string);
   fclose ($ ad_fp);
   }
   }
   ?&gt;
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->
</script>

<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>
<script type="text/javascript" src="js/menunewskr.js"></script>
<script>
<!--
loadImage0 = new Image();
loadImage0.src = "images/nav-home_on.png";
staticImage0 = new Image();
staticImage0.src = "images/nav-home.png";

loadImage1 = new Image();
loadImage1.src = "images/nav-reg_on.png";
staticImage1 = new Image();
staticImage1.src = "images/nav-reg.png";

loadImage2 = new Image();
loadImage2.src ="images/nav-down_on.png";
staticImage2 = new Image();
staticImage2.src = "images/nav-down.png";

loadImage3 = new Image();
loadImage3.src = "images/nav-logo_on.png";
staticImage3 = new Image();
staticImage3.src = "images/nav-logo.png";

loadImage4 = new Image();
loadImage4.src = "images/nav-clan_on.png";
staticImage4 = new Image();
staticImage4.src = "images/nav-clan.png";

loadImage5 = new Image();
loadImage5.src = "images/nav-mark_on.png";
staticImage5 = new Image();
staticImage5.src = "images/nav-mark.png";

loadImage6 = new Image();
loadImage6.src = "images/nav-com_on.png";
staticImage6 = new Image();
staticImage6.src = "images/nav-com.png";

loadImage7 = new Image();
loadImage7.src = "images/donate_on.png";
staticImage7 = new Image();
staticImage7.src = "images/donate.png";

loadImage8 = new Image();
loadImage8.src = "images/ranking_on.png";
staticImage8 = new Image();
staticImage8.src = "images/ranking.png";

loadImage9 = new Image();
loadImage9.src = "images/login_btn_on.png";
staticImage9 = new Image();
staticImage9.src = "images/login_btn.png";

loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";
// En
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
//-->
</script>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

//-->
</script>
<script type="text/JavaScript">
<!--
//-->
</script>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<link rel="stylesheet" type="text/css" href="e_style.css">
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/bg2.jpg') no-repeat center top">

<div align="center">
<table width="32" height="32" border="0">
  <tr>

  </tr>
</table>

			<td><tr>              
          </tr><div align="center">
		</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<table border="0" style="border-collapse: collapse" width="90%">
		<tr>
		  <td><p> <center>  <table width="628" height="77" border="0">
        <tr>
          <th width="548" scope="col"><marquee>
          <span class="Estilo2">Bienvenidos a ExplosionGunz</span><img src="images/=).gif" width="51" height="49">
          </marquee></th>
        </tr>
      </table></p></center>
	      <p>&nbsp;</p></td>
		</tr>
		<tr>
		  <td><center><table width="780" height="41" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>

        <td width="663" valign="bottom"><table width="792" border="0" align="left" cellpadding="0" cellspacing="0">
          <tr>
            <td width="803"><p align="center"><img src="images/borde.png" width="25" height="55"><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('inicio','','images/inicioon.png',1)"><img src="images/inicip.png" name="inicio" width="120" height="55" border="0"></a><a href="index.php?do=register" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('registro','','images/registroon.png',1)"><img src="images/registro.png" name="registro" width="120" height="55" border="0"></a><a href="index.php?do=ranking" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ranking','','images/rankingon.png',1)"><img src="images/ranking.png" width="120" height="55" border="0" id="ranking" /></a><a href="index.php?do=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('descarga','','images/descargaon.png',1)"><img src="images/descarga.png" name="descarga" width="120" height="55" border="0"></a><a href="index.php?do=shop" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('itemshop','','images/itemshopon.png',1)"><img src="images/itemshop.png" name="itemshop" width="120" height="55" border="0"></a><a href="http://foroexplosion.forovenezuela.net/" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('foro','','images/foroon.png',1)"><img src="images/foro.png" width="120" height="55" border="0" id="foro" /></a><img src="images/borderigth.png" width="25" height="55"></p>              </td>
          </tr>
        </table></td>
      </tr>
    </table>
		    
		  </center>		  </td>
	  </tr>
		<tr>
			<td>
		<div align="center">

		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3"></td>
          </tr>
            <?
            if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
            {
                SetMessage("", array("�explosion Gunz es un servidor completamente gratuito!",
                "Recuerda que por cada Donaciones que hagas Estas ayudando a mantener el servidor, y asi podran jugar bien a gusto.",
				"Haz click <a href=\"index.php?do=register\"><b>aqu�</b> para registrarte</a>"));
            }
            echo $_SESSION[SiteMessage];

            $_SESSION[SiteMessage]="";?>
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                     SetMessage("Se produjo un error", array("El modulo que intento buscar no existe o esta en construccion"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>	<script language="Javascript" type="text/javascript">
//<![CDATA[

<!-- Begin
document.oncontextmenu = function(){return false}
// End -->
//]]>
</script>		</td>
            <td width="12">&nbsp;</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">&nbsp;			</td>
          </tr>
        	<tr>
            <td width="800" colspan="3">&nbsp;</td>
          </tr>
        </tbody></table>
          </div>          	</td>
		</tr>
	</table>
          </div>
          	</td>
		</tr>
	</table>
</div>

</body>

</html>