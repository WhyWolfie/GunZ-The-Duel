﻿<?php
/*	*********************ACERCA DEL SCRIPT********************************
	ESTE SCRIPT LO ENCONTRE EN EL FORO DE PHPOST CREADO POR "djarielstyle"
	AL PARECER EL NO LO CREO, PERO LE AGRADECEMOS LA IDEA DEL SCRIPT
	
	HEMOS UTILIZADO LA IDEA Y COMO BASE EL SCRIPT DEL FORO DE PHPOST
	PARA DESARROLLAR EL SIGUIENTE SCRIPT.
	
	EL SCRIPT FUE MEJORADO POR ALGROX DE [ FORO7.COM / CIBER-ADICTOS.COM ]
	Y HE ELIMINADO MUCHOS ERRORES QUE TENIA, ASI COMO ELIMINAR LAS
	NOTIFICACIONES VIA EMAIL QUE SE SUPONIA QUE DEBIA DE ENVIAR, ASI COMO
	COOKIES INNECESARIAS Y LINEAS DE CODIGO QUE NO FUNCIONABAN BAJO XAMPP
	
	AHORA EL SCRIPT FUNCIONA BAJO WINDOWS Y LINUX.
	
	DESARROLLAREMOS ACTUALIZACIONES PARA EL SCRIPT LAS CUALES CONTENDRAN
	VARIAS MEJORAS.
	LAS MEJORAS SE DESARROLLARAN DEPENDIENDO LAS NECESIDADES DE LOS USUARIOS,
	ESTAS DEBERAN SER PROPUESTAS EN EL BLOG DE CIBER-ADICTOS.COM
	***********************ACERCA DEL SCRIPT*********************************/
	

//Configuracion de bloqueo
	$tiempobloqueo = 3600; //Tiempo que sera bloqueada una direccion IP en segundos
	$visitasbloqueo = 3600; //Visitas permitidas en un peridio de $tiempovisitas segundos
	$tiempovisitas = 3600; //Tiempo en el que se resetea el numero de visitas permitidas

//Configuracion de registro (Logs)
	$logdir = "./log/"; //Este directorio debe tener permisos 777 para poder crear los archivos
	$logarchivo = "registro.dat"; //Archivo de Registro

/* No modificar si no tienes experiencia con PHP*/
	$archivoip = base64_encode($_SERVER["REMOTE_ADDR"]);
	$tiempoinicio = 0;
	if (file_exists($logdir.$archivoip)){
		$tiempoinicio = filemtime($logdir.$archivoip);
	}
	$time = time();
	if ($tiempoinicio < $time){
		$tiempoinicio = $time;
	}
	$nuevotiempo = $tiempoinicio + $tiempovisitas;
	
	if ($nuevotiempo >= $time+$tiempovisitas*$visitasbloqueo){
		touch($logdir.$archivoip, $time + $tiempovisitas*($visitasbloqueo-1) + $tiempobloqueo);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<title>Solicitud denegada!</title>
		<style type="text/css">
			body {
				background: #FFF;
				font-family: 'Arial', sans-serif;
				font-size: small;
				color: #000;
			}
			.wrapper {
				width: 560px;
				margin: 0 auto;
				text-align: center;
			}
			.header {
				padding: 10px 15px 15px;
			}
			.content {
				padding: 15px;
			}
			hr {
				margin: 15px 0 0;
				border: none;
				border-top: dotted 1px #B9B9B9;
			}
			a {
				color: #058EC4;
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
			}
			h1 a {
				display: block;
				width: 435px;
				height: 68px;
				margin: 0 auto;
				background: url(http://3.bp.blogspot.com/-v-jl7ORKg1I/TqXShGLnIsI/AAAAAAAAAEM/kWXgzFl1wXQ/s1600/Ciber-Adictos.png) no-repeat;
			}
			h1 a span {
				display: none;
			}
			h2 {
				margin: 0;
				font-size: 1.9em;
				color: #333;
			}
			h3 {
				margin: 5px 0 0;
				font-size: 1em;
				color: #999;
			}
			p {
				margin: 20px 0 5px;
				font-size: 1.1em;
			}
			p a {
				margin: 0 5px;
			}
			.box {
				position: relative;
				background: #FFF;
			}
			.corner {
				position: absolute;
				width: 50%;
				height: 5px;
			}
			.corner.tl {
				top: -5px;
				left: 0;
				background-position: left top;
			}
			.corner.tr {
				top: -5px;
				right: 0;
				background-position: right top;
			}
			.corner.bl {
				bottom: -5px;
				left: 0;
				background-position: left bottom;
			}
			.corner.br {
				bottom: -5px;
				right: 0;
				background-position: right bottom;
			}
		.Estilo1 {color: #FF0000}
        </style>
	</head>
	<body>
		<div class="wrapper">
			<h1><img src="http://i.imgur.com/OyVHK.png" width="505" height="91"></h1>
			<div class="box">
		    <div class="header">
					<h2>Lo sentimos, esta página esta protegida.</h2>
					<h3><strong>Detectamos que ha estado haciendo mal uso de nuestro servicio, por tal motivo hemos decidido bloquear tu IP por unos momentos.</strong></h3>
					<p><strong>Este sitio web utiliza el sistema anti denegación de servicio creado</strong></p>
					<p><strong> Cz-Security </strong></p>
					<p><strong><em>Sigues Intentado Inutil </em></strong></p>
				</div>
				<div class="content">
					<div align="center"><b><span class="Estilo1">C0nt@ct m3: </span><font color="red">teerrormaster@hotmail.com</font></b></div>
					<hr />
					<p>&nbsp;</p>
			  </div>
				<div class="corner bl"></div>
				<div class="corner br"></div>
		  </div>
	</div>
	</body>
</html>
<?
			touch($logdir.$logarchivo);
			$fp = fopen($logdir.$logarchivo, "a");
			$dominio = $_SERVER['HTTP_HOST'];
			
			if ($fp){
				$useragent = "<unknown user agent>";
				if (isset($_SERVER["HTTP_USER_AGENT"])){
					$useragent = $_SERVER["HTTP_USER_AGENT"];
				}
				fputs($fp, $_SERVER["REMOTE_ADDR"]." ".date("d/m/Y H:i:s")." ".$useragent."\n");
				fclose($fp);
				$dominio = $_SERVER['HTTP_HOST'];
			}
			
			exit;
			
	}
	
	touch($logdir.$archivoip, $nuevotiempo);

?>