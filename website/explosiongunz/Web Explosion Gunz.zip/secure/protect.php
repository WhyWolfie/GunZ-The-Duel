<?php
if (!isset($_SESSION)) {.
session_start();
}
// anti flood protection
if($_SESSION['last_session_request'] > time() - 2){
// Anti Flood para WebSite by [AG]
header("location: /flood.html");
exit;
}
$_SESSION['last_session_request'] = time();
?>
