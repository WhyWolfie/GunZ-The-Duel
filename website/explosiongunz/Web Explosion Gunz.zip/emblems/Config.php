<?php
/////Lo editamos con nuestros datos
$DBHost = 'WIN-FG2P6CE39VQ\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'Wye4F53931219H';
$DB = 'GunzDB';
?>
