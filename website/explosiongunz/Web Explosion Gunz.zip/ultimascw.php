<table width="431" border="0">
  <tr>
    <td height="27" style="background:#1E1E1E; color:#146CCD; border-radius:5px 5px 0px 0px;"><center><strong>Ultimos Clan War</strong></center></td>
  </tr>
</table>
<table style="background:#171717;"><tr><td><table width="420">
  <tr>
    <td><table width="415">
  <tr>
    <td width="35" bgcolor="#1F1F1F" style="border-radius:3px 3px 3px 3px;" align="center"><strong>Win</strong></td>
    <td width="158" bgcolor="#282828" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8">&nbsp;<strong>Clan Ganador</strong></font></td>
    <td width="19"></td>
    <td width="143" bgcolor="#282828" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8"><strong>Clan Perdedor</strong></font></td>
    <td width="43" bgcolor="#1F1F1F" style="border-radius:3px 3px 3px 3px;" align="center"><strong>Losse</strong></td>
  </tr>
  
</table>
</td>
  </tr>
</table></td></tr></table>
<?php
$busca999 = mssql_query("SELECT TOP 7 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
<table style="background:#171717"><tr><td><table width="420">
  <tr>
    <td><table width="415">
  <tr>
    <td width="35" bgcolor="#1F1F1F" style="border-radius:3px 0px 0px 3px;" align="center"><font color="#99FF00"><?=$item22[2]?> +</font></td>
    <td width="153" bgcolor="#282828" style="border-radius:0px 3px 3px 0px;" align="center"><font size="1,8"><?=$item22[0]?></font></td>
    <td width="19" align="center">Vs</td>
    <td width="148" bgcolor="#282828" style="border-radius:3px 0px 0px 3px;" align="center"><font size="1,8"><?=$item22[1]?></font></td>
    <td width="36" bgcolor="#1F1F1F" style="border-radius:0px 3px 3px 0px;" align="center"><font color="#FF0000">- <?=$item22[3]?></font></td>
  </tr>
  
</table>
</td>
  </tr>
</table></td></tr></table>

<?
}
?>