<?php
if(!isset($_SESSION['AID']))
{
	alertbox("Quem &eacute; voc&ecirc;? -.-!","index.php");
}

if(!isset($_GET['id']) && !isset($_GET['clid']))
{
	alertbox("Error","index.php");
}
if(!is_numeric($_GET['id']) && !is_numeric($_GET['clid']))
{
	alertbox("Error","index.php");
}
$id = clean($_GET['id']);
$clid = clean($_GET['clid']);
$q = mssql_query("SELECT * FROM Clan a INNER JOIN Character b ON a.MasterCID=b.CID WHERE b.AID='".$_SESSION['AID']."' AND a.CLID='".$clid."'");
if(!mssql_num_rows($q))
{
	alertbox("Voc&ecirc; n&atilde;o &eacute; nada para aqui ¬ ¬","index.php");
}

mssql_query("UPDATE Peticiones SET Status='2' WHERE ID='".$id."'");
alertbox("Pedido rejeitado =D","index.php?do=clan");
?>