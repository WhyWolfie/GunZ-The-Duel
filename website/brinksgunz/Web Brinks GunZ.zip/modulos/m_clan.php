<?php
if(empty($_SESSION['AID']))
{
	alertbox("Voc&ecirc; n&atilde;o est&aacute; logado","index.php");
}
?>
<div class="sub-box1" align="left">
  <div align="center"><a style="" href="./index.php?do=clan&amp;page=miclan"><span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas">Meu</span>&nbsp;<span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas">Cl&atilde;s</span> </a> | <a style="" href="./index.php?do=clan&amp;page=peticion"> <span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas">Meu</span>&nbsp;<span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas">Peti&ccedil;&otilde;es</span> </a> | <a style="" href="./index.php?do=clan&amp;page=salir">Sair ou Fechar Clan</a><br />
    <a style="" href="./index.php?do=clan&amp;page=cambiar">Mudan&ccedil;a de status de um membro</a><br/>
  </div>
</div>
<br />
<font color="#FFFFFF">------------------</font>
<div class="sub-box1" align="left">
  <div align="center">
    <?
if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	if($page == "peticion")
	{
		?>
Para enviar um pedido para o clan basta ir ao clan Ranking<br />
clicar sobre o clan que voc&ecirc; quer entrar e mostrar se eles est&atilde;o dispon&iacute;veis os seus rendimentos e / ou solicita&ccedil;&otilde;es.<a style="color:#0F0" href="./index.php?do=clan&amp;page=cambiar"></a><br/>
  </div>
</div>
<font color="#FFFFFF">--------------------------------------------------------</font>
<br>
<br>
<br />
<br />
        <font color="#FFFFFF">-------------------------------------------------------------------------------</font>
        <?
		include "./clan/mipeticion.php";
	}elseif($page == "miclan")
	{
		include "./clan/miclan.php";
	}elseif($page == "salir")
	{
		include "./clan/salir.php";
	}elseif($page == "cambiar")
	{
		include "./clan/cambiar.php";
	}
}else{ ?>
<p>&nbsp;</p>
<?
}
?>