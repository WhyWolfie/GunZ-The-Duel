<?
if(empty($_GET['code']) || empty($_GET['aid']))
{
	alertbox("C&oacute;digo inv&aacute;lido","index.php");
}else{
	$code = clean($_GET['code']);
	$aid = clean($_GET['aid']);
	if(!is_numeric($aid))
	{
		alertbox("Erro na ID","index.php");
	}
	$q = mssql_query("SELECT * FROM Login WHERE Code='".$code."' AND AID='".$aid."'");
	if(!mssql_num_rows($q))
	{
		alertbox("O código não existe ou já foi usado","index.php");
	}else{
		$r = mssql_fetch_object($q);
		if(isset($_POST['reset']))
		{
			$pass = clean($_POST['pass']);
			$npass = clean($_POST['npass']);
			if(empty($pass) || empty($npass))
			{
				alertbox("N&atilde;o deixe espa&ccedil;os vazios","index.php");
			}
			if($pass != $npass)
			{
				alertbox("As senha n&atilde;o identicas","index.php");
			}
			
			mssql_query("UPDATE Login SET CodeFecha=GETDATE(), Code='0', Password='".$pass."' WHERE AID='".$aid."'");
			alertbox("Senha alterada com sucesso!","index.php");
		}else{
			$nick = $r->UserID;
		?>
		<form name="resetp" method="post">
        <center>
          <div class="sub-box1" align="left">
          <p align="center"><font color="#00FF00">Bem Vindo ,
              <?=$nick?>
              <br />
              <span title="Clique para mostrar traduções alternativas">Nova</span> <span title="Clique para mostrar traduções alternativas">Senha</span> :
              <br />
              <input type="password" name="pass" />
              <br />
          </font></p>
          <p align="center"><font color="#00FF00"><span title="Clique para mostrar traduções alternativas">Confirme Senha</span> : <br />
          <input type="password" name="npass" id="npass" />
          <br />
          </font></p>
          <p align="center"><font color="#00FF00">
            <div id="log-b2">
              <div align="center">
                <input type="submit" name="reset" value="Mudar" />
              </div>
            </div>
          </font><br/>
          </p>
          </div>
        </center>
        </form>
        <? }  } } ?>