<?php
if(empty($_SESSION['AID']))
{
?>
<form name="loguear" method="post" action="./index.php?do=loguear">
<div class="sub-box1" align="left"> UserID:<br/>
        <input type="text" name="user" class="username" onclick="this.value=''" maxlength="21" />
    <br/>
  Senha: <br/>
  <input type="password" name="pass" class="password" onclick="this.value=''" maxlength="21" />
  <br/>
* Use detalhes da sua conta no jogo * <br/>
  <div class="line2"></div>
  <table cellpadding="0" cellspacing="0">
    <tr>
      <td valign="top"><div id="log-b2">
        <input name="login" type="submit" value="Logar" alt="login" />
      </div></td>
      <td valign="top" style="padding: 3px 0px 0px 5px;"><a href="./index.php?do=reset">Esqueceu sua senha ?</a> <br/>
        <a href="./index.php?do=registro">Criar novo Cadastro !</a> </td>
    </tr>
  </table>
  </div>
      <p>&nbsp;      </p>
</form>
      <? }else{ 
	  include "./panel/index.php";
	  }
	  ?>
	  