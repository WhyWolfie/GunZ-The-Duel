<font color="#FFFFFF">
<?php
if(!isset($_GET['clid']) || !is_numeric($_GET['clid']))
{
	alertbox("Error","index.php");
}
$clid = clean($_GET['clid']);
$q = mssql_query("SELECT * FROM Clan WHERE CLID ='".$clid."'");
if(!mssql_num_rows($q))
{
	alertbox("O clan n&atilde;o existe","index.php?do=ranking&type=1");
}
$r = mssql_fetch_object($q);
?>
</font>
<table width="531" style="border-collapse: collapse">
  <tbody>
    <tr>
      <td width="10">&nbsp;</td>
      <td width="101">&nbsp;</td>
      <td width="404">&nbsp;</td>
    </tr>
    <tr>
      <td width="10">&nbsp;</td>
      <td width="101" valign="top"><div align="center"></div>
      <font color="#FFFFFF"><img width="100" height="100" src="./emblems/upload/<?=$r->EmblemUrl?>" /></font></td>
      <td width="404"><div align="center">
        <table width="370" border="0" bgcolor="#1e1e1e" style="border-collapse: collapse">
          <tbody>
            <tr>
              <td width="19">&nbsp;</td>
              <td width="435" colspan="2"><div align="left"><font color="#FF0000">
                <?=$r->Name?>
              </font></div></td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="435">Dono:</td>
              <td align="left" width="372">
                <?=master($r->MasterCID)?>
              </td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="435">Pontos::</td>
              <td align="left" width="372">
                <?=$r->Point?>
              </td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="435">Wins:</td>
              <td align="left" width="372">
                <?=$r->Wins?>
             </td>
            </tr>
            <tr>
              <td width="19">&nbsp;</td>
              <td align="left" width="435">Losses:</td>
              <td align="left" width="372">
                <?=$r->Losses?>
              </td>
            </tr>
          </tbody>
        </table>
      </div></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
<table width="478" bgcolor="#1e1e1e">
  <tr>
  <td width="83" align="center">Nome</td><td width="54" align="center">Level</td>
  <td width="106" align="center">Cargo</td>
  <td width="127" align="center">Data</td>
  </tr>
  <?
$q = mssql_query("SELECT * FROM ClanMember WHERE CLID = '".$clid."'");
while($r = mssql_fetch_object($q))
{
	if($r->Grade == 1)
	{
		$rango = "Dono";
	}elseif($r->Grade == 2){
		$rango = "Administrador";
	}else{
		$rango = "Normal";
	}
	?>
  <tr>
    <td align="center"><?=getcha($r->CID)?></td><td align="center"><?=getlvl($r->CID)?></td><td align="center"><?=$rango?></td><td align="center"><?=$r->RegDate?></td>
  </tr>
  <?
} ?>
</table>
<p>&nbsp;</p>
<?
if(isset($_SESSION['AID']))
{
	$q = mssql_query("SELECT * FROM Clan WHERE CLID='".$clid."'");
	$r = mssql_fetch_object($q);
	if($r->Peticion == 0)
	{
		?>
    	<a style="color:#FF0" href="./index.php?do=peticionenviar&clid=<?=$clid?>">Enviar Pedido</a>
    	<?
	}else{
		echo '<font color="#FFFF00">Sistema de pedidos est&atilde;o offline</font>';
	}
}
?>