<?php
if(!isset($_SESSION['AID']))
{
	redir("index.php");
}
if(!isset($_GET['clid']) || !is_numeric($_GET['clid']))
{
	alertbox("Error","index.php");
}
$clid = clean($_GET['clid']);

$q = mssql_query("SELECT * FROM Clan WHERE CLID='".$clid."'");
if(mssql_num_rows($q))
{
	$r = mssql_fetch_object($q);
	if($r->Peticion != 0)
	{
		alertbox("O cl&atilde;cancelou os pedidos.","index.php");
	}
}else{
	alertbox("O cl&atilde; n&atilde;o existee.","index.php");
}

if(!isset($_POST['enviar']))
{
	?>
    <form name="peticion" method="post">
      <div class="sub-box1" align="left">
        <div align="center"><font color="#FFFFFF">W
          <?
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	alertbox("Voc� n�o possui personagem.","index.php");
}
?>
        Enviar Pedido para Clan
<?=getclan($clid)?>
        </font></div>
        <p align="center">&nbsp;</p>
        <div align="center"><font color="#FFFFFF">Selecionar Personagem
          <select name="pj">
            <? while($r = mssql_fetch_object($q))
{
	?>
                      <option value="<?=$r->CID?>">
                      <?=$r->Name?>
                                </option>
            <?
}
?>
              </select>
        <br />
        <br />
               </font></div>
        <font color="#FFFFFF">
        <div id="log-b2">
          <div align="center">
            <input type="submit" name="enviar" value="Enviar" />
          </div>
        </div>
        </font>
        <div align="center"><br/>
        </div>
      </div>
</form>
<?
}else{
	$cid = clean($_POST['pj']);
	$pj = getcha($cid);
	$lvl = getlvl($cid);
	$q = mssql_query("SELECT * FROM ClanMember WHERE CID='".$cid."'");
	if(mssql_num_rows($q))
	{
		mssql_query("DELETE FROM Peticiones WHERE CLIDClan='".$clid."' AND CID='".$cid."' AND Status='1'");
		alertbox("O personagem ja est&aacute; em um cl&atilde;","index.php?do=peticionenviar&clid=".$clid."");
	}
	$q = mssql_query("SELECT * FROM Peticiones WHERE CLIDClan='".$clid."' AND CID='".$cid."'");
	if(mssql_num_rows($q))
	{
		alertbox("Voc&ecirc; j&aacute; enviou um pedido para o cl&atilde; com esse personagem","index.php?do=peticionenviar&clid=".$clid."");
	}
	mssql_query("INSERT INTO Peticiones (CID, Personaje, [Level], CLIDClan, Status, Fecha) VALUES ('".$cid."', '".$pj."', '".$lvl."', '".$clid."', '0', GETDATE())");
	alertbox("Pedido enviado Sucesso","index.php");
}?>