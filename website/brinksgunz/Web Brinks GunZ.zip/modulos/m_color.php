<?
$login22 = clean($_SESSION["USERID"]);

if (!(isset($_SESSION["USERID"])))
{
die ("Voc&ecirc; n&atilde;o est&aacute; logado");
}else{

$step = clean($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
  <div class="sub-box1" align="left">
    <p align="center">Voc&ecirc; ir&aacute; gastar <font color="red">500</font> BCoins.<br />
      Selecione a cor de seu nick name:<br />
  <select name="color222" class="text">
    <option value="3">Color 1</option>
    <option value="4">Color 2</option>
    <option value="5">Color 3</option>
    <option value="6">Color 4</option>
    <option value="7">Color 5</option>
    <option value="8">Color 6</option>
  </select><br />
        <input type="hidden" name="color55" value="1" />
        </p>
<div id="log-b">

          <div align="center">
            <input name="color2" type="submit" id="login" align="right" value="Comprar" />
            </div>
    </div></p>
    <div align="center"><br/>
      </div>
  </div>
</form>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = clean($_POST['color222']);

$buscanome = "SELECT euCoins FROM Login WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 8000) 
{
	alertbox("Desculpe, n&atilde;o foi possivel realizar sua compra.","index.php");
	alertbox("Voc&ecirc; n&atilde;o tem BCoins suficiente.","index.php");
	alertbox("Adquira mais BCoins e volte novamente!","index.php");
        alertbox("Obrigado.","index.php");
}else{

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
echo "af, quando fa�o isso no teu gunz n�o gosta n�?";
die();
}



mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE UserID = '$login22'");
mssql_query("update Login set euCoins=euCoins - 500 where UserID='$login22'");
alertbox("Compra realizada com sucesso! Seu nick color j&aacute; est&aacute; em sua conta basta relogar.","index.php");
}
}else{
echo "desculpe, por favor volte p�gina inicial.";
}
}
}
?>