<form method="post" name="rankp" id="rankp">
  <p><font color="#FF0000">A cada 30 dias, o ranking de clan &eacute; resetado.</font><br />
  -------------------------------------------------------------------- </p>
</form>
<p><?php
if(isset($_POST['buscar']))
{
	$nombre = clean($_POST['name']);
	if(empty($nombre))
	{
		alertbox("N&atilde;o deixe espa&ccedil;os em branco","index.php?do=ranking&type=1");
	}
	$q = mssql_query("SELECT * FROM Clan WHERE Name = '".$nombre."'");
	$ran = 0;
}else{
	$q = mssql_query("SELECT TOP 40 * FROM Clan WHERE Name != '' Order by Point Desc");
	$ran = 1;
}
if($ran == 0)
	{
		$i = $r->Ranking;
	}else{
		$i = 1;
	}
if(mssql_num_rows($q)){ ?>
</p>
<div class="sub-box1" align="left">
  <table width="466" align="center">
    <tr>
      <td width="51" align="center"><font color="#FFFFFF"><b>#</b></font></td>
      <td width="105" align="center"><font color="#FFFFFF"><b>Emblema</b></font></td>
      <td width="73" align="center"><font color="#FFFFFF"><b>Nome</b></font></td>
      <td width="116" align="center"><font color="#FFFFFF"><b>Dono</b></font></td>
      <td width="137" align="center"><font color="#FFFFFF"><b>Wins/Losses</b></font></td>
      <td width="137" align="center"><font color="#FFFFFF"><b>Win (%)</b></font></td>
      <td width="137" align="center"><font color="#FFFFFF"><b>Pontos</b></font></td>
    </tr>
    <?	while($r = mssql_fetch_object($q))
	{ 
	$emblemz = $r->EmblemUrl;
	if(empty($emblemz) || !file_exists("./emblems/upload/".$emblemz))
	{
		$emblemz = "noemblem.jpg";
	}
	
?>
    <tr>
      <td align="center"><font color="#FFFFFF">
        <?=$i?>
      </font></td>
      <td align="center"><img width="25" height="20" src="./emblems/upload/<?=$emblemz?>" /></td>
      <td align="center"><a href="./index.php?do=peticion&amp;clid=<?=$r->CLID?>"><font color="#FFFFFF">
        <?=utf8_encode($r->Name)?>
      </font></a></td>
      <td align="center"><font color="#FFFFFF">
        <?=utf8_encode(master($r->MasterCID))?>
      </font></td>
      <td align="center"><font color="#FFFFFF">
        <?=$r->Wins?>
        /
        <?=$r->Losses?>
      </font></td>
      <td align="center"><font color="#FFFFFF">
        <?=ratioclan($r->Wins,$r->Losses)?>
      </font></td>
      <td align="center"><font color="#FFFFFF">
        <?=$r->Point?>
      </font></td>
    </tr>
    <? 
		if($ran = 1)
		{
			$i++;
		}
	}?>
  </table>
  <br/>
</div>
<?
}else{
	echo "<font color='#FFFFFF'>N&atilde;o Cl&atilde;</font>";
}
?>
<br>
<bR>