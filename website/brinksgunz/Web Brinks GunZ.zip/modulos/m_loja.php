<p><a href="./index.php?do=tienda"><img src="../styles/donatori.png" width="459" height="63" border="0" /></a>
</p>
<p><a href="./index.php?do=tienda2"><img src="../styles/eventi.png" width="459" height="63" border="0" /></a></p>
<p><img src="../styles/customa.png" width="459" height="63" /></p>
