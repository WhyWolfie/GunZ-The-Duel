<form name="rankp" method="post">
  <p><font color="#FF0000">Administrador</font> | <font color="#00FF00">GameMaster</font> | <font color="00FFFF">Doador</font>| <font color="#FFFFFF">Player</font> | <font color="#666666">Banido</font><br />
  --------------------------------------------------------------------  </p>
  </form>

<?php
mssql_query("UPDATE Character SET Ranking='0'");
$q = mssql_query("SELECT TOP 100 * FROM Character WHERE Name != '' Order by XP DESC");
$i = 1;
while($r = mssql_fetch_object($q))
{
	mssql_query("UPDATE Character SET Ranking='".$i."' WHERE CID='".$r->CID."'");
	$i++;
}

if(isset($_POST['buscar']))
{
	$nombre = clean($_POST['name']);
	if(empty($nombre))
	{
		alertbox("No Dejes Espacios En Blanco","index.php?do=ranking");
	}
	$q = mssql_query("SELECT * FROM Character WHERE Name = '".$nombre."'");
}else{
	if(isset($_GET['max']))
	{
		$max = clean($_GET['max']);
		if(!is_numeric($max))
		{
			$max = 25;
		}
	}else{
		$max = 25;
	}
	switch($max)
	{
		case 25:
			$order = "WHERE Ranking <= '25'";
			break;
		case 50:
			$order = "WHERE Ranking >= 26 AND Ranking <= 50";
			break;
		case 75:
			$order = "WHERE Ranking >= 51 AND Ranking <= 75";
			break;
		case 100:
			$order = "WHERE Ranking >= 76 AND Ranking <= 100";
			break;
	}
	$q = mssql_query("SELECT * FROM Character ".$order." Order by Ranking ASC");
	
}
$i = 1;
if(mssql_num_rows($q)){ ?>
<div class="sub-box1" align="left">
  <table width="466" align="center">
    <tr>
      <td width="51" align="center"><font color="#FFFFFF"><b>#</b></font></td>
      <td width="105" align="center"><font color="#FFFFFF"><b>Nome</b></font></td>
      <td width="73" align="center"><font color="#FFFFFF"><b>Level</b></font></td>
      <td width="116" align="center"><font color="#FFFFFF"><b>XP</b></font></td>
      <td width="137" align="center"><font color="#FFFFFF"><b>Kill/Deaths (%)</b></font></td>
    </tr>
    <?	while($r = mssql_fetch_object($q))
	{ 
?>
    <tr>
      <td align="center"><font color="#FFFFFF">
        <?=$r->Ranking?>
      </font></td>
      <td align="center"><?=utf8_encode(checarname($r->AID,$r->Name))?></td>
      <td align="center"><font color="#FFFFFF">
        <?=$r->Level?>
      </font></td>
      <td align="center"><font color="#FFFFFF">
        <?=$r->XP?>
      </font></td>
      <td align="center"><font color="#FFFFFF">
        <?=ratiopj($r->KillCount,$r->DeathCount)?>
      </font></td>
    </tr>
    <? $i++;
	}?>
  </table>
  <br/>
</div>
<?
}else{
	echo "<font color='#FFFFFF'>N&atilde;o Contem Personagens</font>";
}
?>
<br />
<a style="color:#FF0" href="./index.php?do=ranking&type=0&max=25">[1-25]</a> <a style="color:#FF0" href="./index.php?do=ranking&type=0&max=50">[26-50]</a> <a style="color:#FF0" href="./index.php?do=ranking&type=0&max=75">[51-75]</a> <a style="color:#FF0" href="./index.php?do=ranking&type=0&max=100">[76-100]</a> 
<br>
<bR>