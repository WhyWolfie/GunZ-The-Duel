<?
if(isset($_POST['change']))
{
	$tipo = clean($_POST['type']);
	$sex = clean($_POST['Sex']);
	redir("./index.php?do=tienda2&tipo=".$tipo."&sex=".$sex);
	
}
?>
<form name="tipoz" method="post">
  <div class="sub-box1" align="left">
    <div align="center"><font color="#FFFFFF">Tipo:
      <select name="type">
        <option value="0">Roupas</option>
        <option value="1">Armas</option>
        <option value="2">Espadas</option>
        <option value="3">Items</option>
        <option selected="selected" value="4">Todos</option>
      </select>
      Sexo:
      <select name="Sex">
        <option value="0">Homem</option>
        <option value="1">Mulher</option>
        </select>
     <input type="submit" value="Buscar" name="change" />
      </font><br/>
      </div>
  </div>
<? 

if(isset($_GET['tipo']) && isset($_GET['sex']))
{
	$tipo = clean($_GET['tipo']);
	$sex = clean($_GET['sex']);
	if($tipo != 4)
	{
		$consulta = " WHERE Tipo = '".$tipo."' AND Sex='".$sex."'";
	}else{
		$consulta = " WHERE Sex='".$sex."'";
	}
}else{
	$tipo = 4;
	$sex = 2;
	$consulta = "";
}


$q = mssql_query("SELECT * FROM Tienda2 ".$consulta. " Order by ID DESC");

	$i = 1;
	$pages = 1;
if(mssql_num_rows($q))
{
	while($r = mssql_fetch_object($q))
	{
		$item[$i][$pages]['Imagen'] = $r->Imagen;
		$item[$i][$pages]['ID'] = $r->ID;
		$item[$i][$pages]['Name'] = $r->Name;
		$item[$i][$pages]['Tipo'] = $r->Tipo;
		$item[$i][$pages]['Sexo'] = $r->Sex;
		$item[$i][$pages]['Level'] = $r->Level;
		$item[$i][$pages]['Precio'] = $r->Precio;
		
		if($i == 6)
		{
			$i = 0;
			$pages++;
		}
		$i++;
	}
	
	if(isset($_GET['page']))
	{
		$page = clean($_GET['page']);
		if(!is_numeric($page))
		{
			alertbox("Error","index.php?do=tienda2");
		}
		if($page > $pages)
		{
			alertbox("Pagina nao existe","index.php?do=tienda2");
		}
	}else{
		$page = 1;
	}
?>
  </font>
  <table border="1" style="border-collapse: collapse" width="500">
    <tr>
      <td width="249" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="249">
            <tr>
              <td width="181">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[1][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="181" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="160">
                    <tr>
                      <td colspan="2"><div align="left"><b><span class="item_name">
                          <font color="#FFFFFF"><?=$item[1][$page]['Name']?> </font>
                      </span></b> </font></div></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Tipo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=gettipo($item[1][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Sexo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=getsex($item[1][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Nivel:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[1][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Pre&ccedil;o:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[1][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar2&amp;id=<?=$item[1][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif1" width="50" height="23" border="0" id="gif1" /></a></span></font></td>
              <td width="181"><font color="#FFFFFF"><span style="width: 55px"><a href="index.php?do=comprar2&amp;id=<?=$item[1][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy1" width="52" height="23" border="0" id="buy1" /><span style="width: 56px"><a href="index.php?do=info2&id=<?=$item[1][$page]['ID']?>"><img src="./images/info.jpg" alt="" name="inf1" width="56" height="23" border="0" id="inf1" /></a></span></font></td>
            </tr>
          </table>
      </div></td>
      <td width="258" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="237">
            <tr>
              <td width="194">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[2][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="194" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="148">
                    <tr>
                      <td colspan="2"><div align="left"> <font color="#FFFFFF"><b><span class="item_name">
                         <font color="#FFFFFF"> <?=$item[2][$page]['Name']?> </font>
                      </span></b> </font></div></td>
                    </tr>
                    <tr>
                      <td width="51" align="left">Tipo:</td>
                      <td width="122"><font color="#FFFFFF">
                        <?=gettipo($item[2][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="51" align="left">Sexo:</td>
                      <td width="122"><font color="#FFFFFF">
                        <?=getsex($item[2][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="51" align="left">Nivel:</td>
                      <td width="122"><font color="#FFFFFF">
                        <?=$item[2][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="51" align="left">Pre&ccedil;o:</td>
                      <td width="122"><font color="#FFFFFF">
                        <?=$item[2][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar&amp;id=<?=$item[2][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif2" width="50" height="23" border="0" id="gif2" /></a></span></font></td>
              <td width="194"><font color="#FFFFFF"><span style="width: 55px"><a href="index.php?do=comprar&amp;id=<?=$item[2][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy2" width="52" height="23" border="0" id="buy2" /><span style="width: 56px"><a href="index.php?do=info&id=<?=$item[2][$page]['ID']?>"><img src="./images/info.jpg" alt="" name="inf2" width="56" height="23" border="0" id="inf2" /></a></span></font></td>
            </tr>
          </table>
      </div></td>
    </tr>
    <tr>
      <td width="249" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="217">
            <tr>
              <td width="194">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[3][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="194" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="128">
                    <tr>
                      <td colspan="2"><div align="left"><font color="#FFFFFF"><b><span class="item_name">
                        <font color="#FFFFFF">  <?=$item[3][$page]['Name']?> </font>
                      </span></b></font></div></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Tipo:</td>
                      <td width="108"><font color="#FFFFFF">
                        <?=gettipo($item[3][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Sexo:</td>
                      <td width="108"><font color="#FFFFFF">
                        <?=getsex($item[3][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Nivel:</td>
                      <td width="108"><font color="#FFFFFF">
                        <?=$item[3][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Pre&ccedil;o:</td>
                      <td width="108"><font color="#FFFFFF">
                        <?=$item[3][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar&amp;id=<?=$item[3][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif3" width="50" height="23" border="0" id="gif3" /></a></span></font></td>
              <td width="194"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=comprar&amp;id=<?=$item[3][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy3" width="52" height="23" border="0" id="buy3" /><span style="width: 56px"><a href="./index.php?do=info&id=<?=$item[3][$page]['ID']?>"><img src="./images/info.jpg" alt="" name="inf3" width="56" height="23" border="0" id="inf3" /></a></span></font></td>
            </tr>
          </table>
      </div></td>
      <td width="258" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="217">
            <tr>
              <td width="194">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[4][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="194" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="128">
                    <tr>
                      <td colspan="2"><div align="left"><font color="#FFFFFF"><b><span class="item_name">
                        <font color="#FFFFFF">  <?=$item[4][$page]['Name']?> </font>
                      </span></b></font></div></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Tipo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=gettipo($item[4][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Sexo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=getsex($item[4][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Nivel:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[4][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Pre&ccedil;o:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[4][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar&amp;id=<?=$item[4][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif4" width="50" height="23" border="0" id="gif4" /></a></span></font></td>
              <td width="194"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=comprar&amp;id=<?=$item[4][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy4" width="52" height="23" border="0" id="buy4" /><span style="width: 56px"><a href="./index.php?do=info&id=<?=$item[4][$page]['ID']?>"><img src="./images/info.jpg" alt="" name="inf4" width="56" height="23" border="0" id="inf4" /></a></span></font></td>
            </tr>
          </table>
      </div></td>
    </tr>
    <tr>
      <td width="249" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="217">
            <tr>
              <td width="194">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top" style="height: 100%"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[5][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="194" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="128">
                    <tr>
                      <td colspan="2"><div align="left"><font color="#FFFFFF"><b><span class="item_name">
                       <font color="#FFFFFF">   <?=$item[5][$page]['Name']?></font>
                      </span></b></font></div></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Tipo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=gettipo($item[5][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Sexo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=getsex($item[5][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Nivel:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[5][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Pre&ccedil;o:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[5][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar&amp;id=<?=$item[5][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif5" width="50" height="23" border="0" id="gif5" /></a></span></font></td>
              <td width="194"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=comprar&amp;id=<?=$item[5][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy5" width="52" height="23" border="0" id="buy5" /></a></span><a href="./index.php?do=info&amp;id=<?=$item[5][$page]['ID']?>"><span style="width: 56px"><img src="./images/info.jpg" alt="" name="inf5" width="56" height="23" border="0" id="inf5" /></a></font></td>
            </tr>
          </table>
      </div></td>
      <td width="258" valign="top"><div align="center">
          <table border="0" style="border-collapse: collapse" width="217">
            <tr>
              <td width="194" valign="top">&nbsp;</td>
            </tr>
            <tr>
              <td width="74" valign="top"><font color="#FFFFFF"><img alt="" border="0" src="./images/tienda/<?=$item[6][$page]['Imagen']?>" width="70" height="70" style="border: 2px solid #171516" /></font></td>
              <td width="194" valign="top"><div align="center">
                  <table border="0" style="border-collapse: collapse" width="128">
                    <tr>
                      <td colspan="2"><div align="left"><font color="#FFFFFF"><b><span class="item_name">
                         <font color="#FFFFFF"> <?=$item[6][$page]['Name']?> </font>
                      </span></b></font></div></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Tipo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=gettipo($item[6][$page]['Tipo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Sexo:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=getsex($item[6][$page]['Sexo'])?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Nivel:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[6][$page]['Level']?>
                      </font></td>
                    </tr>
                    <tr>
                      <td width="42" align="left">Pre&ccedil;o:</td>
                      <td width="118"><font color="#FFFFFF">
                        <?=$item[6][$page]['Precio']?>
                      </font></td>
                    </tr>
                  </table>
              </div></td>
            </tr>
            <tr>
              <td width="74" align="right"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=regalar&amp;id=<?=$item[6][$page]['ID']?>"><img src="./images/gift.jpg" alt="" name="gif6" width="50" height="23" border="0" id="gif6" /></a></span></font></td>
              <td width="194"><font color="#FFFFFF"><span style="width: 55px"><a href="./index.php?do=comprar&amp;id=<?=$item[6][$page]['ID']?>"><a href="./index.php?do=comprar&id=<?=$item[6][$page]['ID']?>"><img src="./images/buy.jpg" alt="" name="buy6" width="52" height="23" border="0" id="buy6" /></a><a href="./index.php?do=info&amp;id=<?=$item[6][$page]['ID']?>"><img src="./images/info.jpg" alt="" name="inf6" width="56" height="23" border="0" id="inf6" /></a></span></font></td>
            </tr>
          </table>
      </div></td>
    </tr>
  </table>
  <font color="#FFFFFF">
<p>&nbsp;</p>
<? for($x = 1; $x<= $pages; $x++)
{
	?>
    <a style="color:#FF0" href="./index.php?do=tienda&page=<?=$x?>&type=<?=$tipo?>&sex=<?=$sex?>"><?=$x?>
    </a>
    <?
}}else{
?>
Nenhum item
<? }?>
    </font>
</form>