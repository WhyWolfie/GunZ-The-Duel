<div class="sub-box1" align="left">
  <p>Abaixo segue a nossa tabela de conduta para o servidor. Atualmente existem 33 artigos que regem essa tabela. A qualquer momento ela poderá ser atualizada ou remanejada de acordo com as necessidades do servidor.<br />
      <br />
    1 - Ofensa leve, que atinjam diretamente a pessoa.<br />
    Punição: De 01 á 05 dias de bloqueio de chat, podendo ser cumulativo. <br />
    OBS: Em casos de ofensa leve, dentro das salas de PVP os casos serão desconsiderados por motivos de estresse devido a pressão de jogo.</p>
  <p>2 - Ofensa pesada a outro usuário, que atinjam diretamente a pessoa, difamando ascendentes, descendentes, etc. <br />
    Punição: De 01 á 05 dias de bloqueio de chat ou dependendo do caso até 05 dias de bloqueio de conta, podendo ser cumulativo.</p>
  <p>3 - Preconceito, discriminação racial, religiosa ou xenofobia que atinjam diretamente a pessoa <br />
    Punição: Bloqueio permanente de chat, dependendo do caso o usuário poderá ter sua conta banida permanentemente do jogo.</p>
  <p>4 - Praticar swap, free-kill ou algo do gênero. <br />
    Punição: Bloqueio permanente das contas dos envolvidos.</p>
  <p>5 - Não é permitido o aproveitamento de bugs (falhas) do jogo e/ou divulgação de bugs a outros jogadores. Qualquer jogador que tirar proveito será considerado um hacker. É obrigatório ao jogador informar a equipe sobre qualquer anormalidade no Brinks GunZ que possa beneficiar alguém de forma incorreta e injusta. <br />
    Punição: Bloqueio permanente de conta.</p>
  <p>6 - Oferecer ou aceitar programas ilegais, que modifiquem o jogo. <br />
    Punição: Bloqueio permanente das contas dos envolvidos.</p>
  <p>7 - É proibido qualquer tipo de alteração no client (hacker, etc), não importando a situação e o motivo da alteração.<br />
    Punição: Bloqueio permanente de conta.</p>
  <p>8 - É proibido fazer qualquer toda a espécie de anúncio ilegal, fazendo propaganda de outros servidores, de sites inadequados, produtos e anúncios enganosos. Comentários existem mas propragandas e divulgação são terminantemente proibidos. <br />
    Punição: Bloqueio permanente de conta.</p>
  <p>9 - A equipe não se responsábiliza por contas hackeadas. O site disponibiliza toda a segurança possível, além de um vasto sistema de recuperação de conta por e-mail. Qualquer tipo de reclamação por conta perdida (por hackers ou qualquer coisa do tipo) é expressamente proibido. Não passe informações pessoais à ninguém (nem a primos, tios, sogras, bozo, etc).<br />
    Punição: Bloqueio permanente de conta do fórum ou até bloqueio de conta do jogo (caso o jogador use a mesma para enviar tickets repetitivos na área de suporte).</p>
  <p>10 - É proibido flood dentro ou fora (no fórum ou na área de suporte) do jogo. Flood é quando uma mensagem é enviada repetitivamente, casos de várias mensagens diferentes e perturbadoras poderão ser considerados casos de flood também.<br />
    Punição: De 01 á 03 dias de bloqueio de chat, podendo ser cumulativo.</p>
  <p>11 - Troca de itens ou troca de itens por bens materias ou dinheiro é terminantemente proibido. Como é algo que infelizmente não pode ser evitado nós da equipe queremos deixar claro que nós não nos responsábilizamos por qualquer item roubado.<br />
    Punição: 30 dias de bloqueio de conta.</p>
  <p>12 - Ofensas, provocações, preconceito ou acusações sem provas (só para provocar) feitas a qualquer membro da equipe do Brinks GunZ é proibido.<br />
    Punição: De 15 á 30 dias de bloqueio de chat, dependendo do caso de 05 á 10 dias de bloqueio de conta ou até mesmo bloqueio permanente de conta, podendo ser cumulativo.</p>
  <p>13 - Nome de personagem ou de clã com apelos sexuais, palavras de baixo calão e nomes preconceituosos.<br />
    Punição: Personagem será renomeado para &quot;Nome_001&quot; (obviamente que o número varia), para retomar um novo nick será preciso enviar um ticket na área de suporte.</p>
  <p>14 - Difamação (declaração pública) no fórum, comunidade ou em jogo, forjar algo que prejudique publicamente a imagem de uma pessoa ou formalizar uma denúncia para prejudicar outro jogador (forjar denúncia).<br />
    Punição: 30 dias de bloqueio de conta, podendo acarretar em Bloqueio permanente da conta (do fórum, comunidade ou em jogo, varia do lugar).</p>
  <p>15 - Ameaçar a integridade física de outro jogador ou de algum membro da equipe. Ameaçar outra pessoa declarando que vai ferir ou matar a pessoa (ameaças fora das questões de jogo).<br />
    Punição: 30 dias de bloqueio de conta, podendo acarretar em Bloqueio permanente da conta.</p>
  <p>16 - Insistir em contestar julgamentos referentes a casos já encerrados pela equipe (sem provas ou sem razão, apenas apelando para pedidos desesperados).<br />
    Punição: 07 dias de bloqueio de conta, podendo acarretar em bloqueio permanente da conta. <br />
    OBS: Usuários não envolvidos na denúncia assumindo um papel de &quot;advogado do réu&quot;, também receberão 07 dias de bloqueio em sua conta ou a mesma pena aplicada ao infrator, caso não prove a inocência do mesmo dentro de um prazo estipulado pela equipe.</p>
  <p>17 - Dizer-se amigo, parente ou íntimo de qualquer membro da equipe, dizer ser ex-membro da equipe ou dar tal impressão para tirar proveito, provocar, ou se proteger.<br />
    Punição: 30 dias de bloqueio de conta, podendo acarretar em bloqueio permanente da conta.</p>
  <p>18 - É proibido se passar por um membro da equipe Brinks GunZ ou, sendo membro, revelar sua identidade como jogador, ou deixar transparecer algo do gênero. Em seu nome são proibidos: [GM], [GM-H], [GM-C], [GM-D], Test, Tester, [Admin], [MOD] ou qualquer termo que simbolize a equipe Brinks GunZ, seja do jogo, seja do Forum ou Comunidade.<br />
    Punição: Bloqueio permanente de conta e bloqueio de outras contas, mediante investigação.</p>
  <p>19 - Exigir qualquer coisa da equipe, bens no jogo, dinheiro, qualquer coisa.<br />
    Punição: Punição: 1 dia de bloqueio de conta. Podendo ser cumulativo.</p>
  <p>20 - Ficar especulando sobre informações pessoais dos membros da equipe, ficar perguntando identidade (nome, MSN pessoal, etc), ficar perguntando dados pessoais ou sabendo estas informações divulga-las no forum, comunidade, em jogo etc.<br />
    Punição: 05 dias de bloqueio de conta, podendo acarretar em bloqueio permanente da conta ( do fórum, comunidade ou em jogo, varia do lugar).</p>
  <p>21 - Utilizar imagem indevida para o emblema do clã, imagem que outro clã esteja usando. Será necessário 3 caracteres consideráveis para diferenciar os nomes.<br />
    Punição: Clã desfeito e seu líder terá bloqueio de conta por 03 dias.</p>
  <p>22 - Jogadores que estiverem lagados serão kikados das salas de evento para não atrapalhar o andamento do mesmo.<br />
    Punição: Kick da sala.</p>
  <p>23 - Será proibida qualquer tipo de troca de itens de evento (Event Coins) ou de recompensa mediante doações (BG Coins) portanto escolha bem o item disponível em nossa loja virtual para não haver transtornos. Não esqueça de tomar cuidado ao comprar um item: atualizar a página várias vezes, vários cliques no botão de comprar etc, podem fazer com que você adquira varios itens sem querer, fique atento.<br />
    Punição: Se insitir na troca terá seu inventário deletado (remoção de todos itens da conta).</p>
  <p>24 - Não aceite qualquer item enviado por estranhos ou por alguém que simplesmente estava oferecendo itens. Essas pessoas podem ter descoberto algum bug no site e tenha abusado deste bug a afim de conseguir vantagem.<br />
    Punição: A conta de quem enviou será banida e a de quem recebeu perderá todos os Itens.</p>
  <p>Finalizações <br />
    Siga e respeite todas as Regras. Importante a leitura das regras pelo menos uma vez por mês para se manter informado. Lendo as regras evitará que sua conta seja banida ou tenha alguma advertência.</p>
  <p>Observações:</p>
  <p>O não conhecimento das regras não justifica cometer ações que não estejam de acordo com nossos termos de uso. Qualquer usuário que infringir as regras, será punido de acordo com o ato cometido mesmo ele dizendo que desconhecia as regras.</p>
  <p>Qualquer usuário que permita que um terceiro se utilize de sua conta para ter acesso ao jogo, fórum ou site é diretamente responsável por todos os atos cometidos por ele, sendo-lhe aplicáveis as punições previstas em caso de descumprimento de regras.</p>
  <br/>
</div>
