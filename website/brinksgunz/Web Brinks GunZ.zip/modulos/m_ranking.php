<center><?php 
if(isset($_GET['type']) && is_numeric($_GET['type'])){
	$type = clean($_GET['type']);
}else{
	$type = 0;
}
if($type == 0){
	include "./modulos/rankp.php";
}elseif($type == 1){
	include "./modulos/rankc.php";
}else{
	alertbox("Error ....","index.php");
}
	?>
	</center>