<? 
if(empty($_SESSION['AID']))
{
	alertbox("Voce Deve Estar logado","index.php");
}

if(admin() == 1)
{
	logz("AID: [".$_SESSION['AID']."] - User: [".$_SESSION['USERID']."] Intento entrar al Panel");
	alertbox("Nao Tem Permicao para entrar Aqui","index.php");
}
?>
<center>
<div class="sub-box1" align="left">
    <div align="center"><a href="./index.php?do=adm&amp;page=noticia">Adicionar Noticias</a> | <a href="./index.php?do=adm&amp;page=ban">Banir Personagem</a> | <a href="./index.php?do=adm&amp;page=buscar">Buscar Conta</a> | <a href="./index.php?do=adm&amp;page=coins">Dar EvCoins</a> | <a href="./index.php?do=adm&amp;page=grado">Dar Admin</a> <br />
      <a href="./index.php?do=adm&amp;page=tienda">Add item shop donate</a> | <a href="./index.php?do=adm&amp;page=tienda2">Add item shop EV</a><br/>
    </div>
  </div>
<p>&nbsp;</p>
<div class="sub-box1" align="left">
  <div align="center">
    <center>
      <?php if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "noticia")
	{
		include "./box/adm/noticia.php";
	}elseif($page == "ban"){
		include "./box/adm/ban.php";
	}elseif($page == "buscar"){
		include "./box/adm/buscar.php";
	}elseif($page == "coins"){
		include "./box/adm/coins.php";
	}elseif($page == "grado"){
		include "./box/adm/grado.php";
	}elseif($page == "tienda"){
		include"./box/adm/tienda.php";
	}elseif($page == "tienda2"){
		include"./box/adm/tienda2.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=adm&page=".$page);
		alertbox("A pagina que voce esta tentando acessar, nao ha nenhuma","index.php?do=adm");
	}
	
}
?>
      <br>
</center>
    </div>
</div>
</center>
