<center><font color="#00FF00"><table border="0" width="38%" style="border-collapse: collapse; border-color: #000000">
<tbody>
  <tr>
    <td height="24" style="background-image: url('./images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top"><div class="sub-box1" align="left">
      <div align="center">Escolha um </font> link para o download do Client.<br />
          <table border="0" width="100%" style="border-collapse: collapse">
            <tbody>
              <tr>
                <td align="center" valign="middle"><a target="_self" href="#"><img border="0" src="./images/descargar.jpg" /></a></td>
                <td align="center" valign="middle"><a target="_self" href="#"><img border="0" src="./images/descargar2.jpg" /></a></td>
                <td align="center" valign="middle"><a target="_self" href="#"><img border="0" src="./images/descargar3.jpg" /></a></td>
              </tr>
            </tbody>
          </table>
      </div>
      <div align="center"></div>
      <br/>
    </div>    </td>
  </tr>
</tbody></table>
</font>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table cellspacing="1" cellpadding="3" border="0" width="100%">
    <tbody>
      <tr>
        <td height="21" bgcolor="#121212" width="75"><span style="font-size: 7pt">&nbsp;</span></td>
        <td height="21" bgcolor="#121212" width="228">Recomendações Mínima </td>
        <td height="21" bgcolor="#121212" width="292">Recomendações Adequadas </td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt">OS</span></td>
        <td bgcolor="#232323" align="center" colspan="2"><span style="font-size: 7pt"> Windows XP, Windows Vista 32/64 bit, Windows 7 32/64 bit</span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> DirectX</span></td>
        <td bgcolor="#232323" align="center" colspan="2"><span style="font-size: 7pt"> DirectX 9.0c o superior</span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> Procesador</span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> Pentium IV 1.0 Ghz</span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> Core 2 Duo 1.33 Ghz </span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> Memoria</span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> 512 MB</span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> 1 GB o más</span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> Tarjeta de Video</span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> Compatible con Direct3D 9.0 </span></td>
        <td bgcolor="#232323" align="center"><span style="font-size: 7pt"> GeForce 4 MX o mejor</span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> Tarjeta de Sonido</span></td>
        <td bgcolor="#232323" align="center" colspan="2"><span style="font-size: 7pt"> Compatible con Direct3D Sound </span></td>
      </tr>
      <tr>
        <td bgcolor="#121212" align="center"><span style="font-size: 7pt"> Mouse</span></td>
        <td bgcolor="#232323" align="center" colspan="2"><span style="font-size: 7pt"> Se recomienda un mouse con Scroll (Ruedita)</span></td>
      </tr>
    </tbody>
  </table>
</center>