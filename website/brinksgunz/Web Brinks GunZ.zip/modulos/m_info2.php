<?php
if(!isset($_GET['id']))
{
	alertbox("Erro na ID","index.php?do=tienda2");
}
$id = clean($_GET['id']);
if(!is_numeric($id))
{
	alertbox("Os numeros de erro -.- Só!","index.php?do=tienda2");
}
$q = mssql_query("SELECT * FROM Tienda2 WHERE ID='".$id."'");
if(!mssql_num_rows($q))
{
	alertbox("O item não existe","index.php?do=tienda2");
}
$r = mssql_fetch_object($q);
?>
<font color="#FFFFFF">
<table border="0" width="560" style="border-collapse: collapse">
    		<tbody><tr>
    			<td width="1">&nbsp;</td>
    			<td width="180">&nbsp;</td>
    			<td colspan="2">&nbsp;</td>
    		</tr>
    		<tr>
    			<td width="1" rowspan="3">&nbsp;</td>
    			<td width="180" valign="top">
    			<div align="center" >
    			    <img height="100" border="0" width="100" style="border: 2px solid #1D1B1C" src="images/tienda/<?=$r->Imagen?>" alt="item">
                </div>
                </td>
    			<td width="315">
    			<div align="center">
  				<table width="100%" border="0" bgcolor="#1e1e1e" style="border-collapse: collapse">
   			  <tbody><tr>
    				<td width="19">&nbsp;</td>
    				<td width="435" colspan="2">
    				<div align="left">
    				  <table width="301" border="0">
                        <tr>
                          <td width="158">Nome:</td>
                          <td width="133"><b><font size="2">
                            <?=$r->Name?>
                          </font></b></td>
                        </tr>
                      </table>
    				</div>                    </td>
    			</tr>
    			<tr>
    				<td width="19">&nbsp;</td>
    				<td align="left" width="435">Tipo: </td>
    				<td align="left" width="372"><?=gettipo($r->Tipo)?></td>
    			</tr>
    			<tr>
    				<td width="19">&nbsp;</td>
    				<td align="left" width="435">Sexo: </td>
    				<td align="left" width="372"><?=getsex($r->Sex)?></td>
    			</tr>
    			<tr>
    				<td width="19">&nbsp;</td>
    				<td align="left" width="435">Nivel: </td>
    				<td align="left" width="372"><?=$r->Level?></td>
    			</tr>
    			<tr>
    				<td width="19">&nbsp;</td>
    				<td align="left" width="435">Preço: </td>
    				<td align="left" width="372"><?=$r->Precio?></td>
    			</tr>
  				</tbody></table>
    			</div>
    			</td>
    			<td width="46" rowspan="3">&nbsp;</td>
    		</tr>
    		<tr>
    			<td colspan="2">&nbsp;</td>
    		</tr>
            
            <tr>
			<td height="144" style="background-image: url('images/mis_iteminfo_bg.jpg'); background-repeat: no-repeat; background-position: center" colspan="2">
			<div align="center">
				<table border="0" width="443" bgcolor="#1e1e1e" style="border-collapse: collapse">
		  <tbody><tr>
    				<td width="143">
    				<div align="center">
    					<table border="1" width="143" style="border-collapse: collapse; border-color: #565053">
  						<tbody><tr>
  							<td align="left" width="71">
                                <span style="font-size: 7pt; font-weight: 700">Peso</span>                            </td>
  							<td align="right" width="56">
                               <?=$r->Peso?>&nbsp;
                            </td>
  						</tr>
  						<tr>
  							<td align="left" width="71">
                                <span style="font-size: 7pt; font-weight: 700">Dano</span>                            </td>
  							<td align="right" width="56"><?=$r->Dano?>&nbsp;
                            </td>
  						</tr>
  						<tr>
  							<td align="left" width="71"><span style="font-size: 7pt; font-weight: 700">Delay</span></td>
  							<td align="right" width="56"><?=$r->Delay?>&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="71"><span style="font-size: 7pt; font-weight: 700">Controle</span></td>
  							<td align="right" width="56"><?=$r->Controlabilidad?>&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="71"><span style="font-size: 7pt; font-weight: 700">Munição</span></td>
						  <td align="right" width="56"><?=$r->Balas?>&nbsp; </td>
  						</tr>
    					</tbody></table>
    				</div>
    				</td>
    				<td width="143">
    				<div align="center">
    					<table border="1" width="160" style="border-collapse: collapse; border-color: #565053">
				    <tbody><tr>
  							<td align="left" width="69"><span style="font-size: 7pt; font-weight: 700">MaxBalas</span></td>
  							<td align="right" width="58"><?=$r->Max_Balas?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="69"><span style="font-size: 7pt; font-weight: 700">HP</span></td>
  							<td align="right" width="58"><?=$r->HP?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="69"><span style="font-size: 7pt; font-weight: 700">AP</span></td>
  							<td align="right" width="58"><?=$r->AP?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="69"><span style="font-size: 7pt; font-weight: 700">Max Peso</span></td>
  							<td align="right" width="58"><?=$r->Max_Peso?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="69"><span style="font-size: 7pt; font-weight: 700">Reload Timer</span></td>
  							<td align="right" width="58"><?=$r->Recarga?>  							  &nbsp;&nbsp;&nbsp; </td>
                            </tbody></table>
    				</div>
    				</td>
    				<td width="159">
    				<div align="center">
    					<table border="1" width="172" style="border-collapse: collapse; border-color: #565053">
				    <tbody><tr>
  							<td align="left" width="45"><span style="font-size: 7pt; font-weight: 700">Duração</span></td>
  							<td align="right" width="82"><?=$r->Duracion?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="45"><b><span style="font-size: 7pt">FR</span></b></td>
  							<td align="right" width="82"><?=$r->FR?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="45"><b><span style="font-size: 7pt">CR</span></b></td>
  							<td align="right" width="82"><?=$r->CR?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="45"><b><span style="font-size: 7pt">PR</span></b></td>
  							<td align="right" width="82"><?=$r->PR?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
  						<tr>
  							<td align="left" width="45"><b><span style="font-size: 7pt">LR</span></b></td>
  							<td align="right" width="82"><?=$r->LR?>  							  &nbsp;&nbsp;&nbsp; </td>
  						</tr>
    					</tbody></table>
    				</div>
    				</td>
    			</tr>
				</tbody></table>
			</div>
			</td>
			</tr>
            
    		<tr>
    			<td colspan="4">&nbsp;</td>
    		</tr>
			</tbody></table>
</font>
<div class="sub-box1" align="left">
  <div align="center"><a href="./index.php?do=regalar2&amp;id=<?=$id?>" style="color:#FF0">Presentiar</a> | <a href="./index.php?do=comprar2&amp;id=<?=$id?>" style="color:#FF0">Comprar</a> | <a href="./index.php?do=tienda2" style="color:#FF0">Voltar</a> <font color="#FFFFFF"></font> <br/>
  </div>
</div>
