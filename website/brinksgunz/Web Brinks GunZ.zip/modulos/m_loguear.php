<?php
if(!empty($_POST['user']) && !empty($_POST['pass']))
{
	$user = clean($_POST['user']);
	$pass = clean($_POST['pass']);
	if(empty($user) || empty($pass))
	{
		alertbox("Preencha os campos obrigatorios","index.php");
	}
	
	$q = mssql_query("SELECT * FROM Login WHERE UserID='".$user."' AND Password='".$pass."'");
	if(mssql_num_rows($q))
	{
		$rr = mssql_fetch_object($q);
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
		$r = mssql_fetch_object($q);
		$_SESSION['USERID'] = $r->UserID;
		$_SESSION['UGRADEID'] = $r->UGradeID;
		$_SESSION['AID'] = $r->AID;
		$_SESSION['FECHA'] = $r->RegDate;
		$_SESSION['NAME'] = $r->Name;
		$_SESSION['COINS'] = $rr->euCoins;
		$_SESSION['COINS2'] = $rr->evcoins;
		echo "<font color='#FFFF00'>Identificados: ".$_SESSION['USERID']."</font>";
		redir("index.php");
	}else{
		alertbox("Dados incorretos","index.php");
	}

    }else{
		alertbox("Preencha os campos obrigat&oacute;rios","index.php");
	}
?>