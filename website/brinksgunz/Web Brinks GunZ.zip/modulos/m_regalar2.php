<?php
if(empty($_SESSION['AID']))
{
	alertbox("Voc&ecirc; n&atilde;o esta logado","index.php?do=panel");
}
if(!isset($_GET['id']))
{
	alertbox("Error","index.php?do=tienda2");
}
if(!is_numeric($_GET['id']))
{
	alertbox("Error","index.php?do=tienda2");
}
$id = clean($_GET['id']);
$q = mssql_query("SELECT * FROM Tienda2 WHERE ID='".$id."'");
if(!mssql_num_rows($q))
{
	alertbox("Error","index.php?do=tienda2");
}
$r = mssql_fetch_object($q);
$itemid = $r->ItemID;

if(isset($_POST['rentdays']))
{
	if(!is_numeric($_POST['rentdays']))
	{
		alertbox("Error","index.php?do=tienda2");
	}
	$renta = clean($_POST['rentdays']);
	$renta = $renta*24;
}

if(!isset($_POST['buy']))
{
?>
  <script type="text/javascript">
    function UpdatePrice()
    {
    	try
    	{
    	    var SelectedDays = document.regalar.rentdays.value;
    	    var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
    	    var Current = document.getElementById("currbalance").innerHTML;

            document.getElementById("dayprice").innerHTML = PricePerDay;

    	    document.getElementById("Total").innerHTML = SelectedDays * PricePerDay + 10;

    	    document.getElementById("afterpur").innerHTML = Current - (SelectedDays * PricePerDay);

    	}
        catch(err)
        {

    	}
    }

    var RecaptchaOptions =
    {
      theme : 'blackglass',
      lang : 'es'
    };

  </script>
  <font color="#FFFFFF">
  <table width="100%" >
    	<tbody><tr>
    		<td>
    		<div align="center">
    			<form name="regalar" method="POST">
                <table width="531" style="border-collapse: collapse">
        <tbody><tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="458" colspan="2">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104" valign="top">
  					<div align="center"><img height="100" border="0" width="100" style="border: 2px solid #1D1B1C" src="images/tienda/<?=$r->Imagen?>" alt="item" /></div>                  </td>
  					<td width="458" colspan="2">
  					<div align="center" >
  						<table border="0" width="370"  bgcolor="#1e1e1e" style="border-collapse: collapse">
    					<tbody><tr>
    						<td width="19">&nbsp;</td>
    						<td width="435" colspan="2"><?=$r->Nome?></td>
    					</tr>
    					<tr>
    						<td width="19">&nbsp;</td>
    						<td align="left" width="61">Tipo:</td>
    						<td align="left" width="372"><?=gettipo($r->Tipo)?></td>
    					</tr>
                        <tr>
    						<td width="19">&nbsp;</td>
    						<td align="left" width="61">Sexo:</td>
    						<td align="left" width="372"><?=getsex($r->Sex)?></td>
  						</tr>
    					<tr>
    						<td width="19">&nbsp;</td>
    						<td align="left" width="61">Nivel:</td>
    						<td align="left" width="372"><?=$r->Level?></td>
    					</tr>
    					<tr>
    						<td width="19">&nbsp;</td>
    						<td align="left" width="61">Preço:</td>
   						  <td align="left" width="372">
    						    <span id="currentprice"><?=$r->Precio?></span>
                                <input type="hidden" value="43" name="itemid">                            </td>
    					</tr>
    					<tr>
    						<td width="19">&nbsp;</td>
    						<td width="435" valign="middle" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" rowspan="5" colspan="2">
    						    <div align="center">Duração do Item:&nbsp;
   							      <select onchange="UpdatePrice()" name="rentdays" size="1" style="background:#0b0b0b; border:1;">
    								<option selected="selected" value="1">1 Dias</option>
                                    <option value="10">10 Dias</option>n>
                                    <option value="30">30 Dias</option>
                                    <option value="50">50 Dias</option>
                                    <option value="60">60 Dias</option>
                                    <option value="70">70 Dias</option>
                                    <option value="80">80 Dias</option>
                                    <option value="90">90 Dias</option>
                                    <option value="100">100 Dias</option>
                                    <option value="366">366 Dias</option>
                                </select>&nbsp;
                                (<span id="dayprice">10</span> Coins por dia)                                </div>    						</td>
    					</tr>
    					<tr>
    						<td width="19">&nbsp;</td>
    					</tr>
  						</tbody></table>
  					</div>  					</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  					<td align="left" width="435" rowspan="4">
  					<div align="center">
  						<table border="0" width="394" style="border-collapse: collapse">
    					<tbody><tr>
    						<td width="419" style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center">
    						<div align="center">
    							<table border="0" width="370"  bgcolor="#1e1e1e" style="border-collapse: collapse">
			            <tbody><tr>
    									<td width="1">&nbsp;</td>
    									<td align="left" width="118"><div align="center">Total:</div></td>
    									<td align="left" width="148"><div align="center"><span id="Total">
    									  <?=$r->Precio?>
  									  </span></div></td>
    									</tr>
    								<tr>
    									<td width="1">&nbsp;</td>
    									<td align="left" width="118"><div align="center">Saldo Autal</div></td>
    									<td align="left" width="148"><div align="center"><span id="currbalance">
    									  <?=$_SESSION['COINS2']?>
  									  </span></div></td>
								    </tr>
    								<tr>
    									<td width="1">&nbsp;</td>
    									<td align="left" width="118"><div align="center">Saldo da Compra:</div></td>
    									<td align="left" width="148"><div align="center"><span id="afterpur"><? echo ($_SESSION['COINS2'] - $r->Precio) ?></span></div></td>
								    </tr>
    								<tr>
    									<td height="1" colspan="3"></td>
    								</tr>
    							</tbody></table>
    						    <table width="200" border="0">
                                  <tr>
                                    <td>&nbsp;</td>
                                  </tr>
                                </table>
    						    <table width="370" border="0" bgcolor="#1e1e1e">

                                  <tr>
                                    <td width="163" bgcolor="#1e1e1e">UserID:</td>
                                    <td width="197" bgcolor="#1e1e1e"><input type="text" name="userid" /></td>
                                  </tr>
                                  <tr>
                                    <td bgcolor="#1e1e1e">Pin:</td>
                                    <td bgcolor="#1e1e1e"><input type="text" name="oldpasswordd" /></td>
                                  </tr>
                                </table>
    						</div></td>
    						<td width="12" style="background-repeat: no-repeat; background-position: left center">&nbsp;</td>
    					</tr>
  						</tbody></table>
  					</div></td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="11" height="39">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="569" colspan="4" align="center"><table width="341" border="0">
                      <tr>
                        <td width="18">&nbsp;</td>
                        <td width="313"> <div id="log-b2"><input type="submit" name="buy" value="Presentiar" />   </div></td>
                      </tr>
                    </table>
  					  <p><br>
				        <!--<a style="color:#FF0" href="./index.php?do=comprar&id=<?=$id?>&itemid=<?=$r->ItemID?>">Comprar</a> | <a href="./index.php?do=tienda" style="color:#FF0">Cancelar</a>-->
				         
			               
		                   <div align="right"></div>
			       
				      </p></td>
  				</tr>
    			</tbody></table>
              </form>
    		</div>
    		</td>
    	</tr>
		</tbody></table>
</font>
<?
}else{
	$userid = clean($_POST['userid']);
	$opasss = clean($_POST['oldpasswordd']);
	if(empty($userid))
	{
		alertbox("Por favor preencha todos os campos.");
	}
	$z = mssql_query("SELECT Pin FROM Login WHERE AID='".$_SESSION['AID']."'");
	$w = mssql_fetch_object($z);
	if($w->Pin != $opasss)
	{
		alertbox("Corriga o seu Pin","index.php?do=tienda2");
	}
	$q = mssql_query("SELECT * FROM Login WHERE UserID='".$userid."'");
	if(!mssql_num_rows($q))
	{
		alertbox("Esse usu&aacute;rio n&atilde;o existe.","index.php?do=tienda");
	}
	$r = mssql_fetch_object($q);
	$aid = $r->AID;
	$q = mssql_query("SELECT * FROM Tienda2 WHERE ID='".$id."' AND ItemID='".$itemid."'");
	if(!mssql_num_rows($q))
	{
		alertbox("Erro o item n&atilde;o existe.","index.php?do=tienda2");
	}
	$r = mssql_fetch_object($q);
	$precio = $r->Precio;
	$q = mssql_query("SELECT * FROM Login WHERE AID='".$_SESSION['AID']."'");
	if(!mssql_num_rows($q))
	{
		alertbox("Voc&ecirc; n&atilde;o est&aacute; logado para efetuar a Compra.","index.php?do=tienda2");
	}
	$r = mssql_fetch_object($q);
	$dinero = $r->evcoins;
	if($dinero < $precio)
	{
		alertbox("Voc&ecirc; n&atilde;o possui BCoins suficiente.","index.php");
	}
	$total = $dinero - $precio;
	if(is_numeric($total))
	{
		mssql_query("UPDATE Login SET evcoins='".$total."' WHERE AID='".$_SESSION['AID']."'");
	mssql_query("INSERT INTO AccountItem (AID, ItemID, RentDate, RentHourPeriod, cnt) VALUES ('".$aid."', '".$itemid."', GETDATE(), '".$renta."', 1)");

	alertbox("O item foi enviado com sucesso para conta: ".$userid,"index.php?do=tienda2");
	}else{
		alertbox("Error","index.php");
	}
	
 } ?>