<?php
 session_start();
 session_destroy();
 redir("index.php");
 /*
		$_SESSION['USERID'] = "";
		$_SESSION['UGRADEID'] = "";
		$_SESSION['AID'] = "";
		$_SESSION['FECHA'] = "";
		$_SESSION['NAME'] = "";
		$_SESSION['COINS'] = "";
		redir("index.php");
		*/
?>