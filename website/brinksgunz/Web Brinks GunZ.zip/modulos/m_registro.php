<center>
<?php
if(!empty($_SESSION['AID']))
{
	alertbox("Voc&ecirc; j&aacute; possui uma conta","index.php");
}
$q = mssql_query("SELECT TOP 1 * FROM Account Order by RegDate DESC");
if(mssql_num_rows($q))
{
	$qq = mssql_fetch_object($q);
}
if(isset($_POST['submit'])){
	$user = clean($_POST['user']);
	$email = clean($_POST['email']);
	$name = clean($_POST['name']);
	//$pais = clean($_POST['pais']);
	$pass = clean($_POST['pass']);
	$pass2 = clean($_POST['pass2']);
	$pass3 = clean($_POST['pass3']);
	
	if(empty($user) || empty($email) || empty($name) || empty($pass2) || empty($pass))
	{
		alertbox("Por favor, preencha todos os campos!","index.php?do=registro");
	}
	
	if(strlen($user) < 6 || strlen($pass) < 6)
	{
	if(strlen($user) > 12 || strlen($pass) > 12)
	{
		alertbox("O Usuario e / ou a senha nao deve ser inferior a Min 6 ou superior a Max 12","index.php?do=registro");
	}}
	
	$q = mssql_query("SELECT * FROM Account WHERE UserID='$user'");
	if(mssql_num_rows($q)){
		alertbox("UserID: $user Esta em uso!","index.php?do=registro");
	}
	
	$q = mssql_query("SELECT * FROM Account WHERE Email='$email'");
	if(mssql_num_rows($q)){
		alertbox("Email: $email Esta em uso!","index.php?do=registro");
	}
	
	if($pass != $pass2){
		alertbox("Senhas nao sao Compativel!","index.php?do=registro");
	}
	do{
		$rando = random1(30);
		$q = mssql_query("SELECT * FROM Login WHERE Password0='".$rando."'");
		if(mssql_num_rows($q))
		{
			$yy = 1;
		}else{
			$yy = 0;
		}
	}while($yy == 1);
	$rando1 = random1(strlen($rando));
	$texto = "Você se registrou com sucesso, mas para ativar sua conta , Voce deve Clicar no Link Ativar sua Conta <br><a href='http://".getUrl()."/index.php?do=activar&code=".$rando."'>Ativar sua Conta</a><br><br>Tenha Bom Jogo  ".$_SESSION['nombregunz'];
	
	if(enviarmail($email,"Registro ".$_SESSION['nombregunz'],$texto) != 0){
		alertbox("Falha ao Cadastrar tente novamente mais tarde!","index.php");
	}
	mssql_query("INSERT INTO Account ([Name], UserID, UGradeID, PGradeID, Email, RegDate) VALUES ('$name', '$user', '0', '0', '$email', GETDATE())");
	$q = mssql_query("SELECT * FROM Account WHERE UserID='$user'");
	$r = mssql_fetch_object($q);
	$aid = $r->AID;
	
	
	if(mssql_query("INSERT INTO Login (AID, UserID, Password, Passwordz, Password0, euCoins, evcoins , pin) VALUES ('".$aid."', '".$user."', '".$rando1."', '".$pass."', '".$rando."', '0','50', '".$pass3."')"))
	{
		
		alertbox("Registro de Usuário: $user Cadastrado Com Sucesso, Verifique Seu email para Ativar Conta $email","index.php");
	}else{
		die("Error");
	}
	
}else{	?>
<br />
<form name="register" method="post">
  <div class="sub-box1" align="left"><font color="#666">UserID</font>:<br/>
    <input name="user" type="text" maxlength="12" />
    <br/>
    <font color="#666">Nome:</font><br/>
    <input type="text" name="name" />
    <br/>
    <font color="#666">Email:</font><br/>
    <input type="email" name="email" />
    <br/>
    <font color="#666">Senha:</font><br/>
    <input name="pass" type="password" maxlength="10" />
    <br/>
    <font color="#666">Confirme a Senha: </font><br/>
    <input name="pass2" type="password" maxlength="10" />
	<br/>
    <font color="#666">Pin: </font><br/>
    <input name="pass3" type="password" maxlength="9" />
    <br/>
    <br />
  <div id="log-b2">
    <input type="submit" name="submit" value="Registrar" />
    <br />
</div>
  </div>
  </form>

<div class="sub-box1" align="left">*Aviso <br />
  1) Use E-mail valido, para ativar sua conta no nosso servidor.<br />
  2) O registro so aceita caracteres a A-Z e 0-9<br />
  3) Pin é Usado para Recuperar senha e Mudar Senha, so aceita caracteres 0-9<br/>
</div>
<p>
  <? } ?>
</p>
</center>
