<div class="sub-box1" align="left">
  <div align="center">Administradores<br/>
  </div>
</div>
<p align="center">&nbsp;</p>
<div class="sub-box1" align="left">
  <div align="center">
    <table width="335" border="0">
      <tr>
        <td width="135"><img src="../styles/troll-face1.jpg" alt="" width="89" height="98" /></td>
        <td width="126"><table width="223" border="0">
            <tr>
              <td width="63">Nome :</td>
              <td width="109">Fellipe Almeida</td>
            </tr>
            <tr>
              <td>Idade :</td>
              <td>18</td>
            </tr>
            <tr>
              <td>Contato :</td>
              <td><!--
Skype 'Skype Me™!' button
http://www.skype.com/go/skypebuttons
-->
<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>
<a href="skype:team.npn?call"><img src="http://download.skype.com/share/skypebuttons/buttons/call_blue_transparent_34x34.png" style="border: none;" width="24" height="23" alt="Skype Me™!" /></a></td>
            </tr>
            <tr>
              <td>Nick:</td>
              <td>TeamNpN</td>
            </tr>
        </table></td>
      </tr>
      </table>
    <table width="335" border="0">
      <tr>
        <td width="135"><img src="../styles/troll-face1.jpg" alt="" width="89" height="98" /></td>
        <td width="126"><table width="223" border="0">
            <tr>
              <td width="79">Nome :</td>
              <td width="134">Leandro Souza</td>
            </tr>
            <tr>
              <td>Idade :</td>
              <td>16</td>
            </tr>
            <tr>
              <td>Contato:</td>
              <td><a href="skype:leanroox?call"><img src="http://download.skype.com/share/skypebuttons/buttons/call_blue_transparent_34x34.png" style="border: none;" width="24" height="23" alt="Skype Me™!" /></a></td>
            </tr>
            <tr>
              <td>Nick:</td>
              <td>ROX-</td>
            </tr>
        </table></td>
      </tr>
      </table>
    <br/>
  </div>
</div>
<p>&nbsp;</p>
<div class="sub-box1" align="left">
  <div align="center">GameMaster<br/>
  </div>
</div>
<p>&nbsp;</p>
<div class="sub-box1" align="left">
  <div align="center">
    <table width="335" border="0">
      <tr>
        <td width="135"><img src="../styles/troll-face1.jpg" alt="" width="70" height="79" /></td>
        <td width="126"><table width="223" border="0">
          <tr>
            <td width="63">Nome :</td>
            <td width="109">André Silva</td>
          </tr>
          <tr>
            <td>Idade :</td>
            <td>14</td>
          </tr>
          <tr>
            <td>Contato :</td>
            <td><!--
Skype 'Skype Me™!' button
http://www.skype.com/go/skypebuttons
-->
<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>
<a href="skype:andre-losty...?call"><img src="http://download.skype.com/share/skypebuttons/buttons/call_blue_transparent_34x34.png" style="border: none;" width="24" height="23" alt="Skype Me™!" /></a></td>
          </tr>
          <tr>
            <td>Nick:</td>
            <td>Losty</td>
          </tr>
        </table></td>
      </tr>
    </table>
    <table width="335" border="0">
      <tr>
        <td width="135"><img src="../styles/troll-face1.jpg" alt="" width="70" height="79" /></td>
        <td width="126"><table width="223" border="0">
            <tr>
              <td width="63">Nome :</td>
              <td width="109">Paulo Leme</td>
            </tr>
            <tr>
              <td>Idade :</td>
              <td>17</td>
            </tr>
            <tr>
              <td>Contato :</td>
              <td><!--
Skype 'Skype Me™!' button
http://www.skype.com/go/skypebuttons
-->
<script type="text/javascript" src="http://download.skype.com/share/skypebuttons/js/skypeCheck.js"></script>
<a href="skype:pauloleme_?call"><img src="http://download.skype.com/share/skypebuttons/buttons/call_blue_transparent_34x34.png" style="border: none;" width="24" height="23" alt="Skype Me™!" /></a></td>
            </tr>
            <tr>
              <td>Nick:</td>
              <td>Leme</td>
            </tr>
        </table></td>
      </tr>
    </table>
    <p><br/>
      </p>
  </div>
</div>
<p>&nbsp;</p>
