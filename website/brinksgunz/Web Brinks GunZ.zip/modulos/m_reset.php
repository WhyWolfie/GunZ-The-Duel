<?php
if(isset($_POST['reset']))
{
	$user = clean($_POST['user']);
	$opasss = clean($_POST['oldpasswordd']);
	$tmp = clean($_POST['captch']);
	if(empty($user) || empty($tmp))
	{
		alertbox("N&atilde;o deixa  espa&ccedil;os vazios","index.php?do=reset");
	}
	
	if($tmp != $_SESSION['tmptxt'])
	{
		alertbox("O c&oacute;digo est&aacute; incorreto","index.php?do=reset");
	}
	$w = mssql_query("SELECT UserID, Pin FROM Login WHERE UserID='".$user."'");
	if(!mssql_num_rows($w))
	{
		alertbox("UserID não existe","index.php?do=reset");
	}else{
		$r = mssql_fetch_object($w);
		if($r->Pin != $opasss ){
			alertbox("Corriga o seu Pin","index.php");
		}
	}
	$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	if(!mssql_num_rows($q))
	{
		alertbox("UserID n&atilde;o existe","index.php?do=reset");
	}else{
		$r = mssql_fetch_object($q);
		if($r->Code != 0 || $r->Code != ""){
			alertbox("Como n&atilde;o h&aacute; um c&oacute;digo, dispon&iacute;vel em sua conta, verifique seu e-mail, checo poderia ser na &aacute;rea de Spam ","index.php");
		}
	}
	
	do{
		$code = random1(40);
		$q = mssql_query("SELECT * FROM Login Where Code='".$code."'");
		if(mssql_num_rows($q))
		{
			$y = 1;
		}else{
			$y = 0;
		}
	}while($y == 1);
	mssql_query("UPDATE Login SET CodeFecha=GETDATE(), Code='".$code."' WHERE AID='".$r->AID."'");
	$texto = "Voc&ecirc; foi enviado um email com o endereço onde poder&aacute; alterar sua senha, <br> Este link é v&aacute;lido apenas 1 vez
	<a href='http://".getUrl()."/index.php?do=reset2&code=".$code."&aid=".$r->AID."'>Mudar Sua Senha</a><br>Codigo e v&aacute;lido ate 15 Dias";
	enviarmail($r->Email,"Recuperar Senha",$texto);
	alertbox("Voc&ecirc; foi enviado um e-mail com instru&ccedil;&otilde;es para redefinir sua senha, o c&oacute;digo é v&aacute;lido por 15 dias","index.php");
}else{
?>
<form name="resetz" method="post">
<center>
  <div class="sub-box1" align="left">
    <div align="center">Digite Usuario :<br />
        <input type="text" name="user" />
        <br />
		Pin :<br />
        <input type="text" name="oldpasswordd" />
        <br />
        </font>Verificar o código:</span> :<font color="#00FF00"><br />
        <input type="text" name="captch" />
        <br />
        <img src="./modulos/captcha.php" width="100" height="30" vspace="3" /><br />
        <br />
         <div id="log-b2"><input type="submit" name="reset" value="Recuperar" /></div>
          </font><br/>
      </div>
  </div>
  </center>
</form>
<? } ?>