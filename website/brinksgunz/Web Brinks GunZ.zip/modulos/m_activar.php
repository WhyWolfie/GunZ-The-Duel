<?php
if(isset($_GET['code']))
{
	$code = clean($_GET['code']);
	$q = mssql_query("SELECT * FROM Login WHERE Password0='$code'");
	$r = mssql_fetch_object($q);
	if(mssql_num_rows($q)){
		$q = mssql_query("SELECT * FROM Account WHERE AID='".$r->AID."'");
		$r = mssql_fetch_object($q);
		mssql_query("UPDATE Login SET Password=Passwordz, Passwordz='0', Password0='0' WHERE Password0='".$code."'");
		enviarmail($r->Email,"Bem Vindo ao ".$_SESSION['nombregunz'],"Bem Vindo  ao ".$_SESSION['nombregunz']."<br>
		Esperamos que a sua estadia voc&ecirc; vai se divertir e se divertir<br>By. Staff do ".$_SESSION['nombregunz']);
		alertbox("Conta: ".$r->UserID." Ativada com Sucesso!","index.php");
	}else{
		alertbox("C�digo Invalido","index.php");
	}
}else{
	alertbox("Voc&ecirc; n&atilde;o inseriu nenhum c&oacute;digo","index.php");
}
?>