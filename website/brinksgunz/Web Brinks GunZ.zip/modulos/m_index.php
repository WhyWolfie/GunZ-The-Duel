<?php
$q = mssql_query("SELECT TOP 3 * FROM Noticias WHERE Tipo='0' Order by ID DESC");
if(!mssql_num_rows($q))
{ ?>
<div id="newsbox2">
          <div id="newsboximgs"> <img src="images/content3/newsboximg1.png" /> </div>
          <h2>N&atilde;o Cont&eacute;m not&iacute;cias</h2>
  <h2 class="date"><?=date("d/M/Y g:i a")?></h2>
          <p class="left">N&atilde;o Cont&eacute;m not&iacute;cias.</p>
          
</div>
<p>
  <? }else{
	while($r = mssql_fetch_object($q))
	{
		?>
</p>
<div class="sub-box1" align="left"><h2>Titulo:
    <?=utf8_encode($r->Titulo)?>
    Autor:
  <?=utf8_encode($r->UserID)?>
  <br/>
</div>
<div class="sub-box1" align="left">
  <h2>
    Noticias: <?=utf8_encode($r->Texto)?>
  </h2>
  <h2>    <span class="date">Data de Emiss&atilde;o:
    <?=$r->Fecha?>
      </span><br/>
  </h2>
</div>
<p>&nbsp;</p>
<? }
}
?>
<br />
