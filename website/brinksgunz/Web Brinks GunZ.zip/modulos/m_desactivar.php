<?php
if(!isset($_SESSION['AID']))
{
	alertbox("Quem &eacute; voc&ecirc;? -.-!","index.php");
}

if(!isset($_GET['cid']) || !isset($_GET['id']))
{
	alertbox("Error","index.php");
}
if(!is_numeric($_GET['cid']) || !is_numeric($_GET['id']))
{
	alertbox("Error","index.php");
}

$cid = clean($_GET['cid']);
$id = clean($_GET['id']);
if($id != 1 && $id != 0)
{
	alertbox("Error","index.php");
}
$q = mssql_query("SELECT * FROM Clan a INNER JOIN Character b ON a.MasterCID=b.CID WHERE b.AID='".$_SESSION['AID']."' AND a.MasterCID='".$cid."'");
if(!mssql_num_rows($q))
{
	alertbox("Voc&ecirc; n&atilde;o &eacute; nada para estar fazeno aqui!","index.php");
}

mssql_query("UPDATE Clan SET Peticion='".$id."' WHERE MasterCID='".$cid."'");
if($id == 0)
{
	alertbox("Ativada Petiçoes","index.php");
}else{
	alertbox("Desativado Petiçoes","index.php");
}
?>