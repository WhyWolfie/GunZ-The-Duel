<link href="../default.css" rel="stylesheet" type="text/css" />
<?
$conn = @mssql_connect($DBHost, $DBUser, $DBPass);
@mssql_select_db($DB);
$d = "Ly8vLy8gQ29kZWFkbyBwb3IgRGlvc3o=";
if(!isset($_GET['step'])) {
    $_GET['step'] = 1;
}
 
// Codeado por Diosz
if (isset($_GET['step'])) {
    $argv = explode('-',$_GET['step']);
    settype($argv,'array');
    $_GET['step'] = @$argv[0];
    $_GET['url'] = @$argv[1];
    $_GET['do'] = @$argv[2];
    $_GET['mess'] = @$argv[3];
}
$step = !isset($_GET['step']) ? home : $_GET['step'] ;
        if ($step == '2') { ?>
<title><?=$_SESSION['nombregunz']?></title>
 
<?
 } if ($step == '1') {
  
$user1 = clean($_SESSION['USERID']);
//$pass1 = clean();
    
 
 $query = mssql_query("SELECT AID From Login Where UserID = '$user1'");
            while($r = mssql_fetch_array($query)){
if (mssql_num_rows($query) == 1){
                         
                        $query2 = mssql_query("
SELECT     Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID
FROM         ClanMember INNER JOIN
                      Clan ON ClanMember.CLID = Clan.CLID INNER JOIN
                      Login INNER JOIN
                      Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and ClanMember.Grade = '1' ");
                      if (mssql_num_rows($query2)){ ?>
<div class="sub-box1" align="left">
  <p align="center" class="style1">Aviso do Clan Emblema</p>
  <p align="center" class=""> 1.- Clan Emblema So Aceita png <br />
  2.- Tamanho maximo da Foto é de 57x56. </p>
  <p align="center" class=""><strong>Leia as Descrição Acima.</span><br/>
  </p>
</div>
<div class="sub-box1" align="left">
  <p align="center">Selecione a imagem:  </p>
  <p align="center">
    <input name="uploaded" type="file" />
  </p>
  <p align="center">Selecione o Clan:</p>
  <p align="center">
    <select name="clan">
      <?
                            for($i='';$i < @mssql_num_rows($query2);++$i){
                            $row = @mssql_fetch_row($query2);
                            $ClanName = $row[4]; ?>
      <option value="<?=$row[4]?> ">
      <?=$row[4]?>
      </option>
      <? }?>
    </select>
  </p>
  <p align="center">
  
<div id="log-b"> 
     <div align="center"></div>
  </div>
    <br/>
</p>
</div>
<?
                            }else { echo '<font color="#FFFFFF">Voce nao e Dono Clan</font><br>';
							echo '<p>&nbsp;</p>';} }
                            }
            ;
        } 
     
    ;
     
    if ($step == 'done') {                  
    $emblem = $_POST['uploaded'] ;
    $CLID = $_POST['clan'];
$target = "./emblems/upload/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$ok=1;
$ext = pathinfo($target);
$EXT1 = strtolower($ext['extension']);
$f = $ext['basename'];
if($EXT1 != "jpg" && $EXT1 != "png" && $EXT1 != "jpeg") {
    $ok = 0; } else { $ok = 1; }
 
 
//
 
 
if ($ok==0)
{
alertbox("Erro! Sua imagem não carregar, verificar a extensão eo tipo de arquivo.","index.php?do=emblemaindex&step=1");
 
}
 
else
{
        $q = mssql_query("SELECT * From Clan Where Name='$CLID'");
$s = mssql_fetch_assoc($q);
if(!empty($s['EmblemUrl'])) { $g = pathinfo($s['EmblemUrl']); unlink("./emblems/upload/".$g['basename']); }
if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
{
     
do {
$archivo = Random();
$archivo = $archivo . ".";
$archivo = $archivo . $EXT1;
} while(file_exists($archivo));
 
    rename("./emblems/upload/".$f,"./emblems/upload/".$archivo);
mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
mssql_query ("UPDATE Clan SET EmblemUrl = '".clean($archivo)."' WHERE Name = '$CLID'");
alertbox("Parabens Seu Clan Agora Tem Emblema.","index.php");
 
}
else
{
alertbox("Erro! Houve um problema ao tentar carregar a imagem","index.php?do=emblema&step=1");
}
}
};

?>
<img src="./images/buttonokwu8.gif" alt="" class="hand" onclick="regform.submit()"/>