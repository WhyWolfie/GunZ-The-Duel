<?php
$q = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
if(isset($_POST['update']))
{
	$nombre = clean($_POST['nombre']);
	$edad = clean($_POST['edad']);
	$email = clean($_POST['email']);
	if(!is_numeric($edad))
	{
		alertbox("A idade deve ser apenas n&uacute;meros","index.php");
	}
	
	mssql_query("UPDATE Account SET Name='".$nombre."', Age='".$edad."', Email='".$email."' WHERE AID='".$_SESSION['AID']."'");
	
	alertbox("Foi Alterada com Sucesso","index.php?do=panel");
	
}else{

?>
<form name="datos" method="post">
<div class="sub-box1" align="left">
  <table align="center">
    <tr>
      <td><b>Nome :</b></td>
      <td><input type="text" name="nombre" value="<?=$r->Name?>" /></td>
    </tr>
    <tr>
      <td><b>Idade :</b></td>
      <td><input type="number" name="edad" value="<?=$r->Age?>" /></td>
    </tr>
    <tr>
      <td><b>Email :</b></td>
      <td><input type="email" name="email" value="<?=$r->Email?>" /></td>
    </tr>
    <tr>
      <td></td>
      <td><div id="log-b">
        <input type="submit" name="update" value="Atualizar" />
      </div></td>
    </tr>
  </table>
  <br/>
</div>
<span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas"></span>&nbsp;<span title="Clique para mostrar tradu&ccedil;&otilde;es alternativas"></span> </font>
</form>
<? } ?>