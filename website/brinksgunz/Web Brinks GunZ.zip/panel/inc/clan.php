<div id="pos">
<br /><div id="ststitle">Delete Clan :</div><br />
<form action="index.php?page=clan" method="post">
<?php	
$query2 = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag='0'");
if (mssql_num_rows($query2) >1){
 echo "<select name='clan'>";
while ($cha = mssql_fetch_assoc($query2)){

$clanq = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$cha['CID']."'");
if (mssql_num_rows($clanq) <> 0){
 $clanq2 = mssql_fetch_assoc($clanq);
if($clanq2['Grade'] == 9 OR $clanq2['Grade'] == 2){
  $msg = "Voc&ecirc; n&atilde;o &eacute; dono cl&atilde;"; alert($msg);
  redirect("index.php");
}else{
  $clani2 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."' AND DeleteFlag='0'");
  $clani3 = mssql_fetch_assoc($clani2);
   echo "<option value='".$clani3['Name']."'>";
   echo $clani3['Name'];
   echo "</option>";
 }
}
}
  echo "</select>";
}
?>
 <input type="submit" name="deleteclan" value="Delete Clan" />
</form>
<?php
if(isset($_POST['deleteclan'])){
 $clan = $_POST['clan'];

  $sql = mssql_query("DELETE FROM ClanMember WHERE CLID='".$clanq2['CLID']."'");
  $query = mssql_query("UPDATE Clan SET Name = NULL, DeleteFlag = 1, DeleteName='$clan' WHERE CLID='".$clanq2['CLID']."'");

  $msg = "Cl&atilde; deletado com sucesso."; alert($msg);
  redirect("index.php");
}
?>
</div>