<?php
if(isset($_POST['changepassword']))
{
	$opass = clean($_POST['oldpassword']);
	$opasss = clean($_POST['oldpasswordd']);
	$npass = clean($_POST['newpassword']);
	$npass1 = clean($_POST['repeatnewpassword']);
	if(empty($opass) || empty($npass) || empty($npass1) || empty($npasss))
	{
		alertbox("Preencha os campos obrigatorios","index.php?do=panel&page=pass");
	}
	if($npass != $npass1)
	{
		alertbox("As senhas n&atilde;o correspondem","index.php?do=panel&page=pass");
	}
	$q = mssql_query("SELECT * FROM Login WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
	if($r->Password != $opass)
	{
		alertbox("A senha atual incorreta","index.php?do=panel&page=pass");
	}
	$z = mssql_query("SELECT Pin FROM Login WHERE AID='".$_SESSION['AID']."'");
	$w = mssql_fetch_object($z);
	if($w->Pin != $opasss)
	{
		alertbox("Pin incorreto","index.php?do=panel&page=pass");
	}
	mssql_query("UPDATE Login SET Password='".$npass."' WHERE AID='".$_SESSION['AID']."'");
	alertbox("Senha alterada com sucesso","index.php?do=panel");
}else{
	?>
    <form name="pass" method="post">
    <div class="sub-box1" align="left">
      <table align="center">
        <tr>
          <td><b> Senha Atual  :</b></td>
          <td><input name="oldpassword" type="password" maxlength="12" /></td>
        </tr>
		 <tr>
          <td><b> Pin  :</b></td>
          <td><input name="oldpasswordd" type="password" maxlength="12" /></td>
        </tr>
        <tr>
          <td><b>Nova Senha :</b></td>
          <td><input name="newpassword" type="password" maxlength="12" /></td>
        </tr>
        <tr>
          <td><b>Repita Nova Senha :</b></td>
          <td><input name="repeatnewpassword" type="password" maxlength="12" /></td>
        </tr>
        <tr>
          <td></td>
          <td><div id="log-b">
            <input type="submit" name="changepassword" value="Mudar" />
          </div></td>
        </tr>
      </table>
      <br/>
    </div>
    </font>
</form>
<? } ?>