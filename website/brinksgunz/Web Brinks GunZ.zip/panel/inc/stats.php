<font color="#00FF00">
</font>
<div id="us">
  <div class="sub-box1" align="left">
    <p><strong>Meus Personagens</strong></p>
  </div>
  <div class="sub-box1" align="left"><font color="#00FF00"><?php
$query = mssql_query("SELECT TOP 4* FROM Character WHERE AID = '".$_SESSION['AID']."' AND Name != '' AND DeleteFlag = 0 ORDER BY Level DESC");
if ( mssql_num_rows($query) < 1 ){
echo '<font color="#ff0000">N&atilde;o Cont&eacute;m Personagens.';
}else{
?>
  <table border='0' style='border-collapse:collapse' width='434'>
    <tr height='23' style='font-weight:bold;color:#00FF00;'>
        <td align="center">Nome</td>
        <td align="center">Nivel</td>
        <td align="center">Experiencia</td>
        <td align="center">Sexo</td>
        <td align="center">Kills</td>
        <td align="center">Deaths</td>
      </tr>
      <?
$i = 1;
while ( $i <= mssql_num_rows($query) ){
$chars = mssql_fetch_assoc($query);
?>
      <tr style="font-size:11px;">
        <td align="center" width="70"><?=master($chars['CID'])?></td>
        <td width="30" align="center"><?=$chars['Level']?></td>
        <td width="97" align="center"><?=$chars['XP']?></td>
        <td width="79" align="center"><?=Sex($chars['Sex'])?></td>
        <td width="50" align="center"><?=$chars['KillCount']?></td>
        <td width="82" align="center"><?=$chars['DeathCount']?></td>
      </tr>
      <?
$i++;
}?>
    </table>
  <font color="#00FF00"><?
}
?>
  </font><br/>
    </font></div>
<div class="logged_dline">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

<div class="sub-box1" align="left"><strong>Cl&atilde;s</strong><br/>
</div>
<div class="sub-box1" align="left">
  <font color="#00FF00"><p>
    <font color="#00FF00"><?		
$query2 = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND Name != '' ORDER BY CharNum ASC");
if (mssql_num_rows($query2)){
?>
  </font></p>
  <table border='0' style='border-collapse: collapse' width='434'>
    <tr height='23' style='font-weight:bold;color:#00FF00;'>
      <td width="85" align="center">Nome</td>
      <td width="116" align="center">Dono</td>
      <td width="58" align="center">Wins</td>
      <td width="79" align="center">Losses</td>
      <td width="74" align="center">Draws</td>
    </tr>
    <?
while ($cha = mssql_fetch_assoc($query2)){

$clanq = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$cha['CID']."'");
if (mssql_num_rows($clanq) != 0){
$clanq2 = mssql_fetch_assoc($clanq);
if($clanq2['Grade'] == 9){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
    <tr style='font-size:11px;'>
      <td align="center"><?=$claninfo['Name']?></td>
      <td align="center"><?=Char($cha['CID'])?></td>
      <td align="center"><?=$claninfo['Wins']?></td>
      <td align="center"><?=$claninfo['Losses']?></td>
      <td align="center"><?=$claninfo['Draws']?></td>
    </tr>
    <?
}
}else
if($clanq2['Grade'] == 1){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
    <tr style='font-size:11px;'>
      <td align="center"><?=$claninfo['Name']?></td>
      <td align="center"><?=Char($cha['CID'])?></td>
      <td align="center"><?=$claninfo['Wins']?></td>
      <td align="center"><?=$claninfo['Losses']?></td>
      <td align="center"><?=$claninfo['Draws']?></td>
    </tr>
    <?
}
}else
if($clanq2['Grade'] == 2){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
    <tr style='font-size:11px;'>
      <td align="center"><?=$claninfo['Name']?></td>
      <td align="center"><?=Char($cha['CID'])?></td>
      <td align="center"><?=$claninfo['Wins']?></td>
      <td align="center"><?=$claninfo['Losses']?></td>
      <td align="center"><?=$claninfo['Draws']?></td>
    </tr>
    <?
}
}
}
}
}
?>
  </table>
<br/>
</font></div>
</div>

<p><font color="#00FF00"></font>
</p>
</p>
<p>&nbsp;</p>
