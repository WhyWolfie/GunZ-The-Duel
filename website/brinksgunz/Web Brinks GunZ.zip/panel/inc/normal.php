<font color="#FFFFFF">
Bem Vindo, <?=$_SESSION['USERID'];?><br>
Tipo: <?=staff()?><br>
BCoins: <?=$_SESSION['COINS']?><br>
EvCoins: <?=$_SESSION['COINS2']?>
</font>