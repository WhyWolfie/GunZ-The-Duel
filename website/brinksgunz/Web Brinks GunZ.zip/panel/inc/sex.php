<?php
if(isset($_POST['cambiar'])){
$pj = clean($_POST['pjs']);
$sex = clean($_POST['sex']);
if(empty($pj) || $sex != 0 && $sex != 1)
{
	alertbox(" Error Inesperado ","index.php");
}
mssql_query("UPDATE Character SET Sex='".$sex."' WHERE AID='".$_SESSION['AID']."' AND CID='".$pj."'");
alertbox("Cambios Realizados Exitosamente","index.php?do=panel");
}else{
?>
<form name="sex0" method="post">
<div class="sub-box1" align="left">
  <div align="center">
    <?php
$q = mssql_query("SELECT * FROM Character WHERE AID ='".$_SESSION['AID']."' AND NAME != '' Order by CharNum ASC");
if(mssql_num_rows($q))
{
	?>
    Personagem:
    <select name="pjs">
      <?
	while($r = mssql_fetch_object($q))
	{
		?>
      <option value="<?=$r->CID?>">
        <?=$r->Name?>
        </option>
      <?
	} ?>
    </select>
    Sexo:
    <select name="sex">
      <option value="0">Homem</option>
      <option value="1">Mulher</option>
    </select>
    <br />
    <br />
     <div id="log-b2"><input type="submit" name="cambiar" value="Trocar" /></div>
    <?
}else{
	?>
    <? }  ?>
    <br/>
  </div>
</div>
</form>
<? } ?>