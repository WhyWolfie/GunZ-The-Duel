<? if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "edit")
	{
		include "./panel/inc/edit.php";
	}elseif($page == "pass"){
		include "./panel/inc/pass.php";
	}elseif($page == "stats"){
		include "./panel/inc/stats.php";
	}elseif($page == "sex"){
		include "./panel/inc/sex.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=panel&page=".$page);
		alertbox("La Pagina A La Que Intentas Acceder, No Existe","index.php?do=panel");
	}
	
}else{
}?>