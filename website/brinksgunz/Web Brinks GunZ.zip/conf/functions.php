<?php
function sumaDia($fecha,$dia)
{list($day,$mon,$year) = explode('/',$fecha);
return date('d/m/Y',mktime(0,0,0,$mon,$day+$dia,$year));} 
function update()
{
	if(!empty($_SESSION['AID']))
	{
		$q = mssql_query("SELECT * FROM Account a INNER JOIN Login b ON a.AID=b.AID WHERE a.AID='".$_SESSION['AID']."'");
		$r = mssql_fetch_object($q);
		$_SESSION['UGRADEID'] = $r->UGradeID;
		$_SESSION['COINS'] = $r->euCoins;
	}
		$fecha = date("d/m/Y");
		$q = mssql_query("SELECT * FROM Login WHERE Code != '0' Or Code=''");
		if(mssql_num_rows($q))
		{
			$q = mssql_query("SELECT * FROM Login WHERE DateDIFF(d, CodeFecha, '$fecha') > 15");
			if(mssql_num_rows($q))
			{
				while($r = mssql_fetch_object($q))
				{
					mssql_query("UPDATE Login SET Code='0', CodeFecha='$fecha' WHERE AID='".$r->AID."'");
				}
			}
		}
}
function lvl()
{
	$q = mssql_query("SELECT TOP 1 * FROM LevelUpLog a INNER JOIN Character b ON a.CID=b.CID Order by Date DESC");
	if(mssql_num_rows($q))
	{
		$r = mssql_fetch_object($q);
		return "Personatem ".$r->Name." Subio a:	".$r->Level;
	}else{
		return "Apesar de algumas informacoes no Show";
	}
}
function kill()
{
	$q = mssql_query("SELECT TOP 1 * FROM KillLog Order by Time DESC");
	if(mssql_num_rows($q))
	{
		$r = mssql_fetch_object($q);
		return master($r->AttackerCID)." Mato a:	".master($r->VictimCID);
	}else{
		return "Apesar de algumas informacoes no Show";
	}
}
function clan()
{
	$q = mssql_query("SELECT TOP 1 * FROM ClanGameLog Order by RegDate DESC");
	if(mssql_num_rows($q))
	{
		$r = mssql_fetch_object($q);
		return "Clan Win".$r->WinnerClanName." Clan Loser ".$r->LoserClanName." ".$r->RoundWins."/".$r->RoundLosses;
	}else{
		return "Apesar de algumas informacoes no Show";
	}
}
function titulo($web)
{
	switch($web)
	{
		case "registro":
			return "Registrar";
		
		case "descarga":
			return "Download";
			
		case "ranking":
			return "<a style='color:#FFF' href='./index.php?do=ranking&type=0'>Ranking Player </a> - <a style='color:#FFF' href='./index.php?do=ranking&type=1'>Ranking Clan</a>";
			
		case "tienda":
			return "Loja Donate";
			
		case "tienda2":
			return "Loja Evento";	
			
		case "panel":
			return "User Panel";
		
		case "adm":
			return "Panel Staff";
			
		case "reset":
			return "Recuperar Senha";
		
		case "clan":
			return "Clan";
			
		case "emblema":
			return "Clan Emblema";
			
		case "peticion":
			return "Informa&ccedil;&atilde;o de Clan";
		
		case "peticionenviar":
			return "Enviar Pedido";
		
		case "info":
			return "Informacion del ItemID";	
			
		case "comprar":
			return "Comprar Item";
		
		case "regalar":
			return "Presente Item";
			
		case "regras":
			return "Regras do Servidor";
		
		case "equipe":
			return "In-game Brinks Gunz";
					
		case "color":
			return "Comprar Nick Color";
		
		case "loja":
			return "Menu Loja";
		
		default:
			return "Not&iacute;cias &amp; Atualiza&ccedil;&otilde;es";
	}
}
function Char($cid){
$ncid = clean($cid);
$query = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));
$name = $query[1];
switch($query[0]){
case 255:
return "<font color='#FF0000'>$name</font>";
break;
case 254:
return "<font color='#FF8040'>$name</font>";
break;
case 252:
return "<font color='#0033FF'>$name</font>";
break;
default:
return $name;
break;
}
}
function Sex($tipo)
{
	if($tipo == 0)
	{
		return "Homem";
	}elseif($tipo == 1)
	{
		return "Mulher";
	}else{
		return "Gay";
	}
}
function alertbox($text, $dir)
{
	echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$dir'</script></body>";
    die("Javascript disabled");
}

function clean($value)
{
        $check = $value;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');

        $value = str_replace($search, '', $value);

        $value = preg_replace(sql_regcase("/(from|select|shutdown|insert|delete|where|drop table|show tables|#|\*|--|'|;|\|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);

        if( $check != $value )
        {
            $logf = fopen("./logs/injection.txt", "a+");
            fprintf($logf, "%s (m_%s.php) - [AID=%s] - Fecha: %s IP: %s Valor: %s, Corregido: %s\r\n", $_SERVER[PHP_SELF],$_GET['do'], $_SESSION['AID'],date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
			alertbox("Voc� pretende fazer? (:, melhor verificar isso xD", "top5.lupee.com.br");
			
        }

        return( $value );
}
function logz($text)
{
	$logf = fopen("./logs/wtf.txt", "a+");
            fprintf($logf, $text."\r\n");
            fclose($logf);
}
function banz($text)
{
	$logf = fopen("./logs/Bans.txt", "a+");
            fprintf($logf, $text."\r\n");
            fclose($logf);
}
function Coins($text)
{
	$logf = fopen("./logs/Coins.txt", "a+");
            fprintf($logf, $text."\r\n");
            fclose($logf);
}
function Grado($text)
{
	$logf = fopen("./logs/Grados.txt", "a+");
            fprintf($logf, $text."\r\n");
            fclose($logf);
}
function admin()
{
	$grado = clean($_SESSION['UGRADEID']);
	if(!is_numeric($grado))
	{
		alertbox("Error Inesperado ... ","index.php");
	}
	switch($grado)
	{
		case 255:
			return 0;
		case 254:
			return 0;
		case 252:
			return 0;
		default:
			return 1;
	}
}
function f() { return "Q29kZWFkbyBwb3IgRGlvc3o="; }
function Random() {
    $length = 100;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $string = "";   
 
    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }
 
    return $string;
}

function random1($tama) {
    $length = $tama;
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $string = "";    

    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }

    return $string;
} 

function ratiopj($Wins, $Losses)
{
$total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

function ratioclan($k, $d)
{
    $total = $Wins + $Losses;

    return ($total == 0) ? "0%" : round((100 * $Wins) / $total, 2) . "%";
}
function master($cid)
{
//	$cid = clean($cid);
	$q = mssql_query("SELECT * FROM Character WHERE CID='".$cid."'");
	$r = mssql_fetch_object($q);
	return $r->Name;
}
function checarname($aid, $name)
{
	if(empty($aid))
	{
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$name."'");
		$r = mssql_fetch_object($q);
		$aid = $r->AID;
		//alertbox($aid,"index.php");
	}
	$q = mssql_query("SELECT * FROM Account WHERE AID='".$aid."'");
	$r = mssql_fetch_object($q);
	$t = $r->UGradeID;
	switch($t)
	{
		case 0:
			return "<font color='#FFFFFF'>$name</font>";
		case 2:
			return "<font color='#FFFFFF'>$name</font>";
		case 255:
			return "<font color='#FF0000'>$name</font>";
		case 254:
			return "<font color='#00FF00'>$name</font>";
		case 252:
			return "<font color='#FFFFFF'>$name</font>";
		case 253:
			return "<font color='#666666'>$name</font>";
		default:
			return "<font color='#00FFFF'>$name</font>";
	}
}
function staff()
{
	$q = mssql_query("SELECT * FROM Account a INNER JOIN Login b ON a.AID=b.AID WHERE a.AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
	$t = $r->UGradeID;
	$_SESSION['COINS'] = $r->euCoins;
	switch($t)
	{
		case 0:
			return "<font color='#FFFFFF'>Normal</font>";
		case 2:
			return "<font color='#FFFFFF'>Normal Jjang</font>";
		case 255:
			return "<font color='#FF0000'>Administrador</font>";
		case 254:
			return "<font color='#00FF00'>GameMaster</font>";
		case 252:
			return "<font color='#00FFFF'>GameMaster Invisivel</font>";
		case 253:
			return "<font color='#666666'>Banido</font>";
		default:
			return "<font color='#00FFFF'>Donator</font>";
	}
	
}
function staffz($aid)
{
	$q = mssql_query("SELECT * FROM Account a INNER JOIN Login b ON a.AID=b.AID WHERE a.AID='".$aid."'");
	$r = mssql_fetch_object($q);
	$t = $r->UGradeID;
	switch($t)
	{
		case 0:
			return "<font color='#FFFFFF'>Normal</font>";
		case 2:
			return "<font color='#FFFFFF'>Normal Con Jjang</font>";
		case 255:
			return "<font color='#FF0000'>Administrador</font>";
		case 254:
			return "<font color='#00FF00'>GameMaster</font>";
		case 252:
			return "<font color='#00FFFF'>GameMaster Invisivel</font>";
		case 253:
			return "<font color='#666666'>Banido</font>";
		default:
			return "<font color='#00FFFF'>Donator</font>";
	}
	
}

function enviarmail($para, $tema, $mensaje)
{
	
	$mail = new PHPMailer ();
//	alertbox($_SESSION['correo']." ".$passcorreo,"index.php");
	$mail -> From = $_SESSION['correo'];
	$mail -> FromName = $_SESSION['nombregunz'];
	$mail -> AddAddress ($para);
	$mail -> Subject = $tema;
	$mail -> Body = $mensaje;
	$mail -> IsHTML (true);

	$mail->IsSMTP();
	$mail->Host = 'ssl://smtp.gmail.com';
	$mail->Port = 465;
	$mail->SMTPAuth = true;
	$mail->Username = $_SESSION['correo'];
	$mail->Password = $_SESSION['passcorreo'];

	if(!$mail->Send()) {
	        return 1;
	}else{
	       return 0;;
	}

}

function getUrl() {
    return $_SERVER['HTTP_HOST'];
}

function redir($url)
{
	echo "<body  bgcolor='#000000'><script>document.location = './$url'</script></body>";
    die("Javascript disabled");
	die();
}
function listen($host,$port){

	        $fp = @fsockopen($host, $port, $errno, $errstr, 0);

        if (!$fp)
        {
            $result = '<font color="#FF0000">Offline</font>';
        }
        else
        {
            $result = '<font color="#00FF00">Online</font>';
            fclose($fp);
        }
		return $result;
}
function usuario()
{
	$grado = clean($_SESSION['permi']);
	switch($grado)
	{
		case 1:
			return '<font color="#FF0000">Administrador</font><br><a style="color:#FF0" href="./index.php?do=adm">Panel Staff</a>';
		case 2:
			return '<font color="#00FF00">Moderador</font><br><a style="color:#FF0" href="./index.php?do=adm">Panel Staff</a>';
		default:
			return '';
	}
}
function getclan($clid)
{
	$q = mssql_query("SELECT * FROM Clan WHERE CLID='".$clid."'");
	$r = mssql_fetch_object($q);
	return $r->Name;
}
function getclancid($clid)
{
	$q = mssql_query("SELECT * FROM Clan WHERE CLID='".$clid."'");
	$r = mssql_fetch_object($q);
	return $r->MasterCID;
}
function getcha($cid)
{
	$q = mssql_query("SELECT * FROM Character WHERE CID='".$cid."'");
	$r = mssql_fetch_object($q);
	return $r->Name;
}
function getlvl($cid)
{
	$q = mssql_query("SELECT * FROM Character WHERE CID='".$cid."'");
	$r = mssql_fetch_object($q);
	return $r->Level;
}
function activo($cid)
{
	$cid = clean($cid);
	$q = mssql_query("SELECT * FROM CLan WHERE MasterCID='".$cid."'");
	$r = mssql_fetch_object($q);
	return $r->Peticion;
}
function gettipo($tipo)
{
	$tipo = clean($tipo);
	switch($tipo)
	{
		case 0:
			return "Roupas";
		case 1:
			return "Armas";
		case 2:
			return "Espada";
		case 3:
			return "Item";
		default:
			return "Nada";
	}
}
function getsex($sex)
{
	$sex = clean($sex);
	switch($sex)
	{
		case 0:
			return "Homem";
			
		case 1:
			return "Mulher";
			
		case 2:
			return "Ambos";
		
		default:
			return "Nada";
		
	}
}

?>