<?php
$text = "<font size='-1' color='#CCCCCC'>";

$hora = time();
$fin = $hora-600;
if(empty($_SESSION['AID']))
{
	$ip = clean($_SERVER['REMOTE_ADDR']);
	$q = mssql_query("SELECT * From Online WHERE IP='".$ip."'");
}else{
	$user = clean($_SESSION['USERID']);
	$q = mssql_query("SELECT * From Online WHERE UserID='".$user."'");
}


if(!mssql_num_rows($q))
{
	if(!empty($user))
	{
		mssql_query("INSERT INTO Online (UserID, IP, Time) VALUES ('".$user."', '', '".$hora."')");
	}else{
		mssql_query("INSERT INTO Online (UserID, IP, Time) VALUES ('', '$ip', '$hora')");
	}
}else{
	if(!empty($user))
	{
		mssql_query("UPDATE Online SET Time='".$hora."' WHERE UserID='".$user."'");
	}else{
		mssql_query("UPDATE Online SET Time='".$hora."' WHERE IP='".$ip."'");
	}
}

mssql_query("DELETE From Online WHERE Time < ".$fin);
$countU = mssql_num_rows(mssql_query("SELECT * FROM Online WHERE IP = ''"));
$countI = mssql_num_rows(mssql_query("SELECT * FROM Online WHERE UserID = ''"));
$count0 = mssql_num_rows(mssql_query("SELECT * FROM Online"));

$text = $text."<br>Usuarios Online:".$count0." ( ".$countU." Membros , ".$countI." Visitantes)<br><br>";

$q = mssql_query("SELECT TOP 18 * From Online WHERE UserID != '' Order by ID DESC");
if(mssql_num_rows($q))
{
	$i = 1;
	while($r = mssql_fetch_object($q))
	{
		
		$text = $text."".checarname("",$r->UserID).","; 
        
		if($i == 13)
		{
			$text = $text."<br>";
			$i = 0;
		}
		$i++;
	}
}
		
        $text = $text."<br /> <br />
        <font color='#FF0000'>Administrador</font> | <font color='#00FF00'>GameMaster</font> | <font color='00FFFF'>Donator</font> | <font color='#FFFFFF'>Normal</font> | <font color='#666666'>Banido</font><br />
		</font>";
		$_SESSION['ONLINE'] = $text;
		?>