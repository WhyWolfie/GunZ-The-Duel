<?php
@session_start();
$DBHost = 'Tu-PC\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'dasdfa';
$DB = 'GunzDB';
$r = mssql_connect($DBHost, $DBUser, $DBPass);
if(!$r)
{
	die( mssql_error() );
}

mssql_select_db($DB,$r);
$_SESSION['correo'] = 'brinksgun@gmail.com';
$_SESSION['passcorreo'] = 'capeta10';
$_SESSION['nombregunz'] = 'Brinks Gunz';
date_default_timezone_set("America/Mazatlan");
?>