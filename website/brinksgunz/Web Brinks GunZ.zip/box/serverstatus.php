<?php
$q = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
	$r = mssql_fetch_object($q);
	$qs = listen("127.0.0.1",6000);
	$cw = listen("127.0.0.1",6000);
	$users = "<font color='#FFFFFF'>".$r->CurrPlayer."/".$r->MaxPlayer."</font>";
?>
<br />
<table>
<tr>
<td>
<font color="#FFFFFF">
Quest Server:</font></td><td> <?=$qs?></td>
</tr>
<tr>
<td>
<font color="#FFFFFF">
Clan Server: </font></td><td><?=$cw?></td>
</tr>
<tr>
<td>
<font color="#FFFFFF">
Players Online:</font></td><td> <?=$users?></td>
</tr>
</table>
