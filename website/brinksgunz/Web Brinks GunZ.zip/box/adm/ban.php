<?php
if(isset($_POST['banear']))
{
	$tipo = clean($_POST['tipo']);
	$user = clean($_POST['user']);
	if(empty($tipo) || empty($user))
	{
		alertbox("No dejes espacios en blanco","index.php?do=adm");
	}
	if($tipo == "UserID")
	{
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	}else{
		$q = mssql_query("SELECT * FROM Account a INNER JOIN Character b ON a.AID=b.AID WHERE b.Name='".$user."'");
	}
	if(!mssql_num_rows($q))
	{
		alertbox("El ".$tipo." No Existe","index.php?do=adm&page=ban");
	}else{
		$r = mssql_fetch_object($q);
		if($r->UGradeID == 253)
		{
			alertbox("Conta foi Banida","index.php?do=adm");
		}
	}
	banz("UserID: [".$_SESSION['USERID']."] Baneo al UserID : ".$r->UserID);
	mssql_query("UPDATE Account SET UgradeID='253' WHERE AID='".$r->AID."'");
	alertbox("Cuenta: ".$r->UserID." Baneada","index.php?do=adm");
}else{
	?>
	<form name="ban" method="post">
<center>
<select name="tipo">
<option value="UserID">UserID</option>
<option value="Personaje" selected="selected">Personagem</option>
</select> : <input type="text" name="user">  <div id="log-b2"><input name="banear" value="Banir" type="submit"></div>
</center>
</form>
<? } ?>
    
    
    