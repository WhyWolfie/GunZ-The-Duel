<?php
	echo "<body  bgcolor='#000000'><script>document.location = './index.php'</script></body>";
    die("Javascript disabled");
	die();

?>