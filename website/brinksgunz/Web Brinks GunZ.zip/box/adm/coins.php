<form name="coinz" method="post">
<center>
<select name="tipo">
<option value="UserID">UserID</option>
<option value="Personaje">Personagem</option>
</select> : <input type="text" name="user"> <br><br>
</font>Quantidade:
<input type="number" name="coin"> 
<br>
<br>
 <div id="log-b2"><input name="coins" value="Dar" type="submit"></div>
 <div id="log-b2"><input name="coins0" value="Retirar" type="submit"></div>
</center>
</form>
<?php 
if(isset($_POST['coins']) || isset($_POST['coins0']))
{
	$coins = clean($_POST['coin']);
	$tipo = clean($_POST['tipo']);
	$user = clean($_POST['user']);
	if(empty($tipo) || empty($coins) || empty($user))
	{
		alertbox("No dejes espacios en blanco","index.php?do=adm&page=coins");
	}
	if(!is_numeric($coins))
	{
		alertbox("Error Inesperado","index.php?do=adm");
	}
	if($tipo == "UserID")
	{
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	}else{
		$q = mssql_query("SELECT * FROM Account a INNER JOIN Character b ON a.AID=b.AID WHERE b.Name='".$user."'");
	}
	if(!mssql_num_rows($q))
	{
		echo '<font color="#FFFFFF">La Cuenta No Existe</font>';
		die();
	}		
	$r = mssql_fetch_object($q);
	$aid = $r->AID;
	if(isset($_POST['coins']))
	{
		Coins($_SESSION['USERID']." Deu ".$coins." Coins al ".$tipo.": ".$user);
		mssql_query("UPDATE Login SET euCoins=euCoins+".$coins." WHERE AID='".$aid."'");
		alertbox("Coins Enviados","index.php?do=adm");
	}else{
		Coins($_SESSION['USERID']." Removeu ".$coins." Coins al ".$tipo.": ".$user);
		mssql_query("UPDATE Login SET euCoins=euCoins-".$coins." WHERE AID='".$aid."'");
		alertbox("Coins Removidos","index.php?do=adm");
	}
}
?>
	