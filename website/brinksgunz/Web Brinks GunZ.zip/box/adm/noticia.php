<?php
if(isset($_POST['agregar']))
{
	$titulo = clean($_POST['titulo']);
	$tipo = clean($_POST['tipo']);
	$texto = $_POST['texto'];
	if(!is_numeric($tipo))
	{
		alertbox("El tipo de anuncio es erroneo","index.php?do=adm");
	}
	if($tipo == 1)
	{
		if(empty($titulo))
		{
			alertbox("No dejes espacios en blanco","index.php?do=adm&page=noticia");
		}
	}else{
		if(empty($titulo) || empty($texto))
		{
			alertbox("No dejes espacios en blanco","index.php?do=adm&page=noticia");
		}
	}
	mssql_query("INSERT INTO Noticias ([Titulo], [Tipo], [Texto], [UserID], [Fecha]) VALUES ('".$titulo."', '".$tipo."', '".$texto."', '".$_SESSION['USERID']."', GETDATE())");
	if($tipo == 0)
	{
		alertbox("Noticia [".$titulo."] Agregada","index.php?do=adm");
	}else{
		alertbox("Anuncio [".$titulo."] Agregado","index.php?do=adm");
	}
}else{
?>
<form name="noticia" method="post">
<center>
  <p>&raquo; Noticia: Noticias que se muestran en la pagina principal</p>
  <p>&raquo; Anuncio: Es el anuncio que se muestra arriba de todo</p>
  <table>
  <tr>
  <td align="center">Agregar <select name="tipo">
  <option value="0">Noticia</option>
  <option value="1">Anuncio</option>
  </select>
  </td>
  </tr>
  <tr>
  <td align="center">Titulo: <input type="text" name="titulo"></td>
  </tr>
  <tr>
  <td align="center">Mensaje<br>
    <textarea name="texto" cols="55" rows="20"></textarea></td>
  </tr>
  <tr>
  <td align="center"> <div id="log-b2"><input name="agregar" type="submit" value="[Postar]"></div></td>
  </tr>
</table>
</center>
</form>
<? } ?>