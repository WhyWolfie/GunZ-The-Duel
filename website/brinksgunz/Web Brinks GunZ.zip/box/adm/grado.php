<form name="grade" method="post">
<center>
<select name="tipo">
<option value="UserID">UserID</option>
<option value="Personaje">Personagem</option>
</select> : <input type="text" name="user"> <br><br>
Grade: <select name="grado">
<option value="254">Moderador</option>
<option value="253">Banido</option>
<option value="0">User Normal</option>
</select><br><br>
 <div id="log-b2"><input name="cambiar" value="Dar" type="submit"></div>
</center>
</form>
<?php
if(isset($_POST['cambiar']))
{
	$grado = clean($_POST['grado']);
	$tipo = clean($_POST['tipo']);
	$user = clean($_POST['user']);
	if(empty($tipo) || empty($coins) || empty($user))
	{
		alertbox("No dejes espacios en blanco","index.php?do=adm&page=coins");
	}
	if(!is_numeric($grado))
	{
		alertbox("Error Inesperado","index.php?do=adm");
	}
	if($tipo == "UserID")
	{
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	}else{
		$q = mssql_query("SELECT * FROM Account a INNER JOIN Character b ON a.AID=b.AID WHERE b.Name='".$user."'");
	}
	if(!mssql_num_rows($q))
	{
		echo '<font color="#FFFFFF">La Cuenta No Existe</font>';
		die();
	}		
	$r = mssql_fetch_object($q);
	$aid = $r->AID;
	Grado($_SESSION['USERID']." Cambio el UGradeID al Usuario ".$r->UserID. " a [".$grado."]");
	mssql_query("UPDATE Account SET UGradeID='".$grado."' WHERE AID='".$r->AID."'");
	alertbox("Grade Mudada com Sucesso","index.php?do=adm");
}
?>