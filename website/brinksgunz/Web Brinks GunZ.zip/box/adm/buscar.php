<form name="buscar" method="post">
<center>
<select name="tipo">
<option value="UserID">UserID</option>
<option value="Personaje">Personagem</option>
</select> : <input type="text" name="user"> <div id="log-b2"><input name="buscar0" value="Buscar" type="submit"></div>
<br />
<font color="#FF0000">Administracao</font> | <font color="#00FF00">GameMaster</font> | <font color="00FFFF">Donator</font> | <font color="#FFFFFF">Normal</font> | <font color="#666666">Banido</font><br />
--------------------------------------------------------------------
</center>
</form>
<?php
if(isset($_POST['buscar0']))
{
	$tipo = clean($_POST['tipo']);
	$user = clean($_POST['user']);
	if(empty($tipo) || empty($user))
	{
		alertbox("No dejes espacios en blanco","index.php?do=adm");
	}
	if($tipo == "UserID")
	{
		$q = mssql_query("SELECT * FROM Account WHERE UserID='".$user."'");
	}else{
		$q = mssql_query("SELECT * FROM Account a INNER JOIN Character b ON a.AID=b.AID WHERE b.Name='".$user."'");
	}
	if(!mssql_num_rows($q))
	{
		echo '<font color="#FFFFFF">La Cuenta No Existe</font>';
		die();
	}		
	$r = mssql_fetch_object($q);
	$aid = $r->AID;
	$q = mssql_query("SELECT * FROM Account a INNER JOIN Login b ON a.AID=b.AID WHERE a.AID='".$aid."'");
	$qq = mssql_query("SELECT * FROM Character a INNER JOIN Login b ON a.AID=b.AID WHERE a.AID='".$aid."'");
	$r = mssql_fetch_object($q);

?>
<font color="#FFFFFF">
<table width="528" height="111">
<tr>
<td width="53" align="center">Conta:</td>
<td width="66"></td>
<td width="76"></td>
<td width="97"></td>
<td width="81"></td>
<td width="65"></td>
</tr>
<tr>
  <td align="center">AID</td>
  <td align="center">UserID</td>
  <td align="center">Nome</td>
  <td align="center">Email</td>
  <td align="center">Tipo</td>
  <td align="center">Coins</td>
  </tr>
<tr>
  <td align="center"><?=$r->AID?></td>
  <td align="center"><?=$r->UserID?></td>
  <td align="center"><?=$r->Name?></td>
  <td align="center"><?=$r->Email?></td>
  <td align="center"><?=staffz($r-UGradeID)?></td>
  <td align="center"><?=$r->Coins?></td>
  </tr>
<tr>
  <td>&nbsp;</td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  </tr>
<tr>
  <td align="center">Personagem:</td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
  <td></td>
</tr>
<tr>
  <td align="center">CID</td>
  <td align="center">Nome</td>
  <td align="center">Level</td>
  <td align="center">XP</td>
  <td align="center">Kill</td>
  <td align="center">Deaths</td>
</tr>
<? if(mssql_num_rows($qq))
{
	while($r = mssql_fetch_object($qq))
	{ ?>
<tr>
  <td align="center"><?=$r->CID?></td>
  <td align="center"><?=utf8_encode($r->Name)?></td>
  <td align="center"><?=$r->Level?></td>
  <td align="center"><?=$r->XP?></td>
  <td align="center"><?=$r->KillCount?></td>
  <td align="center"><?=$r->DeathCount?></td>
</tr>
<? }
$m = 0;
}else{
	$m = 1;
	?>
<tr>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
</tr>
<? } ?>
<tr>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
</tr>
<tr>
  <td align="center">Clan:</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
  <td align="center">&nbsp;</td>
</tr>
<tr>
  <td align="center">Ranking</td>
  <td align="center">Emblema</td>
  <td align="center">Nome</td>
  <td align="center">Wins</td>
  <td align="center">Losses</td>
  <td align="center">Pontos</td>
</tr>
<? 
if($m == 0)
{
	$qq = mssql_query("SELECT * FROM Character WHERE Name != '' AND AID='".$aid."'");
	while($r = mssql_fetch_object($qq))
	{
		
		$T = mssql_query("SELECT * From Clan WHERE MasterCID='".$r->CID."'");
		if(mssql_num_rows($T))
		{
			$g = mssql_fetch_object($T);
			if(empty($g->EmblemUrl) || !file_exists("./emblems/upload/".$g->EmblemUrl))
			{
				$emblema = "./emblems/upload/noemblem.jpg";
			}else{
				$emblema =	"./emblems/upload/".$g->EmblemUrl;
			}
			?>
            <tr>
  <td align="center"><?=$g->Ranking?></td>
  <td align="center"><img width="34" height="30" src="<?=$emblema?>" /></td>
  <td align="center"><?=$g->Name?></td>
  <td align="center"><?=$g->Wins?></td>
  <td align="center"><?=$g->Losses?></td>
  <td align="center"><?=$g->Point?></td>
			</tr>
<?		}
	}
}
?>
</table>
</font>
<? } ?>