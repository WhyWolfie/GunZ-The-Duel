<?php
if(isset($_POST['agregar0']))
{
	$consulta = "INSERT INTO Tienda (";
	foreach($_POST as $var => $valor)
	{
		$_POST[$var] = clean($_POST[$var]);
		if($var == "agregar0")
		{
			$consulta = $consulta.") ";
		}elseif($var == "Name"){
			$consulta = $consulta.$var.", imagen, ";
		}elseif($var == "PR"){
			$consulta = $consulta.$var;
		}else{
			$consulta = $consulta.$var.", ";
		}
   	}
		foreach($_POST as $var => $valor)
		{
			if(empty($_POST[$var]) && $_POST[$var] != 0 )
			{
				alertbox("No dejes espacios en blanco ".$var." - ".$_POST[$var],"index.php?do=adm");
			}
			
   		}
	$consulta = $consulta."VALUES (";
    $emblem = $_POST['imagen'] ;

	$target = "./images/tienda/";
	$target = $target . basename( $_FILES['imagen']['name']) ;
	$ok=1;
	$ext = pathinfo($target);
	$EXT1 = strtolower($ext['extension']);
	$f = $ext['basename'];
	if($EXT1 != "jpg" && $EXT1 != "png" && $EXT1 != "jpeg") 
	{
    	$ok = 0; 
	}else{ 
		$ok = 1; 
	}
	
	if ($ok==0)
	{
		alertbox("Error!!! Tu imagen no ha subido, verifica la extension y el tipo de archivo.","index.php?do=adm");
 	}
	
	if(move_uploaded_file($_FILES['imagen']['tmp_name'], $target))
	{
    
		do {
			$archivo = random1(50);
			$archivo = $archivo . ".";
			$archivo = $archivo . $EXT1;
		} while(file_exists("./images/tienda/".$archivo));
 
	    rename("./images/tienda/".$f,"./images/tienda/".$archivo);
		
			foreach($_POST as $var => $valor)
			{
				$_POST[$var] = clean($_POST[$var]);
   				if($var == "agregar0")
				{
					$consulta = $consulta.") ";
				}elseif($var == "Name"){
					$consulta = $consulta."'".$_POST[$var]."', '".$archivo."', ";
				}elseif($var == "PR"){
					$consulta = $consulta."'".$_POST[$var]."'";
				}else{
					
					$consulta = $consulta."'".$_POST[$var]."', ";
				}
  		 	}
		
		if(mssql_query($consulta))
		{
			logz("[".$_SESSION['USERID']."]: Item ".$_POST['Name']." Agregado a la Tienda");
			alertbox("Item Agregado a la tienda","index.php?do=adm");
		}else{
			echo '<font color="#FF0000">Error al Agregar Item a la Tienda<br>Consulta: '.$consulta.'</font>';
		}
 	}else{
		echo "Error!!! Ha ocurrido un problema al intentar subir la imagen";
	}
	
} 
?>
<form name="agregar" method="post" enctype="multipart/form-data">
<font color="#FFFFFF">
<table width="384" height="476">
<td width="103">ItemID:</td>
<td width="269"><input type="number" name="ItemID"></td>
</tr>
<tr>
  <td>Nombre:</td>
  <td><input type="text" name="Name"></td>
</tr>
<tr>
  <td>Imagen:</td>
  <td><input type="file" name="imagen"></td>
</tr>
<tr>
  <td>Precio:</td>
  <td><input name="Precio" type="number" value="0"></td>
</tr>
<tr>
  <td>Level:</td>
  <td><input name="Level" type="number" value="0"></td>
</tr>
<tr>
  <td>Tipo:</td>
  <td><select name="tipo">
<option selected value="0">Ropa</option>
<option value="1">Armas</option>
<option value="2">Espadas</option>
<option value="3">Items</option>
</select></td>
</tr>
<tr>
  <td>Sexo:</td>
  <td><select name="Sex">
<option value="0">Hombre</option>
<option value="1">Mujer</option>
<option selected value="2">Todos</option></select></td>
</tr>
<tr>
  <td>Peso:</td>
  <td><input name="Peso" type="number" value="0"></td>
</tr>
<tr>
  <td>Daño:</td>
  <td><input name="Dano" type="number" value="0"></td>
</tr>
<tr>
  <td>Retraso:</td>
  <td><input name="Delay" type="number" value="0"></td>
</tr>
<tr>
  <td>Controlabilidad:</td>
  <td><input name="Controlabilidad" type="number" value="0"></td>
</tr>
<tr>
  <td>Balas:</td>
  <td><input name="Balas" type="number" value="0"></td>
</tr>
<tr>
  <td>Max Blas:</td>
  <td><input name="Max_Balas" type="number" value="0"></td>
</tr>
<tr>
  <td>HP:</td>
  <td><input name="HP" type="number" value="0"></td>
</tr>
<tr>
  <td>AP:</td>
  <td><input name="AP" type="number" value="0"></td>
</tr>
<tr>
  <td>Max Peso:</td>
  <td><input name="Max_Peso" type="number" value="0"></td>
</tr>
<tr>
  <td>Recarga:</td>
  <td><input name="Recarga" type="number" value="0"></td>
</tr>
<tr>
  <td>Duracion:</td>
  <td><input name="Duracion" type="number" value="0"></td>
</tr>
<tr>
  <td>FR:</td>
  <td><input name="FR" type="number" value="0"></td>
</tr>
<tr>
  <td>LR:</td>
  <td><input name="LR" type="number" value="0"></td>
</tr>
<tr>
  <td>CR:</td>
  <td><input name="CR" type="number" value="0"></td>
</tr>
<tr>
  <td>PR:</td>
  <td><input name="PR" type="number" value="0"></td>
</tr>
</table>
 <div id="log-b2"><input type="submit" name="agregar0" value="ADD ITEM Do">
 </div>
</font>
</form>
