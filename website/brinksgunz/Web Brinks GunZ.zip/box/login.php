<?php
if(empty($_SESSION['USERID']))
{ 

?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>

<div id="login" class="left" >
  <div id="login-mid">
    <form name="loguear" method="post" action="./index.php?do=loguear">
      <div id="inputbox">
        <input name="user" type="text" class="loginbox_username" onclick="this.value=''" value="Username" maxlength="15" />
        <input type="password" name="pass" class="loginbox_password" onclick="this.value=''" value="Password" maxlength="12" />
        
        
      </div>
      <table cellpadding="2" cellspacing="2">
        <tr>
          <td valign="top" style=" text-align:right"><div id="log-b">
              <input type="submit" value="Logar"/>
          </div></td>
          <td valign="top" style="padding: 5px 0px 0px 0px;"><a href="./index.php?do=reset"> Esqueceu sua senha ?</a> <a href="./index.php?do=registro">Novo Cadastro !</a> </td>
        </tr>
      </table>
      </form>
      <!--<span class="forgot"><img src="" /><a class="normal">Forgot your password? </a><a href="#">Click here!</a></span>--> </div>
    <div id="login-bottom"></div>
  </div>
<? 
}else{ ?>
<div id="login" class="left" >
    <div id="login-top"></div>
    <div id="login-seperator"></div>
    <div id="login-mid"><form name="loguear" method="post" action="./index.php?do=loguear"><div id="inputbox">
      <table width="184" height="245" border="0" align="center" cellpadding="0" cellspacing="0" style="background-repeat:no-repeat; background-position:top center;">
          <tr valign="top">
            <td align="center" class="estilo1"><table width="200" border="0">
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
              <table width="160" height="270" border="0">
                <tr>
                  <p></p>
                  <td><div class="realmlist">
                      <div align="center"><span class="estilo6">Ol&aacute;
                        ,<font color="#FFFFFF"><b>
                                  <?=$_SESSION['USERID']?>
                                </b></font>Seja Bem Vindo <a href="./index.php?do=desloguear"> (Sair</a></span><a href="index.php?gunz=logout">)</a></div>
                  </div>
                      <div class="realmlist">
                        <div align="center">
                          <table width="160" border="0">
                            <tr>
                              <td>B Coins:</td>
                              <td><div align="right">( <font color="#FFFFFF">
                                  <?=$_SESSION['COINS']?>
                              </font> )</div></td>
                            </tr>
                          </table>
                        </div>
                      </div>
                    <div class="realmlist">
                      <div align="center">
                          <table width="160" border="0">
                            <tr>
                              <td>Ev Coins:</td>
                              <td><div align="right">( <font color="#FFFFFF">
                                  <?=$_SESSION['COINS2']?>
                              </font> )</div></td>
                            </tr>
                          </table>
                        </div>
                    </div>
                    <div class="realmlist">
                        <div align="center" class="style1">Menu da Conta</div>
                    </div>
                    <div class="realmlist">
                        <div align="center"><a href="./index.php?do=panel&amp;page=edit">Editar Perfil</a></div>
                    </div>
                    <div class="realmlist">
                        <div align="center"><a href="./index.php?do=panel&amp;page=pass"> Trocar de Senha</a></div>
                    </div>
                    <div class="realmlist">
                        <div align="center"><a href="./index.php?do=panel&amp;page=stats">Meus Personagem</a></div>
                    </div>
                    <div class="realmlist">
                        <div align="center"><a href="./index.php?do=panel&amp;page=sex">Mudar Sexo (P)</a></div>
                    </div>
                    <div class="realmlist">
                        <div align="center"><a href="./index.php?do=color">Comprar Color</a></div>
                    </div>
                    <div class="realmlist">
                      <div align="center"><span class="style1">Menu de Cl&atilde;n</span></a></div>
                    </div>
                    <div class="realmlist">
                      <div align="center"><a href="./index.php?do=emblema">Clan Emblema</a><a href="./index.php?do=clan"></a></div>
                    </div>
                    <div class="realmlist">
                      <div align="center"><a href="./index.php?do=clan">Painel de Clan</a></div>
                  </div></td>
                </tr>
              </table></td>
          </tr>
        </table>
      </div>
     
<!--      <input type="image" src="./images/login/register.png" name="register"  alt="register"/>-->
<!--      <div id="submit" class="left"><a href="#"></a></div>
      <div id="register" class="right"><a href="./index.php?do=registro"></a></div>-->
      </form>
  <!--<span class="forgot"><img src="" /><a class="normal">Forgot your password? </a><a href="#">Click here!</a></span>--> </div>
    <div id="login-bottom"></div>
  </div>
<? } ?><br />