<?php $q = mssql_query("SELECT TOP 10 Name, Level FROM Character Where Name != '' Order by XP DESC");
if(mssql_num_rows($q)){
	$i = 1;
	?>
    <table width="224" align="center">
    <?php
	while($r = mssql_fetch_object($q))
	{
		?>
		<tr><td width="41" align="center"><div align="center"><font color="#FFFFFF">
	    <?=$i?>
		  </font></div></td>
	    <td width="89" align="center"><font color="#FFFFFF">
        <?=utf8_encode($r->Name)?>
	      </font></td><td width="78" align="center"><div align="center"><font color="#FFFFFF">
          <?=$r->Level?>
	        </font></div></td></tr>
        <?php
		$i++;
	 } ?>
		</table>
    <p>
      <?php 
}else{
	echo "<center>N&atilde;o Cont&eacute;m Personagens </center>";
}?>
    </p>
