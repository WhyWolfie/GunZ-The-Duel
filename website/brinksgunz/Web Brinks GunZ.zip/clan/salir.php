<form name="salir" method="post">
<?php
$q = mssql_query("SELECT * FROM Character a INNER JOIN ClanMember b ON a.CID=b.CID WHERE a.AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo "Voc&ecirc; n&atilde;o possui personagens";
}else{
?>
aqui voc&ecirc; tamb&eacute;m pode fechar um cl&atilde; e ter todos os membros, incluindo a si mesmo.<br />
<br>
Sair ou Fechar Clan: <?=getclan($clid)?><p>&nbsp;</p>
Selecione um personagem: <select name="pj">
<? while($r = mssql_fetch_object($q))
{
	?>
	<option value="<?=$r->CID?>"><?=$r->Name?> - <?=getclan($r->CLID)?></option>
    <?
	
}
?>
</select>
<br /><br />
 <div id="log-b2"><input type="submit" name="salir0" value="Sair do Clan" /></div>
</form>
<?php
if(isset($_POST['enviar0']))
{
	$cid = clean($_POST['pj']);
	$q = mssql_query("SELECT * FROM Character a INNER JOIN ClanMember b ON a.CID=b.CID WHERE a.AID='".$_SESSION['AID']."' AND a.CID='".$pj."'");
	if(!mssql_num_rows($q))
	{
		alertbox("O personagem n&atilde;o &eacute; seu","index.php");
	}
	$r = mssql_fetch_object($q);
	if($r->Grade != 1)
	{
		mssql_query("DELETE FROM ClanMember WHERE CID='".$cid."'");
		alertbox("O Personagem: ".getcha($cid)." Ele deixou seu clan","index.php");
	}else{
		mssql_query("DELETE FROM ClanMember WHERE CLID='".$r->CLID."'");
		mssql_query("DELETE FROM Clan WHERE CLID='".$r->CLID."'");
		alertbox("Clan ".getclan($r->CLID)." Eliminado","index.php");
	}
	
}
}
?>