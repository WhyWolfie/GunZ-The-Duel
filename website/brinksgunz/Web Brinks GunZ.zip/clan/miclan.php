<font color="#FFFFFF">
<?php
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(mssql_num_rows($q))
{
	while($r = mssql_fetch_object($q))
	{
		$qq = mssql_query("SELECT * FROM Clan WHERE MasterCID='".$r->CID."' Order by CLID ASC");
		if(mssql_num_rows($qq))
		{
			$rr = mssql_fetch_object($qq);
			$qqq = mssql_query("SELECT * FROM Peticiones WHERE CLIDClan='".$rr->CLID."' Order by ID DESC");
			?>
            Master: <?=master($rr->MasterCID)?> <? if(activo($rr->MasterCID) == 0) { ?>
            <a style="color:#F00" href="./index.php?do=desactivar&cid=<?=$rr->MasterCID?>&id=1">Off Clan Peti&ccedil;oes</a> <br />
			<? }else{ ?>
            <a style="color:#F00" href="./index.php?do=desactivar&cid=<?=$rr->MasterCID?>&id=0">Ativar Peti&ccedil;oes Clan</a>
            <br />
			<? }
			if(mssql_num_rows($qqq))
			{
				?>
				<table width="389">
                <tr>
                <td width="47" align="center">Clan</td>
                <td width="50" align="center">Player</td><td width="49" align="center">Level</td><td width="54" align="center">Status</td><td width="75">&nbsp;</td><td width="74">&nbsp;</td>
                </tr>
                
                <?
				while($rrr = mssql_fetch_object($qqq))
				{
					if($rrr->Status == 0)
					{
						$status = '<font color="#00FFFF">Espera</font>';
					}elseif($rrr->Status == 1){
						$status = '<font color="#00FF00">Aprovado</font>';
					}else{
						$status = '<font color="#FF0000">Recusado</font>';
					}
					?>
                    <tr>
                    <td align="center"><?=$rr->Name?></td><td align="center"><?=$rrr->Personaje?></td><td align="center"><?=$rrr->Level?></td><td align="center"><?=$status?></td><?
					if($rrr->Status == 0)
					{ ?>
                    <td align="center"><a style="color:#0F0" href="./index.php?do=acept&clid=<?=$rr->CLID?>&id=<?=$rrr->ID?>&cid=<?=$rrr->CID?>">Aprovar</a></td><td align="center"><a style="color:#F00" href="./index.php?do=rechazar&id=<?=$rrr->ID?>&clid=<?=$rr->CLID?>">Recurar</a></td>
					<?
					}else{
					?>
                    <?
					}
					?>
                    </tr>
                    <?
				}
				?>
				</table>
<br>
                <?
			}else{
				echo "Voc&ecirc; n&atilde;o tem pedidos.";
			}
		}else{
			echo "N&atilde;o ha nenhum dono nesse cl&atilde;.";
		}
	}
}else{
	echo "N&atilde;o possui personagem.";
}
?>
</font>