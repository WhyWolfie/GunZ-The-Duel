<font color="#FFFFFF">
</font>
<div class="sub-box1" align="left"><font color="#FFFFFF">
  <?php
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo "<br>Voc&ecirc; n&atilde;o possui personagens";
}else{
	while($r = mssql_fetch_object($q))
	{
		$qq = mssql_query("SELECT * FROM Peticiones WHERE CID='".$r->CID."'");
		if(mssql_num_rows($qq))
		{			
		?>
Personagen: <?=$r->Name?></font><br/>
</div>
<p>&nbsp;</p>
<div class="sub-box1" align="left"><font color="#FFFFFF">
  <table width="566">
    <tr>
      <td align="center">Clan</td>
      <td align="center">Status</td>
      <td align="center">Fecha</td>
    </tr>
    <?
			while($rr = mssql_fetch_object($qq))
			{
				if($rr->Status == 0)
					{
						$status = '<font color="#00FFFF">Espera</font>';
					}elseif($rr->Status == 1){
						$status = '<font color="#00FF00">Aprovado</font>';
					}else{
						$status = '<font color="#FF0000">Recusado</font>';
					}
				?>
    <tr>
      <td><?=getclan($rr->CLIDClan)?></td>
      <td><?=$status?></td>
      <td><?=$rr->Fecha?></td>
    </tr>
    <?
			}?>
  </table>
  </font><font color="#FFFFFF">
  <?
		}else{
			echo "<br>";
		}
	}
}
?>
  </font><br/>
</div>
<p><font color="#FFFFFF"><br>
</font></p>