<?
if($_SESSION['UGradeID'] == 104){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 0){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 1){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 2){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 3){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 4){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 5){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 6){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 7){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 8){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 9){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 10){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 11){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 12){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 13){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 14){
    msgbox("Access Denied","index.php");
}
if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $user = $_SESSION['UserID'];
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?do=admincp&page=muteuser");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE UserID = '$userID'");
            mssql_query_logged("INSERT INTO Muteuser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$user', '$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the ID $id has been muted","index.php?do=admincp");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?do=admincp&page=muteuser");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE AID = '$UserAID'");
            mssql_query_logged("INSERT INTO Muteuser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$user', '$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the character $id has been muted","index.php?do=admincp");
        }
    }

}


?>
<form name="mute" method="POST" action="index.php?do=admincp&page=muteuser">
<ul id="cat_quadrados">
<li>Mutar usuario:</li>
<p>&nbsp;</p>
<li><select size="1" name="type">
	<option selected value="1">User ID
	</option>
	<option value="2">Character Name
	</option>
	</select>: <input type="text" name="id" size="26"></li>
<li>Mute Reason: <select size="1" name="reason" onchange="UpdateCustom()">
	<option selected value="Spamming looby chat">Spamming looby chat</option>
	<option value="Spamming gameroom chat">Spamming gameroom chat</option>
	<option value="Spamming ingame chat">Spamming ingame chat</option>
        <option value="Insulting the staff">Insulting the staff</option>
	<option value="Insulting Player">Insulting player</option>
	<option value="No reason specified">No reason specified</option>
	</select></li>
<li><input class="go" type="submit" value="Mutar Usuario" name="submit"></td>
</ul>
</form>