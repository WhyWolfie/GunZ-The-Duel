<?
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 104){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 0){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 1){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 2){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 3){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 4){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 5){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 6){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 7){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 8){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 9){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 10){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 11){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 12){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 13){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 14){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $titulo = clean($_POST['titulo']);
    $noticia = clean($_POST['noticia']);
    $user = $_SESSION['UserID'];
    mssql_query_logged("INSERT INTO Noticia ([autor], [Data], [Noticia], [Titulo])VALUES('$user', GETDATE(), '$noticia', '$titulo')");
    msgbox("Adicionado corretamente","index.php?do=admincp");
}else{
?>
<form method="POST" action="index.php?do=admincp&page=addanuncio">
<ul id="cat_quadrados">
<li>Adicionar Anuncio:</li>
<p>&nbsp;</p>
<li>Titulo: <input type="text" name="titulo" size="40"></li>
<li>Texto: <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea rows="8" name="noticia" cols="35"></textarea></li>
<li><input class="go" type="submit" value="Concluir" name="submit"></li>
</ul>
</form>

<?
}
?>