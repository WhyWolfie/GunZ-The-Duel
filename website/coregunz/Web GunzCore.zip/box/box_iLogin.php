<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if($_SESSION[AID] == "")
{
?>
                        <form name="login" method="POST" action="index.php?do=login&header=1">
                <!-- isto � uma caixa de categoria -->
   	        	<div class="cat_painel">
   	         	<h3><img src="images/list1_active.png" width="8" height="11" /> Painel de controle</h3></div>
                    <div class="cat_painel_sub">
                      	<div class="login_div">
                      	  <label for="id"></label>
                       	  <input  class="logar" name="userid" type="text" id="login" value="Login" />
                      	</div>
                        <div class="login_div">
                       	  <label for="passw"></label>
                        	<input name="pasw" class="logar" type="password" id="pasw" value="12345678" />
                        </div>
                        <div class="login_div">
                       	  <input class="go"  type="submit" name="submit" id="logar" value="Logar-se" />
                        </div>
                      </form>
                      <div class="login_div"><h4><a href="#">Recuperar Senha?</a></h4></div>
                    <div class="break"></div>
                    </div>
                    <!-- isto � o fim de uma caixa de categoria -->

<?
}else{
//And again.
$res = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$d = mssql_fetch_assoc($res);

//No shit?
$res2 = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$numitems = mssql_num_rows($res2);

$busca1 = mssql_query_logged("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$busca2 = mssql_fetch_row($busca1);
?>

                    <!-- Informa��es do Painel ( JOGADOR ) -->
                    <!-- isto � uma caixa de categoria -->
   	        		<div class="cat_painel">
   	         		<h3><img src="images/list1_active.png" width="8" height="11" /> Ol&aacute;, <?=$_SESSION['UserID']?></h3></div>
                    <div class="cat_painel_sub">
                    <ul id="cat_quadrados">
                      <li><a href="index.php?do=minhaconta">Minha Conta</a></li>
                      <li><a href="index.php?do=personagens">Meus Personagens</a></li>
                      <li><a href="index.php?do=clans">Meus Cl&atilde;s</a></li>
<?
if($busca2[0] == 255){
?> 
                      <li><a href="index.php?do=admincp">Admin Painel</a></li>
<? } ?>
                      <li><a href="index.php?do=login&action=logout&header=1">Sair</a></li>
                    </ul>
                    <div class="break"></div>
                    </div>
                    <!-- isto � o fim de uma caixa de categoria -->

<?
}
?>