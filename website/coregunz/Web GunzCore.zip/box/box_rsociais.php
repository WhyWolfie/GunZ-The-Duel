                    <!-- isto � uma caixa de categoria -->
                	<div class="cat_painel">
                	  <h3><img src="images/list1_active.png" width="8" height="11" /> Redes Sociais</h3></div>
                    <div class="cat_painel_sub">
                    <div style="margin:10px; font:10px Verdana, Geneva, sans-serif;">Participe de Nossas Redes Sociais e fique por dentro de todas novidades de nosso Servidor , participe e Colabore.</div>
                    <div id="Redes-sociais" style="text-align:center; margin:10px;">
               	    	<a href="#" class="someClass" title="Face Book"><img src="images/facebook.png" width="20" height="20" /></a>
                        <a href="#" class="someClass" title="Twitter"><img src="images/twitter.png" width="20" height="20" /></a>
                        <a href="#" class="someClass" title="You tube"><img src="images/youtube.png" width="20" height="20" /></a>
                        <a href="#" class="someClass" title="Yahoo"><img src="images/yahoo.png" width="20" height="20" /></a>
                    	<a href="#" class="someClass" title="Feed De Noticias"><img src="images/feed.png" width="20" height="20" /></a>
                    </div>
                    </div>
                    <!-- isto � o fim de uma caixa de categoria -->