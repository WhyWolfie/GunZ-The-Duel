<?
$res = mssql_query("SELECT TOP 10 Name, Level, CID FROM Character WHERE Name != '' ORDER BY Level DESC");
    $count = 0;
    ?>
                    <!-- isto � uma caixa de categoria -->
                	<div class="cat_painel">
                	  <h3><img src="images/list1_active.png" width="8" height="11" /> Rank de Personagem</h3></div>
                    <div class="cat_painel_sub">
<?
while($r = mssql_fetch_assoc($res)){
$count++;
?>
<ul id="cat_quadrados">
<li><a href="index.php?do=charinfo&id=<?=$r['CID']?>"><?=utf8_encode($r['Name'])?></li>
</ul>

<?}?>
                    </div>
                    <!-- isto � o fim de uma caixa de categoria -->

<?
$res = mssql_query("SELECT TOP 10 Name, Point, CLID FROM Clan WHERE Name != '' ORDER BY Point DESC");
	$rank = 0;
?>

                    <!-- isto � uma caixa de categoria -->
                	<div class="cat_painel">
                	  <h3><img src="images/list1_active.png" width="8" height="11" /> Rank de Clan</h3></div>
                    <div class="cat_painel_sub">
<? while($r = mssql_fetch_assoc($res)){
$rank++;  
?>
<ul id="cat_quadrados">
<li><td width="100" align="left"><a href="index.php?do=claninfo&id=<?=$r['CLID']?>"><?=utf8_encode($r['Name'])?></a></td></li>
</ul>

<?}?>
                    </div>
                    <!-- isto � o fim de uma caixa de categoria -->