                    <!-- isto � uma caixa de categoria -->
                	<div class="cat_painel">
                	  <h3><img src="images/list1_active.png" width="8" height="11" /> Estat&iacute;sticas</h3>
                    </div>
				    <div class="cat_painel_sub">
						<ul id="cat_quadrados">
<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = $data->ServerName;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<li>Status do Servidor:<strong class='offline'>Offline</strong></li>";
        }
        else
        {
            echo "<li>Status do Servidor:<strong class='online'>Online</strong></li>";
            fclose($fp);
        }
    }
    ?>
                        	<li>Jogadores Online: <strong><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "$servercount";
    ?></strong></li>
<?php
 
//Total Contas
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "<li>Total de Contas: <strong>".$num_rows."</strong></li>";

?>
<?php
 
//Total Personagens
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "<li>Total de Noobs: <strong>".$num_rows."</strong></li>";

?>
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
                        	<li>Record Online:<strong><?=$b['PlayerCount']?></strong></li>
                        </ul>
          			</div>
                    <!-- isto � o fim de uma caixa de categoria -->