<?php
//Act GunZ Online By Sparrow
$link = mssql_connect("Tu-PC\SQLEXPRESS","sa","gvjhvjn");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Act GunZ Connected

$DBHost = 'TU-PC\SQLEXPRESS'; //Sparrow SQL
$DBUser = 'sa'; //Your DB User 
$DBPass = '2ibjkkjn'; //Sparrow Senha 
$DB = 'GunzDB'; //Sparrow GunZ DB 

//Configura��es "Ultimas Do F�rum"
$link25 = "http://link/forum/"; //Link do seu forum!
$server = "localhost"; //Nome do servidor do Mysql (Padr�o:localhost)
$dbnamef = "forum"; // Indique o nome do banco de dados (Database do f�rum)
$usuario = "root"; // Indique o nome do usu�rio que tem acesso
$password = "senha mysql"; // Indique a senha do usu�rio
$mode = "off"; //Se o modo estiver "on" � porque esta ativado, se tiver "off" � porque esta desativado
?>