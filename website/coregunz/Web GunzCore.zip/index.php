﻿<?php
include "conf/config.php";
include "conf/_functions.php";
include "conf/checkcookie.php";
include 'conf/shield.php';
include 'conf/antisql.php';
include 'conf/anti_sql.php';
include 'conf/sql_check.php';
include 'conf/sqlcheck.php';
include 'conf/inject.php';
include 'conf/pls.php';
include 'conf/banneduser.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("paginas/pag_" . $_GET['do'] . ".php")) {
        include "paginas/pag_" . $_GET['do'] . ".php";
	}
} }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<!-- Por Favor , Não remova os Creditos  -->
<!-- Welliton : Criação do Layout e Visual  -->
<!-- Pablo : Programção e Desenvolvimento  -->
<!-- Nome : Publicação e divulgação da web  -->
<title>GunzCore v1.0</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Welliton Gervickas" />
<meta name="keywords" content="Jogos , Jogos Online, Fps online , Action Fps , Online fps action , Gunz , Gunz the Duel , the duel , Servidor pirata , The Duel , Gunz Online , online gunz , Online jogos , play Game , gz online , Br Gunz" />
<link rel="shortcut icon" href="images/favicon.png" />
<!-- Folhas de Estilo -->
<link rel="stylesheet" href="css/estilo.css" type="text/css" />
<link rel="stylesheet" href="css/formularios.css" type="text/css" />
<link rel="stylesheet" href="css/tipTip.css" type="text/css" />
<link rel="stylesheet" type="text/css" href="javascript/slider/themes/carbono/jquery.slider.css" />
<!--[if IE 6]>
<link rel="stylesheet" type="text/css" href="javascript/slider/themes/carbono/jquery.slider.ie6.css" />
<![endif]-->
<!-- Arquivos Js , jquery e Java -->
<script type="text/javascript" src="javascript/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="javascript/jquery.min.js"></script>
<script type="text/javascript" src="javascript/jquery.tipTip.js"></script>
<script type="text/javascript" src="javascript/jquery.tipTip.minified.js"></script>
<script type="text/javascript" src="javascript/slider/jquery.slider.min.js"></script>
<!-- Codigos de js -->
<script type="text/javascript">
$(function(){

$(".someClass").tipTip();

});
</script>
<script type="text/javascript">
jQuery(document).ready(function($) {
      $(".slider").slideshow({
        width      : 660,
        height     : 200,
        pauseOnHover : false,
        transition : ['slideLeft', 'slideRight', 'slideTop', 'slideBottom']
      });
      
      $(".caption").fadeIn(500);

      // playing with events:
      
      $(".slider").bind("sliderChange", function(event, curSlide) {
        $(curSlide).children(".caption").hide();
      });
      
      $(".slider").bind("sliderTransitionFinishes", function(event, curSlide) {
        $(curSlide).children(".caption").fadeIn(500);
      });
    });
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
</script>
<!-- Outros arquivos externos -->
</head>
<body onload="MM_preloadImages('images/hover.png')">
<!-- Estrutura Base-->
<div class="principal">
	<!-- segunda estrutura Base -->
    <div class="sub_principal">
    	<!-- Header -->
  <div class="header">
        	<!-- logo -->
<div class="banner2">
            	<div style="width:900px; height:auto; margin-left:10px; padding:20px;">
                	<Div style="float:left;">
                    	<!-- LOGO -->
           	    		<img src="images/logo_tipo.png" width="290" height="160" />
                	</Div>
                    <Div style="float:right; width:300px;">
                   	<!-- Jogo Grátis --><a href="#" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('hover_jogue','','images/hover.png',1)"><img src="images/jogue_graca.png" alt="Jogue grátis" name="hover_jogue" width="200" height="160" border="0" id="hover_jogue" /></a></Div>
                <div class="break"></div>
        </div>
      </div>
            <!-- Hack --> <div class="break"></div>
      <!-- Fim de logo -->
      </div>
        <!-- Fim de Header -->
        <!-- Menu fundo -->
  <div class="menu_bg">
       	    <!-- Categorias do menu -->
            <ul id="menu">
                	<li><a href="index.php">Início</a></li>
                    <li><a href="index.php?do=registro">Registro</a></li>
                    <li><a href="index.php?do=download">Download</a></li>
                    <li><a href="#">Loja</a>
                    	<ul>
                        	<li><a href="index.php?do=shopd&sub=listallitems&expand=1&type=1">Loja Donator</a></li>
                            <li><a href="index.php?do=shope&sub=listallitems&expand=1&type=1">Loja Evento</a></li>
                        </ul>
                    </li>
                    <li><a href="#">Ranking</a>
                    	<ul>
                            <li><a href="index.php?do=rankp">Player</a></li>
                            <li><a href="index.php?do=rankc">Clan</a></li>
                    	</ul>
                    </li>
                    <li><a href="index.php?go=faq">Suporte</a></li>
                    <li><a href="index.php?go=suporte">Fórum</a></li>
            </ul>
            <div class="break"></div>
            <!-- Fim das categorias do menu -->
	  		</div>
        	<!-- Inicio do Site (paginas )-->
        	<div class="estrutura_page">
            	<!-- Divisao das paginas , Menu e estrutura -->
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("paginas/pag_" . $_GET['do'] . ".php")) {
        					include "paginas/pag_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
                <!-- esquerdo da pagina --->
                <Div class="left_page">
<? include "box/box_iLogin.php" ?>                    
<? include "box/box_status.php" ?> 
<? include "box/box_ranking.php" ?> 
<? include "box/box_rsociais.php" ?> 
                </Div>
                <!-- Lado direito da pagina -->
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("paginas/pag_" . $_GET['do'] . ".php")) {
							    include "paginas/pag_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "paginas/pag_home.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
                <!-- Fim dos dois lados -->
                <!-- Hack -->
                <div class="break"></div>
                <!-- Fim das divisao -->
            </div>
        <!-- Fim do site (Paginas ) -->
       	<!-- Fim do Fundo menu -->
      <div style="width:890px; height:auto; padding:5px; text-align:center; font-size:12px;">
      <h4>&copy; GunzCore - Todos os Direitos reservados - Programação Pablo  | Design By Welliton gervickas | Versão 1.0 free</h4></div>    
    </div>
    <!-- fim de segunda estrutura base-->
</div>
<!-- Fim de estrutura Base -->
<!-- Não Remova os creditos por favor. -->
</body>
</html>