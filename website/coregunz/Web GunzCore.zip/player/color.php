<?
//Name color By:Pablo '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

$step = Filtrrar($_GET['step']);
$aid22 = antisql($_SESSION['AID']);

if ($step == ""){
?>
<form id="site_Login" name="site_Login" method="post" action="index.php?do=charcp&page=color&step=1">
<ul id="cat_quadrados">
<li>Recuperar personagem:</li>
<p>&nbsp;</p>
<li>Voc&ecirc; ir&aacute; gastar <font color=red>40</font> Coins.</li>
<li>Selecione a cor de seu nick name: <select name="color222" class="text">
<option value="4">Roxo</option>
<option value="5">Laranja</option>
<option value="6">Amarelo</option>
<option value="7">Verde �gua</option>
<option value="8">Cinza</option>
<option value="9">Azul Escuro</option>
<option value="13">Rosa</option>
<option value="14">Vermelho</option>
<option value="16">Lilas</option>
<option value="17">Azul</option>
</select></li>
<li><font color="#8968CD"> Roxo</font></li>
<li><font color="#FF6347"> Laranja</font></li>
<li><font color="#FFFF00"> Amarelo</font></li>
<li><font color="#00CED1"> Verde &Aacute;gua</font></li>
<li><font color="#8B8989"> Cinza</font></li>
<li><font color="#00008B"> Azul Escuro</font></li>
<li><font color="#FF00FF"> Rosa</font></li>
<li><font color="red"> Vermelho</font></li>
<li><font color="#8968CD"> Lilas</font></li>
<li><font color="#1E90FF"> Azul</font></li>
<input type="hidden" name="color55" value="1">
<li><input class="go" name="color2" type="submit" id="login" value="Comprar"></li>
</form>
<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    msgbox ("Voc� comprou Admin com sucesso!!  Brinks HAHA");
}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 30) 
{
	msgbox ("Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem Coins suficientes","index.php?do=charcp");
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -40 where AID='$aid22'");
msgbox ("Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.","index.php?do=charcp");
}
}else{
echo "Acesse site.aulagunz.com.br";
}
}



$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>
