<?php
if(isset($_POST['cambiar'])){
$pj = clean($_POST['pjs']);
$sex = clean($_POST['sex']);
if(empty($pj) || $sex != 0 && $sex != 1)
{
	msgbox(" Error Inesperado ","index.php?do=charcp");
}
mssql_query("UPDATE Character SET Sex='".$sex."' WHERE AID='".$_SESSION['AID']."' AND CID='".$pj."'");
msgbox("Sexo trocado com sucesso","index.php?do=charcp");
}else{
?>
<form name="sex0" method="post">
<ul id="cat_quadrados">
<li>Trocar Sexo :</li>
<p>&nbsp;</p>
<li>Selecione o personagem: <?php
$q = mssql_query("SELECT * FROM Character WHERE AID ='".$_SESSION['AID']."' AND NAME != '' Order by CharNum ASC");
if(mssql_num_rows($q))
{
	?><select name="pjs"><?
	while($r = mssql_fetch_object($q))
	{
		?>
        
        <option value="<?=$r->CID?>">
        <?=$r->Name?>
        </option>
        
        <?
	} ?>
    </select></li>
    <li>Selecione o sexo: <select name="sex">
    <option value="0">Masculino</option>
    <option value="1">Feminino</option>
    </select></li>
    <li><input class="go" type="submit" name="cambiar" value="Trocar Sexo" /></li>
</ul>
    <?
}else{
	?>
    Voce nao possui personagem
 <? }  ?>
</font>
</form>
<? } ?>