<?
//Cria��o de clan By Pablo ;D

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables", "union", "UPDATE", "update");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

$login22 = antisql($_SESSION['UserID']);
$etapa = antisql($_GET['etapa']);
$aid22 = antisql($_SESSION['AID']);

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
            msgbox("Voc� n�o possui nenhum personagem.","index.php?do=usercp");
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="index.php?do=charcp&page=criarclan&etapa=1">
<ul id="cat_quadrados">
<li>Recuperar personagem:</li>
<p>&nbsp;</p>
<li>Escolha o L&iacute;der: <select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select></li>
<li>Nome do clan: <input type="text" id="name1" class="log_field" size="16" name="name1" value="" maxlength="10"></li>
<li><input class="go" type="submit" name="criar" value="Criar Clan"/></li>
</ul>
</form>

<?
}

if($etapa == 1)
{

$cid22 = antisql($_POST['cid22']);
$name1 = antisql($_POST['name1']);

if(strlen($name1) > 10){
            msgbox("Nome muito grande, somente ate 10 letras","index.php?do=charcp&page=criarclan");
    die();
        }
if(strlen($name1) < 4){ 
            msgbox("Nome muito curto, coloque maior que 4 letras","index.php?do=charcp&page=criarclan");
    die();
        }

$busca1 = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$cid22'"); 
$busca2 = mssql_query("SELECT Name FROM Clan WHERE Name = '$name1'"); 
$busca3 = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$cid22'");

if (mssql_num_rows($busca2) >= 1){
            msgbox("Este clan ja existe","index.php?do=charcp&page=criarclan");
    die();
        }
if (mssql_num_rows($busca1) >= 1){
            msgbox("Voc� ja possui um clan.","index.php?do=charcp&page=criarclan");
    die();
        }
if (mssql_num_rows($busca3) == 0 )
        {
            msgbox("Esse char pertence a outra conta.","index.php?do=charcp&page=criarclan");
    die();
    }

$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$name1', '$cid22', GETDATE())");
$res = mssql_query("SELECT * FROM Clan(nolock) WHERE Name = '$name1' AND MasterCID = '$cid22'");
        $usr = mssql_fetch_assoc($res);
        $clid = $usr['CLID'];

mssql_query("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$cid22', 1, GETDATE())"); 
if($sql){

    msgbox("Clan criado com sucesso.","index.php?do=charcp"); 
    die();  
}else{ 
    msgbox("Erro!","index.php?do=charcp"); 
    die();  
} 
} 

?>