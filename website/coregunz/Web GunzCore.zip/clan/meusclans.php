<ul id="cat_quadrados">
<li>Meus clans:</li>
<p>&nbsp;</p>
<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(mssql_num_rows($q))
{
	while($r = mssql_fetch_object($q))
	{
		$qq = mssql_query("SELECT * FROM Clan WHERE MasterCID='".$r->CID."' Order by CLID ASC");
		if(mssql_num_rows($qq))
		{
			$rr = mssql_fetch_object($qq);
			$qqq = mssql_query("SELECT * FROM Pedidos WHERE CLIDClan='".$rr->CLID."' Order by ID DESC");
			?>
            Master: <?=master($rr->MasterCID)?> <? if(activo($rr->MasterCID) == 0) { ?>
            <a style="color:#F00" href="index.php?do=desativar&cid=<?=$rr->MasterCID?>&id=1">Desativar Pedidos do Clan</a> <br />
			<? }else{ ?>
            <a style="color:#F00" href="index.php?do=desativar&cid=<?=$rr->MasterCID?>&id=0">Ativar Pedidos do Clan</a>
            <br />
			<? }
			if(mssql_num_rows($qqq))
			{
				?>
				<table width="494">
                <tr>
                <td align="center">Clan</td><td align="center">Personagem</td><td align="center">Level</td><td align="center">Status</td><td align="center">Data</td><td>&nbsp;</td><td>&nbsp;</td>
                </tr>
                
                <?
				while($rrr = mssql_fetch_object($qqq))
				{
					if($rrr->Status == 0)
					{
						$status = 'Esperando';
					}elseif($rrr->Status == 1){
						$status = 'Aprovado';
					}else{
						$status = 'Reprovado';
					}
					?>
                    <tr>
                    <td align="center"><?=$rr->Name?></td><td align="center"><?=$rrr->Personaje?></td><td align="center"><?=$rrr->Level?></td><td align="center"><?=$status?></td><td align="center"><?=$rrr->Fecha?></td>
                    <?
					if($rrr->Status == 0)
					{ ?>
                    <td align="center"><a style="color:#0F0" href="index.php?do=aprovar&clid=<?=$rr->CLID?>&id=<?=$rrr->ID?>&cid=<?=$rrr->CID?>">Aprovar</a></td><td align="center"><a style="color:#F00" href="index.php?do=rejeitar&id=<?=$rrr->ID?>&clid=<?=$rr->CLID?>">Rejeitar</a></td>
					<?
					}else{
					?>
                    <td>&nbsp;</td><td>&nbsp;</td>
                    <?
					}
					?>
                    </tr>
                    <?
				}
				?>
				</table><br><br>
                <?
			}else{
				echo "Nao possui pedidos";
			}
		}else{
			echo "Voce nao e dono de nenhum clan<br>";
		}
	}
}else{
	echo "Voce nao possui nenhum personagem";
}
?>