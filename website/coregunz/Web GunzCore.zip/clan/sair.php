<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$q = mssql_query("SELECT * FROM Character a INNER JOIN ClanMember b ON a.CID=b.CID WHERE a.AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo "<ul id='cat_quadrados'>
<li>Sair ou encerrar um clan:</li>
<p>&nbsp;</p>Voc&ecirc; n&atilde;o possuiu nenhum clan</ul>";
}else{
?>
<form name="sair" method="post">
<ul id="cat_quadrados">
<li>Sair ou encerrar um clan:</li>
<p>&nbsp;</p>
<font color="#FF0000">Bom, aqui voce tambem pode fechar um clan, e remover todos os membros, incluindo a si mesmo.</font><br>
Sair ou encerrar o clan: <?=getclan($clid)?><p>&nbsp;</p>
Selecione o personagem: <select name="pj">
<? while($r = mssql_fetch_object($q))
{
	?>
	<option value="<?=$r->CID?>"><?=$r->Name?> - <?=getclan($r->CLID)?></option>
    <?
	
}
?>
</select>
<br /><br />
<input class="go" type="submit" name="sair" value="Sair do Clan" />
</form>
</ul>
<?php
if(isset($_POST['sair']))
{
	$cid = clean($_POST['pj']);
	$q = mssql_query("SELECT * FROM Character a INNER JOIN ClanMember b ON a.CID=b.CID WHERE a.AID='".$_SESSION['AID']."' AND a.CID='".$pj."'");
	if(!mssql_num_rows($q))
	{
		msgbox("Este personagem nao pertence a voce","index.php");
	}
	$r = mssql_fetch_object($q);
	if($r->Grade != 1)
	{
		mssql_query("DELETE FROM ClanMember WHERE CID='".$cid."'");
		msgbox("O personagem ".getcha($cid)." saiu do clan","index.php?do=clancp");
	}else{
		mssql_query("DELETE FROM ClanMember WHERE CLID='".$r->CLID."'");
		mssql_query("DELETE FROM Clan WHERE CLID='".$r->CLID."'");
		msgbox("Clan ".getclan($r->CLID)." Deletado","index.php?do=clancp");
	}
	
}
}
?>