<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$q = mssql_query("SELECT * FROM Character a INNER JOIN Clan b ON a.CID=b.MasterCID WHERE a.AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	echo '<ul id="cat_quadrados">
<li>Mudar Status de um Membro:</li>
<p>&nbsp;</p>Voc&ecirc; n&atilde;o e dono de nenhum clan.</ul>';
	die();
}
if(!isset($_GET['paso']) || !is_numeric($_GET['paso']))
{
	$paso = 1;
}else{
	$paso = clean($_GET['paso']);
}

if($paso == 1){
	?>
<ul id="cat_quadrados">
<li>Mudar Status de um Membro:</li>
<p>&nbsp;</p>
    <form name="cambiar" method="post" action="index.php?do=clancp&page=mudar&paso=2">
	Clan: <select name="clan">
	<?
	while($r = mssql_fetch_object($q))
	{
	?>
    	<option value="<?=$r->CLID?>"><?=getclan($r->CLID)?></option>
        <?
	}

?>
		</select>
        <br><br>
        <input class="go" type="submit" name="cambiar" value="Seleccionar">
        </form>
</ul>
        <? }
		elseif($paso == 2)
		{
			$clid = clean($_POST['clan']);
			if(empty($clid))
			{
				msgbox("Nenhum clan foi selecionado","index.php?do=clancp&page=mudar");
			}
			$q = mssql_query("SELECT * FROM Character a INNER JOIN Clan b ON a.CID=b.MasterCID WHERE a.AID='".$_SESSION['AID']."' AND CLID='".$clid."'");
if(!mssql_num_rows($q))
{
	echo "<ul id='cat_quadrados'>
<li>Mudar Status de um Membro:</li>
<p>&nbsp;</p>Voc&ecirc; n&atilde;o e dono de nenhum clan.<;ul>";

}else{
$q = mssql_query("SELECT * FROM ClanMember WHERE CLID='".$clid."' AND CID != '".getclancid($clid)."'");

if(!mssql_num_rows($q))
{
	echo '<ul id="cat_quadrados">
<li>Mudar Status de um Membro:</li>
<p>&nbsp;</p>O clan nao possui membros</ul>';
	
}else{
			?>
<ul id="cat_quadrados">
<li>Mudar Status de um Membro:</li>
<p>&nbsp;</p>
			<form name="cambiar" method="post" action="index.php?do=clancp&page=mudar&paso=3">
	Membro: <select name="char">
	<?
	while($r = mssql_fetch_object($q))
	{
	?>
    	<option value="<?=$r->CID?>"><?=getcha($r->CID)?></option>
        <?
	}

?>
		</select><br>
        Status: <select name="grado">
        <option value="2">Administrador</option>
        <option value="9">Normal</option>
        <option value="0">Retirar</option>
        </select><br>
        <input class="go" type="submit" value="Mudar Status" name="cambiarr">
        </form</ul>
            <?
			
}}}elseif($paso == 3){
			
			$rango = clean($_POST['grado']);
			$cid = clean($_POST['char']);
			if(!is_numeric($rango))
			{
				msgbox("Error","index.php");
			}
			if(!is_numeric($cid))
			{
				msgbox("Error","index.php?do=clancp");
			}
			if($rango == 0)
			{
				mssql_query("DELETE FROM ClanMember WHERE CID='".$cid."'");
				msgbox("Membro retirado do clan","index.php?do=clancp");
			}else{
				mssql_query("UPDATE ClanMember SET Grade='".$rango."' WHERE CID='".$cid."'");
				msgbox("Status Mudado","index.php?do=clancp");
			}
		}
			?>