﻿<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
if(isset($_POST['changepassword']))
{
	$opass = clean($_POST['oldpassword']);
	$npass = clean($_POST['newpassword']);
	$npass1 = clean($_POST['repeatnewpassword']);
	if(empty($opass) || empty($npass) || empty($npass1))
	{
		msgbox("Preencha os campos obrigatorios","index.php?do=contacp&page=pass");
	}
	if($npass != $npass1)
	{
		msgbox("Senhas nao correspondem","index.php?do=contacp&page=pass");
	}
	$q = mssql_query("SELECT * FROM Login WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
	if($r->Password != $opass)
	{
		msgbox("Senha atual incorreta","index.php?do=contacp&page=pass");
	}
	mssql_query("UPDATE Login SET Password='".$npass."' WHERE AID='".$_SESSION['AID']."'");
	msgbox("Senha trocada  corretamente","index.php?do=contacp");
}else{
	?>
<form name="pass" method="post">
<ul id="cat_quadrados">
<li>Mudar Senha:</li>
<p>&nbsp;</p>
<li>Senha Atual:<input type="password" name="oldpassword" /></li>
<li>Nova Senha:<input type="password" name="newpassword" /></li>
<li>Repita a nova senha:<input type="password" name="repeatnewpassword" /></li>
<li><input class="go" type="submit" name="changepassword" value="Mudar Senha" /></li>
</ul>
</form>
<? } ?>