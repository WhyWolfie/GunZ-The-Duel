<?php
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$q = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION['AID']."'");
	$r = mssql_fetch_object($q);
if(isset($_POST['update']))
{
	$nome = clean($_POST['nome']);
	$idade = clean($_POST['idade']);
	$email = clean($_POST['email']);
	if(!is_numeric($idade))
	{
		msgbox("A idade deve ser somente n�meros","index.php?do=contacp&page=edit");
	}
	
	mssql_query("UPDATE Account SET Name='".$nome."', Age='".$idade."', Email='".$email."' WHERE AID='".$_SESSION['AID']."'");
	
	msgbox("Dados Alterados com sucesso","index.php?do=contacp");
	
}else{

?>
<form name="datos" method="post">
<ul id="cat_quadrados">
<li>Editar Datos :</li>
<p>&nbsp;</p>
<li>Nome :<input type="text" name="nome" value="<?=$r->Name?>" /></li>
<li>Idade :<input type="number" name="idade" value="<?=$r->Age?>" /></li>
<li>Email :<input type="email" name="email" value="<?=$r->Email?>" /></li>
<li><input class="go" type="submit" name="update" value="Atualizar" /></li>
</ul>
</form>
<? } ?>