<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$user = $_SESSION['UserID'];
$aid = $_SESSION['AID'];
$query1 = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
$conta = mssql_fetch_assoc($query1);
$query2 = mssql_query("SELECT * FROM Login WHERE UserID = '$user'");
$conta1 = mssql_fetch_assoc($query2);
?> 


	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Minha Conta</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li>Meu login: <?=$conta['UserID']?></li>
<li>Meu Email: <?=$conta['Email']?></li>
<li>Status da Conta: <?
                                                    switch ( $conta['UGradeID'] ){
                                                        case "0";
                                                        $ugradeID = "Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeID = "Event Winner";
                                                        break;
                                                        case "3";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "4";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "5";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "6";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "7";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "8";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "9";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "10";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "11";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "12";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Mute";
                                                        break;
                                                        case "252";
                                                        $ugradeID = "Moderador";
                                                        break;
                                                        case "254";
                                                        $ugradeID = "Game Master";
                                                        break;
                                                        case "255";
                                                        $ugradeID = "Administrador";
                                                        break;
                                                    } echo $ugradeID;

                                                        ?></li>
<li>Saldo em RZCoins: <?=$conta1['RZCoins']?></li>
<li>Saldo em EVCoins: <?=$conta1['EVCoins']?></li>
<div align="right"><li><a href="index.php?do=contacp">Configura&ccedil;&otildees Avan&ccedil;adas</a></li></div>
</ul>
                        
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->