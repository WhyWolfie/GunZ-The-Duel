<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
$aid = $_SESSION['AID'];
$query = mssql_query("SELECT * FROM Character WHERE AID = '$aid' ORDER BY Level DESC");
$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character WHERE AID = '$aid' ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character WHERE AID = '$aid' ORDER BY DeathCount DESC"));
$busca = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid' AND DeleteFlag = '0'");

if( mssql_num_rows($busca) < 1 )
{
            msgbox("Voce nao possui nenhum personagem.","index.php");
}
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Meus Personagens</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li>Mais matou: <?=$matou[0]?></li>
<li>Mais morreu: <?=$morreu[0]?></li>
<li>Meus personagens:</li>
<table width="450" align="center"><tr height='23' style='font-weight:bold;'>
<td width="105" align="center"><b>Nome</b></font></td>
<td width="73" align="center"><b>Level</b></font></td>
<td width="105" align="center"><b>Sexo</b></font></td>
<td width="116" align="center"><b>XP</b></td>
<td width="138" align="center"><b>Kill/Deaths</b></td>
</tr>
<?
while($personagens = mssql_fetch_assoc($query)){
?>
<tr>
<td align="center"><?=$personagens['Name']?></td>
<td align="center"><?=$personagens['Level']?></td>
<td align="center"><?
                                                    switch ( $personagens['Sex'] ){
                                                        case "0";
                                                        $sex = "Masculino";
                                                        break;
                                                        case "1";
                                                        $sex = "Feminino";
                                                        break;
                                                    } echo $sex;

                                                        ?></td>
<td align="center"><?=$personagens['XP']?></td>
<td align="center"><?=$personagens['KillCount']?>/<?=$personagens['DeathCount']?></font></td>
</tr>
<? } ?>
</table>
<div align="right"><li><a href="index.php?do=charcp">Configura&ccedil;&otildees Avan&ccedil;adas</a></li></div>
</ul>

                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->