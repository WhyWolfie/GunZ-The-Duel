﻿<?php
if(!isset($_SESSION['AID']))
{
	msgbox("quem e voce? -.-!","index.php");
}

if(!isset($_GET['id']) && !isset($_GET['clid']))
{
	msgbox("Error","index.php");
}
if(!is_numeric($_GET['id']) && !is_numeric($_GET['clid']))
{
	msgbox("Error","index.php");
}
$id = clean($_GET['id']);
$clid = clean($_GET['clid']);
$q = mssql_query("SELECT * FROM Clan a INNER JOIN Character b ON a.MasterCID=b.CID WHERE b.AID='".$_SESSION['AID']."' AND a.CLID='".$clid."'");
if(!mssql_num_rows($q))
{
	msgbox("Voce nao e nada daqui ¬¬","index.php");
}

mssql_query("UPDATE Pedidos SET Status='2' WHERE ID='".$id."'");
msgbox("Pedido Rejeitado","index.php?do=clancp");
?>