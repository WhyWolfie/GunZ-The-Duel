<?		
$query2 = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND Name != '' ORDER BY CharNum ASC");
if (mssql_num_rows($query2)){
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Meus Clans</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li>Meus Clans:</li>
<table border='0' style='border-collapse: collapse' width='515'><tr height='23' style='font-weight:bold;'>
<td align="center">Clan Name</td>
<td align="center">Clan Leader</td>
<td align="center">Wins</td>
<td align="center">Losses</td>
<td align="center">Draws</td></tr>
<?
while ($cha = mssql_fetch_assoc($query2)){

$clanq = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$cha['CID']."'");
if (mssql_num_rows($clanq) != 0){
$clanq2 = mssql_fetch_assoc($clanq);
if($clanq2['Grade'] == 9){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><a href="index.php?do=claninfo&id=<?=$claninfo['CLID']?>"><?=$claninfo['Name']?></a></td>
<td align="center"><?=Char($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td>
<td align="center"><?=$claninfo['Draws']?></td></tr>
<?
}
}else
if($clanq2['Grade'] == 1){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><?=$claninfo['Name']?></td>
<td align="center"><?=FormatCharName($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td>
<td align="center"><?=$claninfo['Draws']?></td></tr>
<?
}
}else
if($clanq2['Grade'] == 2){
{
$claninfoq = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clanq2['CLID']."'");
$claninfo = mssql_fetch_assoc($claninfoq);
?>
<tr style='font-size:11px;'><td align="center"><?=$claninfo['Name']?></td>
<td align="center"><?=Char($cha['CID'])?></td>
<td align="center"><?=$claninfo['Wins']?></td>
<td align="center"><?=$claninfo['Losses']?></td>
<td align="center"><?=$claninfo['Draws']?></td></tr>
<?
}
}
}
}
}
?>
</table>
<div align="right"><li><a href="index.php?do=clancp">Configura&ccedil;&otildees Avan&ccedil;adas</a></li></div>
</ul>
                        
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->