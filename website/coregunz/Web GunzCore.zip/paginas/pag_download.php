	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Download</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
			<div class="contentBox">
              <ul class="rank">
            	<li><h2 class="noMargin style1">Links Para  Download</h2></li>

                <table width="612" border="1" align="center" cellpadding="1" cellspacing="1" bgcolor="000" class="hover" style="border: 1px">
	<tr>
	  <th width="186" align="center" bgcolor="#FFFFFF">Nome do Arquivo</th>
	  <th width="186" align="center" bgcolor="#FFFFFF">Descri&ccedil;&atilde;o do Arquivo</th>
	  <th width="164" align="center" bgcolor="#FFFFFF">Tamanho</th>
	  <th width="240" align="center" bgcolor="#FFFFFF">Link do Arquivo</th>
	</tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">GunZCore</td>
	<td align="center" bgcolor="#FFFFFF">Mirror 1 </td>
	<td align="center" bgcolor="#FFFFFF">320 MB</td>
	<td align="center" bgcolor="#FFFFFF"><a class="active" href="#">[4Shared]</a></td>
  </tr>  <tr>
	<td align="center" bgcolor="#FFFFFF">GunZCore</td>
	<td align="center" bgcolor="#FFFFFF">Mirror 2 </td>
	<td align="center" bgcolor="#FFFFFF">320 MB</td>
	<td align="center" bgcolor="#FFFFFF"><a class="active" href="#">[GameFront]</a></td>
  </tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">GunZCore</td>
	<td align="center" bgcolor="#FFFFFF">Mirror 3 </td>
	<td align="center" bgcolor="#FFFFFF">320 MB</td>
	<td align="center" bgcolor="#FFFFFF"><a class="active" href="#">[MultiUpload]</a></td>
  </tr>
	</table>
<p>&nbsp;</p>

            	<li><h2 class="noMargin style1">Requerimentos Basicos</h2></li>
                <table class="style">
<table width="612" border="1" align="center"  cellpadding="2" cellspacing="1" bgcolor="000" class="hover"  style="border: 1px">
  <tr>
	<th align="center" bgcolor="#FFFFFF" >Tipo</th>
	<th align="center" bgcolor="#FFFFFF">M&iacute;nimo Requerido</th>
	<th align="center" bgcolor="#FFFFFF" >Recomendado</th>
  </tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">CPU</td>
	<td align="center" bgcolor="#FFFFFF">Pentium III - 700 MHz</td>
	<td align="center" bgcolor="#FFFFFF">Pentium IV - 2.0 GHz ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">RAM</td>
	<td align="center" bgcolor="#FFFFFF">256MB</td>
	<td align="center" bgcolor="#FFFFFF">512MB ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">Sistema Operacional</td>
	<td align="center" bgcolor="#FFFFFF">Win9x</td>
	<td align="center" bgcolor="#FFFFFF">Win2000/XP</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#FFFFFF">VGA</td>
	<td align="center" bgcolor="#FFFFFF">32MB</td>
	<td align="center" bgcolor="#FFFFFF">128MB ou superior</td>
  </tr>
  <tr>
	<td height="19" align="center" bgcolor="#FFFFFF">Conex&atilde;o</td>
	<td align="center" bgcolor="#FFFFFF">56k</td>
	<td align="center" bgcolor="#FFFFFF">Banda larga ou superior</td>
  </tr>
</table>
<p>&nbsp;</p>
  </div></div>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->