﻿<div class="right_page">
               	<!-- Lado central -->
                <div class="central_cat">
                <div class="all_central">
                <div class="central_sub_tit">
                    <div class="slider">
      				<div>
        			<div class="caption">
          				<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
       				 </div>
        				<img src="images/slides/slide_1.jpg" alt=""/>
      				</div>
      
      				<div>
        			<div class="caption">
          				<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
        			</div>
        				<img src="images/slides/slide_2.jpg" alt=""/>
      				</div>
      
      				<div>
        			<div class="caption">
          				<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
        			</div>
        				<img src="images/slides/slide_3.jpg" alt=""/>
      				</div>
      
      				<div>
        			<div class="caption">
          				<h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h4>
        			</div>
        				<img src="images/slides/slide_4.jpg" alt=""/>
      				</div>
    			</div>
                </div>
                </div>
                    <div class="all_central">
                       	  <div class="central_tit"><div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
                       	    <h5>Atualizações e Novidades</h5></div></div>
                            <div class="central_sub_tit">
                            	<ol>
<?
$res = mssql_query_logged("SELECT TOP 5 * FROM Noticia ORDER BY ID DESC");
while($n = mssql_fetch_assoc($res)){
?>
                                	<li id="listagens"><h4><a href="index.php?do=noticia&sub=anuncio&id=<?=$n['ID']?>"><?=$n['Titulo']?></a></h4></li>
<?}?>
                                </ol>
                            </div>
                            <div class="break"></div>
                        </div>
                    </div>
                    <div class="central_cat">
                    	<div class="all_central">
                       	  <div class="central_tit"><div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
                       	    <h5>Ultimas do fórum</h5></div></div>
                            <div class="central_sub_tit">
<?
//Script de ultimas do forum Coded By Pablo ;D

if($mode == on)

{


if(!($id = mysql_connect($server,$usuario,$password))) {
   echo "<ol><li id='listagens'><h4>Forum em manuntenção</h4></ol>";
}


if(!($con=mysql_select_db($dbnamef,$id))) {
   echo "<ol><li id='listagens'><h4>Forum em manuntenção</h4></ol>";
} 

$busca1 = mysql_query("SELECT tid, title, starter_name FROM topics ORDER BY start_date DESC LIMIT 6");

while($busca2 = mysql_fetch_row($busca1))
{

$busca3 = mysql_query("SELECT member_id FROM members WHERE members_display_name = '$busca2[2]'");
$busca4 = mysql_fetch_row($busca3);

?>
                            	<ol>
<li id="listagens"><h4><a href="<?=$link25?>index.php?/topic/<?=$busca2[0]?>-<?=$busca2[1]?>/"><?=$busca2[1]?></a></h4></li>
<li id="listagens"><h4><a target="meio" href="<?=$link25?>index.php?/user/<?=$busca4[0]?>-<?=$busca2[2]?>/"><?=$busca2[2]?></a></h4></li>
                                </ol>

<?
}
}else{
echo "<ol><li id='listagens'><h4>Forum em manuntenção</h4></ol>";
}
?>
                            </div>
                            <div class="break"></div>
                        </div>
                    </div>
                    <div class="central_cat">
                    	<div class="all_central">
                       	  <div class="central_tit"><div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
                       	    <h5>Ultima Guerra de Clã</h5></div></div>
                            <div class="central_sub_tit">
                       	    <div class="cla_atk">
<?php
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}
$war = mssql_query("SELECT TOP 1 WinnerClanName, LoserClanName, RoundWins, RoundLosses, WinnerClid, LoserClid FROM ClanGameLog ORDER BY id DESC;");
$clan = mssql_fetch_object($war);
$winclid = Filtrrar($clan->WinnerClid);
$loseclid = Filtrrar($clan->LoserClid);
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$winclid' AND DeleteFlag=0");
$clanwin = mssql_fetch_object($query);
$query1 = mssql_query("SELECT * FROM Clan WHERE CLID = '$loseclid' AND DeleteFlag=0");
$clanlose = mssql_fetch_object($query1);
$war1 = mssql_query("SELECT TOP 1 WinnerClanName, LoserClanName, RoundWins, RoundLosses, WinnerClid, LoserClid FROM ClanGameLog ORDER BY id DESC;");
while ($wars = mssql_fetch_row($war1)) {
?>
                                	<div class="img_cla"><img src="<?=($clanwin->EmblemUrl == "") ? "images/_clan.png" : $clanwin->EmblemUrl?>" width="60" height="60"></div>
                                    <div class="img_cla_2"><img src="<?=($clanlose->EmblemUrl == "") ? "images/_clan.png" : $clanlose->EmblemUrl?>" width="60" height="60"></div>
                                    <div class="cla_texto"><?=$wars[0];?></div>
                                    <div class="cla_texto_2"><?=$wars[1];?></div>
                              </div>
                            </div>
                            <div class="central_sub_tit"><strong>Resultado:</strong> <?=$wars[0];?> <?=$wars[2];?> x <?=$wars[3];?> <?=$wars[1];?></div>
<?php
}
?>
                            <div class="break"></div>
                        </div>
                    </div>
                    <!-- Fim do lado central -->
                </div>