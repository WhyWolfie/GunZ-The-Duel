<?php	
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Clan") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 50; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Clan where Point not in (select top $max Point from Character order by Point desc) order by Point desc");
$name = mssql_fetch_row($result);
if(mssql_num_rows($result)){
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Player Ranking</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<table width="506" align="center">
<tr>
<td width="51" align="center"><b>#</b></td><td width="105" align="center"><b>Name</b></td><td width="105" align="center"><b>Master</b></td><td width="73" align="center"><b>Points</b></td><td width="137" align="center"><b>Win/Losses (%)</b></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
		<tr>
		<td align="center"><?php echo "$rank";?></td><td align="center"><a href='index.php?do=claninfo&id=<?php echo "$row[0]";?>'><?=utf8_encode($row[1])?></a></td><td align="center"><? $res2 = mssql_query("SELECT * FROM Character WHERE CID = '".$row[5]."'");
                                                                            $c = mssql_fetch_assoc($res2);
                                                                            echo $c['Name'];
                                                                        ?></font></td><td align="center"><?php echo "$row[4]";?></td><td align="center"><?php echo "$row[6]";?>/<?php echo "$row[13]";?>(<?
																			$matchTotal = $row[6] + $row[13] + $row[14];
																			if ($matchTotal > 0)
																			{
																				echo(round($row[6] / $matchTotal * 100));
																			}
																			else
																			{
																				echo(0);
																			}
																		?>%)</td>
		</tr>
        <? $i++;
	}?>
    </table>
<br><center><?
echo "<p>"; 
echo "Pagina $pagenum de $last <p>";
if ($pagenum == 1) { }
else
{
echo "<a href='index.php?do=rankc&pagenum=1'> <<-Primeira |</a> ";
echo " ";
$previous = $pagenum-1;
echo "<a href='index.php?do=rankc&pagenum=$previous'> <-Anterior |</a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=rankc&pagenum=$next'>Proxima -></a> ";
echo " ";
echo " <a href='index.php?do=rankc&pagenum=$last'>| Ultima ->></a> ";
}
?></center>
<? 
}else{
	echo "Nenhum personagem foi encontrado</font>";
} 
?>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->