<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 104){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 0){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 1){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 2){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 3){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 4){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 5){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 6){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 7){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 8){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 9){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 10){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 11){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 12){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 13){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 14){
    msgbox("Access Denied","index.php");
}
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Configura&ccedil;&otildees Avan&ccedil;adas</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li><a href="index.php?do=admincp&page=addanuncio">Adionar Anuncio</a></li>
<li><a href="index.php?do=admincp&page=banuser">Banir Usuario</a></li>
<li><a href="index.php?do=admincp&page=muteuser">Mutar Usuario</a></li>
<li><a href="index.php?do=admincp&page=unban">Desban/Desmute Usuario</a></li>
</ul><br>

<? if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "addanuncio")
	{
		include "adm/addanuncio.php";
	}elseif($page == "banuser"){
		include "adm/banuser.php";
	}elseif($page == "muteuser"){
		include "adm/muteuser.php";
	}elseif($page == "unban"){
		include "adm/unban.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=panel&page=".$page);
		msgbox("A pagina que voce esta procurando nao existe","index.php?do=admincp");
	}
	
}else{
}?>
<ul id="cat_quadrados">
<div align="right"><li><a href="index.php?do=minhaconta">Voltar</a></li></div>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->