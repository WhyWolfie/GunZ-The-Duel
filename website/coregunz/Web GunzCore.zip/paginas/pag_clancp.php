<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Configura&ccedil;&otildees Avan&ccedil;adas</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li><a href="index.php?do=clancp&page=meusclans">Meus Clans</a></li>
<li><a href="index.php?do=clancp&page=meuspedidos">Meus pedidos</a></li>
<li><a href="index.php?do=clancp&page=emblemas">Adcionar Emblema</a></li>
<li><a href="index.php?do=clancp&page=mudar">Mudar Status de um Membro</a></li>
<li><a href="index.php?do=clancp&page=sair">Sair ou encerrar um clan</a></li>
</ul><br>

<? if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "meusclans")
	{
		include "clan/meusclans.php";
	}elseif($page == "meuspedidos"){
		include "clan/meuspedidos.php";
	}elseif($page == "mudar"){
		include "clan/mudar.php";
	}elseif($page == "sair"){
		include "clan/sair.php";
	}elseif($page == "emblemas"){
		include "clan/emblemas.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=clancp&page=".$page);
		msgbox("A pagina que voce esta procurando nao existe","index.php?do=clancp");
	}
	
}else{
}?>
<ul id="cat_quadrados">
<div align="right"><li><a href="index.php?do=clancp">Voltar</a></li></div>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->