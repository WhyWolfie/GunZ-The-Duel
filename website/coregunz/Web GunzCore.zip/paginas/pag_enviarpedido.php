<?php
if(!isset($_SESSION['AID']))
{
	re_dir("index.php?do=login");
}
if(!isset($_GET['clid']) || !is_numeric($_GET['clid']))
{
	msgbox("Error","index.php");
}
$clid = clean($_GET['clid']);

$q = mssql_query("SELECT * FROM Clan WHERE CLID='".$clid."'");
if(mssql_num_rows($q))
{
	$r = mssql_fetch_object($q);
	if($r->Peticion != 0)
	{
		msgbox("Os pedidos desse clan est�o desativados.","index.php");
	}
}else{
	msgbox("Esse clan n�o existe.","index.php");
}

if(!isset($_POST['enviar']))
{
	?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Enviar pedido ao Clan <?=utf8_encode(getclan($clid))?></h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<form name="peticion" method="post">
<?
$q = mssql_query("SELECT * FROM Character WHERE AID='".$_SESSION['AID']."'");
if(!mssql_num_rows($q))
{
	msgbox("Voc� n�o possui nenhum personagem.","index.php");
}
?>
<li>Enviar Pedido ao Clan: <?=utf8_encode(getclan($clid))?></li>
<li>Selecione um Personagem: <select name="pj">
<? while($r = mssql_fetch_object($q))
{
	?>
	<option value="<?=$r->CID?>"><?=$r->Name?></option>
    <?
}
?>
</select></li>
<input class="go" type="submit" name="enviar" value="Enviar Pedido">
</font>
</form>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->
<?
}else{
	$cid = clean($_POST['pj']);
	$pj = getcha($cid);
	$lvl = getlvl($cid);
	$q = mssql_query("SELECT * FROM ClanMember WHERE CID='".$cid."'");
	if(mssql_num_rows($q))
	{
		mssql_query("DELETE FROM Pedidos WHERE CLIDClan='".$clid."' AND CID='".$cid."' AND Status='1'");
		msgbox("Este personagem ja pertence a outro clan.","index.php?do=enviarpedido&clid=".$clid."");
	}
	$q = mssql_query("SELECT * FROM Pedidos WHERE CLIDClan='".$clid."' AND CID='".$cid."'");
	if(mssql_num_rows($q))
	{
		msgbox("Voc� enviou um pedido ao clan com este personagem.","index.php?do=enviarpedido&clid=".$clid."");
	}
	mssql_query("INSERT INTO Pedidos (CID, Personaje, [Level], CLIDClan, Status, Fecha) VALUES ('".$cid."', '".$pj."', '".$lvl."', '".$clid."', '0', GETDATE())");
	msgbox("Pedido Enviado.","index.php");
}?>