<? include "conf/inject.php" ?>
<? include "conf/pls.php" ?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Configura&ccedil;&otildees Avan&ccedil;adas</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<li><a href="index.php?do=charcp&page=recuperar">Recuperar Personagem Deletado</a></li>
<li><a href="index.php?do=charcp&page=color">Comprar Name Color</a></li>
<li><a href="index.php?do=charcp&page=ev_coins">Trocar Pontos Cw</a></li>
<li><a href="index.php?do=charcp&page=sex">Trocar de Sexo</a></li>
<li><a href="index.php?do=charcp&page=criarclan">Criar Clan</a></li>
</ul><br>

<? if(isset($_GET['page']))
{
	$page = clean($_GET['page']);
	
	if($page == "recuperar")
	{
		include "player/recuperar.php";
	}elseif($page == "sex"){
		include "player/sex.php";
	}elseif($page == "color"){
		include "player/color.php";
	}elseif($page == "ev_coins"){
		include "player/ev_coins.php";
	}elseif($page == "criarclan"){
		include "player/criarclan.php";
	}else{
		logz("AID:[".$_SESSION['AID']."] - UserID:[".$_SESSION['USERID']."] : Intento entrar a la pagina: index.php?do=panel&page=".$page);
		msgbox("A pagina que voce esta procurando nao existe","index.php?do=charcp");
	}
	
}else{
}?>
<ul id="cat_quadrados">
<div align="right"><li><a href="index.php?do=personagens">Voltar</a></li></div>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->