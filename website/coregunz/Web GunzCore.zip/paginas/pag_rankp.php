	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Player Ranking</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
<font color="#FF0000">Admin</font> | <font color="#00FF00">Mod</font> | <font color="00FFFF">Donator</font> | Normal | <font color="#666666">Baneado</font><br />
--------------------------------------------------------------------------------------------------
</font>
</form>

<?php	
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Character") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 50; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Character where Level not in (select top $max Level from Character order by Level desc) order by Level desc");
$name = mssql_fetch_row($result);
if(mssql_num_rows($result)){
?>
<table width="506" align="center">
<tr>
<td width="51" align="center"><b>#</b></td><td width="105" align="center"><b>Name</b></td><td width="73" align="center"><b>Level</b></td><td width="116" align="center"><b>Sexo</b></td><td width="137" align="center"><b>Kill/Deaths (%)</b></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
		<tr>
		<td align="center"><?php echo "$rank";?></td><td align="center"><a href='index.php?do=charinfo&id=<?php echo "$row[3]";?>'><?=utf8_encode(FormatCharName($row[0]))?></a></td><td align="center"><?php echo "$row[3]";?></font></td><td align="center"><?
																		switch ( $row[4] ){
																		case "0";
																		$row[4] = "Masculino";
																		break;
																		case "1";
																		$row[4] = "Feminino";
																		break;
																		} echo $row[4];

																		?></td><td align="center"><?php echo "$row[32]";?>/<?php echo "$row[33]";?></td>
		</tr>
        <? $i++;
	}?>
    </table>
<br><center><?
echo "<p>"; 
echo "Pagina $pagenum de $last <p>";
if ($pagenum == 1) { }
else
{
echo "<a href='index.php?do=rankp&pagenum=1'> <<-Primeira |</a> ";
echo " ";
$previous = $pagenum-1;
echo "<a href='index.php?do=rankp&pagenum=$previous'> <-Anterior |</a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=rankp&pagenum=$next'>Proxima -></a> ";
echo " ";
echo " <a href='index.php?do=rankp&pagenum=$last'>| Ultima ->></a> ";
}
?></center>
<? 
}else{
	echo "Nenhum personagem foi encontrado</font>";
} 
?>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->