﻿<?
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $name = clean($_POST['name']);
    $address = clean($_POST['endereco']);
    $mobile = clean($_POST['telefone']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Email em uso.","index.php?do=registro");
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Usuario em uso.","index.php?do=registro");
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            msgbox("As senhas não coincidem.","index.php?do=register");
            $er = 1;
        }

        if($user == ""){
            msgbox("Por favor digite o nome de Usuario.","index.php?do=registro");
            $er = 1;
        }

        if($name == ""){
            msgbox("Por favor digite o nome de Usuario.","index.php?do=registro");
            $er = 1;
        }

        if($email == ""){
            msgbox("Por favor digite um email.","index.php?do=registro");
            $er = 1;
        }

        if(strlen($pw1) < 6){
            msgbox("Senha deve conter mais de 6 caracteres..","index.php?do=registro");
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            msgbox("Por favor digite uma senha.","index.php?do=registro");
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, UGradeID, PGradeID, RegDate, mobile, Address)Values ('$user', NULL, '$name','$email', 0, 0, GETDATE(),'$mobile', '$address')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins])VALUES('$user','$aid','$pw1',0,0)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>
<!-- Não é Fixo -->
<link rel="stylesheet" href="css/formularios.css" type="text/css" />
<link rel="stylesheet" href="css/estilo.css" type="text/css" />
<!-- Não é Fixo -->
<div class="right_page">
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto é o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Criar uma Nova conta</h5></div> 
        <!-- Isto é o Titulo do Quadrado -->
        </div>
       	<!-- Isto é o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
            <div class="d_cadastro"><span id="obrigatorio">Todos os Campos com * são obrigatorios</span></div>
       	    <div class="registro_left">
                	<div id="formulario">
                   	  <form name="reg" method="POST" action="index.php?do=registro">
                      	<div class="reg_left_div"><h6>Usuario <span id="obrigatorio">*</span> 8-16 </h6></div><!-- Titulo -->
                      	<div class="reg_left_div">
                    		  <label for="userid"></label>
                    		  <input name="userid" type="text" class="box_registro" id="user" maxlength="16" />
                      	</div>
                        <div class="reg_left_div"><h6>Senha <span id="obrigatorio">*</span> 6-8</h6></div><!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="passw"></label>
                          <input name="pw1" type="password" class="box_registro" id="passw" maxlength="8" />
                        </div>
                        <div class="reg_left_div"><h6>Re-Senha <span id="obrigatorio">*</span></h6></div><!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="passw2"></label>
                          <input name="pw2" type="password" class="box_registro" id="passw2" maxlength="8" />
                        </div>
                        <div class="reg_left_div"><h6>E-mail <span id="obrigatorio">*</span></h6></div><!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="email"></label>
                          <input name="email" type="text" class="box_registro" id="email" />
                        </div>
                        <div class="reg_left_div">
                          <h6>Nome Completo <span id="obrigatorio">*</span> 0-25</h6></div>
                        <!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="name"></label>
                          <input name="name" type="text" class="box_registro" id="name" maxlength="25" />
                        </div>
                        <div class="reg_left_div">
                          <h6>Endereço 0-20</h6></div>
                        <!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="address"></label>
                          <input name="addess" type="text" class="box_registro" id="adress" maxlength="20" />
                        </div>
                        <div class="reg_left_div">
                          <h6>Telefone 0-10 ( DD + Numero )</h6> </div>
                        <!-- Titulo -->
                        <div class="reg_left_div">
                          <label for="mobile"></label>
                          <input name="mobile" type="text" class="box_registro" id="phone" maxlength="10" />
                        </div>
                                    <input class="go" type="submit" name="submit" id="submit" value="Criar Conta" /> 
                        
                  	  </form>
               	</div>
                    <div class="break"></div>               
              </div>
                <div class="registro_right"><h6>Por Favor , Prencha todos os campos que solicitar * é importante para Completar Seu cadastro em nosso site. Assim que completar Seu registro você já pode Efetuar o Acesso ao Servidor. Tenha um bom jogo!</h6></div>
                <div class="break"></div>
        	</div>
            <div class="d_cadastro">Regras Básicas</div>
            <div class="central_sub_tit">
				<!-- Digite as regras no Arquivo de Texto localizado na Pasta do Site -->
            	<? include ('regras.html') ?>
            </div>
        <!-- Isto é o Titulo do Quadrado -->
        <!-- Isto é um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->
</div>

<?
}else{
?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto é o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Conta criada com sucesso</h5></div> 
        <!-- Isto é o Titulo do Quadrado -->
        </div>
       	<!-- Isto é o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
            A conta <span><?=$user?></span> foi criada corretamente<br>
            Voce pode jogar Fatality GunZ Agora.

                        
                    <div class="break"></div>               
              </div>
        <!-- Isto é o Titulo do Quadrado -->
        <!-- Isto é um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->
<?
}
?>