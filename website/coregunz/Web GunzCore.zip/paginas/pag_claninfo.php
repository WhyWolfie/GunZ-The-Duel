<?
$cinfo = antisql($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan Does not Exist","index.php");
exit();
}

$clid = $clan->CLID;
?> 
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Informa&ccedil;&otilde;es do Clan <?=utf8_encode($clan->Name)?></h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                               <center><ul id="cat_quadrados"><?=utf8_encode($clan->Name)?></br>
&nbsp;</br>
<img src="<?=($clan->EmblemUrl == "") ? "images/_clan.png" : $clan->EmblemUrl?>" width="100" height="100" BORDER=5 ></center></br>
&nbsp;</td>
</tr>
                          <tr>
                            <td bgcolor="#000000" class="Estilo1" align="center" valign="top">
<table width="447" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top">

<table border="2" style="border-collapse: collapse" width="447" height="100%">
<div align="center">
&nbsp;
                         <tr>			    
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Rank: </td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->Ranking?></td>

                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Pontos: </td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Win:</td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Losses:</td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Draw:</td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Criado:</td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados">&nbsp;&nbsp;&nbsp;Membros:</td>
                                    <td align="left" class="estilo1"><ul id="cat_quadrados"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="448" border="0" cellpadding="0" cellspacing="0">
&nbsp;
                                  <tr>
                                    <td align="center" class="estilo1"><u><ul id="cat_quadrados">Char</u></td>
                                    <td align="center" class="estilo1"><u><ul id="cat_quadrados">Rank</u></td>
                                    <td align="center" class="estilo1"><u><ul id="cat_quadrados">Entrou</u></td>
                                    <td align="center" class="estilo1"><u><ul id="cat_quadrados">Pontos</u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><ul id="cat_quadrados"><a href="index.php?do=charinfo&id=<?=($char->CID)?>"><?=utf8_encode(FormatCharName($char->CID))?></a></td>
                                    <td align="center" class="estilo1"><ul id="cat_quadrados"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><ul id="cat_quadrados"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><ul id="cat_quadrados"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
<center><a href="index.php?do=enviarpedido&clid=<?=$clan->CLID?>"><input class="go" type="submit" name="enviarpedido" value="Enviar pedidoao Clan" /></a></center>
                            </table></td>
                          </tr>
						</td>
					</tr>
			
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->