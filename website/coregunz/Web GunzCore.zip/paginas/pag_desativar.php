﻿<?php
if(!isset($_SESSION['AID']))
{
	msgbox("Quem e voce? -.-!","index.php");
}

if(!isset($_GET['cid']) || !isset($_GET['id']))
{
	msgbox("Error","index.php");
}
if(!is_numeric($_GET['cid']) || !is_numeric($_GET['id']))
{
	msgbox("Error","index.php");
}

$cid = clean($_GET['cid']);
$id = clean($_GET['id']);
if($id != 1 && $id != 0)
{
	msgbox("Error","index.php");
}
$q = mssql_query("SELECT * FROM Clan a INNER JOIN Character b ON a.MasterCID=b.CID WHERE b.AID='".$_SESSION['AID']."' AND a.MasterCID='".$cid."'");
if(!mssql_num_rows($q))
{
	msgbox("Voce nao e nada do clan ¬¬","index.php");
}

mssql_query("UPDATE Clan SET Pedidos='".$id."' WHERE MasterCID='".$cid."'");
if($id == 0)
{
	msgbox("Pedidos Ativados","index.php");
}else{
	msgbox("Pedidos Desativados","index.php");
}
?>