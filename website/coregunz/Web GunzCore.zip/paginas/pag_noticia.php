<?
if($_GET['sub'] == "anuncio"){
    $res = mssql_query("SELECT * FROM Noticia WHERE ID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Anuncio</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
<ul id="cat_quadrados">
            <li>Equipe GunzCore, <?=$a['Data']?></li><br>
            <?=$a['Noticia']?>
</ul>
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->

    <?
}else{
    $res = mssql_query("SELECT * FROM Noticia WHERE ID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Anuncio</h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
            Equipe Fatality GunZ, <?=$a['Date']?><br><br>
            <?=$a['Noticia']?>

                        
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->

<?}?>