<?
    $cid = antisql($_GET['id']);
if(!is_numeric($cid)){
msgbox("Not Available","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);

if($num_rows < 1){
msgbox("Account Does not Exist","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "253" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "254" || $char2['UGradeID'] == "255"){
    msgbox("You are not allowed to View this Account Information.","index.php");
exit();
	}
	if ( $char2['DeleteFlag'] != "0"){
    msgbox("Voc� n�o pode ver isso..","index.php");
exit();
	}
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
	<!-- Lado central -->
    <div class="central_cat">
    	<div class="all_central">
        <div class="central_tit">
        <!-- Isto � o Titulo do Quadrado -->
        	<div class="float"><img src="images/list1_active.png" width="8" height="11" /></div><div>
            <h5>Informa&ccedil;&otilde;es do Char <?=utf8_encode(FormatCharName($char['CID']))?></h5></div> 
        <!-- Isto � o Titulo do Quadrado -->
        </div>
       	<!-- Isto � o Conteudo do Quadrado -->
        	<div class="central_sub_tit">
                   <ul id="cat_quadrados"><table width="450" border="0" align="left" cellpadding="0" cellspacing="0">
                                <td align="left" valign="top"><table width="220" border="0" align="left">
<li><font style='font-weight:bold;'>Character Info:</font></li>
<li>Nome:</font></td> <?=utf8_encode(FormatCharName($char['CID']))?></li>
<li>Level: <?=$char['Level']?></li>
<li>Exp: <?=number_format($char['XP'],0,'','.');?></li>
<li>Kill/Death: <?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></li>
<li>Clan: <a href="index.php?do=claninfo&id=<?=$claninfo['CLID']?>"><?=utf8_encode(FormatCharName($claninfo['CID']))?></a></li></table></td>
                                <td align="left" valign="top"><table width="220" border="0" align="left">
<li><font style='font-weight:bold;'>Account Info:</font></li>
<li>Nome: <?=utf8_encode($char2['Name'])?></li>
<li>Sexo: <?
                                                    switch ( $char2['Sex'] ){
                                                        case "0";
                                                        $sex = "Masculino";
                                                        break;
                                                        case "1";
                                                        $sex = "Feminino";
                                                        break;
                                                    } echo $sex;

                                                        ?></li>
<li>Idade: <?=$char2['Age']?></li>
<li>Rank: <?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeID = "Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeID = "Event Winner";
                                                        break;
                                                        case "3";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "4";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "5";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "6";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "7";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "8";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "9";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "10";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "11";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "12";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Donator";
                                                        break;
                                                        case "13";
                                                        $ugradeID = "Mute";
                                                        break;
                                                        case "252";
                                                        $ugradeID = "Moderador";
                                                        break;
                                                        case "254";
                                                        $ugradeID = "Game Master";
                                                        break;
                                                        case "255";
                                                        $ugradeID = "Administrador";
                                                        break;
                                                    } echo $ugradeID;

                                                        ?></li></table></td></table>
</ul>                  
                    <div class="break"></div>               
              </div>
        <!-- Isto � o Titulo do Quadrado -->
        <!-- Isto � um Hack  -->
        <div class="break"></div>
        </div>
    </div>
    <!-- Fim do lado central -->