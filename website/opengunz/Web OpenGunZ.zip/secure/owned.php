<?
include"./secure/config.php";
include "./secure/anti_inject.php";
include "./secure/sql_check.php";
$ip = $_SERVER[REMOTE_ADDR];
$cargadedatos3 = mssql_query("SELECT IP,BanReason,BanDate FROM AccountBan WHERE IP='$ip' ");
$respuesta3      = mssql_fetch_assoc($cargadedatos3);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$_SERVERNAME?> - Cuenta Prohibida</title>
</head>

<body>
<p><strong><font size="6">Baneado</font></strong><br>
  <br>
Lista de cuentas prohibidas por esta ip:<?=$respuesta3['IP']?><br />
<?
$cargadedatos1	= mssql_query("SELECT AID,LastIP FROM Login WHERE LastIP='$ip' ");
$respuesta1	= mssql_fetch_assoc($cargadedatos1);
$aid		= $respuesta1[AID];
$cargadedatos2 	= mssql_query("SELECT TOP 1 * FROM Account WHERE AID='$aid' ORDER BY AID DESC");
$count = 1;
if($respuesta2 = mssql_fetch_assoc($cargadedatos2))
{
?>
|=========================CUENTA #<?=$count?>======================!<br />
AID:<?=$respuesta2['AID']?><br />
Nombre:<?=$respuesta2['UserID']?><br />
Email:<?=$respuesta2['Email']?><br />
Propietario:<?=$respuesta2['Name']?><br />
Fecha de  Registro:<?=$respuesta2['RegDate']?><br />
<?
$cargadedatos4 = mssql_query("SELECT IP,BanReason,BanDate FROM AccountBan WHERE IP='$ip' ");
if($respuesta4 = mssql_fetch_assoc($cargadedatos4))
{
?>
Fecha de  Prohibición: <?=$respuesta4['BanDate']?><br />
|========================================================!<br /><br />
<? $count++;}} ?>

El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP:<?=$respuesta3['IP']?>./ Razon: <?=$respuesta3['BanReason']?><br>
</p>
<hr>
<p> 
  <em>Has sido baneado permanentemente de <?=$_SERVERNAME?> por el equipo de staff de <?=$_SERVERNAME?>.</em></p>
</body>
</html>
