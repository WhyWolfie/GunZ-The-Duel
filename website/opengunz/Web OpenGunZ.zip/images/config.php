<?

@session_start();

//MSSQL Server configuration

$_MSSQL[Host]               = "WIN-0NC63BTVO0E\RINCON";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "Sebas123";
$_MSSQL[DBNa]               = "GunZDB";

//MySQL Server configuration

$_MYSQL[Host]               = "WIN-0NC63BTVO0E\RINCON";
$_MYSQL[User]               = "sa";
$_MYSQL[Pass]               = "Sebas123";
$_MYSQL[DBNa]               = "GunzDB";

//Configuration

$_CONFIG[NewsFID]           = 2;
$_CONFIG[EventsFID]         = 0;
$_CONFIG[vBulletinPrefix]   = "HGF";
$_CONFIG[ForumURL]          = "http://skihgunz.sytes.net/gunz";

//Offline page
$_CONFIG[OfflinePage]       = "";




$r = mysql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mysql_select_db($_MSSQL[DBNa], $r);

?>