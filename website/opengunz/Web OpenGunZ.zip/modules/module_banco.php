<?

SetTitle("ExplosionGames Gunz - Donar");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donate");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*3
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " Sa Gunz Coins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.Estilo7 {color: #CCCCCC}
.Estilo8 {color: #FF0000}
.Estilo9 {color: #00FF00; }
-->
</style>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="293" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
					  </td>
						<td width="594" valign="top">
						<div align="center">
							<table width="76%" height="1218" border="1" bordercolor="#000000" style="border-collapse: collapse">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top;">
									<div align="center">
										<b><font face="Tahoma" size="2">Donaciones ExplosionGames Gunz</font></b></td>
							  </tr>
								<tr>
								  <td bgcolor="#2C2A2A"><p align="center" class="Estilo7">Donaciones Via Bancaria</p>
								    <p align="center" class="Estilo7">INTRUCCIONES</p>
								    <p align="center" class="Estilo7">1. DEPOSITAR EL MONTO INDICADO</p>
								    <p align="center" class="Estilo7">2. UNA VEZ DEPOSITADO GUARDA EL BAUNCHER DEL BANCO </p>
								    <p align="center" class="Estilo7">3. UNA VEZ TENGAS EL BAUNCHER BUSCA EL NUMERO EL CUAL SE ENCUENTRA EN EL</p>
								    <p align="center" class="Estilo7">4 UNA VEZ ENVIADO EL NUMERO DE BAUNCHER A ESTE CORREO UNICO AUTORIZADO PARA COMPRAS DE COINS ZALIONGZ@HOTMAIL.COM </p>
								    <p align="center" class="Estilo7">5. DEVES ESPERAR UN MINIMO DE 20 HORAS PARA QUE SE TE AGA LA ENTREGA DE LOS DONATORCOINS</p>
								    <p align="center" class="Estilo7">6.DATOS PARA REALIZAR EL DEPOSITO </p>
								    <p align="center" class="Estilo7">BANCO DE VENEZUELA</p>
								    <p align="center" class="Estilo7"><img src="../images.jpeg" alt="BANCO DE VENEZUELA" width="376" height="71" /></p>
								    <p align="center" class="Estilo7"><img src="../IMG-20130619-00227.png" alt="1" width="398" height="252" /></p>
								    <p align="left" class="Estilo7">TIPO DE CUENTA : <span class="Estilo8">CORRIENTE</span></p>
								    <p align="left" class="Estilo7">NUMERO DE CUENTA : <span class="Estilo8">0102 0140 360000070506 </span></p>
								    <p align="left" class="Estilo7">TITULAR DE LA CUENTA : <span class="Estilo8">BEYNER BAYUELO</span></p>
								    <p align="center" class="Estilo9">DATOS DONATOR COINS </p>
								    <p align="center" class="Estilo7"><span class="Estilo8">220</span> DCOOINS = <span class="Estilo9">50</span> BSF </p>
								    <p align="center" class="Estilo7"><span class="Estilo8">260</span> DCOINS = <span class="Estilo9">100</span> BSF </p>
								    <p align="center" class="Estilo7"><span class="Estilo8">360</span> DCOINS = <span class="Estilo9">150</span> BSF </p>
								    <p align="center" class="Estilo7"><span class="Estilo8">440</span> DCOINS = <span class="Estilo9">200</span> BSF </p>
								    <p align="center" class="Estilo7"><span class="Estilo8">550</span> DCOINS = <span class="Estilo9">250 </span>BSF</p>
								    <p align="center" class="Estilo7">&nbsp;</p>
							      <p>&nbsp;</p></td>
								</tr>
								<tr>
								  <td bgcolor="#2C2A2A">&nbsp;</td>
							  </tr>
							</table>
						</div>
					  <p align="center"></td>
						<td width="265" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
					  </td>
					</tr>
				</table>
<?
$filhodaputa = array(";","'","\"","*","uninic","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>