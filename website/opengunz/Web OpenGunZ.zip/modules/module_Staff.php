<?php
SetTitle("ExplosionGunz - Lista Staff");
?>					
<table width="601" height="552" border="0" align="center">
  <tr>
     <td width="237" align="center" valign="top"><table width="422" height="546" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="546" align="center" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="30" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td height="50" class="estilo6"><CENTER><font color="#00FF00"><b>Lista Del STAFF Del Gunz</b></font></CENTER></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="450" height="200" border="0" bgcolor="#151515">
              <tr>
                <td width="98" align="left" class="Estilo1"><font color="#D7D21C">&nbsp; </font><font color="#FF8000">Fundadores</font></td>
                <td width="110" align="left" class="Estilo1"><font color="#00FF00"> Administradores</font></td>
                <td width="81" align="left" class="Estilo1"><font color="##00FFFF">GamersMasters</font></td>
                </tr>
              <tr>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrow2.jpg" width="10" height="10"/> ZALION </p>
				  <p align="left">&nbsp;<img border="0" src="images/mis_arrow2.jpg" width="10" height="10"/> . </p>
				  <p align="left">&nbsp;<img border="0" src="images/mis_arrow2.jpg" width="10" height="10"/> . </p>
                  <p>&nbsp;</p>
                  </td>
                <td align="left" class="Estilo1">
                  <p> <img src="images/mis_arrow2.jpg" alt="" width="10" height="10" />  </p>
                  <p><img src="images/mis_arrow2.jpg" alt="" width="10" height="10" />  YouHareEz </p>
				  </td>
                <td align="left" class="Estilo1">
                  <p><img src="images/mis_arrow2.jpg" alt="" width="10" height="10" /> Minato Trank </p>
                  <p><img src="images/mis_arrow2.jpg" alt="" width="10" height="10" />Zuba </p>
				  <p><img src="images/mis_arrow2.jpg" alt="" width="10" height="10" />  </p>
                </td>
                </tr>
              <tr>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
              <tr>
                <td height="33" align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
            </table>
			<font color="#FF0000">Se Busca Nuevo Staff Porfavor Contactenos en<div class="pathname-box"><a class="nav" href="http://www.facebook.com/ExplosionGamesVz">Facebook</a>
			Gracias por las Suscricciones de mi</div> <div class="pagination"><br>&nbsp;</div><div class="pathname-box"><a class="nav" href="http://www.youtube.com/user/ZALIONGZ">Canal De Youtube</a></div><div class="pagination"><br>&nbsp;</div></font></td>          
            </td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
</table>
 