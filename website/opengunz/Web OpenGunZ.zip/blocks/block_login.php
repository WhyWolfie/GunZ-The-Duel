<?
if($_SESSION[AID] == "")
{
?>
                        <body onLoad="FP_preloadImgs(/*url*/'images/btn_login_on.jpg', /*url*/'images/btn_editclan_on.jpg')">

                        <form name="login" method="POST" action="index.php?do=login">
                          <input type="hidden" name="submit" value="1">
                          <table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_login.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
                            <tr>
                              <td width="5" height="175">&nbsp;</td>
                              <td width="156" valign="top" height="175"><div align="center">
                                <table border="0" style="border-collapse: collapse" width="156">
                                  <tr>
                                    <td width="154" colspan="2">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td width="154" colspan="2">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td width="154" colspan="2">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td width="83"><input name="userid" size="12" class="textLogin" style="float: left" tabindex="1"></td>
                                    <td width="69" rowspan="3"><div align="center">
                                      <input border="0" src="images/btn_login_off.jpg" id="img812" name="img812" width="57" height="47" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img812',/*url*/'images/btn_login_on.jpg')" type="image">
                                    </div></td>
                                  </tr>
                                  <tr>
                                    <td width="83">&nbsp;</td>
                                  </tr>
                                  <tr>
                                    <td width="83" height="29"><input name="pass" size="12" class="textLogin" style="float: left" type="password" tabindex="2"></td>
                                  </tr>
                                  <tr>
                                    <td width="152" colspan="2"></td>
                                  </tr>
                                  <tr>
                                    <td width="152" colspan="2" height="57" valign="middle"><div align="center">
                                      <table width="100%" height="54" border="0" style="border-collapse: collapse">
                                        <tr>
                                          <td width="2" height="14"></td>
                                          <td width="10"><img src="images/mis_arrow.jpg" alt="" width="5" height="9" id="img1783" border="0"></td>
                                          <td width="134" align="left"><span style="font-size: 7pt"> <a href="index.php?do=register">&iexcl;Registrate Ahora!</a></span></td>
                                        </tr>
                                        <tr>
                                          <td height="14"></td>
                                          <td><img src="images/mis_arrow.jpg" alt="" width="5" height="9" border="0"></td>
                                          <td align="left"><a href="index.php?do=resetpwd"> <span style="font-size: 7pt"> &iquest;Recuperar Contrase&ntilde;a?</span></a></td>
                                        </tr>
   <tr>
                                          <td width="2" height="18"></td>
                                          <td width="10"><img src="images/mis_arrow.jpg" alt="" width="5" height="9" id="img1783" border="0"></td>
                                          <td width="134" align="left"><span style="font-size: 7pt"><a href="/emblems/"><b><blink>Aqui</b> <blinK>Emblema</a><a href="index.php?do=register"></a></span></td>
                                        </tr></table>
                                    </div></td>
                                  </tr>
                                </table>
                              </div></td>
                              <td width="8" height="175"></td>
                            </tr>
                            <tr></tr>
                            <tr>
                            </tr>
                            <tr>
                              <td height="2"></td>
                            </tr>
                          </table>
                          <p><a href="index.php?do=donate"><img src="../images/ldsms.png" width="175" height="175" border="0"></a></p>
                          <p><a href="index.php?do=Recovarchar"><img src="../images/lrp.png" width="175" height="175"></a></p>
                          <p><a href="index.php?do=banco"><img src="../images/Donate.png" width="175" height="175"></a></p>
						  <p><a href="index.php?do=Staff"><img src="../images/Team.png" width="175" height="175"></a></p>
                            <input type="hidden" name="submit2" value="1">
                            </p>
                        </form>
<?
}else{

    //$query1 = mssql_query_logged("SELECT * FROM AccountItem(nolock) WHERE AID = '{$_SESSION[AID]}'");
    $query2 = mssql_query_logged("SELECT Coins, EventCoins FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
    //$_MEMBER[NumItems]      = mssql_num_rows($query1);
    $_MEMBER[AccountData]   = mssql_fetch_assoc($query2);
?>


<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("imageclan");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "explosiongunz.com/emblems/upload/" + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>

<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_logued.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
								<tr>
									<td width="175" height="230">
									<div align="center">
									  <table border="0" style="border-collapse: collapse" width="175" height="100%">
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155" rowspan="2">
												<div align="left"><b><font face="Tahoma"><blink></blink> 
												<?=$_SESSION[UserID]?> </font></b></td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="153" rowspan="4">
												<div align="center">
                                                <?
                                                    if(CheckIfExistClan($_SESSION[AID]))
                                                    {
                                                ?>
                                                <table border="0" style="border-collapse: collapse" width="100%" height="100%">
														<tr>
															<td rowspan="4">
									<a href="index.php?do=Clanadmin&CLID=1">	<img src="http://5.31.243.198/emblems/upload/" name="imageclan" width="55" height="55" id="imageclan" style="border: 1px solid #000000"></td> 
															<td width="124">
															<div align="left">
															<select onChange="UpdateClan()" id="clanlist" size="1" name="selclan" style="color: #FFFFFF; font-family: Verdana; font-size: 7pt; border: 1px solid #000000; background-color: #101010">
															<?
                                                            $qr = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
                                                            if( mssql_num_rows($qr) > 0 )
                                                            {
                                                            while($char = mssql_fetch_assoc($qr))
                                                            {
                                                                     $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
                                                                     if( mssql_num_rows($queryc) > 0 )
                                                                     {
                                                                        $a = mssql_fetch_assoc($queryc);
                                                                        $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));

                                                                         $_CLAN[Name]       = $b[Name];
                                                                         $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
                                                                         $_CLAN[CLID]       = $a[CLID];
                                                                         $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "noemblem.jpg" : $b[EmblemUrl];

                                                                         $info = implode("-|-", $_CLAN);

                                                                         if($_CLAN[Name] <> "")
                                                                            echo "<option value = '$info'>{$_CLAN[Name]}</option>";
                                                                     }
                                                                }
                                                            }
                                                            ?>
															</select></td>
														</tr>
														<tr>
															<td height="2" width="124"></td>
														</tr>
														<tr>
															<td width="124">
															<a id="editlink" href="http://explosiongunz.com/emblems/">
															<blink> <a href="http://explosiongunz.com/emblems/"><b><blink>Aqui</b> <blinK>Emblema</a></td>
														</tr>
														<tr>
															<td width="124">
															<div align="left">
															<span style="font-size: 7pt">
															Leader: </span><span id="clanmaster"></span></td>
														</tr>
												  </table>
                                                    <?
                                                    }else{
                                                    ?>
                                                    <table border="0" style="border-collapse: collapse" width="100%" height="100%">
														<tr>
															<td>
															<div align="center">
															   <span style="font-size: 7pt">
															     No Tienes Clan   </span></td>
														</tr>
													</table>
<?
}?>
</div>
</td>
<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="155" rowspan="3">
												<div align="center">
												  <table border="0" style="border-collapse: collapse" width="155" height="100%">
												    <tr>
												      <td width="3"></td>
												      <td width="73">DCoins:</td>
												      <td width="73"><div align="left">
												        <b>
												          <?=$_MEMBER[AccountData][Coins]?>
											            </b></td>
											        </tr>
												    <tr>
												      <td width="3"></td>
												      <td width="73">EventCoins:</td>
												      <td width="73"><div align="left">
												        <b>
												          <?=$_MEMBER[AccountData][EventCoins]?>
											            </b></td>
											        </tr>
		                                            <tr>
		                                              <td></td>
		                                              <td><div align="left">
		                                                Tu AID:</td>
		                                              <td><b style="color:red;">
		                                                <?=$_SESSION[AID]?>
		                                                </b></td>
		                                              <?
                                                        /*
                                                        echo '
                                                        <tr>
															<td width="3"></td>
															<td width="73">
															<div align="left">
															Items:</td>
															<td width="73">
															<div align="left"><b>
															'.$_MEMBER[NumItems].'</b></td>
														</tr>'; */
                                                        ?>
        										    <?
                                                        /*
                                                        echo '
                                                        <tr>
															<td width="3"></td>
															<td width="73">
															<div align="left">
															Items:</td>
															<td width="73">
															<div align="left"><b>
															'.$_MEMBER[NumItems].'</b></td>
														</tr>'; */
                                                        ?>
												    <tr>
												      <td width="3"></td>
											        </tr>
											      </table>
												</div>
                                                <center>
                                                </center>
                                                
												</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6">&nbsp;</td>
												<td width="8">&nbsp;</td>
											</tr>
											<tr>
												<td width="6" height="21">&nbsp;</td>
												<td width="155">
												<div align="center">
												<a href="index.php?do=editaccount">
												<img border="0" src="images/btn_editacc_off.jpg" width="72" height="16" id="img1781" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1781',/*url*/'images/btn_editacc_on.jpg')"></a>
												<a href="index.php?do=logout">
												<img border="0" src="images/btn_changebt_off.jpg" width="72" height="16" id="img1782" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1782',/*url*/'images/btn_changebt_on.jpg')"></a></td>
												<td width="8">&nbsp;</td>
										  </tr>
											<tr>
												
											
									  </table>
									</div>
									</td>
								<tr>
									
								</tr>
						</table>
						<p>
						  <script language="javascript">
									UpdateClan();
								</script>
						  
						  <p><a href="index.php?do=donate"><img src="../images/ldsms.png" width="175" height="175" border="0"></a></p>
                          <p><a href="index.php?do=Recovarchar"><img src="../images/lrp.png" width="175" height="175"></a></p>
                          <p><a href="index.php?do=banco"><img src="../images/Donate.png" width="175" height="175"></a></p>
						  <p><a href="index.php?do=Staff"><img src="../images/Team.png" width="175" height="175"></a></p>
						<p>
						  <input type="hidden" name="submit3" value="1">
						  <?
}
?>
					    </p>
                        