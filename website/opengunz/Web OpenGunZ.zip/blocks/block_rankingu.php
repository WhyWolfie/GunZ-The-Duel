<?
$res = mssql_query("SELECT TOP 5 * FROM Account a, Character b WHERE b.AID=a.AID AND a.UGradeID !=255|253 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo1 {color: #090912}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->
</style>
<table background="images/md_ir.png"  width="174" height="143" border="0">
<tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="4" rowspan="6">&nbsp;</td>
        <td height="4" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2"><b>No Data &laquo; </b></div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="7" align="left">
	  
  										<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
  										<td width="104" align="left"><span style="font-size: 8pt"><font color="#FFFFFF"><?=$user['Name']?></td></font></span><td width="1" align="left"><span style="font-size: 7pt"><font color="#FFFFFF"><?=$user['Level']?>Lv.</font></span></td>
										
      </td>
      </tr>
      <?}}?>
    </table>    <td height="40"></tr>
</table>
