<?php
// Config Siganture
$url	=	"http://www.explosiongunz.com/gunz";
$img 	=	"/images/sing.png";

?>