<?
//Name color By:Pablo '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
  <div id='boxxing'>
   <ul><li>Comprar Nick Color</li></ul> 
<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
<font color="#FFFFFF">Voc� ir� gastar <font color=red>50</font> SG Coins.<br><br>
Selecione a cor de seu nick name:</font><br><br>
<select name="color222" class="text">
<option value="3">Preto</option>
<option value="4">Verde</option>
<option value="5">Rosa</option>
<option value="7">Verde �gua</option>
<option value="8">Roxo</option>
</select>
<br><br>
<font color="#000000">Preto</font><br><br>
<font color="#00FF00">Verde</font><br><br>
<font color="#FF00FF">Rosa</font><br><br>
<font color="#20B2AA">Verde �gua</font><br><br>
<font color="#A020F0">Roxo</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
<br>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Voc� comprou Admin com sucesso!!  Brinks HAHA";
die ();  

}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 50) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  TF Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -50 where AID='$aid22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Acesse site.aulagunz.com.br";
}
}
}


$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>