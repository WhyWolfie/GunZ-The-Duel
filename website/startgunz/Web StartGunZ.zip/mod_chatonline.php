
  <div id='boxxing'>
   <ul>
     <li>Start Gunz - Chat Online </li>
   </ul> 

   <p>&nbsp;</p>
 <table width="612" align="center"  cellpadding="2" cellspacing="5"  style="border: 1px solid #279B61" class="hover">
  <tr>
	<th align="center" bgcolor="#f90" ><p>Chat - Splat Gunz Oficial </p>
	  <p>
	    <img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzODExNzY2NDAwMjImcHQ9MTM4MTE3NjY1NzM4NyZwPTUzMTUxJmQ9Jmc9MSZvPTkxNGFmYzE3MGI4MTRjYTNiMDBh/YjNjMmEyNzMyMDFl.gif" /><embed wmode="transparent" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="540" height="405" name="chat" FlashVars="id=201660916" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.php" /><br><small><a target="_BLANK" href="http://xat.com/web_gear/?cb"></a> <a target="_BLANK" href="http://xat.com/web_gear/chat/go_large.php?id=201660916"></a></small><br>

                
	      <br>	  
	      <br>
	    
          </p></th>
  </tr>
</table>
<p>&nbsp;</p>
  </div>