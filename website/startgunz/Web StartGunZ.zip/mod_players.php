<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {color: #FF9900}
-->
</style>
  <div id='boxxing'>
   <ul class="style1"><li>Ranking de Jogadores - <a href="?do=clans">Ranking de Cl�s</a></li></ul>
<table width="610" border="0" cellspacing="0" cellpadding="0" align="lift">
<tr>
    <td width="50" align="center" class="topranking style1"><div align="left"><b>Rank</b></div></td>
	<td width="100" align="left" class="topranking style1">Nick</td>
    <td width="50" align="center" class="topranking style1"><div align="left"><i>Lvl</i></div></td>
    <td width="100" align="center" class="topranking style1"><div align="left"><em>Frag</em> </div></td>
    <td width="79" align="center" class="topranking style1"><div align="left"><i>Exp</i></div></td>
    <td width="140" align="center" class="topranking style1"><div align="left">Ultimo Login </div></td>
    <td width="91" align="center" class="topranking style1">&nbsp;</td>
</tr>
</table>
<span class="style1">
<?php
$num_por_pagina = 100; 
$pagina = $_GET['pagina']; 

if(!$pagina)
{
 $pagina = 1;
}

$primeiro_registro = ($pagina*$num_por_pagina) - $num_por_pagina;
if ($pagina == 1)
{
$res = mssql_query("SELECT TOP $num_por_pagina Name, Level, XP, LastTime, PlayTime FROM Character WHERE Name != '' ORDER BY XP DESC");
$count = 0;
}
else
{
$res = mssql_query("SELECT TOP $num_por_pagina Name, Level, XP, LastTime, PlayTime FROM Character WHERE Name != '' ORDER BY XP DESC");
}
while($item = mssql_fetch_assoc($res))
{
?>
</span>
<table width="611" border="0" align="lift" cellpadding="0" cellspacing="0">
<tr>
    <td width="50" align="center" class="topranking style1"><div align="left"><b>
      <font color="#FF9900">
        <?=++$count ?>
      </font>    .</b></div></td>
	<td width="101" align="left" class="topranking style1">
	  <div align="left">
	    <?=$item['Name'] ?>
      </div></td>
    <td width="50" align="left" class="topranking style1"><div align="left"><i>
      <?=$item['Level'] ?>
    </i></div></td>

    <td width="100" align="center" class="topranking style1">
      
      <div align="left">
        <?=GetKDRatio($char['KillCount'], $char['DeathCount'])?>    
        </div></td>
        <td width="80" align="center" class="topranking style1"><div align="left"><i>
          <?=$item['XP'] ?>
        </i></div></td>
        <td width="140" align="center" class="topranking style1"><div align="left"><i>
          <?=$item['LastTime'] ?>
        </i></div></td>
        <td width="90" align="center" class="topranking style1">&nbsp;</td>
</tr>
</table>

  
  <div align="left">
    <?
}?>
      
    <table width="400" border="0">
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table>
  </div>
  <table width="619" border="0">
    <tr>
      <td width="613"><div align="center"><a href="?do=players&amp;sub=player&amp;expand=1&amp;pagina=2" class="style2">Pr&oacute;ximo</a></div></td>
    </tr>
  </table>
  