<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style2 {color: #FF9900}
-->
</style>
  <div id='boxxing'>
   <ul class="style1"><li>Ranking de Cl�s - <a href="?do=players">Ranking de Jogadores</a></li></ul>
<table width="350" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
    <td width="50" align="center" class="topranking style1"><div align="left"><strong>Rank</strong></div></td>
	<td width="100" align="left" class="topranking  style1"><div align="left">Nome do Clan</div></td>
    <td width="50" align="center" class="topranking style1"><div align="left"><em>Pontos</em></div></td>
    <td width="150" align="center" class="topranking style1"><div align="left"><i>Vit�rias/Derrotas</i></div></td>
</tr>
</table>
<p class="style1"></p>
  <span class="style1">
<?php
$num_por_pagina = 100; 
$pagina = $_GET['pagina']; 

if(!$pagina)
{
 $pagina = 1;
}

$primeiro_registro = ($pagina*$num_por_pagina) - $num_por_pagina;
if ($pagina == 1)
{
 $res = mssql_query("SELECT TOP $num_por_pagina * FROM Clan WHERE Ranking > $primeiro_registro-1 AND DeleteFlag = 0 ORDER BY Point DESC");
}
else
{
 $res = mssql_query("SELECT TOP $num_por_pagina * FROM Clan WHERE Ranking >= $primeiro_registro AND DeleteFlag = 0 ORDER BY Point DESC");
$id = 0;
}
while($item = mssql_fetch_assoc($res))
{
?>
</p>
  </span>
<table width="350" border="0" cellspacing="0" cellpadding="0" align="left">
<tr>
    <td width="50" align="center" class="topranking style1"><div align="left"><b>
      <font color="#FF9900"><?=++$count?></font>
    .</b></div></td>
	<td width="100" align="left" class="topranking style1"><?=$item['Name'] ?></td>
    <td width="50" align="center" class="topranking style1"><div align="left"><i>
      <?=$item['Point'] ?>
    </i></div></td>
    <td width="150" align="center" class="topranking style1"><div align="left"><i>
      <?=$item['Wins'] ?> 
      / 
      <?=$item['Losses'] ?>
    </i></div></td>
</tr>
</table>
<p class="style1">&nbsp;</p>
<p class="style1">
  <?
}?>
</p>
<table width="619" border="0">
  <tr>
    <td width="613"><div align="center"><a href="?do=clans&amp;sub=clan&amp;expand=1&amp;pagina=2" class="style2">Pr&oacute;ximo</a></div></td>
  </tr>
</table>
  