<?

if( $_SESSION['AID'] == "" )
{
msgBox("Esta Pagina � s� para Us�arios Logado, Logue-se para acessa esta pagina.","index.php?do=login");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
  <div id='boxxing'>
   <ul>
     <li>Extra </li>
   </ul> 

   <p>&nbsp;</p>
 <table width="612" align="center"  cellpadding="2" cellspacing="5"  style="border: 1px solid #279B61" class="hover">
  <tr>
	<th align="center" bgcolor="#333333" >Escolha sua Op&ccedil;&oacute;es </th>
	</tr>
  <tr>
	<td align="center" bgcolor="#333333"><a href="?do=color">Comprar Name Color</a></td>
	</tr>
  <tr>
	<td align="center" bgcolor="#333333"><a href="?do=jjang">Comprar jjang </a></td>
	</tr>
  <tr>
	<td align="center" bgcolor="#333333"><a href="?do=nick_name">Trocar de Nick </a></td>
	</tr>
  <tr>
	<td align="center" bgcolor="#333333"><a href="?do=ev_coins">Trocar Pontos CW</a></td>
	</tr>
  <tr>
	<td height="19" align="center" bgcolor="#333333"><a href="?do=sex">Trocar de Sexo</a></td>
	</tr>	<td height="19" align="center" bgcolor="#333333"><a href="?do=emblemas">Clan emblema</a><a href="?do=chatonline"></a></td>
	</tr>
	<td height="19" align="center" bgcolor="#333333"><a href="?do=chatonline">Chat Online </a></td>
	</tr>
		    <td height="19" align="center" bgcolor="#333333"><a href="?do=suporte">Suporte </a></td>
	</tr>		
	  <td height="19" align="center" bgcolor="#333333"><a href="?do=login&amp;action=logout&amp;header=1">Sair da Conta </a></td>
	</tr>
</table>
<p>&nbsp;</p>
  </div>