<?php
include "authadmin.php";
?><head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>

  
<div id='boxxing'>
   <ul class="style2"><li>Painel de Administrador - Start Gunz</li></ul> 
<form method="GET" action="index.php?do=admin">
  <div align="center">
    <table width="199" border="0" id="table5" style="border-collapse: collapse">

      <tr>
        <td>
          <table border="0" style="border-collapse: collapse" width="189" height="100%">
            <tr><br>
              <td width="4">&nbsp;</td>
			    <td width="171">
  <p><b><a href="index.php?do=addindexcontent">Adicionar Noticias</a></b></p>
  <p><b><a href="index.php?do=rzadditem">Adicionar Donator</a></b></p>
  <p><b><a href="index.php?do=evadditem">Adicionar Evento</a></b></p>
  <p><b><a href="index.php?do=mandar">Enviar EvCoins</a></b></p>
  <p><b><a href="index.php?do=mandarsgcoins">Enviar SG Coins</a></b></p>
  <p><b><a href="index.php?do=muteuser">ChatBlock</a></b></p>
  <p><b><a href="index.php?do=banuser">Banir Usuario</a></b></p>
  <p><b><a href="index.php?do=ipbanuser">Banir IP</a></b></p>  </td>
			    <td width="8">&nbsp;</td>
		    </tr>
            <tr>			  </tr>
          </table>		  </td>
							  </tr>

								  <td width="10"></td>
							  </tr>
      </table>
  </div>
</form>


							