<?
//Deewzy.exe Owna =P

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

if($etapa22 == 0){
?>  <div id='boxxing'>
   <ul><li>Trocar Pontos de Cw</li></ul> 
<form id="ev_coins" name="ev_coins" method="post" action="?do=ev_coins&etapa=1">
<font color="#FFFFFF">Personagem:</font>
<select name="cid" class="text">
<?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proximo ->" />
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))


{
die ("Este Personagem N�o Pertence a Nenhum Clan");
}else{

$_SESSION["CID"] = $cid22;
echo '
<font color=red>Aten��o:</font><font color=Ivory>A Cada 2 Pontos � o que vale a 1 EvCoin!</font><br><br>
<form id="ev_coins" name="ev_coins" method="post" action="?do=ev_coins&etapa=2">';
echo "<font color=Ivory>Ol� $login22 voc� tem $busca2[0] Pontos com o personagem selecionado para trocar em EvCoins.</font><br><br>";
echo "<font color=Ivory>Quantos pontos deseja trocar?</font><br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="ev_coins" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "<font color=Ivory>Voc� bebeu? Voc� tem $busca4[0] pontos e quer trocar por $pontos EvCoins -.-'</font>";
}else{

if ( !is_numeric($cid23) )
{
echo "<font color=Ivory>ID do personagem editado</font>";
die();
}

if ( !is_numeric($pontos) )
{
echo "<font color=Ivory>O N�mero de Coins precisa ser um n�mero</font>";
die();
}

if ($pontos == 0)
{
echo "<font color=Ivory>N�o h� necessidade de comprar 0 EV Coins</font>	";
die();		
}

if($pontos < 1)
{
echo "<font color=Ivory>Voc� N�o Pode Ficar Com Coins Negativos</font>";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set EvCoins=EvCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}
?>