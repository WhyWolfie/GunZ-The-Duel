<?

if( $_SESSION['AID'] == "" )
{
msgBox("Esta Pagina � s� para Us�arios Logado, Logue-se para acessa esta pagina.","index.php?do=login");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<style type="text/css">
<!--
body {
	background-color: #333333;
}
.style4 {color: #CCCCCC}
.style5 {color: #FFFFFF}
-->
</style>

  <div id='boxxing'>
   <ul>
     <li>Equipe Start GunZ </li>
   </ul> 

   <p>&nbsp;</p>
   <div align="center">
     <table width="600" border="0">
       <tr>
         <td><div align="center"><span style="text-shadow: 1px 1px 3px #FF6600;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Fundadores </b></span></span></div></td>
       </tr>
       <tr>
         <td height="22"><div align="center"><font color="#FFFFFF">Buh - Fundador Geral </font></div></td>
       </tr>
       <tr>
         <td height="22"><div align="center"><font color="#FFFFFF">Rei - Fundador / Inactivo </font></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style4">#</div></td>
       </tr>
       <tr>
         <td><div align="center"><span style="text-shadow: 1px 1px 3px #FFF000;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Administrador </b></span></span></div></td>
       </tr>
       <tr>
         <td><div align="center">Eletroplus - Administrador Geral</div></td>
       </tr>
       
       
       <tr>
         <td>        </td>
       </tr>
       <tr>
         <td> <div align="center"><span style="text-shadow: 1px 1px 3px #0099FF;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Games Master</b></span></span></div></td>
       </tr>
       
       <tr>
         <td><div align="center"><font color="#FFFFFF">Snake - Eventos / Divulgador</font></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style4">Deewzy.exe - Eventos / Suporte / Report</div></td>
       </tr>
       <tr>
         <td><div align="center" class="style5">VAGA - Eventos / Suporte / Report</div></td>
       </tr>
       <tr>
          <td><div align="center"><span style="text-shadow: 1px 1px 3px #009900;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b>Moderadores </b></span></span></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style5">Brida - Moderador / Designer</div></td>
       </tr>
         <td><div align="center" class="style5">Mickey - Moderador / Divulgador</div></td>
       </tr>
        </table>
   </div>
   <p>&nbsp;</p>
  </div>