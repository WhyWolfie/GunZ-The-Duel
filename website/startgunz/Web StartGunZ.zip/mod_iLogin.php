<?
if ($_SESSION['AID'] == ""){
?>
<div align="lift">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">

							<tr><td background="images/menu_bg.png">
								<form method="POST" action="index.php?do=login&header=1" name="login">
									<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="4">&nbsp;</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="text" name="userid" size="14" style="background-image: url('images/usernamebg.jpg'); background-position: left lift" class="login"></td>
											<td width="62" rowspan="2">
											  <p align="lift"></td>
											<td width="8" rowspan="2">&nbsp;											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="password" name="pasw" size="14" style="background-image: url('images/passwordbg.jpg'); background-position: left lift" class="login" id="input"></td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">
											<input type="checkbox" name="cookie" value="ON" checked>Manter-me logado</td>
											<td width="8">&nbsp;											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">&nbsp;
										    <input type="submit" value="Login" name="submit" />											</td>
											<td width="8">&nbsp;											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">
											<span style="font-size: 7pt">&nbsp;�
											<a href="index.php?do=registro">
											Registre-se!</a></span></td>
											<td width="8">&nbsp;											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">
											<span style="font-size: 7pt">&nbsp;�
											<a href="javascript: void('Gnee')" onClick="Sexy.alert('<h3>Desculpe a op��es de recuperar conta esta desativado no momento, att Phuma.</h3>'); return false;">Recuperar senha!<span class='bold_cooper'></span></a></span></td>
											<td width="8">&nbsp;											</td>
										</tr>
									</table>
								</form>
								</td>
							</tr>
							<tr>
								<td height="22">&nbsp;</td>
							</tr>
						</table>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);

$busca1 = mssql_query_logged("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$busca2 = mssql_fetch_row($busca1);
?>

<div align="lift">
<div align="lift">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
						  </tr>
							<tr>
								<td background="images/menu_bg.png">
																	<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2"></td>
											<td width="181">
											
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<font size="2" face="Tahoma">
											<font color="#CCCCCC">Bem Vindo, <?=$_SESSION['UserID']?> !</font></font></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=login&action=logout&header=1">
											Deseja deslogar ?</a></td>
										</tr>
                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=sex">
											Trocar de Sexo <b><font color=red>(Novo)</b></font></a></td></b></a></td>
										</tr>
                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=nick_name">
											Trocar de Nick <b><font color=red>(Novo)</b></font></a></td></b></a></td>
										</tr>
                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=ev_coins">
											Trocar Pontos CW </a></td></a></td>
										</tr>
                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=color">
											Comprar Name Color</a></td>
										</tr>
                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=jjang">
											Comprar jjang</a></td>
										</tr>
                                                                                <?
                                                                                if($busca2[0] == 255 OR $busca2[0] == 254){
                                                                                ?>  

                                                                                 <tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=mandar">
											Adicionar Event Coins</a></td>
										</tr>
                                                                                <?
                                                                                 }
                                                                                 ?>

                                                                          
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="lift">
												<table border="0" width="171" height="169" style="border-collapse: collapse; background-image: url('images/accountframe.png')">
													<tr>
														<td height="29" width="12">&nbsp;</td>
														<td height="29" width="155" colspan="2">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url(''); background-repeat: no-repeat; background-position-x: left">
														<p align=""><b><span style="font-size: 7pt"><font color="#FFFFFF">�ltima data de conex�o</font><br>
														<b><font color="#FFFFFF"><?=$d['LastConnDate']?></font></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses1.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
										                                <td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_rzcoins.png'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 10pt">
														<font color="#FFFFFF"><?=$d['RZCoins']?></fon  t></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
												  </tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_evcoins.PNG'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 10pt">
														<font color="#FFFFFF"><?=$d['EVCoins']?></font></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses1.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url(''); background-repeat: no-repeat; background-position-x: left">
														<a href="index.php?do=myaccount&act=editinfo">
														<img border="0" src="images/af_editaccountinfo.gif" width="138" height="22" id="img3" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img3',/*url*/'images/af_editaccountinfo_effect.gif')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12">&nbsp;</td>
														<td width="155" colspan="2">
														<p align="lift">
														</td>
													</tr>
												</table>
											</div>
											</td>
										</tr>
										</table>
								
								</td>
							</tr>
							<tr>
								<td height="22">&nbsp;</td>
						  </tr>
						</table>

<?
}
?>