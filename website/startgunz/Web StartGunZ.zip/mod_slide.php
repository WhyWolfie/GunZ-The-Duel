
<body>  <div id='boxxing'>
   <ul><li>Start Gunz - Principal</li></ul> <center>
<div id="exibicao">
		<table cellpadding="0" cellspacing="0">
		<tr>
			<td bgcolor="#000000" nowrap="nowrap"><img id="image" src="images/u2.png" width='550' height='290' style="margin:0 10px 0px 0px;"></td>
			<td bgcolor="#000000" style="width:68px;" nowrap="nowrap">
			<img src="http://tinypic.com/r/2qb5h8j/5" width='58' height='58'>
			<br>
			<img src="http://tinypic.com/r/2qb5h8j/5" width='58' height='58'>
			<br>
		        <img src="http://tinypic.com/r/2qb5h8j/5" width='58' height='58'>
			<br>
			<img src="http://tinypic.com/r/2qb5h8j/5" width='58' height='58'>
			</td>
		</tr>
		</table>
</div>
</center>
</body>
