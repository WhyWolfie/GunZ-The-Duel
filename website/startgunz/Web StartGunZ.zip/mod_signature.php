<?

if( $_SESSION['AID'] == "" )
{
msgBox("Logue-se primeiro","index.php?do=login");
    die();
}

    $ronaldo1 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");

    if( mssql_num_rows($ronaldo1) < 1 )
    {
	msgBox("Voc� n�o tem personagens","index.php?do=login");
    	die();
    }

?>
<head>
<script type="text/javascript">
    function AtualizarAssinatura()
    {
        var cid = document.assinatura.charlist.value;
        var sign = document.getElementById("sign");
        sign.innerHTML = '<img src="http://no-ip.com/images/sign/imagemphp.php?cid='+ cid + '" />';
        document.assinatura.codigoforum.value = '[IMG]http://no-ip.com/images/sign/imagemphp.php?cid=' + cid + '[/IMG]';
        document.assinatura.linkdireto.value = "http://no-ip.com/images/sign/imagemphp.php?cid=" + cid + "";
        document.assinatura.codigohtml.value = '<a href="http://no-ip.com/images/index.php?do=signature"><img src="http://no-ip.com/images/imagemphp.php?cid=' + cid + '" border="0"></a>';
    }

</script>

<meta http-equiv="Content-Language" content="BR">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="348">
											<img border="0" src="images/inf/staff.png " width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">&nbsp;
											</td>
										</tr>
	
										<tr>
<div align="center"><form name="assinatura">
										<table border="0" style="border-collapse: collapse" width="414" height="100%">
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="181">
												<p align="right">Selecione um personagem</td>
												<td width="13">&nbsp;</td>
												<td width="190">
												<select size="1" name="charlist" onchange="AtualizarAssinatura()">
                                                <?
                                                while( $ronaldo2 = mssql_fetch_row($ronaldo1) )
                                                {
                                                ?>
                                                    <option value="<?=$ronaldo2[0]?>"><?=$ronaldo2[1]?></option><br />';
                                                <?
                                                }
                                                ?>
												</select></td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td align="center" colspan="5">Sign:</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td align="center" colspan="5"><span id="sign"></span></td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
												<td align="center" width="315" colspan="3">
                                                C�digo para F�rums:<br />
                                                <input type="text" name="codigoforum" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/></td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
												<td align="center" width="315" colspan="3">
                                                C�digo HTML:<br />
                                                <input type="text" name="codigohtml" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/></td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
                                            <tr>
                                                <td width="10">&nbsp;</td>
												<td align="center" width="315" colspan="3">
                                                Link Direto:<br />
                                                <input type="text" name="linkdireto" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/></td>
												<td width="11">&nbsp;</td>
											</tr>
                                            <script type="text/javascript">
                                            AtualizarAssinatura();
                                            </script>
										</table></form>
									</div>
	
								
								
							
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					