<?php
alertbox("Invalid Payment.","http://192.168.0.199/index.php");
    die();
?>

