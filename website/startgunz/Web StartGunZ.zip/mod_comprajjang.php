<?
//jjang By:Gaspar '-'

$login22 = Filtrrar($_SESSION["login"]);

$busca57 = mssql_query("SELECT EventCoins FROM Account WHERE USerID = '$login22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION["login"])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<B><font size="2"><span><span></span>
jjang - Tipo: Custom - Sexo: Ambos - Level: 1
</span></B>
</h2>
<li class="h">
<img src="_img/no_preview.png">
</li>
<a href="?gz=jjang&step=1">Comprar</a><br>
Voce tem um total de <?=$busca58[0]?> EVCoins , apos fazer essa compra ira sobrar <?=$busca58[0]-40?>
<?
}else{


$buscanome = "SELECT EVCoins FROM Account WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 40) 
{
	echo "Desculpe, nao foi possivel realizar sua compra.<br>";
	echo "Voce nao tem EVCoins sufuciente.<br>";
	echo "Adquira mais EVCoins e volte novamente!<br>";
        echo "Obrigado.<br>";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE UserID = '$login22'");
mssql_query("update Account set Coins=Coins -40 where UserID='$login22'");
echo "Compra realizada com sucesso! Seu jjang ja esta em sua conta basta relogar.<br>";
}


}
}
?>