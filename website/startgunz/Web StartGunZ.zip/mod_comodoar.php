<br /><br /><br /><p align="left"><a href="index.php?do=comodoar1" class="comodoar4">Como Donatar</a><br />
<a href="index.php?do=comodoar2" class="comodoar3">Tabela de pre�os</a><br />
<a href="index.php?do=comodoar3" class="comodoar3">Recebendo suas Coins</a><br />
<a href="index.php?do=comodoar4" class="comodoar3">Cuidados</a><br />
<a href="index.php?do=comodoar5" class="comodoar3">F.A.Q</a><br /></p><br /><br />