<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>NighT GamerZ</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<STYLE type="text/css">
<!--
body, p, td {font-size: 8pt; font-family: Verdana; color: #000000}
A:link{color:FF0000;text-decoration:none}
A:visited{color:FF0000;text-decoration:none}
A:active{color:FF0000;text-decoration:none}
A:hover{color:0000FF;text-decoration:none}
-->
</STYLE>

<body bgcolor="000000">
<div align="center"><br><br>
<img src="http://img139.imageshack.us/img139/6995/manuntencao.jpg" />
</div>
</body>
</html>