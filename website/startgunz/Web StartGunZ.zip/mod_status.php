<? include "inject.php" ?>
<style type="text/css">
@import "final.css";
</style>
					  <table style="border-collapse: collapse;" id="table4" width="195" border="0">
							<tbody><tr>
								<td width="195" background="images/serverstatus.gif" height="30">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
<br>
<b><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'The Fake Gunz';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;� $name: <font style='color: #66F212'><B>Online</B></font><br />";
        }
        else
        {
            echo "&nbsp;� $name: <font style='color: #66F212'><B>Online</B></font><br />";
            fclose($fp);
        }
    }
    ?>
<b>
<b><?php
        $ip = 'thefakegunz.zapto.org';
        $port = '7777';
        $name = 'Match Agent';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;� $name: <font style='color: #66F212'><B>Online</B></font><br />";
        }
        else
        {
            echo "&nbsp;� $name: <font style='color: #66F212'><B>Online</B></font><br />";
            fclose($fp);
        }
    ?>
<b><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;� Players Online: <strong>$servercount";
    ?>
    </strong><b><br>
    

<b>&nbsp;� <? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Total Accounts: ".$num_rows."<n>"; 

?><br> 
<b>&nbsp;� <?php
 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Total Characters: ".$num_rows."<n>";

?><br>

<b>&nbsp;� <?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Total Clans: ".$num_rows."<n>";

?><br>

    <b>&nbsp;� Visitas Hoje:
    <?php
$file_count = fopen('counter/count.db', 'rb');
	$data = '';
	while (!feof($file_count)) $data .= fread($file_count, 4096);
	fclose($file_count);
	list($today, $yesterday, $total, $date, $days) = split("%", $data);
	echo $today;
?>
    </b><b><br>
<b>&nbsp;� Total Visitas: <?php
	echo $total;
?>
</b></b></strong></b>
    <table style="border-collapse: collapse;" width="193" border="0" height="100%">
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td></tr>

<br>���Recorde Online: 
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<?=$b['PlayerCount']?>
	</b></b></strong></b><table style="border-collapse: collapse;" width="193" border="0" height="100%">
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

      </tbody></table>
<strong>								</strong></td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</tbody></table><br>
<!-- Inicio Codigo Visitas online gratis opromo.com  -->
<script language="Javascript" src="http://www.opromo.com/servicos/usuariosonline/useronline.php?site=sitewwwwargunzcombr&corfont1=00ACFF&texto=1&formato=normal&tipo=verdana&tamanho=3&simbo=1" type="text/javascript"></script>
<!-- Fim Codigo Visitas online gratis opromo.com  -->
