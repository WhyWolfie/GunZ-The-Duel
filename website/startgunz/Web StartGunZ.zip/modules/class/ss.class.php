<?php
		class screen extends funcao
			{
			
		  function ss()
		{
			global $conexao;
			echo "<div id='boxxing'>
		<ul><li>Screen Shoots</li></ul>
		<ol><table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"10\">";
		$guild = $conexao->ExecuteReader("select TOP 4 * from GneeSite.dbo.gnee_screen order by votos desc");
		$guild2 = $conexao->ExecuteReader("select TOP 4 * from GneeSite.dbo.gnee_screen order by votos desc");
		
		?>
		  <tr>
		  <?php while($g = $guild->fetchArray()) 
          { ?>
			<td><div align="center"><a href="?gne=ss_view&id=<?php echo  $g['id']; ?>"><img class="imagemg" src="<?php echo lugar_ss ."/". $g['nome']; ?>"      /></a></div></td>
			<?php } ?>
		  </tr>
		  <tr>
		   <?php while($g2 = $guild2->fetchArray()){
				 ?>
			<td align="center" valign='top'><span class='top_ul2'>Personagem: <?php echo $g2['personagem']; ?><br>Votos: <?php echo $g2['votos']; ?></span></td>
			<?php } ?>
		  </tr>  
		  <tr>
			<td><span class='ss'><a href="?gne=todas_ss">[Todas as Screen]</span></a></td>
			</tr>
		</table>
		
		</ol>
		</div>
		<?php    
		}
	
		function todas_ss()
		{
			global $conexao;
		                  	echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select * from GneeSite.dbo.gnee_screen ORDER BY votos DESC");    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							echo ('<div id="alertas_2" align="center">Nenhuma Screen Shoot Cadastrada</div>');
							}
							for($x=0;$x<$banchar->getRowCount();$x++) 
							{
							echo '<tr>';
							for($i=0;$i<$banchar->getRowCount()/2;$i++) 
							{
							$reset = $banchar->FetchArray(); 
							if($reset['id'] == '') 
							{
							echo '<td></td>';
							}
							else
							{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=ss_view&id=".$reset['id']."\" \"><img src=\"".lugar_ss."/".$reset['nome']."\" class=\"imagemg\" /><br /></a>
							<span class='top_ul2'>Personagem:</span><span class='top_ul3'> ".$reset['personagem']."<br />
							<span class='top_ul2'>Votos</span>: <span class='top_ul3'>(".$reset['votos'].")<br /></span><br />
							</div>
							</td>";
							$p++;
							}
							}
							}
							echo "</table>";
		}
	
		   function ss_voto($nota,$id)
			{
			 global $conexao;   
			 $chekchar = $conexao->ExecuteReader("select nome from GneeSite.dbo.gnee_screen_votado where nome=? AND idss=?",$this->login,(int)$id);  
             if(!isset($_SESSION['GneeSite_login']) || !isset($_SESSION['GneeSite_senha']))
				{
					return utf8_decode("<script language=\"javascript\">jQuery(function() { mensagem('<h1>Voc&ecirc; Precisa Estar Logado para Votar.</h1>'); });</script>");  
				}
			 elseif($chekchar->getRowCount() > 0)
				{
					return utf8_decode("<script language=\"javascript\">jQuery(function() { mensagem('<h1>Voc&ecirc; ja Votou Nessa Screen Shot</h1>'); });</script>"); 
				} 
			 else
				{
				  $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_screen_votado (nome,idss) VALUES (?,?);
						   update GneeSite.dbo.gnee_screen set votos=votos+? where id=?",$this->login,(int)$id,$nota,$id);
						   header("Location: ?gne=ss_view&id=".(int)$id."");  
				}   
			}
			
		  function comet_ss_view($resp,$char,$id)
		  {
			global $conexao,$bbcode;
			$data = @date("d-m-Y");
			
			if(empty($char) || empty($resp))
				{
			 return "<span class=\"error_q\">Todos os Campos S&atilde;o Obr&iacute;gatorios.</span>";       
				} 
		$conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_screen_resp (id,login,resp,data,personagem) VALUES (?,?,?,?,?)",(int)$id,$this->login,$bbcode->arrumar_acentos_color($resp),$data,$char); 
		header("Location: ?gne=ss_view&id=".(int)$id."");   
		
		}	
		  
	}  
	?>
		
