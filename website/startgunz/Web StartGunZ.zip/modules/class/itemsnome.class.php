	<?php
		if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
		/*LEITOR DE ITEM.TXT. 
		CREDITOS WOLF.*/
		$itemnames = array();

		$file = fopen("modules/item(kor).txt", "r+");
		if (!$file) {
			$file = fopen("modules/item(kor).txt", "r+");
		} 
		if (!$file) {
			die("Falha ao abrir o item(kor).txt");
		} 
		
		if($file){
			$section = -1;
			while (!feof($file)) {

				$line = fgets($file);
				$line = trim($line, " \t\r\n");

				if (substr($line, 0, 2) == "//" || substr($line, 0, 2) == "#" || $line == "") {
					continue;
				}

				if (($pos = strpos($line, "//")) !== false) {
					$line = substr($line, 0, $pos);
				}
				$line = trim($line, " \t\r\n");

				if ($section == -1) {
					if (is_numeric($line)) {
						$section = (int)$line;
					}
				} else {
					if (strtolower($line) == "end") {
						$section = -1;
						continue;
					} else {
						$word = "";
						$column = 0;
						$string = false;
						$id = -1;
						$name = "&lt;??????????????&gt;";

						for ($i = 0; $i < strlen($line); $i++) {
							if ($string == true) {
								if ($line{$i} == "\"") {
									$string = false;
								} else {
									$word .= $line{$i};
								}
							} else {
								if ($word == "") {
									if ($line{$i} == "\"") {
										$string = true;
									} else
										if ($line{$i} != " " && $line{$i} != "\t") {
											$word .= $line{$i};
										}
								} else {
									if ($line{$i} == " " || $line{$i} == "\t") {
										if ($column == 0) {
											$id = $word;
										} 
                                        if ($column == 3) {
                                            $x = $word;
                                        }
                                        if ($column == 4) {
                                            $y = $word;
                                        }
											if ($column == 8) {
												$name = $word;
												break;
											}
										$column++;
										$word = "";
									} else {
										$word .= $line{$i};
									}
								}
							}
						}

						$itemnames[$section][$id] = $name; 
                        $itemsx[$section][$id] = $x;
                        $itemsy[$section][$id] = $y;
					}
				}

			}
		}?>