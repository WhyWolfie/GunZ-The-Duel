
<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
class items  extends funcao
{
	
	private function tipo($item)
		{
			$this->item = $item;
			if(VERSAO_MU == 1)
				{
					$this->tipo = hexdec(substr($this->item, 18,1));
					return $this->tipo;
				}
			$this->tipo = ((hexdec(substr($this->item, 0, 2)) & 0xE0) >> 5) + (((hexdec(substr($this->item, 14,2)) & 0x80) == 0x80) ? 8 : 0);
			return $this->tipo;
		}
        
	private function id($item)
		{
			$this->item = $item; 
			if(VERSAO_MU == 1)
				{  
					$this->item = ((hexdec(substr($this->item, 0, 2)) & 0xFF));
					return $this->item;
				}
					$this->item = ((hexdec(substr($this->item, 0, 2)) & 0x1F));
					return $this->item;
		}
        
	private function skill($item)
		{
			$this->item = $item; 
			$this->item = ((hexdec(substr($this->item, 2, 2)) & 0x80) == 0x80) ? " + Skill" : "";
			return $this->item;
		}
        
	private function level($item)
		{
			$this->item = $item;   
			$this->item = (hexdec(substr($this->item, 2, 2)) & 0x78) >> 3;
			if ($this->item == 0)
			{
			} 
			else 
			{
			 return " + " . $this->item;
			}
		}
        
	private function luck($item)
		{
			$this->item = $item; 
			$this->item = ((hexdec(substr($this->item, 2, 2)) & 0x04) == 0x04) ? " Luck(Chance de Sucesso com Soul +25%)<br />Luck(Aumenta o dano cr&iacute;tico em +5%)" : "";
			return $this->item;
		}
        
	private function option($item)
		{
			$this->item = $item;
			$this->item = (((hexdec(substr($this->item, 2, 2)) & 0x03)) + (((hexdec(substr($this->item, 14, 2)) & 0x40) == 0x40) ? 4 : 0)) * 4;
			if ($this->item == 0) {
			} else {
				return " Defesa Adicional: +  " . $this->item;
			}
		}
        
	private function dura($item)
		{
			$this->item = $item; 
			$this->item = hexdec(substr($this->item, 4, 2));
			return $this->item;
		}
        
	private function serial($item)
		{
			$this->item = $item; 
			$this->item = hexdec(substr($this->item, 6, 8));
			return $this->item;
		}
        
	private function ancient($item)
		{
			$this->item = $item;
			$item = (((hexdec(substr($this->item, 4, 2)) & 0x20) >> 6) + ((hexdec(substr($this->item, 17, 1)))));
			$this->item3 = (($this->item & 0x00) == 0x00) ? $this->val = "" : "" ;
			$this->item3 = (($this->item & 0x05) == 0x05) ? $this->val = "Staminia +5" : "" ;
			$this->item3 = (($this->item & 0x09) == 0x09) ? $this->val = "Staminia +10" : "" ;
			return $this->val;   
		}   
        
	private function refe($item)
		{
			$this->item = $item;
			$this->item = ((hexdec(substr($this->item,19,1)) & 0x08) == 0x08) ? "Refine: Dano Adicional + 200 <br />Chance de Sucesso de Pow + 10" : "";
			return $this->item;
		}
        
	private function harmony($item)
		{
			$this->item = $item;
			$this->a =  ((substr($this->item,20,1)));
			$this->b =((substr($this->item,21,1)));
			
			return $this->a.$this->b;
		}   
        
	private function nome_harmony($item,$tipo)
		{
			$this->item = $item;
			$this->tipo = $tipo;
			   if($this->tipo >= 0 && $this->tipo <= 4 )
			   {
				switch($this->item)
					
					{
						default:$this->nome = "Harmony N&atilde;o Encontrado";
						break;
						case 00: $this->nome = "";
						break;
						case 10: $this->nome = "Min Attack Power + 2";
						break;    
						case 11: $this->nome = "Min Attack Power + 3";
						break; 
						case 12: $this->nome = "Min Attack Power + 4";
						break;
						case 13: $this->nome = "Min Attack Power + 5";
						break;
						case 14: $this->nome = "Min Attack Power + 6";
						break;
						case 15: $this->nome = "Min Attack Power + 7";
						break;
						case 16: $this->nome = "Min Attack Power + 9";
						break;
						case 17: $this->nome = "Min Attack Power + 11";
						break;
						case 18: $this->nome = "Min Attack Power + 12";
						break;
						case 19: $this->nome = "Min Attack Power + 14";
						break; 
						case "1A": $this->nome = "Min Attack Power + 15";
						break; 
						case "1B": $this->nome = "Min Attack Power + 16";
						break;
						case "1C": $this->nome = "Min Attack Power + 17";
						break;
						case "1D": $this->nome = "Min Attack Power + 20";
						break; 
						case "1E": $this->nome = "Min Attack Power + 100000";
						break; 
						case "1F": $this->nome = "Min Attack Power + 110000";
						break; 
						case 20: $this->nome = "Max Attack Power + 3";
						break;    
						case 21: $this->nome = "Max Attack Power + 4";
						break; 
						case 22: $this->nome = "Max Attack Power + 5";
						break;
						case 23: $this->nome = "Max Attack Power + 6";
						break;
						case 24: $this->nome = "Max Attack Power + 7";
						break;
						case 25: $this->nome = "Max Attack Power + 8";
						break;
						case 26: $this->nome = "Max Attack Power + 10";
						break;
						case 27: $this->nome = "Max Attack Power + 12";
						break;
						case 28: $this->nome = "Max Attack Power + 14";
						break;
						case 29: $this->nome = "Max Attack Power + 17";
						break; 
						case "2A": $this->nome = "Max Attack Power + 20";
						break; 
						case "2B": $this->nome = "Max Attack Power + 23";
						break;
						case "2C": $this->nome = "Max Attack Power + 26";
						break;
						case "2D": $this->nome = "Max Attack Power + 29";
						break; 
						case "2E": $this->nome = "Max Attack Power + 100000";
						break; 
						case "2F": $this->nome = "Max Attack Power + 110000";
						break;
						case 30: $this->nome = "Need Strength - 6";
						break;    
						case 31: $this->nome = "Need Strength - 8";
						break; 
						case 32: $this->nome = "Need Strength - 10";
						break;
						case 33: $this->nome = "Need Strength - 12";
						break;
						case 34: $this->nome = "Need Strength - 14";
						break;
						case 35: $this->nome = "Need Strength - 16";
						break;
						case 36: $this->nome = "Need Strength - 20";
						break;
						case 37: $this->nome = "Need Strength - 23";
						break;
						case 38: $this->nome = "Need Strength - 26";
						break;
						case 39: $this->nome = "Need Strength - 29";
						break; 
						case "3A": $this->nome = "Need Strength - 32";
						break; 
						case "3B": $this->nome = "Need Strength - 35";
						break;
						case "3C": $this->nome = "Need Strength - 37";
						break;
						case "3D": $this->nome = "Need Strength - 40";
						break; 
						case "3E": $this->nome = "Need Strength - 100000";
						break; 
						case "3F": $this->nome = "Need Strength - 110000";
						break; 
						case 40: $this->nome = "Need Agility - 6";
						break;    
						case 41: $this->nome = "Need Agility - 8";
						break; 
						case 42: $this->nome = "Need Agility - 10";
						break;
						case 43: $this->nome = "Need Agility - 12";
						break;
						case 44: $this->nome = "Need Agility - 14";
						break;
						case 45: $this->nome = "Need Agility - 16";
						break;
						case 46: $this->nome = "Need Agility - 20";
						break;
						case 47: $this->nome = "Need Agility - 23";
						break;
						case 48: $this->nome = "Need Agility - 26";
						break;
						case 49: $this->nome = "Need Agility - 29";
						break; 
						case "4A": $this->nome = "Need Agility - 32";
						break; 
						case "4B": $this->nome = "Need Agility - 35";
						break;
						case "4C": $this->nome = "Need Agility - 37";
						break;
						case "4D": $this->nome = "Need Agility - 40";
						break; 
						case "4E": $this->nome = "Need Agility - 100000";
						break; 
						case "4F": $this->nome = "Need Agility - 110000";
						break;                    
						case 50: $this->nome = "Attack (Max,Min) + 0";
						break;    
						case 51: $this->nome = "Attack (Max,Min) + 0";
						break; 
						case 52: $this->nome = "Attack (Max,Min) + 0";
						break;
						case 53: $this->nome = "Attack (Max,Min) + 0";
						break;
						case 54: $this->nome = "Attack (Max,Min) + 0";
						break;
						case 55: $this->nome = "Attack (Max,Min) + 0";
						break;
						case 56: $this->nome = "Attack (Max,Min) + 7";
						break;
						case 57: $this->nome = "Attack (Max,Min) + 8";
						break;
						case 58: $this->nome = "Attack (Max,Min) + 9";
						break;
						case 59: $this->nome = "Attack (Max,Min) + 11";
						break; 
						case "5A": $this->nome = "Attack (Max,Min) + 12";
						break; 
						case "5B": $this->nome = "Attack (Max,Min) + 14";
						break;
						case "5C": $this->nome = "Attack (Max,Min) + 16";
						break;
						case "5D": $this->nome = "Attack (Max,Min) + 19";
						break; 
						case "5E": $this->nome = "Attack (Max,Min) + 0";
						break; 
						case "5F": $this->nome = "Attack (Max,Min) + 0";
						break;
						case 60: $this->nome = "Critical Damage + 0";
						break;    
						case 61: $this->nome = "Critical Damage + 0";
						break; 
						case 62: $this->nome = "Critical Damage + 0";
						break;
						case 63: $this->nome = "Critical Damage + 0";
						break;
						case 64: $this->nome = "Critical Damage + 0";
						break;
						case 65: $this->nome = "Critical Damage + 0";
						break;
						case 66: $this->nome = "Critical Damage + 12";
						break;
						case 67: $this->nome = "Critical Damage + 14";
						break;
						case 68: $this->nome = "Critical Damage + 16";
						break;
						case 69: $this->nome = "Critical Damage + 18";
						break; 
						case "6A": $this->nome = "Critical Damage + 20";
						break; 
						case "6B": $this->nome = "Critical Damage + 22";
						break;
						case "6C": $this->nome = "Critical Damage + 24";
						break;
						case "6D": $this->nome = "Critical Damage + 30";
						break; 
						case "6E": $this->nome = "Critical Damage + 0";
						break; 
						case "6F": $this->nome = "Critical Damage + 0";
						break;
						case 70: $this->nome = "Skill Power + 0";
						break;    
						case 71: $this->nome = "Skill Power + 0";
						break; 
						case 72: $this->nome = "Skill Power + 0";
						break;
						case 73: $this->nome = "Skill Power + 0";
						break;
						case 74: $this->nome = "Skill Power + 0";
						break;
						case 75: $this->nome = "Skill Power + 0";
						break;
						case 76: $this->nome = "Skill Power + 0";
						break;
						case 77: $this->nome = "Skill Power + 0";
						break;
						case 78: $this->nome = "Skill Power + 0";
						break;
						case 79: $this->nome = "Skill Power + 12";
						break; 
						case "7A": $this->nome = "Skill Power + 14";
						break; 
						case "7B": $this->nome = "Skill Power + 16";
						break;
						case "7C": $this->nome = "Skill Power + 18";
						break;
						case "7D": $this->nome = "Skill Power + 22";
						break; 
						case "7E": $this->nome = "Skill Power + 0";
						break; 
						case "7F": $this->nome = "Skill Power + 0";
						break;
						case 80: $this->nome = "Attack % Rate + 0";
						break;    
						case 81: $this->nome = "Attack % Rate + 0";
						break; 
						case 82: $this->nome = "Attack % Rate + 0";
						break;
						case 83: $this->nome = "Attack % Rate + 0";
						break;
						case 84: $this->nome = "Attack % Rate + 0";
						break;
						case 85: $this->nome = "Attack % Rate + 0";
						break;
						case 86: $this->nome = "Attack % Rate + 0";
						break;
						case 87: $this->nome = "Attack % Rate + 0";
						break;
						case 88: $this->nome = "Attack % Rate + 0";
						break;
						case 89: $this->nome = "Attack % Rate + 5";
						break; 
						case "8A": $this->nome = "Attack % Rate + 7";
						break; 
						case "8B": $this->nome = "Attack % Rate + 9";
						break;
						case "8C": $this->nome = "Attack % Rate + 11";
						break;
						case "8D": $this->nome = "Attack % Rate + 14";
						break; 
						case "8E": $this->nome = "Attack % Rate + 0";
						break; 
						case "8F": $this->nome = "Attack % Rate + 0";
						break;                    
						case 90: $this->nome = "SD - Rate + 0";
						break;    
						case 91: $this->nome = "SD - Rate + 0";
						break; 
						case 92: $this->nome = "SD - Rate + 0";
						break;
						case 93: $this->nome = "SD - Rate + 0";
						break;
						case 94: $this->nome = "SD - Rate + 0";
						break;
						case 95: $this->nome = "SD - Rate + 0";
						break;
						case 96: $this->nome = "SD - Rate + 0";
						break;
						case 97: $this->nome = "SD - Rate + 0";
						break;
						case 98: $this->nome = "SD - Rate + 0";
						break;
						case 99: $this->nome = "SD - Rate + 3";
						break; 
						case "9A": $this->nome = "SD - Rate + 5";
						break; 
						case "9B": $this->nome = "SD - Rate + 7";
						break;
						case "9C": $this->nome = "SD - Rate + 9";
						break;
						case "9D": $this->nome = "SD - Rate + 10";
						break; 
						case "9E": $this->nome = "SD - Rate + 0";
						break; 
						case "9F": $this->nome = "SD - Rate + 0";
						break;
						case "A0": $this->nome = "SD Ignore Rate + 0";
						break;    
						case "A1": $this->nome = "SD Ignore Rate + 0";
						break; 
						case "A2": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A3": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A4": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A5": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A6": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A7": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A8": $this->nome = "SD Ignore Rate + 0";
						break;
						case "A9": $this->nome = "SD Ignore Rate + 0";
						break; 
						case "AA": $this->nome = "SD Ignore Rate + 0";
						break; 
						case "AB": $this->nome = "SD Ignore Rate + 0";
						break;
						case "AC": $this->nome = "SD Ignore Rate + 0";
						break;
						case "AD": $this->nome = "SD Ignore Rate + 10";
						break; 
						case "AE": $this->nome = "SD Ignore Rate + 0";
						break; 
						case "AF": $this->nome = "SD Ignore Rate + 0";
						break;
					}
				}
				if($this->tipo == 5)
					{
						switch($this->item)
						{
							default:$this->nome = "Harmony N&atilde;o Encontrado";
							break;
							case 00: $this->nome = "";
							break;
							case 10: $this->nome = "Magic Power + 6";
							break;    
							case 11: $this->nome = "Magic Power + 8";
							break; 
							case 12: $this->nome = "Magic Power + 10";
							break;
							case 13: $this->nome = "Magic Power + 12";
							break;
							case 14: $this->nome = "Magic Power + 14";
							break;
							case 15: $this->nome = "Magic Power + 16";
							break;
							case 16: $this->nome = "Magic Power + 17";
							break;
							case 17: $this->nome = "Magic Power + 18";
							break;
							case 18: $this->nome = "Magic Power + 19";
							break;
							case 19: $this->nome = "Magic Power + 21";
							break; 
							case "1A": $this->nome = "Magic Power + 23";
							break; 
							case "1B": $this->nome = "Magic Power + 25";
							break;
							case "1C": $this->nome = "Magic Power + 27";
							break;
							case "1D": $this->nome = "Magic Power + 31";
							break; 
							case "1E": $this->nome = "Magic Power + 100000";
							break; 
							case "1F": $this->nome = "Magic Power + 110000";
							break; 
							case 20: $this->nome = "Need Strength - 6";
							break;    
							case 21: $this->nome = "Need Strength - 8";
							break; 
							case 22: $this->nome = "Need Strength - 10";
							break;
							case 23: $this->nome = "Need Strength - 12";
							break;
							case 24: $this->nome = "Need Strength - 14";
							break;
							case 25: $this->nome = "Need Strength - 16";
							break;
							case 26: $this->nome = "Need Strength - 20";
							break;
							case 27: $this->nome = "Need Strength - 23";
							break;
							case 28: $this->nome = "Need Strength - 26";
							break;
							case 29: $this->nome = "Need Strength - 29";
							break; 
							case "2A": $this->nome = "Need Strength - 32";
							break; 
							case "2B": $this->nome = "Need Strength - 35";
							break;
							case "2C": $this->nome = "Need Strength - 37";
							break;
							case "2D": $this->nome = "Need Strength - 40";
							break; 
							case "2E": $this->nome = "Need Strength - 100000";
							break; 
							case "2F": $this->nome = "Need Strength - 110000";
							break; 
							case 30: $this->nome = "Need Agility - 6";
							break;    
							case 31: $this->nome = "Need Agility - 8";
							break; 
							case 32: $this->nome = "Need Agility - 10";
							break;
							case 33: $this->nome = "Need Agility - 12";
							break;
							case 34: $this->nome = "Need Agility - 14";
							break;
							case 35: $this->nome = "Need Agility - 16";
							break;
							case 36: $this->nome = "Need Agility - 20";
							break;
							case 37: $this->nome = "Need Agility - 23";
							break;
							case 38: $this->nome = "Need Agility - 26";
							break;
							case 39: $this->nome = "Need Agility - 29";
							break; 
							case "3A": $this->nome = "Need Agility - 32";
							break; 
							case "3B": $this->nome = "Need Agility - 35";
							break;
							case "3C": $this->nome = "Need Agility - 37";
							break;
							case "3D": $this->nome = "Need Agility - 40";
							break; 
							case "3E": $this->nome = "Need Agility - 100000";
							break; 
							case "3F": $this->nome = "Need Agility - 110000";
							break;                    
							case 40: $this->nome = "Skill Power + 0";
							break;    
							case 41: $this->nome = "Skill Power + 0";
							break; 
							case 42: $this->nome = "Skill Power + 0";
							break;
							case 43: $this->nome = "Skill Power + 0";
							break;
							case 44: $this->nome = "Skill Power + 0";
							break;
							case 45: $this->nome = "Skill Power + 0";
							break;
							case 46: $this->nome = "Skill Power + 7";
							break;
							case 47: $this->nome = "Skill Power + 10";
							break;
							case 48: $this->nome = "Skill Power + 13";
							break;
							case 49: $this->nome = "Skill Power + 16";
							break; 
							case "4A": $this->nome = "Skill Power + 19";
							break; 
							case "4B": $this->nome = "Skill Power + 22";
							break;
							case "4C": $this->nome = "Skill Power + 25";
							break;
							case "4D": $this->nome = "Skill Power + 30";
							break; 
							case "4E": $this->nome = "Skill Power + 0";
							break; 
							case "4F": $this->nome = "Skill Power + 0";
							break;                
							case 50: $this->nome = "Critical Damage + 0";
							break;    
							case 51: $this->nome = "Critical Damage + 0";
							break; 
							case 52: $this->nome = "Critical Damage + 0";
							break;
							case 53: $this->nome = "Critical Damage + 0";
							break;
							case 54: $this->nome = "Critical Damage + 0";
							break;
							case 55: $this->nome = "Critical Damage + 0";
							break;
							case 56: $this->nome = "Critical Damage + 10";
							break;
							case 57: $this->nome = "Critical Damage + 12";
							break;
							case 58: $this->nome = "Critical Damage + 14";
							break;
							case 59: $this->nome = "Critical Damage + 16";
							break; 
							case "5A": $this->nome = "Critical Damage + 18";
							break; 
							case "5B": $this->nome = "Critical Damage + 20";
							break;
							case "5C": $this->nome = "Critical Damage + 22";
							break;
							case "5D": $this->nome = "Critical Damage + 28";
							break; 
							case "5E": $this->nome = "Critical Damage + 0";
							break; 
							case "5F": $this->nome = "Critical Damage + 0";
							break;
							case 60: $this->nome = "SD - Rate + 0";
							break;    
							case 61: $this->nome = "SD - Rate + 0";
							break; 
							case 62: $this->nome = "SD - Rate + 0";
							break;
							case 63: $this->nome = "SD - Rate + 0";
							break;
							case 64: $this->nome = "SD - Rate + 0";
							break;
							case 65: $this->nome = "SD - Rate + 0";
							break;
							case 66: $this->nome = "SD - Rate + 0";
							break;
							case 67: $this->nome = "SD - Rate + 0";
							break;
							case 68: $this->nome = "SD - Rate + 0";
							break;
							case 69: $this->nome = "SD - Rate + 4";
							break; 
							case "6A": $this->nome = "SD - Rate + 6";
							break; 
							case "6B": $this->nome = "SD - Rate + 8";
							break;
							case "6C": $this->nome = "SD - Rate + 10";
							break;
							case "6D": $this->nome = "SD - Rate + 13";
							break; 
							case "6E": $this->nome = "SD - Rate + 0";
							break; 
							case "6F": $this->nome = "SD - Rate + 0";
							break;
							case 70: $this->nome = "Attack % Rate + 0";
							break;    
							case 71: $this->nome = "Attack % Rate + 0";
							break; 
							case 72: $this->nome = "Attack % Rate + 0";
							break;
							case 73: $this->nome = "Attack % Rate + 0";
							break;
							case 74: $this->nome = "Attack % Rate + 0";
							break;
							case 75: $this->nome = "Attack % Rate + 0";
							break;
							case 76: $this->nome = "Attack % Rate + 0";
							break;
							case 77: $this->nome = "Attack % Rate + 0";
							break;
							case 78: $this->nome = "Attack % Rate + 0";
							break;
							case 79: $this->nome = "Attack % Rate + 0";
							break; 
							case "7A": $this->nome = "Attack % Rate + 0";
							break; 
							case "7B": $this->nome = "Attack % Rate + 0";
							break;
							case "7C": $this->nome = "Attack % Rate + 0";
							break;
							case "7D": $this->nome = "Attack % Rate + 0";
							break; 
							case "7E": $this->nome = "Attack % Rate + 0";
							break; 
							case "7F": $this->nome = "Attack % Rate + 0";
							break;                    
							case "80": $this->nome = "SD Ignore Rate + 0";
							break;    
							case "81": $this->nome = "SD Ignore Rate + 0";
							break;
							case "82": $this->nome = "SD Ignore Rate + 0";
							break;
							case "83": $this->nome = "SD Ignore Rate + 0";
							break;
							case "84": $this->nome = "SD Ignore Rate + 0";
							break;
							case "85": $this->nome = "SD Ignore Rate + 0";
							break;
							case "86": $this->nome = "SD Ignore Rate + 0";
							break;
							case "87": $this->nome = "SD Ignore Rate + 0";
							break;
							case "88": $this->nome = "SD Ignore Rate + 0";
							break;
							case "89": $this->nome = "SD Ignore Rate + 0";
							break; 
							case "8A": $this->nome = "SD Ignore Rate + 0";
							break; 
							case "8B": $this->nome = "SD Ignore Rate + 0";
							break;
							case "8C": $this->nome = "SD Ignore Rate + 0";
							break;
							case "8D": $this->nome = "SD Ignore Rate + 10";
							break; 
							case "8E": $this->nome = "SD Ignore Rate + 0";
							break; 
							case "8F": $this->nome = "SD Ignore Rate + 0";
							break;
							
							
							
						
						}
					}   
				if($this->tipo > 5 && $this->tipo <12)    
					{
					switch($this->item)
						{
							default:$this->nome = "Harmony N&atilde;o Encontrado";
							break;
							case 00: $this->nome = "";
							break;
							case 10: $this->nome = "Def Power + 3";
							break;    
							case 11: $this->nome = "Def Power + 4";
							break; 
							case 12: $this->nome = "Def Power + 5";
							break;
							case 13: $this->nome = "Def Power + 6";
							break;
							case 14: $this->nome = "Def Power + 7";
							break;
							case 15: $this->nome = "Def Power + 8";
							break;
							case 16: $this->nome = "Def Power + 10";
							break;
							case 17: $this->nome = "Def Power + 12";
							break;
							case 18: $this->nome = "Def Power + 14";
							break;
							case 19: $this->nome = "Def Power + 16";
							break; 
							case "1A": $this->nome = "Def Power + 18";
							break; 
							case "1B": $this->nome = "Def Power + 20";
							break;
							case "1C": $this->nome = "Def Power + 22";
							break;
							case "1D": $this->nome = "Def Power + 25";
							break; 
							case "1E": $this->nome = "Def Power + 100000";
							break; 
							case "1F": $this->nome = "Def Power + 110000";
							break; 
							case 20: $this->nome = "Max AG + 0";
							break;    
							case 21: $this->nome = "Max AG + 0";
							break; 
							case 22: $this->nome = "Max AG + 0";
							break;
							case 23: $this->nome = "Max AG + 4";
							break;
							case 24: $this->nome = "Max AG + 6";
							break;
							case 25: $this->nome = "Max AG + 8";
							break;
							case 26: $this->nome = "Max AG + 10";
							break;
							case 27: $this->nome = "Max AG + 12";
							break;
							case 28: $this->nome = "Max AG + 14";
							break;
							case 29: $this->nome = "Max AG + 16";
							break; 
							case "2A": $this->nome = "Max AG + 18";
							break; 
							case "2B": $this->nome = "Max AG + 20";
							break;
							case "2C": $this->nome = "Max AG + 22";
							break;
							case "2D": $this->nome = "Max AG + 25";
							break; 
							case "2E": $this->nome = "Max AG + 0";
							break; 
							case "2F": $this->nome = "Max AG + 0";
							break; 
							case 30: $this->nome = "Max HP + 0";
							break;    
							case 31: $this->nome = "Max HP + 0";
							break; 
							case 32: $this->nome = "Max HP + 0";
							break;
							case 33: $this->nome = "Max HP + 7";
							break;
							case 34: $this->nome = "Max HP + 9";
							break;
							case 35: $this->nome = "Max HP + 11";
							break;
							case 36: $this->nome = "Max HP + 13";
							break;
							case 37: $this->nome = "Max HP + 15";
							break;
							case 38: $this->nome = "Max HP + 17";
							break;
							case 39: $this->nome = "Max HP + 19";
							break; 
							case "3A": $this->nome = "Max HP + 21";
							break; 
							case "3B": $this->nome = "Max HP + 23";
							break;
							case "3C": $this->nome = "Max HP + 25";
							break;
							case "3D": $this->nome = "Max HP + 30";
							break; 
							case "3E": $this->nome = "Max HP + 0";
							break; 
							case "3F": $this->nome = "Max HP + 0";
							break;                    
							case 40: $this->nome = "HP Auto Rate + 0";
							break;    
							case 41: $this->nome = "HP Auto Rate + 0";
							break; 
							case 42: $this->nome = "HP Auto Rate + 0";
							break;
							case 43: $this->nome = "HP Auto Rate + 0";
							break;
							case 44: $this->nome = "HP Auto Rate + 0";
							break;
							case 45: $this->nome = "HP Auto Rate + 0";
							break;
							case 46: $this->nome = "HP Auto Rate + 1";
							break;
							case 47: $this->nome = "HP Auto Rate + 2";
							break;
							case 48: $this->nome = "HP Auto Rate + 3";
							break;
							case 49: $this->nome = "HP Auto Rate + 4";
							break; 
							case "4A": $this->nome = "HP Auto Rate + 5";
							break; 
							case "4B": $this->nome = "HP Auto Rate + 6";
							break;
							case "4C": $this->nome = "HP Auto Rate + 7";
							break;
							case "4D": $this->nome = "HP Auto Rate + 8";
							break; 
							case "4E": $this->nome = "HP Auto Rate + 0";
							break; 
							case "4F": $this->nome = "HP Auto Rate + 0";
							break;                
							case 50: $this->nome = "MP Auto Rate + 0";
							break;    
							case 51: $this->nome = "MP Auto Rate + 0";
							break; 
							case 52: $this->nome = "MP Auto Rate + 0";
							break;
							case 53: $this->nome = "MP Auto Rate + 0";
							break;
							case 54: $this->nome = "MP Auto Rate + 0";
							break;
							case 55: $this->nome = "MP Auto Rate + 0";
							break;
							case 56: $this->nome = "MP Auto Rate + 0";
							break;
							case 57: $this->nome = "MP Auto Rate + 0";
							break;
							case 58: $this->nome = "MP Auto Rate + 0";
							break;
							case 59: $this->nome = "MP Auto Rate + 1";
							break; 
							case "5A": $this->nome = "MP Auto Rate + 2";
							break; 
							case "5B": $this->nome = "MP Auto Rate + 3";
							break;
							case "5C": $this->nome = "MP Auto Rate + 4";
							break;
							case "5D": $this->nome = "MP Auto Rate + 5";
							break; 
							case "5E": $this->nome = "MP Auto Rate + 0";
							break; 
							case "5F": $this->nome = "MP Auto Rate + 0";
							break;
							case 60: $this->nome = "Def Success Rate + 0";
							break;    
							case 61: $this->nome = "Def Success Rate + 0";
							break; 
							case 62: $this->nome = "Def Success Rate + 0";
							break;
							case 63: $this->nome = "Def Success Rate + 0";
							break;
							case 64: $this->nome = "Def Success Rate + 0";
							break;
							case 65: $this->nome = "Def Success Rate + 0";
							break;
							case 66: $this->nome = "Def Success Rate + 0";
							break;
							case 67: $this->nome = "Def Success Rate + 0";
							break;
							case 68: $this->nome = "Def Success Rate + 0";
							break;
							case 69: $this->nome = "Def Success Rate + 3";
							break; 
							case "6A": $this->nome = "Def Success Rate + 4";
							break; 
							case "6B": $this->nome = "Def Success Rate + 5";
							break;
							case "6C": $this->nome = "Def Success Rate + 6";
							break;
							case "6D": $this->nome = "Def Success Rate + 8";
							break; 
							case "6E": $this->nome = "Def Success Rate + 0";
							break; 
							case "6F": $this->nome = "Def Success Rate + 0";
							break;
							case 70: $this->nome = "Dmg - Rate + 0";
							break;    
							case 71: $this->nome = "Dmg - Rate + 0";
							break; 
							case 72: $this->nome = "Dmg - Rate + 0";
							break;
							case 73: $this->nome = "Dmg - Rate + 0";
							break;
							case 74: $this->nome = "Dmg - Rate + 0";
							break;
							case 75: $this->nome = "Dmg - Rate + 0";
							break;
							case 76: $this->nome = "Dmg - Rate + 0";
							break;
							case 77: $this->nome = "Dmg - Rate + 0";
							break;
							case 78: $this->nome = "Dmg - Rate + 0";
							break;
							case 79: $this->nome = "Dmg - Rate + 3";
							break; 
							case "7A": $this->nome = "Dmg - Rate + 4";
							break; 
							case "7B": $this->nome = "Dmg - Rate + 5";
							break;
							case "7C": $this->nome = "Dmg - Rate + 6";
							break;
							case "7D": $this->nome = "Dmg - Rate + 7";
							break; 
							case "7E": $this->nome = "Dmg - Rate + 0";
							break; 
							case "7F": $this->nome = "Dmg - Rate + 0";
							break;                    
							case "80": $this->nome = "SD Rate + 0";
							break;    
							case "81": $this->nome = "SD Rate + 0";
							break;
							case "82": $this->nome = "SD  Rate + 0";
							break;
							case "83": $this->nome = "SD  Rate + 0";
							break;
							case "84": $this->nome = "SD  Rate + 0";
							break;
							case "85": $this->nome = "SD  Rate + 0";
							break;
							case "86": $this->nome = "SD  Rate + 0";
							break;
							case "87": $this->nome = "SD  Rate + 0";
							break;
							case "88": $this->nome = "SD  Rate + 0";
							break;
							case "89": $this->nome = "SD  Rate + 0";
							break; 
							case "8A": $this->nome = "SD  Rate + 0";
							break; 
							case "8B": $this->nome = "SD  Rate + 0";
							break;
							case "8C": $this->nome = "SD  Rate + 0";
							break;
							case "8D": $this->nome = "SD  Rate + 5";
							break; 
							case "8E": $this->nome = "SD  Rate + 0";
							break; 
							case "8F": $this->nome = "SD  Rate + 0";
							break;
						}	
					}
		
			return $this->nome; 
		}   
        
	private function Socket1($item)
		{
		$this->item = $item;    
		$this->item = hexdec(substr($this->item,22,2));
		return $this->item;    
		} 
        
	private function Socket2($item)
		{
		$this->item = $item;    
		$this->item = hexdec(substr($this->item,24,2));
		return $this->item;    
		} 
        
	private function Socket3($item)
		{
		$this->item = $item;    
		$this->item = hexdec(substr($this->item,26,2));
		return $this->item;    
		}
        
	private function Socket4($item)
		{
		$this->item = $item;    
		$this->item = hexdec(substr($this->item,27,2));
		return $this->item;    
		}
        
	private function Socket5($item)
		{
		$this->item = $item;    
		$this->item = hexdec(substr($this->item,30,2));
		return $this->item;    
		}			
        	  
	private function nome_socket($nome,$num = 0)
		{
			$this->nome = $nome;
			$this->num = $num;
			switch($this->nome)
				{ 
					default: $this->a = "Socket ".$this->num." Nao Encontrado";
					break;  
					case 255: $this->a = "Socket ".$this->num." Livre";
					break;
					case 0: $this->a = "";
					break;
					case 1: $this->a = "Socket ".$this->num." : Fire (Increase Damage/SkillPower (*lvl)) + 20";
					break;
					case 201:
					case 51: 
					case 101:;
					case 151: 
					$this->a = "Socket ".$this->num." : Fire (Increase Damage/SkillPower (*lvl)) + 400";
					break;
					case 2: $this->a = "Socket ".$this->num." : Fire (Increase Attack Speed) + 7";
					break;
					case 52:
					case 102:
					case 152:
					case 202:
					$this->a = "Socket ".$this->num." : Fire (Increase Attack Speed) + 1";
					break;
					case 3: $this->a = "Socket ".$this->num." : Fire (Increase Maximum Damage/Skill Power) + 30";
					break;
					case 53:
					case 103:
					case 153:
					case 203:
					$this->a = "Socket ".$this->num." : Fire (Increase Maximum Damage/Skill Power) + 1";
					break;
					case 4: $this->a = "Socket ".$this->num." : Fire (Increase Minimum Damage/Skill Power) + 20";
					break;
					case 54:
					case 104:
					case 154:
					case 204:
					$this->a = "Socket ".$this->num." : Fire (Increase Minimum Damage/Skill Power) + 1";
					break;
					case 5: $this->a = "Socket ".$this->num." : Fire (Increase Damage/Skill Power) + 20";
					break;
					case 55:
					case 105:
					case 155:
					case 205:
					$this->a = "Socket ".$this->num." : Fire (Increase Damage/Skill Power) + 1";
					break;
					case 6: $this->a = "Socket ".$this->num." : Fire (Decrease AG Use) + 40";
					break;
					case 56:
					case 106:
					case 156:
					case 206:
					$this->a = "Socket ".$this->num." : Fire (Decrease AG Use) + 1";
					break;
					case 11: $this->a = "Socket ".$this->num." : Water (Increase Defense Success Rate) + 10";
					break;
					case 61:
					case 111:
					case 161:
					case 211:
					$this->a = "Socket ".$this->num." : Water (Increase Defense Success Rate) + 1";
					break;
					case 12: $this->a = "Socket ".$this->num." : Water (Increase Defense) + 30";
					break;
					case 62:
					case 112:
					case 162:
					case 212:
					$this->a = "Socket ".$this->num." : Water (Increase Defense) + 1";
					break;
					case 13: $this->a = "Socket ".$this->num." : Water (Increase Defense Shield) + 7";
					break;
					case 63:
					case 113:
					case 163:
					case 213:
					$this->a = "Socket ".$this->num." : Water (Increase Defense Shield) + 1";
					break;
					case 14: $this->a = "Socket ".$this->num." : Water (Damage Reduction) + 4";
					break;
					case 64:
					case 114:
					case 164:
					case 214:
					$this->a = "Socket ".$this->num." : Water (Damage Reduction) + 1";
					break;
					case 15: $this->a = "Socket ".$this->num." : Water (Damage Reflections) + 5";
					break;
					case 65:
					case 115:
					case 165:
					case 215:
					$this->a = "Socket ".$this->num." : Water (Damage Reflections) + 1";
					break;
					case 17: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Life After Hunting) + 8";
					break;
					case 67: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Life After Hunting) + 49";
					break;
					case 117: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Life After Hunting) + 50";
					break;
					case 167: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Life After Hunting) + 51";
					break;
					case 217: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Life After Hunting) + 52";
					break;				
					case 18: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Mana After Hunting) + 8";
					break;
					case 68: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Mana After Hunting) + 49";
					break;
					case 117: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Mana After Hunting) + 50";
					break;
					case 167: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Mana After Hunting) + 51";
					break;
					case 217: $this->a = "Socket ".$this->num." : Ice (Increases + Rate of Mana After Hunting) + 52";
					break;
					case 19: $this->a = "Socket ".$this->num." : Ice (Increase Skill Attack Power) + 37";
					break;
					case 69:
					case 119:
					case 169:
					case 219:
					$this->a = "Socket ".$this->num." : Ice (Increase Skill Attack Power) + 1";
					break;
					case 20: $this->a = "Socket ".$this->num." : Ice (Increase Attack Success Rate) + 25";
					break;
					case 70:
					case 120:
					case 170:
					case 220:
					$this->a = "Socket ".$this->num." : Ice (Increase Attack Success Rate) + 1";
					break;
					case 21: $this->a = "Socket ".$this->num." : Ice (Item Duarability Reinforcement) + 30";
					break;
					case 71:
					case 121:
					case 171:
					case 221:
					$this->a = "Socket ".$this->num." : Ice (Item Duarability Reinforcement) + 1";
					break;
					case 22: $this->a = "Socket ".$this->num." : Wind (Increase Life AutoRecovery) + 8";
					break;
					case 72:
					case 122:
					case 172:
					case 222:
					$this->a = "Socket ".$this->num." : Wind (Increase Life AutoRecovery) + 1";
					break;
					case 23: $this->a = "Socket ".$this->num." : Wind (Increase Maximum Life) + 4";
					break;
					case 73:
					case 123:
					case 173:
					case 223:
					$this->a = "Socket ".$this->num." : Wind (Increase Maximum Life) + 1";
					break;
					case 24: $this->a = "Socket ".$this->num." : Wind (Increase Maximum Mana) + 4";
					break;
					case 74:
					case 124:
					case 174:
					case 224:
					$this->a = "Socket ".$this->num." : Wind (Increase Maximum Mana) + 1";
					break;
					case 25: $this->a = "Socket ".$this->num." : Wind (Increase Mana AutoRecovery) + 7";
					break;
					case 75:
					case 125:
					case 175:
					case 225:
					$this->a = "Socket ".$this->num." : Wind (Increase Mana AutoRecovery) + 1";
					break;
					case 26: $this->a = "Socket ".$this->num." : Wind (Increase Maximum AG) + 25";
					break;
					case 76:
					case 126:
					case 176:
					case 226:
					$this->a = "Socket ".$this->num." : Wind (Increase Maximum AG) + 1";
					break;					
					case 27: $this->a = "Socket ".$this->num." : Wind (Increase AG Amount) + 3";
					break;
					case 77:
					case 127:
					case 177:
					case 227:
					$this->a = "Socket ".$this->num." : Wind (Increase AG Amount) + 1";
					break;    
					case 30: $this->a = "Socket ".$this->num." : Lightning (Increase Excellent Damage) + 15";
					break;
					case 80:
					case 130:
					case 180:
					case 230:
					$this->a = "Socket ".$this->num." : Lightning (Increase Excellent Damage) + 1";
					break; 			
					case 31: $this->a = "Socket ".$this->num." : Lightning (Increase Excellent Damage Success Rate) + 10";
					break;
					case 81:
					case 131:
					case 181:
					case 231:
					$this->a = "Socket ".$this->num." : Lightning (Increase Excellent Damage Success Rate) + 1";
					break;         
					case 32: $this->a = "Socket ".$this->num." : Lightning (Increase Critical Damage) + 30";
					break;
					case 82:
					case 132:
					case 182:
					case 232:
					$this->a = "Socket ".$this->num." : Lightning (Increase Critical Damage) + 1";
					break;  
					case 33: $this->a = "Socket ".$this->num." : Lightning (Increase Critical Damage Success Rate) + 8";
					break;
					case 83:
					case 133:
					case 183:
					case 233:
					$this->a = "Socket ".$this->num." : Lightning (Increase Critical Damage Success Rate) + 1";
					break;
					case 37: $this->a = "Socket ".$this->num." : Ground (Increase Stamina) + 30";
					break;
					case 87:
					case 137:
					case 187:
					case 237:
					$this->a = "Socket ".$this->num." : Ground (Increase Stamina) + 1";
					break;
							 
				}
		   return $this->a;    
		}          
          
	private function achar_item_serial($serial)
		{
			$serial = "0x" . dechex($serial);
			$a = mssql_fetch_row(mssql_query("select Name,AccountID from character where ( CHARINDEX (" .
				$serial . ", inventory ) %10 = 4)"));
			$b = mssql_fetch_row(mssql_query("select AccountID from warehouse where ( CHARINDEX (" .
				$serial . ", items ) %10 = 4)"));
			$b[0];
			if ($a[0] < 1) {
			} else {
				return $a[0];
			}
			if ($b[0] < 1) {
			} else {
				return $b[0];
			}
		}			
        																	   
	private function exe($item)
		{
			$this->item = $item;
			$this->item = hexdec(substr($this->item, 14, 2));
			$this->count = 0;
			$this->exc = array();
			$this->exc[0] = (($this->item & 0x01) == 0x01);
			$this->exc[1] = (($this->item & 0x02) == 0x02);
			$this->exc[2] = (($this->item & 0x04) == 0x04);
			$this->exc[3] = (($this->item & 0x08) == 0x08);
			$this->exc[4] = (($this->item & 0x10) == 0x10);
			$this->exc[5] = (($this->item & 0x20) == 0x20);
			if ($this->exc[0] == true) {
				$this->count += 1;
			}
			if ($this->exc[1] == true) {
				$this->count += 1;
			}
			if ($this->exc[2] == true) {
				$this->count += 1;
			}
			if ($this->exc[3] == true) {
				$this->count += 1;
			}
			if ($this->exc[4] == true) {
				$this->count += 1;
			}
			if ($this->exc[5] == true) {
				$this->count += 1;
			}
			if ($this->count == 0) {
				return "";
			} else {
				return $this->count;
			}
		}
        
	private function nome_exe($item,$tipo)
		{
			$this->item = $item;
			$this->tipo = $tipo;
			$this->item = hexdec(substr($this->item, 14, 2));
			$this->exc = array();
			if($this->tipo > 5 && $this->tipo < 12 || $this->tipo == 13)
				{
					$exc[0] = (($this->item & 0x01) == 0x01) == true ? $this->a = "<br /><br />\t Aumento da taxa de aquisi&ccedil;&atilde;o de zen em +40</br>" :"";
					$exc[1] = (($this->item & 0x02) == 0x02) == true ? $this->a .= "\t Sucesso de Defesa em 10%</br>" :"";
					$exc[2] = (($this->item & 0x04) == 0x04) == true ? $this->a .= "\t Reflete em 5% o dano Recebido</br>" :"";
					$exc[3] = (($this->item & 0x08) == 0x08) == true ? $this->a .= "\t Diminui o Dano em 4%</br>" :"";
					$exc[4] = (($this->item & 0x10) == 0x10) == true ? $this->a .= "\t Aumenta a Mana em 4%</br>" :"";
					$exc[5] = (($this->item & 0x20) == 0x20) == true ? $this->a .= "\t Aumenta a Vida em 4%</br>" :"";
					return $this->a;
				}
			elseif($this->tipo >= 0 && $this->tipo <= 4 )
				 {
					$exc[0] = (($this->item & 0x01) == 0x01) == true ? $this->b = "<br /><br />\t Sucesso em Dano Excelente + 10%</br>" :"";
					$exc[1] = (($this->item & 0x02) == 0x02) == true ? $this->b .= "\t Aumento do Dano M&aacute;gico + level / 20</br>" :"";
					$exc[2] = (($this->item & 0x04) == 0x04) == true ? $this->b .= "\t Aumento do Dano M&aacute;gicoem + 1%</br>" :"";
					$exc[3] = (($this->item & 0x08) == 0x08) == true ? $this->b .= "\t Aumento da Velocidade do Dano M&aacute;ico + 7</br>" :"";
					$exc[4] = (($this->item & 0x10) == 0x10) == true ? $this->b .= "\t Aumento da Taxa de Recupera&ccedil;&atilde;o de Vida (Vida/8)</br>" :"";
					$exc[5] = (($this->item & 0x20) == 0x20) == true ? $this->b .= "\t Aumento da Taxa de Recupera&ccedil;&atilde;o de Mana (Mana/8)</br>" :"";
					return $this->b;
						 
				 }
			elseif($this->tipo == 5 )
				 {
					 
				 } 
			
			elseif($this->tipo == 12 )
				 {
					$exc[0] = (($this->item & 0x01) == 0x01) == true ? $this->c = "<br /><br />\t Aumento da Velocidade do Dano M&aacute;ico + 5</br>" :"";
					$exc[1] = (($this->item & 0x02) == 0x02) == true ? $this->c .= "\t Staminia Aumentada em + 50</br>" :"";
					$exc[2] = (($this->item & 0x04) == 0x04) == true ? $this->c .= "\t Defesa do Opoente Ignorada em 3%</br>" :"";
					$exc[3] = (($this->item & 0x08) == 0x08) == true ? $this->c .= "\t Mana Aumentada em + 125" : "";
					$exc[4] = (($this->item & 0x10) == 0x10) == true ? $this->c .= "\t  Vida Aumentada em + 125</br>" :"";
					$exc[5] = (($this->item & 0x20) == 0x20) == true ? $this->c .= "" :"";
					return $this->c;
					 
				 } 	 
		}
        
	private function nomeitem($tipo, $id)
		{
			global $itemnames;
			return isset($itemnames[$tipo][$id]) ? $itemnames[$tipo][$id] : "Nome nao encontrado";
		}
        
    private function tamanhox($tipo, $id)
        {
            global $itemsx;
            return $itemsx[$tipo][$id];
        }
        
    private function tamanhoy($tipo, $id)
        {
            global $itemsy;
            return $itemsy[$tipo][$id];
        } 
               
	public function serial_alterar($item2)
		{
			$a = mssql_fetch_row(mssql_query("exec MuOnline.dbo.WZ_GetItemSerial"));
			$serial = str_pad(dechex($a[0]), 8, "0", STR_PAD_LEFT);
			$item = substr_replace($item2,$serial,6,8);
			return $item;
		}
        
	private function possicao($pos)
		{
			switch($pos)
				{
					case 0: $p = "M&atilde;o Esquerda: ";
					break;
					case 1: $p = "M&atilde;o Direita: ";
					break;
					case 2: $p = "Helm: ";
					break;
					case 3: $p = "Armor: ";
					break;
					case 4: $p = "Pants: ";
					break;
					case 5: $p = "Gloves: ";     
					break;
					case 6: $p = "Boots : ";        
					break;
					case 7: $p = "Asa : ";
					break;
					case 8: $p = "Anjo: ";                  
					break;
					case 9: $p = "Pendant: ";
					break;                                      
					case 10: $p = "Ring Esquerdo: ";
					break;
					case 11: $p = "Ring Direito: ";
					break;   
					default: $p= "Invent&aacute;rio: ";
					break;
				}
			 return $p;   
		}
        
	public function deletar_todos_items_hexa($codigo)
		{
				global $TROCA_DE_ITEMS_MOEDA;
				if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}  
                	(VERSAO_MU == 1) ? $cortar = 32 : $cortar = 20;
                    $tamanho = str_repeat("F",$cortar);
				$query = mssql_query("SELECT CONVERT(TEXT, CONVERT(VARCHAR(".TAMANHO_BAU."), Items)) AS 'Warehouse' FROM MuOnline.dbo.warehouse WHERE AccountID = '" . $this->login . "'");
				if ($query) 
				{
						if ($character = mssql_fetch_object($query)) 
						{
							$character->Warehouse = strtoupper(bin2hex($character->Warehouse));
							$items = str_split($character->Warehouse, $cortar);
										(int)$coint=0;
							foreach ($items as $id => $item) 
							{
								if($items[$id] == $tamanho)
									{
										
									}
								else 
								{   

									if(VERSAO_MU == 0)
                                        {
                                            $items[$id] = substr_replace($items[$id],"0000",16,4); 
        									$TROCA_DE_ITEMS_MOEDA["HEXADECIMAL"] = substr_replace($TROCA_DE_ITEMS_MOEDA["HEXADECIMAL"],"0000",16,4);
									        
                                        }
									if($items[$id] == $TROCA_DE_ITEMS_MOEDA["HEXADECIMAL"]) 
										{ 
											$items[$id] = $tamanho;
											$coint++;
										} 
								}   
								   
							}
						 
							mssql_query("UPDATE MuOnline.dbo.warehouse SET Items = 0x" . implode('', $items) . " where AccountID='".$this->login."'");
							mssql_query("UPDATE MuOnline.dbo.".$TROCA_DE_ITEMS_MOEDA["TABELA"]." set ".$TROCA_DE_ITEMS_MOEDA["COLUNA"]."=".$TROCA_DE_ITEMS_MOEDA["COLUNA"]."+'".(($TROCA_DE_ITEMS_MOEDA["QTD_POR_ITEM"])*$coint)."' where ".$TROCA_DE_ITEMS_MOEDA["LOGIN"]."='".$this->login."'");
							if($coint >= 1)
								{
									return '<center><div class="ok">[&loz;]Foram Retirados '.$coint.' Items e Foram Adicionado(s) '.($TROCA_DE_ITEMS_MOEDA["QTD_POR_ITEM"]*$coint).' '.$TROCA_DE_ITEMS_MOEDA["NOME_MOEDA"].'(s).</div>';  
								}
						   elseif($coint < 1)
								{
									return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem Nenhum Item Requerido Para a Troca.</div>';  
								}     
						} 
				}
		}   
        
    private function procurar_espaco($x,$y)
        {
            $this->x = $x;
            $this->y = $x;
            
        }
    public function verificar_items($nome)
        {
            (VERSAO_MU == 1) ? $cortar = 32 : $cortar = 20;
            $tamanho = str_repeat("F",$cortar);
            $query = mssql_query("SELECT CONVERT(TEXT, CONVERT(VARCHAR(".TAMANHO_INV."), Inventory)) AS 'Inventory' FROM MuOnline.dbo.Character WHERE Name = '" .
                $nome . "'");
            if($query)
                {
                  if ($character = mssql_fetch_object($query)) 
                  {
                    $character->Inventory = strtoupper(bin2hex($character->Inventory));
                    $items = str_split($character->Inventory, $cortar);
                    for((int)$x=0;$x<12;$x++)  
                        {
                            if($items[$x] == $tamanho)
                                {
                                    
                                }
                            else
                                {
                                    $contador++;
                                }    
                        }
                        return $contador;
                  }  
            }    
        }    
	public function inventorio($nome)
		{
		  	(VERSAO_MU == 1) ? $cortar = 32 : $cortar = 20;
			$tamanho = str_repeat("F",$cortar);
		
			$query = mssql_query("SELECT CONVERT(TEXT, CONVERT(VARCHAR(".TAMANHO_INV."), Inventory)) AS 'Inventory' FROM MuOnline.dbo.Character WHERE Name = '" .
				$nome . "'");
			if ($query) {
				if ($character = mssql_fetch_object($query)) {
					$character->Inventory = strtoupper(bin2hex($character->Inventory));
					$items = str_split($character->Inventory, $cortar);
						(int)$pos = 0;
						(int)$q = 0;  
					foreach ($items as $id => $item) 
					{
									 
						if ($item == $tamanho) 
						{
							 if($q < 12) 
							 {   
								 $post = $this->possicao($pos);   
								 
								 echo "<tr><td align=\"center\" ><span class=\"nome_free\"><b>".$post."</b> Slot Livre</td></tr>"; 
								 $q++;
							 }
						} 
						else
						 {
							$q++;
							$item;
							$count = 0;
							$dump = $item;
							$tipo = $this->tipo($dump);
							$id = $this->id($dump);
							$skill = $this->skill($dump);
							$luck = $this->luck($dump);
							$level = $this->level($dump);
							$option = $this->option($dump);
							$durability = $this->dura($dump);
							$serial = $this->serial($dump);
							$exe = $this->nome_exe($dump,$tipo);
							$nexe = $this->exe($dump);
							$nome = $this->nomeitem($tipo, $id);
							$anc = $this->ancient($dump);
							$post = $this->possicao($pos);
							($anc == "") ? $anc = "" : $anc; 
							if(VERSAO_MU == 1)
								{
									$refe = $this->refe($dump);
									$socket1 = $this->nome_socket($this->Socket1($dump),1);
									$socket2 = $this->nome_socket($this->Socket2($dump),2);
									$socket3 = $this->nome_socket($this->Socket3($dump),3);
									$socket4 = $this->nome_socket($this->Socket4($dump),4);
									$socket5 = $this->nome_socket($this->Socket5($dump),5);
									$harmony = $this->nome_harmony($this->harmony($dump),$this->tipo($dump));   
									($harmony == "") ? $harmony = "" : $harmony = "Harmony: ".$harmony;
									($socket1 == "") ? $socket1 = "Socket 1: Livre" : $socket1;
									($socket2 == "") ? $socket2 = "Socket 2: Livre" : $socket2;
									($socket3 == "") ? $socket3 = "Socket 3: Livre" : $socket3;
									($socket4 == "") ? $socket4 = "Socket 4: Livre" : $socket4;
									($socket5 == "") ? $socket5 = "Socket 5: Livre" : $socket5;
									
								}
									if($nexe >= 1)
										{
											$nome = "Excelente ".$nome;
										}
								
							if(VERSAO_MU == 1)
								{			
								echo "<script>$(function()
										{
										$('#a".$g."').tooltip ('<div id=\"detalhes_itens2\"><br /><h2>".$nome."</h2> <center>Durability: ".$durability."</center><br /><p class=\"luck2\" >".$luck."<br />".$option."".$exe."</p><span class=\"refine\">".$refe."</span><br /><span class=\"harmony2\">".$harmony."</span><br /><br />".$anc."<br /><span class=\"socket2\">Informa&ccedil;&atilde;o de Sockets</span><br /><br /><span class=\"gold2\">".$socket1."<br />".$socket2."<br />".$socket3."<br />".$socket4."<br />".$socket5."</span> </div>', {width: 0, style: 'alert',});
										}
										);	</script>
								
								<tr><td align=\"center\" width=\"35%\"><span id=\"a".$g."\" class=\"nome_item\"><b>".$post."</b> ".$nome."".$level." </td></tr>";
								}
							if(VERSAO_MU == 0)
								{
								echo "<script>$(function()
										{
										$('#a".$g."').tooltip ('<div id=\"detalhes_itens2\"><br /><h2>".$nome."</h2> <p><center>Durability: ".$durability.".</center></p><h3>".$luck."<br />".$option."".$exe."</h3></div>', {width: 320, style: 'alert',});
										}
										);	</script>
								
								<tr><td align=\"center\" width=\"35%\"><span id=\"a".$g."\" class=\"nome_item2\"><b>".$post."</b> ".$nome."".$level." </td></tr>";	
								}
						}
						$pos++;
						$g++;
					}
				} else {
					echo "Erro ao retornar inventario";
				}
			} else {
				echo "Erro executar comando sql";
			}
		}
        
	public function Bau($login)
		{
			(VERSAO_MU == 1) ? $cortar = 32 : $cortar = 20;
			$tamanho = str_repeat("F",$cortar);
			$query = mssql_query("SELECT CONVERT(TEXT, CONVERT(VARCHAR(".TAMANHO_BAU."), Items)) AS 'Inventory' FROM MuOnline.dbo.warehouse WHERE AccountID = '" .
				$login . "'");
			if ($query) {
				if ($character = mssql_fetch_object($query)) {
					$character->Inventory = strtoupper(bin2hex($character->Inventory));
					$items = str_split($character->Inventory, $cortar);
					$g =0;
					foreach ($items as $id => $item) {
						$g++;
						if ($item == $tamanho) {
						} else {
							$item;
							$count = 0;
							$dump = $item;
							$tipo = $this->tipo($dump);
							$id = $this->id($dump);
							$skill = $this->skill($dump);
							$luck = $this->luck($dump);
							$level = $this->level($dump);
							$option = $this->option($dump);
							$durability = $this->dura($dump);
							$serial = $this->serial($dump);
							$exe = $this->nome_exe($dump,$tipo);
							$nexe = $this->exe($dump);
							$nome = $this->nomeitem($tipo, $id);
							$anc = $this->ancient($dump);
							($anc == "") ? $anc = "" : $anc; 
							if(VERSAO_MU == 1)
								{
									$refe = $this->refe($dump);
									$socket1 = $this->nome_socket($this->Socket1($dump),1);
									$socket2 = $this->nome_socket($this->Socket2($dump),2);
									$socket3 = $this->nome_socket($this->Socket3($dump),3);
									$socket4 = $this->nome_socket($this->Socket4($dump),4);
									$socket5 = $this->nome_socket($this->Socket5($dump),5);
									$harmony = $this->nome_harmony($this->harmony($dump),$this->tipo($dump));   
									($harmony == "") ? $harmony = "" : $harmony = "Harmony: ".$harmony;
									($socket1 == "") ? $socket1 = "Socket 1: Livre" : $socket1;
									($socket2 == "") ? $socket2 = "Socket 2: Livre" : $socket2;
									($socket3 == "") ? $socket3 = "Socket 3: Livre" : $socket3;
									($socket4 == "") ? $socket4 = "Socket 4: Livre" : $socket4;
									($socket5 == "") ? $socket5 = "Socket 5: Livre" : $socket5;
									
								}
									if($nexe >= 1)
										{
											$nome = "Excelente ".$nome;
										}
								
							if(VERSAO_MU == 1)
								{			
								echo "<script>$(function()
										{
										$('#a".$g."').tooltip ('<div id=\"detalhes_itens\"><br /><h2>".$nome."</h2> <center>Durability: ".$durability."</center><br /><p class=\"luck\" >".$luck."<br />".$option."".$exe."</p><span class=\"refine\">".$refe."</span><br /><span class=\"harmony\">".$harmony."</span><br /><br />".$anc."<br /><span class=\"socket\">Informa&ccedil;&atilde;o de Sockets</span><br /><br /><span class=\"gold\">".$socket1."<br />".$socket2."<br />".$socket3."<br />".$socket4."<br />".$socket5."</span> </div>', {width: 0, style: 'alert',});
										}
										);	</script>
								
								<tr><td align=\"center\" width=\"35%\"><span id=\"a".$g."\" class=\"nome_item\">".$nome."".$level." </td></tr>";
								}
							if(VERSAO_MU == 0)
								{
								echo "<script>$(function()
										{
										$('#a".$g."').tooltip ('<div id=\"detalhes_itens\"><br /><h2>".$nome."</h2> <p><center>Durability: ".$durability.".</center></p><br /><br /><p class=\"luck\" >".$luck."<br />".$option."".$exe."</p></div>', {width: 320, style: 'alert',});
										}
										);	</script>
								
								<tr><td align=\"center\" width=\"35%\"><span id=\"a".$g."\" class=\"nome_item\">".$nome."".$level." </td></tr>";	
								}
						}
						echo "\n";
					}
				} else {
					echo "Erro ao retornar Ba&uacute;";
				}
			} else {
				echo "Erro executar comando sql";
			}
		}


}

?>