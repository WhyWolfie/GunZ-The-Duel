<?php
class func_char extends funcao
{
   function remov_foto($codigo,$nome)
	{
		global $conexao;
	   if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		$conexao->ExecuteNonQuery("update character set foto='sem_foto.jpg' where name=? and accountid=?",$nome,$this->login);
		return '<center><div class="ok">[&loz;]Foto do Char '.$nome.' Foi Removida.</div>';						 
	}    
   function transferir_reset($codigo,$nome,$nome2,$qtd)
	{
	   global $conexao;
	   if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q"><style="color:#333;">[&loz;]C&oacute;digo Incorreto.</div>';
			} 
       if($qtd < 0)  
          {
             return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>';
          }     
		$checkreset = $conexao->ExecuteScalar("select ".coluna_reset." FROM MuOnline.dbo.character where name=? and accountid=?",$nome,$this->login);	
		$checkchar  = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.character where name=?",$nome2);
	  if(empty($nome) || empty($qtd))
		{
		  return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>';
		}
	   elseif($checkchar < 1)
			{
			return '<center><div class="error_q">[&loz;]O Char '.$nome2.' n&atilde;o existe.</div>';
			}
		elseif($checkreset < $qtd )
			{
			  return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem '.$qtd.' Resets para Transferir.</div>';
			}
																								  
		$q = $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."+? where name=?",(int)$qtd,$nome2);
		$q2 = $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=? and accountid=?",(int)$qtd,$nome,$this->login);	
		return '<center><div class="ok">[&loz;]O Personagem '.$nome.' transferiu '.$qtd.' Resets para '.$nome2.'.</div>';
	}
	function transferir_pontos($codigo,$char,$nome,$pontos)
		{
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			     return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}  
          if($pontos < 0)  
            {
             return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>';
            }  
			$checkchar = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.character where name=?",$nome);
			$a = $conexao->ExecuteScalar("select leveluppoint from MuOnline.dbo.character where name=? and accountid=?",$char,$this->login); 
		  if($checkchar < 1)
			{
			 return '<center><div class="error_q">[&loz;] O Char '.$nome.' n&atilde;o Existe.</div>';
			}
		  elseif($a < $pontos)
			{
			  return '<center><div class="error_q">[&loz;] Voc&ecirc; n&atilde;o tem '.$pontos.' para Transferir.</div>';
			}
		 $q = $conexao->ExecuteNonQuery("update character set leveluppoint=leveluppoint+? where name=?",(int)$pontos,$nome);
         $g = $conexao->ExecuteNonQuery("update character set leveluppoint=leveluppoint-? where name=? and accountid=?",(int)$pontos,$char,$this->login);	
		return '<center><div class="ok">[&loz;]O Personagem '.$char.' transferiu '.$pontos.' Pontos para '.$nome.'</div>';																  			
		} 
	 function transferir_mr($codigo,$nome1,$nome2,$reset)
		{
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
           if($reset < 0)  
            {
                 return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>';
            } 
		   $checkreset = $conexao->ExecuteScalar("select ".coluna_mr." from MuOnline.dbo.character where name=? and accountid=?",$nome1,$this->login);	
		   $checkchar  = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.character where name=?",$nome2);
		if(empty($nome1) || empty($reset))
			{
			return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>';
			}
		elseif($checkchar < 1)
			{
			 return '<center><div class="error_q">[&loz;]O Char '.$nome2.' n&atilde;o existe.</div>';
			}
		elseif($checkreset < $reset )
			{
			return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem '.$resets.' Master Resets para Transferir.</div>';
			}
		$q = $conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+? where name=?",(int)$reset,$nome2);
        $conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."-? where name=?",(int)$reset,$nome1);	
		return '<center><div class="ok">[&loz;]O Personagem '.$nome1.' transferiu '.$reset.' Master Resets para '.$nome2.' .</div>';     
		}   
	function habilitar_perfil($codigo,$nome)
		{
			global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			} 
		  $a = $conexao->ExecuteScalar("select perfil from MuOnline.dbo.character where name=? and accountid=?",$nome,$this->login);    
			  if($a == 1)
			  {    
				return '<center><div class="error_q">[&loz;]Perfil do Char '.$nome.' Ja esta Ativado.</div>';    
			  }
		   $conexao->ExecuteNonQuery("update character set perfil=1 where name=? and accountid=?",$nome,$this->login);  
			return '<center><div class="ok">[&loz;]Perfil do Char '.$nome.' Foi Ativado.</div>';  
		}	
	function desabilitar_perfil($codigo,$nome)
		{
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			} 
		   $a = $conexao->ExecuteScalar("select perfil from MuOnline.dbo.character where name=? and accountid=?",$nome,$this->login);  
				if($a == 0)
					{
					  return '<center><div class="error_q">[&loz;]Perfil do Char '.$nome.' Ja esta desativado.</div>';   
					}
			  $conexao->ExecuteNonQuery("update character set perfil=0 where name=? and accountid=?",$nome,$this->login);
				return '<center><div class="ok">[&loz;]Perfil do Char '.$nome.' Foi desativado.</div>';
		  }		  
	 function desbugar_pontos($codigo,$nome)
		{
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
			$b = $conexao->ExecuteReader("select Strength,Dexterity,Vitality,Energy,Class from MuOnline.dbo.character where name=? and accountid=?",$nome,$this->login);
			 $b = $b->fetchObject();
             if($b->Strength > 32767 || $b->Strength < 0 || $b->Dexterity > 32767 || $b->Dexterity < 0 || $b->Vitality > 32767 || $b->Vitality < 0 || $b->Energy > 32767 || $b->Energy < 0)
				{                                
					if($b->Strength > 32767 || $b->Strength  < 0)
					{
					   $conexao->ExecuteNonQuery("update character set Strength='".desb_p."' where name=? and accountid=?",$nome,$this->login);
					   $return++;
					}                                 
					if($b->Dexterity > 32767 || $b->Dexterity < 0)
					 {
						$conexao->ExecuteNonQuery("update character set Dexterity='".desb_p."' where name=? and accountid=?",$nome,$this->login);
						$return++;
					 }
					 if($b->Vitality > 32767 || $b->Vitality < 0)
					 {
						$conexao->ExecuteNonQuery("update character set Vitality='".desb_p."' where name=? and accountid=?",$nome,$this->login);
						 $return++;
					 }
					 if($b->Energy > 32767 || $b->Energy < 0)
					 {
						$conexao->ExecuteNonQuery("update character set Energy='".desb_p."'where name=? and accountid=?",$nome,$this->login);
						$return++;
					 }
					if(VERSAO_MU == 1)
					{
					  $leader_check = $conexao->ExecuteScalar("select Leadership from MuOnline.dbo.character where name=? and accountid=?",$nome,$this->login);
					  if($leader_check < 0 || $leader_check > 32767 && $b->Class == 64 || $b->Class == 65)
					  {  
					  $conexao->ExecuteNonQuery("update character set LeaderShip='".desb_p."' where name=? and accountid=?",$nome,$this->login);
					  $return++;
					  }
					} 
			}   
			else 
			{
			  return '<center><div class="error_q">[&loz;]Seus Pontos n&atilde;o est&atilde;o Bugados.</div>';
			}
			  if($return > 0)
			  {
				return '<center><div class="ok">[&loz;]Pontos Desbugados Com Sucesso.</div>';
			  }                                  
		}
	 function limpar_magia($codigo,$nome)
		{
  		global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		   $f = str_repeat("F", TAMANHO_MAGIA);                                                                                         
		   $conexao->ExecuteNonQuery("UPDATE CHARACTER SET MagicList=0x".$f." WHERE NAME=? and accountid=?",$nome,$this->login);
		   return '<center><div class="ok">Magias do Char do Char '.$nome.' foram Limpas com Sucesso.</div>';              
		}
	function limpar_pk($codigo,$nome)
		{
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
			  $check = $conexao->ExecuteReader("SELECT Pktime,Money,PkLevel,PkCount FROM MuOnline.dbo.character WHERE Name=? and accountid=?",$nome,$this->login);
			  $check = $check->fetchObject();
              $zen = ($check->Money * preco_pk);  
			  if($zen > 2000000000) {$zen = 2000000000;}
			  if($zen < $check->Money)
				{
				 $conexao->ExecuteNonQuery("UPDATE Character SET PkLevel=3, PkCount=0, PkTime=0,Money=Money-? WHERE Name=? and accountid=?",(int)$zen,$name,$this->login);               
				}
			  return '<center><div class="ok">[&loz;]Pk Retirado Com Sucesso.</div>';                
		}   
	 function alterar_classe($codigo,$class,$nome) 
	 {
		 global $conexao,$info_char,$items;
         
         
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
           if($items->verificar_items($nome) > 0)
            {
               return '<center><div class="error_q">[&loz;]Desequipe Todos os Itens Para Mudar de Classe.</div>';  
            } 
		   $conexao->ExecuteNonQuery("update character set class=? where name=? and accountid=?",(int)$class,$nome,$this->login); 
           
           if(ZERAR_QUEST_CLASSE == true)
                {
           $quest = str_repeat("F", TAMANHO_QUEST);                                                                                            
		   $conexao->ExecuteNonQuery("UPDATE CHARACTER SET MagicList=0x".$quest." WHERE NAME=? and accountid=?",$nome,$this->login);
		        }
                  
           if(ZERAR_MAGIA_CLASSE == true)
                {
           $magia = str_repeat("F", TAMANHO_MAGIA);                                                                                         
		   $conexao->ExecuteNonQuery("UPDATE CHARACTER SET MagicList=0x".$magia." WHERE NAME=? and accountid=?",$nome,$this->login);
		        } 
          
		   return '<center><div class="ok">[&loz;]Classe do Char '.$nome.' Alterado para '.$info_char->pegar_classe($class).' Com Sucesso.</div>';
	 }  
	function mover_char($codigo,$char,$mover,$x,$y)
		{
			global $conexao;
			global $info_char;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
			if(empty($x) || empty($y))
			{
			  return '<center><div class="error_q">[&loz;]Por Favor preencher todos os Campos.</div>';
			}
			$conexao->ExecuteNonQuery("update character set MapNumber=?,mapposx=?,mapposy=? where name=? and accountid=?",(int)$mover,(int)$x,(int)$y,$char,$this->login);
			 return '<center><div class="ok">[&loz;]Char '.$char.' Movido para '.$info_char->pegar_mapa($mover).' com Sucesso.</div>';							
		}	
	function master_reset($codigo,$name)
		{
			global $conexao;
			global $MASTER_R;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
          $vip = $conexao->ExecuteScalar("select ".vip_coluna." from MuOnline.dbo.".tabela_vip."  where ".vip_login."=?",$this->login);
		  if(VERSAO_MU == 0)
			{
			  $mr = $conexao->ExecuteReader("select cLevel,Strength,Dexterity,Vitality,Energy,".coluna_reset." as Reset from MuOnline.dbo.character where Name=? and accountid=?",$name,$this->login);        
			  $mr = $mr->fetchObject();
             
              
			 if($vip == 0)
			 {
				if($mr->cLevel < $MASTER_R["LVL"]["FREE"])
				    {
				    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["FREE"].'.</div>';
				    }		
			 elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
			     {
			         return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
			     }    
             elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                {
                    if($MASTER_R["TROCAR_RESET_POR_MR"]["FREE"] > $mr->Reset)
                        {
                            return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["FREE"].' Resets para Dar Master Reset.</div>';  
                        }
                    $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["FREE"],$name);    
                }
			 $conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],$name,$this->login);
			 $conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["FREE"],$this->login);
			  return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
			 }   
			 elseif($vip == 1)
				 {
					if($mr->cLevel < $MASTER_R["LVL"]["VIP1"])
					    {
						    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP1"].'.</div>';
					    }
					elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
					    {
						    return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					    }    
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"],$name);    
                        }    
						$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],$name,$this->login);
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP1"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				}  
			  elseif($vip == 2)
			  {
				if($mr->cLevel < $MASTER_R["LVL"]["VIP2"])
				    {
					    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["VIP2"].'.</div>';
				    }
				elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}    
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"],$name);    
                        }
					$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],$name,$this->login);
					$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP2"],$this->login);
					return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';  
			} 
			elseif($vip == 3)
			  {
				if($mr->cLevel < $MASTER_R["LVL"]["VIP3"])
				    {
					    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["VIP3"].'.</div>';
				    }
					elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}  
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"],$name);    
                        } 
					$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],$name,$this->login);
					$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP3"],$this->login);
					return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';   
			} 
			elseif($vip == 4)
			  {
				if($mr->cLevel < $MASTER_R["LVL"]["VIP4"])
				    {
					    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["VIP4"].'.</div>';
				    }
					elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					} 
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"],$name);    
                        }   
					$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],$name,$this->login);
					$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP4"],$this->login);
					return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';     
			} 
			elseif($vip == 5)
			  {
				if($mr->cLevel < $MASTER_R["LVL"]["VIP5"])
				    {
					    return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["VIP5"].'.</div>';
				    }
					elseif($mr->Strength < status_minimo_mr || $mr->Dexterity < status_minimo_mr || $mr->Vitality < status_minimo_mr || $mr->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}   
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"],$name);    
                        } 
				
					$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+'1',cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],$name,$this->login);
					$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP5"],$this->login);
					return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';     
			} 							
		} 
		elseif(VERSAO_MU == 1)
		{
				$mr2 = $conexao->ExecuteReader("select cLevel,Strength,Dexterity,Vitality,Energy,Leadership,Class from MuOnline.dbo.character where Name=? and AccountID=?",$name,$this->login);        
				$mr2 = $mr2->fetchObject();
                if($vip == 0)
					{
						if($mr2->cLevel < $MASTER_R["LVL"]["FREE"])
						   {
							  return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '.$MASTER_R["LVL"]["FREE"].'.</div>';
						   }
						elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
						   {
							  return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
						   }
                        elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }   
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["FREE"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["FREE"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["FREE"],$name);    
                        } 
							$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],(int)$MASTER_R["STATUS_RETORNO"]["FREE"],$name,$this->login);
                            if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["FREE"],$name,$this->login);
                                } 
							$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["FREE"],$this->login);
							return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
					}
				 elseif($vip == 1)
				 {
					if($mr2->cLevel < $MASTER_R["LVL"]["VIP1"])
					{
						return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP1"].'.</div>';
					}
					elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}  
                    elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }  
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP1"],$name);    
                        } 
					    $conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],$name,$this->login);
                        if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["VIP1"],$name,$this->login);
                                } 
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP1"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				 }
				 elseif($vip == 2)
				 {
					if($mr2->cLevel < $MASTER_R["LVL"]["VIP2"])
					{
						return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP2"].'.</div>';
					}
					elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					} 
                    elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP2"],$name);    
                        }  
						$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],$name,$this->login);
                        if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["VIP2"],$name,$this->login);
                                } 
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP2"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				 }
				 elseif($vip == 3)
				 {
					if($mr2->cLevel < $MASTER_R["LVL"]["VIP3"])
					{
						return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP3"].'.</div>';
					}
					elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}  
                    elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }  
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP3"],$name);    
                        } 
					    $conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],$name,$this->login);
                        if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["VIP3"],$name,$this->login);
                                }
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP3"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				 }
				 elseif($vip == 4)
				 {
					if($mr2->cLevel < $MASTER_R["LVL"]["VIP4"])
					{
						return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP4"].'.</div>';
					}
					elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					} 
                    elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP4"],$name);    
                        } 
						$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],$name,$this->login);
                        if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["VIP4"],$name,$this->login);
                                }
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP4"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				 }
				 elseif($vip == 5)
				 {
					if($mr2->cLevel < $MASTER_R["LVL"]["VIP5"])
					{
						return '<center><div class="error_q">[&loz;]Level Insuficiente para Master Reset, level m&iacute;nimo '. $MASTER_R["LVL"]["VIP5"].'.</div>';
					}
					elseif($mr2->Strength < status_minimo_mr || $mr2->Dexterity < status_minimo_mr || $mr2->Vitality < status_minimo_mr || $mr2->Energy < status_minimo_mr) 
					{
						return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
					}  
                    elseif($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65) 
                            {
                              return '<center><div class="error_q">[&loz;]Status Insuficiente Para Master Reset, Status m&iacute;nimo = '.status_minimo_mr.'.</div>';
                            }
                    elseif($MASTER_R["TROCAR_RESET_POR_MR"]["ATIVAR"] == TRUE)
                        {
                            if($MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"] > $mr->Reset)
                                {
                                    return '<center><div class="error_q">[&loz;]Necessario ter '.$MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"].' Resets para Dar Master Reset.</div>';  
                                }
                            $conexao->ExecuteNonQuery("update character set ".coluna_reset."=".coluna_reset."-? where name=?",(int)$MASTER_R["TROCAR_RESET_POR_MR"]["VIP5"],$name);    
                        } 
						$conexao->ExecuteNonQuery("update character set ".coluna_mr."=".coluna_mr."+1,cLevel=?,Strength=?,Dexterity=?,Vitality=?,Energy=? where name=? and AccountID=?",(int)$MASTER_R["LVL_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],$name,$this->login);
                        if($mr2->Leadership < status_minimo_mr && $mr2->Class == 64 || $mr2->Class == 65)
                                {
                                    $conexao->ExecuteNonQuery("update character set Leadership=? where name=? and accountid=?",(int)$MASTER_R["STATUS_RETORNO"]["VIP5"],$name,$this->login);
                                }
						$conexao->ExecuteNonQuery("update ".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$MASTER_R["GOLD_MR"]["VIP5"],$this->login);
						return '<center><div class="ok">[&loz;]Personagem '.$name.' deu Master Reset.</div>';
				 }
		 } 
	}	
	function distribuir_pontos($codigo,$char,$for,$agi,$viti,$ene,$cmd = 0)
		{
			 global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
            if($for < 0 || $agi < 0 || $viti < 0 || $ene < 0 || $cmd < 0)  
                {
                 return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>';
                } 
		   $a= $conexao->ExecuteReader("select Strength,Dexterity,Vitality,Energy,levelupPoint FROM MuOnline.dbo.character where name=? and accountid=?",$char,$this->login);
		   $a = $a->fetchObject();
           if(VERSAO_MU == 1)
		   {
			   $b = $conexao->ExecuteReader("select Leadership FROM MuOnline.dbo.character where name=? and accountid=?",$char,$this->login);
               $b = $b->fetchObject();
		   }
		  if($for+$agi+$viti+$ene+$cmd > $a->levelupPoint)
			{
			     return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem essa Quantidade de Pontos para Distribuir</div>';
			}
		  if($a->Strength+$for > max_pontos)
			{
			  return '<center><div class="error_q">[&loz;]For&ccedil;a n&atilde;o pode Passar de '.max_pontos.'.</div>';
			}
		   else
		   {
			$conexao->ExecuteNonQuery("update character set Strength=Strength+?,LevelupPoint=LevelupPoint-? where name=? and accountid=?",(int)$for,(int)$for,$char,$this->login);
			$ok++;                         
		   } 
		 if($a->Dexterity+$agi > max_pontos)
		 {
		   return '<center><div class="error_q">[&loz;]Agilidade n&atilde;o pode Passar de '.max_pontos.'.</div>';
		 }
		  else 
		  {
			$conexao->ExecuteNonQuery("update character set Dexterity=Dexterity+?,LevelupPoint=LevelupPoint-? where name=? and accountid=?",(int)$agi,(int)$agi,$char,$this->login);
			$ok++;
		  }
			if($a->Vitality+$viti > max_pontos)
				{
				  return '<center><div class="error_q">[&loz;]Vitalidade n&atilde;o pode Passar de '.max_pontos.'.</div>';
				}
		   else 
		   {
			 $conexao->ExecuteNonQuery("update character set Vitality=Vitality+?,LevelupPoint=LevelupPoint-? where name=? and accountid=?",(int)$viti,(int)$viti,$char,$this->login);
			 $ok++;
		   }
		   if($a->Energy+$ene > max_pontos)
			{
				 return '<center><div class="error_q">[&loz;]Energia n&atilde;o Passar de '.max_pontos.'.</div>';
			}
			else
			  {
				$conexao->ExecuteNonQuery("update character set Energy=Energy+?,LevelupPoint=LevelupPoint-? where name=? and accountid=?",(int)$ene,(int)$ene,$char,$this->login);
				$ok++;
			  }
				if(VERSAO_MU ==1)
					{
					if($b->Leadership+$cmd > max_pontos)
					  {
						return '<center><div class="error_q">[&loz;]Comando n&atilde;o pode Passar de '.max_pontos.'.</div>';
					  }
						else
						{
						  $conexao->ExecuteNonQuery("update character set Leadership=Leadership+?,LevelupPoint=LevelupPoint-? where name=? and accountid=?",(int)$cmd,(int)$cmd,$char,$this->login);
						  $ok++;
						}
					}																	  
				if($ok >= 1)
				{
				  header("Location: index.php?gne=painel/distri_p");
				}											  
		}
	function alterar_nick($codigo,$nome,$nick)
		{
         global $conexao;
		 if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		$checknome = $conexao->ExecuteReader("select Name FROM MuOnline.dbo.character where name=?",$nome);
			if(empty($nome))
				{
				  return '<center><div class="error_q">[&loz;]Campo Novo Nick Obrigat&oacute;rio.</div>';
				}
			if(strlen($nome) <3 )
				{
				    return '<center><div class="error_q">[&loz;]Campo Novo Nick deve ser Maior que três caracteres.</div>';
				}
			if($checknome->getRowCount() > 0)
				{
				    return '<center><div class="error_q">[&loz;]Nick '.$nome.' Ja Esta em Uso.</div>';
				}    
			elseif(eregi($nome,'webzen') || eregi($nome,'web_zen') || eregi($nome,'memb_info') || eregi($nome,'gm') || eregi($nome,'adm') || eregi($nome,'administrador') || eregi($nome,'admin') || eregi($nome,'gamemaster') || eregi($nome,'mm')
									|| eregi($nome,'webzen_') || eregi($nome,'_webzen_') || eregi($nome,'_webzen') || eregi($nome,'-webzen') ||eregi($nome,'-webzen-') || eregi($nome,'webzen-') || eregi($nome,'webzem') || eregi($nome,'web_zem') || eregi($nome,'[') || eregi($nome,']')
                                    || eregi($nome,'{') || eregi($nome,'}') || eregi($nome,'(') || eregi($nome,')') || eregi($nome,'-webzem')
                                    || eregi($nome,'gm-'))
				  {
									
				  return '<center><div class="error_q">[&loz;]Nick '.$nome.' foi probido Pelo Administrador.</div>';
				  }    
				  $conexao->ExecuteNonQuery("update character set name=? where name=? and accountid=?",$nome,$nick,$this->login);
				  $conexao->ExecuteNonQuery("update guild set G_master=? where G_master=?",$nome,$nick);
				  $conexao->ExecuteNonQuery("update guildMember set name=? where name=?",$nome,$nick);
                  
				  $s = $conexao->ExecuteReader("select GameID1,GameID2,GameID3,GameID4,GameID5,GameIDC FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);
				  $s = $s->fetchObject();
                  if($s->GameID1 == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameid1=? where gameid1=? and id=?",$nome,$nick,$this->login);
    				  }
				  if($s->GameID2 == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameid2=? where gameid2=? and id=?",$nome,$nick,$this->login);
    				  }
				  if($s->GameID3 == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameid3=? where gameid3=? and id=?",$nome,$nick,$this->login);
    				  }
				  if($s->GameID4 == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameid4=? where gameid4=? and id=?",$nome,$nick,$this->login);
    				  }
				  if($s->GameID5 == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameid5=? where gameid5=? and id=?",$nome,$nick,$this->login);
    				  }
				  if($s->GameIDC == $nick)
    				  {
    				    $conexao->ExecuteNonQuery("update accountcharacter set gameidc=? where gameidc=? and id=?",$nome,$nick,$this->login);
    				  }
							  if(REGISTRAR_LOGS == true)
							  {
							$fp = fopen("modules/logs/nick.gnee", "a");
							fwrite($fp, "\r\n==============================================================================\r\nNick Alterado.
							\r\nLogin: ".$this->login."\r\nNome Antigo: ".$nick."\r\nNome Novo: ".$nome."" );
							fclose($fp);
							
							   }   
							   return '<center><div class="ok">[&loz;]Nick '.$nick.' alterado para '.$nome.' Com Suceso.</div>';																		
			}
	function redistribuir_pontos ($codigo,$name)
		{
		 global $conexao;
		 if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			} 	
		 if(VERSAO_MU == 0)
			{
				$a = $conexao->ExecuteReader("select levelupPoint,Strength,Dexterity,Vitality,Energy,Class FROM MuOnline.dbo.character where name=? and accountid=?",$name,$this->login);
				$a = $a->fetchObject();
                $for = $a->Strength;
				$agi = $a->Dexterity;
				$vit = $a->Vitality;
				$ene = $a->Energy;
				$total =$for+$agi+$vit+$ene-80;
				$conexao->ExecuteNonQuery("update character set Strength=20,Dexterity=20,Vitality=20,Energy=20,levelupPoint=leveluppoint+? where name=? and accountid=?",(int)$total,$name,$this->login);
				return '<center><div class="ok">[&loz;]Foram Redistribuidos '.$total.' Pontos para o char '.$name.'.</div>';
			}    
			elseif(VERSAO_MU == 1)
				{
					$a = $conexao->ExecuteReader("select levelupPoint,Strength,Dexterity,Vitality,Energy,LeaderShip FROM MuOnline.dbo.character where name=? and accountid=?",$name,$this->login);
					$a = $a->fetchObject();
                    $for = $a->Strength;
    				$agi = $a->Dexterity;
    				$vit = $a->Vitality;
    				$ene = $a->Energy;
					$cmd = $a->LeaderShip;
					$total = $for+$agi+$vit+$ene-80;
                    if($a->Class == 64 || $a->Class == 65)
                        {
                            $total = $total+$cmd-20;
                            $conexao->ExecuteNonQuery("update character set Leadership=20 where name=? and accountid=?",$name,$this->login);
                        }
					$conexao->ExecuteNonQuery("update character set Strength=20,Dexterity=20,Vitality=20,Energy=20,levelupPoint=leveluppoint+? where name=? and accountid=?",(int)$total,$name,$this->login);
                    
					return '<center><div class="ok">[&loz;]Foram Redistribuidos '.$total.' Pontos para o char '.$name.'.</div>';
				}    
														
			
		}		
	function criar_char($codigo,$nome,$classe)
		{
		 global $conexao;
		 if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		  $check =  $conexao->ExecuteReader("select Name FROM MuOnline.dbo.character where Accountid=?",$this->login);
		  $check1 = $conexao->ExecuteReader("select Name FROM MuOnline.dbo.character where Name=?",$nome);
		  $check2 = $conexao->ExecuteScalar("select id FROM MuOnline.dbo.AccountCharacter where GameID1=?",$this->login);
		  $check3 = $conexao->ExecuteScalar("select GameID2 FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);
		  $check4 = $conexao->ExecuteScalar("select GameID3 FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);
		  $check5 = $conexao->ExecuteScalar("select GameID4 FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);
		  $check6 = $conexao->ExecuteScalar("select GameID5 FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);
		  $check7 = $conexao->ExecuteScalar("select GameIDC FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);  
		  $check8 = $conexao->ExecuteReader("select number FROM MuOnline.dbo.AccountCharacter where id=?",$this->login);   

        	if(empty($nome))
				{
				return '<center><div class="error_q">[&loz;]Campo Nome Necessario.</div>';
				}                                    
			if(strlen($nome) <3)
				{
				return '<center><div class="error_q">[&loz;]Nome deve ser Maior que 3 Digitos.</div>';
				}                                        
			if($check1->GetRowCount() > 0)
				{    
			     	return '<center><div class="error_q">[&loz;]Nick '.$nome.' j&aacute; est&aacute; em Uso.</div>';
				}
			if($check->GetRowCount() > 4)
			{
			 return '<center><div class="error_q">[&loz;]Voc&ecirc; j&aacute; atingiu o limite de Chars Criados.</div>';
			}
			if(eregi($nome,'webzen') || eregi($nome,'web_zen') || eregi($nome,'delete') || eregi($nome,'memb_info') || eregi($nome,'gm') || eregi($nome,'adm') || eregi($nome,'administrador') || eregi($nome,'admin') || eregi($nome,'gamemaster') || eregi($nome,'mm')
									|| eregi($nome,'webzen_') || eregi($nome,'_webzen_') || eregi($nome,'_webzen'))
				  {
									
				  return '<center><div class="error_q">[&loz;]Nick '.$nome.' foi probido Pelo Administrador.</div>';
				  }    
			$conexao->ExecuteNonQuery("insert into character (AccountID,name,clevel,leveluppoint,class,experience,Strength,Dexterity,Vitality,Energy,money,MapNumber,mapposx,mapposy,mapDir,pkcount,pklevel,pktime,ctlcode) values (?,?,'1','0',?,'0','20','20','20','20','0','0','125','125','0','3','0','0','0')",$this->login,$nome,$classe);
				if(VERSAO_MU == true)
					{
					  $conexao->ExecuteNonQuery("update character set Leadership=20 where name=? and accountid=?",$nome,$this->login);  
					}
				if($check8->GetRowCount() == 0 && $check2 == NULL)
					{
					  $conexao->ExecuteNonQuery("insert into AccountCharacter (id,GameID1,GameIDC) values('$this->login','$nome','$nome')");
					}
				elseif($check2 == NULL)
    				{
    					$conexao->ExecuteNonQuery("update AccountCharacter set GameID1=?  where id=?",$nome,$this->login);
    				}    
				elseif($check3 == NULL || $check3 == "NULL")
					{
					  $conexao->ExecuteNonQuery("update AccountCharacter set GameID2=?  where id=?",$nome,$this->login);
					}
				elseif($check4 == NULL || $check4 == "NULL")
					{
				 $conexao->ExecuteNonQuery("update AccountCharacter set GameID3=?  where id=?",$nome,$this->login);
					}
				elseif($check5 == NULL || $check5 == "NULL")
					{
					 $conexao->ExecuteNonQuery("update AccountCharacter set GameID4=?  where id=?",$nome,$this->login);
					}
				elseif($check6 ==  NULL || $check6 ==  "NULL")
					{
					  $conexao->ExecuteNonQuery("update AccountCharacter set GameID5=?  where id=?",$nome,$this->login);
					}
				elseif($check7 == NULL || $check7 == "NULL")
					{
					  $conexao->ExecuteNonQuery("update AccountCharacter set GameIDC=?  where id=",$nome,$this->login);
					}
				if(REGISTRAR_LOGS == true)
							{
						$fp = fopen("modules/logs/criar.gnee", "a");
						fwrite($fp, "\r\n==============================================================================\r\nChar Criado.
						\r\nLogin: ".$this->login."\r\nNome: ".$nome."\r\nClasse: ".$classe."" );
						fclose($fp);
							}
					  return '<center><div class="ok">[&loz;]Char '.$nome.' Criado Com sucesso.</div>';	 
		}		
	function enviar_foto($codigo,$char,$foto)
			{
				global $conexao;
				if($_SESSION["captcha_site"] != $codigo)
				  {
				 return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }	
				$pasta = lugar_foto;
				$permisao = array('image/jpg','image/jpeg','image/pjpeg','image/png','image/gif' );
				$type = $foto['type'];  
				$tmp = $foto['tmp_name'];
				$name = $foto['name'];				  
				$a = explode("/",$type);
				 if($a[1] == "jpg" || $a[1] == "jpeg" || $a[1] == "pjpeg" || $a[1] == "png")
				   {
					 $tipo = "jpg";   
				   }
				 elseif($a[1] == "gif")
				   {
				   $tipo = "gif";
				   }
				 if(!empty($name) && in_array($type,$permisao))
					{
					 $nome = md5(uniqid(rand(),true)).".".$tipo;
					 $antiga = $conexao->ExecuteScalar("select foto FROM MuOnline.dbo.character where name=? and accountid=?",$char,$this->login);
					  if($tipo == "jpg")
							{
						  if($antiga =! "sem_foto.jpg") 
    						  {
    					       	   unlink($pasta."/".$antiga);      
    						  }     
    					upload_jpg($tmp,$nome,100,100,$pasta);
							
							}          
					elseif($tipo == "gif")
						 {  
						   upload_gif($tmp,$nome,100,100,$pasta);  
						   if($antiga =! "sem_foto.jpg") 
    						   {
    						   unlink($pasta."/".$antiga);      
    						   } 
						 }	
				   $conexao->ExecuteNonQuery("update character set foto=? where name=? and accountid=?",$nome,$char,$this->login);
						 return '<center><div class="ok">[&loz;]Imagem Alterada com Sucesso.</div>';        
					}
				   else
					{
					   return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';
					}                                                    
												  
			}	
	function remover_foto($codigo,$nome)
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				  {
				 return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }  
			   $conexao->ExecuteNonQuery("update character set foto='sem_foto.jpg' where name=? and accountid=?",$nome,$this->login);         
			   return '<center><div class="ok">[&loz;]Foto do Char '.$nome.' Foi Removida.</div>'; 
			}
	function deletar_char($codigo,$nome1,$email,$id)
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				  {
				    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }
				if(empty($nome1) || empty($email) || empty($id))
    				{	
    			     	 return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>';
    				}   
				$checkchar  = $conexao->ExecuteReader("select AccountID FROM MuOnline.dbo.character where name=? and accountid=?",$nome1,$this->login); 
				$checkinfo  = $conexao->ExecuteReader("select memb__pwd FROM MuOnline.dbo.memb_info where mail_addr=? and sno__numb=? and memb___id=?",$email,(int)$id,$this->login);
				if($checkchar->GetRowCount() < 1)
					{
					 return '<center><div class="error_q">[&loz;]O Char '.$nome1.' n&atilde;o existe.</div>';
					}
				if($checkinfo->GetRowCount() < 1)
					  {
						return '<center><div class="error_q">[&loz;]E-mail ou Personal Id Incorreto.</div>';
					  }
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.character where name=? and accountid=?",$nome1,$this->login);
				$conexao->ExecuteNonQuery("update AccountCharacter set GAMEID1=NULL where GAMEID1=? and id=?",$nome1,$this->login);
				$conexao->ExecuteNonQuery("update AccountCharacter set GAMEID2=NULL where GAMEID2=? and id=?",$nome1,$this->login);
				$conexao->ExecuteNonQuery("update AccountCharacter set GAMEID3=NULL where GAMEID3=? and id=?",$nome1,$this->login);
				$conexao->ExecuteNonQuery("update AccountCharacter set GAMEID4=NULL where GAMEID4=? and id=?",$nome1,$this->login);
				$conexao->ExecuteNonQuery("update AccountCharacter set GAMEID5=NULL where GAMEID5=? and id=?",$nome1,$this->login);    
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.Guild where G_master=?",$nome1);        
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.GuildMember where Name=?",$nome1);    
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_banchar where Nome=?",$nome1);   
				if(REGISTRAR_LOGS == true)
						{
						$fp = fopen("modules/logs/deletar.gnee", "a");
						fwrite($fp, "\r\n==============================================================================\r\nChar Deletado.
						\r\nLogin: ".$this->login."\r\nNome: ".$nome1."\r\nE-mail: ".$email."" );
						fclose($fp);    
						}
				return '<center><div class="ok">[&loz;]O Personagem '.$nome1.' Foi Deletado com Sucesso.</div>';               
			}	
	function limpar_inventorio($codigo,$nome)
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				  {
				 return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }
			  $f = str_repeat("F", TAMANHO_INV*2);
			  $conexao->ExecuteNonQuery("UPDATE CHARACTER SET INVENTORY=0x".$f." WHERE NAME=? and accountid=?",$nome,$this->login);
			  return '<center><div class="ok">[&loz;]Invet&aacute;rio do Char '.$nome.' foi Limpo com Sucesso.</div>';						
			}							
	function visualizar_inventorio($codigo,$char)
			{
				global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				  {
					 return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }
				  $check = $conexao->ExecuteReader("select AccountID FROM MuOnline.dbo.character where name=? and accountid=?",$char,$this->login);
				if($check->GetRowCount() < 1)
					{
					   return '<center><div class="error_q">[&loz;]Personagem '.$char.' N&atilde;o Encontrado.</div>';    
					}
				setcookie('char_inventorio_view',$char, time()+1);	
				header("Location: ?gne=painel/vizu_inv");			
			}					
	function resetar($codigo,$char)
			{
			  global $conexao;
              global $RESET;
			  if($_SESSION["captcha_site"] != $codigo)
				  {
				    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				  }
				$lvl = $conexao->ExecuteScalar("select cLevel FROM MuOnline.dbo.character where name=? and AccountID=?",$char,$this->login);
				$vip = $conexao->ExecuteScalar("select ".vip_coluna." FROM MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$this->login);
				if(tipo_reset == 1)
				  {
				   if($vip == 0)
					{
					  if($lvl < $RESET["LVL"]["FREE"])
					   {
					       	return '<center><div class="error_q">[&loz;]Necess&aacute;rio Estar no level '.$RESET["LVL"]["FREE"].' Para Reset.</div></center>';
					   }
						$conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["FREE"],(int)$RESET["RESETS_GANHOS"]["FREE"],(int)$RESET["CIDADE_VOLTA"]["FREE_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSX"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSY"],$char,$this->login);
						return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div></center>';
					}
					if($vip == 1)
						{
						  if($lvl < $RESET["LVL"]["VIP1"])
							{
							 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP1"].' Para Reset.</div>';
							}
							$conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP1"],(int)$RESET["RESETS_GANHOS"]["VIP1"],$RESET["CIDADE_VOLTA"]["VIP1_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSY"],$char,$this->login);
							return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
						}
					if($vip == 2)
						{
						  if($lvl < $RESET["LVL"]["VIP2"])
							{
							 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP2"].' Para Reset.</div></center<';
							}    
                                $conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP2"],(int)$RESET["RESETS_GANHOS"]["VIP2"],$RESET["CIDADE_VOLTA"]["VIP2_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSY"],$char,$this->login);    
								return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div></center>';
						}
					if($vip == 3)
						{
						  if($lvl < $RESET["LVL"]["VIP3"])
							{
							 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP3"].' Para Reset.</div></center<';
							}    
								$conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP3"],(int)$RESET["RESETS_GANHOS"]["VIP3"],$RESET["CIDADE_VOLTA"]["VIP3_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSY"],$char,$this->login);    
								return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div></center>';
						}
					if($vip == 4)
						{
						  if($lvl < $RESET["LVL"]["VIP4"])
							{
							 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP3"].' Para Reset.</div></center<';
							}    
								$conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP4"],(int)$RESET["RESETS_GANHOS"]["VIP4"],$RESET["CIDADE_VOLTA"]["VIP4_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSY"],$char,$this->login);    
								return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div></center>';
						}
					if($vip == 5)
						{
						  if($lvl < $RESET["LVL"]["VIP5"])
							{
							 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP5"].' Para Reset.</div></center<';
							}    
								$conexao->ExecuteNonQuery("update character set cLevel=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP5"],(int)$RESET["RESETS_GANHOS"]["VIP5"],$RESET["CIDADE_VOLTA"]["VIP5_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSY"],$char,$this->login);    
								return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div></center>';
						}
			  }          
					 if(tipo_reset == 2)
						{
						 if($vip == 0)
							{
							 if($lvl < $RESET["LVL"]["FREE"])
							   {
								 return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["FREE"].' Para Reset.</div>';
							   }                                                                                                                                                                                                                                                                 
								if(VERSAO_MU == 1)
    								{
    								    $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["FREE"],(int)$RESET["PONTOS_RESET"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["RESETS_GANHOS"]["FREE"],(int)$RESET["CIDADE_VOLTA"]["FREE_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSX"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSY"],$char,$this->login);
    								}
								else
    								{    
    							     	 $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["FREE"],(int)$RESET["PONTOS_RESET"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["STATUS_VOLTA"]["FREE"],(int)$RESET["RESETS_GANHOS"]["FREE"],(int)$RESET["CIDADE_VOLTA"]["FREE_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSX"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSY"],$char,$this->login);
    								}
							 return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
							}
						 if($vip == 1)
							{
							 if($lvl < $RESET["LVL"]["VIP1"])
								{
								    return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP1"].' Para Reset.</div>';
								}
								if(VERSAO_MU == 1)
									{
									   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP1"],(int)$RESET["PONTOS_RESET"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["RESETS_GANHOS"]["VIP1"],$RESET["CIDADE_VOLTA"]["FREE_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSX"],(int)$RESET["CIDADE_VOLTA"]["FREE_POSY"],$RESET["CIDADE_VOLTA"]["VIP1_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSY"],$char,$this->login);
                                    }                             
								else
    								{     
    								   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP1"],(int)$RESET["PONTOS_RESET"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["STATUS_VOLTA"]["VIP1"],(int)$RESET["RESETS_GANHOS"]["VIP1"],$RESET["CIDADE_VOLTA"]["VIP1_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP1_POSY"],$char,$this->login);
    								} 
									return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
							}
						if($vip == 2)
						   {
							if($lvl < $RESET["LVL"]["VIP2"])
								{
								    return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP2"].' Para Reset.</div>';
								}    
							if(VERSAO_MU == 1)
									{
									   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP2"],(int)$RESET["PONTOS_RESET"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["RESETS_GANHOS"]["VIP2"],$RESET["CIDADE_VOLTA"]["VIP2_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSY"],$char,$this->login);
                                    }                             
								else
    								{     
    								   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP2"],(int)$RESET["PONTOS_RESET"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["STATUS_VOLTA"]["VIP2"],(int)$RESET["RESETS_GANHOS"]["VIP2"],$RESET["CIDADE_VOLTA"]["VIP2_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP2_POSY"],$char,$this->login);
    								}
									return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
						   }            
						if($vip == 3)
						   {
							if($lvl < $RESET["LVL"]["VIP3"])
								{
								return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP3"].' Para Reset.</div>';
								}    
							if(VERSAO_MU == 1)
									{
									   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP3"],(int)$RESET["PONTOS_RESET"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["RESETS_GANHOS"]["VIP3"],$RESET["CIDADE_VOLTA"]["VIP3_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSY"],$char,$this->login);
                                    }                             
								else
    								{     
    								   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP3"],(int)$RESET["PONTOS_RESET"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["STATUS_VOLTA"]["VIP3"],(int)$RESET["RESETS_GANHOS"]["VIP3"],$RESET["CIDADE_VOLTA"]["VIP3_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP3_POSY"],$char,$this->login);
    								}
									return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
						   }
						 if($vip == 4)
						   {
							if($lvl < $RESET["LVL"]["VIP4"])
								{
								return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP4"].' Para Reset.</div>';
								}    
							if(VERSAO_MU == 1)
									{
									   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP4"],(int)$RESET["PONTOS_RESET"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["RESETS_GANHOS"]["VIP4"],$RESET["CIDADE_VOLTA"]["VIP4_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSY"],$char,$this->login);
                                    }                             
								else
    								{     
    								   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP4"],(int)$RESET["PONTOS_RESET"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["STATUS_VOLTA"]["VIP4"],(int)$RESET["RESETS_GANHOS"]["VIP4"],$RESET["CIDADE_VOLTA"]["VIP4_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP4_POSY"],$char,$this->login);
    								}
									return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
						   }
						 if($vip == 5)
						   {
							if($lvl < $RESET["LVL"]["VIP5"])
								{
								return '<center><div class="error_q">[&loz;]Necessario Estar no level '.$RESET["LVL"]["VIP5"].' Para Reset.</div>';
								}    
							if(VERSAO_MU == 1)
									{
									   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Leadership=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP5"],(int)$RESET["PONTOS_RESET"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["RESETS_GANHOS"]["VIP5"],$RESET["CIDADE_VOLTA"]["VIP5_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSY"],$char,$this->login);
                                    }                             
								else
    								{     
    								   $conexao->ExecuteNonQuery("update character set cLevel=?,experience=0,leveluppoint=leveluppoint+?,Strength=?,Dexterity=?,Vitality=?,Energy=?,".coluna_reset."=".coluna_reset."+?,MapNumber=?,MapPosX=?,MapPosY=? where name=? and AccountID=?",(int)$RESET["LVL_VOLTA"]["VIP5"],(int)$RESET["PONTOS_RESET"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["STATUS_VOLTA"]["VIP5"],(int)$RESET["RESETS_GANHOS"]["VIP5"],$RESET["CIDADE_VOLTA"]["VIP5_CIDADE"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSX"],(int)$RESET["CIDADE_VOLTA"]["VIP5_POSY"],$char,$this->login);
    								}
									return '<center><div class="ok">[&loz;]Character '.$char.' Resetado Com Sucesso.</div>';
						   }    			
						}				  
			}										
	function limpar_quest($codigo,$nome)
		{
			
		  global $conexao;
		  if($_SESSION["captcha_site"] != $codigo)
			{
			  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		   $f = str_repeat("F", TAMANHO_QUEST);                                                                                            
		   $conexao->ExecuteNonQuery("UPDATE CHARACTER SET MagicList=0x".$f." WHERE NAME=? and accountid=?",$nome,$this->login);
		   return '<center><div class="ok">Quest(s) do Char do Char '.$nome.' foram Limpas com Sucesso.</div>';   
		}

}                  
?>                                    
								
								
								
											
								
								
								
								