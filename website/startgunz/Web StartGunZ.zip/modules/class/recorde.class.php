<?php

if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}

class recorde
{
		function rec()
		{
		   global $conexao;
		   
		   $open = fopen("modules/logs/record.gnee", "a+");
		   $qtd = fread($open, 1000);
		   
		   $arquivo = explode("-", $qtd);
		   $contador = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_stat where ConnectStat='1'");
		   if($contador > $arquivo[0])
		   {
			$escrever = fopen("modules/logs/record.gnee", "w");
			fwrite($escrever,$contador."-".@date("d/m/Y, H:m:i"));
			fclose($escrever);
		   }
		 return $arquivo[0]."-".$arquivo[1];   
		} 
}

?>