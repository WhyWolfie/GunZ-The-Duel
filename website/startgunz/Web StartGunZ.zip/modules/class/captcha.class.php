<?php
    session_start();
    
	function calculateTextBox($text,$fontFile,$fontSize,$fontAngle) 
	{
		$rect = imagettfbbox($fontSize,$fontAngle,$fontFile,$text);
		$minX = min(array($rect[0],$rect[2],$rect[4],$rect[6]));
		$maxX = max(array($rect[0],$rect[2],$rect[4],$rect[6]));
		$minY = min(array($rect[1],$rect[3],$rect[5],$rect[7]));
		$maxY = max(array($rect[1],$rect[3],$rect[5],$rect[7]));

		return array(
		 "left"   => abs($minX) - 1,
		 "top"    => abs($minY) - 1,
		 "width"  => $maxX - $minX,
		 "height" => $maxY - $minY,
		 "box"    => $rect
		);
	} 
	
	header("Content-type: image/png"); 
	function captcha($largura,$altura,$tamanho_fonte,$quantidade_letras)
	{
		$fonte = "arial.ttf"; 
		$imagem = imagecreate($largura, $altura); 
		$preto  = imagecolorallocate($imagem,0,0,0); 
		$branco = imagecolorallocate($imagem,255,255,255); 
		
		$colors = array();
		for($i = 0; $i < 8; $i++)
		{
			$colors[] = imagecolorallocate($imagem, mt_rand(160, 200), mt_rand(160, 200), mt_rand(160, 200));
		}

		imagefilledrectangle($imagem, 0, 0, $largura, $altura, $preto);

		$palavra = substr(str_shuffle(strtoupper("ABCDEFGHJKMNPQRSTUVXYZ123456789")),0,($quantidade_letras));
		$_SESSION["captcha_site"] = $palavra;
		
		$left = $tamanho_fonte;
		for($i = 1; $i <= $quantidade_letras; $i++)
		{
			$angle = rand(-10, 10);
			$size = calculateTextBox($palavra{$i-1}, $fonte, $tamanho_fonte, $angle);
			imagettftext($imagem, $tamanho_fonte, $angle, $left, $tamanho_fonte + ($altura - $size["height"]) / 2, $colors[rand() % sizeof($colors)], $fonte,                 $palavra{$i-1}); 
			$left += $size["width"] + 4; 
		}
		
		imagepng($imagem); 
		imagedestroy($imagem); 	
		
	}  
	captcha(100,30,11,5); 
