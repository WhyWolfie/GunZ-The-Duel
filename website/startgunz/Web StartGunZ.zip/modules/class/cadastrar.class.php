<?php

class cadastrar extends funcao
{
	function registrar($senha,$senha2,$email,$email2,$nome,$id,$id2,$perg,$resp,$codigo,$bonus,$indicado,$login)
		{
			global $conexao;
			global $items;
			global $items_bonus;
			global $QTD_EMAILS;
			global $info_char;
			$ip = $_SERVER['REMOTE_ADDR'];
			$date = @date( "d/m/Y, H:i:s" );
			$b = explode(",",$bonus);
			(int)$b[0];
			(int)$b[1];         
			(int)$erro=0;       
			$logincheck = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$login);
			
			if(SPAM_CADASTRO_IP == true)
			   {
					$checkandoissoaki = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_info where ip=?",$ip);
					if($checkandoissoaki > 0)
						{
						   $erro++;
						}
				}
			if(empty($login) || empty($perg) || empty($codigo) || empty($resp)|| empty($senha) || empty($senha2) || empty($email) || empty($email2) || empty($nome))
				{
				   return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Todos os Campos S&atilde;o Obrigat&oacute;rios\'); });</script>');
				}
             elseif(preg_match("/^[0-9a-zA-Z_]{4,10}$/",$login) == false || preg_match("/^[0-9a-zA-Z_]{4,10}$/",$senha) == false)
                {
                   return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'<b>Login</b> e <b>Senha</b> So Podem Conter Caracteres Alphanumericos <b>(0-9 a-z A-Z)</b>\'); });</script>'); 
                }    
			elseif($_SESSION["captcha_site"] != $codigo)
				{ 
					return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'C&ograve;digo de Seguran&ccedil;a Incorreto\'); });</script>');
				} 
			elseif(strlen($login) < 3 || strlen($senha) < 3 || strlen($nome) < 3)
				 {
					 return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'<h3> - O Campo Login Deve ser maior doque 4 Characteres.
					 <br /> - O Campo Senha Deve ser maior doque 4 Characteres
					 <br /> - O Campo Nome Deve ser maior doque 4 Characteres</h3>\'); });</script>'); 
				 }    
			elseif($senha <> $senha2)
				  {
						return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'As senhas n&atilde;o correspondem.\'); });</script>');
				  }	    
			elseif(filter_var($email,FILTER_VALIDATE_EMAIL) == FALSE)
				  {
					  return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Por Favor Informar um E-mail V&aacute;lido.\'); });</script>');
				  }  
			elseif($email <> $email2)
				  {
					  return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Os E-mails n&atilde;o correspondem.\'); });</script>');
				  }     
			 elseif($logincheck > 0 )
				   {
					   return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Login: <strong>'.$login.'</strong> J&aacute; Cadastrado.\'); });</script>');
				   }
			 elseif($QTD_EMAILS["ATIVO"] == true)
				{
					$num_email = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_info where mail_addr='".$email."'");
					if($num_email >= $QTD_EMAILS["QTD"])
						{
							return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Limite de Contas por E-mail Atingido\'); });</script>');
						}
				}  
             elseif(PERSOLNAL_ID == true)
                {
                    if($id != $id2)
                        {
                           return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'Os Ids n&atilde;o Correspondem.\'); });</script>');
                        }
                    elseif(strlen($id) < 7)
                        {
                            return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'O Personal Id, deve Ser Igual a 7.\'); });</script>'); 
                        }    
                    elseif(preg_match("/^[0-9]{7}$/",$id) == false)
                        {
                           return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'<b>Personal ID</b> Numericos <b>(0-9)</b>\'); });</script>'); 
                        }    
                        
                }             
			  (MINUSCULO_PALAVRA == true) ? $login = strtolower($login) : $login;      
			  (CONFIRMAR_CADASTRO == true) ? $bloc_code = 1 : $bloc_code = 0;
			 $add = $conexao->ExecuteNonQuery("insert into MuOnline.dbo.memb_info (memb___id,memb__pwd,memb_name,sno__numb,post_code,addr_info,addr_deta,tel__numb,phon_numb,mail_addr,bloc_code,ctl1_code,fpas_ques,fpas_answ,ip) 
             values (?,?,?,?,'0','0','0','0','0',?,?,'0',?,?,?)",$login,$senha,$nome,(int)$id,$email,$bloc_code,$perg,$resp,$ip);
			if (INDICACAO_NOVA_ACC == true ) 
				  {
				     $conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set indicado=? where memb___id=?",$indicado,$login);
				  }
			($bloc_code == 1) ? $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_banacc (login,motivo,dias,quem) values (?,'Ativa&ccedil;&atilde;o da Conta Pendente','999','Site')",$login): 0;        	
			if(bonus_cadastro_vip == true) 
			   {
    				$check = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$login);
    				if($check == 0 )
    					{
    					  $add2 = $conexao->ExecuteNonQuery("insert into MuOnline.dbo.".tabela_vip." (".vip_coluna.",".data_vip.") values('".tipo_vip."','".dias_vip."'");
    					}
    				else 
    				   {
    					$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."='".tipo_vip."',".data_vip."='".dias_vip."' where ".vip_login."=?",$login);
    				   }
			   }        
			 if(bonus_cadastro_gold == true) 
				{
				 $check_gold = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.".tabela_gold." where ".gold_login."=?",$login);
				if($check_gold == 0)
				  {
				   $add3 = $conexao->ExecuteNonQuery("insert into MuOnline.dbo.".tabela_gold." (".gold_login.",".gold_coluna.") values (?,".qtd_gold.")",$login);
				  }   
				else
				  {
				   $conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."='".qtd_gold."' where ".gold_login."=?",$login);
				  }                           
				}
				if(VIR_CUR == TRUE)
				   {
					$add4 = $conexao->ExecuteNonQuery("insert into MuOnline.dbo.vi_curr_info (ends_days,chek_code,used_time,memb___id,memb_name,memb_guid,sno__numb,bill_section,bill_value,bill_hour,surplus_point,surplus_minute,increase_days) values ('1900','1',1234,?,?,1,'7','6','3','6','6','1989-11-23','0')",$login,$nome);
				   }
			$conexao->ExecuteNonQuery( "insert into MuOnline.dbo.warehouse (AccountID,items,Money,EndUseDate,DbVersion,pw) values (?, convert(varbinary(".TAMANHO_BAU."), replicate(0xFF, ".TAMANHO_BAU.")), 0, getdate(), 2 , 0)",$login);
			
			if(SPAM_CADASTRO == true)
				{
				if(isset($_COOKIE['cadstro_ativo_bonus']) || isset($_SESSION['cadstro_ativo_bonus']))
					{
		              $erro++;	
					}
				else
				{
				$_SESSION['cadstro_ativo_bonus'] = $login;    
				setcookie('cadstro_ativo_bonus',$login,time()+(3600*365)); 
				}        
				}   
			if(ITEM_CADASTRO == true && $erro == 0)
				{
					(VERSAO_MU == 0) ? $tamanho_bau = 120 : $tamanho_bau = 192;
                    (VERSAO_MU == 1) ? $tama_espa = 32 : $tama_espa = 20;
                    $espaco = str_repeat("F", $tama_espa);
                    $linha = str_repeat("F", 8 * $tama_espa);
                    $espaco2 = str_repeat("F", ($tama_espa/2)); 
				    switch($b[0])
								{
									case 0:
										{
											
											$helm = $items->serial_alterar($items_bonus[0][$b[1]][4]);
											$armor = $items->serial_alterar($items_bonus[0][$b[1]][1]);
											$pants = $items->serial_alterar($items_bonus[0][$b[1]][5]);
											$gloves = $items->serial_alterar($items_bonus[0][$b[1]][3]);
											$bots = $items->serial_alterar($items_bonus[0][$b[1]][2]);      
											$items = $helm.$espaco.$pants.$espaco.$gloves.$espaco.$bots.$espaco
										.$linha.$armor;
											$items = str_pad($items, $tamanho_bau * $tama_espa, "F", STR_PAD_RIGHT); 
											$items = "0x" . $items;
										}
										break;
									case 1:
										{
											$all = $items->serial_alterar($items_bonus[1][$b[1]][1]);
											$items = $all.$espaco.$espaco.$espaco.$espaco;
											$items = str_pad($items, $tamanho_bau * $tama_espa, "F", STR_PAD_RIGHT);
											$items = "0x" . $items;
										}
										break;
									case 2:
										{
										$ring = $items->serial_alterar($items_bonus[2][$b[1]][1]);
										$ring2 = $items->serial_alterar($items_bonus[2][$b[1]][2]);
										$pendant = $items->serial_alterar($items_bonus[2][$b[1]][2]);
										$items = $ring.$espaco.$ring.$espaco.$pendant.$espaco.$espaco;
										$items = str_pad($items, $tamanho_bau * $tama_espa, "F", STR_PAD_RIGHT);
										$items = "0x" . $items;
										}
										break;
									case 3:
										{
										$helm = $items->serial_alterar($items_bonus[3][$b[1]][4]);
										$armor = $items->serial_alterar($items_bonus[3][$b[1]][1]);
										$boots = $items->serial_alterar($items_bonus[3][$b[1]][2]);
										$gloves = $items->serial_alterar($items_bonus[3][$b[1]][3]);
										$pants = $items->serial_alterar($items_bonus[3][$b[1]][5]);
										$ring1 = $items->serial_alterar($items_bonus[3][$b[1]][6]);
										$ring2 = $items->serial_alterar($items_bonus[3][$b[1]][7]);
										$pendant = $items->serial_alterar($items_bonus[3][$b[1]][8]);
										$asa = $items->serial_alterar($items_bonus[3][$b[1]][9]);
										$items = $helm.$espaco.$pants.$espaco.$gloves.$espaco.$boots.$espaco
										.$linha.$armor.$espaco.$ring1.$espaco1.$ring2.$espaco1.$pendant.$espaco1.$asa;
										$items = str_pad($items, $tamanho_bau * $tama_espa, "F",STR_PAD_RIGHT);
										$items = "0x".$items;
										}    
								}
							
							$conexao->ExecuteNonQuery("update MuOnline.dbo.warehouse set items=".$items.",DbVersion = 1 where AccountID=?",$login); 
							} 
		
				if(CONFIRMAR_CADASTRO == true)
					{
						$host = $_SERVER["HTTP_HOST"];
						$s = $_SERVER["SCRIPT_NAME"];
						$link_ativ = rand(0,10000);
						$link_ativ .= rand(0,10000);
						$host = "http://".$host.$s."?gne=conf_cadastro&login=".$login."&link_ativ=".$link_ativ;
						sendMailCadastro($login,$host,$email);
						$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set link_ativacao=? where memb___id=?",$link_ativ,$login);
						
					}
				if(REGISTRAR_LOGS == true)
						{
						$fp = fopen("modules/logs/cadastro.gnee", "a");
		fwrite($fp, "\r\n==============================================================================\r\nO ip ".$ip." se cadastro com os seguintes dados.\r\n\r\nnLogin: ".$login."\r\nE-mail: ".$email."\r\nNome: ".$nome."\r\nRegistrado em: ".$date."\r\nPergunta secreta: ".$perg."\r\nResposta secreta: ".$resp."\r\nPremio: ".$items_bonus[$b[1]][$b[2]][0]."" );
		fclose($fp);
					   }
					  
				(CONFIRMAR_CADASTRO == true) ? $msg = "Caso você deseje receber ".dias_vip." dias ".$info_char->pegar_vip(tipo_vip)." inteiramente grátis, basta você confirmar seu cadastro no e-mail."  : $msg = "" ;
				return utf8_decode('<script language="javascript">jQuery(function() { mensagem_info(\'<h2><center>Cadastro Realizado Com Sucesso</center></h2><br /><br /><strong>Login:</strong> '.$login.'<br /><strong>Senha:</strong> ******<br /><strong>Personal ID:</strong> '.$id.'<br /><strong>E-mail:</strong> '.$email.'<br /><br /><br />'.$msg.'</h2>\'); });</script>');	
				unset($senha,$senha2,$email,$email2,$nome,$id,$id2,$perg,$resp,$codigo,$bonus,$indicado,$login);   	
							 
		}
		
	function confirmar_cadastro($login,$ativ,$codigo)
		{
			 global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{ 
					return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'C&ograve;digo de Seguran&ccedil;a Incorreto\'); });</script>');
				}
			$checando = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_info where memb___id=? and link_ativacao=?",$login,$ativ);
			if($checando < 1)
				{
					return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'C&ograve;digo de  Ativa&ccedil;&atilde;o Incorreto\'); });</script>');
				}
			$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set bloc_code=0,link_ativacao=0 where memb___id=? and link_ativacao=?",$login,$ativ);
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_banacc where login=?",$login);
			 
					echo "<script>setTimeout(\"abrir_pagina('?')\",2000);</script>";
					return '<div class="ok">[&loz;]Conta Ativada Com Sucesso, voc&ecirc; Sera Redirecionado para a P&aacute;gina Principal.</center>';   
					
				 
		}

}



?>			

							
		