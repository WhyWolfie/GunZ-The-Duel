<?php

    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */
    
    require_once(pathinfo(__FILE__, PATHINFO_DIRNAME) . "\\Argument.php");
    require_once(pathinfo(__FILE__, PATHINFO_DIRNAME) . "\\ISettings.php");
    require_once(pathinfo(__FILE__, PATHINFO_DIRNAME) . "\\IRecordset.php");
    require_once(pathinfo(__FILE__, PATHINFO_DIRNAME) . "\\IDatabase.php");

    /**
    * Classe principal da API, usada para cria��o das conex�es
    */
    class DatabaseFactory
    {
        
        /// Lista de drivers dispon�veis
        protected static $Drivers = array();
        
        /// Se o factory foi carregado ou n�o
        protected static $Loaded = false;  
        
        /// Se sistema est� soltando exceptions
        protected static $ThrowExceptions = false;  
        
        /**
        * Fun��o utilizada para despachar exceptions
        * 
        * @param mixed $message
        */
        public static function ThrowException($message)
        {
            DatabaseFactory::WriteLog($message, "Exceptions");
            if(DatabaseFactory::$ThrowExceptions == true)
            {
                throw new Exception($message);
            }
        }
        
        /**
        * Inicializa a engine do banco de dados
        * 
        * @param mixed $exceptions
        * @return boolean
        */
        public static function Initialize($exceptions = false)
        {
            
            DatabaseFactory::$ThrowExceptions = $exceptions;
                        
            $drvs = array();  
            $basedir = pathinfo(__FILE__, PATHINFO_DIRNAME) . "\\Drivers\\";
            
            /*
            Aqui basicamente vou listar todas as pasta dentro da pasta Drivers, 
            que ser�o os nossos nomes dos drivers dispon�veis...
            */
            if (is_dir($basedir)) 
            {
                if ($dir = opendir($basedir)) 
                {
                    while (($file = readdir($dir)) !== false) 
                    {
                        if($file != "." && $file != "..")
                        {
                            if(is_dir($basedir . $file) == true)
                            {
                                $drvs[] = $file;
                            }
                        }
                    }
                    closedir($dir);
                }
            }
            
            /*
            Se nenhum driver estiver instalado, gerar um erro
            */
            if(sizeof($drvs) == 0)
            {
                DatabaseFactory::ThrowException("Nenhum driver existente para inicializa��o");
                return false;
            }              
            
            /*
            verifica se todos os drivers est�o devidamente instalados e programados
            */
            foreach($drvs as $driver_key => $driver)
            {
                
                if(
                    file_exists($basedir . $driver . "\\Database.php") &&
                    file_exists($basedir . $driver . "\\Recordset.php") &&
                    file_exists($basedir . $driver . "\\Settings.php")
                  )
                {
                    
                    @require_once($basedir . $driver . "\\Database.php");
                    @require_once($basedir . $driver . "\\Recordset.php");
                    @require_once($basedir . $driver . "\\Settings.php");
                    
                    if(!class_exists($driver . "Database")) 
                    {
                        DatabaseFactory::ThrowException("Classe '" . $driver . "Database' est� faltando no driver '" . $driver . "' driver.");
                        continue;
                    }
                    else
                    {
                        if(!is_subclass_of($driver . "Database", "IDatabase"))
                        {
                            DatabaseFactory::ThrowException("Classe '" . $driver . "Database' do driver '" . $driver . "' n�o � uma subclasse de 'IDatabase'");
                            continue;
                        }
                    }
                    
                    if(!class_exists($driver . "Recordset")) 
                    {
                        DatabaseFactory::ThrowException("Classe '" . $driver . "Recordset' est� faltando no driver '" . $driver . "'.");
                        continue;
                    }
                    else
                    {
                        if(!is_subclass_of($driver . "Recordset", "IRecordset"))
                        {
                            DatabaseFactory::ThrowException("Classe '" . $driver . "Recordset' do driver '" . $driver . "' n�o � uma subclasse de 'IRecordset'");
                            continue;
                        }
                    }
                    
                    if(!class_exists($driver . "Settings")) 
                    {
                        DatabaseFactory::ThrowException("Classe '" . $driver . "Settings' est� faltando no driver '" . $driver . "'.");
                        continue;
                    }
                    else
                    {
                        if(!is_subclass_of($driver . "Settings", "ISettings"))
                        {
                            DatabaseFactory::ThrowException("Classe '" . $driver . "Settings' do driver '" . $driver . "' n�o � uma subclasse de 'ISettings'");
                            continue;
                        }
                    }
                    
                    DatabaseFactory::$Drivers[] = $driver;
                    
                }
                else
                {
                    DatabaseFactory::ThrowException("O driver '" . $driver . "' est� com arquivos faltando.");
                    continue;
                }
                
            }
            
            DatabaseFactory::$Loaded = true;
            return true;
            
        }
        
        /**
        * Verifica se o Factory foi inicializado
        * 
        * @return boolean
        */
        public static function IsInitialized()
        {
            return DatabaseFactory::$Loaded;
        }
        
        /**
        * Verifica se um driver existe
        * 
        * @param mixed $name
        * @return boolean
        */
        public static function DriverExists($name)
        {
            if(!DatabaseFactory::IsInitialized())
            {
                DatabaseFactory::ThrowException("DatabaseFactory n�o foi inicializado!");
                return false;
            }
            if(array_search($name, DatabaseFactory::$Drivers) === false)
            {
                return false;
            }
            return true;
        }
        
        /**
        * Retorna a lista de drivers dispon�veis
        * 
        * @return array
        */
        public static function AvailableDrivers()
        {
            if(!DatabaseFactory::IsInitialized())
            {
                DatabaseFactory::ThrowException("DatabaseFactory n�o foi inicializado!");
                return false;
            }
            return DatabaseFactory::$Drivers;               
        }
        
        /**
        * Cria uma conex�o com o banco de dados
        * 
        * @param mixed $driver
        * @param mixed $settings
        * @return IDatabase
        */
        public static function CreateConnection($settings)
        {
            
            if(DatabaseFactory::DriverExists($settings->GetDriverName()) == false)
            {
                DatabaseFactory::ThrowException("O driver '" . $settings->GetDriverName() . "' requisitado n�o existe.");
                return false;
            }           
             
            $class = $settings->GetDriverName() . "Database"; 
            $obj = new $class($settings);
            
            return $obj;
            
        }
        
        /**
        * Cria um objeto de configura��o
        * 
        * @param mixed $driver
        * @param mixed $settings
        * @return ISettings
        */
        public static function CreateSettings($driver)
        {
            
            if(DatabaseFactory::DriverExists($driver) == false)
            {
                DatabaseFactory::ThrowException("O driver '" . $driver . "' requisitado n�o existe.");
                return false;
            }           
            
            $class = $driver . "Settings"; 
            $obj = new $class;
            
            $obj->SetDriverName($driver);
            
            return $obj;
            
        }   
        
        public static function WriteLog ( $string , $file = "Log", $path = "./Logs")
        {
            @file_put_contents ( $path . "/" . $file . ".txt", $string . "\r\n", FILE_APPEND );
        }
        
    }
    

    

?>