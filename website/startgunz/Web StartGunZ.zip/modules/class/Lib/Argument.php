<?php

    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */

    /**
    * Constantes que indicam o tipo de argumento presente na funcao
    */
    final class ArgumentType
    {
        const AT_STRING = 1;
        const AT_NUMBER = 2;
        const AT_BINARY = 4;
        const AT_BINARY_FORMATTED = 8;
    }

    /**
    * Classe que funciona como um argumento para as queries SQL
    */
    final class Argument
    {
        
        protected $Value;
        protected $Type;
        
        /**
        * Constr�i o argumento
        * 
        * @param mixed $value   Valor do argumento
        * @param mixed $type    Tipo do argumento
        * @return Argument
        */
        public function __construct($value, $type = AT_STRING)
        {
            $this->Value = $value;
            $this->Type = $type;    
        }
        
        /**
        * Retorna o valor do argumento
        * 
        */
        public function GetValue()
        {
            return $this->Value;
        }
        
        /**
        * Retorna o tipo do argumento
        * 
        */
        public function GetType()
        {
            return $this->Type;
        }
        
    }

?>