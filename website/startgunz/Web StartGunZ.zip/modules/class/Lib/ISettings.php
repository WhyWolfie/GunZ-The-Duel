<?php

    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */

    /**
    * Classe base que armazena as configura��es de conex�o dos objetos
    */
    class ISettings
    {
        
        /// Driver name
        protected $Driver;
        
        /// IP/HOST Servidor
        protected $Host; 
        
        /// Porta de conex�o do servidor
        protected $Port;
        
        
        /// Nome do banco de dados
        protected $Name;
        
        
        /// Usu�rio para autentica��o
        protected $User;
        
        /// Senha para autentica��o
        protected $Password;
        
        
        /**
        * Constr�� o objeto
        * 
        * @param mixed $host    Servidor
        * @param mixed $name    Nome do banco de dados
        * @param mixed $user    Usu�rio para autentica��o
        * @param mixed $password    Senha para autentica��o
        * @param mixed $port    Porta para conex�o 
        * @return ISettings
        */
        public function __construct($host = null, $name = null, $user = null, $password = null, $port = null)
        {
            
            $this->Host = $host;
            $this->Port = $port;
            
            $this->Name = $name;
            
            $this->User = $user;
            $this->Password = $password;
            
            if($this->Password == null)
            {
                $this->Password = "";
            }
            
        }
        
        
        /**
        * Retorna o endere�o do servidor
        * 
        */
        public function GetServerHost()
        {
            return $this->Host;
        }
        
        /**
        * Retorna a porta do servidor
        * 
        */
        public function GetServerPort()
        {
            return $this->Port;
        }
        
        /**
        * Retorna o nome do banco de dados
        * 
        */
        public function GetDatabaseName()
        {
            return $this->Name;
        }
        
        /**
        * Retorna o usu�rio para autentica��o
        * 
        */
        public function GetAuthUser()
        {
            return $this->User;
        }
        
        /**
        * Retorna a senha para autentica��o
        * 
        */
        public function GetAuthPassword()
        {
            return $this->Password;
        }
        
        
        /**
        * Retorna o nome do driver
        * 
        */
        public function GetDriverName()
        {
            return $this->Driver;
        }
        
        
        /**
        * Muda o valor do nome do driver
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetDriverName($value)
        {
            $this->Driver = $value;
            return $this;
        }
        
        
        /**
        * Muda o valor do endere�o do servidor
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetServerHost($value)
        {
            $this->Host = $value;
            return $this;
        }
        
        /**
        * Muda o valor da porta do servidor
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetServerPort($value)
        {
            $this->Port = $value;
            return $this;
        }
        
        /**
        * Muda o nome do banco de dados
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetDatabaseName($value)
        {
            $this->Name = $value;
            return $this;
        }
        
        /**
        * Muda o usu�rio para autentica��o
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetAuthUser($value)
        {
            $this->User = $value;
            return $this;
        }
        
        /**
        * Muda a senha para autentica��o
        * 
        * @param mixed $value
        * @return ISettings  
        */
        public function SetAuthPassword($value)
        {
            $this->Password = $value;
            return $this;
        }
        
    }
    



?>