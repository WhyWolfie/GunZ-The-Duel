<?php
    
    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */
    
    /**
    * Classe de conex�o Mysql
    */
    class MysqlDatabase
        extends IDatabase
    {
        
        protected $LastInsertedId = 0;
        
        /**
        * Constructor
        * 
        * @param MysqlSettings $settings    Configura��es 
        * @return MysqlDatabase
        */
        public function __construct(MssqlSettings $settings)  
        {
            if(!extension_loaded('mysqli'))
            {
                DatabaseFactory::ThrowException("A sua instala��o atual PHP n�o possui a extens�o 'php_mysqli'");
            }
            parent::__construct($settings);
        }
        
        /**
        * Retorna TRUE caso o objeto esteja conectado a um banco de dados.
        * 
        * @return boolean
        */
        public final function IsConnected()
        {
            if($this->GetConnection() == null)
            {
                return false;
            }
            if(!is_resource($this->GetConnection()))
            {
                return false;
            }
            return true;
        }
        
        /**
        * Verifica se a conex�o est� funcional
        * 
        * @return boolean
        */
        public final function CheckConnection($action = "Default")
        {
            $connected = $this->IsConnected();
            if(!$connected)
            {
                DatabaseFactory::ThrowException("Imposs�vel realizar a��o '" . $action . "' : desconectado do banco de dados.");
            }
            return $connected;
        }
        
        /**
        * Conecta-se a um banco de dados
        * 
        * @param IDbSettings $settings  Configura��es (manter null caso ja esteja configurado)
        * @return boolean
        */
        public final function Connect(ISettings $settings = null)
        {
            
            if($this->IsConnected())
            {
                //DatabaseFactory::ThrowException("Objeto j� est� conectado.");
                $this->Disconnect();
            }
            
            if($settings != null)
            {
                $this->Settings  = $settings;
            }
            
            $address = $this->Settings->GetServerHost();
            if($this->Settings->GetServerPort() != 1433)
            {
                $address .= "," . string($this->Settings->GetServerPort()); 
            }
            
            if($this->Settings->IsPersistent())
            {
                $this->SetConnection(@mysql_pconnect ( $address, $this->Settings->GetAuthUser(), $this->Settings->GetAuthPassword(), $this->Settings->IsNewLink()));
            }
            else
            {
                $this->SetConnection(@mysql_connect ( $address, $this->Settings->GetAuthUser(), $this->Settings->GetAuthPassword(), $this->Settings->IsNewLink()));
            }
            
            if($this->IsConnected())
            {
                if($this->SelectDatabase($this->Settings->GetDatabaseName()))
                {
                    return true;
                }
            }
            
            DatabaseFactory::ThrowException("Imposs�vel conectar-se ao banco de dados (" . $this->GetLastError() . ")");            
            return false;

        }
        
        /**
        * Desconecta-se do banco de dados
        * 
        * @return void
        */
        public final function Disconnect()
        {
            if($this->IsConnected())
            {
                @mysql_close($this->GetConnection());
            }
        }
        
        /**
        * Executa uma procedure no banco de dados
        * 
        * @param string $name   Nome da procedure
        * @return MysqlRecordset
        */
        public final function ExecuteProcedureReader($name)
        {
            
            if(!$this->CheckConnection("MysqlDatabase::ExecuteProcedureReader()"))
            {
                $this->QueryFailIncrement();
                return null;
            }
            
            $query = "CALL " . $name;    
            $funcargs = func_get_args();
            $arguments = IDatabase::ParseArguments($this, $funcargs, 1);
            if(sizeof($arguments) > 0)
            {
                $query .= " ";
                //$query .= " ( ";  
                $query .= implode(', ', $arguments);
                //$query .= " )";  
            }
            
            $result = $this->Query($query, $this->GetConnection());
            if(!$result)
            {
                $this->QueryFailIncrement();
                DatabaseFactory::ThrowException($this->GetLastError() . " (" . $this->Settings->GetDatabaseName() . ")");
                return null;
            }
            
            $this->QuerySuccessIncrement();
            return new MssqlRecordset($this, $result);
            
        }
        
        /**
        * Executa uma procedure no banco de dados n�o retornando nada
        * 
        * @param string $name
        * @return void
        */
        public final function ExecuteProcedureNonQuery($name)
        {
        
            if(!$this->CheckConnection("MysqlDatabase::ExecuteProcedureNonQuery()"))
            {
                $this->QueryFailIncrement();
                return;
            }
            
            //
            $query = "CALL "  . $name;   
            $funcargs = func_get_args();
            $arguments = IDatabase::ParseArguments($this, $funcargs, 1);
            if(sizeof($arguments) > 0)
            {
                $query .= " ";
                //$query .= " ( ";
                $query .= implode(', ', $arguments);
                //$query .= " )";
            }
            
            $result = $this->Query($query, $this->GetConnection());
            if(!$result)
            {
                $this->QueryFailIncrement();
                DatabaseFactory::ThrowException($this->GetLastError() . " (" . $this->Settings->GetDatabaseName() . ")"); 
                return;
            }
            
            $this->QuerySuccessIncrement();
            return;
        
        }
        
        /**
        * Executa uma query e retorna um IRecordset no caso de sucesso, ou FALSE no caso de falha.
        * 
        * @param string $command    Comando a ser executado
        * @return MssqlRecordset
        */
        public final function ExecuteReader($command)
        {
            
            if(!$this->CheckConnection("MysqlDatabase::ExecuteReader()"))
            {
                $this->QueryFailIncrement();
                return null;
            }
            
            $query = $command;
            $funcargs = func_get_args();
            $arguments = IDatabase::ParseArguments($this, $funcargs, 1);
            $query = IDatabase::FormatQuery($query, $arguments);
            
            $result = $this->Query($query, $this->GetConnection());
            if(!$result)
            {
                $this->QueryFailIncrement();
                DatabaseFactory::ThrowException($this->GetLastError() . " (" . $this->Settings->GetDatabaseName() . ")"); 
                return null;
            }
            
            $this->QuerySuccessIncrement();
            return new MssqlRecordset($this, $result);
            
        }
        
        /**
        * Executa uma query que n�o retornar� resultados. (Ex.: UPDATE ...)
        * 
        * @param string $command
        * @return void
        */
        public final function ExecuteNonQuery($command)
        {
            
            if(!$this->CheckConnection("MysqlDatabase::ExecuteNonQuery()"))
            {
                $this->QueryFailIncrement();
                return;
            }
            
            $query = $command;
            $funcargs = func_get_args();
            $arguments = IDatabase::ParseArguments($this, $funcargs, 1);
            $query = IDatabase::FormatQuery($query, $arguments);
            
            /*if(stripos($query, "INSERT") == 0)
            {
                $this->LastInsertedId = $this->ExecuteScalar("SELECT @@IDENTITY AS 'ID'");   
            }*/
            
            $result = $this->Query($query, $this->GetConnection());
            if(!$result)
            {
                $this->QueryFailIncrement();
                DatabaseFactory::ThrowException($this->GetLastError() . " (" . $this->Settings->GetDatabaseName() . ")"); 
                return;
            }
            
            $this->QuerySuccessIncrement();
            return;
            
        } 
        
        /**
        * Executa uma query na qual o valor retornado � o valor da primeira coluna e da primeira linha
        * 
        * @param string $command    Comando a ser executado
        * @return mixed
        */
        public final function ExecuteScalar($command)
        {
            
            if(!$this->CheckConnection("MysqlDatabase::ExecuteScalar()"))
            {
                $this->QueryFailIncrement();
                return null;
            }
            
            $query = $command;
            $funcargs = func_get_args();
            $arguments = IDatabase::ParseArguments($this, $funcargs, 1);
            $query = IDatabase::FormatQuery($query, $arguments);
            
            $result = $this->Query($query, $this->GetConnection());
            if(!$result)
            {
                $this->QueryFailIncrement();
                DatabaseFactory::ThrowException($this->GetLastError() . " (" . $this->Settings->GetDatabaseName() . ")"); 
                return null;
            }
            
            $obj = @mysql_result($result, 0, 0);
            $this->FreeResult($result);
            
            if(!$obj)
            {
                $this->QueryFailIncrement();    
                return null;
            }
            
            $this->QuerySuccessIncrement();
            return  $obj; 
            
        }
        
        /**
        * Executa uma query
        * 
        * @param $str Comando
        * @return resource
        */
        protected final function Query($str)
        {
            //echo $str;
            //if($str != "SET QUOTED_IDENTIFIER ON")
            //    throw new Exception($str);
            DatabaseFactory::WriteLog($str, "Query");
            return @mysql_query($str, $this->GetConnection());
        }
        
        
        /**
        * Muda o banco de dados atual
        * 
        * @param string $name   Nome do banco de dados
        * @return boolean
        */
        public final function SelectDatabase($name)
        {
            if(!$this->CheckConnection("MysqlDatabase::SelectDatabase()"))
            {
                return false;
            }
            return (bool)@mysql_select_db($name, $this->GetConnection());
        } 
        
        /**
        * Inicializa uma transa��o
        * 
        * @param $name Nome da transa��o
        */
        public final function BeginTransaction($name = null)
        {
            $this->ExecuteNonQuery("START TRANSACTION;");
        }
        
        /**
        * Finaliza uma transa��o
        * 
        * @param $name Nome da transa��o
        */
        public final function RollbackTransaction($name = null)
        {
            $this->ExecuteNonQuery("ROLLBACK;");
        }
        
        /**
        * Salva uma transa��o
        *
        * @param $name Nome da transa��o
        */
        public final function CommitTransaction($name = null)
        {
            $this->ExecuteNonQuery("COMMIT;");            
        }
        
        /**
        * Libera um resultado de query
        * 
        * @param mixed $result
        */
        public final function FreeResult($result)
        {
            @mysql_free_result($result);
        }
        
        /**
        * Retorna a descri��o do �ltimo erro ocorrido
        * @return string
        */
        public final function GetLastError()
        {
            return $this->GetLastMessage();
        }
        
        /**
        * Retorna a descri��o do �ltimo erro ocorrido 
        * @return string
        */
        public final function GetLastMessage()
        {
            return @mysql_error($this->GetConnection());
        }
        
        /**
        * Retorna o �ltimo id inserido no banco de dados (null em caso de falha)
        * @return int
        */
        public final function GetLastInsertedId()
        {
            return $this->LastInsertedId;
        }
        
        /**
        * Protege contra SQL-Injection
        * 
        * @param mixed $string String a ser protegida
        * @return string
        */
        public final function EscapeString($string)
        {
            return @mysql_real_escape_string($string); /*  $this->EscapeCharacter() . 
                    str_replace($this->EscapeCharacter(), $this->EscapeCharacter() . $this->EscapeCharacter(), $string) . 
                   $this->EscapeCharacter(); */
        }
        
        /**
        * Protege contra SQL-Injection
        * 
        * @param mixed $string String a ser protegida
        * @return string
        */
        public final function EscapeCharacter()
        {
            return "`";
        }
        
    }

?>
