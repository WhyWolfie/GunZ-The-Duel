<?php
	class funcao
	
{
	var $login;
	var $senha;
	
	  function funcao()
		{
			$this->login = $_SESSION['GneeSite_login'];
			$this->senha = $_SESSION['GneeSite_senha'];
		}
	   function logado()
		{
		  if(!isset($_SESSION['GneeSite_login']) || !isset($_SESSION['GneeSite_senha']))
		  {
			$_SESSION['GneeSite_login'] == "";
			$_SESSION['GneeSite_senha'] == "";
			header("Location: index.php");
			exit();
		  }  
		}
	   function logado_cadastro()
	   {
		if(isset($_SESSION['GneeSite_login']) || isset($_SESSION['GneeSite_senha']))
			{
				 exit('<table width="100%" border="0" cellspacing="3" cellpadding="0" >
			  <span class="desc">Deslogue para Usar essa P&aacute;gina</span></div></table>
					</td>
				  </tr>
				</table>
				</div>
				<div id=\'footer\'>
				  <ol>
				  Todos direitos reservados <span class=\'bold\'>'.NAME.'</span><br>
				   Layout by <span class=\'bold_cooper\'>ViniciusA</span> | Programa&ccedil;&atilde;o by: <span class=\'bold_cooper\'>Raphael Gnecco</span>
				  </ol>
				</div>
				</div>
				</body>
				</html>');
			}
	   } 
		function online()
		{
			global $conexao;
			$check = $conexao->ExecuteScalar("select connectstat from MuOnline.dbo.memb_stat where memb___id=?",$this->login);
			if($check > 0)
			{
				exit('<table width="100%" border="0" cellspacing="3" cellpadding="0" >
			  <span class="desc">Deslogue para Usar essa P&aacute;gina</span></div></table>
					</td>
				  </tr>
				</table>
				</div>
				<div id=\'footer\'>
				  <ol>
				  Todos direitos reservados <span class=\'bold\'>'.NAME.'</span><br>
				   Layout by <span class=\'bold_cooper\'>ViniciusA</span> | Programa&ccedil;&atilde;o by: <span class=\'bold_cooper\'>Raphael Gnecco</span>
				  </ol>
				</div>
				</div>
				</body>
				</html>');  
			}
		}    
		
		function pegar_vip($config)
		{
			global $conexao;
			global $VIPS;
			$vip = $conexao->ExecuteScalar("select ".vip_coluna." from MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$this->login);
			if($vip < $config)
			{
			  switch($config)
			  {
				case 0: $nome_vip = "Free";
				break;
				case 1: $nome_vip = $VIPS["NOME"]["VIP1"];
				break;
				case 2: $nome_vip = $VIPS["NOME"]["VIP2"];
				break;
				case 3: $nome_vip = $VIPS["NOME"]["VIP3"];
				break;
				case 4: $nome_vip = $VIPS["NOME"]["VIP4"];
				break;
				case 5: $nome_vip = $VIPS["NOME"]["VIP5"];
				break;
			  } 
			  exit('<table width="100%" border="0" cellspacing="3" cellpadding="0" >
			  <span class="desc">Necess&aacute;rio ser '.$nome_vip.' para Acessar Essa P&aacute;gina Ou P&aacute;gina Desativada.</span></table>
					</td>
				  </tr>
				</table>
				</div>
				<div id=\'footer\'>
				  <ol>
				  Todos direitos reservados <span class=\'bold\'>'.NAME.'</span><br>
				   Layout by <span class=\'bold_cooper\'>ViniciusA</span> | Programa&ccedil;&atilde;o by: <span class=\'bold_cooper\'>Raphael Gnecco</span>
				  </ol>
				</div>
				</div>
				</body>
				</html>');
			}                
		} 
		function so_adm($nivel)
		{
			global $conexao;
			$check_nivel = $conexao->ExecuteScalar("select nivel from GneeSite.dbo.gnee_admin where login=?",$this->login);
			if($check_nivel < $nivel)
			{
			 exit('<table width="100%" border="0" cellspacing="3" cellpadding="0" >
			  <span class="desc">Voc&ecirc; n&atilde;o tem Permiss&atilde;o para Acessar essa P&aacute;gina</span></div></table>
					</td>
				  </tr>
				</table>
				</div>
				<div id=\'footer\'>
				  <ol>
				  Todos direitos reservados <span class=\'bold\'>'.NAME.'</span><br>
				   Layout by <span class=\'bold_cooper\'>ViniciusA</span> | Programa&ccedil;&atilde;o by: <span class=\'bold_cooper\'>Raphael Gnecco</span>
				  </ol>
				</div>
				</div>
				</body>
				</html>');   
			}
		}
	  function buscar_personagem($nick)
		{
			global $conexao;
		  if(strlen($nick ) < 3)
			  {
			      return '<div class="error_q" align="center">O Nick deve Ser Maior que 3 Characteres</div></table>' ;  
			  } 
		   echo '<table width="600" align="center" cellpadding="0" cellspacing="2">'; 
				 $banchar = $conexao->ExecuteReader("select top 30 name,".coluna_reset." as Reset,foto from MuOnline.dbo.character where name like '%$nick%'");    
				$p=1;
			if($banchar->getRowCount() <= 0) 
				  {
					return ('<div id="alertas_2" align="center">Nenhum Personagem encontrado</div></table>');
                  }
					for($x=0;$x<$banchar->getRowCount()/2;$x++)
					  {
						echo '<tr>';
						 for($i=0;$i<4;$i++) 
						   {
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
								{
							echo '<td></td>';
								}
							else
								{ 
								echo "<td align=\"center\">
								<span class='top_ul2'>".$p."&ordm;<br /></span>
								<a href=\"?gne=char_info&name=".$reset->name."\"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
								<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
								<span class='top_ul2'>Reset's</span>: <span class='top_ul3'>".$reset->Reset."<br /></span><br />
								</div>
								</td>
								</div>";
							$p++;
								}
							}     
						}
	   echo "</table>"; 
		}
	  function ranking($rank,$numero)
		{
			global $conexao;
			global $func;
				if(empty($numero) || empty($rank))
					{
					return '<div class="error_q" align="center">[&loz;]Por Favor Selecione um Ranking e um Número.</center></table>';
					}
																		 
					if($rank == "Resets")
					{                     
					   echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
					   $banchar = $conexao->ExecuteReader("select TOP ? name,".coluna_reset." as Reset,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".coluna_reset." DESC",(int)$numero);    
					   $p=1;
					if($banchar->getRowCount() <= 0) 
						{
				        	return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
						}
					for($x=0;$x<$banchar->getRowCount()/4;$x++) 
						{
						   echo '<tr>';
						for($i=0;$i<4;$i++) 
						{
						   $reset = $banchar->fetchObject(); 
						 if($reset->name == '') 
							{
						   echo '<td></td>';}
						else
							{
						   echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Reset's</span>: <span class='top_ul3'>".$reset->Reset."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}    
					        if($rank == "mr"){
					   		echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".coluna_mr." as MR,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".coluna_mr." DESC",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++)
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
							{
							echo '<td></td>';}
							else{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Master Reset's</span>: <span class='top_ul3'>".$reset->MR."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}            
				             if($rank == "Hero"){
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".coluna_hero." as Hero,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".coluna_hero." desc",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
							{
							echo '<td></td>';}
							else{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Hero</span>: <span class='top_ul3'>".$reset->Hero."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}
		
							if($rank == "Pk"){
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".coluna_pk." as pk,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".coluna_pk." desc",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
							{
							echo '<td></td>';
							}
							else{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>PK</span>: <span class='top_ul3'>".$reset->pk."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}
				            if($rank == "Guild"){
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? G_name,G_Score,G_Mark from MuOnline.dbo.Guild ORDER BY G_Score Desc",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++)
							 {
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->G_name == '') 
							{
							echo '<td></td>';
							}
							else
							{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>                
							<a href=\"?gne=guild_info&name=".$reset->G_name."\" \"><img class=\"imagem\" src=\"modules/class/gmark.class.php?m=".bin2hex($reset->G_Mark)."\"  /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->G_name."<br />
							<span class='top_ul2'>Score</span>: <span class='top_ul3'>".$reset->G_Score."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}         

				            if($rank == "Sign"){

        $rankq = mssql_query("Select REG_SIEGE_GUILD,REG_MARKS FROM MuOnline.dbo.MuCastle_REG_SIEGE ORDER BY REG_MARKS DESC");
        $result = mssql_num_rows($rankq);
        echo '<table width="600" align="center" cellpadding="0" cellspacing="2">';
          $pos = 0;
        if($result <= 0) {
            echo '<div class="error_q" align="center">Nenhuma Guild encontrada</div></table>';
        }
           for($x=0;$x<mssql_num_rows($rankq)/5;$x++) {
            echo '<tr>';
               for($i=0;$i<5;$i++) {
                $rank = mssql_fetch_row($rankq);

                if($rank[2] <= 1){$score = $rank[1].' Sing';} else {$score = $rank[1].' Sings';}
                $mark = $conexao->ExecuteReader("SELECT G_Mark FROM MuOnline.dbo.Guild WHERE G_Name='".$rank[0]."'");
                $logo = $mark->fetchObject();
                $pos = $pos+1;
                if($pos <= $result) {
                    if($rank[0] == '') {
                        echo '<td></td>';
                    } else {
                        echo "<td align=\"center\">
							<span class='top_ul2'>".$pos."&ordm;<br /></span>
							<a href=\"?gne=guild_info&name=".$rank[0]."\" \"><img class=\"imagem\" src=\"modules/class/gmark.class.php?m=".bin2hex($logo->G_Mark)."\"  /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$rank[0]."<br />
							<span class='top_ul2'>Score</span>: <span class='top_ul3'>".$score."<br /></span><br />
							</div>
							</td>
							</div>";
                    }
                }
            }
          echo '</tr>';
          }
        echo '</table>';
    }
    
		
                            if($rank == "Resets_dia"){                     
		  					echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".reset_dia." as dia,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".reset_dia." DESC",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '')
							 {
							echo '<td></td>';
							}
							else
							{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Reset's</span>: <span class='top_ul3'>".$reset->dia."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}    
							if($rank == "Resets_sema"){                     
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".reset_semana." as semana,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".reset_semana." DESC",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
							{
							echo '<td></td>';
							}
							else
							{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Reset's</span>: <span class='top_ul3'>".$reset->semana."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}    
							if($rank == "Resets_mensa"){                     
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? name,".reset_mes." as mes,foto from MuOnline.dbo.character where ctlcode < 8 ORDER BY ".reset_mes." DESC",(int)$numero);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							{
							$reset = $banchar->fetchObject(); 
							if($reset->name == '') 
							{
							echo '<td></td>';
							}
							else
							{
							echo "<td align=\"center\">
							<span class='top_ul2'>".$p."&ordm;<br /></span>
							<a href=\"?gne=char_info&name=".$reset->name."\" \"><img src=\"images/char/".$reset->foto."\" class=\"imagem\" /><br /></a>
							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset->name."<br />
							<span class='top_ul2'>Reset's</span>: <span class='top_ul3'>".$reset->mes."<br /></span><br />
							</div>
							</td>
							</div>";
							$p++;}}}}
							if($rank == "Divul")
							{                     
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
							$banchar = $conexao->ExecuteReader("select TOP ? memb_name,link_bonus,contador_link_bonus from MuOnline.dbo.memb_info ORDER BY contador_link_bonus DESC",(int)$numero);    
							
							?>
							<tr>     
							<td align="center" width="10%"class="top_ul2"><strong>Posi&ccedil;&atilde;o</strong></td>                        
							<td align="center" width="10%"class="top_ul2"><strong>Nome</strong></td>
							<td align="center" width="50%" class="top_ul2"><strong>Link</strong></td>
							<td align="center" width="30%"class="top_ul2"><strong>Quantidade de Cliques</strong></td>
							</tr>
							<?php 
							(int)$pos =0;
                            
							while ($linha = $banchar->fetchObject()){
							  $pos++;
							?>
							<tr>
							<td align="center" bgcolor="#666"class="top_ul3"><? echo $pos; ?></td>
							<td align="center" bgcolor="#666"class="top_ul3"><? echo $linha->memb_name; ?></td>
							<td align="center"bgcolor="#666"class="top_ul3"><? echo $linha->link_bonus; ?></td>
							<td width="10%" align="center"bgcolor="#666"class="top_ul3"><?php echo $linha->contador_link_bonus; ?></td>
						  </tr>
							<?php }
							echo '</div>
							</td>
							</div>';
							 }
							 
							if($rank == "Vanert" || $rank == "Duprian")
							{
							global $info_char;
							switch($rank)
							{
								case "Vanert" : $time = NUMER_FAMILIA_VANERT;
								break;
								case "Duprian" : $time =  NUMERO_FAMILIA_DUPRIAN;
								break;
							} 
							echo ('<table width="600" align="center" cellpadding="0" cellspacing="2">');
						    $banchar = $conexao->ExecuteReader("select TOP ? * from MuOnline.dbo.".TABELA_SISTEMA_GENS." WHERE ".TABELA_FAMILIA_GENS."=? ORDER BY ".CONTRIBUIRION_SISTEMA_GENS." DESC",(int)$numero,$time);    
							$p=1;
							if($banchar->getRowCount() <= 0) 
							{
							     return '<div class="error_q" align="center">Nenhum Personagem encontrado</div></table>';
							}
							for($x=0;$x<$banchar->getRowCount()/4;$x++) 
							{
							echo '<tr>';
							for($i=0;$i<4;$i++) 
							 {
    							$reset = $banchar->FetchArray();
    							$foto = $conexao->ExecuteScalar("select foto from MuOnline.dbo.character where name=?",$reset[COLUNA_NOME_SISTEMA_GENS]);
    							if($reset[COLUNA_NOME_SISTEMA_GENS] == '') 
        							{
        						      	echo '<td></td>';
        							}
							else
                                {
    							echo "<td align=\"center\">
    							<span class='top_ul2'>".$p."&ordm;<br /></span>
    							<a href=\"?gne=char_info&name=".$reset[COLUNA_NOME_SISTEMA_GENS]."\" \"><img src=\"images/char/".$foto."\" class=\"imagem\" /><br /></a>
    							<span class='top_ul2'>Nome:</span><span class='top_ul3'> ".$reset[COLUNA_NOME_SISTEMA_GENS]."<br />
    							<span class='top_ul2'>Fam&iacute;lia</span>: <span class='top_ul3'>".$rank."<br /></span>
    							<span class='top_ul2'>Patente</span>: <span class='top_ul3'>".$info_char->patente_gens($reset[COLUNA_NOME_SISTEMA_GENS])."<br /></span>
    							<span class='top_ul2'>Pontos</span>: <span class='top_ul3'>".$reset[CONTRIBUIRION_SISTEMA_GENS]."<br /><br /></span>
    							</div>
    							</td>
    							</div>";
    							$p++;}}}}
		  echo "</table>"; 
		  }         
	
    	function retornar_infos_tops()
            {
                global $conexao;            
                      $inforeset = $conexao->ExecuteReader("select TOP 1 name,foto,".coluna_reset." As Resets,class from character order by ".coluna_reset." desc");
                      $inforesetd = $conexao->ExecuteReader("select TOP 1 name,foto,".reset_dia." As Resets,class from character order by ".reset_dia." desc");
                      $inforesets = $conexao->ExecuteReader("select TOP 1 name,foto,".reset_semana." As Resets,class from character order by ".reset_semana." desc");
                      $inforesetm = $conexao->ExecuteReader("select TOP 1 name,foto,".reset_mes." As Resets,class from character order by ".reset_mes." desc");
                      $infomr = $conexao->ExecuteReader("select TOP 1 name,foto,".coluna_mr." As Resets,class from character order by ".coluna_mr." desc");
                      $infopk = $conexao->ExecuteReader("select TOP 1 name,foto,".coluna_pk." As Resets,class from character order by ".coluna_pk." desc");
                      $infohero = $conexao->ExecuteReader("select TOP 1 name,foto,".coluna_hero." As Resets,class from character order by ".coluna_hero." asc"); 
                      $infoguild = $conexao->ExecuteReader("select TOP 1 G_name,G_Mark,G_Score from guild order by G_Score desc");
                      $reset = $inforeset->FetchObject(); 
                      $resetd = $inforesetd->FetchObject(); 
                      $resets = $inforesets->FetchObject(); 
                      $resetm = $inforesetm->FetchObject(); 
                      $mr = $infomr->FetchObject(); 
                      $pk = $infopk->FetchObject(); 
                      $hero = $infohero->FetchObject(); 
                      $guild = $infoguild->FetchObject(); 
                      return array("NOME_RESET" => $reset->name,"RESET_RESETS" => $reset->Resets, "FOTO_RESET" => $reset->foto, "CLASS_RESET" => $reset->class,
                                 "NOME_RESETD" => $resetd->name,"RESETD_RESETS" => $resetd->Resets, "FOTO_RESETD" => $resetd->foto, "CLASS_RESETD" => $resetd->class,
                                 "NOME_RESETS" => $resets->name,"RESETS_RESETS" => $resets->Resets, "FOTO_RESETS" => $resets->foto, "CLASS_RESETS" => $resets->class,
                                 "NOME_RESETM" => $resetm->name,"RESETM_RESETS" => $resetm->Resets, "FOTO_RESETM" => $resetm->foto, "CLASS_RESETM" => $resetm->class,
                                 "NOME_MASTER" => $mr->name,"MASTER_RESETS" => $mr->Resets, "FOTO_MASTER" => $mr->foto, "CLASS_MASTER" => $mr->class,
                                 "NOME_PK" => $pk->name,"PK_MORTES" => $pk->Resets, "FOTO_PK" => $pk->foto, "CLASS_PK" => $pk->class,
                                 "NOME_HERO" => $hero->name,"HERO_MORTES" => $hero->Resets, "FOTO_HERO" => $hero->foto, "CLASS_HERO" => $hero->class,
                                 "NOME_GUILD" => $guild->G_name,"GUILD_SCORE" => $guild->G_Score, "FOTO_GUILD" => $guild->G_Mark);
            }
        function retornar_nivel()
            {
                global $conexao;
                return $conexao->ExecuteScalar("Select nivel FROM GneeSite.dbo.gnee_admin where login=?",$this->login);
            } 
         
   }
   
   ?>