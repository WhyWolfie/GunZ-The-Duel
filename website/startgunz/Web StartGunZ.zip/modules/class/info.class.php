<?php 
class status {
			function total_acc()
                {
    				$total = mssql_num_rows(mssql_query("select memb___id from MuOnline.dbo.memb_info"));
    				return $total;
				}
			function total_char()
                {
    				$total = mssql_num_rows(mssql_query("select AccountID from MuOnline.dbo.character"));
    				return $total;
				}    
			function total_vip($tipo)
                {
    				$total = mssql_num_rows(mssql_query("select memb___id from MuOnline.dbo.memb_info where ".vip_coluna."='".$tipo."'"));
    				return $total;
                }        
			function ban_acc()
                {
    				$total = mssql_num_rows(mssql_query("select memb___id from MuOnline.dbo.memb_info where bloc_code='1'"));
    				return $total;
				}    
			function ban_char()
                {
    				$total = mssql_num_rows(mssql_query("select AccountID from MuOnline.dbo.character where ctlcode='1'"));
    				return $total;
				}
			function total_on()
                {
    				$total = mssql_num_rows(mssql_query("select memb___id from MuOnline.dbo.memb_stat where ConnectStat >='1'"));
    				return $total;
				}    
	function gm() 
        {
    		echo '<table width="200" border="0" cellpadding="0" cellspacing="0">';
    		$online = mssql_query("SELECT 
    		Memb_stat.Connectstat,AccountCharacter.GameIDC,Character.Name FROM Memb_stat 
    JOIN AccountCharacter ON Memb_stat.memb___id = AccountCharacter.ID COLLATE database_default 
    		JOIN Character ON Memb_stat.memb___id = Character.AccountID COLLATE database_default 
    		WHERE Character.CtlCode > 1 ORDER BY CtlCode asc");
    		
    		while($linha = mssql_fetch_row($online)) 
                {
                	if($linha[0] >= 1 and $linha[1] == $linha[2]) 
                        {
                        $on = '<font color="#00FF00">Online</font>';
                        } 
 			        else 
                     {
                       $on = '<font color="#f000">Offline</font>';
                     }
                			  echo '<tr>
    						<td width="40%" align="left">&nbsp;&nbsp;&nbsp;<a style="text-decoration:none" href="?gne=char_info&name='.$linha[2].'">'.$linha[2].'</a></td>
    									
    						
    						<td width="60%" align="center">'.$on.'</td>
    				  </tr>';
    			   }
    			echo '</table>';
	   }        
		function server_on($max,$strig) 
            {
        		global $conexao;
        		$strig != '' ? $strig = "AND ServerName='".$strig."'" : $strig = '';
        		$veryq = $conexao->ExecuteScalar("SELECT COUNT(1) FROM MuOnline.dbo.MEMB_STAT WHERE ConnectStat=1 ".$strig."");
        		$percent = $veryq*100/$max;
        		if($percent>100) {$percent=100;}
	   	        return $percent;
	       }
}
?>