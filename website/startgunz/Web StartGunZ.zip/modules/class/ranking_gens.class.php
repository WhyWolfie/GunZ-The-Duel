<?php
  class gens
  {
	  function total_chars($tipo)
		{
			global $conexao;
			$tipo = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.".TABELA_SISTEMA_GENS." where ".TABELA_FAMILIA_GENS."=?",(int)$tipo);
			return $tipo;
		}
	   function total_pontos($tipo)
		{
			global $conexao;
			$conta = $conexao->ExecuteReader("select ".CONTRIBUIRION_SISTEMA_GENS." from MuOnline.dbo.".TABELA_SISTEMA_GENS." where ".TABELA_FAMILIA_GENS."=?",(int)$tipo);
            while($b = $conta->fetchArray())
				{
					$total = $total + $b[CONTRIBUIRION_SISTEMA_GENS];
				}
			return $total;    
		} 
	  
	function mostrar()  
		{
			echo "<div id='boxxing'>
			<ul>
			<li>Ranking Gens</li></ul>
			<ol>
			<table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"10\">
			<div class=\"gens\">
			<div style=\"position:relative; top:62px; left:160px; width: 200px;\"><h1><font color=\"aqua\">".$this->total_chars(NUMER_FAMILIA_VANERT)."</font></h1></div>
			<div style=\"position:relative; top:20px; left:430px; width: 200px;\"><h1><font color=\"red\">".$this->total_chars(NUMERO_FAMILIA_DUPRIAN)."</font></h1></div>
			<div style=\"position:relative; top:27px; left:150px; width: 200px;\"><h1><font color=\"aqua\">".$this->total_pontos(NUMER_FAMILIA_VANERT)."</font></h1></div>
			<div style=\"position:relative; top:-12px; left:420px; width: 200px;\"><h1><font color=\"red\">".$this->total_pontos(NUMERO_FAMILIA_DUPRIAN)."</font></h1></div>
			</div> 
			</table>
			</ol>
			</div>";
		}
  }
  
?>