<?php
  class func_adm extends funcao
  {
	  function deletar_divul()
		{
			global $conexao;
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_bonus_link");
			$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set contador_link_bonus=0");
			header("Location: ?gne=paineladm/gerenciar_bonus");
		}
	  
      function deletar_noticia($id)
		{
			global $conexao;
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_noticias where id=?",(int)$id);
			header("Location: ?gne=paineladm/gerenciar_noticia");
		}
	  
	  function banir_char($codigo,$qqqqqqqqqqqq,$motivo,$dias,$quem,$prova)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
			     	return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
            if(empty($qqqqqqqqqqqq) || empty($motivo) || empty($dias) || empty($quem))
				{
					return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>';
				}     
			$check = $conexao->ExecuteReader("select MuOnline.dbo.Name from character  where name=?",$qqqqqqqqqqqq); 
            $chek = $conexao->ExecuteScalar("select MuOnline.dbo.CtlCode from character where name=?",$qqqqqqqqqqqq);
			
			if($check->GetRowCount() < 1)
				{
				    return '<center><div class="error_q">[&loz;]Character '.$qqqqqqqqqqqq.' N&atilde;o Encontrado.</div>';    
				}    
			elseif(strlen($motivo) < 5)
				{
			     	return '<center><div class="error_q">[&loz;]Campo Motivo deve ser Maior que 5 caracteres.</div>';    
				}                                
			elseif(strlen($quem) < 4)
				{
				    return '<center><div class="error_q">[&loz;]Nick do GM/ADM que esta Banindo deve ser maior que 4.</div>';  
				}   
            $check = $check->fetchObject();     
			if($chek == 1)
				{
				    return '<center><div class="error_q">[&loz;]O Character '.$qqqqqqqqqqqq.' ja Esta Banido.</div>';  
				}    
			 $conexao->ExecuteNonQuery("update MuOnline.dbo.character set CtlCode='1' where name=?",$qqqqqqqqqqqq);
			 $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_banchar (nome,motivo,dias,quem,prova) values (?,?,?,?,?)",$qqqqqqqqqqqq,$motivo,(int)$dias,$quem,$prova);			
			         if(REGISTRAR_LOGS == true) 
								{
								$fp = fopen("modules/logs/ban_char.gnee", "a");
								fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Baniu:
								\r\Char: ".$qqqqqqqqqqqq."\r\nMotivo: ".$motivo."\r\nDias: ".$dias."\r\nData: ".$today."\r\nHora: ".$today1."");
								fclose($fp);
								}
			return '<center><div class="ok">[&loz;]O Char '.$qqqqqqqqqqqq.' Foi Banida por '.$dias.' Dias pelo Motivo de '.$motivo.'.</div>';    
													 
		}
		
	  function deletar_vip($codigo,$IUAHSUIDH) 
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				{
				    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			  if(empty($IUAHSUIDH))
				{
				    return '<center><div class="error_q">[&loz;]Campo Nome Obrigatório.</div>';
				}    
			$check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$IUAHSUIDH);
			 if($check->GetRowCount() < 1)
				{
				    return '<center><div class="error_q">[&loz;]Login '.$IUAHSUIDH.' N&atilde;o Encontrado.</div>';
				}    
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=0,".data_vip."=0 where ".vip_login."=?",$IUAHSUIDH);
				if(REGISTRAR_LOGS == true) 
								{
								$fp = fopen("modules/logs/del_vip.gnee", "a");
								fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Deletou Vip Da:
								\r\Conta: ".$IUAHSUIDH."\r\nData: ".$today."\r\nHora: ".$today1."");
								fclose($fp);
								}	
				return '<center><div class="ok">[&loz;]Vip da Conta '.$IUAHSUIDH.' Removido com Sucesso.</div>';
																					
				  
			}
		
	  function remover_gold($codigo,$gold,$UHUL)
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
				
			  $check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$UHUL);
			  $check_gold = $conexao->ExecuteScalar("select ".gold_coluna." from MuOnline.dbo.".tabela_gold." where ".gold_login."=?",$UHUL);
			 if(empty($UHUL) || empty($gold))
				{
					return '<center><div class="error_q">[&loz;]Todos os Campos s&atilde;o Obrigatórios.</div>';
				}    
			 if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Login '.$UHUL.' N&atilde;o Encontrado.</div>';
				}    
			if($check_gold < $gold)
			   {
				 $gold = $check_gold; 
			   }										
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."-? where ".gold_login."=?",(int)$gold,$UHUL);
			if(REGISTRAR_LOGS == true) 
			   {   
				 $fp = fopen("modules/logs/del_gold.gnee", "a");
				 fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Deletou Gold Da:
				 \r\Conta: ".$UHUL."\r\nData: ".$today."\r\nHora: ".$today1."");
				 fclose($fp);
			   }							 
			  return '<center><div class="ok">[&loz;]Foram Removidos '.$gold.' Golds da Conta '.$UHUL.'.</div>';

			}
	  
      function adicionar_gold($codigo,$gold,$aham_claudia)
			{
			  global $conexao;
			  if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			  $check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$aham_claudia);
				if(empty($aham_claudia) || empty($gold))
					{
					   return '<center><div class="error_q">[&loz;]Todos os Campos s&atilde;o Obrigat&oacute;rios.</div>';
					}    
				elseif($check->GetRowCount() < 1)
					{
						return '<center><div class="error_q">[&loz;]Login '.$aham_claudia.' N&atilde;o Encontrado.</div>';
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$gold,$aham_claudia);
					if(REGISTRAR_LOGS == true) 
					   {
						 $fp = fopen("modules/logs/addgold.gnee", "a");
						 fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Adicionou:\r\Conta: ".$aham_claudia."\r\Golds: ".$gold."\r\nData: ".$today."\r\nHora: ".$today1."");
								fclose($fp);
								}
				
					return '<center><div class="ok">[&loz;]Foram Adicionados '.$gold.' Golds da Conta '.$aham_claudia.'.</div>';					
			}
	  
      function deslogar_conta($codigo,$KKKKKKKKKKKKKKKK)
			{
				 global $conexao;                 
				 if($_SESSION["captcha_site"] != $codigo)
					{
						return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
					}   
				$check = $conexao->ExecuteReader("select memb__pwd from MuOnline.dbo.memb_info where memb___id=?",$KKKKKKKKKKKKKKKK);
				
				if(empty($KKKKKKKKKKKKKKKK))
					{
						return '<center><div class="error_q">[&loz;]Todos os Campos s&atilde;o Obrigat&oacute;rios.</div>';
					}    
				if($check->GetRowCount() < 1)
					{
						return '<center><div class="error_q">[&loz;]Login '.$KKKKKKKKKKKKKKKK.' N&atilde;o Encontrado.</div>';
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_stat set Connectstat=0 where memb___id=?",$KKKKKKKKKKKKKKKK);
				return '<center><div class="ok">[&loz;]Conta '.$KKKKKKKKKKKKKKKK.' Deslogada Com Sucesso.</div>';
																
			}	
	  
      function adicionar_noticia($codigo,$tipo,$mensagem,$titulo,$char)
			{
				global $conexao,$bbcode;
				if($_SESSION["captcha_site"] != $codigo)
					{
						return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
					}
				if(empty($mensagem) || empty($tipo))
				{            
					return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>';
				}
				  $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_noticias (tipo,mensagem,quem,titulo,data) values (?,?,?,?,getdate())",$bbcode->arrumar_acentos_color($tipo),$bbcode->arrumar_acentos_color($mensagem),$char,$bbcode->arrumar_acentos_color($titulo));
				  header("Location: ?gne=paineladm/gerenciar_noticia");
			}	
			
	  function desbanir_acc($codigo,$acc)
			{
				global $conexao;
				if($_SESSION["captcha_site"] != $codigo)
					{
						return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
					}
				$check_ban = $conexao->ExecuteScalar("select bloc_code from MuOnline.dbo.memb_info where memb___id=?",$acc);
				if($check_ban == 0)
					{
						return '<center><div class="error_q">[&loz;]Conta '.$acc.' n&atilde;o esta Banida ou n&atilde;o Existe.</div>';
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set bloc_code=0 where memb___id=?",$acc);
				$conexao->ExecuteNonQuery("delete  from GneeSite.dbo.gnee_banacc where login=?",$acc); 
				if(REGISTRAR_LOGS == true) 
				   {
					 $fp = fopen("modules/logs/desban_acc.gnee", "a");
					 fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Desbaniu:
					 \r\Conta: ".$acc."\r\nLogin Sorteado: ".$login."\r\nData: ".$today."\r\nHora: ".$today1."");
					 fclose($fp);
				   }
				return '<center><div class="ok">[&loz;]Conta '.$acc.' Desbanida com Sucesso.</div>';
				
			}	
	  
      function banir_acc($codigo,$porra,$motivo,$dias,$quem,$prova)
			{
				global $conexao;
				if($_SESSION["captcha_site"] != $codigo)
					{
						return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
					}
				$check = $conexao->ExecuteReader("select bloc_code from MuOnline.dbo.memb_info where memb___id=?",$porra);	
				$check2 = $conexao->ExecuteScalar("select memb__pwd,bloc_code from MuOnline.dbo.memb_info where memb___id=?",$porra);
                if(empty($porra) || empty($motivo) || empty($dias) || empty($quem))
					{
						return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos.</div>'; 
					}                                	
				if($check->GetRowCount() < 1)
					{
						return '<center><div class="error_q">[&loz;]Login '.$porra.' N&atilde;o Encontrado.</div>';    
					}    
				if(strlen($motivo) < 5)
					{
						return '<center><div class="error_q">[&loz;]Campo Motivo deve ser Maior que 5 caracteres.</div>';    
					}                                
				if(strlen($quem) < 4)
					{
					return '<center><div class="error_q">[&loz;]Nick do GM/ADM que esta Banindo deve ser maior que 4.</div>';    
					} 
                 $check = $check->fetchObject();      
				 if($check->bloc_code == 1)
					{
						return '<center><div class="error_q">[&loz;]Login '.$porra.' ja Esta Banido.</div>';    
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set bloc_code='1' where memb___id=?",$porra);
				$conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_banacc (login,motivo,dias,quem,prova) values (?,?,?,?,?)",$porra,$motivo,(int)$dias,$quem,$prova);								
                if(REGISTRAR_LOGS == true) 
				  {
					  $fp = fopen("modules/logs/ban_acc.gnee", "a");
					  fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Baniu:
					  \r\Conta: ".$porra."\r\nMotivo: ".$motivo."\r\nDias: ".$dias."\r\nData: ".$today."\r\nHora: ".$today1."");
					  fclose($fp);
				  } 
				return '<center><div class="ok">[&loz;]A Conta '.$porra.' Foi Banida por '.$dias.' Dias pelo Motivo de '.$motivo.'.</div>';    		
			}
	  
      function deletar_char($codigo,$aham)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			if(empty($aham))
				{
					return '<center><div class="error_q">[&loz;]Todos os Campos s&atilde;o Obrigatórios.</div>';
				}    
			$check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.character where name=?",$aham);
			if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Personagem '.$aham.' N&atilde;o Encontrado.</div>';
				}    
			$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.character where name=?",$aham);											
			$conexao->ExecuteNonQuery("update MuOnline.dbo.AccountCharacter set GAMEID1=NULL where GAMEID1=?",$aham);	
			$conexao->ExecuteNonQuery("update MuOnline.dbo.AccountCharacter set GAMEID2=NULL where GAMEID2=?",$aham);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.AccountCharacter set GAMEID3=NULL where GAMEID3=?",$aham);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.AccountCharacter set GAMEID4=NULL where GAMEID4=?",$aham);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.AccountCharacter set GAMEID5=NULL where GAMEID5=?",$aham);
			$conexao->ExecuteNonQuery("DELETE from MuOnline.dbo.Guild where G_master=?",$aham);
			$conexao->ExecuteNonQuery("DELETE from MuOnline.dbo.GuildMember where Name=?",$aham);
			$conexao->ExecuteNonQuery("DELETE from GneeSite.dbo.gnee_banchar where Nome=?",$aham);
			
			if(REGISTRAR_LOGS == true) 
				{
				   $fp = fopen("modules/logs/del_char.gnee", "a");
				   fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Deletou o Char:
					\r\Persoangem: ".$aham."\r\nData: ".$today."\r\nHora: ".$today1."");
					fclose($fp);
				}
								
			  return '<center><div class="ok">[&loz;]Character '.$aham.' Deletada Com Sucesso.</div>';                  
			
		}
	  
      function deletar_conta($codigo,$UHULLP)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			if(empty($UHULLP))
				{
					return '<center><div class="error_q">[&loz;]Todos os Campos s&atilde;o Obrigat&oacute;rios.</div>';
				}
			$check = $conexao->ExecuteReader("select memb__pwd from MuOnline.dbo.memb_info where memb___id=?",$UHULLP);
			if($check->GetRowCount() < 1)
			{
				return '<center><div class="error_q">[&loz;]Login '.$UHULLP.' N&atilde;o Encontrado.</div>';
			}    
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.AccountCharacter where id=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.character where AccountID=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.memb_info where memb___id=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.".tabela_gold." WHERE ".gold_login."=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.memb_stat where memb___id=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM MuOnline.dbo.VI_CURR_INFO where memb___id=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_admin where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_banacc where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_bonus_link where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_pag where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_screen where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_screen_resp where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_ticket where login=?",$UHULLP);
				$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_ticket_resp where login=?",$UHULLP);								
			if(REGISTRAR_LOGS == true) 
			   {
				 $fp = fopen("modules/logs/del_acc.gnee", "a");
				 fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Deletou a Conta:
				 \r\Conta: ".$UHULLP."\r\nData: ".$today."\r\nHora: ".$today1."");
				 fclose($fp);
			   }
			  return '<center><div class="ok">[&loz;]Conta '.$UHULLP.' Deletada Com Sucesso.</div>';
		}	
	   
	  function desbanir_char($codigo,$acc)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			$check_ban = $conexao->ExecuteScalar("select ctlcode from character where name=?",$acc);
				if($check_ban == 0)
				{
					return '<center><div class="error_q">[&loz;]Personagem n&atilde;o esta banido.</div>';
				}
			$conexao->ExecuteNonQuery("update MuOnline.dbo.character set ctlcode=0 where name=?",$acc);
			$conexao->ExecuteNonQuery("delete from GneeSite.dbo.gnee_banchar where nome=?",$acc); 
			if(REGISTRAR_LOGS == true) 
			   {
				$fp = fopen("modules/logs/desban_char.gnee", "a");
				fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Desbaniu:
				\r\Personagem: ".$acc."\r\nData: ".$today."\r\nHora: ".$today1."");
				fclose($fp);
			   }
			return '<center><div class="ok">[&loz;]Personagem '.$acc.' Desbanida com Sucesso.</div>';		
		}  		
	 
     function adicionar_vip($codigo,$afffff,$vip,$dias)
		{
			global $conexao;
			global $VIPS;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			if(empty($afffff))
				{
				   return '<center><div class="error_q">[&loz;]Campo Login Obrigat&oacute;rio.</div>';
				}    
									
			$check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$afffff);
			if($check->GetRowCount() < 1)
				{
				   return '<center><div class="error_q">[&loz;]Login '.$afffff.' N&atilde;o Encontrado.</div>';
				}    
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=?,".data_vip."=".data_vip."+? where memb___id=?",(int)$vip,(int)$dias,$afffff);			
				
			  if(REGISTRAR_LOGS == true) 
				 {
				   $fp = fopen("modules/logs/addvip.gnee", "a");
				   fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Adicionou:
				   \r\Conta: ".$afffff."\r\Vip: ".$vip." com ".$dias." Dias:\r\nData: ".$today."\r\nHora: ".$today1."");
				   fclose($fp);
				 }
			  return '<center><div class="ok">[&loz;]Conta '.$afffff.' adicionado '.$dias.' Dias de '.$VIPS["NOME"]["VIP".$vip.""].'.</div>';			 
		}
	
    function vizualizar_bau($conta)  
		{
			global $conexao;
			global $items;
			$check = $conexao->ExecuteReader("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$conta);
			if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Conta '.$conta.' N&atilde;o Encontrado.</div>';    
				}
			setcookie('vizualizar_bau',$conta,time()+1);
			header("Location: ?gne=paineladm/vizu_bau");			
		}	
	
    function vizualizar_inventorio($char)  
		{
			global $conexao;
			$check = $conexao->ExecuteReader("select name from MuOnline.dbo.character where name=?",$char);
			if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Character '.$char.' N&atilde;o Encontrado.</div>';    
				}
			setcookie('vizualizar_inv',$char,time()+1);
			header("Location: ?gne=paineladm/vizu_inv");            
		}
	
    function editar_conta($continha)
		{
			global $conexao;
			$check = $conexao->ExecuteReader("select memb_guid from MuOnline.dbo.memb_info where memb___id=?",$continha);
			if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Conta '.$continha.' N&atilde;o Encontrado.</div>';    
				}
			header("Location: ?gne=paineladm/editaracc1&editando_conta=".$continha."");			   
							   
			
		}    	
	
    function editar_conta1($codigo,$nome,$vip,$dias,$gold,$email,$id,$code,$login,$cash = 0)
		{
			 global $conexao;
			 if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			$conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set memb_name=?,mail_addr=?,sno__numb=?,bloc_code=? where memb___id=?",$nome,$email,(int)$id,(int)$code,$login);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=?,".data_vip."=? where  ".vip_login."=?",(int)$vip,(int)$dias,$login);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=? where ".gold_login."=?",(int)$gold,$login);
            $conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold2." set ".gold_coluna2."=? where ".gold_login2."=?",(int)$cash,$login);                                   
			if(REGISTRAR_LOGS == true) 
				{
					$fp = fopen("modules/logs/editar_acc.gnee", "a");
					fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Editou:
					\r\Conta: ".$a[0]."\r\nData: ".$today."\r\nHora: ".$today1."");
					fclose($fp);
				}									
			return '<center><div class="ok">[&loz;]Dados Alterados Com Sucesso.</div>';
								
		}    
	
    function editar_char($nick)
		{
			global $conexao;
			$check = $conexao->ExecuteReader("select name from MuOnline.dbo.character where name=?",$nick);
			if($check->GetRowCount() < 1)
				{
					return '<center><div class="error_q">[&loz;]Character '.$nick.' N&atilde;o Encontrado.</div>';    
				}
			header("Location: ?gne=paineladm/editarchar1&editando_char=".$nick."");               					
						
		}	
	
    function editar_char1($codigo,$level,$ulevel,$forca,$agi,$vit,$ene,$cmd = 0,$zen,$mapa,$x,$y,$ctlcode,$reset,$mr,$class,$char)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			$conexao->ExecuteNonQuery("update MuOnline.dbo.character set clevel=?,class=?,leveluppoint=?,Strength=?,Dexterity=?,Vitality=?,Energy=?,Money=?,MapNumber=?,Mapposx=?,Mapposy=?,Ctlcode=?,".coluna_reset."=?,".coluna_mr."=? where name=?",(int)$level,(int)$class,(int)$ulevel,(int)$forca,(int)$agi,(int)$vit,(int)$ene,(int)$zen,(int)$mapa,(int)$x,(int)$y,(int)$ctlcode,(int)$reset,(int)$mr,$char);	
				if(VERSAO_MU == 1)
					{
							$conexao->ExecuteNonQuery("update MuOnline.dbo.character set Leadership=? and Name=?",(int)$cmd,$char);    
					}
				if(REGISTRAR_LOGS == true) 
				  {
					$fp = fopen("modules/logs/editar_char.gnee", "a");
					fwrite($fp, "\r\n==============================================================================\r\nLogin ".$this->login." Editou:
					\r\Char: ".$nome."\r\nData: ".$today."\r\nHora: ".$today1."");
					fclose($fp);
				  }
				  return '<center><div class="ok">[&loz;]Dados Alterados Com Sucesso.</div>';     
		}    
		
	 function realizar_backup($codigo,$db,$nome,$diretorio)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
					return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			if(empty($db))
				{
					return '<center><div class="error_q">[&loz;]Selecione uma DataBase.</div>';
				}
			if(empty($nome))
				{
				    return '<center><div class="error_q">[&loz;]Informe o Nome do BackUp.</div>';
				}   
			if(!file_exists($diretorio))
				{
					return '<center><div class="error_q">[&loz;]Diret&oacute;rio Inv&aacute;lido.</div>';
				}
            $lugar = $diretorio.$nome;                                    
			$conexao->ExecuteNonQuery("BACKUP DATABASE [".$db."] TO  DISK = N'".$lugar."' WITH NOFORMAT, NOINIT, STATS = 10");   	
				
		}   			 
}        
?>							
	
