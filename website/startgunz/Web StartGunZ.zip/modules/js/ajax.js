function Gnee(url, div, tipo, campos)
{
	var ajax = null;
	if(window.ActiveXObject)
		ajax = new ActiveXObject('Microsoft.XMLHTTP');
	else if(window.XMLHttpRequest)
		ajax = new XMLHttpRequest();


	if(ajax != null)
	{
		var cache = new Date().getTime();
		ajax.open(tipo, url + "&cache=" + cache , true);
		ajax.onreadystatechange = function status()
		{
				if(ajax.readyState == 4)
				{
					if(ajax.status == 200)
					{
						document.getElementById(div).innerHTML = ajax.responseText;
						var texto=unescape(ajax.responseText);
						extraiScript(texto);
					}
				}
				else if(ajax.readyState == 0)
					document.getElementById(div).innerHTML = '<center><img src="images/load.gif" /></center>';
				else if(ajax.readyState == 3)
					document.getElementById(div).innerHTML = '<center><img src="images/load.gif" /></center>';
				else
					document.getElementById(div).innerHTML = '<center><img src="images/load.gif" /></center>';
		}
		
		if(tipo == "POST"){
			ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			ajax.setRequestHeader("Cache-Control", "no-store, no-cache, must-revalidate");
			ajax.setRequestHeader("Cache-Control", "post-check=0, pre-check=0");
			ajax.setRequestHeader("Pragma", "no-cache");
			ajax.send(campos); 
		}
	else {
		ajax.send(null);
	}
	}

}

function Numero(e)
{
navegador = /msie/i.test(navigator.userAgent);
if (navegador)
var tecla = event.keyCode;
else
var tecla = e.which;

if(tecla > 46 && tecla < 59) // numeros de 0 a 9
return true;
else
{
if (tecla != 8) // backspace
return false;
else
return true;
}
}
function abrir_banco(id)
	{
		if( id == "bb")
		{
			document.getElementById("bb").style.display = "";
			document.getElementById("itau").style.display = "none";
			document.getElementById("loterica").style.display = "none";
			document.getElementById("bradesco").style.display = "none";
            document.getElementById("santander").style.display = "none";
		}
	else if( id == "itau")
		{
			document.getElementById("itau").style.display = "";
			document.getElementById("bb").style.display = "none";
			document.getElementById("loterica").style.display = "none";
			document.getElementById("bradesco").style.display = "none";
            document.getElementById("santander").style.display = "none";
		}
	else if( id == "loterica")
		{
			document.getElementById("loterica").style.display = "";
			document.getElementById("itau").style.display = "none";
			document.getElementById("bb").style.display = "none";
			document.getElementById("bradesco").style.display = "none";
            document.getElementById("santander").style.display = "none";
		}
	else if( id == "bradesco")
		{
			document.getElementById("bradesco").style.display = "";
			document.getElementById("itau").style.display = "none";
			document.getElementById("loterica").style.display = "none";
			document.getElementById("bb").style.display = "none";
            document.getElementById("santander").style.display = "none";
		}
     else if( id == "santander")
        {
            document.getElementById("santander").style.display = "";
            document.getElementById("itau").style.display = "none";
            document.getElementById("loterica").style.display = "none";
            document.getElementById("bb").style.display = "none";
            document.getElementById("bradesco").style.display = "none";
        }   			
	}
    
function Abrir_Vip(id)
    {
         if( id == "vantagem")
            {
               document.getElementById("vantagem").style.display = "";
               document.getElementById("golds").style.display = "none";
               document.getElementById("como_compra").style.display = "none";
               document.getElementById("dados_deposito").style.display = "none";
            }
         else if(id == "golds")
            {
               document.getElementById("golds").style.display = "";
               document.getElementById("vantagem").style.display = "none";
               document.getElementById("como_compra").style.display = "none";
               document.getElementById("dados_deposito").style.display = "none"; 
            }
         else if(id == "como_compra")
            {
               document.getElementById("como_compra").style.display = "";
               document.getElementById("vantagem").style.display = "none";
               document.getElementById("golds").style.display = "none";
               document.getElementById("dados_deposito").style.display = "none";  
            } 
         else if(id == "dados_deposito")
            {
               document.getElementById("dados_deposito").style.display = "";
               document.getElementById("vantagem").style.display = "none";
               document.getElementById("como_compra").style.display = "none";
               document.getElementById("golds").style.display = "none"; 
            }    
    }
    
function Abrir(id,a)
{
	 if(document.getElementById(id).style.display == "")
		{
			document.getElementById(id).style.display = "none";
			document.getElementById(a).innerHTML = "[Mostrar]";
		}
	else
		{
			document.getElementById(id).style.display = "";
			document.getElementById(a).innerHTML = "[Ocultar]";
		}
} 
 
function atualizarCaptcha(img)
{
 img.src = "modules/class/captcha.class.php?r=" + Math.floor(Math.random()*5000000).toString();
}

function abrir_pagina(pagina)
{
  location.href=pagina;
}

function mensagem(msg) {
		msg = Sexy.error(msg);
}

function mensagem_info(msg2) {
		msg2 = Sexy.info(msg2);
}
function mensagem_alert(msg3) {
		 msg3 = Sexy.alert(msg3);
}

$(function()
	{
$('#login').tooltip2 ('<div id=\"pagina_cadastro\"><h1>O Login, &eacute; Usado para Logar no Servidor e No Site.<br />Apenas Aceita Characteres de a-z, A-Z , 0-9 e _ </h1></div>', {style: 'pagina_cadastro',});
$('#senha').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Recomendamos que utilize Characteres Alphanumericos (Letras e N&uacute;meros), contendo no m&iacute;nimo 4 characteres.<br />Sua Senha &eacute; Pessoal e Intransferiv&eacute;l. </h1></div>', {style: 'pagina_cadastro',});
$('#resenha').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Digitar a mesma senha que foi utilizada no Campo "Senha".</h1></div>', {style: 'pagina_cadastro',});
$('#nome').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Colocar seu Nome ou Um Nick Para Identifica&ccedil;&atilde;o.</h1></div>', {style: 'pagina_cadastro',});
$('#resposta').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor informar a Resposta para a Pergunta Selecionada.</h1></div>', {style: 'pagina_cadastro',});
$('#email').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Informar Um E-mail V&aacute;lido, o Mesmo ser&aacute; Usado para Ativar e Recuperar Dados da Sua Conta.</h1></div>', {style: 'pagina_cadastro',});
$('#reemail').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor confirmar o E-mail Utilizado Acima.</h1></div>', {style: 'pagina_cadastro',});
$('#pid').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Informar o Seu Personal ID.</h1></div>', {style: 'pagina_cadastro',});
$('#repid').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor confirmar o Personal ID Utilizado Acima.</h1></div>', {style: 'pagina_cadastro',});
$('#login_indicado').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Informar o Login da Pessoa que te Indiou, Caso exista.</h1></div>', {style: 'pagina_cadastro',});
$('#bonus').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Selecionar o Item Bonus do Cadastro.</h1></div>', {style: 'pagina_cadastro',});
$('#captcha').tooltip2 ('<div id=\"pagina_cadastro\"><h1>Por Favor Confirmar o C&oacute;digo De Seguran&ccedil;a Informado na Imagem Acima.</h1></div>', {style: 'pagina_cadastro',});

	}
 );    
 
 $(function() {
	// Use this example, or...
	$('a[rel*=lightbox]').lightBox(); // Select all links that contains lightbox in the attribute rel
});
 
 