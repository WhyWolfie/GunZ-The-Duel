<div class="bg-ultimositens">
<div class="title-noticias">Novos Itens<span class="title-view">Shopping</span></div>

<!-- ITEM 01 -->
<div class="fd-ultimositens fd-pos">
	<div class="fd-uitem"><img src="imagens/shop/shop-index/1.png" width="80" height="80" /></div>
	<span class="item-index-title">Custom Pionner ShotGun</span>
	<span class="item-index-info">
		<ul>
		<li>Damage: 12</li>
		<li>Delay: 1000</li>
		<li>Level: 15</li>
		</ul>
	</span>
		<div class="btn-comprar">Comprar</div>
	<div class="btn-detalhes">Detalhes</div>
</div>

<!-- ITEM 02 -->
<div class="fd-ultimositens">
	<div class="fd-uitem"><img src="imagens/shop/shop-index/2.png" width="80" height="80" /></div>
	<span class="item-index-title">Custom Pionner ShotGun</span>
	<span class="item-index-info">
		<ul>
		<li>Damage: 12</li>
		<li>Delay: 1000</li>
		<li>Level: 15</li>
		</ul>
	</span>
		<div class="btn-comprar">Comprar</div>
	<div class="btn-detalhes">Detalhes</div>
</div>

<!-- ITEM 03 -->
<div class="fd-ultimositens">
	<div class="fd-uitem"><img src="imagens/shop/shop-index/3.png" width="80" height="80" /></div>
	<span class="item-index-title">Custom Pionner ShotGun</span>
	<span class="item-index-info">
		<ul>
		<li>Damage: 12</li>
		<li>Delay: 1000</li>
		<li>Level: 15</li>
		</ul>
	</span>
		<div class="btn-comprar">Comprar</div>
	<div class="btn-detalhes">Detalhes</div>
</div>
</div>
<!-- fim ultimos itens-->

<div class="bg-fts">
	<div class="title-noticias">Screenshots</div>

	<div class="area-uitens">
	<div id="img-index">
<div class="imagem-player"><img src="imagens/fotos-players/1.png"/></div>
<div class="nome-player">Player: <span style="color:#2C679D"> Nerva</span></div>
</div>

<div id="img-index">
<div class="imagem-player"><img src="imagens/fotos-players/2.png"/></div>
<div class="nome-player">Player: <span style="color:#6A2020"> Diabolik</span></div>
</div>

<div id="img-index">
<div class="imagem-player"><img src="imagens/fotos-players/3.png"/></div>
<div class="nome-player">Player: <span style="color:#674328"> Matematico</span></div>
</div>

<div id="img-index">
<div class="imagem-player"><img src="imagens/fotos-players/4.png"/></div>
<div class="nome-player">Player:<span style="color:#2D9E2F"> Akyu</span></div>
</div>
</div>

</div>



</div>
<!-- FIM NOTICIAS -->

</section>
<!-- FIM SECTION -->