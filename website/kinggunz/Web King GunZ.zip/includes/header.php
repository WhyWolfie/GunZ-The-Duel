
<?php require "conf/config.php";
require "conf/funcoes.php";
require "conf/Guard.php"; 
define('king', 1);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="description" content="Website Gunz Online">
<meta name="keywords" content="Gunz,Gunz Online,Gunz The Duel">
<meta name="author" content="MatheusDev - Matheus Gomes">
<link rel="shortcut icon" href="favicon.png">
<title>MatheusDev - Web Gunz Online</title>

<!-- CSS PRINCIPAL -->
<link re="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/paginas.css">

<!-- JQUERY -->
<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
<script type="text/javascript">
 $(function () {
 	$("#slide ul").cycle({
 		fx:'fade',
 		speed:2000,
 		timeout:4000,

 	})
 })
</script>
</head>
<body>

<!-- CABEÇALHO -->
<header>

<figure>
<img src="imagens/logo.png" class="logo" alt="Logo do Site"/>
</figure>

</header>
<!-- FIM DO CABEÇALHO -->

<!-- CONTEUDO PRINCIPAL -->
<section id="container">

<nav id="menu">
<ul>
<li><a href="index.php">home</a></li>
<li><a href="?king=cadastro">cadastro</a></li>
<li><a href="?king=download">download</a></li>
<li><a href="?king=ranking">ranking</a></li>
<li><a href="?king=lojas">lojas</a></li>
<li><a href="?king=doacao">doação</a></li>
</ul>
</nav>

<!-- SLIDE -->
<section id="slide-serverinfo">
	<div id="slide">
		<ul>
<li><img src="imagens/slide/1.png" width="752" height="240" /></li>
<li><img src="imagens/slide/2.png" width="752" height="236"/></li>
<li><img src="imagens/slide/3.png" width="752" height="236"/></li>
		</ul>
	</div>
<!-- FIM SLIDE

<!-- SERVER STATUS -->
	<div id="bg-painel">
		<ul>
		<li class="server-status">Status do Servidor</li>
		<li class="game-server">GAME SERVER: <span style="color:#64cb1f"><?php ServerStatus(); ?></span></li>
		<li class="players-online">PLAYERS ONLINE: <span style="color:#fffefe"><?php PlayersOnline();?></span></li>
		<li class="record-online">RECORD ONLINE: <span style="color:#fffefe"><?php RecordOnline();?></span></li>
		<li class="total-contas">CONTAS ATIVAS: <span style="color:#fffefe"><?php TotalDeContas();?></span></li>
		<li class="total-personagem">TOTAL DE CLANS: <span style="color:#fffefe"><?php TotalClans(); ?></span></li>
		</ul>
	</div>
	<!-- FIM SERVER STATUS -->
</section>
<!-- FIM DO SLIDE SERVERINFO -->

