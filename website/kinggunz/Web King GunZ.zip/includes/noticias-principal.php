<!-- NOTICIAS -->

<div id="bg-noticias">
	<div class="title-noticias">Noticias & Atualizações<span class="title-view">Ver Todas</span></div>

<div class="fd-title">
		<div class="icone-noticia"><img src="imagens/news.png" class="icone-news"/></div>
		<div class="titulo-noticia"><a href="?king=noticia1">Lançamento King Gunz 1.5 - 17/08/2015.</a></div>
	</div>

	<!-- ----------------------- 
<div class="fd-title">
		<div class="icone-noticia"><img src="imagens/update.png" class="icone-update"/></div>
		<div class="titulo-noticia"><span class="i-update"><a href="#">Manutenção agendada para este final de semana 25/07/2015.</a></span></div>
	</div>
-->
</div>
<!-- FIM NOTICIAS -->