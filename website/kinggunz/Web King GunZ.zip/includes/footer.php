<!-- RODAPE -->
<footer>
<div class="rodape-copy">
<figure>
<img src="imagens/logo.png" class="logo-rodape" alt="Logo do Site"/>
</figure>
<div class="p-rodape">Copyright © 2015 <span style="color:#dfb554;font-weight:bold;">kinggunz.com.br</span> Todos Direitos Reservados<br>
Gunz é uma marca registrada pela MAIET Entertainment, Inc.<br>
O <span style="color:#dfb554;font-weight:bold;">King Gunz </span>é um servidor privado sem fins financeiros, totalmente gratuito, as doações sao utilizadas<br> para cobrir os gastos do servidor.</div>
</div>
<div class="rodape-creditos">Copyright &copy; Codado por <span style="color:#dfb554;font-weight:bold;">MatheusDEV</span> design por  <span style="color:#dfb554;font-weight:bold;">Ly4mph</span> Versão: <span style="color:#dfb554;font-weight:bold;">1.0 Beta</span></div>
</footer>

</section>
<!-- FIM DO CONTEUDO PRINCIPAL --> 

</body>
</html>