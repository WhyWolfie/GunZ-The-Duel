<!-- ASIDE LOGIN ETC-->
<aside>
 <?
if($_SESSION[AID] == "")
{
?> 
<div id="login-painel">
	<div class="title">Login</div>
	<form name="login" action="?king=logar" method="post">
	<table id="table-login">
	<tr>
	<td><input type="text" name="username" placeholder="Usuário" id="username" maxlength="16" required></td></tr>
	<tr>
	<td><input type="password" name="password" placeholder="Senha" id="password" maxlength="16" required></td></tr>
	<tr>
	<td id="permanecer-logado"><label><input type="radio">Remember me</label></td>
	<td><input type="submit" name="submit" id="logar" value=""></td></tr>
	</form>
	</table>
	<span class="forgot">Forgot <span style="color:#E96404;">Username / Password ?</span></span>
	<a href="cadastro.php"><div id="btn-register">CRIAR CONTA</div></a>
</div>
<div id="bg-donate">
<figure>
<a href="doacao.php"><img src="imagens/btn-donate.png" class="img-donate" alt="Faça uma doação"/></a>
</figure>
<a href="doacao.php"><div class="saiba-mais"></div></a>
</div>
<!--Funcao do Painel de login-->
<?
}else{

$login = antisql($_SESSION["login"]);
$aid23 = antisql($_SESSION['AID']);
    $stuff = mssql_query("SELECT * FROM Account WHERE UserID = '$login'");
    $stuff2 = mssql_fetch_assoc($stuff);

$query3 = mssql_query("SELECT * FROM Account WHERE UserID = '$login' AND UGradeID='253'");
if( mssql_num_rows($query3) == 1 )
{
die("Você foi banido.");
}


$busca25 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login'");
$busca26 = mssql_fetch_row($busca25);

if ($busca26[0] == 255 OR $busca26[0] == 254 OR $busca26[0] == 252 OR $busca26[0] == 0 OR $busca26[0] == 4 OR $busca26[0] == 5 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 2 OR $busca26[0] == 244 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 3 OR $busca26[0] == 8 OR $busca26[0] == 9 OR $busca26[0] == 33 OR $busca26[0] == 44 OR $busca26[0] == 55 OR $busca26[0] == 10 OR $busca26[0] == 11  OR $busca26[0] == 20){

?>
<!--Opcao do Painel-->
<?php include "php/painel.php"; ?>
<?
}
}
// ********************************** //
?>






<?
$res = mssql_query("SELECT TOP 6 * FROM TotalRanking ORDER BY Rank ASC");
?>

<div id="bg-cw">
<div class="title">Ultimas Cws</div>
<table class="ultimas-cw">
<tr class="fd-th">
<th>Vencedor</th>
<th>Score</th>
<th>Perdedor</th>
</tr>
<?
$busca999 = mssql_query("SELECT TOP 6 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
<tr>
<td><!-- clan que ganhou -->
<?=$item22[0]?></td>
<td><!--resultado do vencedor -->
<?=$item22[2]?> x <!-- resultado do perdedor -->
<?=$item22[3]?></td>
<td><!-- clan que perdeu -->
 <?=$item22[1]?></td>
</tr>
<?
}
?>
</table>
</div>
<div id="bg-facebook">
	<div class="title">Facebook</div>
	<div class="frame">
	<iframe src="https://www.facebook.com/plugins/likebox.php?api_key=113869198637480&sdk=joey&height=291&header=true&show_faces=true&stream=true&width=204&href=https://www.facebook.com/pages/The-Duel/406443839557420?fref=ts&colorscheme=light" scrolling="no" frameborder="0" style="border: medium none; overflow: hidden; height: 295px; width: 204px;" allowTransparency="true"></iframe>
</div>
</div>
<div id="bg-trailer">
	<div class="title">Trailler do Mês</div>
	<div class="frame">
	<iframe width="204" height="154" src="https://www.youtube.com/embed/GNOWF0IMmHg" frameborder="0" allowfullscreen></iframe>
	</div>
</div>
</aside>