USE [RPGGAMESGUNZ] 
GO

/****** Object:  Table [dbo].[Perfil]    Script Date: 03/11/2015 18:00:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Perfil](
	[ativar] [nchar](10) NULL,
	[char] [nchar](10) NULL,
	[nome] [nchar](10) NULL,
	[idade] [nchar](10) NULL,
	[sexo] [nchar](10) NULL,
	[cidade] [nchar](10) NULL,
	[msn] [nchar](10) NULL,
	[skype] [nchar](10) NULL,
	[conteudo] [nchar](10) NULL,
	[nick] [nchar](10) NULL,
	[mim] [nchar](10) NULL
) ON [PRIMARY]

GO


