USE [RPGGAMESGUNZ] 
GO

/****** Ao Executar ser� criada a Tabela [dbo].[CustomItemShop] Feito por Matheus Gomes ( Nerva ) data: 24/07/2013 21:27:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[CustomItemShop](
	[CSID] [int] NOT NULL,
	[ItemID] [int] NOT NULL,
	[NewItemOrder] [tinyint] NULL,
	[CashPrice] [int] NOT NULL,
	[WebImgName] [varchar](64) NULL,
	[Opened] [tinyint] NULL,
	[RegDate] [datetime] NULL,
	[RentType] [tinyint] NULL,
	[Name] [varchar](256) NOT NULL,
	[TotalPoint] [int] NULL,
	[ResSex] [tinyint] NULL,
	[ResRace] [tinyint] NULL,
	[ResLevel] [int] NULL,
	[Slot] [tinyint] NULL,
	[Weight] [int] NULL,
	[BountyPrice] [int] NULL,
	[Damage] [int] NULL,
	[Delay] [int] NULL,
	[EffectID] [int] NULL,
	[Controllability] [int] NULL,
	[Magazine] [int] NULL,
	[ReloadTime] [int] NULL,
	[SlugOutput] [tinyint] NULL,
	[Gadget] [int] NULL,
	[HP] [int] NULL,
	[AP] [int] NULL,
	[MaxWeight] [int] NULL,
	[SF] [int] NULL,
	[FR] [int] NULL,
	[CR] [int] NULL,
	[PR] [int] NULL,
	[LR] [int] NULL,
	[BlendColor] [int] NULL,
	[ModelName] [varchar](64) NULL,
	[Description] [varchar](max) NULL,
	[MaxBullet] [int] NULL,
	[LimitSpeed] [tinyint] NULL,
	[IsCashItem] [tinyint] NULL,
	[Control] [int] NULL,
	[Duration] [varchar](64) NULL,
 CONSTRAINT [PK_CustomItemShop] PRIMARY KEY CLUSTERED 
(
	[CSID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


