USE [RPGGAMESGUNZ] 
GO

/****** Object:  Table [dbo].[Suporte]    Script Date: 07/04/2013 20:20:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Suporte](
	[tipo] [nchar](10) NULL,
	[usuario] [nchar](10) NULL,
	[data] [nchar](10) NULL,
	[texto] [nchar](10) NULL,
	[titulo] [nchar](10) NULL
) ON [PRIMARY]

GO


