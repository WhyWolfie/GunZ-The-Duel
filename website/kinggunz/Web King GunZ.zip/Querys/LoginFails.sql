USE [RPGGAMESGUNZ]
GO

/****** Object:  Table [dbo].[LoginFails]    Script Date: 03/11/2015 01:23:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[LoginFails](
	[IP] [varchar](500) NULL,
	[UserID] [varchar](500) NULL,
	[Time] [varchar](500) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


