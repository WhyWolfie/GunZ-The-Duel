﻿
<?php
//Act GunZ Online By Sparrow
$link = mssql_connect("Tu-PC\SQLEXPRESS","sa","pass");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Act GunZ Connected

$DBHost = '179.155.100.215,1433'; //Sparrow SQL
$DBUser = 'DestinyGames'; //Your DB User
$DBPass = '!@#$rpgonline'; //Sparrow Senha
$DB = 'RPGGAMESGUNZ'; //Sparrow GunZ DB

//Configurações "Ultimas Do Fórum"
$link25 = "http://link/forum/"; //Link do seu forum!
$server = "localhost"; //Nome do servidor do Mysql (Padrão:localhost)
$dbnamef = "forum"; // Indique o nome do banco de dados (Database do fórum)
$usuario = "root"; // Indique o nome do usuário que tem acesso
$password = "senha mysql"; // Indique a senha do usuário
$mode = "off"; //Se o modo estiver "on" é porque esta ativado, se tiver "off" é porque esta desativado
?>
