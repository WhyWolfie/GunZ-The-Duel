<?php
/* 	                               Nova Digital - Sua Marca na Web.
                              NERVA GUARD - PROTEÇÃO PARA WEBSITE 2014
															  

ANTIDDOS , ANTI SQL INJECTIONS , ANTI UPDATE , ANTI INVASÃO , ANTI REPLACE NA URL , BLOQUEIO DE CARACTERES , RESTRIÇÃO , ENTRE OUTROS. 

*/
?>


<?php

/*---------------------------------------------------------------------------------------

                                  ANTI DDOS
								  
Função: Bloqueia o Acesso se o IP entrar muitas veses por segundo no seu WEBSITE.

-----------------------------------------------------------------------------------------*/

$crlf=chr(13).chr(10);
$itime=3;  //Minimum number of seconds between one-visitor visits
$imaxvisit=10;  //Maximum visits in $itime x $imaxvisits seconds
$ipenalty=($itime * $imaxvisit);  //Minutes for waitting
$iplogdir="./NervaGuard/LogDeAtacks/";
$to      = 'gunz@kaosgunz.com';
$headers = 'From: Nerva Guard - Proteção DDOS' . "\r\n";
$subject = "Atenção. Possivel Atack DDos detectado em $today:$min:$sec";
  

//Warning Messages:
$message1='<font color="red">Nerva Guard - Anti DDOS</font><br>';
$message2='Por favor aguarde ... ';
$message3=' segundos para voltar ao nosso site.<br>';
$message4='<font color="blue">Você está atacando nosso site com DDOS.</font><br>Se você for humano troque de ip.<br>Seu IP foi banido do nosso servidor <b>'.$_SERVER["REMOTE_ADDR"].' </b>por ataque de DDOS.';

//---------------------- FIM DA INICIAÇÃO ---------------------------------------  

//Get file time:
$ipfile=substr(md5($_SERVER["REMOTE_ADDR"]),-3);  // -3 means 4096 possible files
$oldtime=0;
if (file_exists($iplogdir.$ipfile)) $oldtime=filemtime($iplogdir.$ipfile);

//Update times:
$time=time();
if ($oldtime<$time) $oldtime=$time;
$newtime=$oldtime+$itime;

//     Check human or bot:
if ($newtime>=$time+$itime*$imaxvisit)
{
	//     To block visitor:
	touch($iplogdir.$ipfile,$time+$itime*($imaxvisit-1)+$ipenalty);
	header("HTTP/1.0 503 Service Temporarily Unavailable");
	header("Connection: close");
	header("Content-Type: text/html");
	echo '<html><head><title>Nerva Guard - ANTI DDOS</title></head><body><p align="center"><strong>'
	      .$message1.'</strong>'.$br;
	echo $message2.$ipenalty.$message3.$message4.$message6.'</p></body></html>'.$crlf;
	//     Mailing Warning Message to Site Admin
	{
		@mail($to, $subject, $message5, $headers);
	}
	//     logging:
	$fp=@fopen($iplogdir.$iplogfile,"a");
	if ($fp!==FALSE)
	{
		$useragent='<unknown user agent>';
		if (isset($_SERVER["HTTP_USER_AGENT"])) $useragent=$_SERVER["HTTP_USER_AGENT"];
		@fputs($fp,$_SERVER["REMOTE_ADDR"].' on '.date("D, d M Y, H:i:s").' as '.$useragent.$crlf);
	}
	@fclose($fp);
	exit();

}

//Modify file time:
//touch($iplogdir.$ipfile,$newtime);

?>

<?php
/*
---------------------------------------------------------------------------------------

                                   ANTI SQL INJECTION - FORMA I
								   
Função: Bloqueia modificação na url , manibulação do banco de dados e Varios meios de Injeção WEB

---------------------------------------------------------------------------------------
 */


$xa = getenv('REMOTE_ADDR');
$badwords = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--"); 

foreach($_POST as $value) 
foreach($badwords as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Operação Bloqueada - [ Nerva Guard ]'); location='javascript:history.back()'</script>");
?>



<?
/*
---------------------------------------------------------------------------------------

                                   ANTI SQL INJECTION - FORMA II
								   
Função: Bloqueia modificação na url , manibulação do banco de dados e Varios meios de Injeção WEB

---------------------------------------------------------------------------------------
 */
 function re_dir($url){
echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";

}
function antisql($value)
{
	global $sgz;

    $check = $value;

    $search = array(
        'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20',
		'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr',
		'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir',
		'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=',
		'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(',
		'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(',
		'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(',
		'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like',
		'like%20', '$_request', '$_get', '$request', '$get', 'HTTP_PHP', '&aim', '%20getenv',
		'getenv%20', 'new_password', '&icq', '/etc/password', '/etc/shadow', '/etc/groups',
		'/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a',
		'/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+',
		'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
		'/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://',
		'window.open', '<script>', 'javascript\://', 'img src', 'img%20src', '.jsp', 'ftp.exe',
		'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
		'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
		'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20',
		'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache',
		'/servlet/con', '<script', 'UPDATE', 'updateupdateupdate', 'SELECT', 'DROP', '/robot.txt',
		'/perl', 'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20',
		'truncate', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?', '?>', 'sql=', 'shutdown',
		'backup', 'database', 'to disk'
    );

    $value = str_replace($search, '', $value);
	$value = preg_replace(sql_regcase("/(create|database|from|select|update|insert|delete|alter|drop|truncate|where|shutdown|column|drop table|truncate table|show tables|#|\*|--|\\\\)/"), "", $value);
	$value = str_replace($search, '', $value);
	$value = preg_replace(sql_regcase("/(create|database|from|select|update|insert|delete|alter|drop|truncate|where|shutdown|column|drop table|truncate table|show tables|#|\*|--|\\\\)/"), "", $value);
    $value = str_replace($search, '', $value);
	$value = preg_replace(sql_regcase("/(create|database|from|select|update|insert|delete|alter|drop|truncate|where|shutdown|column|drop table|truncate table|show tables|#|\*|--|\\\\)/"), "", $value);

	$value = trim($value);
	$value = strip_tags($value);
	$value = addslashes($value);
	$value = str_replace("'", "''", $value);

    if ($check != $value)
    {
        die("<script>alert('Operação Bloqueada - [ Nerva Guard ]';location='javascript:history.back()'</script>");

        }
        return( $value );
}
?>


<? 
/*
---------------------------------------------------------------------------------------

                                   ANTI SQL INJECTION -  FORMA III
								   
Função: Bloqueia modificação na url , manibulação do banco de dados e Varios meios de Injeção WEB

---------------------------------------------------------------------------------------
 */
function writeToLogFile($msg)
{
	$today = date("Y_m_d"); 
	$logfile = "NervaGuard/LogAntiSQL/".$today."antisqlll.txt"; 
	$dir = '';
	$saveLocation=$logfile;
	$fp = @fopen( $saveLocation,"r");
	$Data = @fread($fp, 800000);

	if (!$handle = @fopen($saveLocation, "w+b"))
	{
		echo "error";
		exit;
	}
	else
	{
		if(@fwrite($handle,"$msg\r\n Operação Bloquiada. [ Nerva Guard ].\r\n$Data")===FALSE) 
		{
			echo "geen error";
			exit;
		}
		@fclose($handle);
	}
}

function anti_injection($value)
{
        $value = preg_replace(sql_regcase("/(from|select|union|exec|varchar|0x|cast|update|set|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
        return( $value );
}


function valida($campos)
{
	foreach($campos as $c)
	{
		if(empty($c))
		{ 
			echo "Operação Bloquiada. [ Nerva Guard ]."; 
			$time = date("M j G:i:s Y"); 
			$ip = getenv('REMOTE_ADDR');
			$userAgent = getenv('HTTP_USER_AGENT');
			$referrer = getenv('HTTP_REFERER');
			$query = getenv('QUERY_STRING');
			$msg = "IP: " . $ip . " TIME: " . $time . " REFERRER: " . $referrer . " SEARCHSTRING: " . $query;
		
			writeToLogFile($msg);
			return false;
		}
		else
		{
        		return true;
		}
	}
}
?> 


<?
/*
---------------------------------------------------------------------------------------

                                   ANTI SQL INJECTION - FORMA IIII
								   
                       Função: Bloqueia algumas formas de injecão na DB.

---------------------------------------------------------------------------------------
 */
$ip = getenv('REMOTE_ADDR');
$requested = stripslashes($_SERVER['REQUEST_URI']);

foreach($_POST as $post)
if(eregi("^0-9a-zA-Z_@.?<>", $post)){
$posted = stripslashes($post);
$qIps = mssql_query("Select memb___id From MEMB_STAT Where ip='".$ip."'");
if(mssql_num_rows($qIps) <= 0){
}else{
	for($a=0;$a<mssql_num_rows($qIps);$a++){
		$name = mssql_fetch_row($qIps);
}
die("<script>alert('Operação Bloqueada - [ Nerva Guard ]'); location='javascript:history.back()'</script>");
}
foreach($_GET as $get)
if(eregi("[^0-9a-zA-Z_@$]", $get)){
$qIps = mssql_query("Select memb___id From MEMB_STAT Where ip='".$ip."'");
if(mssql_num_rows($qIps) <= 0){
	fwrite($fp, "  Nenhum \n ============== \n");
}else{
	for($a=0;$a<mssql_num_rows($qIps);$a++){
		$name = mssql_fetch_row($qIps);
}
die("<script>alert('Operação Bloqueada - [ Nerva Guard ]'); location='javascript:history.back()'</script>");
} 
foreach($_COOKIE as $cookie)
if(eregi("[^0-9a-zA-Z_@_$]", $cookie)){
$qIps = mssql_query("Select memb___id From MEMB_STAT Where ip='".$ip."'");
if(mssql_num_rows($qIps) <= 0){
	fwrite($fp, "  Nenhum \n ============== \n");
}else{
	for($a=0;$a<mssql_num_rows($qIps);$a++){
		$name = mssql_fetch_row($qIps);
}}}}}
?>



<?
/*-------------------------------------------------------------------------

                         ANTI SQL INJECTION - FORMA IIIII
								   
Função: Bloqueia algumas formas de injecão na DB , Alteração de URL Entre outras em GERAL.

---------------------------------------------------------------------------

 */
@session_start();
function makepoststring($string) {
    if (strlen($string) > 17){
        return ucfirst(substr($string,0,17) . "...");
    }else{
        return ucfirst($string);
    }
}

function clean($value)
{
        $check = $value;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=', '/');

        $value = str_replace($search, '', $value);
        $value = str_replace(sql_regcase("/(shutdown|'|RubyDBMS|backup|select|request|from|insert|delete|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables|name|password|login|account|login|clan|0x|;|character|set|where|#|\|*|;|//;/|;/;|;/*|;/*;|/*/;|/*/;/|\\;\*|;/|*;/|//;|)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
        if( $check != $value )
        {
die("<script>alert('Operação Bloqueada - [ Nerva Guard ]';location='javascript:history.back()'</script>");

        }
        return( $value );
}

/*-------------------------------------------------------------------------

                           FUNÇÃO DO SQL

---------------------------------------------------------------------------

 */


function mssql_query_logged($query)
{

     return mssql_query($query);
}

/*-------------------------------------------------------------------------
                              -      EXTRAS  -  

                               JAVASCRIPT ( MSGBOX )

---------------------------------------------------------------------------

 */

function msgbox($text, $url){
echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>"; 
}

/*-------------------------------------------------------------------------

                           JAVASCRIPT ( REDIRECIONAR )

---------------------------------------------------------------------------


 */


/*-------------------------------------------------------------------------

                           JAVASCRIPT ( OUTROS )

---------------------------------------------------------------------------


 */
function GetKDRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}



function FormatCharName($cid)
{
    $ncid = clean($cid);
    $res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character(nolock) ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));

    $name = $res[1];

    switch($res[0])
    {
        case 2:
            return "<font color='#51FA79'>$name</font>";
        break;
        case 4:
            return "<font color='#7D26CD'>$name</font>";
        break;
        case 5:
            return "<font color='#EE7600'>$name</font>";
        break;
        case 6:
            return "<font color='#FFFF00'>$name</font>";
        break;
        case 7:
            return "<font color='#00CED1'>$name</font>";
        break;
        case 8:
            return "<font color='#696969'>$name</font>";
        break;
        case 9:
            return "<font color='#191970'>$name</font>";
        break;
		case 14:
            return "<font color='#ff0000'>$name</font>";
        break;
		case 17:
            return "<font color='#1E90FF'>$name</font>";
        break;
        case 255:
            return "<font color='FF6600'>$name</font>";
        break;
        case 252:
            return "<font color='FF0000'>$name</font>";
        break;
        default:
            return $name;
        break;
    }
}
?>



<?php
/*-------------------------------------------------------------------------

                           JAVASCRIPT ( BOX )

---------------------------------------------------------------------------


 */
function ErrorBox($data) {
    return "                               <br><tr>
											<td width='434' colspan='2'>
											<div align='center'>
												<table border='1' width='90%' height='90%' style='border-collapse: collapse' bordercolor='#FF0000' bgcolor='#FF9191' class='errorbox'>
													<tr>
														<td>
														<table border='0' width='100%' height='100%' style='border-collapse: collapse'>
															<tr>
																<td valign='bottom' width='434' colspan='2'>
														<img border='0' src='images/icon_error.gif' width='16' height='17'>
														<font size='1'><b>An error occurred!</b></font></td>
															</tr>
															<tr>
																<td width='19'>&nbsp;</td>
																<td width='434' valign='top'><b>$data</b></td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width='8'>&nbsp;</td>
										</tr>
										<tr>
											<td width='145'>
											&nbsp;</td>
											<td width='289'>
											&nbsp;</td>
											<td width='8'>&nbsp;</td>
										</tr>";
}

?>
