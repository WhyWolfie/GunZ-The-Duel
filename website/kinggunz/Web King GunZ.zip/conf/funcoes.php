<?php


//sERVIDOR ON / OFF
function ServerStatus () {
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = '';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<font color='green'>ONLINE</font>";
        }
        else
        {
            echo "ONLINE";
            fclose($fp);
        }
    }
    
    }

//TOTAL DE JOGADORES ONLINE
    function PlayersOnline() {
        $res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "<font style='color: #fffefe'>$servercount</font>";
    
    }

    //RECORD ONLINE
    function RecordOnline() {
    $b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
    echo $b['PlayerCount'];
}

// total de contas
function TotalDeContas() {
$statisticactiveacc = mssql_query("SELECT * FROM Login WHERE LastConnDate!=NULL");
$activeaccounts = mssql_num_rows($statisticactiveacc);
echo "$activeaccounts";
}


// TOTAL CLANS
function TotalClans(){
$statisticclansquery = mssql_query("SELECT * FROM Clan");
$clansrows = mssql_num_rows($statisticclansquery);
echo "$clansrows";
}

// RESTRIÇÃO LOGIN
function ResticaoLogin() {
$login = antisql($_SESSION["login"]);
$aid23 = antisql($_SESSION['AID']);
$stuff = mssql_query("SELECT * FROM Account WHERE UserID = '$login'");
$stuff2 = mssql_fetch_assoc($stuff);

$query3 = mssql_query("SELECT * FROM Account WHERE UserID = '$login' AND UGradeID='253'");
if( mssql_num_rows($query3) == 1 ) {
die("Você foi banido.");
}
$busca23 = mssql_query("SELECT RZCoins, EVCoins FROM Login WHERE UserID = '$login'");
$busca24 = mssql_fetch_row($busca23);

$busca25 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login'");
$busca26 = mssql_fetch_row($busca25);

if ($busca26[0] == 255 OR $busca26[0] == 254 OR $busca26[0] == 252 OR $busca26[0] == 0 OR $busca26[0] == 4 OR $busca26[0] == 5 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 2 OR $busca26[0] == 244 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 3 OR $busca26[0] == 8 OR $busca26[0] == 9 OR $busca26[0] == 33 OR $busca26[0] == 44 OR $busca26[0] == 55 OR $busca26[0] == 10 OR $busca26[0] == 11  OR $busca26[0] == 20){

}
}

// ALERTA

?>