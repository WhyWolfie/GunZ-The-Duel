
<?php

unset($_SESSION['UserID']);
unset($_SESSION['Login']);
unset($_SESSION['AID']);
unset($_SESSION['UGradeID']);
unset($_SESSION['Senha']);
session_unset();
$_SESSION = array();

msgbox("Conta deslogada. Estamos redirecionando você !","index.php");

?>
<META HTTP-EQUIV="Refresh" CONTENT="2 ; URL=index.php">