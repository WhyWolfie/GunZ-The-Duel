
<?php

$ip = $_SERVER['REMOTE_ADDR'];  
$script = $_SERVER[PATH_TRANSLATED];  
$fp = fopen ("logs/cadastro_logs.txt", "a+");  
$sql_inject_1 = array(";","'","%",'"'); #Whoth need replace  
$sql_inject_2 = array("", "","","&quot;"); #To wont replace  
$GET_KEY = array_keys($_GET); #array keys from $_GET  
$POST_KEY = array_keys($_POST); #array keys from $_POST  
$COOKIE_KEY = array_keys($_COOKIE); #array keys from $_COOKIE  
/*begin clear $_GET */  
for($i=0;$i<count($GET_KEY);$i++)  
{  
$real_get[$i] = $_GET[$GET_KEY[$i]];  
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]]));  
if($real_get[$i] != $_GET[$GET_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: GET\r\n");  
fwrite ($fp, "Value: $real_get[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_GET */  
/*begin clear $_POST */  
for($i=0;$i<count($POST_KEY);$i++)  
{  
$real_post[$i] = $_POST[$POST_KEY[$i]];  
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]]));  
if($real_post[$i] != $_POST[$POST_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: POST\r\n");  
fwrite ($fp, "Value: $real_post[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_POST */  
/*begin clear $_COOKIE */  
for($i=0;$i<count($COOKIE_KEY);$i++)  
{  
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]];  
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]]));  
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: COOKIE\r\n");  
fwrite ($fp, "Value: $real_cookie[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  

/*end clear $_COOKIE */  
fclose ($fp);  
?>
<?
$errorcode = "";
$emailErro = "";
$loginErro = "";
$senhaErro = "";
$csenhaErro = "";
$perguntasecretaErro = "";
 $respostasecretaErro = "";

$er = 0;

$registered = 0;

if (isset($_POST['submit'])){

$user = antisql($_POST['userid']);

$email = antisql($_POST['email']);
 
$pw1 = antisql($_POST['pw1']);

$pw2 = antisql($_POST['pw2']);

$country = antisql($_POST['country']);

$sq = antisql($_POST['sq']);

$sa = antisql($_POST['sa']);

$name = antisql($_POST['name']);
$zip = antisql($_POST['zip']);
$age = antisql($_POST['age']);
$sex = antisql($_POST['sex']);
$address = antisql($_POST['address']);

$szcod = antisql($_POST['cod']);

if($szcod != $_SESSION[COD])
{

$errorcode.="Codigo incorreto.";
         $er = 1;
		}


$res = mssql_query("SELECT * FROM Account WHERE email = '".$email."'");
if (mssql_num_rows($res) >= 1){
$emailErro.="E-Mail em uso.";
            $er = 1;
        }


$res = mssql_query("SELECT * FROM Login WHERE UserID = '".$user."'");
if (mssql_num_rows($res) >= 1){

$loginErro.="Login em uso.";
            $er = 1;
        }

if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
$senhaErro.="As senhas sao diferentes.";
            $er = 1;
        }

if($user == ""){
            $loginErro.="Coloque um Login.";
            $er = 1;
        }if($email == ""){
            $emailErro.="Coloque um e-mail.";
            $er = 1;
        }


if(strlen($pw1) < 6){
            $senhaErro.="Use senhas com 6 ou mais caracteres.";
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $senhaErro.="Coloque uma senha.";
            $er = 1;
        }


        if($sq == ""){
            $perguntasecretaErro.="Digite uma pergunta secreta.";
            $er =1;
        }

        if($sa == ""){
            $respostasecretaErro.="Digite uma resposta secreta.";
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, ZipCode, Address)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$zip', '$address')");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins])VALUES('$user','$aid','$pw1',130,100)");			//mssql_query("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            //$errorbox = msgbox($errorcode,"?king=cadastro");
        }
}

			global $palavra;
			$palavra = rand(1111111111, 9999999999);
			$_SESSION[palavra] = $palavra;

if ($registered == 0){		
?>
<? echo @$errorbox ?>

<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">
<div class="title-formulario">Cadastro</div>	
<div class="msg-formulario">A sua privacidade é importante para nós. Não forneça sua senha para desconhecidos.</div>
<div class="form-grande">
<form method="post" action="?king=cadastro">
<table class="fundo-cadastro">
<tr>
<td>Login ID :</td>
<td><input type="text" name="userid" id="form-usuario" value="<?php echo $user ?>"></td>
<td><span class="isa_error"><?php echo $loginErro;?></span></td>
</tr>

<tr>
<td>Senha : </td>
<td><input type="password" name="pw1" id="form-senha" value="<?php echo $pw1 ?>"></td>
<td><span class="isa_error"><?php echo $senhaErro;?></span></td>
</tr>

<tr>
<td>Confirmar Senha :</td>
<td><input type="password" name="pw2" id="form-csenha" value="<?php echo $pw2 ?>"></td>
<td><span class="isa_error"><?php echo $senhaErro;?></span></td>
</tr>
</table>
</div>

<div class="msg-formulario msg-pos">Por favor insira um endereço de e-mail válido.</div>
<div class="bg-email">
<table class="fundo-cadastro">
<tr>
<td>Email :</td>
<td><input type="email" name="email" id="form-email" value="<?php echo $email ?>"></td>
<td><span class="isa_error"><?php echo $emailErro;?></span></td>
</tr>
</table>
</div>

<div class="msg-formulario msg-pos">A pergunta e resposta de segurança é utilizado para recuperar senhas perdidas ou esquecidas.
</div>
<div class="bg-pergunta">
<table class="fundo-cadastro">
<tr>
<td>Pergunta Secreta :</td>
<td><input type="text" name="sq" id="form-pergunta" value="<?php echo $sq ?>"></td>
<td><span class="isa_error"><?php echo $perguntasecretaErro;?></span></td>
</tr>
<tr>
<td>Resposta Secreta :</td>
<td><input type="text" name="sa" id="form-pergunta" value="<?php echo $sa ?>"></td>
<td><span class="isa_error"><?php echo $respostasecretaErro;?></span></td>
</tr>
</table>	
</div>
<div class="msg-termos msg-pos-2"><span style="color:red;">Atenção</span> : ao clicar em cadastrar, você concorda com os termos do <span style="color:#fd6d03;">King Gunz</span>
</div>
<table align="center">
<td>
<td><input type="submit" id="btn-cadastrar" value="" alt="Criar conta" name="submit"></td>
<td><input type="reset" value="" id="btn-limpar" alt="Limpar formulario"></td>
</td>
</table>
</form>
</div>
<!-- FIM CADASTRO -->
<?
}else {
	msgbox("Conta criada com sucesso!, Bom jogo.","index.php");
?>				
									
											
							
								
					
<?
}
?>
</div>
</section>