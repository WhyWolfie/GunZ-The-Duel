<section id="fundo-paginas">
<div class="title-formulario">Painel de Usuario</div>	
<div class="msg-formulario"><strong>Opções da Conta</strong></div>

<div class="bolha">Name Color</div>
<a href="?king=mudarsenha"><div class="bolha">Mudar Senha</div>
<div class="bolha">Recuperar Personagem</div>
<div class="bolha">Doação</div><br><br>
<div class="bolha">Recuperar Senha</div>
<div class="bolha">Editar Dados</div>
<br><br><br><br>

<div class="msg-formulario"><strong>Opções Personagem</strong></div>

<a href="?king=mudarsexo"><div class="bolha">Mudar Sexo</div></a>
<a href="?king=criarclan"><div class="bolha">Criar Clan</div>
<div class="bolha">Deletar Clan</div>
<div class="bolha">Resetar Clan</div>
<div class="bolha">Recuperar Personagem</div>

</section>
