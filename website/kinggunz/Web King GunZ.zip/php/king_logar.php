
<?
session_start();
if(isset($_POST[submit]))
{

    $user = ($_POST[username]);
    $pass = ($_POST[password]);

    $ip = $_SERVER['REMOTE_ADDR'];

    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
	
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
	msgbox("Você falhou 5 vezes para efetuar o login, aguarde 15 minutos e tente novamente.","index.php");
}
    $loginquery = mssql_query("SELECT UserID, AID, Password FROM Login WHERE UserID = '$user' AND Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION["login"] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];
        $_SESSION[Senha] = $logindata[2];
        msgbox("Logado com sucesso!, Aguarde estamos redirecionando você.","index.php");

    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
    msgbox("Usuario ou senha incorretos.","index.php");
	}

}else{
echo "Você quer logar sem senha e login ? O_O";
}
?>