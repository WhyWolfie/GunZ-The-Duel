


<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Mudar Senha</div>
<?

if ($_SESSION['AID'] == ""){

die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$login22 = ($_SESSION["login"]);

if (!(isset($_POST['senha1'])))
{
?><Br /><Br />
<center>
<form id="site_Login" name="site_Login" method="post" action="?king=mudarsenha">
<input type="password" id="senha1" value="Senha" class="log_field" size="25" name="senha1" value="" maxlength="20">  <-- Digite sua senha atual<br><Br />
<input type="password" id="senha2" value="Senha" class="log_field" size="25" name="senha2" value="" maxlength="20">  <-- Digite sua nova senha<br>
<br />
<font color="red" size="-2"> Essa ação não poderá ser revertida, você ter certeza que deseja mudar?</font>
<br><br>
<input type="submit" name="logar" class="button validate" value="Alterar!"/>
</form>
<br><br><br><br>
<?
}else{

$senha1 = clean($_POST['senha1']);
$senha2 = clean($_POST['senha2']);

$busca22 = mssql_query("SELECT Password FROM Login WHERE UserID = '$login22'");
$busca23 = mssql_fetch_row($busca22);

if ($busca23[0] == $senha1){
mssql_query("UPDATE Login SET Password = '$senha2' WHERE UserID = '$login22'");
{
	msgbox("Senha Alterada Com Sucesso!","index.php");
}
}else{
{
msgbox("A sua senha atual nao confere com a que temos em nosso sistema. Tente Novamente.");
}
}
}
}
?>
</center>
</section>
