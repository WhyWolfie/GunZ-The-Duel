
<meta charset="utf-8">
<?php
if( $_SESSION['AID'] == "" )
{
msgBox("Você não tem permissão, Logue-se Primeiro!","index.php");
    die();
}
?>
<?
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan não existe","index.php");
exit();
}

$clid = $clan->CLID;
?>
<?
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan não existe","index.php");
exit();
}

$clid = $clan->CLID;
?>


    <!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Informações do clan  <strong>( <?=$clan->Name?> ) </strong></div>


<br><br>
<center>
<table class="tabela-claninfo">
								

                          <tr>
                            <td align="center">
                              <div align="left" style="position:relative;top:130px;"><img src="imagens/logo2.png" width="150" height="100" BORDER=5 ></br></br></br>
                            </div></td>
</tr>
                          <tr>
                            <td bgcolor="" class="Estilo1" align="center" valign="top">
<table class="tabela-claninfo-2">
                              
                                  </center>
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Win:</td>
                                    <td width="435" align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Loser:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
								  <tr>
                                      <td align="left" class="estilo1">Pontos: </td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Clan Criado Em:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Total de membros:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                  <center>
                                    <td width="126"><div align="center"></div></td>
                                  </center>
                              </table>                                </td>
      </tr>
                            
                              <tr>
                                <td align="center" valign="top"><table>
&nbsp;
                                  <tr>
                                    <td width="124" align="center" class="estilo1"><u>Char</u></td>
                                    <td width="190" align="center" class="estilo1"><u>Gradua&ccedil;&atilde;o</u></td>
                                    <td width="129" align="center" class="estilo1"><u>Data de Inclus&atilde;o </u></td>
                                    <td width="138" align="center" class="estilo1"><u>Pontos</u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Membro";
    break;
    case "2";
       $grade = "Administrador";
    break;
    case "1";
       $grade = "Lider";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><a href="index.php?king=charinfo&id=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                      </table>
</center>
</section>