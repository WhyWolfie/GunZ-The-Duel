<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="title-noticias">Downloads</div>
<div class="msg-formulario down">Escolha uma das opções abaixo :</div>
<div class="form-download">
	<figure>
	<img src="imagens/download/4shared.png"/>
	<img src="imagens/download/mega.png"/>
	<img src="imagens/download/mediafire.png"/>
	</figure>
</div>
<div class="msg-formulario down">Depois de baixar siga esses passos :</div>
<div class="passos">
	<textarea name="guia-instalacao" class="guia-instalacao">
1 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur s
int occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 

2 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur s
int occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

3 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur s
int occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

4 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur s
int occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
	
5 - Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et 
dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur s
int occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

	</textarea>

</div>
<!-- -------------- -->
<!-- ##############  -->

</section>