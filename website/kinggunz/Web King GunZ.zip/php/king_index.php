
<!-- RANKING PLAYER-->
<div id="ranking">
	<ul>
	<li>Ranking Player <a href="#"><span class="view-all">Ver +</span></a></li>
	</ul>
	<?
$res = mssql_query("SELECT TOP 5 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<table class="tb-rank">
	<tr class="fd-th">
			<th width="25px">#</th>
			<th>Nome</th>
			<th width="25px">Lvl</th>
		</tr>
                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="64">;</td>
										<td width="93"><center>Nemhum Clan.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>

<tr>
        <td><div class="rk1"><?=++$count ?></div></td>
		<td><a href="?king=charinfo&amp;id=<?=$clan['CID']?>"><?=$clan['Name']?></a></td>
		<td> <?=$clan['Level']?></td>
		</tr>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                           <?}}?>
									

</table>
</div>
<!-- FIM PLAYER RANKING -->

<!-- RANKING CLAN -->
<div id="ranking">
	<ul>
	<li>Ranking Clan <a href="#"><span class="view-all">Ver +</span></a></li>
	</ul>
	<?
$res = mssql_query("SELECT TOP 5 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
$count = 0;
?>
<table class="tb-rank">
	<tr class="fd-th">
			<th width="25px">#</th>
			<th>Clã</th>
			<th width="25px">Pts.</th>
		</tr>
                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="64">;</td>
										<td width="93"><center>Nemhum Clan.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>

<tr>
        <td><div class="rk1"><?=++$count ?></div></td>
		<td><a href="?king=claninfo&amp;id=<?=$clan['CLID']?>"><?=$clan['Name']?></a></td>
		<td><?=number_format($clan['Point'],0,'','.');?></td>
		</tr>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
                           <?}}?>
									

</table>
</div>
<!-- FIM RANKING CLAN -->

<!-- RANKING DUEL TOURNAMENT -->
<div id="ranking">
	<ul>
	<li>Ranking PlayerWar <a href="#"><span class="view-all">Ver +</span></a></li>
	</ul>
	
	<br><br><br>
<center>
	EM BREVE !
</center>
									

</table>
</div>
<!-- FIM RANKING DUEL TOURNAMENT -->


<?php include 'includes/noticias-principal.php' ?>
