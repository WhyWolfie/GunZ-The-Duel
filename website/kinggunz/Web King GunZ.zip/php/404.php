<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Pagina em Construção !</div>

<center><span class="erro">404</span>
<br>
<h2>Pagina em Construção !</h2>
<p style="font-family:arial;font-size:12px;">
A página que você esta tentando acessar ainda não está disponivel ou não existe, caso esteja ocorrendo algum tipo de erro,
entre em contato<br> com a nossa equipe através do <span style="color:#fd6d03;">TICKET</span>, que iremos dar total suporte para você.<br><br>
</p>
<button>VOLTAR</button>
</center>





<!-- -------------- -->
<!-- ##############  -->
</section>