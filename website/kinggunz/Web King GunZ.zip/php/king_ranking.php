<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Rankings</div>

<div class="fd-ranking">
	<div class="title-ranking">
	<a href="?king=ranking">Individual Ranking</a> / <a href="?king=rankclan">Clan Ranking</a>
	</div>
<?
$res = mssql_query_logged("SELECT TOP 20 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
	<div class="bg-procurar-player">
	<span style="color:#8d8e8c;font-size:14px;float:left;margin-left:22px;margin-top:2px;">Procurar Player :</span>
		<form>
		<input type="text" class="btn-procurar">
		</form>
	</div>

	<div class="procurar-fundo-rank">
		<div class="title-procurar-rk">
			<table class="procurar-th">
			<th width="70px">#</th>
			<th>Nome</th>
			<th>Level</th>
			<th>XP</th>
			<th>Kills</th>
			<th>Deaths</th>
			<tr>
			<td><br></td>
			</tr>
		<?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="68"></td>
										<td width="90"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
		</tr>
		<tr>
		<td><?=++$count ?></td>
		<td><a href="?king=charinfo&amp;id=<?=$clan['CID']?>"><?=$clan['Name']?></a></td>
		<td><?=$clan['Level']?></td>
		<td><?=$clan['XP']?></td>
		<td><?=$clan['KillCount']?></td>
		<td><?=$clan['DeathCount']?></td>
		</tr>

		<?}}?>
			
		</table>
		</div>
	</div>
	<div class="btn-numeros"><a href="#">1</a></div>
	<div class="btn-numeros"><a href="#">2</a></div>
	<div class="btn-numeros"><a href="#">3</a></div>
	<div class="btn-numeros"><a href="#">4</a></div>
	<div class="btn-numeros"><a href="#">5</a></div>
	<div class="btn-numeros"><a href="#">6</a></div>
	<div class="btn-numeros"><a href="#">7</a></div>
	<div class="btn-numeros"><a href="#">8</a></div>
</div>





<!-- -------------- -->
<!-- ##############  -->
</section>