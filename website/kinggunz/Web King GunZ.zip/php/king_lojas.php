	<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Selecione a Loja desejada</div>

<figure class="selecione">
<a href="?king=rzitemshop&sub=listallitems&expand=1&type=1"><img src="imagens/shop/img-donate.png"/></a>
<br><br>
<a href="?king=lojaevento"><img src="imagens/shop/img-evento.png"/>
<br><br>
<a href="?king=lojacustom"><img src="imagens/shop/img-custom.png"/>
</figure>






<!-- -------------- -->
<!-- ##############  -->

</section>