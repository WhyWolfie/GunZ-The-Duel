	<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Lançamento King Gunz 1.5 - 17/08/2015.</div>
<p style="margin-left:25px;">
È com muito prazer que anunciamos o lançamento do King Gunz, curta esse incrível servidor que pretente trazer diversão
para todos os jogadores.
</p>




<!-- -------------- -->
<!-- ##############  -->

</section>