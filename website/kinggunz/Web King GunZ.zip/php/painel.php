	<div id="login-painel">
	<ul class="opcoes-painel">
	<li><strong>Bem vindo de novo,<br> <font color="#FFA042"> <?=$_SESSION['UserID']?></font>.</strong></li><br>
	<li><a href="?king=doacao"><img src="imagens/ponto.png"/>&nbsp;&nbsp;CASH:&nbsp;<?echo "$busca24[0]";?></a> - <span style="color:#FFA042">COMPRAR MAIS</span><br />
	<li><a href="?king=doacao"><img src="imagens/ponto.png"/>&nbsp;&nbsp;Event Coins:&nbsp;<?echo "$busca24[1]";?></a><br /><br />
	<li><a href="?king=doacao">Email: <?=$email?><br />
	<li><a href="?king=doacao">Banco: 0 Itens</a><br /><br />
	<li><a href="?king=conta"><strong><center>Opcoes da sua Conta</center></strong></a>
	<li><a href="?king=deslogar"><img src="imagens/sair.png" class="btn-sair" /></a><bR />
	</div>