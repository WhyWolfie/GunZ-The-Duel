<!-- FORMULARIO DE CADASTRO -->
<section id="fundo-paginas-doacao">

<!-- CONTEUDO VAI AQUI -->
<div class="msg-formulario down">Doação</div>

<div class="txt-doacao">
<span class="txt-span">
<span style="color:#fd6d03;">King Gunz</span> é uma organizaçao sem fins lucrativos, portanto, com exclusão de qualquer responsabilidade jurídica, civil ou fiscal, portanto<br>
os serviços prestados aqui são todos gratuitos, estes são apenas benefícios para as pessoas que escolhem nos apoiar, lembrando <br>
mais uma vez que não e um serviço pago, esses são privilegios para quem faz doações.
</span>
</div>

<div class="msg-formulario down-2">Confirmar doação</div>

<div class="txt-min-doacao">
<span class="txt-min">

Após efeutar o pagamento da doação, você deve enviar os dados do pagamento para o E-mail : <span style="color:#fd6d03;">gunztheduel@hotmail.com</span><br>
Após a confimação voce tem o prazo de 24 horas para receber sua doação.

</span>
</div>

<div class="msg-formulario down-3">Boleto Bancário</div>

<div class="txt-min-doacao">
<span class="txt-min">

Apos a doação e necessário que nos envie uma foto do comprovante para o nosso email : <span style="color:#fd6d03;">gunztheduel@hotmail.com</span>, <br>
ou pelo nosso skype: <span style="color:#fd6d03;">King Gunz</span> juntamente do seu login, e do seu nick para que possamos liberar as GCoins. 
</span>
</div>

<div class="msg-formulario down-3">Cartão de Crédito</div>

<div class="txt-min-doacao">
<span class="txt-min">
O Pagamento cai na hora, basta nos enviar o código de transação que encontra-se em seu e-mail ultilizado para fazer a compra, 
juntamente do seu login, e nick para que possamos liberar as EGCoins. 
</span>
</div>


<!-- -------------- -->
<!-- ##############  -->
</section>