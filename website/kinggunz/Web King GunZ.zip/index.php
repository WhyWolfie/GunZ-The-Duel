<?php include "includes/header.php"; ?>

<!-- RANKING -->
<section id="bg-ranking">

<!--Script de aparecer o conteudo na div By: Nerva-->
<?php
if (isset($_GET['king']
)) 
{
$_GET['expand'] = 0;
if (file_exists("php/king_" . $_GET
['king'] . ".php"
)) 
{include "php/king_" . $_GET['king']
 . ".php";
}
else
{
include("php/404.php");
}}
else
{include "php/king_index.php";}
?>
<!--fim-->


<?php include ("includes/section.php"); ?>
<?php include ("includes/aside.php"); ?>
<?php include ("includes/footer.php"); ?>