<?
header("Content-type: image/png");
$img = imagecreate("145", "20");
imagecolorallocate($img, 0, 0, 0);
$cor = imagecolorallocate($img, 255, 255, 255);
$fonts = rand(1,3);

switch ($fonts) 
{
	case (1): $fontfile = "tahoma.ttf"; break;
	case (2): $fontfile = "comic.ttf"; break;
	case (3): $fontfile = "georgia.ttf"; break; 
}
	
imagettftext($img, 10, 0, rand(15, 65), 14, $cor, $fontfile, $_GET["str"]);
imagepng($img);
imagedestroy($img);
?>