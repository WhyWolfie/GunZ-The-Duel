<?php
// Config Siganture
$url	=	"http://localhost:80/Gunz";
$img 	=	"img/sing.png";

?>