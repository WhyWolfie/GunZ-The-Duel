<?
header("Location: /GunZ/error101/index.php");
die();
?>