<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<div align="center" >
                    	<h1 class="blind"><span style="color:#FF0000">Subir Emblema Parte 2</h1>
                    </div>
							<table border="0" style="border-collapse: collapse" width="100%" bordercolor="">
								<tr>
									<td bgcolor="">
								
									<br>
									  <span style="color:#000000"><strong>Colocar la parte roja que copio en el paso anterior y pegarla en el espacio en blanco:<strong/>
									  <?php
   echo '
	  <table border="0" width="240">
	   <tr><td>
		  <table>
		   <tr><td>
			
			
   ';
 //Select User AID
 SetTitle("EnergyGz - Clan Emblema");
 $seluaid = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION[AID]."'");
 $uaid = mssql_fetch_object($seluaid);
 //Select User CID
 $selucid = mssql_query("SELECT * FROM Character WHERE AID='".$uaid->AID."' AND DeleteFlag='0'");
  echo '<br />
  <table border="0" align="center">
	<form action="index.php?vct=emblems2" method="post" enctype="multipart/form-data">
	  <tr><td><select name="clanname">
  ';
 while($ucid = mssql_fetch_object($selucid)){
 //Select User Clan
 $seluclan = mssql_query("SELECT * FROM Clan WHERE MasterCID='".$ucid->CID."' AND DeleteFlag='0'");
 while($uclan = mssql_fetch_object($seluclan)){
                 
    echo '
		<option value="'.$uclan->Name.'">'.$uclan->Name.'</option>
	';
   
 }}
   echo '</select></td>
	  <td><input type="text" name="link" /></td>
	  <td><input type="submit" type="button" class="Info2" name="insert" value=" Subir Emblema! " /></td></tr>
	</form>
	</table>
	   <br />
    ';

//Upload
echo '<div class="errmess">';
 if(isset($_POST['insert'])){
 $clanname = ($_POST['clanname']);
 $emblem = ($_POST['link']);
 
	  
	  $sqluploademb = mssql_query("UPDATE Clan SET EmblemUrl='$emblem' WHERE Name='$clanname'");
	  $sqluploademb = mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$clanname'");
	  echo "Emblema Subido Exitosamente para notar el cambio recargue la pagina!";	 
      
 }
echo '</div>';
 
	echo ' <br />
			
		   </td></tr>
		  </table>
		</td></tr>
	  </table>
   ';
?></p>
									</div>
									</td>
								</tr>
							</table>