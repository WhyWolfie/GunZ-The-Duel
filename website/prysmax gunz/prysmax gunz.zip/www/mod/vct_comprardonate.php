<?php
SetTitle("EnergyGz - Comprar");

if( $_SESSION['AID'] == "" ){
	alertbox("Para Comprar un Item Deves estar Logueado","index.php");
	die();
	}

if(!isset($_POST[itemid]))
{
    if($_GET[itemid] == "" || !is_numeric($_GET[itemid]))
    {
	alertbox("Incorrecta Informacion del item","index.php");
	die();
	}
}

if(isset($_POST[itemid]))
{
    $itemid  = clean($_POST[itemid]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopDonator(nolock) WHERE CSSID = $itemid");

    if(mssql_num_rows($ires) == 0)
{
	alertbox("Item no Funciona","index.php");
	die();
	}

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID  = $accid"));

    $totalprice       = $ires->Price;
    $accountbalance = $ares->DonatorCoins;
    $afterbalance   = $accountbalance - $totalprice;
    $ugradeid = $ares->UGradeID;
	
	if ($itemid == 95)
    {
	//Gamble 1
    mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 5)");
	}
	if ($itemid == 96)
    {
	//Gamble 2
    mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 5)");
	}
	if ($itemid == 97)
    {
	//Gamble 3
    mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 5)");
	}

    if ($itemid == 1 && $ugradeid == 2)
    {
	alertbox("Ya usted tiene el JJang no tiene que comprarlo denuevo","index.php");
	die();
	}
    elseif($itemid == 1 && $ugradeid != 0)
    {
	alertbox("NO puedes Regalarle un JJang a un Moderador","index.php");
	die();
	}

    if($afterbalance < 0)
    {
	alertbox("Usted no Posee Suficientes Coins para comprar este Item","index.php");
	die();
	}else{
        if( $itemid == 1 )
        {
            mssql_query_logged("UPDATE Account SET UGradeID = 2, DonatorCoins = DonatorCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopDonator SET Selled = Selled + 1 WHERE CSSID = $itemid");

            alertbox("Usted ha comprado el JJang Exitosamente","index.php?vct=tiendadonate");
	die();
	}
        else
        {
            mssql_query_logged("UPDATE Account SET DonatorCoins = DonatorCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopItems SET Selled = Selled + 1 WHERE CSSID = $itemid");

            //Datos del Item
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 1)");


            alertbox("El Item ha sido comprado Satisfactoriamente","index.php?vct=tiendadonate");
	die();
	}

    }
}else{
    $itemid  = clean($_GET[itemid]);

    $ires = mssql_query_logged("SELECT * FROM ShopDonator(nolock) WHERE CSSID = $itemid");


    if(mssql_num_rows($ires) == 0)
{
	alertbox("Item no Funciona","index.php");
	die();
	}

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));

    $data = mssql_fetch_object($ires);
    switch($data->Slot)
{
    case 3:
        $type = "Armadura";
    break;
    case 2:
        $type = "Melee";
    break;
    case 1:
        $type = "Rango";
    break;
    case 5:
        $type = "Especial";
    break;
    default:
        $type = "Armadura";
    break;
}
}


$type = Donator

?>
<div style="background:url(img/div/center/head2.png) no-repeat; width:593px; height:30px;">
		<table width="640" border="0">
  			<tr>
    		<td width="572" height="25" align="center" style="background:; border:0px #cccccc solid; padding:5px;"><font color="#000000" style=" text-shadow: #000000 0px 0px 9px;"><strong>Comprar Donator Item : <span style="color:#80BFFF"><?=$data->Name?></strong></td>
  			</tr>
		</table>
</div>

							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse; border: 0px solid #4A4648" width="100%" bordercolor="#4A4648">
											<tr>
												<td>
													<form method="POST" action="index.php?vct=comprardonate" name="frmBuy"><table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="458" colspan="2">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104" valign="top">
													
															<img border="0" src="img/shop/<?=$data->ImageURL?>" width="100" height="100" style="border: 2px solid #000000"></td>
															<td width="458" colspan="2">
													
																<table border="0" style="border-collapse: collapse" width="458" height="100%">
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#000000">Tipo:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#000000"><?=$type?><strong/></td>
																	</tr>
                                                                    <tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#000000">Sexo:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#000000"><?=GetSexByID($data->Sex)?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#000000">Nivel:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#000000"><?=$data->Level?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#000000">Precio:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#000000"><span id="currentprice"><?=$data->Price?><strong/></span>
                                                                        <input type="hidden" name="itemid" value="<?=$_GET[itemid]?>">
                                                                        </td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="0" colspan="2" rowspan="5" >
																		<strong><span style="color:#000000">Duracion (Dias): Permanente<strong/>
                                                                       
																		</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																</table>
															
															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
															<td width="435" align="left" rowspan="4">
															
																<table border="0" style="border-collapse: collapse" width="435" height="66">
																	<tr>
																		<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
																		
																			<table border="0" style="border-collapse: collapse" width="419" height="100%">
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><strong><span style="color:#000000">Total:</td>
																					<td width="62" align="left"><strong><span style="color:#000000"><span id="Total"><?=$data->Price?></span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><strong><span style="color:#000000">Tienes DCoins</td>
																					<td width="62" align="left"><strong><span style="color:#000000"><span id="currbalance"><?=$acd->DonatorCoins?></span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left"><strong><span style="color:#000000">Despues:</td>
																					<td width="62" align="left"><strong><span style="color:#000000"><span id="afterpur"><?=(($acd->DonatorCoins) - ($data->Price))?></span></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="413" colspan="4" height="1"></td>
																				</tr>
																			</table>
																	
																		</td>
																		<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
																	</tr>
																</table>
													
															</td>
														</tr>
														<tr>
															<td width="569" colspan="4">&nbsp;</td>
														</tr>
													</table>

						
												</td>
											</tr>
										</table>
							
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;
									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">
									<p align="center">
									<a href="javascript:document.frmBuy.submit();"><button type="button" name="insert" value="Info" class="Info">Comprar</button></a>
									<a href="index.php?do=shopdonator"><button type="button" name="insert" value="Info" class="Info">Cancelar</button></a></td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>