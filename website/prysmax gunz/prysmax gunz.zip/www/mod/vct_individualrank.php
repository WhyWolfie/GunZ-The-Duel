<?php
SetTitle("EnergyGz - Rank Individual");
?>
<br>
<a href="index.php?vct=clanrank"><button type="button" name="insert" class="Info3">Clan Ranking</button>
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url(''); background-repeat:repeat-y" width="640">
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;<p>&nbsp;</p>
									<p></p></td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="vct" value="individualrank" />
									<select name="type">
									<option value="1">Nombre de Personaje</option>
                                    <option value="2">Nombre de Cuenta</option>
									</select>
									<input type="text" name="name"/>
									<input type="submit" value="Buscar" />
                                    <p align="center">
					                </form>
                                    </td>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
									<img border="0" src="img/playerrankinglegend.PNG" width="601" height="25" /></td>
								</tr>
<tr>
	<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
	<div align="center">
	<img border="0" src="img/individualrankbg.PNG" width="601" height="25" /></td>
</tr>
								<tr>
									<td style="background-repeat: no-repeat; background-position: center top" width="100" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse; background-image: url(''); background-repeat: no-repeat; background-position: center top" width="100">
											<tr>
												<td width="14">&nbsp;</td>
												<td width="538" colspan="5" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="538">
														<tr>
															<td width="59">&nbsp;</td>
															<td width="132">&nbsp;</td>
															<td width="43">&nbsp;</td>
															<td width="149">&nbsp;</td>
															<td width="145">&nbsp;</td>
														</tr>
																  <?
														eng_query("UPDATE Character SET RankingPlayer='0'");
                                                        $q = eng_query("SELECT TOP 100 * From Character WHERE Name != '' Order By XP DESC");
                                                        $c = 1;
                                                        while($r = eng_object($q)){
                                                        eng_query("UPDATE Character SET RankingPlayer='".$c."' WHERE CID='".$r->CID."'");
                                                        $c++;
                                                        }
                                                        $squery = "SELECT TOP 0 * From Character WHERE Name != '' Order By XP DESC";
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT CID, Level, XP, RankingPlayer, KillCount, DeathCount FROM Character(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $accountq = mssql_query("SELECT AID FROM Account(nolock) WHERE UserID = '$name'");
                                                                if( mssql_num_rows($accountq) == 1 )
                                                                {
                                                                $accountdata = mssql_fetch_row($accountq);
                                                                $aid = $accountdata[0];
                                                                $squery = "SELECT CID, Level, XP, RankingPlayer, KillCount, DeathCount, LastTime, Sex FROM Character(nolock) WHERE AID = '$aid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC";
                                                                }
                                                                else
                                                                {
                                                                    echo '
                                                                <tr>

                                                                </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {
														if(isset($_GET['page'])){
														$page = clean($_GET['page']);
														if(!is_numeric($page))
														{
														$page = 1;
														}
														}else{
														$page = 1;
														}
														switch($page){
														case 1:
														$ir = "WHERE RankingPlayer <= '20'";break;
														case 2:
														$ir = "WHERE RankingPlayer >= '21' AND RankingPlayer <='40'";
														break;
														case 3:
														$ir = "WHERE RankingPlayer >= '41' AND RankingPlayer <='60'";
														break;
														case 4:
														$ir = "WHERE RankingPlayer >= '61' AND RankingPlayer <='80'";
														break;
														case 5:
														$ir = "WHERE RankingPlayer >= '81' AND RankingPlayer <='100'";
														break;
														}
                                                           $res = mssql_query("SELECT * From Character ".$ir." AND RankingPlayer !='0' Order By RankingPlayer ASC");
                                                            }
                                                            else
                                                            {
                                                                $res = mssql_query($squery);
                                                            }
                                                              if(mssql_num_rows($res) <> 0)
                                                              {
                                                            while($char = mssql_fetch_object($res))
                                                            {

                                                        ?>
                                                                    <tr>
                                                                        <td width="59" align="center">
                                                                        <span style="color:#000000"><strong><b><?=$char->RankingPlayer?></b></td>
                                                                        <td width="132" align="center">
                                                                        <strong><?=FormatCharName($char->CID)?></td>
                                                                        <td width="43" align="center">
                                                                        <span style="color:#000000"><strong><?=$char->Level?></td>
                                                                        <td width="149" align="center">
                                                                        <span style="color:#000000"><strong><?=number_format($char->XP, 0, ",", ".")?></td>
                                                                        <td width="145" align="center">
                                                                        <span style="color:#000000"><strong><?=GetKDRatio($char->KillCount, $char->DeathCount)?></td>
                                                                    </tr>
                                                                  <?
                                                                  $count++;
		}
		}else{
		?>
           </tbody>
        <tr align="center">
          <td colspan="8"><center><STRONG><font color="#00FF00">No Existe.</STRONG></center></td></tr>
        
        <? }?>
													</table>
												</div>
												</td>
												<td width="13">&nbsp;</td>
											</tr>
									  </table>
									</div>
									<br>
                                    <?
                                    if( $search == 0 )
                                    { ?>
                                    <p align="center"><a href="#"></a></p>
                                    <?
                                    }
                                    ?>
                                    </td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<p></p></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>