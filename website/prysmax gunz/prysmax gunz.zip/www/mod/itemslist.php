<center><table width="590" border="0"> 
  <tr>
    <td height="30" style="background:#000000; color:#05a18d; border-radius:5px 5px 5px 5px;"><center><strong>Ultimos Items Donator</strong></center></td> 
  </tr>
</table>
  <tr>
    <td><table width="577">
  <tr>
	<td align="left"><div style="width:700px">
    <?$res = mssql_query("SELECT TOP 9 * FROM ShopDonator WHERE Name <> '' ORDER BY Level DESC");?>
	<table width="0" height="0" border="0" style="border-collapse: collapse">
	<?if(mssql_num_rows($res) == 0){?>
    <tr>
    <td height="23" colspan="2">
    <div align="left" class="Estilo2">No hay datos</div></td>
    </tr>
    <?}else{while($clan = mssql_fetch_assoc($res)){?>
<tr>
<a href="index.php?vct=comprardonate&itemid=<?=$clan['CSSID']?>"><img src="img/shop/<?=$clan['ImageURL']?>" width="64" height="64"></td>
<?}}?>
</table></tr>
</table>
<table width="590" border="0"> 
  <tr>
    <td height="30" style="background:#000000; color:#05a18d; border-radius:5px 5px 5px 5px;"><center><strong>Ultimos Items Evento</strong></center></td> 
  </tr> 
</table>
  <tr>
    <td><table width="577"> 
  <tr>
    <td align="left"><div style="width:700px">
    <?$res = mssql_query("SELECT TOP 9 * FROM ShopEvents WHERE Name <> '' ORDER BY Level DESC");?>
	<table width="0" height="0" border="0" style="border-collapse: collapse">
	<?if(mssql_num_rows($res) == 0){?>
    <tr>
    <td height="23" colspan="2">
    <div align="left" class="Estilo2">No hay datos</div></td>
    </tr>
    <?}else{while($clan = mssql_fetch_assoc($res)){?>
    <tr>
	<a href="index.php?vct=comprarevento&itemid=<?=$clan['CSSID']?>"><img src="img/shop/<?=$clan['ImageURL']?>" width="64" height="64"></td>
    <?}}?>
    </table></tr>
	</table></center>