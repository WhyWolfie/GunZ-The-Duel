
 <body>
    <td width="1030" valign="top"><table width="250" height="171" align="center" background="img/welcome.jpg">
      <tr>
        <td><table width="708" height="167" align="center">
          <tr>
            <td width="698" height="33">&nbsp;</td>
          </tr>
          <tr>
            <td height="53"><table width="413">
              <tr>
                <td width="245" height="27">&nbsp;</td>
                <td width="156">
                  <span class="style3">
                <?
			 $useron = mssql_query("SELECT CurrPlayer FROM ServerStatus WHERE Opened != 0");
			 $count = 0;
			 while($onlines = mssql_fetch_row($useron)){
				 $count = $count + $onlines[0];
				 }
				 echo $count;
			 ?>
                </span></span></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="71"><table width="689">
              <tr>
                <td width="241" height="53"><table width="245" height="34">
                  <tr>
                    <td width="175" height="28">&nbsp;</td>
                    <td width="58"><?   $status = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
		 while($data = mssql_fetch_object($status)){
			 $ip = $data->IP;
			 $port = $data->Port;
			 $name = $data->Name;
			 $lst = @fsockopen($ip,$port,$errno,$errstr, 1);
			 if(!$lst){
				echo "<font size='2' color='#FF0000'>Apagado</font></font>";	
				 }else{
					echo"<font size='2' color='#00FF00'>Online</font></font>";
					fclose($lst);
					 }
			 }
           ?>&nbsp;</td>
                  </tr>
                </table></td>

              </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
    </table>
	       <table width="731" height="436" align="center" background="img/Info_px.png">
        <tr>
          <td width="797" height="430" valign="top"><table width="722" height="428" align="center">
            <tr>
              <td height="30">&nbsp;</td>
            </tr>
            <tr>
              <td height="390" valign="top"><div align="center"><span class="style5"><span class="style8">&iquest;Que es Gunz? </span><br />
                    <br />
                Gunz es un TPS, Third Person Shooter. Bastante adrenalinico y veloz, que tiene una jugabilidad unica en cuanto a libertad de movimiento. A diferencia de otros shooters, aca tenes un personaje que va progresando a lo largo del tiempo, y segun tu level podes ir comprando diferentes items. Tambien tiene un modo quest, donde jugas contra NPCs para conseguir items que solo podes conseguir de esa manera</span><span class="style5">.<br />
                <br />
                </span>
                </div>
                <p align="center" class="style7">Informacion del Servidor de Prysmax  </p>
                <ul class="style5">
                  <li>Experiencia del servidor: 7X </li>
                  <li>Dinero en el servidor: 7X </li>
                  <li>Duel Tournament (Se Habilitara cuando hayan suficientes usuarios)</li>
                  <li>Suvirval Mode </li>
                  <li>Rankings individuales y por clan</li>
                  <li>Items en la shop del gunz (balanceados)</li>
                  <li>Items donator(No hay mucha diferencia con los de la shop del gunz , esto es para el balanceo) </li>
                  <li>Nuevos items en la tienda donator</li>
                  <li>Nuevo sistema de Anti-Lead </li>
                  <li>Nuevo Anti-Hack 2015 </li>
                  <li>Nuevo equipo de staff en el servidor </li>
                </ul>
                <p align="center" class="style9">Podes obtener mas informacion en el&nbsp;<a href="foro.prysmaxgunz.com">foro</a></p>                </td>
            </tr>
          </table></td>
        </tr>
      </table>      	
      <table width="729" height="727" align="center" background="img/Info_px02.png">
        <tr>
          <td width="775" height="721" valign="top"><table width="721" height="710">
            <tr>
              <td height="27">&nbsp;</td>
            </tr>
            <tr>
              <td height="675" valign="top">                       	<h3 align="center" class="style5">Que es el juego de accion de disparo alternativo</h3>
                            <p class="style5">
                            	GUNZ es un juego similar a otros juegos FPS. Sin embargo GUNZ, incluye los diferentes elementos que otros juegos FPS.                            </p>
                            <h3 class="style12">Maxima accion de juego on-line</h3>
                            <p class="style12">
                            	Se pude ver diversas acciones como una pelicula o de juego de Video-consola. Es posible realizar las acciones como Dash,<br />
                                saltar en las paredes Tumbling, estar sujetado a la pared, multiple salto en las paredes,<br />
                                utilizar el cuchillo, armas, acciones combo, etc. En GUNZ, mas que disparar, es actuar con diferentes sentidos.							</p>
                            <h3 align="center" class="style13">Juego de accion 3D</h3>
                            <p class="style12">
                            	La batalla se realiza en la tierra, pared y tambien en la columna.<br />
                                Ustedes podran pisar la pared, columna, saltar en ellos con diversas acciones. Experimenta ya el nuevo juego estrategico!!!                            </p>
                            <h3 class="style12">Creacion de diversos personajes con unica caracteristica</h3>
                            <p class="style12">
                            	Hay diversos personajes de GUNZ, no cuenta solamente los personajes que ofrece el desarrollador, sino uds podran equipar con los items,<br />
                                vestidos segun sus preferencias y gustos. Claro que si el avatar se cambiara de apariencia al equipar con diversos items.<br />
                                Por primera vez en el juego de acción, GUNZ apoya con los 12 items slot que el jugador puede cambiar su apariencia.                            </p>
                        </div>
						<div class="speciality2">
                        	<h3 align="center" class="style13">Diversas armas e items</h3>
                            <p class="style12">
								A parte de vestidos y accesorios, ustedes pueden usar las armas seleccionandolas.<br />
                                Participen en las batallas con las armas de su preferencia. Puede atacar con ametralladora, pistola, Machine gun en ambas manos.<br /> 
                                Ademas ofrece tambien diversas armas para los ataques proximos.<br />
                                Si usa la espada larga, puede estar sostenido en la pared, o puede dejar el enemigo en estado de levitacion, y si usa la espada corta, sera posible realizar un juego agil. <br />
                                Los vestidos, como las armas tienen diferentes diseños, colores. Y asi que puede ser un item fashion como las armas.							</p>
                            <h3 align="center" class="style13">Juego adicional</h3>
                            <p class="style12">
                            	El GUNZ que tendra su servicio oficial en Centro america y Sudamerica, estara extendiendo continuamente sin parar.<br /> 
                                GUNZ es el juego de acción con un elemento de Role playing, y más adelante estaremos añadiendo más elementos de role playing, mas que los elementos limitados como aumento de nivel según su record.                            </p>
            </tr>
          </table></td>
        </tr>
      </table>
<center>	  <?php include "UltimasCw.php"?>
	  <?php include "itemslist.php"?> </center>