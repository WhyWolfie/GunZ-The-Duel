                	<div align="center" class="tit_download_client">
                    	<h1 class="blind"><span style="color:#FF0000">PANEL DE USUARIO</h1>
                    </div>
      
			
<div style="background:url(img/div/center/center2.png) repeat-y; width:640px; font-weight: bold;">
                <br />

<? 
SetTitle("EnergyGz - Panel");
if($_SESSION['AID'] == ""){
	alertbox("Logueate primero","index.php");
	die();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>
<?php
$you = mssql_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
$acc = mssql_fetch_object($you);
$email = $acc->Email;
$sa = $acc->sa;
$sq = $acc->sq;	
	if(isset($_POST['newpass'])){
		$pwanti = vct_antisql($_POST['pwanti']);
		$pwnew1 = vct_antisql($_POST['pwnew1']);
		$pwnew2 = vct_antisql($_POST['pwnew2']);
		if(empty($pwanti) || empty($pwnew1) || empty($pwnew2)){
			alertbox("No dejes campos vacios","index.php");
			die();
			}
		$vpw = mssql_query("SELECT * From Login WHERE Password='".$pwanti."' AND AID='".$_SESSION['AID']."'");
		
		if(mssql_num_rows($vpw) == 0){
			alertbox("Contraseña incorrecta","index.php");
			die();
				}
				
			if($pwnew1 != $pwnew2){
				alertbox("Contraseñas new no considen","index.php");
				die();
				}
		mssql_query("UPDATE Login SET Password='$pwnew1' WHERE AID='".$_SESSION['AID']."'");
		alertbox("Tu contraseña ha sido Cambiada con exito.","index.php");
			die();
		}
		if(isset($_POST['newemail'])){
			$newemail = vct_antisql($_POST['email']);
			if($newemail == ""){
				alertbox("No dejes campo vacio","index.php");
				die();
				}
		mssql_query("UPDATE Account SET Email='$newemail' WHERE AID='".$_SESSION['AID']."'");
			alertbox("Tu Email ha sido Cambiada con exito.","index.php");
			die();
			}
		if(isset($_POST['newsa'])){
			$newpre = vct_antisql($_POST['newpre']);
			$newres = vct_antisql($_POST['newres']);
			if(empty($newpre) || empty($newpre)){
			alertbox("No dejes campo vacio","index.php");
				die();
				}	
		mssql_query("UPDATE Account SET sa='$newpre' WHERE AID='".$_SESSION['AID']."'");
		mssql_query("UPDATE Account SET sq='$newres'WHERE AID='".$_SESSION['AID']."'");
		
			alertbox("Tu Pregunta y respuesta ha sido Cambiada con exito.","index.php");
			die();
				
			}
		
		
?>

<body>
<form action="" name="fromx" method="post">
<table width="355" border="0">
  <tr>
    <td width="345" height="23" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td height="120" valign="top"><table width="349" border="0">
      <tr>
        <td colspan="2" style=""><span style="color:#000000"><strong>Cambio de contrase&ntilde;a.</a></td>
      </tr>
      <tr>
        <td width="169"><span style="color:#000000"><strong>Antigua contrase&ntilde;a:</td>
        <td width="164"><input type="password" name="pwanti" /></td>
      </tr>
      <tr>
        <td><span style="color:#000000"><strong>Nueva Contrase&ntilde;a:</td>
        <td><input type="password" name="pwnew1" /></td>
      </tr>
      <tr>
        <td><span style="color:#000000"><strong>Repetir nueva contrase&ntilde;a:</td>
        <td><input type="password" name="pwnew2" /></td>
      </tr>
      <tr>
        <td height="28">&nbsp;</td>
        <td><input type="submit" class="Info" name="newpass"  value="Cambiar Contraseña"/></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="51"><table width="347" border="0">
      <tr>
        <td colspan="2"><span style="color:#000000"><strong>Cambio de E-mail.</a></td>
      </tr>
      <tr>
        <td width="170"><span style="color:#000000"><strong>Tu E-mail:</td>
        
        <td width="161"><?=$email?></td>
      </tr>
      <tr>
      <td><span style="color:#000000"><strong> Nuevo E-mail: </td>
        <td><input type="text" value="<?=$email?>" name="email" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit"  class="Info3" name="newemail"  value="Cambiar Email"/></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="40"><table width="347" border="0">
      <tr>
        <td colspan="2"><span style="color:#000000"><strong>Cambio de Pregunta y Respuesta.</a></td>
      </tr>
      <tr>
        <td width="170"><span style="color:#000000"><strong>Nueva Pregunta:</td>
        <td width="161"><input type="text" name="newpre" id="newpre" value="<?=$sa?>" /></td>
      </tr>
      <tr>
        <td><span style="color:#000000"><strong>Nueva Respuesta:</td>
        <td><input type="text" name="newres" value="<?=$sq?>" id="newres" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit"  class="Info3" name="newsa"  value="Cambiar Pre. y Res." id="newsa"/></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</body>
</html>
  <p class='notify'>&nbsp;</p>
                 
               					<br />


</div>
<div style="background:url(img/div/center/footer2.png) no-repeat; width:593px; height:7px;"></div>