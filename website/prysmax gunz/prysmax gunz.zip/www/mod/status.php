<center><table width="280" border="0" cellpadding="0" cellspacing="0" align="LEFT">
  <tr>
    <td style="background:#242424; width:100px; border-radius: 1px 1px 1px 1px;-moz-border-radius: 1px 1px 1px 1px;-webkit-border-radius: 1px 1px 1px 1px;border: 1px solid #000000; padding:1px;" align="center">
    
    <strong>
    <a href="">
	<?
	$useron = mssql_query("SELECT CurrPlayer FROM ServerStatus WHERE Opened != 0");
	$count = 0;
	while($onlines = mssql_fetch_row($useron)){
	$count = $count + $onlines[0];
	}
	echo $count;
	?>
    </a>
    </strong>
    
    </td>
    <td style="background:#000000; border-radius: 1px 1px 1px 1px;-moz-border-radius: 1px 1px 1px 1px;-webkit-border-radius: 1px 1px 1px 1px;border: 1px solid #000000; padding:1px;"><span style="color:#00cec2"><strong>Players Online</strong></td>
  </tr>
  <table width="280" border="0" cellpadding="0" cellspacing="0" align="CENTER">
    <td style="background:#242424; width:100px; border-radius: 1px 1px 1px 1px;-moz-border-radius: 1px 1px 1px 1px;-webkit-border-radius: 1px 1px 1px 1px;border: 1px solid #000000; padding:1px;" align="center">
     <strong>
	 <?   $status = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
		 while($data = mssql_fetch_object($status)){
			 $ip = $data->IP;
			 $port = $data->Port;
			 $name = $data->Name;
			 $lst = @fsockopen($ip,$port,$errno,$errstr, 1);
			 if(!$lst){
				echo "<font size='2' color='#FF0000'>Offline</font></font>";	
				 }else{
					echo"<font size='2' color='#00FF00'>Online</font></font>";
					fclose($lst);
					 }
			 }
       ?>
    </strong>
    
    </td>
    <td style="background:#151515; border-radius: 1px 1px 1px 1px;-moz-border-radius: 1px 1px 1px 1px;-webkit-border-radius: 1px 1px 1px 1px;border: 1px solid #000000; padding:1px;"><span style="color:#80BFFF"><strong>Server Estado</strong></td>
  </tr>
</table>
<br></center>