<table>
<td>
<table border="0" style="border: 4px solid #; float:center" width="600" height="100">
<?
SetTitle("EnergyGz - Clan Info");
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("El Clan no Existe","index.php");
exit();
}

$clid = $clan->CLID;
?> 
                                                  <div align="center"><br><span style="color:#00GG00"><strong>Clan: 
                                                  <?=$clan->Name?>
                                                  </strong>
                                                    </center>
												  </div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											  <td width="380" style="background-repeat: no-repeat; background-position: center top"><div align="center"><br><img src="http://i.imgur.com/<?=($clan->EmblemUrl == "") ? "cATDNqD.png" : $clan->EmblemUrl?>" width="100" height="100" ></div></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
												<table border="0" style="border: 4px solid #242424; float:center" width="400" height="100">
&nbsp;
                         <tr>			    
                                    <td align="left"><span style="color:#000000"><strong>Rank:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->Ranking?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Puntos:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Win:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Losses:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Draw:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Creado:</td>
                                    <td align="left"><span style="color:#000000"><strong><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><span style="color:#000000"><strong>Membros:</td>
                                    <td align="left"><span style="color:#000000"><strong><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
</tr>
</table>
								           </td>
											<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top"></td>
											  <td style="background-repeat: no-repeat; background-position: center top"></td>
											  <td style="background-repeat: no-repeat; background-position: center top"></td>
											  </tr>
											<tr>
											  <td style="background-repeat: no-repeat; background-position: center top"></td>
											  <td style="background-repeat: no-repeat; background-position: center top"><br><table width="448" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td align="center"><span style="color:#000000"><strong>Personajes</strong></u></td>
                                   <td align="center"><span style="color:#000000"><strong>Rango</strong></u></td>
                                    <td align="center"><span style="color:#000000"><strong>Ultima Coneccion</strong></u></td>
                                    <td align="center"><span style="color:#000000"><strong>Pts</strong></u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "<font color='white'>Miembro";
    break;
    case "2";
       $grade = "<font color='red'>Administrador";
    break;
    case "1";
       $grade = "<font color='orange'>Lider";
    break;
}


?>
                                  <tr>
                                    <td align="center"><a href="index.php?vct=charinfo&id=<?=($char->CID)?>"><strong><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center"><strong><? echo $grade; ?></td>
                                    <td align="center"><span style="color:#000000"><strong><?=$char->RegDate?></td>
                                    <td align="center"><span style="color:#000000"><strong><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
											  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  </tr>
											</table>
									</div></td>
								</tr>
						  </table>