<table width="590" border="0"> 
  <tr> 
    <td height="30" style="background:#000000; color:#05a18d; border-radius:5px 5px 5px 5px;"><center><strong>Ultimos Clan War</strong></center></td> 
  </tr> 
</table>
  <tr> 
    <td><table width="577"> 
  <tr> 
    <td width="35" bgcolor="#000000" style="border-radius:3px 3px 3px 3px;" align="center"><strong><span style="color:#FFFFFF">Win</strong></td> 
    <td width="158" bgcolor="#000000" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8">&nbsp;<strong><span style="color:#FFFFFF">Clan Ganador</strong></font></td> 
    <td width="19"></td> 
    <td width="143" bgcolor="#000000" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8"><strong><span style="color:#FFFFFF">Clan Perdedor</strong></font></td> 
    <td width="43" bgcolor="#000000" style="border-radius:3px 3px 3px 3px;" align="center"><strong><span style="color:#FFFFFF">Losse</strong></td> 
  </tr>
</table> 
</td> 
  </tr> 
</table></td></tr></table> 
<?php 
$busca999 = mssql_query("SELECT TOP 6 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC"); 
$busca998 = mssql_fetch_row($busca999); 

while($item22 = mssql_fetch_row($busca999)) 
{ 

?> 
<table style="background:"><tr><td><table width="420"> 
  <tr> 
    <td><table width="560"> 
  <tr> 
    <td width="35" bgcolor="#000000" style="border-radius:3px 0px 0px 3px;" align="center"><font color="#99FF00"><?=$item22[2]?> +</font></td> 
    <td width="153" bgcolor="#000000" style="border-radius:0px 3px 3px 0px;" align="center"><font size="1,8"><span style="color:#FFFFFF"><?=$item22[0]?></font></td> 
    <td width="19" align="center"><font color="#FF0000">Vs</td>
    <td width="153" bgcolor="#000000" style="border-radius:3px 0px 0px 3px;" align="center"><font size="1,8"><span style="color:#FFFFFF"><?=$item22[1]?></font></td> 
    <td width="35" bgcolor="#000000" style="border-radius:0px 3px 3px 0px;" align="center"><font color="#FF0000">- <?=$item22[3]?></font></td> 
  </tr> 
   
</table> 
</td> 
  </tr> 
</table></td></tr></table> 

<? 
} 
?>