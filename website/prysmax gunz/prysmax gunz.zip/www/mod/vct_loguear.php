<?php
@session_start();
if($_SESSION['AID'] <> ""){
	alertbox("Usuario $_SESSION[AID] Ya estas logueado");
	die();
	}
if(isset($_POST['submit'])){
	$user = vct_antisql($_POST['user']);
	$pass = vct_antisql($_POST['pass']);
	if(empty($user) || empty($pass)){
		alertbox("No dejas campos vacios.","index.php");
		die();
		}
	$que = mssql_query("SELECT UserID, AID From Login WHERE UserID='".$user."' AND Password='".$pass."'");
	if(mssql_num_rows($que) == 0){
		alertbox("Datos Incorrectos o Cuenta no existe.","index.php");
		die();
		}
	$go = mssql_fetch_row($que);
	$_SESSION['AID']	= $go[1];
	$_SESSION['UserID']	= $go[0];
	
	alertbox("Bienvenido Usuario: $user","index.php");

}
?>