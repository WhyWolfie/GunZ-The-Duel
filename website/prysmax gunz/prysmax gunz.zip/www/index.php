<?php
include("seg/config.php");
include_once("seg/functions.php");
function PrysmaxGz($content)
{
   if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "Prysmax Gunz", $content);
        return $r;
    }
}
ob_start("Prysmax");
?>
<head>
	<meta charset="UTF-8">
	<title>Prysmax Gunz</title>
	<link href="energy_gamers_style_4887972201245736175728215437676987.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<center><script language="JavaScript">
<!--
function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("No tienes suficientes Coins para comprar por " + SelectedDays + " Dias");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
</script></center>
<body>
	<div class="background">
		<div class="page">
			<div class="header">
				<a href="<?=$inicio?>" id="logo"><img src="img/logo.png" alt="logo"></a>
				<ul>
					<li>
						<a href="<?=$registro?>">Registro</a>
					</li>
					<li>
						<a href="<?=$descargas?>">Descargas</a>
					</li>
					<li>
						<a href="<?=$Tienda?>">Tienda</a>
					</li>
					<li>
						<a href="<?=$Rankins?>">Rankings</a>
					</li>
					<li>
						<a href="<?=$foro?>">Foro</a>
					</li>
				</ul>
			</div>
			<div class="body home">
						<!-- ////////////////////////////-- Paginacion --////////////////////////////-->
        
        <tr>
    		<td align="center"><div style="width:640px; padding:px;">
            
            
<? 
                if(isset($_GET['vct'])){
				$vct = $_GET['vct'];		  
				}else{
				$vct = "index";
				}
				if(file_exists("mod/vct_$vct.php")){
				include "mod/vct_$vct.php";							
				}else{
alertbox("Pagina no existe.","index.php");
die();
}
?>
            
            
    </div></td>
  	</tr>        
	</table>
	</ul>
	<div class="sidebar">
	<div class="news">
	<spon>Login</spon>
	<ul>
	</ul>
	<?php include("Login/login.php"); ?>
	</div>
					<div class="section">
						<spon>Top 5 Players</spon>
						<ul>
							<?php include("Login/PlayerRanking.php"); ?>
						</li>
						</ul>
					</div>
					<div class="section">
						<spon>Top 5 Clan</spon>
						<ul>
							<?php include("Login/ClanRanking.php"); ?>
						</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="footer">
				<div>
					<ul>
						<li>
							<a href="<?=$opcion1?>">Inicio</a>|
						</li>
						<li>
							<a href="<?=$opcion2?>">Shop</a>|
						</li>
						<li>
							<a href="<?=$opcion3?>">Rankings</a>|
						</li>
						<li>
							<a href="<?=$opcion4?>">Descargas</a>|
						</li>
						<li>
							<a href="<?=$opcion5?>">Nuestro Grupo de Facebook</a>
						</li>
					</ul>
					<p>
						GUNZ WEB CODEADA POR SISMAR , DISEÑADA POR ARZAE
					</p>
				</div>
				<div class="connect">
				</div>
			</div>
		</div>
	</div>
<script language="javascript">
UpdateClan();
</script>
</body>
</html>