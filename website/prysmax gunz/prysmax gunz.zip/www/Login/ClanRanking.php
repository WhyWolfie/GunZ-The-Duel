<?
$query = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");

while($query2 = mssql_fetch_assoc($query))
{
 
$aid = $query2['AID'];
$cid = $query2['CID'];
 

 
 
?>
          <li>
            <table width="200" border="0">
			<td width="27" align="center"><img src="http://i.imgur.com/<?=($query2['EmblemUrl'] == "") ? 'cATDNqD.png' : $query2['EmblemUrl']?>" width="22" height="22"></td>
			<td width="125" align="center"><a href="index.php?vct=claninfo&id=<?=$query2['CLID']?>"><strong ><?=$query2['Name']?></a></strong></td>
			<td width="26" align="center"><font color='#FF0040'><span class="Estilo8"><strong >Tp:<?=number_format($query2['Point'],0,'','.');?><strong/></td>
            </table>
			</li>
<?}?>
