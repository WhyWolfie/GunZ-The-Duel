<?php
include 'antisql.php';
include 'anti_inject.php';
include 'anti_injectx.php';
include "banned.php";
include "bannedip.php";
include "banneduser.php";
include 'inject.php';
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
<span><h3>
Duke GunZ - Informa��es
</span></h3>

<br>
<span><h3>
Duke GunZ.
</span></h3>

</a> <a href="" target="_blank"><img src="favicons.ico" width="30" height="30"></a></a>
<br>
<span><h3>
Duke GunZ - Suporte Online
</span></h3>
Suporte via Emails:
<br><a href="index.php?do=suporte"><u>Clique aqui!</u></a><br>
<br>
<span><h3>
Duke GunZ - Equipe
</span></h3>
Conhe�a nossa Equipe:
<br><a href="index.php?do=equipe"><u>Clique aqui!</u></a><br>

<br>
<span><h3>
F�rum Online
</span></h3>
Se voc� tem alguma d�vida, opini�o,<br> sugest�o, cr�tica, utilize nosso Email:
<br><a href=index.php?do=email><u>Galegoedu@hotmail.com</u></a><br>



</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

