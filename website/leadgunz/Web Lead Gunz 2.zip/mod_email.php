So Add Msn E fala Comigo By: Duh.Exorcist.
<div align="center"><strong><font color="cyan">Galegoedu@hotmail.com - </font>MSN</strong></div></td>