<?
//Name color By:Duh.Exorcist '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
Voc� ir� gastar <font color=FF0080>50</font> DG Coins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="2">Verde Lim�o.</option>
<option value="3">Troca De Cor -> Amarelo, Azul, Verde</option>
<option value="4">Troca De Cor -> Roxo, Azul, Vermelho, Preto</option>
<option value="5">Troca De Cor -> Gradiente Vermelho</option>
<option value="6">Troca De Cor -> Gradiente Verde</option>
<option value="7">Troca De Cor -> Gradiente Azul</option>
<option value="8">Troca De Cor -> Especial(Azul, Vermelho e Verde.)</option>
<option value="9">Troca De Cor -> Random(Azul, Verde, Vermelho, Amarelo, Verde Agua, Roxo e Rosa)</option>
<option value="10">Azul Claro</option>
<option value="11">Lilas</option>
</select>
<br><br>
<font color="#ffffff"> Verde Lim�o.</font><br><br>
<font color="#FFFFFF"> Troca De Cor -> Amarelo, Azul, Verde</font><br><br>
<font color="#FFFFff"> Troca De Cor -> Roxo, Azul, Vermelho, Preto</font><br><br>
<font color="#ffffff"> Troca De Cor -> Gradiente Vermelho</font><br><br>
<font color="#ffffff"> Troca De Cor -> Gradiente Verde</font><br><br>
<font color="#ffffff"> Troca De Cor -> Gradiente Azul</font><br><br>
<font color="#FFffFF">Troca De Cor -> Especial(Azul, Vermelho e Verde.)</font><br><br>
<font color="ffffff"> Troca De Cor -> Random(Azul, Verde, Vermelho, Amarelo, Verde Agua, Roxo e Rosa)</font><br><br>
<font color="#ffffff"> Lilas</font><br><br>
<font color="#ffffff"> Azul</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
<br>
<span style="color:#CD2990; background: transparent url(http://tinyurl.com/outgum)"><b>Name color - DukeGunZ</b></span></a><br><br>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Voc� comprou Admin com sucesso!!  Brinks HAHA";
die ();  

}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 35) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  KG Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -35 where AID='$aid22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Acesse site.aulagunz.com.br";
}
}
}


$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>