<?

function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/serverstatu.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                        <br><b><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'Lead  Serve';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FF0080'><B>�</B></font> $name: <font style='color: #00FF00'><B>Online</B></font><br />";
        }
        else
        {
            echo "&nbsp;<font style='color: FF0080'><B>�</B></font> $name: <font style='color: #00FF00'><B>Online</B></font><br />";
            fclose($fp);
        }
    }
    ?>
<?php
        $ip = 'aqw.no-ip.biz';
        $port = '7777';
        $name = 'Agent Server';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FF0080'><B>�</B></font> $name: <font style='color: #00FF00'><B>Online</B></font><br />";
        }
        else
        {
            echo "&nbsp;<font style='color: FF0080'><B>�</B></font> $name: <font style='color: #00FF00'><B>Online</B></font><br />";
            fclose($fp);
        }
    ?>
&nbsp;* Usuarios:<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
    $max = $srv['MaxPlayer'];
    $porcentagem = PorcentPlayers($srv['CurrPlayer'], $srv['MaxPlayer']);
}
?> <?=$servercount?>/<?=$max?> - <?=$porcentagem?></li>
    </strong>

<br>�<font style='color: FF0080'><B>�</B></font>�Recorde Online: 
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<font style='color: #1E90FF'><?=$b['PlayerCount']?></font>
<br> 	
									
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Total de Contas: ".$num_rows."<n>"; 
?><br> 
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php


 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Total Personagens: ".$num_rows."<n>";

?><br>
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php
 
//Banidos
$query = mssql_query("SELECT * FROM Account WHERE UgradeID = 253"); 
$num_rows = mssql_num_rows($query); 
echo "Total Banidos: ".$num_rows."<n>";

?><br>
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php
 
//Banidos
$query = mssql_query ("SELECT * FROM Account WHERE UgradeID = 2 "); 
$num_rows = mssql_num_rows($query); 
echo "Total de Jjangs: ".$num_rows."<n>";
?><br>
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php
 
//VIPS
$query = mssql_query("SELECT * FROM Account WHERE UgradeID = 15 "); 
$num_rows = mssql_num_rows($query); 
echo "Total de Vips: ".$num_rows."<n>";

?><br>
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php
 
//VIPS
$query = mssql_query("SELECT * FROM Account WHERE UgradeID = 104 "); 
$num_rows = mssql_num_rows($query); 
echo "Total de Mudos: ".$num_rows."<n>";

?><br>
<b>&nbsp;<font style='color: FF0080'><B>�</B></font> <?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Total de Cl�s: ".$num_rows."<n>";

?><br>
  &nbsp;<font style='color: FF0080'><B>�</B></font> Mais Matou: <strong><font color=lightgreen><?=$matou[0]?><br></font></strong>
  <?
date_default_timezone_set('America/Sao_Paulo');
$arquivo = "contador.txt";
$data = date("d/m/y");

if(!file_exists("$arquivo")){
echo "O arquivo de grava��o de dados n�o foi encontrado, crie-o ou mude suas permiss�es";
}
$file = file("$arquivo");
$partes = explode(" | ", $file[0]);

$hoje = $partes[0];
$dataHoje = $partes[1];

if($dataHoje != $data){

$dataHoje=$data;
$ontem=$hoje;
$hoje=0;

}

$hoje+=1;
$total+=1;


if($hoje > $recorde){
$recorde=$hoje;
$dataRecorde=$data;
}

    ?>
    <b>&nbsp;<font style='color: FF0080'><B>�</B></font> Visitas Hoje:
    <?php
$file_count = fopen('counter/count.db', 'rb');
	$data = '';
	while (!feof($file_count)) $data .= fread($file_count, 4096);
	fclose($file_count);
	list($today, $yesterday, $total, $date, $days) = split("%", $data);
	echo $today;
?>
    </b><b><br>


</b></b></strong></b>
    <table style="border-collapse: collapse;" width="193" border="0" height="100%">


      </tbody></table>
<strong>								</strong></td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</tbody></table><br>
