<?php
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
include "title.php";
include 'anti_inject.php';
include 'anti_inject2.php';
include 'inject.php';
include 'inject2.php';
include 'anti_sql.php';
?>
<?
//HearT Owna =P

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

if($etapa22 == 0){
?>
<form id="ev_coins" name="ev_coins" method="post" action="?do=ev_coins&etapa=1">
Personagem:
<select name="cid" class="text">
<?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proximo ->" />
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))


{
die ("Este personagem n�o pertence a nenhum clan");
}else{

$_SESSION["CID"] = $cid22;
echo '
<font color=red>Aten��o:</font>A cada 2 pontos � o que vale a 1 ecoin.<br><br>
<form id="ev_coins" name="ev_coins" method="post" action="?do=ev_coins&etapa=2">';
echo "Ol� $login22 voc� tem $busca2[0] pontos para trocar.<br><br>";
echo "Quantos pontos deseja trocar?<br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="ev_coins" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "Voc� tem $busca4[0] pontos e quer trocar por $pontos ecoins ? o.0'";
}else{

if ( !is_numeric($cid23) )
{
echo "ID do personagem editado";
die();
}

if ( !is_numeric($pontos) )
{
echo "O N�mero de Coins precisa ser um n�mero";
die();
}

if ($pontos == 0)
{
echo "N�o h� necessidade de comprar 0 ecoins";
die();		
}

if($pontos < 1)
{
echo "N�o existe a possibilidade de ficar com pontos negativos o.0";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set EvCoins=EvCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}
?>