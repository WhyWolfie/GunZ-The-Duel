
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=255adminindex"><table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
					                        <br>
								<td background="images/adminpanel.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="addindexcontent" checked name="do">Adicionar Noticias<br>								
										<input type="radio" value="rzadditem" name="do">Adicionar Item Donate<br>
										<input type="radio" value="evadditem" name="do">Adicionar Item Evento<br>
										<input type="radio" value="send_coin_hue" name="do">Enviar Coins<br>
										<input type="radio" value="send_ecoin_af" name="do">Enviar EV Coins<br>
										<input type="radio" value="banlist" name="do">Lista de Banidos<br>
										<input type="radio" value="x_unban" name="do">Desban/Unmute Usuario<br>
										<input type="radio" value="banuser" name="do">Banir Usuario<br>
										<input type="radio" value="muteuser" name="do">Mutar Usuario<br>
										<input type="radio" value="ipbanuser" name="do">Banir IP Usuario <br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Concluir" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
								</td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							