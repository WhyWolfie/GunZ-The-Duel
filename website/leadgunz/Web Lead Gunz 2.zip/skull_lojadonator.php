<a href="index.php?knight=lojadonator" class="lojad">1</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=2" class="lojad">2</a>&nbsp;  
<a href="index.php?knight=lojadonator&pagina=3" class="lojad">3</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=4" class="lojad">4</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=5" class="lojad">5</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=6" class="lojad">6</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=7" class="lojad">7</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=8" class="lojad">8</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=9" class="lojad">9</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=10" class="lojad">10</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=11" class="lojad">11</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=12" class="lojad">12</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=13" class="lojad">13</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=14" class="lojad">14</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=15" class="lojad">15</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=16" class="lojad">16</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=17" class="lojad">17</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=18" class="lojad">18</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=19" class="lojad">19</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=20" class="lojad">20</a>&nbsp; 
<a href="index.php?knight=lojadonator&pagina=21" class="lojad">21</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=22" class="lojad">22</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=23" class="lojad">23</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=24" class="lojad">24</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=25" class="lojad">25</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=26" class="lojad">26</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=27" class="lojad">27</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=28" class="lojad">28</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=29" class="lojad">29</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=30" class="lojad">30</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=31" class="lojad">31</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=32" class="lojad">32</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=33" class="lojad">33</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=34" class="lojad">34</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=35" class="lojad">35</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=36" class="lojad">36</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=37" class="lojad">37</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=38" class="lojad">38</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=39" class="lojad">39</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=40" class="lojad">40</a>&nbsp;
<a href="index.php?knight=lojadonator&pagina=41" class="lojad">41</a>&nbsp;






<div id="tableshop">
<?php
$num_por_pagina = 12; 
$pagina = $_GET['pagina']; 

if(!$pagina)
{
 $pagina = 1;
}

$primeiro_registro = ($pagina*$num_por_pagina) - $num_por_pagina;
if ($pagina == 1)
{
 $res = mssql_query("SELECT TOP $num_por_pagina * FROM ShopDonator WHERE CSID > $primeiro_registro-1 AND Opened = 1 ORDER BY CSID ASC");
}
else
{
 $res = mssql_query("SELECT TOP $num_por_pagina * FROM ShopDonator WHERE CSID >= $primeiro_registro AND Opened = 1 ORDER BY CSID ASC");
}
while($item = mssql_fetch_assoc($res))
{
?>
                                   	  <table width="180" height="130" >
                                                    	<tr>
                                                        	<td colspan="2" class="centrox">&nbsp;</td>
                                                        </tr>
                                                    	<tr>
                                                        	<td colspan="2" class="centrox"><?=$item['Name']?></td>
                                                        </tr>
                                                        	<tr>
                                                            	<td width="80" rowspan="4" class="tabelashop" valign="middle"><a href="index.php?knight=itemshop&sub=details&id=<?=$item['CSID']?>"><img border="2" src="img/shop/donat/<?=$item['WebImgName']?>" width="80" style="border-width: 1px; border-style: solid; border-color: #000000;"></a></td>
                                                          		<td class="centrox">Tipo:
<?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Arma";
                                                        break;
                                                        case "2";
                                                        $slot = "Espada";
                                                        break;
                                                        case "3";
                                                        $slot = "Roupa";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Especial";
                                                        break;
                                                    } echo $slot;

                                                        ?>
                                                              </td>                                                        
                                                            </tr>
                                                            	<tr>
                                                                	<td class="centrox">Sexo:
                                                  <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Unisex";
                                                    break;
                                                    } echo $sex;
                                                  ?>
                                                                  </td>
                                                                </tr>
                                                                	<tr>
                                                                    	<td class="centrox">Level:
                                                                        <?=$item['ResLevel']?>
                                                                        </td>
                                                                    </tr>
                                                                    	<tr>
                                                                        	<td class="centrox">Moedas:
                                                                            <font color="green"><?=$item['CashPrice']?></font>
                                                                            </td>
                                                        </tr>
                                                               
                                                    </table>
</div>
<div id="tableshop">
<? }
?>                                                          
</div><br />
