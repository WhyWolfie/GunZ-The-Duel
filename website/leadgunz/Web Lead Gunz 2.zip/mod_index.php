<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?><body onload="FP_preloadImgs(/*url*/'image/ele/playbutton_hover.jpg')" bgcolor="#000000">

			<table border="0" style="border-collapse: collapse" width="100%" height="100%" id="table2">
								<tr>
									<td align="center" background="image/mn_info.jpg" height="76" style="background-image: url(''); background-repeat: no-repeat; background-position: center top">


<div align="center">
									<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" name="obj2" width="417" height="76" border="0" id="obj2">
										<param name="movie" value="image/srv_data.swf">
										<param name="quality" value="High">
										<param name="wmode" value="transparent"><param name="BGCOLOR" value="#000000" />
										<embed src="image/srv_data.swf" width="417" height="76" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj2" quality="High" wmode="transparent" bgcolor="#000000"></object>
									</div></td>
								</tr>
				<tr>
					<td width="481" valign="top">
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="">&nbsp;</td>
							</tr>
							<tr>
								<td background="">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="5">&nbsp;</td>
											<td width="430">
											</td>
											<td width="8">&nbsp;</td>
											<td width="430">
											&nbsp;<div align="center">
												<table border="0" style="border-collapse: collapse; background-image: url('images/dukegunz_panel.PNG'); background-position: center top" width="417" height="151">
													<tr>
														<td width="200" height="24">&nbsp;</td>
														<td width="7" height="24">&nbsp;</td>
														<td width="204" height="24">&nbsp;</td>
													</tr>
													<tr>
														<td width="200" valign="top">
														<table border="0" style="border-collapse: collapse" width="200" height="92%">
															<tr>
																<td width="4">&nbsp;</td>
																<td width="192" valign="top">
																<table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
																	<tr>
																		<td height="20">
																		<span class="menu">
																		<span class="style7"><font size="2" face="Verdana"></font></span><font face="Verdana" size="1"><font color="#FFFFFF">
																		<a href="index.php?do=indexcontent&sub=announcement&id=<?=$n['ICID']?>">
																		<font size="1" face="Verdana"><font style='color: #7CFC00'>� </font><?=$n['Title']?></a></font></span></td>
																  </tr>
                                                                    <?}?>
																</table>																</td>
															</tr>
														</table>														</td>
														<td width="7">&nbsp;</td>
														<td width="204" valign="top">
														<table border="0" style="border-collapse: collapse" width="100%" height="92%">
															<tr>
																<td valign="top">
																<table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                                                                                   <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
																	<tr>
																		<td height="20">
																		<span class="menu">

																		<span class="style7">
																		<font size="1" face="Verdana"></font></span>
																		<a href="index.php?do=indexcontent&sub=update&id=<?=$n['ICID']?>">
																		<font size="1" face="Verdana"><font style='color: #7CFC00'>� </font><?=$n['Title']?></font></a></span></td>
																  </tr>
                                                                    <?}?>
																</table>																</td>
															</tr>
														</table>														</td>
													</tr>
												</table>
											</div>											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">&nbsp;											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="" height="27">&nbsp;</td>
						  </tr>
						</table>
					    <br>
				            <? include "mod_ultimositens.php" ?>
			<? if($_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>
			<? if($_SESSION['UGradeID'] == 255){include"mod_255adminindex.php";echo "</br>";} ?>
					</div></td>
			
					</div></td>
                    </tr>
			</table>