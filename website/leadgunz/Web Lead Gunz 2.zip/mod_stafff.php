<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="images/cont_up.png">&nbsp;</td>
    </tr>
    <tr>
      <td background="images/cont_bg.png"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											<img border="0" src="images/inf/stafflist.png" width="413" height="18"></td>
          <td width="435"><div align="center">
            <p>&nbsp;</p>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>
<span style="color:cyan; background: transparent url(http://tinyurl.com/outgum)">Fundadores</span></a><br><br>
              </tr>
              <tr>
              </tr>
              <tr>
                      <td colspan="2"><div align="center"><strong><font color="cyan">SayntPark - </font>Fundador Geral</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
                      <td colspan="2"><div align="center"><strong><font color="cyan">SayntPark - </font>Fundador / Inactivo</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
   
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">Administrador</span></a><br><br>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="red">SayntPark -</font> Administrador Geral</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="red">SayntPark -</font> Administrador Geral</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>

            <table width="259" border="0" cellspacing="0" cellpadding="0">
   
<span style="color:#FFA500; background: transparent url(http://tinyurl.com/outgum)">Games Masters</span></a><br><br>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="#FFA500">SayntPark -</font> Eventos / Suporte / Report</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="#FFA500">SayntPark -</font> Eventos / Suporte / Report</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
   
<span style="color:#FFE4B5; background: transparent url(http://tinyurl.com/outgum)">Moderador</span></a><br><br>
                        </tr>
                        <tr>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="#FFE4B5">SayntPark -</font> Moderador / Designer</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                      </table>
                          <font color='#00FF00'>Aten��o: N�o h� vagas na equipe, favor nao insista.</font>
                    </div>
            <p align="center">&nbsp;</p></td>
                <td width="10">&nbsp;</td>


          </tr>
          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="images/cont_top.png" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
