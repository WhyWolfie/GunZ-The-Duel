<meta name="generator" content="Namo WebEditor v5.0(Trial)">
<center><span style="text-shadow: 1px 1px 3px #FFFF00;"><span style="color:#00FFFF; background: transparent url(http://tinyurl.com/outgum)"><b>Equipe - Fatality Gunz</b></span><br><br>    </span><center><span style="text-shadow: 1px 1px 3px #FFFF00;"><span style="text-shadow: 1px 1px 3px #07EEF6;"><span style="color:#07EEF6; background: transparent url(http://tinyurl.com/outgum)"><b>Fundadores</b></span><br><br>

Duh.Exorcist - Fundador Geral / Dedicado/ Client / Site<br>Fatalit Vitor- Fundador Geral/Dedicado<br>Anonimo - Fundador Geral / Web Designer<br><br><span style="text-shadow: 1px 1px 3px red;"><span style="color: #F6B607; background: transparent url(http://tinyurl.com/outgum)"><b>Administradores</b></span><br><br>
@Vitor.Hugo-Jiin - Adiministrador Geral <br><br>


<span style="text-shadow: 1px 1px 3px #66ccff;"><span style="color: #2307F6; background: transparent url(http://tinyurl.com/outgum)"><b>Game Masters</b></span><br><br>@Blackstar - Gm Lider<br>Vinicius - Event<br><br>
<span style="text-shadow: 1px 1px 3px #66ccff;"><span style="color: #2307F6; background: VAGAurl(http://tinyurl.com/outgum)"><b></b><span>
<span style="text-shadow: 1px 1px 3px #8B0000;"><span style="color: #ADFF2F; background: transparent url(http://tinyurl.com/outgum)"><b></b></span><br><br>
<br>
        </span></span></span></span></center>


<span style="text-shadow: 1px 1px 3px #00ffff;"><span style="text-shadow: 1px 1px 3px #07EEF6;"><span style="color:#07EEF6; background: transparent url(http://tinyurl.com/outgum)">
<font color="#00ffff">Staff n�o se pede E Nem se compra Se Quer Se Tente Me convencer By: Duh.Exorcist. and Equipe DukeGunZ</font><br>

    </span></span></span></span></span>