<tr>
        <td>
        <div align="center">

            <script type="text/javascript"><!--
            google_ad_client = "pub-6433134487825662";
            /* 728x90, criado 27/07/09 */
            google_ad_slot = "0684883185";
            google_ad_width = 728;
            google_ad_height = 90;
            //-->
            </script>
            <script type="text/javascript"
            src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
            </script>
            <br>
            <table style="border: 0px; padding: 0px; width: 800px">
            <tr>
                <td width="800" colspan="3">&nbsp;</td>
            </tr>