USE [GunzDB]
GO
/****** Object: StoredProcedure [dbo].[ClanEmblemUpload] Script Date: 05/16/2008 14:53:10 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ??? ?? ??
CREATE PROC [dbo].[ClanEmblemUpload]
@Checksum int,
@CLID int,
@URL varchar(24)
AS
SET NOCOUNT ON
IF (LEN(@URL) <= 0) OR (LEN(@URL) > 12)
BEGIN
SELECT 0 AS Ret
END

IF EXISTS (SELECT TOP 1 CLID FROM Clan where (EmblemURL=@URL) AND (DeleteFlag=0))
BEGIN
SELECT 0 AS Ret
return (-1)
END

UPDATE Clan SET EmblemURL=@URL WHERE CLID=@CLID
IF 0 = @@ROWCOUNT BEGIN
SELECT 0 AS Ret
RETURN (-1)
END

UPDATE Clan SET EmblemChecksum=@Checksum WHERE CLID=@CLID
IF 0 = @@ROWCOUNT BEGIN
SELECT 0 AS Ret
RETURN (-1)
END