<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="">&nbsp;</td>
    </tr>
    <tr>
      <td background=""><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											
          <td width="435"><div align="center">
            <p>&nbsp;</p>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>
<span style="color:#FF0000; background: transparent url(http://tinyurl.com/outgum)">Fundadores</span></a><br><br>
              </tr>
              <tr>
              </tr>
              <tr>
                      <td colspan="2"><div align="center"><strong><font color="#FF0000">Mc.Zica - </font>Fundador</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
                      <td colspan="2"><div align="center"><strong><font color="#FF0000">Mitinick - </font>Fundador</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
            <table width="259" 
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">

<span style="color:#FF0000; background: transparent url(http://tinyurl.com/outgum)">Administrador</span></a><br><br>
              </tr>
              <tr>
              </tr>
              <tr>
                      <td colspan="2"><div align="center"><strong><font color="#FF0000">Destroyer - </font>Administrador</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
                      <td colspan="2"><div align="center"><strong><font color="#FF0000">Vaga - </font>Administrador</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        </tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
   

   
<span style="color:#FF0000; background: transparent url(http://tinyurl.com/outgum)">Games Masters</span></a><br><br>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="#FF0000">Vaga - </font>Suport & Report</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                        </tr>
                        <tr>
                          <td colspan="2"><div align="center"><strong><font color="#FF0000">Vaga - </font>Suport & Divulgador</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>

<td colspan="2"><div align="center"><strong><font color="#FF0000">Vaga - </font>Suport & F�rum</strong></div></td>
                        </tr>
                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                      <table width="250" border="0" cellspacing="0" cellpadding="0">
   
</table>

                          <font color='#FF1493'>Aten��o: h� vagas na equipe.</font>
                    </div>
            <p align="center">&nbsp;</p></td>
                <td width="10">&nbsp;</td>


          </tr>
          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
