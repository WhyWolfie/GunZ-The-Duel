<?php
@session_start();
function makepoststring($string) {
    if (strlen($string) > 17){
        return ucfirst(substr($string,0,17) . "...");
    }else{
        return ucfirst($string);
    }
}

function antisql($sql) {
    $check = $sql;
    $sql = str_replace("'","''",$sql);
    $sql = preg_replace(sql_regcase("(select|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables)"),"",$sql);
    $sql = trim($sql);
    $sql = strip_tags($sql);
    $sql = addslashes($sql);
        if( $check != $sql )
        {
	    $pageURL = 'http';
	    $pageURL .= "://";
	    $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
            $logf = fopen("logs/sqlinjectionlogs.txt", "a+");
            fprintf($logf, "Date: %s IP: %s Code: %s, Fixed: %s, Link: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value, $pageURL );
            fclose($logf);
        }
    return $sql;
} 

function ChangeTitle($title) {
    echo "<script language='JavaScript'>
document.title='".$title."';
</script>";
}

function mTrim($cadena){
    return str_replace(" ","",$cadena);
   }

function ErrorBox($data) {
    return "<tr>
<td width='434' colspan='2'>
<div align='center'>
<table border='1' width='95%' height='95%' style='border-collapse: collapse' bordercolor='#FF0000' bgcolor='#FF9191' class='errorbox'>
<tr>
<td>
<table border='0' width='100%' height='100%' style='border-collapse: collapse'>
<tr>
<td valign='bottom' width='1052' colspan='2'>
<img border='0' src='images/icon_error.gif' width='16' height='17'>
<font size='1'><b>An error has occurred!</b></font></td>
</tr>
<tr>
<td width='19'>&nbsp;</td>
<td width='1031' valign='top'><b>$data</b></td>
</tr>
</table>
</td>
</tr>
</table>
</div>
</td>
<td width='8'>&nbsp;</td>
</tr>
<tr>
<td width='145'>
&nbsp;</td>
<td width='289'>
&nbsp;</td>
<td width='8'>&nbsp;</td>
</tr>";
}

function msgbox($text, $url){
echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>"; 
}

function re_dir($url){
echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";

}
function CheckIfExistClan($aid){
    $aid = antisql($aid);
    $a = mssql_query("SELECT * FROM Character(nolock) WHERE AID = '$aid'");
    if( mssql_num_rows($a) > 0 )
    {
        while($char = mssql_fetch_assoc($a))
        {
            if(mssql_num_rows(mssql_query("SELECT * FROM Clan(nolock) WHERE MasterCID = '".$char[CID]."'")) == 1)
            {
                return true;
                break;
            }
        }
    }
    return false;
}

function GetKDRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

function GetClanPercent($Wins, $Losses)
{
    $total = $Wins + $Losses;

    return ($total == 0) ? "0%" : round((100 * $Wins) / $total, 2) . "%";
}

function GetCountryCodeByIP($ipaddress)
{
    $res = mssql_query("SELECT * FROM IPToCountry WHERE IPTo >= dbo.inet_aton('$ipaddress') AND IPFrom <= dbo.inet_aton('$ipaddress')");
    $numrows = mssql_num_rows($res);
    $row = mssql_fetch_assoc($res);
	if($numrows>1)
	{
 	   return "XXXX";
	}
    return $row[CountryCode2];

}

if(!function_exists("re_dir") )
{
function re_dir($url)
{
    echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

function Porcentagem($vitorias, $derrotas)
{
    $total = $vitorias + $derrotas;

    return ($total == 0) ? "100%" : round((100 * $vitorias) / $total, 2) . "%";
}

function GetCharNameByCID($cid)
{
    $ncid = antisql($cid);
    $a = mssql_fetch_assoc(mssql_query("SELECT Name FROM Character(nolock) WHERE CID = '$ncid'"));
    return $a[Name];
}

function GetMasterCID($clid)
{
    $nclid = antisql($clid);
    $a2 = mssql_fetch_assoc(mssql_query("SELECT MasterCID FROM Clan(nolock) WHERE CLID = '$nclid'"));
    return $a2[MasterCID];
}

function GetEmblemURL($clid)
{
    $nclid = antisql($clid);
    $a3 = mssql_fetch_assoc(mssql_query("SELECT EmblemURL FROM Clan(nolock) WHERE CLID = '$nclid'"));
    $eurl2 = $a3[EmblemURL];
$noemb = "../images/no_emblem.png";
if($eurl2 == "")
{
    return $noemb;
}
if(file_exists('clanemblem' . $eurl2))
 {
    return $eurl2;
 }
    return $noemb;
}


function FormatCharName($cid)
{
    $ncid = antisql($cid);
    $res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character(nolock) ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));

    $name = $res[1];

    switch($res[0])
    {
        case 255:
            return "<font color='#FF0000'>$name</font>";
        break;
        case 254:
            return "<font color='#00FF00'>$name</font>";
        break;
        case 253:
            return "<font color='#333333'>$name</font>";
        break;
        default:
            return $name;
        break;
    }
}

function validateEmail( $data )
  {
    list( $eMail, $domainName ) = split( "[@]", $data, 2 );
    $eMail = preg_replace( "/[^A-Za-z0-9\(_)\s\.\-]/", "", $eMail );

    $i = 0;
    $restricted = array( "_-", "-_", ".-", "-.", "._", "_.", "..", "--" );
    while( $i < sizeof( $restricted ) )
    {
      if( strstr( $data, $restricted[$i] ) )
        return( -5 );

      $i++;
    }
   

    if( strlen( $eMail ) == 0 )
      return( -1 );

    if( strstr( $domainName, "." ) == FALSE )
      return( -2 );

    list( $name, $extension ) = split( "[.]", $domainName, 2 );

    $name = preg_replace( "/[^A-Za-z0-9]/", "", $name );
    $extension = preg_replace( "/[^A-Za-z0-9\.]/", "", $extension );

    if( strlen( $name ) == 0 || strlen( $extension ) == 0 )
      return( -3 );

    if( @gethostbyaddr( $domainName ) == NULL && gethostbyname( $domainName ) == $domainName )
      return( -4 );


    return( 1 );
}

function validate_username($username)
{
$check = eregi_replace('([a-zA-Z0-9_.]+)', "", $username);
if(empty($check))
	{
		return( 1 );
	}
	else
	{
		return( -1 );
	}
}

function clean($szValor)
{
        CheckSQL( $szValor );

        $check = $szValor;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');

        $szValor = str_replace($search, '', $szValor);
        $szValor = preg_replace(sql_regcase("/(shutdown|'|GunzDB|backup|select|request|from|insert|delete|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables|name|password|login|account|login|clan|0x|;|character|set|where|#|%27|\*|--|\\\\)/"),"",$szValor);
        $szValor = trim($szValor);
        $szValor = strip_tags($szValor);
        $szValor = addslashes($szValor);
        $szValor = str_replace("'", "''", $szValor);
        $szValor = stripcslashes($szValor);
        $szValor = htmlspecialchars($szValor); 

        if( $check != $szValor )
        {
            $logf = fopen("./logs/injection.txt", "a+");
            fprintf($logf, "%s (m_%s.php) - [AID=%s] - Data: %s IP: %s Valor: %s, Fixed: %s\r\n", $_SERVER[PHP_SELF],$_GET['do'], $_SESSION['AID'],date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $szValor );
            fclose($logf);
            alertbox("Caractere indevido! Por favor arrume!","index.php");
        }

        return( $szValor );
}

?>