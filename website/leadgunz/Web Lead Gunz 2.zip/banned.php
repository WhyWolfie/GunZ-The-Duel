<?php
include "config.php";
include 'anti_sql.php';
include 'inject.php';
?>
<?php
$ip = ''.($_SERVER['REMOTE_ADDR']);
?>
<?php
$query = mssql_query_logged("SELECT * FROM Banneduser WHERE IP = '$ip'");
if (mssql_num_rows($query) == 1)
{
include "bannedip.php";
exit();
}
?>