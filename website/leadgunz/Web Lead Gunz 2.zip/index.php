<?php
include "config.php";
include "_functions.php";
include "protecao/pls.php";
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
include "title.php";
include 'sqlcheck.php';
include "protecao/anti_inject.php";
include "protecao/anti_inject2.php";
include "protecao/anti_injectx.php";
include 'sql_check.php';
include "protecao/antiflood.php";
include 'anti_sql.php';
include 'antisql.php';
include 'antisql1.php';
include 'inject.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta http-equiv="Pragma" content="no-cache" />
<title>Lead GunZ - Website <?=$pagetitle?></title>
<link rel="stylesheet" type="text/css" href="image/style.css">
<link rel="stylesheet" type="text/css" href="frontpage.css" />
<script type="text/javascript">var _siteRoot='index.php',_root='index.php';</script>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
<script type='text/javascript' src='js/presentationCycle.js'></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/nav.js"></script>
<script language="JavaScript" src="js/functions.js"> </script>
<link rel="shortcut icon" href="favicons.ico" />
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" background="http://i51.tinypic.com/scesfr.png">
<div align="center">
	<table border="0" style="border-collapse: collapse" width="900" id="table1">
		<tr><td bgcolor="">
<div id="scroller">
	<marquee><span style="color: #F6B607; background: transparent url(http://tinyurl.com/outgum)"><b>Lead GunZ Melho Gunz Online</b></span><br><br></marquee>
	
</div>
</td>
</tr>
		<tr>
			<td background="duke1" width="900" height="225">&nbsp;</td>
		</tr>

				<tr>
<td bgcolor="#1651B6">
<ul class="topnav">  
     <li><a href="index.php">In�cio</a></li>  
     <li>  
         <a href="index.php?do=register">Registro</a>  
     </li>  
     <li>  
         <a href="index.php?do=download">Downloads</a>  
         <ul class="subnav">  
             <li><a href="index.php?do=downloads&expand=1&sub=client">Lead GunZ </a></li>  
 
         </ul>  
     <li><a href="index.php?do=ranking&sub=individual&expand=1">Ranking</a>
         <ul class="subnav">  
             <li><a href="index.php?do=ranking&sub=individual&expand=1">Individual Ranking</a></li>  
             <li><a href="index.php?do=ranking&sub=clan&expand=1">Cl� Ranking</a></li>  
         </ul>  
       </li>  

     <li><a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1">Loja de Itens.</a>
         <ul class="subnav">  
             <li><a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1">Loja Donator</a></li>  
             <li><a href="index.php?do=evitemshop&sub=listallitems&expand=1&type=1">Loja Evento</a></li>   
         </ul>

     <li><a href="index.php?do=emblemas">Painel de controle</a>
         <ul class="subnav">  
             <li><a href=/UserPanel>Painel Geral</a></li>
             <li><a href="index.php?do=userpanel">User Painel</a></li>  
         </ul> </li>  
     <li><a href="index.php?do=suporte">Utilit�rios</a>
         <ul class="subnav">     
             <li><a href="index.php?do=xequipe">Redes Sociais</a></li>  
             <li><a href="index.php?do=doadores">Lista de Doadores</a></li> 
         </ul>   
     <li><a href="index.php?do=equipe"><font color="#84A8E6">Equipe</font></a></li>
     <li><a href="index.php?do=Chat"><font color="#84A8E6">Chat</font></a></li>
    
  
 </ul></td></tr>
		<tr>
			<td background="">
			
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					  <td width="208" valign="top">
					    <div align="center">
                                                                                           <div align="center"><? include "mod_ILogin.php" ?><br><br>
					     <br>
					      <br>
					<? include "mod_status.php" ?>
					<br>
					<br>
<span style="color:black"></span><a href=""><img src="http://i40.tinypic.com/14tq0jb.gif"><a/>
 <br><span style="color:black"></span><a/>
<br>
<br>

					</div>				  
					<br>
					<br>
					<div align="center">
                    </div></td>
					<td width="481" valign="top">
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "mod_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>
					<td width="206" valign="top">
					<div align="center"><? include "mod_clanranking.php" ?>
					</div>
					<br>
					<br>
					<div align="center">
					<? include "mod_playerranking.php" ?>
					</div>
                                        <br>
                                        <br>
                                        <br>
					<div align="center">
					<? include "mod_cw.php" ?>
					</div>
					<br>
				  <p></td>
				  <td width="12">&nbsp;</td>
				</tr>
				</table>
		  </td>
		</tr>
		<tr>

			<td background="" height="2"><div align="center"><br></tr>

			
	</table>
</div>
</body>
<br>
<center><font color="white"><p>Copyright &copy; 2012-2013 Lead GunZ Todos os direitos reservados.<br />
  Lead GunZ &eacute; uma marca registrada pelo <em><u><b>Duh.Exorcist.</u></b></em><br />
  Duket Gamers � um servidor totalmente gratuito e independente, as doa&ccedil;&otilde;es<br />
  s&atilde;o utilizadas para cobrir os gastos do VPS.</br>
 <b>Website Editada por Duh.Exorcist.</b></br></p>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> 
</script>
