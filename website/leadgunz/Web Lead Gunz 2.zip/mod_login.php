<?
$show =1;
//Check if is logued
if(!function_exists("ShowResetPwdForm")){
    function ShowResetPwdForm(){
        if(!$_SESSION['AID'] == ""){re_dir("index.php");}
        if($_POST['submit'] == ""){
            ?>
            					<form name="pwd" method="POST" action="index.php"><div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="9">&nbsp;</td>
											<td width="436" colspan="3">
Pagina desabilitada, rs.
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


            <?
            }elseif ($_POST['submit'] == "Step 2"){
                $userid = clean($_POST['userid']);
                if($userid == ""){
                    msgbox("Please enter a User ID","index.php");
                }
                $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid'");
                if (mssql_num_rows($res) == 0){
                    msgbox("The user ".ucfirst($userid)." does not exist.","index.php");
                }
                $_SESSION['ResetPwdUser'] = $userid;
                $info = mssql_fetch_assoc($res);
                ?>

                <form name="pwd" method="POST" action="index.php"><div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="14">&nbsp;</td>
											<td width="436" colspan="3">
											<img border="0" src="images/inf/resetaccountdata.png" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											Step 2 of 3</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;<?=@$errorbox?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">Your E-Mail</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="email" size="38"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">&nbsp;Secret 
											Question</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<b><?=$info['Sq']?></b></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">Answer</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="sa" size="38"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<p align="center">
											<input type="submit" value="Step 3" name="submit"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
                <?
                   }elseif ($_POST['submit'] == "Step 3"){
                        $sa = clean($_POST['sa']);
                        $mail = clean($_POST['email']);
                        $res = mssql_query_logged("SELECT * FROM Account WHERE Email = '$mail' AND sa = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
                            					<form method="POST" action="index.php"><div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="436" colspan="3">
											<img border="0" src="images/inf/resetaccountdata.png" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											Step 3 of 3</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">Enter your new 
											password</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<input type="password" name="pw1" size="38"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">Repeat your new 
											password</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<input type="password" name="pw2" size="38"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											&nbsp;</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<p align="center">
											<input type="submit" value="End" name="submit"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>

                            <?
                            }else{
                                msgbox("The E-Mail or the secret answer is incorrect.","index.php");
                            }
                    }elseif ($_POST['submit'] == "End"){
                        if($_POST['pw1'] == $_POST['pw2']){
                            $pw1 = clean($_POST['pw1']);
                            mssql_query_logged("UPDATE Login SET Password = '$pw1' WHERE UserID = '".$_SESSION['ResetPwdUser']."'");
                            msgbox("Password reset complete!","index.php?do=login");
                        }else{
                            msgbox("Please use the same password in both boxes!","index.php");
                        }
                    }








                     }}

//Logout
switch ($_GET['action']) {
    case "logout";
        $user = Clean($_SESSION['UserID']);
        $user = ucfirst($user);
        unset($_SESSION['AID']);
        unset($_SESSION['WarGunZCoins']);
        unset($_SESSION['EventCoins']);
        unset($_SESSION['UGradeID']);  
        setcookie ("Nolife_xLogin_usr", "", time() - 3600);
        setcookie ("Nolife_xLogin_pwd", "", time() - 3600);
        echo "<body bgcolor='#000000'><script language='Javascript'> document.location = 'index.php';alert('$user Desconectado.'); </script>";
        break;
    case "resetpwd";
        ShowResetPwdForm();
        $show =0;
    break;
}

if(!$_SESSION['AID']== ""){
    echo "<script language='Javascript'> document.location = 'index.php';alert('Already logged out'); </script>";
}


if (isset($_POST['submit']) and $show ==1){
    $user = clean($_POST['userid']);
    $pwd = Clean($_POST['pasw']);
    $sql = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."' AND Password = '".$pwd."'");
    if (mssql_num_rows($sql) == 1){
        $data = mssql_fetch_assoc($sql);
        $_SESSION['AID'] =  $data['AID'];
        $_SESSION['UserID'] = ucfirst($user);
        $_SESSION['WarGunzCoins'] = $data['WarGunzCoins'];
        $_SESSION['EventCoins'] = $data['EventCoins'];
        //---
        $res2 = mssql_query_logged("SELECT * FROM Account WHERE AID = '".$data['AID']."'");
        $aData = mssql_fetch_assoc($res2);
        $_SESSION['UGradeID'] = $aData['UGradeID'];
        if($_POST['cookie'] == "ON"){
            setcookie("Nolife_xLogin_usr", $user, time()+60*60*24*100);
            setcookie("Nolife_xLogin_pwd", md5("Nolife_xc_".$data['Password']), time()+60*60*24*100);
        }else{
            setcookie ("Nolife_xLogin_usr", "", time() - 3600);
            setcookie ("Nolife_xLogin_pwd", "", time() - 3600);
        }
        header("Location: index.php");
    }else{
        echo "<body bgcolor='#000000'><script language='Javascript'> alert('Usuario ou senha inccoretos.');document.location = 'index.php?do=login'; </script>";
    }
}
if ($show ==1){
?>
<form name="reg" method="POST" action="index.php?do=login&header=1"><body bgcolor="#323232">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="436" colspan="2">
											<img border="0" src="images/inf/userlogin.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<font color="#FF0000" face="Tahoma">
											<b><font size="2">
											<?=@$error ?></font></font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208" valign="middle" align="right">
											Login:</td>
											<td width="226" valign="middle">
											<input type="text" name="userid" size="20" class="login"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208" align="right">
											Senha:</td>
											<td width="226">
											<input type="password" name="pasw" size="20" class="login" style="background-image: url('images/passwordbg.jpg')"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208">&nbsp;
											</td>
											<td width="226">
											<input type="checkbox" name="cookie" value="ON" checked>Manter-me logado</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<p align="center">
											<font color="#BCBCBC">&nbsp;
											<a href="index.php">
											Recuperar senha</a> | 
											<a href="register.php">
											Registre-se!</a></font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<p align="center">
											<input type="submit" value="Login �" name="submit"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24" colspan="2">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>

<?
}
?>