<?php 

include "anti_sql.php";
include "inject.php";

$ip = $_SERVER['REMOTE_ADDR']; 
$time = date("l dS of F Y h:i:s A"); 
$script = $_SERVER[PATH_TRANSLATED]; 
$fp = fopen ("[WEB]SQL_Injection.txt", "a+"); 
$sql_inject_1 = array(";","'","%",'"'); #Whoth need replace 
$sql_inject_2 = array("", "","","&quot;"); #To wont replace 
$GET_KEY = array_keys($_GET); #array keys from $_GET 
$POST_KEY = array_keys($_POST); #array keys from $_POST 
$COOKIE_KEY = array_keys($_COOKIE); #array keys from $_COOKIE 
/*begin clear $_GET */ 
for($i=0;$i<count($GET_KEY);$i++) 
{ 
$real_get[$i] = $_GET[$GET_KEY[$i]]; 
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]])); 
if($real_get[$i] != $_GET[$GET_KEY[$i]]) 
{ 
fwrite ($fp, "IP: $ip\r\n"); 
fwrite ($fp, "Method: GET\r\n"); 
fwrite ($fp, "Value: $real_get[$i]\r\n"); 
fwrite ($fp, "Script: $script\r\n"); 
fwrite ($fp, "Time: $time\r\n"); 
fwrite ($fp, "==================================\r\n"); 
} 
} 
/*end clear $_GET */ 
/*begin clear $_POST */ 
for($i=0;$i<count($POST_KEY);$i++) 
{ 
$real_post[$i] = $_POST[$POST_KEY[$i]]; 
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]])); 
if($real_post[$i] != $_POST[$POST_KEY[$i]]) 
{ 
fwrite ($fp, "IP: $ip\r\n"); 
fwrite ($fp, "Method: POST\r\n"); 
fwrite ($fp, "Value: $real_post[$i]\r\n"); 
fwrite ($fp, "Script: $script\r\n"); 
fwrite ($fp, "Time: $time\r\n"); 
fwrite ($fp, "==================================\r\n"); 
} 
} 
/*end clear $_POST */ 
/*begin clear $_COOKIE */ 
for($i=0;$i<count($COOKIE_KEY);$i++) 
{ 
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]]; 
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]])); 
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]]) 
{ 
fwrite ($fp, "IP: $ip\r\n"); 
fwrite ($fp, "Method: COOKIE\r\n"); 
fwrite ($fp, "Value: $real_cookie[$i]\r\n"); 
fwrite ($fp, "Script: $script\r\n"); 
fwrite ($fp, "Time: $time\r\n"); 
fwrite ($fp, "==================================\r\n"); 
} 
} 

/*end clear $_COOKIE */ 
fclose ($fp); 
?>
<center>

<style type="text/css">
.registro{font: , "Times New Roman", Times, serif; color: #000; font-size: 14px;}
.registroinput{font: , "Times New Roman", Times, serif; color: #000; font-size: 14px; border: #000 1px solid; background: #;}
</style>
<?php
/*
This script was written by Wizkid.
All rights reserved. Any support can be requested via RageZone.

You're allowed to edit this script and modify the template.
However, you are NOT allowed to remove and/or edit my copyright.

Removing this copyright will be your death.
*/

//Edit to fit YOUR requirements.
$servername = "Knight Gunz";
$accounttable = "Account";
$logintable = "Login";

//Edit these variables. If not, no regpage for you. (Or you're fuxpro with the same logins as me.)
$host = "MUSTHOST-CD068D\SQLEXPRESS";
$user = "sa";
$pass = "741852963z";
$dbname = "GunzDB";

$connect = odbc_connect("Driver={SQL Server};Server={$host}; Database={$dbname}", $user, $pass) or die("Can't connect the MSSQL server.");

//The well-known antisql injection. Bad enough, it's needed.
function antisql($sql) {
    $sql = preg_replace(sql_regcase("(select|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables)"),"",$sql);
    $sql = trim($sql);
    $sql = strip_tags($sql);
    $sql = addslashes($sql);
    return $sql;
}

//My favorite function. Get The Fuck Off. (Nothing personally :].)
function gtfo($wut) {
echo "<center><table width='400' cellpadding='5' cellspacing='0' border='0' class='registro'>
<tr>
<td width='100%'><b>Knight Gunz.</b></td>
</tr>
<tr>
<td width='100%'><center>$wut</center></td>
</tr>
</table>";
die();
}

//Check email function. This to prevent fake emails. (Remember the time YOU doing that?)
function checkemail($address) {
list($local, $host) = explode("@", $address);
$pattern_local = "^([0-9a-z]*([-|_]?[0-9a-z]+)*)(([-|_]?)\.([-|_]?)[0-9a-z]*([-|_]?[0-9a-z]+)+)*([-|_]?)$";
$pattern_host  = "^([0-9a-z]+([-]?[0-9a-z]+)*)(([-]?)\.([-]?)[0-9a-z]*([-]?[0-9a-z]+)+)*\.[a-z]{2,4}$";
$match_local = eregi($pattern_local, $local);
$match_host = eregi($pattern_host, $host);
if($match_local && $match_host) {
return 1;
}
else {
return 0;
}
}

//The num_rows() function for ODBC since the default one always returns -1.
function num_rows(&$rid) {

//We can try it at least, right?
$num= odbc_num_rows($rid);
if ($num >= 0) {
return $num;
}

if (!odbc_fetch_row($rid, 1)) {
odbc_fetch_row($rid, 0);
return 0;
}

if (!odbc_fetch_row($rid, 2)) {
odbc_fetch_row($rid, 0);
return 1;
}

$lo= 2;
$hi= 8192000;

while ($lo < ($hi - 1)) {
$mid= (int)(($hi + $lo) / 2);
if (odbc_fetch_row($rid, $mid)) {
$lo= $mid;
} else {
$hi= $mid;
}
}
$num= $lo;
odbc_fetch_row($rid, 0);
return $num;
}
?>
<?php
//Oh well. Let's create the variable $ip to start with.
$ip = antisql($_SERVER['REMOTE_ADDR']);

/*
An extra feature. This is NOT enabled before you remove this + the comment thingy's.

To ban 1 IP it will be:
if ($ip == "xxxxxx")
{
gtfo("Your IP is blacklisted.");
}

For multiple IP's, use this way:
if ($ip == "xxxxxx" OR $ip == "xxxxxx")
{
gtfo("Your IP is blacklisted.");
}
*/

//Get the AID out of the Login table (defined at the top of this file) where LastIP is the visitors IP.
$query1 = odbc_exec($connect,"SELECT AID FROM $logintable WHERE LastIP = '$ip'");

//Understable for the real people. Editing this without knowledge will be the death of your regpage.
$i=1;
while (odbc_fetch_row($query1, $i)){
$aid = odbc_result($query1, 'AID');

$query2 = odbc_exec($connect,"SELECT UGradeID FROM $accounttable WHERE AID = '$aid'");
odbc_fetch_row($query2);
$ugradeid = odbc_result($query2, 1);

if ($ugradeid == "253")
{
//Get the fuck off.
gtfo("Sua conta foi banida, e voc� n�o pode criar uma nova conta.");
}

$i++;
}

//The doreg part.
if (isset($_GET['act']) AND $_GET['act'] == "doreg")
{

//Check for any shit.
if (!is_numeric($_POST['age']) OR !checkemail($_POST['email']) OR empty($_POST['username']) OR empty($_POST['password']) OR empty($_POST['email']) OR empty($_POST['name']) OR empty($_POST['age']))
{
gtfo("Error Preencha os dados Corretamente.");
}

//Check if the username exists already.
$query1 = odbc_exec($connect, "SELECT AID FROM $accounttable WHERE UserID = '" . antisql($_POST['username']) . "'");
$count1 = num_rows($query1);

if ($count1 >= 1)
{
gtfo("Us�ario em uso.");
}

//Check if the Email is in use.
$query2 = odbc_exec($connect, "SELECT AID FROM $accounttable WHERE Email = '" . antisql($_POST['email']) . "'");
$count2 = num_rows($query2);

if ($count2 >= 1)
{
gtfo("Email escolhido em uso.");
}

//Regdate
date_default_timezone_set('UTC');
$regdate = date("Y-m-d H:i:s");

//Time for the real work. Editing this will be the end of your regpage.
$query3 = odbc_exec($connect, "INSERT INTO $accounttable (UserID, UGradeID, PGradeID, RegDate, Sq, Sa, Email, Age, Name) VALUES ('".antisql($_POST['username'])."', '0', '0', getdate(), '".antisql($_POST['Sa'])."', '".antisql($_POST['Sq'])."', '".antisql($_POST['email'])."', '".antisql($_POST['age'])."', '".antisql($_POST['name'])."')");

$query4 = odbc_exec($connect, "SELECT AID FROM $accounttable WHERE UserID = '" . antisql($_POST['username']) . "'");
odbc_fetch_row($query4);
$aid = odbc_result($query4, 1);

//If no results comes back. (Registration failed.)
if (!$aid)
{
gtfo("Shit happened. Please report this bug at our forums.");
}

odbc_exec($connect, "INSERT INTO $logintable (UserID, AID, Password) VALUES ('".antisql($_POST['username'])."', '$aid', '".antisql($_POST['password'])."')");

//When everything is done, show the username/password to the visitor.
gtfo("Sua conta foi criada com �xito.<br><br>
Username: $_POST[username]<br>
Password: $_POST[password]<br><br>
Voc� pode jogar agora mesmo $servername!");
}

//Here the party begins. Feel free to edit this.
echo "<table width='350' class='registro'>
<form action='" . $_SERVER['PHP_SELF'] . "?act=doreg' method='POST'>
<b class='registro'>Registro - $servername.</b><br><br>
<tr>
<td width='50%'><b>Usuario:</b></td>
<td width='50%'><input type='text' name='username'></td>
</tr>
<tr>
<td width='50%'><b>Senha:</b></td>
<td width='50%'><input type='password' name='password'></td>
</tr>
<tr>
<td width='50%'><b>E-mail:</b></td>
<td width='50%'><input type='text' name='email'></td>
</tr>
<tr>
<td width='50%'><b>Nome:</b></td>
<td width='50%'><input type='text' name='name'></td>
</tr>
<tr>
<td width='50%'><b>Idade:</b></td>
<td width='50%'><input type='text' name='age'></td>
</tr>



<tr>
<td width='50%'><b>Pergunta Secreta:</b></td>
<td width='50%'><input type='text' name='Sa'></td>
</tr>
<tr>
<td width='50%'><b>Resposta Secreta:</b></td>
<td width='50%'><input type='text' name='Sq'></td>
</tr>


<tr>
<td width='50%' colspan='2'><i>Clicando em Registrar significa que voc&ecirc; concorda com os termos de uso do SoftKnighte Knight Gunz e com as regras do mesmo.</i></td>
</tr>
<tr>
<td width='50%' colspan='2'><i>OBS: N&atilde;o utilize e-mail inexistente, pois s&oacute; com ele voc&ecirc; pode recuperar sua conta.</i></td>
</tr>
<tr>
<td width='50%'><b></b></td>
<td width='50%'><input type='submit' value='Cadastrar' class='registroinput'></td>
</tr>
</table>";
?>
