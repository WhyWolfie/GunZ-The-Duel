<?
if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 and !$_SESSION['AID'] == ""){
    $userid = $_SESSION['UserID'];
    $aid = $_SESSION['AID'];
    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid' AND AID = '$aid'");
    $data = mssql_fetch_assoc($res);
    if(!$data['UGradeID'] == $_SESSION['UGradeID']){
        echo "Admin Session Invalid";
    }
}else{
    die("Voc� n�o tem pemiss�o para acessar esta pagina.");
}
?>
<?

    if( isset($_POST['addecoin2']) )
    {
        $type = antisql($_POST['type']);
        $id = antisql($_POST['id']);
        $coin = antisql($_POST['coin']);

        if( $type == "" || $id == "" || $coin == "" )
        {
            echo "Prencha todos os campos<br>";
            die();
        }

        if( $type == 0 )
        {
            $query02 = mssql_query("SELECT AID FROM Login WHERE UserID = '$id'");
            $part = "UserID";
        }
        elseif( $type == 1 )
        {
            $query02 = mssql_query("SELECT UserID FROM Account WHERE AID = '$id'");
            $part = "AID";
        }
        else
        {
            die();
        }

        if( mssql_num_rows($query02) != 1 )
        {
            echo "Conta nem existe, af!" , "<meta HTTP-EQUIV='Refresh' CONTENT='2;URL=index.php?do=addecoin'>";
            die();

echo "<meta HTTP-EQUIV='Refresh' CONTENT='4;URL=index.php?do=addecoin.php'>";

        }
        else
        {
            mssql_query("UPDATE Login SET EVCoins = EVCoins + $coin WHERE $part = '$id'");
            echo "Coins dadas com Sucesso!" , "<meta HTTP-EQUIV='Refresh' CONTENT='2;URL=index.php?do=addecoin'>";
            die();
        }
    }

if(!isset($_POST['id'])){
?>

<table border="0" style="border-collapse: collapse" id="addecoin">
<tr><td colspan="2"><b>Adicionar Event Coins</b></td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<form method="post" action="index.php?do=addecoin">
<tr>
<tr><td colspan="2">&nbsp;</td></tr>
</form>
</table>

<br />
<table border="0" style="border-collapse: collapse" id="addecoin2">
<tr><td colspan="2"><b>Event Coins</b></td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<form method="post" action="index.php?do=addecoin">
<tr>
    <td>
    <select name="type">
        <option value="0">UserID</option>
        <option value="1">AID</option>
    </select>
 &nbsp;&nbsp;<input type="text" name="id" />&nbsp;&nbsp;coin:&nbsp;&nbsp;
 <input type="text" name="coin" />
    &nbsp;&nbsp;<input type="submit" name="addecoin2" value="Add coin" />
    </td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
</form>
</table>
<? } ?>

By Alfred�o!