
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/">&nbsp;</td>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/">
								<div align="center">

<span style="color:#00BFFF; background: transparent url(http://tinyurl.com/outgum)">Lista de Doadores</span></a><br><br>
<br>
<span style="color:ff0080; background: transparent url(http://tinyurl.com/outgum)">Duh.Exorcist - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>
<br>
<span style="color:red; background: transparent url(http://tinyurl.com/outgum)">  - </span>Thanks for Donate</a><br><br>

<br>
<span style="color:#6959CD; background: transparent url(http://tinyurl.com/outgum)">Agradecimento a todos que donataram para o Duke Gunz Obrigado.</span></a><br><br>
















								</div>
								</td>
							</tr>
							<tr>
								<td background="images/" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>