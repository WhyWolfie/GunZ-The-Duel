<?php
$gunzname = "Duke GunZ";  //Your Server Name

$_MSSQL['Host'] = "LGV-29A597A36A4\SQLEXPRESS";
$_MSSQL['User'] = "sa";
$_MSSQL['Pass'] = "magicgunz";
$_MSSQL['DB'] = "GunzDB";

$error1 = "Cant connect to database";
$error2 = "Cant find Database";

$con = mssql_connect($_MSSQL['Host'], $_MSSQL['User'], $_MSSQL['Pass']) or die($error1);
mssql_select_db($_MSSQL['DB']) or die($error2);
?>