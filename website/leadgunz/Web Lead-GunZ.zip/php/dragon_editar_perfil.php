 <div class="box_two">
 <div class="box_two_title">Editar Perfil</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if ($_SESSION['AID'] == ""){

die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
	

$editar = $_GET['editar'];

if($editar == nao){
?>
<form id="site_Login" name="site_Login" method="post" action="?page=editar_perfil&editar=nao2">
Selecione o Personagem que voce quer desabilitar o perfil:<br>
<select name="char22" class="text">
<?
$pegaLogin = mssql_fetch_row(mssql_query("SELECT AID FROM LOGIN WHERE USERID='".$_SESSION["login"]."'"));
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID='$pegaLogin[0]'");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[1].'">'.$array[1].'</option>';
}
?>
</select><br<br>
<input type="submit" name="logar" value="Desabilitar" />
</form>
<?
}else{

if($editar == nao2){

$char22 = ($_POST['char22']);

mssql_query("UPDATE Character SET Perfil = '0' WHERE Name = '$char22'");

echo "Perfil de $char22 desabilitado com sucesso!";

}else{

if (!(isset($_GET['perfil'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?page=editar_perfil&perfil=go">
Deseja Ativar Seu perfil:
<select
onchange="if(!options[selectedIndex].defaultSelected)
location='?page='+options[selectedIndex].value">
<option value="1">Sim</option>
<option value="editar_perfil&editar=nao">Nao</option>
</select>
<br><br>
Personagem:
<select name="char" class="text">
<?
$pegaLogin = mssql_fetch_row(mssql_query("SELECT AID FROM LOGIN WHERE USERID='".$_SESSION["login"]."'"));
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID='$pegaLogin[0]'");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[1].'">'.$array[1].'</option>';
}
?>
</select><br><br>
Nome:
<input type="text" id="nome" value="" class="log_field" size="16" name="nome" value="" maxlength="50"><br><br>
Idade:
<select name="idade" class="text">
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select><br><br>
Sexo:
<select name="sexo" class="text">
<option value="Masculino">Maculino</option>
<option value="Feminino">Feminino</option>
</select><br><br>
Cidade:
<input type="text" id="cidade" value="" class="log_field" size="16" name="cidade" value="" maxlength="50"><br><br>
MSN:
<input type="text" id="MSN" value="" class="log_field" size="16" name="MSN" value="" maxlength="200"><br><br>
Skype:
<input type="text" id="skype" value="" class="log_field" size="16" name="skype" value="" maxlength="100"><br><br>
Fale um pouco sobre voce:<br>
<textarea name="conteudo" class="text" cols="35" rows="4"></textarea><br><br>
<input type="submit" name="logar" value="Editar!" />
</form>
<?
}else{

$ativar = ($_POST['ativar']);
$char =	($_POST['char']);
$nome = ($_POST['nome']);
$idade = ($_POST['idade']);
$sexo = ($_POST['sexo']);
$cidade = ($_POST['cidade']);
$MSN = ($_POST['MSN']);
$skype = ($_POST['skype']);
$conteudo = ($_POST['conteudo']);
$verifica = mssql_fetch_row(mssql_query("SELECT Nick FROM Perfil WHERE Nick='".$char."'"));

if(empty($char)
or empty($idade)
or empty($sexo)
or empty($cidade)
or empty($MSN)
or empty($skype)
or empty($conteudo))
{
exit('Preencha todos os campos.');
}else{

if($verifica >= 1){
mssql_query("UPDATE Character SET Perfil = '1' WHERE Name = '$char'");
mssql_query("UPDATE Perfil SET Nome = '$nome', Idade = '$idade', Sexo = '$sexo', Cidade = '$cidade', MSN = '$MSN', Skype = '$skype', Mim = '$conteudo' WHERE Nick = '$char'");
exit('Obrigado por atualizar seu Perfil!');
}
if($verifica >= 0){
mssql_query("UPDATE Character SET Perfil = '1' WHERE Name = '$char'");
mssql_query("INSERT INTO Perfil (Nick, Nome, Idade, Sexo, Cidade, MSN, Skype, Mim) VALUES ('$char', '$nome', '$idade', '$sexo', '$cidade', '$MSN', '$skype', '$conteudo')");
exit('Obrigado por atualizar seu Perfil!');
}
}
}
}
}
}
?>