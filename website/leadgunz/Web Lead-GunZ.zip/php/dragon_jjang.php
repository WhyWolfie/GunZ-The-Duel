 <div class="box_two">
 <div class="box_two_title">Jjang</div>
<div align="center">
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
// Crazy

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

$busca57 = mssql_query("SELECT EVCoins FROM Login WHERE AID = '$aid22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION['AID'])))
{
echo "<script language='Javascript'> alert('Para acessar essa pagina voc� precisa estar logado.');document.location = 'index.php'; </script>";
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
<br>
<br>
<b>Comprando jjang</b><br>
<br>

Qual utilidade do jjang?<br>
- Nada, apenas um adere�o para seu personagem .<br>
<br>

Qual valor?<br>
- Para ter um jjang voc� gastar� 40 EV Coins .<br>
<br>

<a href="?page=jjang&step=1"><input type="submit" name="submit" class="button validate" value="Comprar"/></a>
<br>

Voc� tem um total de 
<?=$busca58[0]?>
 EV Coins , apos fazer essa compra ira sobrar 
<?=$busca58[0]-40?>
<br><br>
<?
}else{


$buscanome = "SELECT EVCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 40) 
{
	echo "<script language='Javascript'> alert('Desculpe, seus EV Coins n�o s�o suficientes.');document.location = 'index.php'; </script>";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE AID = '$aid22'");
mssql_query("update Login set EVCoins=EVCoins-10 where AID='$aid22'");
echo "<script language='Javascript'> alert('Compra realizada,relogue.');document.location = 'index.php'; </script>";
}


}
}

$date = date("d-m-y - H:i:s");
$logfile = fopen("logs/jjang_logs.txt","a+");
$logtext = "$date - IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou Jjang. \r\n";
fputs($logfile, $logtext);
fclose($logfile);


?>
</span>
</div>