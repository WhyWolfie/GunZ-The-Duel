<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
$res = mssql_query_logged("SELECT TOP 8 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
?>
<?
if(mssql_num_rows($res) == 0){
?>
<li><a href="#">Nemhuma not�cia adicionada.</a></li>
<?
}else{
while($n = mssql_fetch_assoc($res)){
?>

                     <li><a href="?page=noticias&sub=buscar&id=<?=$n['ICID']?>"><?=$n['Title']?></a></li>
<?}}?>