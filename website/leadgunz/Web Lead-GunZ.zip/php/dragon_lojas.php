 <div class="box_two">
 <div class="box_two_title">Lojas</div>
<center>
<a href="index.php?page=rzitemshop&sub=listallitems&expand=1&type=1"><img src="images/loja/1d.png"></a>
</br>
<br>
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=1"><img src="images/loja/2e.png"></a>
</center>
