<?
$cinfo = antisql($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan Does not Exist","index.php");
exit();
}

$clid = $clan->CLID;
?> 
 <div class="box_two">
 <div class="box_two_title">Informa��es do cl� (<?=$clan->Name?>)</div>
<img src="<?=($clan->EmblemUrl == "") ? "images/_clan.png" : $clan->EmblemUrl?>" width="100" height="100"/>
<table>
<tr><td>Nome:</td><td><?=$clan->Name?></td></tr>
<tr><td>Pontos:</td><td><?=$clan->Point?></td></tr>
<tr><td>Venceu:</td><td><?=$clan->Wins?></td></tr>
<tr><td>Perdeu:</td><td><?=$clan->Losses?></td></tr>
<tr><td>Empatou:</td><td><?=$clan->Draws?></td></tr>
<?
$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Membro";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Dono";
    break;
}


?>
<table>
<tr><td><? echo $grade; ?>:</td><td><a href="index.php?page=charinfo&id=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td></tr>
</table>
								  <? } ?>