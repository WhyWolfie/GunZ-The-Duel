 <div class="box_two">
 <div class="box_two_title">Banir Conta</div>
<?
include "protect/authgm.php";
include "protect/inject.php";

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['banir']))
{
	$tipo = Filtrrar($_POST['tipo']);
	$usuario = Filtrrar($_POST['usuario']);
	if(empty($tipo) || empty($usuario))
{
	msgbox("No deixe espaos em branco","index.php");
}
	if($tipo == "UserID")
{
	$wQuery01 = mssql_query("SELECT * FROM Account WHERE UserID='".$usuario."'");
}else{
	$wQuery01 = mssql_query("SELECT * FROM Account a INNER JOIN Character b ON a.AID=b.AID WHERE b.Name='".$usuario."'");
}
	if(!mssql_num_rows($wQuery01))
{
	msgbox("".$tipo." no existe","index.php");

}else{
	$wQuery02 = mssql_fetch_object($wQuery01);
	if($wQuery02->UGradeID == 253)
	{
	msgbox("A conta foi banida com sucesso","index.php");
	}
}
	mssql_query("UPDATE Account SET UGradeID='253' WHERE AID='".$wQuery02->AID."'");
	msgbox("A conta: ".$wQuery02->UserID." foi banida","index.php");
}else{
?>
<br><br>
<form name="ban" method="post">
<select name="tipo">
<option value="UserID">UserID</option>
<option value="Character">Character</option>
</select> : <input type="text" name="usuario">
<input name="banir" value="Banir" type="submit">
</form>
<? } ?>
