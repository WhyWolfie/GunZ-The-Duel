 <div class="box_two">
 <div class="box_two_title">Confirmar Pagamento</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if ($_SESSION['AID'] == ""){

die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
	

$step = ($_GET['step']);
$login22 =($_SESSION["login"]);

if ($step == "")
?>


<form enctype="multipart/form-data" action="?page=confirmar_pag&step=done" method="POST">
Selecione o comprovante:<br><br>
<input name="uploaded" type="file" />
<br><br>
<input type="submit" value="Enviar" />
</form>


<?
if ($step == "done") 
{

	$emblem = $_POST['uploaded'] ;
	$target = "comprovantes/";
	$target = $target . basename( $_FILES['uploaded']['name']) ;
	$ok=1;


	$partes = pathinfo( $_FILES['uploaded']['name'] );
	$extensao = $partes['extension'];

	$extensoes = array('jpg', 'jpeg', 'png', 'gif');

	if( !in_array(strtolower($extensao), $extensoes) )
	{
		$err .= "<p>Formato da imagem n�o aceita.</p><br>";
		$ok = 0;
	}

	
	if ($ok == 0)
	{
		echo "<p>Desculpe, sua imagem n�o foi aceita.<br />Verifique os erros:</p><br /><br />";
		echo "$err";
	}
	else
	{
		if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
			{
                                mssql_query("INSERT INTO Comprovantes (UserID, Link) VALUES ('$login22', '".$target."')");
				echo "<p>Seu comprovante foi inserido com sucesso.</p><br />";
			}
			else
			{
				echo "<p>Desculpe, ocorreu um problema, tente novamente.</p>";
			}
	}




}
}
?>


