 <div class="box_two">
 <div class="box_two_title">Loja Evento</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if ($_GET['expand'] == 1){
?>
<? }





if(!function_exists("ListAllItems")){
function ListAllItems(){
    if(!isset($_GET['type'])){
        $type = "";
    }else{
        $type = "Slot = '".clean($_GET['type'])."' AND";
    }

    $res = mssql_query_logged("SELECT * FROM EVCashShop WHERE ".$type." Opened = '1'");

    ?>
                                                                                <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 3) {
                                                $count = 1;
                                                echo "";
                                                ?>

											
		<div id="item_loja">
			<div id="item_imagem">
				<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>">
				<img original-title="Lead GunZ" class="shop-image" src="images/shop/<?=$item['WebImgName']?>" alt="Lead GunZ" name="item" width="100" height="100" border="0" id="item_foto"/>
				</a>
			</div>
			<div id="item_descricao">
				<strong>
				<div id="loja_link">
					<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>"><?=$item['Name']?></a>
				</div>
				</strong><br/>
				<strong>Tipo: </strong>Evento<br/>
				<strong>Sexo: </strong><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?><br/>
				<strong>N&iacute;vel: </strong><?=$item['ResLevel']?><br/>
				<strong>Pre&ccedil;o: </strong><?=$item['CashPrice']?><br/><br/>
				<strong>
				<div id="loja_link">
					<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>">Detalhes</a>
				</div>
				</strong>
			</div>
		</div>
											
                                                <?
                                            }else{
                                                ?>
		<div id="item_loja">
			<div id="item_imagem">
				<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>">
				<img original-title="Lead GunZ" class="shop-image" src="images/shop/<?=$item['WebImgName']?>" alt="Lead GunZ" name="item" width="100" height="100" border="0" id="item_foto"/>
				</a>
			</div>
			<div id="item_descricao">
				<strong>
				<div id="loja_link">
					<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>"><?=$item['Name']?></a>
				</div>
				</strong><br/>
				<strong>Tipo: </strong>Evento<br/>
				<strong>Sexo: </strong><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?><br/>
				<strong>N&iacute;vel: </strong><?=$item['ResLevel']?><br/>
				<strong>Pre&ccedil;o: </strong><?=$item['CashPrice']?><br/><br/>
				<strong>
				<div id="loja_link">
					<a href="index.php?page=evitemshop&sub=details&id=<?=$item['CSID']?>">Detalhes</a>
				</div>
				</strong>
			</div>
		</div>
                                                <?
                                                 $count++;
                                            }
                                        }   ?>
											<td width="30">
											&nbsp;<p>&nbsp;</p>
											<p>&nbsp;</p>
											<p></td>
										</tr>

										<tr>
											<td width="445" colspan="2">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>
										</table>
								</td>
							</tr>
						</table><br><br><br><br><center>
				<div id="loja_link">
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=1">[1]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=2">[2]</a> -
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=3">[3]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=4">[4]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=5">[5]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=6">[6]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=7">[7]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=8">[8]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=9">[9]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=10">[10]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=11">[11]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=12">[12]</a> - 
<a href="index.php?page=evitemshop&sub=listallitems&expand=1&type=13">[13]</a> - 

				</div></center>
    <?
    }  }
if(!function_exists("ShowItemsDetails")){
    function ShowItemsDetails(){
    if($_GET['id'] == ""){
        re_dir("index.php");
    }
    $itemid = clean($_GET['id']);
    $res = mssql_query_logged("SELECT * FROM EVCashShop WHERE CSID = '$itemid'");
    $item = mssql_fetch_assoc($res);
    ?>
	<div id="conteudo_include">
		<p>
			<div align="center">
				<table border="0" style="border-collapse: collapse" width="605">
				<tr>
					<td width="599" valign="top">
						<div align="center">
							<table border="0" width="603">
							<tr>
								<td class="detalhes" width="597" colspan="3">&nbsp;
									
								</td>
							</tr>
							<tr>
								<td class="detalhes" width="7">&nbsp;
									
								</td>
								<td class="detalhes" width="583" valign="top">
									<div align="center">
										<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" bordercolor="#4A4648">
										<tr>
											<td>
												<table border="0" style="border-collapse: collapse" width="579" height="100%">
												<tr>
													<td width="11">&nbsp;
														
													</td>
													<td width="104">&nbsp;
														
													</td>
													<td width="458" colspan="2">&nbsp;
														
													</td>
												</tr>
												<tr>
													<td width="11" rowspan="3">&nbsp;
														
													</td>
													<td width="104" valign="top">
														<img id="item" src="images/shop/<?=$item['WebImgName']?>" width="100" heigth="100">
													</td>
													<td width="443">
														<div align="center">
															<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td colspan="2">
																	<b><?=$item['Name']?> </b>
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td colspan="2">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td width="45" align="left">
																	<span class="branco">Tipo: </span>
																</td>
																<td width="362" align="left">
																	Evento
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td width="45" align="left">
																	<span class="branco">Sexo: </span>
																</td>
																<td width="362" align="left">
																	<?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?>
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td width="45" align="left">
																	<span class="branco">N&iacute;vel: </span>
																</td>
																<td width="362" align="left">
																	<?=$item['ResLevel']?>
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td width="45" align="left">
																	<span class="branco">Pre&ccedil;o: </span>
																</td>
																<td width="362" align="left">
																	<?=$item['CashPrice']?>
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td colspan="2" class="detalhes">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="18">&nbsp;
																	
																</td>
																<td colspan="2" class="detalhes">&nbsp;
																	
																</td>
															</tr>
															</table>
														</div>
													</td>
													<td width="13" rowspan="3">&nbsp;
														
													</td>
												</tr>
												<tr>
													<td width="544" colspan="2" style="background-repeat: no-repeat; background-position: center" height="144">
														<div align="center">
															<table border="0" style="border-collapse: collapse" width="544" height="100%">
															<tr>
																<td width="181">
																	<div align="center">
																		<table border="1" style="border-collapse: collapse;" width="175" height="98" bordercolor="#565053">
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Peso
																			</td>
																			<td width="87" align="right">
																				 <?=$item['Weight']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Damage
																			</td>
																			<td width="87" align="right">
																				 <?=$item['Damage']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Delay
																			</td>
																			<td width="87" align="right">
																				 <?=$item['Delay']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Controle
																			</td>
																			<td width="87" align="right">
																				 <?=$item['Control']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Muni&ccedil;&atilde;o
																			</td>
																			<td width="87" align="right">
																				 <?=$item['Magazine']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		</table>
																	</div>
																</td>
																<td width="181">
																	<div align="center">
																		<table border="1" style="border-collapse: collapse;" width="175" height="98" bordercolor="#565053">
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Mun M&aacute;xima
																			</td>
																			<td width="87" align="right">
																				 <?=$item['MaxBullet']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				HP
																			</td>
																			<td width="87" align="right">
																				 <?=$item['HP']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				AP
																			</td>
																			<td width="87" align="right">
																				 <?=$item['AP']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Peso Max
																			</td>
																			<td width="87" align="right">
																				<?=$item['MaxWeight']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				Reload Time
																			</td>
																			<td width="87" align="right">
																				 <?=$item['ReloadTime']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		</table>
																	</div>
																</td>
																<td width="182">
																	<div align="center">
																		<table border="1" style="border-collapse: collapse;" width="175" height="98" bordercolor="#565053">
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				BP
																			</td>
																			<td width="87" align="right">
																				 0&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				FR </b>
																			</td>
																			<td width="87" align="right">
																				 <?=$item['FR']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				CR
																			</td>
																			<td width="87" align="right">
																				 <?=$item['CR']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				PR
																			</td>
																			<td width="87" align="right">
																				 <?=$item['PR']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		<tr>
																			<td width="86" bgcolor="#464244" align="left" style="border-collapse: collapse; color: #FFF;">
																				LR
																			</td>
																			<td width="87" align="right">
																				 <?=$item['LR']?>&nbsp;&nbsp;&nbsp;
																			</td>
																		</tr>
																		</table>
																	</div>
																</td>
															</tr>
															</table>
														</div>
													</td>
												</tr>
												<tr>
													<td width="569" colspan="4">&nbsp;
														
													</td>
												</tr>
												</table>
												</table>
											</div>
										</td>
										<td class="detalhes" width="7">&nbsp;
											
										</td>
									</tr>
									<tr>
										<td class="detalhes" width="597" colspan="3">&nbsp;
											
										</td>
									</tr>
									<tr>
										<td class="detalhes" width="597" colspan="3">
											<div align="center">
												<a href="index.php?page=evitemshop&sub=buyitem&expand=1&itemid=<?=$item['CSID']?>">
												<p id="botao">
													Comprar
												</p>
												</a><a href="#">
												<p id="botao">
													Presentear
												</p>
												</a><a href="index.php">
												<p id="botao">
													Cancelar
												</p>
												</a>
											</div>
										</td>
									</tr>
									</table>
								</div>
							</td>
						</tr>
						</table>
						<p>&nbsp;
							
						</p>
					</div>
				</p>
			</div>
    <?

}   }

if(!function_exists("ShowBuyItem")){
    function ShowBuyItem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM EVCashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT EVCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
       if(isset($_POST['submit'])){
            $itemid = clean($_POST['ItemID']);
            $res = mssql_query_logged("SELECT * FROM EVCashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT EVCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['EVCoins'] - $item['CashPrice'];
			$as = $item['Compras'] + 1;
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("Um erro aconteceu!");
            }		
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$aid', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET EVCoins = '$updatecoins' WHERE AID = '$aid'");
			mssql_query_logged("UPDATE EVCashShop SET Compras = Compras+1 WHERE CSID = '$itemid'");
            msgbox("Item Enviado para seu banco","index.php?page=evitemshop&sub=listallitems&expand=1&type=1");
       }
       ?>
			<div id="conteudo_include">
				<p>
					<div align="center">
						<table border="0" style="border-collapse: collapse" width="605">
						<tr>
							<td width="599" valign="top">
								<div align="center">
									<form method="POST" action="index.php?page=evitemshop&sub=buyitem">
										<table border="0" class="detalhes" width="603">
										<tr>
											<td class="detalhes" width="597" colspan="3">&nbsp;
												
											</td>
										</tr>
										<tr>
											<td class="detalhes" width="7">&nbsp;
												
											</td>
											<td class="detalhes" width="583" valign="top">
												<div align="center">
													<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#4A4648">
													<tr>
														<td>
															<table border="0" style="border-collapse: collapse" width="579" height="100%">
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104">&nbsp;
																	
																</td>
																<td width="458" colspan="2">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104" valign="top">
<img id="item" src="images/shop/<?=$item['WebImgName']?>" width="100" heigth="100">

																</td>
																<td width="458" colspan="2">
																	<div align="center">
																		<table border="0" style="border-collapse: collapse" width="458" height="100%">
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td colspan="2"><b>
																			  <?=$item['Name']?>
																			  </b></td>
																		  </tr>
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td colspan="2">&nbsp;</td>
																		  </tr>
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td width="61" align="left"><span class="branco">Tipo: </span></td>
																			<td width="372" align="left">Evento</td>
																		  </tr>
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td width="61" align="left"><span class="branco">Sexo: </span></td>
																			<td width="372" align="left"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
																		  </tr>
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td width="61" align="left"><span class="branco">N&iacute;vel: </span></td>
																			<td width="372" align="left"><?=$item['ResLevel']?></td>
																		  </tr>
																		<tr>
																			<td width="19">&nbsp;
																			  
																		    </td>
																			<td width="61" align="left"><span class="branco">Pre&ccedil;o: </span></td>
																			<td width="372" align="left"><?=$item['CashPrice']?>
																			  </td>
																		  </tr>

																		<tr>
																			<td width="19">&nbsp;
																				
																			</td>
																		</tr>
																		<tr>
																			<td width="19">&nbsp;
																				
																			</td>
																		</tr>
																		<tr>
																			<td width="19">&nbsp;
																				
																			</td>
																		</tr>
																		<tr>
																			<td width="19">&nbsp;
																				
																			</td>
																		</tr>
																		</table>
																	</div>
																</td>
															</tr>
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104">&nbsp;
																	
																</td>
																<td width="19">&nbsp;
																	
																</td>
																<td width="435" align="left" rowspan="4">
																	<div align="center">
																		<table border="0" style="border-collapse: collapse" width="435" height="66">
																		<tr>
																			<td width="419">
																				<div align="center">
																					<table border="0" id="tabela" style="border-collapse: collapse" width="419" height="100%">
																					<tr>
																						<td width="138">&nbsp;
																							
																						</td>
																						<td width="127" align="left">
																							<span class="branco">Pre&ccedil;o do Item:</span>
																						</td>
																						<td width="119" align="left">
																							<?=$item['CashPrice']?>
																						</td>
																					</tr>
																					<tr>
																						<td width="138">&nbsp;
																							
																						</td>
																						<td width="127" align="left">
																							<span class="branco">AG Coins Atuais:</span>
																						</td>
																						<td width="119" align="left">
																							<?=$acc['EVCoins']?>
																						</td>
																					</tr>
																					<tr>
																						<td width="138">&nbsp;
																							
																						</td>
																						<td width="127" align="left">
																							<span class="branco">EV Coins Restantes:</span>
																						</td>
																						<td width="119" align="left">
																							<?
                                                    $result = $acc['EVCoins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "EV Coins Insuficiente!";
                                                    }else{
                                                        $boton = "<input type='submit' value='Continuar' name='submit'>";
                                                    }

                                                        echo $acc['EVCoins']-$item['CashPrice'];?>
																						</td>
																					</tr>
																					<tr>
																						<td colspan="4" height="1">
																						</td>
																					</tr>
																					</table>
																				</div>
																			</td>
																			<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;
																				
																			</td>
																		</tr>
																		</table>
																	</div>
																</td>
															</tr>
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104">&nbsp;
																	
																</td>
																<td width="19">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104">&nbsp;
																	
																</td>
																<td width="19">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="11">&nbsp;
																	
																</td>
																<td width="104">&nbsp;
																	
																</td>
																<td width="19">&nbsp;
																	
																</td>
															</tr>
															<tr>
																<td width="569" colspan="4">&nbsp;
																	
																</td>
															</tr>
															</table>
															</table>
														</div>
													</td>
													<td class="detalhes" width="7">&nbsp;
														
													</td>
												</tr>
												<tr>
													<td class="detalhes" width="597" colspan="3">&nbsp;
														
													</td>
												</tr>
												<tr>
													<td class="detalhes" width="597" colspan="3">
														<div align="center"> 
<?=$boton?>
<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
															<a href="index.php">
															<p id="botao">
																Cancelar
															</p>
															</a>
														</div>
													</td>
												</tr>
												</table>
											</form>
										</div>
									</td>
								</tr>
								</table>
							</div>
						</p>
					</div>



<?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "listallitems";
        ListAllItems();
    break;
    case "details";
        ShowItemsDetails();
    break;
    case "buyitem";
        ShowBuyItem();
    break;
}
}





?>
