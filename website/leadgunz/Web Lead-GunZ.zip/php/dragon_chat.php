<img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzNjQ1NjEyMDczMDMmcHQ9MTM2NDU2MTIxMDYwMCZwPTUzMTUxJmQ9Jmc9MSZvPWM4YjFmYjkzNGQ*ZTRhN2ViN2Ez/MmM4NmEwZjI3MDgw.gif" /><embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="400" height="300" name="chat" FlashVars="id=188859656&rl=Portuguese" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" /><br><small><a target="_BLANK" href="http://xat.com/web_gear/?cb">Get your own Chat Box!</a> <a target="_BLANK" href="http://xat.com/web_gear/chat/go_large.php?id=188859656">Go Large!</a></small><br>



<a href="index.php?do=charinfo&cid=66"><img  src=""