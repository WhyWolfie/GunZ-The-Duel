<font size=2>
<?
if($_SESSION[AID] == "")
{
?>
<form name="login" method="POST" action="index.php?page=logar"><table width="5" height="0" border="0" align="center" cellpadding="0" cellspacing="0">
<table width="10" height="30" border="0" cellpadding="0" cellspacing="0" align="">
  <tr>
    </tr>
  <tr>
    <td height="5"><table width="5" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td align="right" height="0"><input name="userid" type="text" value="Login" tabindex="1" value="" maxlength="19"></td>
</tr>
        <td align="right" height="5"><input name="pass"  type="password" value="Senha" tabindex="2" maxlength="19"></td>
      </tr>
    </table></td>
<td width="5" align="right" colspan="2">&nbsp;<input type="submit" name="submit" class="button validate" value="Login"/></td>
      </tr>
    </table></td>
  </tr>
</table>
</form>
</center>
<?
}else{

$login = $_SESSION["login"];

$busca23 = mssql_query("SELECT RZCoins, EVCoins FROM Login WHERE UserID = '$login'");
$busca24 = mssql_fetch_row($busca23);

$busca25 = mssql_query("SELECT UGradeID FROM Account WHERE UserID = '$login'");
$busca26 = mssql_fetch_row($busca25);

if ($busca26[0] == 255 OR $busca26[0] == 254 OR $busca26[0] == 0 OR $busca26[0] == 4 OR $busca26[0] == 5 OR $busca26[0] == 6 OR $busca26[0] == 7 OR $busca26[0] == 2 OR $busca26[0] == 252 OR $busca26[0] == 20){

?>						<table border="0" style="border-collapse: collapse" width="195" id="table5">
										<tr>
											<td width="181">
											<b>- Coins:</b><br>
										</tr>
										<td width="8"></td>
										<tr>
											
											<td width="181">
											<b><?echo "- DG Coins: $busca24[0]";?></b><br>
										</tr>
										<tr>
											
											<td width="181">
											<b><?echo "- EV Coins: $busca24[1]";?></b><br>
										</tr>
										<td width="8">&nbsp;</td>
										<tr>
											
											<td width="181">
											<b>- Conta:</b><br>
										</tr>
										<td width="8"></td>
										<tr>
											
											<td width="181">
											<a href='index.php?page=alterar_senha'><b>- Alterar Senha</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=editar_perfil'><b>- Editar Perfil</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<b>- Personagem:</b><br>
										</tr>
										<td width="8"></td>
										<tr>
											
											<td width="181">
											<a href='index.php?page=nick_color'><b>- Comprar Nick Color</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=jjang'><b>- Comprar Jjang</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=altsexo'><b>- Alterar Sexo</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<b>- Cl�:</b><br>
										</tr>
										<td width="8"></td>
										<tr>
											
											<td width="181">
											<a href='index.php?page=emblemas'><b>- Adicionar emblema</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=ptcw'><b>- Trocar Pontos CW</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=criarclan'><b>- Criar Clan</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<b>- Pagamento:</b><br>
										</tr>
										<td width="8"></td>
										<tr>
											
											<td width="181">
											<a href='index.php?page=confirmar_pag'><b>- Confirmar Pagamento</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=meus_pag'><b>- Meus Pagamento</b></a><br>
										</tr>
										<td width="8">&nbsp;</td>
										<tr>
											
											<td width="181">
											<a href='index.php?page=deslogar'><b>- Deslogar/Sair</b></a><br>
										</tr>
</table><br>
<?
}
}
?>