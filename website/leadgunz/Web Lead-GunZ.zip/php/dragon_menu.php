<? if($_SESSION['UGradeID'] == 255){include"dragon_dragon_admnistrador-_-painel.php";echo "";} ?>
<? if($_SESSION['UGradeID'] == 254){include"dragon_dragon_gamemaster-_-painel.php";echo "";} ?>

 <div class="box_two">
 <div class="box_two_title">Ultimas not�cias</div>
                <div id="news">
                    <div id="news_title">
                        <p>Atualiza��es e novidades</p>
                    </div>
 <? include 'php/dragon_noticia.php'; ?>
                </div>

                <div id="news">
                    <div id="news_title">
                        <p>Ultimas postagens do f�rum</p>
                    </div>
<li><a href="#">
<? 
if($mode == on) 

{ 


if(!($id = mysql_connect($server,$usuario,$password))) { 
   echo "Forum em manunten��o"; 
} 


if(!($con=mysql_select_db($dbnamef,$id))) { 
   echo "Forum em manunten��o"; 
}  

$busca1 = mysql_query("SELECT tid, title, starter_name FROM topics ORDER BY start_date DESC LIMIT 6"); 

while($busca2 = mysql_fetch_row($busca1)) 
{ 

$busca3 = mysql_query("SELECT member_id FROM members WHERE members_display_name = '$busca2[2]'"); 
$busca4 = mysql_fetch_row($busca3); 

?> 
<a href="<?=$link25?>index.php?/topic/<?=$busca2[0]?>-<?=$busca2[1]?>/"><?=$busca2[1]?></a>
<a target="meio" href="<?=$link25?>index.php?/user/<?=$busca4[0]?>-<?=$busca2[2]?>/"><?=$busca2[2]?></a> 
<? 
} 
}else{ 
echo "Forum em manunten��o"; 
} 
?>
</a></li>
                </div>

</div>

 <div class="box_two">
 <div class="box_two_title">Facebook</div>
<iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FArsenal-Gunz%2F383849588317699%3Fsk%3Dinfo&amp;width=655&amp;height=215&amp;colorscheme=dark&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:655px; height:215px;" allowTransparency="true"></iframe>