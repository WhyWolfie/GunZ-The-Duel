<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
                <div id="ranking_box">
                	<div id="ranking_title">
                     	<p>Top 8 <b>Player</b></p>
                    </div>
<?
$buscar = mssql_query("SELECT TOP 8 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
                                    <?
                                    if(mssql_num_rows($buscar) == 0){
                                        ?>
                                        <?
                                    }else{
                                    while($player = mssql_fetch_assoc($buscar)){
                                    ?>
                <table width="133" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="25" align="left" valign="middle"><?=++$count ?></td>
                    <td align="left" valign="middle"><?=$player['Name']?></td>
                    <td align="right" valign="middle"><?=$player['Level']?></td>
                  </tr>
</table>
<?}}?>
                </div>
                <div id="ranking_box">
                	<div id="ranking_title">
                    	<p>Top 8 <b>Cl�s</b></p>
                    </div>
<?
$buscar = mssql_query("SELECT TOP 8 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
$count = 0;
?>
<?
if(mssql_num_rows($buscar) == 0){
?>
<?
}else{
while($clan = mssql_fetch_assoc($buscar)){
?>
                <table width="133" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="25" align="left" valign="middle"><?=++$count ?></td>
                    <td align="left" valign="middle"><?=$clan['Name']?></td>
                    <td align="right" valign="middle"><?=$clan['Point']?></td>
                  </tr>
</table>
<?}}?>
                </div>