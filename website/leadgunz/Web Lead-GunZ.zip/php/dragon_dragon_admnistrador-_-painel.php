<? include 'protect/authadmin.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/inject.php'; ?>
 <div class="box_two">
 <div class="box_two_title">Painel Administrador</div>

										<tr>
											<td width="181">
											<a href='index.php?page=ipbanuser'><b>- Banir IP do Usuario</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=muteuser_zz1'><b>- Mutar usuario</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=banuser'><b>- Banir usuario</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=x_unbanaf11'><b>- Desbanir usuario/desmutar</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=banirpeter'><b>- Banir Conta</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=dragon_adicionar_evcoins-_-painel'><b>- Enviar EV Coins</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=remover_ecoin_afzz'><b>- Retirar EV Coins</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=dragon_adicionar_dgcoins-_-painel'><b>- Enviar LG Coins</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=rzadditem145'><b>- Adicionar Item Donate</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=evadditem'><b>- Adicionar Item Evento</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=rzmasteradcitem'><b>- Adicionar Item Master</b></a><br>
										</tr>
										<tr>
											
											<td width="181">
											<a href='index.php?page=rzaddcustomitem'><b>- Adicionar Item Custom</b></a><br>
										</tr>

</div>
