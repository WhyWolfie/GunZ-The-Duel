 <div class="box_two">
 <div class="box_two_title">Ranking</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if(!isset($_GET['action']))
{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>
<div class="box">
<form id="ranking" name="ranking" method="post" action="?page=ranking&action=ir">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
 					 <tr>
						<td>
						<select name="quant" class="text">
						<option value="10">Top 10</option>
						<option value="30">Top 30</option>
						<option value="50">Top 50</option>
						<option value="100">Top 100</option>
						</select>
						</td>
						<td>
						<select name="tipo" class="text">
							<option value="Guilds">Cl&atilde;s</option>
							<option value="clevel">Personagens</option>
						</select>
						</td>
						<td>
						<select name="forma" class="text">
						<option value="DESC">Decrescente</option>
						<option value="ASC">Crescente</option>
						</select>
						</td>
  <td>
		<input type="submit" name="ranking" class="button validate" value="Gerenciar"/>
  </td>
 </tr>
</table>
</form>
</div>
<br />
<div id="result"></div>
<?
}
else
{
	if($_POST['tipo'] == 'Guilds')
	{
		$res = mssql_query("SELECT TOP  ".$_POST['quant']." NAME,POINT,WINS,LOSSES,MASTERCID FROM Clan WHERE Name != '' ORDER BY Point DESC");		
		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table">';
		echo '<tr class="table_tr">';
		echo '<td class="table_td">#</td>';
		echo '<td class="table_td">Nome</td>';
		echo '<td class="table_td">Pontos</td>';
		echo '<td class="table_td">Dono do cl&atilde;</td>';
		echo '<td class="table_td">Vitorias / derrotas</td>';
		echo '</tr>';
		
		while($array = mssql_fetch_row($res))
		{
			$x++;
			$master = mssql_fetch_row(mssql_query("SELECT CID,NAME,LEVEL FROM Character WHERE CID = '".$array[4]."'"));
			echo '<tr>';
			echo '<td class="table_td"><b>'.$x.'</b></td>';
			echo '<td class="table_td">'.utf8_encode($array[0]).'</td>';
			echo '<td class="table_td">'.$array[1].'</td>';
			echo '<td class="table_td">'.utf8_encode($master[1]).'</td>';
			echo '<td class="table_td">'.$array[2].' / '.$array[3].'</td>';
		}
		
		echo '</table>';
	}

        if($_POST['tipo'] == 'clevel')
        {
	
	$q = mssql_query("SELECT TOP ".$_POST['quant']." Name, Level, XP, KillCount, DeathCount, AID FROM Character WHERE Name != '' ORDER BY Level DESC");


		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table">';
		echo '<tr class="table_tr">';
		echo '<td class="table_td">#</td>';
		echo '<td class="table_td">Nome</td>';
		echo '<td class="table_td">Level</td>';
		echo '<td class="table_td">EXP</td>';
		echo '<td class="table_td">Matou / Morreu</td>';
		echo '</tr>';

                while($row = mssql_fetch_row($q)){

$colorzin = mssql_query("SELECT UGradeID FROM Account WHERE AID = '$row[5]'");
$colorzin2 = mssql_fetch_row($colorzin);

// Crazy

switch($colorzin2[0]) {
	case 255: $color = "<font color=#00FFFF>"; break;
	case 254: $color = "<font color=#FFA500>"; break;
        case 253: $color = "<font color=gray>"; break;
        case 0: $color = "<font color=white>"; break;
        case 2: $color = "<font color=#00CD66>"; break;
        case 4: $color = "<font color=#8A2BE2>"; break;
        case 5: $color = "<font color=#0000FF>"; break;
        case 6: $color = "<font color=#FF4040>"; break;
        case 7: $color = "<font color=#EE1289>"; break;
        case 20: $color = "<font color=#AB82FF>"; break;
        case 252: $color = "<font color=white>"; break;
	case 104: $color = "<font color =red>(Chat Block)</font>"; break;
}
	
		
		        $x++;
			echo '<font color=white>';
			echo '<tr>';
			echo '<td class="table_td"><b>'.$x.'</b></td>';
			echo '<td class="table_td">'.$color.''.$row[0].'</font></td>';
			echo '<td class="table_td">'.$row[1].'</td>';
			echo '<td class="table_td">'.$row[2].'</a></td>';
			echo '<td class="table_td">'.$row[3].'/'.$row[4].'</td>';
			echo '</font>';

               }
	
	echo '</table>'; }} ?>
</font>
