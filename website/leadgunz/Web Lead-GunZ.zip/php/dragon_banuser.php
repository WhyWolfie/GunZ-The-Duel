 <div class="box_two">
 <div class="box_two_title">Banir Usuario</div>
<?

include "protect/authgm.php";
include "protect/inject.php";

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $gmid = clean($_POST['gmid']);
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?page=banuser");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Account SET UGradeID = '253' WHERE UserID = '$userID'");
            mssql_query_logged("INSERT INTO Banneduser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$gmid', '$id', 'Undefined', '$reason', GETDATE(), 'Ban')");
            msgbox("The user with the ID $id has been banned","index.php?page=banuser");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?page=banuser");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Account SET UGradeID = '253' WHERE AID = '$UserAID'");
            mssql_query_logged("INSERT INTO Banneduser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$gmid', '$id', 'Undefined', '$reason', GETDATE(), 'Ban')");
            msgbox("The user with the character $id has been banned","index.php?page=banuser");
        }
    }

}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>


	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form name="ban" method="POST" action="index.php?page=banuser"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="348" colspan="3">

											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">GM User ID</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="gmid" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">User ID
											</option>
											<option value="2">Character Name
											</option>
											</select></td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">User IP</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="ip" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">Ban Reason</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<select size="1" name="reason" onchange="UpdateCustom()">
											<option selected value="Usando programas para modificar o cliente">Usando programas para modificar o cliente
											</option>
											<option value="Usando hacks ou cheats">Usando hacks ou cheats
											</option>
											<option value="Insultando a Equipe">Insultando a Equipe
											</option>
											<option value="Insultando Jogador">Insultando Jogador
											</option>
											<option value="Swap / Etc">Swap / Etc
											</option>
											<option value="Nenhuma razo especificada">Nenhuma razo especificada
											</option>
											<option value="Outros">Outros</option>
											</select></td>
										</tr>
										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>
										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Ban User" name="submit"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
