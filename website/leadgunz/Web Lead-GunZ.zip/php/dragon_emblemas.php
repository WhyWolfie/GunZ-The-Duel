 <div class="box_two">
 <div class="box_two_title">Adicionar cla emblema</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if($_GET['act'] == "")
if($_GET['step'] == "")
$step = $_GET['step'];
if($step == "")
{
	$step = 1;
}
if ($step == '1') 
{
?>
<FORM METHOD=POST ACTION="?page=emblemas&step=2">
<p><font color="white">Etapa 1/3</font></p>
<p>
<input name="userid" onfocus="if(this.value=='Username') this.value='';" onblur="if(this.value=='') this.value='Username';" value="Login" type="text" maxlength="15" onkeyup="valid(this,'special')" onblur="valid(this,'special')">	<p>

<input name="pass" onfocus="if(this.value=='Senha') this.value='';" value="Senha" type="password" maxlength="15" onkeyup="valid(this,'special')" onblur="valid(this,'special')">
<p>
<input type="submit" value="Logar" />
<br />
</form>

<?
}
if ($step == "2") 
{

	$user1 = clean($_POST['userid']);
	$pass1 = clean($_POST['pass']);
	{
		$query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");

		if (mssql_num_rows($query) < 1)
		{
			echo "<br>login ou senha incorretos!";
		}
		else
		{
			$query2 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
			if (mssql_num_rows($query2) >= '1')
			{ 
			?>
<form enctype="multipart/form-data" action="?page=emblemas&step=done" method="POST">
                                        <p><font color="white">Etapa 2/3</font></p>
					 <p><font color="white">Por favor insira o emblema: </font></p>
						<input name="uploaded" type="file" />
    </p>
					<p>
					  <select name="clan">
					    
					    	<? 
						for($i=''; $i < @mssql_num_rows($query2); $i++)
						{
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
						?>
						<option value="<?=$row[4]?>"><?=$row[4]?></option>
                        			<?
						}
						?>
				      </select>
                      <br />
					<p><font color="white">Permitido imagens ate - 100 x 100 a 60 KB.</font></p><br />
					  <input type="submit" value="Enviar Imagem" /><br />
					  <br />
</form>
			<? 
			}
			else 
			{ 
				echo "<p>Voce nao e lider do clan</p>";
			} 
		}
	}
}

if ($step == "done") 
{ 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = clean($_POST['clan']);
	$target = "upload/";
	$target = $target . basename( $_FILES['uploaded']['name']) ;
        $target22 = "upload/";
        $target22 = $target22 . basename( $_FILES['uploaded']['name']) ;
	$ok=1;


	$partes = pathinfo( $_FILES['uploaded']['name'] );
	$extensao = $partes['extension'];

	$extensoes = array('jpg', 'jpeg', 'png', 'gif');

	if($_FILES['uploaded']['size']  > "60720")
	{
		$err .= "A imagem � muito larga.<br>";
		$ok = 0;
	}

	if( !in_array(strtolower($extensao), $extensoes) )
	{
		$err .= "<p>Formato de imagem n�o aceita.</p><br>";
		$ok = 0;
	}

	
	if ($ok == 0)
	{
		echo "<p>Desculpe, sua imagem n�o foi aceita.</p>";
		echo "$err";
	}
	else
	{
		if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
			{
				echo "<p>O emblema foi inserido com sucesso.</p><br />";
				mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
				mssql_query("UPDATE Clan SET EmblemUrl = '".$target22."' WHERE Name = '$CLID'");
			}
			else
			{
				echo "<p>Desculpe, ocorreu um problema, tente novamente.</p>";
			}
	}
}
?>
</font>			
