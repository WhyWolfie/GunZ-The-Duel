 <div class="box_two">
 <div class="box_two_title">Alterar senha</div>
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?

if ($_SESSION['AID'] == ""){

die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$login22 = ($_SESSION["login"]);

if (!(isset($_POST['senha1'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?page=alterar_senha">
<input type="password" id="senha1" value="Senha" class="log_field" size="25" name="senha1" value="" maxlength="20">  <-- Digite sua senha atual<br>
<input type="password" id="senha2" value="Senha" class="log_field" size="25" name="senha2" value="" maxlength="20">  <-- Digite sua nova senha<br><br>
<input type="submit" name="logar" value="Mudar" />
</form>
<?
}else{

$senha1 = ($_POST['senha1']);
$senha2 = ($_POST['senha2']);

$busca22 = mssql_query("SELECT Password FROM Login WHERE UserID = '$login22'");
$busca23 = mssql_fetch_row($busca22);

if ($busca23[0] == $senha1){
mssql_query("UPDATE Login SET Password = '$senha2' WHERE UserID = '$login22'");
echo "Senha Alterada Com Sucesso!";
}else{
echo "A sua senha atual nao confere com a que temos em nosso sistema.";
}
}
}
?>