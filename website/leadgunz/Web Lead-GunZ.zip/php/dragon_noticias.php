<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
if($_GET['sub'] == "buscar"){
    $res = mssql_query("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
 <div class="box_two">
 <div class="box_two_title"><?=$a['Title']?></div>
											<font size="1" face="Verdana"><?=$a['Text']?></br><br>
											Autor: <b><?=$a['User']?></b>, <?=$a['Date']?>.</font>
                                                                    <?}?>
