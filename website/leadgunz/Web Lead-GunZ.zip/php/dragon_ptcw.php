 <div class="box_two">
 <div class="box_two_title">Trocar Pontos CW</div>
<div align="center">
<? include 'protect/inject.php'; ?>
<? include 'protect/inject2.php'; ?>
<? include 'protect/inject3.php'; ?>
<? include 'protect/anti_sql.php'; ?>
<? include 'protect/anti_inject.php'; ?>
<? include 'protect/anti_inject2.php'; ?>
<? include 'protect/anti_injectx.php'; ?>
<?
// Crazy

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
echo "<script language='Javascript'> alert('Para acessar essa pagina voc� precisa estar logado.');document.location = 'index.php'; </script>";
}else{

if($etapa22 == 0){
?>
<BR><BR>
<form id="ev_coins" name="ev_coins" method="post" action="?page=ptcw&etapa=1">
Personagem:
<br><br>
<select name="cid" class="text">
<?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proximo" />
</form>
<br>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))


{
die ("<script language='Javascript'> alert('Esse personagem nao pertence a nemhum cl�.');document.location = 'index.php'; </script>");
}else{

$_SESSION["CID"] = $cid22;
echo '<BR><BR>
<font color=red>Aten��o:</font><font color=white>A cada 2 pontos � o que vale a 1 EV Coins.</font><br><br>
<form id="ev_coins" name="ev_coins" method="post" action="?page=ptcw&etapa=2">';
echo "Ol� $login22 voc� tem $busca2[0] pontos para trocar.<br><br>";
echo "Quantos pontos deseja trocar?<br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="ev_coins" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "<script language='Javascript'> alert('Voc� tem $busca4[0] pontos e quer trocar por $pontos EV Coins ? o.0');document.location = 'index.php'; </script>'";
}else{

if ( !is_numeric($cid23) )
{
echo "<script language='Javascript'> alert('ID do Personagem editado.');document.location = 'index.php'; </script>";
die();
}

if ( !is_numeric($pontos) )
{
echo "<script language='Javascript'> alert('O N�mero de Coins precisa ser um n�mero.');document.location = 'index.php'; </script>";
die();
}

if ($pontos == 0)
{
echo "<script language='Javascript'> alert('N�o h� necessidade de comprar 0 EV Coins.');document.location = 'index.php'; </script>";
die();		
}

if($pontos < 1)
{
echo "<script language='Javascript'> alert('N�o existe a possibilidade de ficar com pontos negativos o.0');document.location = 'index.php'; </script>";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set EvCoins=EvCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "<script language='Javascript'> alert('Troca realizada com sucesso.');document.location = 'index.php'; </script>";


}

}

}
?>
</div>