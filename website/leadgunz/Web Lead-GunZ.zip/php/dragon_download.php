 <div class="box_two">
 <div class="box_two_title">Download</div>
  <p align="center"><strong>Escolha uma op&ccedil;&atilde;o para o Download do Jogo </strong></p>
  <p align="center"><span class="Estilo1">

<center>
      <a href="http://www.gamefront.com/">GameFront - Lead GunZ Cliente V1.0 <font color=green>(Disponivel)</font></a></br>
      <a href="http://www.crocko.com/">Croko - Dragon GunZ Cliente V1.0 <font color=green>(Disponivel)</font></a></br>
      <a href="http://www.4shared.com/">4Shared - Lead GunZ Cliente V1.0 <font color=green>(Disponivel)</font></a></br>
</center>

  </span></p>
  <p align="center">&nbsp;</p>
  <p align="center"><strong>Favor efetuar o download e seguir as instru&ccedil;&otilde;es durante a instala&ccedil;&atilde;o. </strong></p>
  <p align="center">O pacote DirectX vers&atilde;o 8.0 ou superior deve estar instalado em seu computador para que voc&ecirc; possa rodar o Dragon Gunz. Voc&ecirc; pode efetuar o download clicando no link abaixo.</p>
  <p align="center"> <a href="http://download.microsoft.com/download/1/7/1/1718CCC4-6315-4D8E-9543-8E28A4E18C4C/dxwebsetup.exe" target="_blank"><strong>Direct X</strong></a></p>
  <p align="center">Caso  n&atilde;o funcione mesmo ap&oacute;s a instala&ccedil;&atilde;o do DirectX 8.0 ou superior, tente atualizar os drivers de sua placa de v&iacute;deo, visitando o site do fabricante de sua placa. </p>
  <p align="center"><br />
