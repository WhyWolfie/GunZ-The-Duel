﻿ <div class="box_two">
 <div class="box_two_title">Comprar LG Coins</div>
  <tr>
   <div align="center" class="style1">P&aacute;gina 

de Donate</div>
  </tr>
  <tr>
  <div align="center">
      <p class="style2">Abaixo a tabela de Pre&ccedilos:</p>
        <tr>
          <td width="265"><table width="361" height="168" border="0" align="center">
            <tr>
              <td width="151" height="23"><p align="center" class="style1">Pre&ccedilo</p></td>
              <td width="31">&nbsp;</td>
              <td width="165"><div align="center"><span class="style1">AG 

Coins</span></div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center">R$10,00</div></td>
              <td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="Mateusdelicia08@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="1" />
<input type="hidden" name="itemDescription" value="100 LG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="10.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/120x53-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
              <td><div align="center" class="style3">100 AG Coins</div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center">R$20,00</div></td>
              <td class="style3"><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="wendelnmiranda@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="2" />
<input type="hidden" name="itemDescription" value="250 LG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="20.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/120x53-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
              <td class="style3"><div align="center">250 LG Coins</div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center">R$30,00</div></td>
              <td class="style3"><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="wendelnmiranda@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="3" />
<input type="hidden" name="itemDescription" value="450 LG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="30.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/120x53-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
              <td class="style3"><div align="center">450 AG Coins</div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center">R$40,00</div></td>
              <td class="style3"><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/cart.html?action=add" method="post">
<input type="hidden" name="itemCode" value="0159080D7A7A2FDCC4624F9FC9CA1FAF" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/120x53-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
              <td class="style3"><div align="center">550 AG Coins</div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center">R$50,00</div></td>
              <td class="style3"><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/cart.html?action=add" method="post">
<input type="hidden" name="itemCode" value="E0EC31613434440334034FBE3ED36D4F" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/120x53-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - é rápido, grátis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
              <td class="style3"><div align="center">750 LG Coins</div></td>
            </tr>
            <tr>
              <td height="0" class="style3"><div align="center"></div></td>
              <td class="style3"><div align="center"></div></td>
              <td class="style3"><div align="center"></div></td>
            </tr>
          </table>
            <div align="center"></div></td>
        </tr>
      <p class="style1">Como Donatar?</p>
      <p align="center" class="style1">Clique no bot&atilde;o com o valor desejado e siga os passos para confirmar sua compra via PagSeguro!</p>
      <p align="center" class="style1">OBS: Ap&oacute;s o pagamento deve ser enviado um email para: wendelnmiranda@hotmail.com<br>com a <b>foto do comprovante de pagamento</b> e com seu <b>Login</b> e <b>Nick</b> 

do jogo.</p>
      <p align="center" class="style1">Agradecemos sua prefer&ecirc;ncia e desejamos que tenha um Bom Jogo !</p>
      </div></td>
  </tr>
