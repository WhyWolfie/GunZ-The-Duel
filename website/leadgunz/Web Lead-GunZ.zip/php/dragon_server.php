	  <?=$lang['ServerInfo']?>
	  <?php
	  $query = mssql_query("SELECT * FROM ServerStatus WHERE Opened = 1");
	  while($data = mssql_fetch_assoc($query)){
	  ?>
<table class="news" width="100%"> <tbody><tr><td>
	  Login Server:
	  <?php
	$ip = $data['IP'];
	$port = $data['Port'];
    $fp = @fsockopen($ip, 4141, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font style='color: green'>Online</font><br />";
        }
        else
        {
            echo "<font style='color: green'>Online</font><br />";
            fclose($fp);
        }
			?>
</td></tr></tbody></table>

<table class="news" width="100%"> <tbody><tr><td>
<?php
        $ip = '200.216.16.195';
        $port = '6000';
        $name = 'Agent Server';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "$name: <font style='color: green'>Online</font><br />";
        }
        else
        {
            echo "$name: <font style='color: green'>Online</font><br />";
            fclose($fp);
        }
    ?>
</td></tr></tbody></table>

<table class="news" width="100%"> <tbody><tr><td>
	  Clan / Quest:
	  <?php
	$ip = $data['IP'];
	$port = $data['Port'];
    $fp = @fsockopen($ip, 4141, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font style='color: red'>Offline</font><br />";
        }
        else
        {
            echo "<font style='color: green'>Online</font><br />";
            fclose($fp);
        }
			?>
</td></tr></tbody></table>

<table class="news" width="100%"> <tbody><tr><td>
Total Online: <?=$data['CurrPlayer']?>/<?=$data['MaxPlayer']?>
                        <?
						$percent = (($data['CurrPlayer'] / $data['MaxPlayer']) * 100);
						?>
                      <?php
		}
		?>
</td></tr></tbody></table>
<table class="news" width="100%"> <tbody><tr><td>
Recorde Online:
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<?=$b['PlayerCount']?>
</td></tr></tbody></table>