<?php
include "dragon_config.php";
include "protect/antiddos.php";
include "protect/banneduser.php";
include "protect/checkcookie.php";
include "protect/inject.php";
include "protect/inject2.php";
include "protect/inject3.php";
include "protect/anti_Sql.php";
include "protect/anti_inject.php";
include "protect/anti_inject2.php";
include "protect/anti_injectx.php";
include "protect/_functions.php";
include "protect/antisql.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("php/dragon_" . $_GET['page'] . ".php")) {
        include "php/dragon_" . $_GET['page'] . ".php";
	}
} }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/dragon.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/css.css">
<title>Lead GunZ - www.Lead GunZ.com.br</title>
<link rel="shortcut icon" href="images/favicon/1.jpg" />
<script class="dealply_content_script" id="__DealPly_code_909922.5493184673" type="text/javascript">
try{function DealPlyConfigLocalCls(){};DealPlyConfigLocal=new DealPlyConfigLocalCls();DealPlyConfigLocalCls.prototype.getPartner=function(){return 'iron';};DealPlyConfigLocalCls.prototype.getChannel=function(){return 'iron2';};DealPlyConfigLocalCls.prototype.getHardId=function(){return '2568916017815119482495186119416960201804685';};DealPlyConfigLocalCls.prototype.getHardIdSource=function(){return 'inst';};DealPlyConfigLocalCls.prototype.getVehicle=function(){return 'xpi';};}catch(e){}
</script><script class="dealply_content_script" id="__DealPly_code_706045.6402335537" type="text/javascript">undefined</script>
<script class="dealply_content_script" src="js/firefox_content.js" id="__DealPly__409075.6832343016" type="text/javascript"></script>
</head>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> 
</script>
<body>
<div id="overlay"></div> 
<div id="wrapper"> 
<center>
 <img src="images/banners/1" border="none">
</center>
 <div id="menu"> <a href="index.php" class="current">In�cio</a><a href="?page=cadastro">Cadastro</a><a href="?page=download">Download</a><a href="?page=ranking">Ranking</a><a href="?page=lojas">Loja</a><a href="?page=leadcoins">Doa��o</a><a href="/chat/" target="_blank">Chat</a> </div>/a><a href="/equipe/" target="_blank">Equipe</a> </div>
 
 <div id="leftcontent">
 <div class="main_view"> <div class="window"> <div style="width: 2680px;" class="image_reel"> <a href="index.php"><img src="images/slides/1" alt="" border="none"></a><a href="?page=dragoncoins"><img src="images/slides/2" alt="" border="none"></a><a href="/forum/" target="_blank"><img src="images/slides/3" alt="" border="none"></a> </div> </div> <div style="display: block;" class="paging"> <a class="active" href="#" rel="1">1</a><a href="#" rel="2">2</a><a href="#" rel="3">3</a> </div></div>

			<?php
                    	if (isset($_GET['page'])) 
						{
                            $_GET['expand'] = 0;
						    if (file_exists("php/dragon_" . $_GET['page'] . ".php")) 
							{
								include "php/dragon_" . $_GET['page'] . ".php";
							}
							else
							{
								include "404.php";
							}
                        		}
								else
								{
                           		 	include "php/dragon_menu.php";
					    }
                     ?>
</div>
</div>
<div id="rightcontent"><div class="box_one">  
<center>
<a href="http://youtube.com/"><img src="images/sociais/youtube.png" alt="s1" width="51" height="52" title="YouTube" /></a>
<a href="http://www.facebook.com/"><img src="images/sociais/facebook.png" alt="s1" width="51" height="52" title="Facebook" /></a>
<a href="http://twitter.com/"><img src="images/sociais/twitter.png" alt="s1" width="51" height="52" title="Twitter" /></a>
</center>
</div>
<div class="box_one"> 
 <div class="box_one_title">Painel Usuario <?=$_SESSION['UserID']?></div> 
<? include 'php/dragon_painel.php'; ?>
</div>

 <div class="box_one"><div class="box_one_title">Dragon Status</div>

<? include 'php/dragon_server.php'; ?>
<table width="100%"><tbody><tr><td>

</span></td><td> <b></b></span></td> </tr></tbody></table></span></div>

<div class="box_one"><div class="box_one_title">Ranking</div>
<? include 'php/dragon_rankingbar.php'; ?>

</span></td><td> <b></b></span></td> </tr></tbody></table></span></div>

<div class="box_one"><div class="box_one_title">Links �teis</div>
              <a href="index.php?page=download"><img src="images/download.png" alt="download Lead GunZ" width="240" height="103" border="0" class="opacity08" id="box_download_img" /></a>
              <a href="index.php?page=dragoncoins"><img src="images/recharge.png" alt="recarregue Lead GunZ" width="240" height="103" border="0" class="opacity08" id="box_download_img" /></a>

</div> 
</div> 
<center><div id="menu"><font size=2></br>Todos os direitos reservados Lead GunZ</font></div></center> 
</div> 
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="js/slideshow.js"></script>
<script type="text/javascript" src="js/tooltip.js"></script>
 <div style="position: absolute; margin: 0px; top: 384px; left: 351.5px;" id="popup"><div id="popup_title"></div><div id="popup_body">Seems like this was empty</div> <div id="popup_bottom"></div></div>
 
 <div id="dp_swf_engine"><object style="position: absolute; top: -1000000px; left: -1000000px;" id="_dp_swf_engine" data="swf/dealply_swf_engine.swf" type="application/x-shockwave-flash" height="1" width="1"><param value="always" name="allowscriptaccess"></object></div>
 

 </body></html>