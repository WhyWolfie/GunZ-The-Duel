﻿<?$host = "Tu-PC\SQLEXPRESS";
$user = "sa";
$pass = "27asdas";
$dbname = "GunzDB";
$msconnect=@mssql_connect("$host","$user","$pass") or die ('Falha com a tentativa de Conexão com o SQL Server');
$msdb=@mssql_select_db("$dbname",$msconnect) or die ("Falha com a tentativa de Conexão com o Banco de Dados");
?>
<?php
$DBHost = 'Tu-PC\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'sadasd';
$DB = 'GunzDB';
?>