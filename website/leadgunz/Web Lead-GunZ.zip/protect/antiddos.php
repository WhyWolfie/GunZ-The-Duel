<?php

  $crlf=chr(13).chr(10);
  $itime=3;  //Minimum number of seconds between one-visitor visits
  $imaxvisit=10;  //Maximum visits in $itime x $imaxvisits seconds
  $ipenalty=($itime * $imaxvisit);  //Minutes for waitting
  $iplogdir="./atacks/";
  $iplogfile="dg_atacksip.log";
  
  // Time
  $today = date("Y-m-j,G");
  $min = date("i");
  $sec = date("s");
  $r = substr(date("i"),0,1);
  $m =  substr(date("i"),1,1);
  $minute = 0;
  
  $to      = 'Your E-mail';  
  $headers = 'From: Dragon DDOS Shield' . "\r\n";
  $subject = "Warning of Possible DoS Attack at $today:$min:$sec";
  

  //Warning Messages:
  $message1='<font color="red">Dragon GunZ Anti DDOS</font><br>';
  $message2='Por favor aguarde ... ';
  $message3=' segundos para voltar ao nosso site.<br>';
  $message4='<font color="blue">Voc� est� atacando nosso site com DDOS.</font><br>Se voc� for humano troca de ip.<br>Seu IP foi banido do nosso servidor <b>'.$_SERVER["REMOTE_ADDR"].' </b>por ataque de DDOS.';
  $message5= 'Trinity has been attacked by a bot or human visiting from this IP address: '.$_SERVER["REMOTE_ADDR"];
  $message6='<br><img src="./logs/cross.gif" alt="" border="0">'; 
//---------------------- End of Initialization ---------------------------------------  

  //Get file time:
  $ipfile=substr(md5($_SERVER["REMOTE_ADDR"]),-3);  // -3 means 4096 possible files
  $oldtime=0;
  if (file_exists($iplogdir.$ipfile)) $oldtime=filemtime($iplogdir.$ipfile);

  //Update times:
  $time=time();
  if ($oldtime<$time) $oldtime=$time;
  $newtime=$oldtime+$itime;

  //     Check human or bot:
  if ($newtime>=$time+$itime*$imaxvisit)
  {
    //     To block visitor:
    touch($iplogdir.$ipfile,$time+$itime*($imaxvisit-1)+$ipenalty);
    header("HTTP/1.0 503 Service Temporarily Unavailable");
    header("Connection: close");
    header("Content-Type: text/html");
    echo '<html><head><title>Dragon DDOS shield</title></head><body><p align="center"><strong>'
          .$message1.'</strong>'.$br;
    echo $message2.$ipenalty.$message3.$message4.$message6.'</p></body></html>'.$crlf;
   //     Mailing Warning Message to Site Admin
     {
	@mail($to, $subject, $message5, $headers);	
     }
    //     logging:
    $fp=@fopen($iplogdir.$iplogfile,"a");
    if ($fp!==FALSE)
    {
      $useragent='<unknown user agent>';
      if (isset($_SERVER["HTTP_USER_AGENT"])) $useragent=$_SERVER["HTTP_USER_AGENT"];
      @fputs($fp,$_SERVER["REMOTE_ADDR"].' on '.date("D, d M Y, H:i:s").' as '.$useragent.$crlf);
    }
    @fclose($fp);
    exit();

  }

  //Modify file time:
  touch($iplogdir.$ipfile,$newtime);

?>
