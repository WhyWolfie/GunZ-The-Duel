<?php
    $per = imagecreate(172,7);
    $background = imagecolorallocate($per, 0xff, 0xFF, 0xFF);
    $foreground = imagecolorallocate($per, 0x00, 0x8A, 0x01);
    $border = imagecolorallocate($per, 0x99, 0x99, 0x99);
    $new = "1.7";
    if ($_GET['percent'] > 0)
    {
        $grad = imagecreatefrompng("grad.png");
        $per2 = imagecopy($per, $grad, 1, 1, 0, 0, ($_GET['percent'] * $new), 5);
        imagerectangle($per, 0, 0, 171, 6, $border);
    }
    header("Content-type: image/png");
    imagepng($per, NULL, 5);
?>