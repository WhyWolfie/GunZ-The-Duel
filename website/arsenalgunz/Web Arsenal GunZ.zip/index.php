<?php
include "ddos.php";
include "antddos.php";
include "configuracao/config.php";
include "configuracao/configs.php";
include "protects/functions.php";
include "Configuracao/_functions.php";
include "Protects/banned.php";
include "Protects/banneduser.php";
include "php/title.php";
include 'php/sqlcheck.php';
include 'php/sql_check.php';
include 'Protects/anti_sql.php';
include 'Protects/antisql.php';
include 'Protects/antisql1.php';
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
include 'Protects/GeovaneSouza.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("php/ZoooDprotect_" . $_GET['gunz'] . ".php")) {
        include "php/ZoooDprotect_" . $_GET['gunz'] . ".php";
	}
} }
// Proteção Extra Sparrow//
$ip_logado = $_SERVER['REMOTE_ADDR'];
$arquivo = fopen("Protects/Sparrow/Sparrow.htm", "a+");
$escrever = fwrite($arquivo, "==========================<br>");
$escrever = fwrite($arquivo, "Login : $login_logado<br>");
$escrever = fwrite($arquivo, "IP : $ip_logado<br>");
$escrever = fwrite($arquivo, "Data : $data_logado<br>");
$escrever = fwrite($arquivo, "Hora : $hora_logado<br>");
$escrever = fwrite($arquivo, "==========================<br>");
fclose($arquivo);//
// Fim de Proteção Extra Sparrow//
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-br" lang="pt-br" class="gecko win" >

<!-- Mirrored from  by HTTrack Website Copier/3.x [XR&CO'2010], Sun, 08 Apr 2012 15:42:10 GMT -->
<!-- Added by HTTrack --><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /><!-- /Added by HTTrack -->
<style type="text/css">
<!--
a:hover {
	color: #c60;
}
a:active {
	color: #c60;
}
-->
</style><head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="lv host,host,lvhost" />
  <meta name="description" content="Hospedagem de site profissional" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title>Arsenal Gamerz - Nova gera&ccedil;&atilde;o de Gunz Online</title>
  <link href="templates/vt_hosting/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <link rel="stylesheet" href="modules/mod_vtem_news_plus/style.css" type="text/css" />
  <link rel="stylesheet" href="modules/mod_vtemmenu/style.css" type="text/css" />
  <script type="text/javascript" src="media/system/js/mootools.js"></script>
  <script type="text/javascript" src="media/system/js/caption.js"></script>
  <script type="text/javascript" src="modules/mod_vtemslideshow/tmpl/jquery-1.4.2.min.js"></script>
  <script type="text/javascript" src="modules/mod_vtemslideshow/tmpl/slideshow.js"></script>
  <script type="text/javascript" src="modules/mod_vtemmenu/moo_vtemmenu.js"></script>
  <script type="text/javascript">
window.addEvent('domready', function() {new DropdownVtemmenu($E('div#vt_menu'),{mooTransition : 'Quad',mooEase : 'easeOut',mooDuree : 500});});
  </script>

<link rel="stylesheet" href="templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="templates/vt_hosting/css/template.css" type="text/css" />
<link rel="stylesheet" href="templates/vt_hosting/css/styles/style1.css" type="text/css" />
<style>
body{
font-size:12px;
font-family:Arial, Helvetica, sans-serif;
}
          .navleft,.navright{width:230px;}
		  .navleft1,.navright1{width:300px;}
          .contentwidth{width:454px;}
		  .contentwidth1{width:636px;} 
</style>
<!--[if lte IE 6]>
<script src="/site/templates/vt_hosting/vtemtools/warning.js"></script>
<script>window.onload=function(){e("/site/templates/vt_hosting/images/ie6_warning/")}</script>
<![endif]-->
</head>
<body id="vtem">
<div id="vt_body_wapper">
<div id="vt_main_header_wapper">
  <div id="vt_main_menu_wapper">
    <div id="vt_main_menu">
    <style type="text/css">
ul.vt_menu li,div.vt_menu_wapper,ul.vt_menu{
background: transparent left top repeat-x;
}
ul.vt_menu li a,ul.vt_menu li a:link,ul.vt_menu li a:visited{
color:#555555;
}
ul.vt_menu li a:hover,ul.vt_menu li ul.vt_menu_sub li a:hover,ul.vt_menu li.active a{color:#FFFFFF !important;}
ul.vt_menu div.vt_nav ul.vt_menu_sub li{
background: #EEEEEE;
}
ul.vt_menu div.vt_nav{_background:none;}
div.vt_nav li a,div.vt_nav li a:link,div.vt_nav li a:visited,.vtemmenu_mod h3,.vtemmenu_mod{
color: #555555 !important;
}
div.vt_nav ul.vt_menu_sub,div.vt_nav ul.vt_menu_sub li,ul.vt_menu_sub li ul.vt_menu_sub li{
width:220px;
}
ul.vt_menu li div.vt_nav div.vt_nav{
margin-left:221px;
}
ul.vt_menu div.cols2 ul.vt_menu_sub{
width : 460px;
}
ul.vt_menu div.cols3 ul.vt_menu_sub{
width : 690px;
}
ul.vt_menu div.cols4 ul.vt_menu_sub{
width : 920px;
}
</style>
<div class="vt_menu_wapper" id="vt_menu">
	<ul class="vt_menu">
		<li class=" item56 level0" style="z-index : 11994;"><a href="index"><span class="vt_title">Inicio</span>
		<li class=" item56 level0" style="z-index : 11994;"><a href="index.php?gunz=register"><span class="vt_title">Registro</span></li></a>
		

	</li>
	<li class=" item55 level0" style="z-index : 11995;"><a href="index.php?gunz=download"><span class="vt_title">Download</span></a>
		</li>
	<li class=" parent item54 level0" style="z-index : 11999;"><a href="#"><span class="vt_title">Extras</span></a>
	<div class="vt_nav"><div class='vt_arrow_top'></div><div class="vt_menu_sub">
	<ul class="vt_menu_sub"><li class=" item58 level1" style="z-index : 11998;"><a href="#">Comprar Donator</span></a>
		</li>
<li class=" item59 level1" style="z-index : 11997;"><a href="#"><span class="vt_title">Comprar Custom Coins</span></a>
		</li>
<li class=" item60 level1" style="z-index : 11996;"><a href="index.php?gunz=Trocar"><span class="vt_title">Adquirir Event Coins</span></a>
	</li>
	</ul>
	<div class="clr"></div></div><div class="clr"></div></div>
		
<li class=" parent item54 level0" style="z-index : 11999;"><a href="index.php?gunz=WGshop&sub=listallitems&expand=1&type=1"><span class="vt_title">Shopping</span></a>
	<div class="vt_nav"><div class='vt_arrow_top'></div><div class="vt_menu_sub">
	<ul class="vt_menu_sub"><li class=" item58 level1" style="z-index : 11998;"><a href="index.php?gunz=RZshop&sub=listallitems&expand=1&type=1"><span class="vt_title">Shop Donater</span></a>
		</li>
<li class=" item59 level1" style="z-index : 11997;"><a href="index.php?gunz=evitemshop&sub=listallitems&expand=1&type=1"><span class="vt_title">Shop Event</span></a>
		</li>
<li class=" item60 level1" style="z-index : 11996;"><a href="index.php?gunz=PGShop&sub=listallitems&expand=1&type=1">Shop Custon</span></a>
	</li>
	</ul>
	<div class="clr"></div></div><div class="clr"></div></div>
	</li>
	<li class=" parent item54 level0" style="z-index : 11999;"><a href="index.php?gunz=WGshop&sub=listallitems&expand=1&type=1"><span class="vt_title">Rankings</span></a>
	<div class="vt_nav"><div class='vt_arrow_top'></div><div class="vt_menu_sub">
	<ul class="vt_menu_sub"><li class=" item58 level1" style="z-index : 11998;"><a href="index.php?gunz=players"><span class="vt_title">Players</span></a>
		</li>
<li class=" item59 level1" style="z-index : 11997;"><a href="index.php?gunz=clans"><span class="vt_title">Cl�'s</span></a>
		</li>

	</ul>
	<div class="clr"></div></div><div class="clr"></div></div>
	</li>
		
<li class=" item57 level0" style="z-index : 11993;"><a href="index.php?gunz=equipe"><span class="vt_title">Equipe</span></a></li>	</ul>
<div style="clear:both;"></div>
</div>


	<div class="clr"></div>
    </div>
  </div>
  <div id="vt_main_top">
   <div id="vt_main_header">
	 <div id="vt_logo"><a href="http://www.lvhost.com.br/site"><img src="templates/vt_hosting/images/v_logo.png" alt="logo" /></a></div>
	   </div>
      <div id="vt_slider">
     <script type="text/javascript">
jQuery.noConflict();
(function($) {
$(document).ready(function(){
$('#slideshow1').jqFancyTransitions({ 
width:405, 
height: 235,
strips: 10,
delay: 5000,
stripDelay: 50,
titleOpacity: 0.7,
titleSpeed: 1000,
position: 'bottom',
direction: 'fountainAlternate',
effect: 'zipper',
navigation: true,
links : 0});
});
})(jQuery);
</script>
<style type="text/css">
.vtem_wapper{
position:relative;
width:405px;
border:0px solid #F5F5F5;
}
.item_photo{
width:405px;
height:235px;
}
.ft-prev,.ft-next{
color:#333 !important;
font-weight:bold !important;
padding:0 5px;
}
.ft-prev{
background:url(modules/mod_vtemslideshow/images/go.png) right top no-repeat;
_background:#f5f5f5;
}
.ft-next{
background:url(modules/mod_vtemslideshow/images/go.png) left top no-repeat;
_background:#f5f5f5;
}
.vtem_button{
display:none;
visibility:hidden;
}
.vtem_button{
position:absolute;
left:0;
bottom:0;
margin:10px;
}
.vtem_button div a{
background:url(modules/mod_vtemslideshow/images/style4.png) center 0 no-repeat;
padding:5px 9px;
margin:2px;
font-weight:bold;
text-decoration:none !important;
}
.ft-button-slideshow1-active{
color:#000000 !important;
}
</style>
<div class="vtem_wapper">
<div id="slideshow1" class="slidemain">
			<img src='images/stories/slides/Arsenal.png' /><img src='images/stories/slides/Untitled-1.png' /></div></div>
    </div>
      <div class="clr"></div>
  </div>
<div id="vt_main_bg">
  <div id="vt_main_items">
  <div id="vt_main_content">
   <div id="vt_main_contaner">
     <div id="vt_main_inside">
	  	          <div id="vt_main_com" class="floatleft">
	     <div class="vt_rounded"><div class="vt_rounded1"><div class="vt_rounded2"><div class="vt_rounded3">
         <div class="vt_rounded4"><div class="vt_rounded5"><div class="vt_rounded6"><div class="vt_rounded7">
		  <div class="vt_auto_cols contentwidth1">
		  
          <div class="componentheading">
</table>
<table width="635" border="0">
    <tr>
      <td><? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['gunz'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("php/ZoooDprotect_" . $_GET['gunz'] . ".php")) {
							    include "php/ZoooDprotect_" . $_GET['gunz'] . ".php";
						    }
                        }else{
                            include "php/ZoooDprotect_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>
    </tr>
  </table>
</div>

	      		 		 </div>
		 </div></div></div></div></div></div></div></div>
	   </div>
	   	   <div id="vt_right_bg1" class="floatright navright1">
	   	 <div class="vt_rounded"><div class="vt_rounded1"><div class="vt_rounded2"><div class="vt_rounded3">
         <div class="vt_rounded4"><div class="vt_rounded5"><div class="vt_rounded6"><div class="vt_rounded7">
	       <div id="vt_nav_right" class="vt_auto_cols">
	        		<div class="vt_module"><div class="rounded1"><div class="rounded2"><div class="rounded3">
					<h3>
					  <div><span>Login</span></div>
					</h3>
					<div class="vt_module_content">
<table class="vtem_news_plus_wapper" id="vtem_news_plus_1" cellspacing="5" width="100%">

	<tr>
		<td colspan="1" class="vtem_morin_wapper"><br><table width="267" border="0">
		  <tr>
		    <td><? include "php/ZoooDprotect_ilogin.php";?></td>
		    </tr>
		  </table></td>
	</tr>
</table><h3>
					  <div><span>Player Ranking</span></div>
					</h3><?
$res = mssql_query_logged("SELECT TOP 10 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?><table width="200" border="0">
  <tr>
    <td><table border="0" style="border-collapse: collapse" width="277" height="100%">
									<tr>
									  <td width="54"><div align="center">P</div></td>
										<td width="142">Nome</td>
									  <td width="67">&nbsp;LV.</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="54">&nbsp;</td>
										<td width="142"><center></center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									    <tr>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
							      </tr>
								    <tr>
<td width="54"><center><?=++$count ?></center></td>
									  
<td width="142">
  <?=$clan['Name']?></td>

<td width="67">&nbsp;
	          <?=$clan['Level']?></td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="54">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="67">&nbsp;</td>
									</tr>                          
								</table></td>
  </tr>
</table>
<h3>
					  <div><span>Clan Ranking</span></div>
					</h3><?
$res = mssql_query("SELECT TOP 10 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
?><table width="200" border="0">
  <tr>
    <td><table border="0" style="border-collapse: collapse" width="277" height="100%">
									<tr>
									  <td width="56"><div align="center">P</div></td>
										<td width="143">Nome</td>
									  <td width="64">Pts</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="56">&nbsp;</td>
										<td width="143"></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									    <tr>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
							      </tr>
								    <tr>
<td width="56"><center><?=++$count ?></center></td>
									  
<td width="143">
  <?=$clan['Name']?></td>

<td width="64">&nbsp;
	          <?=number_format($clan['Point'],0,'','.');?>&nbsp;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="56">&nbsp;</td>
										<td width="143">&nbsp;</td>
										<td width="64">&nbsp;</td>
									</tr>                          
								</table></td>
  </tr>
</table>
</div>
		</div></div></div></div>
	
	       </div>
	     </div></div></div></div></div></div></div></div>
	   </div>
	          <div class="clr"></div>
	   	 </div>
	 <div class="clr"></div>
     </div>
     	    </div></div></div>
  <div id="vt_footer_menu_copyright">
	      	        <div id="vt_menu_footer"><h4>[ Web Site Codada por ZoooD[BR] E Editada Por SouthPark para o Arsenal Gamerz ] </h4></div>
	      	
		  	        <div class="clr">Arsenal Gamerz </div>
   </div>
</div>
</div>
 <script type="text/javascript">
    $(window).addEvent('load', function(){	
			(function(){
                var vtMaxHeight1 = 0;                                 
                $ES('#vt_main_inside').each(function( item ){                                 
                    if( item.offsetHeight.toInt()  > vtMaxHeight1 ){
                        vtMaxHeight1 =  item.offsetHeight.toInt();
                    }
                });
                if( vtMaxHeight1 > 0 ) {$ES('#vt_main_inside div.vt_auto_cols').setStyle('height', vtMaxHeight1);}              
            }).delay(100);
			
			(function(){
                var vtMaxHeight2 = 0;                                 
                $ES('#vt_bottom_wrapper').each(function( item ){                                 
                    if( item.offsetHeight.toInt()  > vtMaxHeight2 ){
                        vtMaxHeight2 =  item.offsetHeight.toInt();
                    }
                });
                if( vtMaxHeight2 > 0 ) {$ES('#vt_bottom_wrapper div.floatleft').setStyle('height', vtMaxHeight2);}              
            }).delay(100);                                    
    });
</script> 
</body>

<!-- Mirrored from www.lvhost.com.br/site/ by HTTrack Website Copier/3.x [XR&CO'2010], Sun, 08 Apr 2012 15:42:22 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
</html>
<script language="JavaScript">
function tecla() 
{
if (event.keyCode==123)
{
alert("ZoooD[BR]: Proibido usar esta tecla nesta web site");
event.keyCode=0;
event.returnValue=false;
}
} document.onkeydown=tecla;
</script>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> </script>