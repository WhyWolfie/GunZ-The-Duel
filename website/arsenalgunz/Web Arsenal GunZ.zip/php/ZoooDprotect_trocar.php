<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-style: italic;
	font-weight: bold;
	color: #999999;
}
-->
</style>

<div class="componentheading">
    <h3>
      <div>Trocar Pontos Adiquiridos em Clan War</div>
    </h3>
<table width="618" border="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td width="614"><?php
include "protects/banned.php";
include "protects/banneduser.php";
include "protects/checkcookie.php";
include "protects/title.php";
include 'protects/anti_inject.php';
include 'protects/anti_inject2.php';
include 'protects/inject.php';
include 'protects/inject2.php';
include 'protects/anti_sql.php';
?>
<?
//ZoooD[BR] <<< ProtecteD Script

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

if($etapa22 == 0){
?>
<form id="Trocar" name="Trocar" method="post" action="?gunz=Trocar&etapa=1">
  <div align="center">Personagem:
    <select name="cid" class="text">
        <?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
      </select>
    <br>
    <br>
      <input type="submit" name="ev_coins" value="Proxima Etapa" />
  </div>
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))


{
die ("Este Personagen nao pertence a um clan.");
}else{

$_SESSION["CID"] = $cid22;
echo '
<font color=red>Inportante: </font>2 (dois) pontos de cw vc tem direito a 1 Event Coins.<br><br>
<form id="trocar" name="trocar" method="post" action="?gunz=trocar&etapa=2">';
echo "Login $login22 tem $busca2[0] pontos de cw deseja trocar ?<br><br>";
echo "Quantos pontos deseja trocar?<br><br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="trocar" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "Voc� tem $busca4[0] pontos e quer trocar por $pontos EVCoins ?";
}else{

if ( !is_numeric($cid23) )
{
echo "ID do personagem editado";
die();
}

if ( !is_numeric($pontos) )
{
echo "Quantidade de Coins deve ser posta em numeros nao em letras.";
die();
}

if ($pontos == 0)
{
echo "N�o h� necessidade de comprar 0 ecoins";
die();		
}

if($pontos < 1)
{
echo "Error 416 >> Web Protected By: ZoooD[BR]";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set EvCoins=EvCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}
?></td>
  </tr>
</table>

