<div class="componentheading">
    <h3>
      <div>Registro</div>
    </h3>
</div>
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
-->
</style>

			<div class="contentBox">
              <ul class="rank"><?php

include "Protects/anti_sql.php";
include "Protects/inject.php";
include "Configuracao/config.php";

$ip = $_SERVER['REMOTE_ADDR'];  
$time = date("l dS of F Y h:i:s A");  
$script = $_SERVER[PATH_TRANSLATED];  
$fp = fopen ("[WEB]SQL_Injection.txt", "a+");  
$sql_inject_1 = array(";","'","%",'"'); #Whoth need replace  
$sql_inject_2 = array("", "","","&quot;"); #To wont replace  
$GET_KEY = array_keys($_GET); #array keys from $_GET  
$POST_KEY = array_keys($_POST); #array keys from $_POST  
$COOKIE_KEY = array_keys($_COOKIE); #array keys from $_COOKIE  
/*begin clear $_GET */  
for($i=0;$i<count($GET_KEY);$i++)  
{  
$real_get[$i] = $_GET[$GET_KEY[$i]];  
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]]));  
if($real_get[$i] != $_GET[$GET_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: GET\r\n");  
fwrite ($fp, "Value: $real_get[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_GET */  
/*begin clear $_POST */  
for($i=0;$i<count($POST_KEY);$i++)  
{  
$real_post[$i] = $_POST[$POST_KEY[$i]];  
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]]));  
if($real_post[$i] != $_POST[$POST_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: POST\r\n");  
fwrite ($fp, "Value: $real_post[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_POST */  
/*begin clear $_COOKIE */  
for($i=0;$i<count($COOKIE_KEY);$i++)  
{  
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]];  
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]]));  
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: COOKIE\r\n");  
fwrite ($fp, "Value: $real_cookie[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  

/*end clear $_COOKIE */  
fclose ($fp);  
?>
<?
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
	$name = clean($_POST['name']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $sq = clean($_POST['sq']);
    $sa = clean($_POST['sa']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="e-Mail in use.</br>";
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="UserID in use.</br>";
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            $errorcode.="The passwords do not match</br>";
            $er = 1;
        }

        if($user == ""){
            $errorcode.="Please enter a User ID.</br>";
            $er = 1;
        }

        if($email == ""){
            $errorcode.="Please type an e-mail.</br>";
            $er = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Please enter a password with 6 or more characters.</br>";
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please enter a password.</br>";
            $er = 1;
        }

        if($sq == ""){
            $errorcode.="Please enter a secret question.</br>";
            $er =1;
        }

        if($sa == ""){
            $errorcode.="Please enter a secret answer.</br>";
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
           mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, sa, sq, ZipCode, Address)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$sa', '$sq', '$zip', '$address')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins],[RZMaster],[RZCustom])VALUES('$user','$aid','$pw1',50,50,5,5)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>

<form name="reg" method="POST" action="index.php?gunz=register">


					
						<table border="0" width="505" style="border-collapse: collapse">
							
							<tr>
								<td width="661" background="">
								<div align="light">
								  <table width="504" height="218" border="0" cellspacing="1" bordercolor="#999999">
                                      <tr>
                                        <td><table border="0" style="border-collapse: collapse" width="503" height="100%">
										
										<tr>
											<td width="166">&nbsp;&nbsp; </td>
											<td width="170">&nbsp;</td>
										  </tr>
<? echo @$errorbox ?>
										<tr>
										  <td valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome:</td>
										  <td><input type="text" name="name" size="20"></td>
										  </tr>
										<tr>
										  <td valign="middle">&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
											<td width="166" valign="middle">
											<span lang="es">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login:</span></td>
										  <td width="170">
											<input type="text" name="userid" size="20"></td>
										  </tr>
										<tr>
											<td width="166">&nbsp;</td>
											<td width="170">&nbsp;</td>
										  </tr>
										<tr>
											<td width="166">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail:</td>
											<td width="170">
										  <input type="text" name="email" size="20"></td>
										  </tr>
										
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pergunta Secreta: </td>
										  <td><input type="text" name="sq" size="20"></td>
										  </tr>
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Resposta Secreta </td>
										  <td><input type="text" name="sa" size="20"></td>
										  </tr>
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Senha: </td>
										  <td><input name="pw1" type="password" size="20" maxlength="15"></td>
										  </tr>
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Confirme a Senha: </td>
										  <td><input name="pw2" type="password" size="20" maxlength="15"></td>
										  </tr>
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										<tr>
											<td width="166">&nbsp;</td>
											<td width="170">&nbsp;</td>
										  </tr>
										<tr>
											<td colspan="5">
											<center><hr color="#323232" width="96%">
											</center></td>
										</tr>
										<tr>
										  <td colspan="2">&nbsp;</td>
										  </tr>
										
										
										<tr>
											<td colspan="5">
											<center>
										  <input name="submit" type="image" src="images/bt_index_cadastre.png" class="" value=" ACESSAR PAINEL DO PLAYER "></center></td>
										</tr>
								  </table></td>
                                      </tr>
                                  </table>
								</div>
							  </td>
							</tr>
							
</table>
					</form>
<?
}else{
?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form name="reg" method="POST" action="index.php?do=register"><body bgcolor="#323232">

  
						<table width="512" border="0" bordercolor="#999999" style="border-collapse: collapse">
							
							<tr>
								<td width="689" background="images/meio.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="506" height="100%">
										<tr>
											<td width="11" rowspan="8">&nbsp;</td>
											<td colspan="2">											</td>
											<td width="22">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">&nbsp;											</td>
											<td width="22">&nbsp;</td>
										</tr>
										<tr>
											<td width="34" valign="middle"><img src="images/shape.png" width="34" height="35">											</td>
											<td width="855" valign="middle"><b>&nbsp;<?=$user?>, Cadastrado Com Sucesso ! </b></td>
											<td width="22">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">&nbsp;											</td>
											<td width="22">&nbsp;</td>
										</tr>
										<tr>
											<td height="24" colspan="2">
											<center>
										  &nbsp;</center></td>
											<td width="22" height="24">&nbsp;</td>
										</tr>
								  </table>
								
							  </td>
							</tr>
							
  </table>
</form>
<?
}
?>
