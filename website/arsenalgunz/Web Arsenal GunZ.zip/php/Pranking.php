<?
$res = mssql_query_logged("SELECT TOP 1000 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<div class="componentheading">
    <h3>
      <div>Ranking Player</div>
    </h3>
</div>
<table border="0" style="border-collapse: collapse" width="569" id="table4">
							
								<td width="461">
								<table border="0" style="border-collapse: collapse" width="645" height="100%">
									<tr>
									  <td width="68" bgcolor="#999999"><div align="center">Rank</div></td>
										<td width="90" bgcolor="#999999">Nome</td>
										<td width="117" bgcolor="#999999">Tempo Logado (min) </td>
										<td width="83" bgcolor="#999999">Experiencia</td>
										<td width="67" bgcolor="#999999">Matou</td>
									    <td width="66" bgcolor="#999999">Morreu</td>
								      <td width="124" bgcolor="#999999"><div align="center">Level</div></td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="68">&nbsp;</td>
										<td width="90"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
<td width="68"><div align="center"><b>
  
    <?=++$count ?>
    
</b></div></td>
									  
<td width="90"><?=$clan['Name']?></font></td>

<td width="117">
  <?=$clan['PlayTime']?></td>
<td width="83"><?=$clan['XP']?></td>
<td width="67"><?=$clan['KillCount']?></td>
<td width="66"><?=$clan['DeathCount']?></td>
<td width="124">
		    <p align="center">
	        <?=$clan['Level']?>
	        </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="68">&nbsp;</td>
										<td width="90">&nbsp;</td>
										<td width="117">&nbsp;</td>
										<td width="83">&nbsp;</td>
										<td width="67">&nbsp;</td>
										<td width="66">&nbsp;</td>
										<td width="124">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>							  </td>
							</tr>
</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
