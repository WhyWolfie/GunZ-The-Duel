<style type="text/css">
<!--
.statusdoserver {
	font-size: 18px;
	font-style: italic;
}
.playersonlinexD {
	font-size: 24px;
	color: #00FF00;
	font-weight: bold;
}
a:link {
	color: #FF9900;
}
a:visited {
	color: #FF9900;
}
a:hover {
	color: #FF9900;
}
a:active {
	color: #FF9900;
}
.yahsdna {
	color: #0099FF;
	font-size: 16px;
}
.vgbdajsda {
	font-size: 16px;
	color: #999999;
	font-style: italic;
}
.hasgbdha {
	font-size: 15px;
	font-style: italic;
	color: #333333;
}
-->
</style>
<div class="componentheading">
    <h3>
      <div>Situacao do Servidor</div>
    </h3>
</div>
<table width="639" border="0">
  <tr>
    <td width="62"><div align="center"><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?></div></td>
    <td width="154">Server</td>
    <td width="64"><div align="center">
      <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?>
    </div></td>
    <td width="198">Prote&ccedil;&otilde;es</td>
    <td width="387"><div align="center" class="statusdoserver">Players Online </div></td>
  </tr>
  <tr>
    <td><div align="center">
      <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = '7777';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?>
    </div></td>
    <td>Agent</td>
    <td><div align="center">
      <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?>
    </div></td>
    <td>Remote Control Server </td>
    <td><div align="center" class="playersonlinexD"><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong>$servercount";
    ?>&nbsp;</div></td>
  </tr>
  <tr>
    <td><div align="center">
      <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?>
    </div></td>
    <td>Locator</td>
    <td><div align="center">
      <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp; <img src='images/shape1.png' /><br />";
        }
        else
        {
            echo "&nbsp; <img src='images/shape.png' /><br />";
            fclose($fp);
        }
    }
    ?>
    </div></td>
    <td>Ant Lead </td>
    <td></td>
  </tr>
</table><br>
<div class="componentheading">
    <h3>
      <div>Ultimas Noticias Do Servidor </div>
    </h3>
</div>

                <table width="200" border="0">
  <tr>
    <td><table width="634" border="0">
      <tr>
        <td width="628">&nbsp;</td>
      </tr>
      
      <tr>
        <td><? include "Protects/inject.php" ?>          <?
                                                                $res = mssql_query_logged("SELECT TOP 3 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
?></td>
      </tr>
      <tr>
        <td><table border="0" style="border-collapse: collapse" width="631" height="100%">

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="10">&nbsp;</td>
									  <td width="611"><center>
									    <span class="statusdoserver">Nenhum Notica Foi Adicionada									    </span>
									  </center></td>
									</tr>
                                        <?
                                    }else{
                                    while($n = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="10">&nbsp;</td>
										<td width="611"><p align="justify">
										  <span class="yahsdna">
										  Titulo:&nbsp;										  </span> <span class="vgbdajsda">
										  <?=$n['Title']?>
										  </span><br>
										  <br>
									      <span class="hasgbdha">
									      <?=$n['Text']?>
								      ��</span>
										<hr color="#323232" width="100%"></td>
										
									</tr>
                                    <?}}?>
								</table></td>
      </tr>
    </table></td>
  </tr>
</table><br><br><h3>
					  <div><span>Suporte Via Chat</span></div>
					</h3><center><br>
					
					<img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzNDQ3MzU2ODI5MTImcHQ9MTM*NDczNTc5ODYxOSZwPTUzMTUxJmQ9Jmc9MSZvPTIxMDNjNGNkZTllODQyMWM4ZDA2/ZDk3ODYwMzZlM2Yz.gif" /><embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="580" height="405" name="chat" FlashVars="id=180401185" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" /><br><small><a target="_BLANK" href="index.php?gunz=rankings">Conhe�a nosso Ranking Completo</a> <a target="_BLANK" href="index.php?gunz=registro">// Cadastre-se</a></small><br>

