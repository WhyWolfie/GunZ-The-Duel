<?
switch ($_GET['do']){
        case "":
            $pagetitle = "Index";
    break;
        case "register":
            $pagetitle = "Register new account";
    break;
        case "downloads":
            $pagetitle = "Downloads";
    break;
        case "ranking":
            $pagetitle = "Ranking";
    break;
        case "myclan":
            $pagetitle = "Clans";
    break;
        case "itemshop":
            $pagetitle = "Item Shop";
    break;
        case "contact";
            $pagetitle = "Contact";
    break;
        case "login";
            $pagetitle = "User Login";
    break;
}

//

switch ($_GET['sub']){
        case "individual":
            $pagetitle = "Individual Ranking";
    break;
        case "clan":
            $pagetitle = "Clan Ranking";
    break;
        case "hof";
            $pagetitle = "Hall of fame";
    break;
        case "viewmyitems";
            $pagetitle = "View My Items";
    break;
        case "listallitems";
            $pagetitle = "View All Items";
    break;
        case "help";
            $pagetitle = "Help";
    break;
        case "details";
            $pagetitle = "Item Details";
    break;
        case "buyitem";
            $pagetitle = "Buy Item";
    break;
        case "announcement";
            $pagetitle = "Accouncement";
    break;
        case "update";
            $pagetitle = "Update";
    break;

}

//

switch ($_GET['action']){
        case "resetpwd":
            $pagetitle = "Reset Password";
    break;

}

//

switch ($_GET['act']){
        case "viewmyitems":
            $pagetitle = "View My Items";
    break;
        case "editinfo";
            $pagetitle = "Edit User Infos";
    break;


}
?>