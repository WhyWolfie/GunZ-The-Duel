<?
$res = mssql_query("SELECT TOP 1000 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
$count = 0;
?>
<div class="componentheading">
    <h3>
      <div>ranking Cl�n</div>
    </h3>
</div>
<table border="0" style="border-collapse: collapse" width="631" id="table4">
							
								<td>
								<table border="0" style="border-collapse: collapse" width="624" height="100%">
									<tr>
									  <td width="53" bgcolor="#999999"><div align="center">Rank</div></td>
										<td width="101" bgcolor="#999999">Nome</td>
										<td width="55" bgcolor="#999999">Win's</td>
										<td width="52" bgcolor="#999999">Loser's</td>
										<td width="86" bgcolor="#999999">Pontos Total  </td>
										<td width="129" bgcolor="#999999">Pontos Acumulativos </td>
										<td width="118" bgcolor="#999999">Iniciado: </td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="53">&nbsp;</td>
										<td width="101"><center></center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
<td width="53"><div align="center"><b>
  
    <?=++$count ?>
    
</b></div></td>
									  
<td width="101"><?=$clan['Name']?></td>

<td width="55">
  <?=number_format($clan['Wins'],0,'','.');?></td>
<td width="52">
  <?=number_format($clan['Losses'],0,'','.');?></td>
<td width="86">
  <?=number_format($clan['TotalPoint'],0,'','.');?></td>
<td width="129">
  <?=number_format($clan['Point'],0,'','.');?></td>
<td width="118">
		    <p align="center">
	        
<?=$clan['RegDate']?>
	        </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="53">&nbsp;</td>
										<td width="101">&nbsp;</td>
										<td width="55">&nbsp;</td>
										<td width="52">&nbsp;</td>
										<td width="86">&nbsp;</td>
										<td width="129">&nbsp;</td>
										<td width="118">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
