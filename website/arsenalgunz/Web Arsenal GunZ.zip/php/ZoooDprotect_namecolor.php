<div class="componentheading">
    <h3>
      <div>Name Collor</div>
    </h3>
<?
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
.style2 {color: #FF00FF}
.style3 {color: #FF0000}
.style4 {color: #FF6600}
.style5 {color: #6633FF}
.style7 {color: #0066CC}
.style8 {color: #006600}
.style9 {color: #660033}
.style10 {color: #FFFF00}
.style11 {color: #66FF00}
.style12 {color: #00FF00}
.style13 {color: #006666}
.style14 {color: #CCCCCC}
.style15 {color: #FFFFFF}
-->
</style>
<body>
<div align="center">
<table width="346" border="0" cellspacing="1" bordercolor="#666666">

<tr>
											<td colspan="5">
											<center>
											  <div align="center" class="style1"><span class="style2">Todas As Cores Citadas abaixo Custa 25 Custom Coins </span><span class="style15"></span></div>
	</center></td>
  </tr>
  <td width="175" height="21" bgcolor=""></td>
  <tr>
    <td width="175" height="21"><div align="center"><img src="Redes-/Misto/Misto1.gif" width="175" height="21"> </div></td>
    <td width="175" height="21" bgcolor="#0099FF"><div align="center" class="style1">Azull Claro </div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="Redes-/Misto/Misto2.gif" width="175" height="21"></div></td>
    <td width="175" height="21" bgcolor="#006600"><div align="center" class="style1">Verde</div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="Redes-/Misto/Misto3.gif" width="175" height="21"></div></td>
    <td width="175" height="21" bgcolor="#660066"><div align="center" class="style1">Roxo 2 </div></td>
  </tr>
  
  <tr>
    <td><div align="center"><img src="Redes-/Misto/Misto4.gif" width="175" height="21"></div></td>
    <td width="175" height="21" bgcolor="#FFFF00"><div align="center" class="style1">Amarelo</div></td>
  </tr>
  <tr>
    <td width="175" height="21" bgcolor="#FF3399"><div align="center" class="style1">Rosa</div></td>
    <td width="175" height="21" bgcolor="#006666"><div align="center">&nbsp;&nbsp;&nbsp;&nbsp;<span class="style1">Light Sea Green </span></div></td>
  </tr>
  <tr>
    <td width="175" height="21" bgcolor="#FF0000"><div align="center" class="style1">Vermelho</div></td>
    <td width="175" height="21" bgcolor="#FF8040"><div align="center" class="style1">Tomato</div></td>
  </tr>
  <tr>
    <td width="175" height="21" bgcolor="#FFCC00"><div align="center" class="style1">Dourado</div></td>
    <td width="175" height="21" bgcolor="#666666"><div align="center" class="style1">Grey31</div></td>
  </tr>
  <tr>
    <td width="175" height="21" bgcolor="#6600CC"><div align="center" class="style1">Roxo 1 </div></td>
    <td width="175" height="21" bgcolor="#2E61D8"><div align="center" class="style1">Azul 50% </div></td>
  </tr>
  <td width="175" height="21" bgcolor=""></td>
  
  <form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
  
	<tr>
											<td colspan="5">
											<center>
											  <div align="center" class="">
											    <select name="color222" class="text">
        <option value="13">Rosa</option>
        <option value="14">Vermelho</option>
        <option value="15">Dourado</option>
        <option value="16">Roxo</option>
		<option value="17">Azul Claro</option>
        <option value="2">Verde</option>
        <option value="4">Roxo2</option>
        <option value="6">Amarelo</option>
		<option value="18">Misto 1</option>
        <option value="19">Misto 2</option>
        <option value="3">Misto 3</option>
        <option value="20">Misto 4</option>
		<option value="5">Tomato</option>
        <option value="7">Light Sea Green</option>
        <option value="8">Grey31</option>
        <option value="9">Azul Claro 2</option></select></div>
	  </center></td>
	</tr><td width="175" height="21" bgcolor=""></td>
	
										<tr>
										
											<td colspan="5">
											<center>
											  <div align="center" class="">
											  <input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
</table>
</body>
</html>
<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Compra Realizada Com Sucesso";
die ();  

}

$buscanome = "SELECT ESCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 35) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  KG Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set ESCoins=ESCoins -25 where AID='$aid22'");
echo "NameCollor Adiquirido Com Sucesso, WanteD GunZ Agradece Sua Preferencia !";
}
}else{
echo "WanteD GunZ Agradece Sua Preferencia";
}
}
}


$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>