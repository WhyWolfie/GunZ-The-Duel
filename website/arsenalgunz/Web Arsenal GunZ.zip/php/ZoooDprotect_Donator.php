<?

if( $_SESSION['AID'] == "" )
{
msgBox("Area Restrita apenas para usuarios, se vc ja � um menbro WG efetue o login, se n�o �, nao perca tempo e cadastre-se j�!","index.php");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<div class="content-outline content-top">
                  <div class="title">Compra de creditos (PLUS)</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<div align="center"><br>
<table width="355" border="1">
  <tr>
    <td width="169" bgcolor="#333333"><div align="center">Pacote 150 PG Coins </div></td>
    <td width="167"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="DA8AF8ED5A5A7A7664A5AF9EADCB39AB" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 250 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="EAE373E46666063AA4124F9BE0B551B5" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 350 PG Coins</div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="E743DD6FCACAD10114B86FB706C12132" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 450 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="070A74738D8D0F9CC41CEF8B5D7B7B59" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 550 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="84B0211465654D72246EDFA8B5572248" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 700 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="0404F945EEEE406EE47BAFB04D528A22" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 900 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="E3B26595AEAE574AA41B6F89F13D4A21" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 1100 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="BBDAD8BC404073DFF497FFBA85D3B3B2" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 1300 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="EA57800A070711C664AE2FA628FDBE23" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 2000 PG Coins </div></td>
    <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/payment.html" method="post">
  <div align="center">
  <input type="hidden" name="code" value="56D9964A2B2B51E8848B9F820EC71FAC" />
  <input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-azul.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
  </div>
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
  </tr>
</table></div>

<p>&nbsp;</p>
<p><strong class="style1">Como Efetuar Sua Compra Com Seguranca:</strong></p>
<p><br>
1&ordm; &nbsp;&nbsp;Escolha o pacote ao seu gosto e que caiba no seu bolso<br>
2&ordm; &nbsp;&nbsp;Preencha os campos necessarios que se pedi no cadastro pag seguro<br>
3&ordm; &nbsp;&nbsp;Efetue a impress&atilde;o do boleto bancario, que sera gerado logo ap&oacute;s o preencher os dados que se pedi no pag seguro<br>
4&ordm; &nbsp;&nbsp;Efetue o pagamento em qualquer casa loteria ou no banco indicado no boleto bancario<br>
5&ordm; &nbsp;&nbsp;Ap&oacute;s efetuar o pagamento ser&aacute; dado um comprovante juntamente a outra parte do boleto<br>
6&ordm; &nbsp;&nbsp;Guarde este ncomprovante, chegando em sua casa ou no estabelecimento que vc acessa o game ou tenha acesso a internete<br>
7&ordm; &nbsp;&nbsp;Acesse sua conta no aqui no site, v&aacute; at&eacute; a aba painel do usuario/confirma pagamento<br>
8&ordm;&nbsp;&nbsp; Ser&aacute; aberta uma pagina coloque todos os dados do comprovante nele juntamente com seu login.<br>
9&ordm; &nbsp;&nbsp;Aguarde at&eacute; 3 dias uteis para que o pagamento seja confirmado, e os coins entrara altomaticamente em sua conta do jogo.<br>
10&ordm; Curta muito seus coins e seja o melhor dentro do jogo!
</p>
<p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>