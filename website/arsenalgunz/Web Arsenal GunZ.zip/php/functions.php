<?php
/* 
  *******************       CODED BY // Criminal Team     ************************
*/

function conectar($host, $usuario, $senha, $data){

if(!mssql_connect($host,$usuario,$senha)){
die('<br><br><br><br><h3 align="center"><font color="RED">Falha ao conectar com o Servidor, Se o problema persistir entre em contato com o Administrador</h3></font>');}

if(!mssql_select_db($data)){
die('<br><br><br><br><h3 align="center"><font color="RED">Falha ao conectar com o Servidor, Se o problema persistir entre em contato com o Administrador</h3></font>'); }
}

function valida_email($email){
$email = explode("@",$email);
if(count($email) != 2){
return alertredir("Use um endereço de e-mail válido !","index.php?rz=registro");
}else{
list($user,$domain) = $email;
if(!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*$/xi",$user)){
return alertredir("Use um endereço de e-mail válido !","index.php?rz=registro");
}else{
return 1;
}}}

function alertar($msg){
echo '<script language="javascript">alert("'.$msg.'");</script>';
}

function redirecionar($url){
echo "<body><script>document.location = '$url'</script></body>";
}

function alertredir($msg,$url) {
echo "<script language='javascript'>alert('".$msg."');document.location = '$url'</script>";
}

function ChecaGrade($Aid) {
$Query = mssql_query("SELECT * FROM Account WHERE AID='$Aid';");
$Resultado = mssql_fetch_assoc($Query);
return $Resultado['UGradeID'];
}
?>