<style type="text/css">
<!--
.minhaequipefods {
	color: #FF9900;
	font-style: italic;
}
-->
</style>
<div class="componentheading">
    <h3>
      <div>Equipe Arsenal Gamerz</div>
    </h3>
</div>
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
-->
</style>

			<div class="contentBox">
              <ul class="rank">
                </div>
<center>
<style type="text/css">
<!--
.Equipewanted2 {
	color: #999999;
	font-size: 18px;
	font-weight: bold;
	font-style: italic;
}
.Equipewanted3 {font-size: 24px}
-->
</style>

<br>
<table width="617" height="258" border="0" cellspacing="1" bordercolor="#666666">
  <tr>
    <td width="717"><style type="text/css">
<!--
.equipestyle {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
<table width="613" height="276" border="0" cellspacing="1"><center>
   <tr>
											<td colspan="7" bgcolor="#CCCCCC">
											<center>
											  <div align="center" class="equipestyle">Fundadores</div>
		  </center></td>
		</tr>
  <tr>
    <td height="21">&nbsp;</td>
    <td height="21">&nbsp;</td>
    <td height="21">&nbsp;</td>
  </tr>
  <tr>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
  </tr>
  <tr>
    <td><div align="center"><em>Luan Ortega</em></div></td>
    <td><div align="center"><em>Triwer</em></div></td>
     </tr>
  <tr>
    <td height="21"><div align="center" class="minhaequipefods">( --&gt;  &lt;-- ) </div></td>
    <td><div align="center" class="minhaequipefods">( --&gt; &lt;-- ) </div></td>
    <td><div align="center" class="minhaequipefods">( --&gt; &lt;-- ) </div></td>
  </tr>
  <tr>
    <td height="21">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
											<td colspan="7" bgcolor="#CCCCCC">
											<center>
											  <div align="center" class="equipestyle">Co-Owner</div>
		  </center></td>
		</tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
  </tr>
  <tr>
    <td><div align="center"><em></em></div></td>
    <td><div align="center"><em>SuanoN</em></div></td>
  </tr>
  <tr>
    <td height="21"><div align="center" class="minhaequipefods">( --&gt;  &lt;-- ) </div></td>
    <td><div align="center" class="minhaequipefods">( --&gt; &lt;-- ) </div></td>
    <td><div align="center" class="minhaequipefods">( --&gt; &lt;-- ) </div></td>
  </tr>
  <tr>
    <td height="21">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
											<td colspan="7" bgcolor="#CCCCCC">
											<center>
											  <div align="center" class="equipestyle">Administrador</div>
		  </center></td>
		</tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
  </tr>  
  <td>&nbsp;</td>
    <td><div align="center"><em>MonkeyBlack</em></div></td>
    <td><div align="center"><em>SouthPark</em></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
 <tr>
											<td colspan="7" bgcolor="#CCCCCC">
											<center>
											  <div align="center" class="equipestyle">Games Masters</div>
		  </center></td>
		</tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
  </tr>
  <tr>
    <td><div align="center"><em>Lokinho</em></div></td>
    <td><div align="center"><em></em></div></td>
    <td><div align="center"><em>Twilight</em></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   <tr>
											<td colspan="7" bgcolor="#CCCCCC">
											<center>
											  <div align="center" class="equipestyle">Moderador</div>
		  </center></td>
		</tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="255" height="120"><div align="center"><img src="images/no_emblem.png" width="98" height="100"></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><em>Sem Oculpa&ccedil;&atilde;o </em></div></td>
    <td>&nbsp;</td>
  </tr>
</table></td>
  </tr>
</table>
