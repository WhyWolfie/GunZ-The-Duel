<div class="componentheading">
    <h3>
      <div>Adicionar Noticias</div>
    </h3>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?
include "protects/authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $title = clean($_POST['title']);
    $type = clean($_POST['type']);
    $text = clean($_POST['text']);
    $user = $_SESSION['UserID'];
    mssql_query_logged("INSERT INTO IndexContent ([Type], [User], [Date], [Text], [Title])VALUES($type, '$user', GETDATE(), '$text', '$title')");
    msgbox("Noticia Adicionada Com Sucesso!","index.php");
}else{
?><head>
	<meta name="keywords" content="" />
<meta http-equiv="Content-Language" content="pt-BR">


	<link rel="stylesheet" type="text/css" href="estilos/reset.css">
	<link rel="stylesheet" type="text/css" href="estilos/estilo.css">




    <script type="text/javascript" src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
	<script type="text/javascript" src="js/imageeffects.min.js"></script>
    
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
    
    
   

  <link rel="stylesheet" type="text/css" href="javascript/lightbox/themes/default/jquery.lightbox.css">
  <script type="text/javascript" src="javascript/lightbox/jquery.lightbox.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.lightbox').lightbox();
    });
  </script>
  
<script type=�text/javascript�>
if( window.console && window.console.firebug ){
alert(�Desculpe, este site n�o suporta o Firebug!�);
window.location=�/sem_firebug.html�;
}
</script>
<style type="text/css">
<!--
.style1 {
	color: #666666;
	font-weight: bold;
	font-style: italic;
	font-size: 18px;
}
-->
</style>
<body bgcolor="#312F30">

					<div align="center">
					  <span class="style1"><br>					  
					  </span>
					  <br><table width="428" border="0" bordercolor="#666666" style="border-collapse: collapse">
							
							<td width="422">
							<tr>
								<td background="">
								<div align="center">
									<form method="POST" action="index.php?gunz=NoticiasSanDisk"><table border="0" style="border-collapse: collapse" width="740" height="100%">
										

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>

										<tr>
											<td colspan="3">											</td>
										</tr>

										<tr>
											<td colspan="3">											</td>
										</tr>

										<tr>
											<td width="256" align="right">&nbsp;</td>
											<td width="45">Titulo:</td>
											<td width="625">
										  <input type="text" name="title" size="40"></td>
										</tr>

										<tr>
											<td width="256" align="right">&nbsp;</td>
											<td width="45">Tipo:</td>
											<td width="625">
											<select size="1" name="type">
											<option selected value="1">Noticias</option>
										  </td>
										</tr>

										<tr>
											<td width="256" align="right" valign="top"></td>
											<td width="45">Texto:</td>
											<td width="625">
										  <textarea rows="1" name="text" cols="35"></textarea></td>
										</tr>

										<tr>
											<td width="256">&nbsp;											</td>
											<td width="45">&nbsp;											</td>
											<td width="625">&nbsp;											</td>
										</tr>

										<tr>
											<td colspan="3">
											<p align="center">
										  <input type="submit" value="Concluir" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							
					  </table>
</div>
<?
}
?>