<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?php
  $query = mssql_query("SELECT * FROM Account WHERE UserID='".$_SESSION['UserID']."'");
  $selectinf = mssql_fetch_assoc($query);
 ?>
<style type="text/css">
<!--
.style1 {font-style: italic}
.style2 {
	font-size: 12px;
	font-style: italic;
}
-->
</style>


<div class="componentheading">
    <h3>
      <div>Minha Conta</div>
    </h3>
<div align="center">
<table width="518" height="159" border="0" cellspacing="1" bordercolor="#333333">
  <tr>
    <td><table width="518" border="0" cellspacing="1">
	
      <tr>
        <td width="169">&nbsp;</td>
        <td width="6">&nbsp;</td>
        <td width="333">&nbsp;</td>
      </tr>
      <tr>
        <td>Nome:</td>
        <td>:</td>
        <td><?php echo $selectinf['Name']; ?>&nbsp;</td>
      </tr>
      <tr>
        <td>Login:</td>
        <td>:</td>
        <td><?php echo $selectinf['UserID']; ?></td>
      </tr>
      <tr>
        <td>Data de Cria&ccedil;&atilde;o da conta: </td>
        <td>:</td>
        <td><?php echo $selectinf['RegDate']; ?></td>
      </tr>
      <tr>
        <td>Data/hora utimo login: </td>
        <td>:</td>
        <td><?php echo $selectinf['LastLoginTime']; ?></td>
      </tr>
      <tr>
        <td>Data/hora logout: </td>
        <td>:</td>
        <td><?php echo $selectinf['LastLogoutTime']; ?></td>
      </tr>
      <tr>
        <td>Ultimo Login servidor : </td>
        <td>:</td>
        <td><?php echo $selectinf['ServerID']; ?></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      <tr>
		  <td colspan="8">
			<center>
			  <div align="center" class="style2">Agradecemos Sua Preferencia</div>
		  </center></td>
		</tr>
    </table></td>
  </tr>
</table>