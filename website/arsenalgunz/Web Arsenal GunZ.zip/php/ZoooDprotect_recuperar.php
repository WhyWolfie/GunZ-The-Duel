<?php 
if($_SESSION['userid']) 
{ 
redirect("/", 0); 
die(); 
} 
?> 
<div class="componentheading">
    <h3>
      <div>Recupere sua senha!</div>
    </h3>
</div>
              
Digite Seu e-mail de cadastro abaixo para poder recuperar sua senha...


<form action='index.php?gunz=recuperar' method='post'> 
<br><input type='text' name='email' value='Seu e-mail'> 


<input type='submit' value='Recuperar senha' name='submit'> 
</form> 

<?php 
$fet =($_POST['fet']); 
$senha=($_POST['senha']); 
$email = ($_POST['email']); 
$fet2 =($_POST['fet2']); 
if (isset($_POST['submit'])){ 
if ( $email == ""){ 
msgbox ("enter","index.php?gunz=recuperar"); 
} 
else { 
$res = mssql_query(" 
                            SELECT a.AID, a.UserID, a.Email, l.password 
                            FROM Account a INNER JOIN Login l ON a.AID = l.AID 
                            WHERE a.Email = '$email' 
"); 
$row = mssql_fetch_row($res); 
$userid = $row[1]; 
$senha = $row[3]; 
        if (!$row){ 
            msgbox ("Email inexistente.","index.php"); 
        } 
        else { 
$Nome = "Recupera��o de Senha"; 
$emailremetente = "infected_games@yahoo.com.br"; 
$header = "De: ". $Nome . " <" . $emailremetente . ">\r\n"; 
$cabecalho = "Content-type: text/html\r\n"; 
$mensagem ="Detalhes da Sua Conta <br>______________<br>Login = ".$userid." <br>Senha = ".$senha." <br>______________<br>Por favor, n�o passe sua senha para ningu�m.<br>A administra��o jamais ir� pedir sua senha.<br>______________<br>Equipe Gunz"; 
ini_set('sendmail_from', 'infected_games@yahoo.com.br'); 
            mail("$email", "Recupera��o Senha Gunz Online",$mensagem,$cabecalho,$header); 
msgbox ("Enviado. Verifique seu email.","index.php");     
        } 
    } 
} 
/**Programado por Netheris - 
Netheris@hotmail.com**/  

?> 
  </p>