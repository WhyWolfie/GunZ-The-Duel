<?
$res = mssql_query("SELECT TOP 100 * FROM TotalRanking ORDER BY Rank ASC");
?>
<style type="text/css">
<!--
.style1 {font-size: 14px}
-->
</style>

<div class="content-outline content-top">
                  <div class="title"><a href="#">Ultimas Clan War Arsenal Gamerz</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
<table width="559" border="0" bordercolor="#999999" id="table4" style="border-collapse: collapse">
							
							<tr>
								<td><p align="center"><br><?
$busca999 = mssql_query("SELECT TOP 100 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
                                    	<center>
                                    	<span class="style1"><strong>
                                    	
                                    	<?=$item22[2]?>
                                    	- <?=$item22[0]?>
                                    	</strong></a></span> <span class="style1"><strong><font color=cyan>vs</font></strong></span> <strong><span class="style1">
                                    	<?=$item22[1]?> - <?=$item22[3]?>
                                    	</span></strong>
                                    	</center>
    </div>
                                </li>
<center><?
}
?></center></p>
							  </td>
</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>