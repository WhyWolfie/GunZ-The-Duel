<style type="text/css">
<!--
a:link {
	color: #0099FF;
}
a:visited {
	color: #0099FF;
}
a:hover {
	color: #0099FF;
}
a:active {
	color: #0099FF;
}
-->
</style><div class="componentheading">
    <h3>
      <div>Gradua��es</div>
    </h3>
</div>
					
					<center><table width="592" border="0">
  <tr>
    <td width="288" bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p><a href="index.php?gunz=staff1">Administradores</a></p>
      </div></td>
    <td width="288" bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p><a href="index.php?gunz=staff2">Game Master's</a> </p>
      </div></td>
    <td width="288" bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p><a href="index.php?gunz=staff3">Moderadores</a></p>
      </div></td>
  </tr>
  <tr>
    <td height="21" bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p><a href="index.php?gunz=staff4">Banidos</a></p>
      </div></td>
    <td bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p><a href="index.php?gunz=staff5">Chat Blockiado </a></p>
      </div></td>
    <td bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p><a href="index.php?gunz=staff6">jjang</a></p>
      </div></td>
  </tr>
</table></center>

					