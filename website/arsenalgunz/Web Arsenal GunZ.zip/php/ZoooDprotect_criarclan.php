<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
 <div class="box_two">
 <div class="box_two_title">Criar Clan</div>
<?
//Arsenal GunZ - Criar Clan

//ANTI BUG CLAN FUNC
Function foder($str){

	$caracters = array("'", " ", "?", "�", "0x", "!", "^", "-", "*", "&", "@", "#", "�", "�", "+", "~", "<", ">", ":", ";", "�", "`", "%", "update", "select", "drop table", "delete table");
	$blank = "0";
return str_replace($caracters, $blank, $str);
}
?>
<?
if ($_SESSION['AID'] == ""){
    msgbox("Logue-se primeiro!","index.php");
    die();
	}
$q2chars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($q2chars) == 0 )
    {
	msgbox("Sem personagens.","index.php");
    die();
	} 
?> 
<div align="center">
</br>
Escolha o Personagem para ser Dono do Clan :</font></br>
</br>
<form action="index.php?gunz=criarclan" method="post">
<?php
$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0");
echo '<select name="CID">';
 if(mssql_num_rows($query)<>0){
   while($char = mssql_fetch_assoc($query)){
    echo '<option value="'.$char['CID'].'">';
     echo $char['Name'];
    echo '</option>';
   }
 }else{
   echo '<option></option>';
 }
echo '</select>';
?>
<input name="NOME" onfocus="if(this.value=='Username') this.value='';" onblur="if(this.value=='') this.value='Username';" value="Nome Do Cl�" type="text" maxlength="6" onkeyup="valid(this,'special')" onblur="valid(this,'special')"></br>
</br>
</br><input type="submit" class="logon" name="criaraf" value="Criar" />
</form>
<?php
if (isset($_POST['criaraf'])){
$NOME = clean($_POST['NOME']);
$CID = clean($_POST['CID']);

if(strlen($NOME) > 10){
            msgbox("Nome muito grande no Minimo 6 Letras!","index.php");
    die(); 
        }
if(strlen($NOME) < 4){
            msgbox("Nome muito curto no minimo 4 Letras!","index.php");
    die(); 
        }
$lil = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$CID'");
$trin = mssql_query("SELECT Name FROM Clan WHERE Name = '$NOME'");
$otario = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$CID'");

if (mssql_num_rows($trin) >= 1){
msgbox("Nome do clan ja existe!","index.php");
    die(); 
        }
if (mssql_num_rows($lil) >= 1){
msgbox("Esse personagem ja possui um clan!","index.php");
    die(); 
        }
if (mssql_num_rows($otario) == 0 )
        {
	msgbox("Esse Personargem pertence a outra conta!","index.php");
    die();
	}
$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$NOME', '$CID', GETDATE())");
$res = mssql_query_logged("SELECT * FROM Clan(nolock) WHERE Name = '$NOME' AND MasterCID = '$CID'");
	    $usr = mssql_fetch_assoc($res);
	    $clid = $usr['CLID'];
$zuei = mssql_query("DELETE FROM ClanMember WHERE CLID = '$clid'");
mssql_query_logged("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$CID', 1, GETDATE())");
if($sql){
	msgbox("Clan Criado Com sucesso!","index.php");
    die(); 
}else{
	msgbox("Ocorreu um erro fale com algum membro da equipe!","index.php");
    die(); 
}
}
?>
</div>
</br>
</br>