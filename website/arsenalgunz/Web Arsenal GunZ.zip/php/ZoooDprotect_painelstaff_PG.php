<?
include "protects/authadmin.php";
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>

<style type="text/css">
<!--
.style1 {color: #009999}
a:link {
	color: #666666;
	font-style: italic;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
.style2 {
	color: #666666;
	font-style: italic;
	font-size: 9px;
}
-->
</style>
<div class="componentheading">
    <h3>
      <div>Painel Staff</div>
    </h3>
</div><center><table width="419" border="0">
  <tr>
    <td width="127"><div align="center" class="style1">Moderador </div></td>
    <td width="127"><div align="center" class="style1">Game Master </div></td>
    <td width="127"><div align="center" class="style1">Administrador</div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?gunz=VentoCoinsSunDisk">Enviar EV. Coins  </a></div></td>
    <td><div align="center"><a href="index.php?gunz=NoticiasSanDisk&amp;submit">Adcionar Noticia</a> </div></td>
    <td><div align="center"><a href="index.php?gunz=Especialsundisk">Adcionar G.I </a> </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?gunz=wantedmuteplayer">Dar Chat Block </a></div></td>
    <td><div align="center"><a href="index.php?gunz=banlist&amp;submit">Players Banidos </a></div></td>
    <td><div align="center"><a href="index.php?gunz=Donatorsundisk">Adcionar P.I </a></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?gunz=wantedbannedxD">Banir Player's  </a> </div></td>
    <td><div align="center" class="style2">[ Sem Funcao ]</div></td>
    <td><div align="center"><a href="index.php?gunz=VentoAndSunDisk">Adcionar E.I </a></div></td>
  </tr>
</table>

					</div></center>
                </div>
                <div class="content-outline content-end"></div><br>
				<? if($_SESSION['AID'] == 7 or $_SESSION['AID'] == 6 or $_SESSION['AID'] == 2){include"php/ZoooDprotect_fundadorpainelxDxD.php";echo "</br>";} ?>