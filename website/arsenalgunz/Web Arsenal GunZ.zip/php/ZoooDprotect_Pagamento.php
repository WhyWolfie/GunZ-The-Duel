<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?><style type="text/css">
<!--
a:link {
	color: #666666;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
-->
</style>
<div class="componentheading">
    <h3>
      <div>Confirme Seu pagamento aqui</div>
    </h3>
                    <div align="center">
  <table width="488" height="249" border="0" cellspacing="1">
  <tr>
    <td><script type="text/javascript">
<!--
var time = 3000;
var numofitems = 7;

//menu constructor
function menu(allitems,thisitem,startstate){ 
  callname= "gl"+thisitem;
  divname="subglobal"+thisitem;  
	this.numberofmenuitems = allitems;
	this.caller = document.getElementById(callname);
	this.thediv = document.getElementById(divname);
	this.thediv.style.visibility = startstate;
}
				 
//menu methods
function ehandler(event,theobj){
  for (var i=1; i<= theobj.numberofmenuitems; i++){
	  var shutdiv =eval( "menuitem"+i+".thediv");
    shutdiv.style.visibility="hidden";
	}
	theobj.thediv.style.visibility="visible";
}
				
function closesubnav(event){
  if ((event.clientY <48)||(event.clientY > 107)){
    for (var i=1; i<= numofitems; i++){
      var shutdiv =eval('menuitem'+i+'.thediv');
			shutdiv.style.visibility='hidden';
		}  
	}
}
// -->
</script>

<?
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
if(isset($_POST['submit'])){
    $title = clean($_POST['title']);
    $type = clean($_POST['type']);
    $text = clean($_POST['text']);
    $user = $_SESSION['UserID'];
    mssql_query_logged("INSERT INTO confirma ([Type], [User], [Date], [Text], [Title], [Data], [Hora], [Quantidade], [mail], [Provedor])VALUES($type, '$user', GETDATE(), '$text', '$title', '$Data', '$Hora', '$Quantidade', '$mail', '$provedor')");
    msgbox("Ticket Enviado Com Sucesso, Aguarde At� 3 Dias Uteis.","index.php");
}else{
?>

	<style type="text/css">
<!--
a:link {
	color: #0066CC;
}
a:visited {
	color: #0066CC;
}
-->
</style>
<style type="text/css">
<!--
.style3 {font-weight: bold}
.style4 {
	font-size: 18px;
	font-weight: bold;
	color: #999999;
	font-style: italic;
}
-->
</style>
<style type="text/css">
<!--
.style4 {
	color: #00FF00;
	font-size: 14px;
}
.style5 {
	color: #999999;
	font-size: 18px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
<body>

	
	  
	                    <center><table width="484" border="0" bordercolor="#999999" style="border-collapse: collapse">
							
							<tr>
								<td width="584" background="">
								<div align="center">
									<form method="POST" action="index.php?wanted=Pagamento"><table border="0" style="border-collapse: collapse" width="475" height="100%">
										

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>

										<tr>
											<td colspan="3">											</td>
										</tr>

										<tr>
											<td colspan="3">											</td>
										</tr>

										<tr>
											<td width="142" align="right"><span class="style1">Nome</span></td>
											<td width="1">&nbsp;											</td>
											<td width="405">
										  <input name="title" type="text" size="40" maxlength="10"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right"><span class="style1">Data</span></td>
										  <td>&nbsp;</td>
										  <td><input name="Data" type="text" id="Data" value="00/00/00" size="40" maxlength="8"></td>
									  </tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right"><span class="style1">Hora</span></td>
										  <td>&nbsp;</td>
										  <td><input name="Hora" type="text" id="Hora" value="00:00:00" size="40" maxlength="8"></td>
									  </tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right"><span class="style1">Quantidade</span></td>
										  <td>&nbsp;</td>
										  <td><input name="Quantidade" type="text" id="Quantidade" size="40" maxlength="5"></td>
									  </tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right">E-mail</td>
										  <td>&nbsp;</td>
										  <td><input name="mail" type="text" id="mail" size="40" maxlength="8">										    </td>
									  </tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right">Provedor</td>
										  <td>&nbsp;</td>
										  <td><select name="provedor" size="1" id="provedor">
                                              <option selected value="gmail.com">@gmail.com</option>
                                              <option value="hotmail.com.br">@hotmail.com.br</option>
                                              <option value="hotmail.com">@hotmail.com</option>
											  <option value="uol.com.br">@uol.com.br</option>
											  <option value="ig.com.br">@ig.com.br</option>
											  <option value="terra.com.br">@terra.com.br</option>
											  <option value="oi.com.br">@oi.com.br</option>
											  <option value="Outros">Outros Digite abaixo</option>
                                            </select>&nbsp;</td>
									  </tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="142" align="right">
											  <span class="style1">Tipo</span></td>
											<td width="1">&nbsp;											</td>
											<td width="405"><select size="1" name="type">
                                              <option selected value="1">Donator Coins </option>
                                              <option value="2">Custom Coins </option>
                                            </select></td>
										</tr>

										<tr>
										  <td align="right" valign="top">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="142" align="right" valign="top"><span class="style3">Adicionais </span></td>
											<td width="1">&nbsp;											</td>
											<td width="405">
										  <textarea rows="5" name="text" cols="50"></textarea></td>
										</tr>

										<tr>
											<td width="142">&nbsp;											</td>
											<td width="1">&nbsp;											</td>
											<td width="405">&nbsp;											</td>
										</tr>
										
										<tr>
										  <td colspan="3"><div align="center">Se Por Acaso Tiver Faltando Preencher alguma lacuna o ticket ser&aacute; desconsiderado </div></td>
									  </tr>
										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>

										<tr>
											<td colspan="3">
											<p align="center">
										  <input type="submit" value="Confirmar Pagamento" name="submit"></td>
										</tr>

										</table>
									</form>
								</div>							  </td>
							</tr>
	  </table>
				    <p class="style1">&nbsp;</p>
	</div>
<?
}
?></td>
  </tr>
</table></div>
