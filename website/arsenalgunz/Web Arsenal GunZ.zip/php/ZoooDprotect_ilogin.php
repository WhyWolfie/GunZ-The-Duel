<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
<?
if ($_SESSION['AID'] == ""){
?>
<style type="text/css">
<!--
.style2 {font-size: xx-small}
a:link {
	color: #005FA9;
}
-->
</style>

<div align="center">
						<table width="269" height="113" border="0" id="table5" style="border-collapse: collapse">
							<tr>
								<td width="269" background="menu_bg.jpg">
								<form method="POST" action="index.php?gunz=login&header=1" name="login">
									<center><table border="0" style="border-collapse: collapse" width="269" height="100%" id="table10" class="iLogin">
										<tr>
											<td colspan="4"><h4>�������Usuario</h4></td>
										</tr>
										
										<tr>
											
											<td width="161">
										      <div align="center">
										        <input name="userid" type="text" class="login" style="background-image: url(''); background-position: left center" lang="pt" size="30" maxlength="10" />
									      </div></td>
										</tr>
										<tr>
										  <td><h4>�������Senha</h4></td>
									  </tr>
										<tr>
											
											<td width="161">
										      <div align="center">
										        <input name="pasw" type="password" class="login" id="input" style="background-image: url(''); background-position: left center" size="30"> 
								          </div></td>
										</tr>
										
										<tr>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="161" rowspan="2">
											<p align="center">
										  <input name="submit" type="image" src="images/form_but1.png" class="" value=" ACESSAR PAINEL DO PLAYER ">
										  <a href="index.php?gunz=register"><img src="images/form_but2.png" width="67" height="47" border="0" /></a><a href="index.php?gunz=recuperar"><img src="images/form_but3.png" width="52" height="47" border="0" /></a></td>
										</tr>
								  </table>
								</form>								</td>
							</tr>
							<tr>
								
							</tr>
</table>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
?>

<div align="center">
<div align="center">
						<table width="273" height="13" border="0" id="table5" style="border-collapse: collapse">
							<tr>
								
						  </tr>
							<tr>
								<td background="">
																	<table border="0" style="border-collapse: collapse" width="180" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<?=$_SESSION['UserID']?><span class="timeclock" style="margin-left:15px; margin-top:25px; color:#777777; font-size:10px;">
	<script>
 function showTimer() {
  var time=new Date();
  var hour=time.getHours();
  var minute=time.getMinutes();
  var second=time.getSeconds();
  if(hour<10)   hour  ="0"+hour;
  if(minute<10) minute="0"+minute;
  if(second<10) second="0"+second;
  var st=hour+":"+minute+":"+second;
  document.getElementById("timer").innerHTML=st; 
 }
 function initTimer() {
  // O metodo nativo setInterval executa uma determinada funcao em um determinado tempo  
  setInterval(showTimer,1000);
 }
</script>
<body onLoad="initTimer();">
<span id="timer"></span>
</body></font></td>
										</tr>
<tr>

										  <td>&nbsp;</td>
										  </tr>
										<tr>
										<tr>
											<td width="8" rowspan="5">&nbsp;</td>
											<td width="181"><img src="images/ouro.png" width="12" height="11"> Master Coins:<?=$d['RZMaster']?> <br><br>
											<img src="images/prata.png" width="12" height="11">Donater Coins:<?=$d['RZCoins']?> <br><br> 
											<img src="images/bronze.png" width="12" height="11"> Event Coins:<?=$d['EVCoins']?> </td></td>									 <tr>

										  <td>&nbsp;</td>
										  </tr><tr>
											
										  <td><a href="index.php?gunz=painelplayer"><img src="images/bullet.gif" width="12" height="11"> PAINEL AG</a></td>
										  </tr>
										  <tr>

										  <td>&nbsp;</td>
										  </tr>
										  
										<tr>
										  <td><a href="index.php?gunz=login&amp;action=logout&amp;header=1"><img src="images/sair.png" width="30" height="30" border="0" /></a></td>
										  </tr>
										<tr>
										</tr>
<tr>
											<td colspan="2">
											<div align="center">
												
											</div>											</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="center">
												
											</div>											</td>
										</tr>
										</table>
								
								
							</tr>
							<tr>
								
						  </tr>
</table>

<?
}
?>
