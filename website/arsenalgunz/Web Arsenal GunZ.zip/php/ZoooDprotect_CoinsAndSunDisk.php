<div class="componentheading">
    <h3>
      <div>Enviar Donater Coins</div>
    </h3>
</div>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?
include "protects/authafundadores.php";
include 'protects/anti_sql.php';
include 'protects/inject.php';
if($_SESSION['UGradeID'] == 254){
    msgbox("Error 201 = Acesso Negado ###Protegido###","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Error 201 = Acesso Negado ###Protegido###","index.php");
}
//by HearT
include "configura��o/config.php";
if (!(isset($_POST['nick2'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?gunz=CoinsAndSunDisk">
<table border="0" width="456" style="border-collapse: collapse">			
			<tr>
				<td width="4" rowspan="12">&nbsp;</td>
			  <td width="136">&nbsp;<br /></td>
			</tr>

<tr>
<td>Nick do personagem :</td>
<td width="302">
<input type="text" id="nick2" class="log_field" size="16" name="nick2" value="" maxlength="20"><br>
</td>
</tr>
<tr>
<td>Quantidade de coins :</td>
<td><input type="text" id="coins" class="log_field" size="16" name="coins" value="" maxlength="20"><br><br>
</td></tr>
<tr><td></td><td>
<input type="submit" name="logar" value="Enviar" /></td>
</tr>
</table>
</form>
<br><br>


<?
}else{

$aid22 = $_SESSION['AID'];

$busca3 = mssql_query("SELECT UGradeID FROM Account WHERE AID = '$aid22'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255 OR 254){

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables", "union", "UPDATE", "update");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$nick11 = Filtrrar($_POST['nick2']);
$coins11 = Filtrrar($_POST['coins']);

$busca1 = mssql_query("SELECT AID FROM Character WHERE Name = '$nick11'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))
{
die ("## Erro = Protecao ZoooD web, nao encontrou personagen solicitado.##");
}else{
mssql_query("UPDATE Login SET WGCoins = WGCoins + $coins11 WHERE AID = '$busca2[0]'");
echo "$coins11 Coins foram adicionados para o usuario do Char $nick11";
}


}else{
echo "Voce nao tem permissao para acessar esta area";
}
}

$logfile = fopen("Coins/PlusCoins.txt","a+");
$logtext = "IP: {$_SERVER['REMOTE_ADDR']} - AID {$aid22} presenteou {$coins11} coins para {$nick11} . \r\n";
fputs($logfile, $logtext);
fclose($logfile);

?>