<style type="text/css">
<!--
.style1 {color: #009999}
a:link {
	color: #666666;
	font-style: italic;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
-->
</style>
<div class="componentheading">
    <h3>
      <div>Painel player</div>
    </h3>
</div><center><table width="419" border="0">
  <tr>
    <td width="127"><div align="center" class="style1">Minha Conta </div></td>
    <td width="127"><div align="center" class="style1">Personagens</div></td>
    <td width="127"><div align="center" class="style1">Clans</div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?gunz=Trocar">Trocar Pts de CW</a> </div></td>
    <td><div align="center"><a href="index.php?gunz=namecolor">Name Collor </a></div></td>
    <td><div align="center"><a href="index.php?gunz=criarclan">Criar Cl�n </a></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?gunz=minhaconta">Status Da Conta </a></div></td>
    <td><div align="center"><a href="index.php?gunz=Pagamento">Confirmar Pagamento</a> </div></td>
    <td><div align="center"><a href="index.php?gunz=clas">Meus Cl&atilde;'s </a></div></td>
  </tr>
  
  
  
</table>

					</div>
                </div></center>
                <div class="content-outline content-end"></div><br>
				<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252 and !$_SESSION['AID'] == ""){include"php/ZoooDprotect_painelstaff_PG.php";echo "</br>";} ?>
                