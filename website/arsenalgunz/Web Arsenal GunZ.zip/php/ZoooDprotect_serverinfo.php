<div class="content-outline content-top">
                  <div class="title"><a href="#">Informacoes do Servidor  &quot;PlusGunz&quot;</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<table width="416" border="0">
  <tr>
    <td width="202">Servidor:</td>
    <td width="204"><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = '';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #FF00FF'><B>OFFILINE</B></font><br />";
        }
        else
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #228B22'><B>ONLINE</B></font><br />";
            fclose($fp);
        }
    }
    ?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Agent error: </td>
    <td> . Conex&atilde;o NAT </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Players Online:</td>
    <td>. <?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong><font style='color: #00FFFF'>$servercount</font>";
    ?></td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Total de Contas:</td>
    <td>. <? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>"; 
?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Total de Personagens: </td>
    <td>. <?php


 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>";

?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Total de Clan's: </td>
    <td>. <?php


 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>";

?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Server EXP: </td>
    <td>. 65x </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Jogabilidade:</td>
    <td>. Leve / Boa </td>
  </tr>
</table><br />
--------------------------------------------------------------------------------------------<br><br>Contatos Do Servidor</body><br><br><table width="421" border="0">
  <tr>
    <td width="203">FaceBook:</td>
    <td width="208"> . Em Breve </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Twitter:</td>
    <td>. Em Breve </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Skype:</td>
    <td>. Em Breve </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>E-mail:</td>
    <td>. Em Breve </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Orkut:</td>
    <td>. Em Breve </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Messengers:</td>
    <td>. Em Breve </td>
  </tr>
</table>

</html>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
