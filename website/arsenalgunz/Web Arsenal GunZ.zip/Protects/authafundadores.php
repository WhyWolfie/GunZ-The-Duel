<?
if($_SESSION['AID'] == 7 or $_SESSION['AID'] == 6 or $_SESSION['AID'] == 2 and !$_SESSION['AID'] == ""){
    $userid = $_SESSION['UserID'];
    $aid = $_SESSION['AID'];
    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid' AND AID = '$aid'");
    $data = mssql_fetch_assoc($res);
    if(!$data['AID'] == $_SESSION['AID']){
        echo "Se��o admin invalida!";
    }
}else{
    die("Sua Chave de acesso ao painel staff n�o tem autoridade suficiente para acessar esta area!");
}
?>