<?php
mssql_connect("TU-PC\SQLEXPRESS","sa","asdasdn");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Arsenal Gamerz";
}
?>