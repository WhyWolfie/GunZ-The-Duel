<?php
mssql_connect("200-98-161-206\SQLEXPRESS","sa","shanks123");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Arsenal Gamerz";
}
?>