<?
//Script de ultimas do forum Coded By Gaspar ;D

if($mode == on)

{


if(!($id = mysql_connect($server,$usuario,$password))) {
   echo "FORUM EM MANUTEN��O";
}


if(!($con=mysql_select_db($dbnamef,$id))) {
   echo "FORUM EM MANUTEN��O";
} 

$busca1 = mysql_query("SELECT tid, title, starter_name FROM topics ORDER BY start_date DESC LIMIT 6");

while($busca2 = mysql_fetch_row($busca1))
{

$busca3 = mysql_query("SELECT member_id FROM members WHERE members_display_name = '$busca2[2]'");
$busca4 = mysql_fetch_row($busca3);

?>

                            	<li>
                                	<div class="lt_box_topicthreads">
                                    	<a target="meio" href="<?=$link25?>index.php?/topic/<?=$busca2[0]?>-<?=$busca2[1]?>/"><?=$busca2[1]?></a>
                                    </div>
                                    <div class="lt_box_users">
                                    	<a target="meio" href="<?=$link25?>index.php?/user/<?=$busca4[0]?>-<?=$busca2[2]?>/"><?=$busca2[2]?></a>
                                    </div>
                                    <div class="right_col_box_devider"></div>
                                </li>

<?
}
}else{
echo "<br><br>";
echo "FORUM EM MANUTEN��O";
echo "<br><br>";
}
?>
