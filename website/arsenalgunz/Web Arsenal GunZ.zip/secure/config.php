<?php
$gunzname = "Arsenal Gamerz";  //Your Server Name

$_MSSQL['Host'] = "JUANARIAS-PC\SQLEXPRESS";
$_MSSQL['User'] = "sa";
$_MSSQL['Pass'] = "27173706Juan";
$_MSSQL['DB'] = "SoundDB";

$error1 = "Cant connect to database";
$error2 = "Cant find Database";

$con = mssql_connect($_MSSQL['Host'], $_MSSQL['User'], $_MSSQL['Pass']) or die($error1);
mssql_select_db($_MSSQL['DB']) or die($error2);
?>