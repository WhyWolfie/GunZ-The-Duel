<?
//Configura��es "Ultimas Do F�rum"
$link25 = "http://www.energygunz.net/forum/"; //Link do seu forum!
$server = "localhost"; //Nome do servidor do Mysql (Padr�o:localhost)
$dbnamef = "forum"; // Indique o nome do banco de dados (Database do f�rum)
$usuario = "root"; // Indique o nome do usu�rio que tem acesso
$password = "infected#$158"; // Indique a senha do usu�rio
$mode = "on"; //Se o modo estiver "on" � porque esta ativado, se tiver "off" � porque esta desativado
?>