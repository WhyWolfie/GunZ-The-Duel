<?
@session_start();
function makepoststring($string) {
    if (strlen($string) > 17){
        return ucfirst(substr($string,0,17) . "...");
    }else{
        return ucfirst($string);
    }
}

function clean($value)
{
        $check = $value;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');


        $value = str_replace($search, '', $value);
        $value = preg_replace(sql_regcase("/(from|select|insert|delete|update|set|shutdown|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);

        if( $check != $value )
        {
            $logf = fopen("logs/Hacklogs.txt", "a+");
            fprintf($logf, "Date: %s IP: %s Code: %s, Fixed: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
alertbox("SQL Injection Detectado !!","index.php");
        }

        return( $value );
}

function mssql_query_logged($query)
{

    //$f = fopen("logs/Querylogs.txt", "a+");
    //fprintf($f, "%s (mod_%s.php) - [AID=%s] %s [%s] - %s\r\n", $_SERVER[PHP_SELF],$_GET['do'], $_SESSION['AID'],  date("d-m-y - H:i:S"), $_SERVER['REMOTE_ADDR'], $query);
    //fclose($f);

    return mssql_query($query);
}

function ChangeTitle($title) {
    echo "<script language='JavaScript'>
document.title='".$title."';
</script>";
}

function mTrim($cadena){
    return str_replace(" ","",$cadena);
   }

function ErrorBox($data) {
    return "                               <tr>
											<td width='434' colspan='2'>
											<div align='center'>
												<table border='1' width='90%' height='90%' style='border-collapse: collapse' bordercolor='#FF0000' bgcolor='#FF9191' class='errorbox'>
													<tr>
														<td>
														<table border='0' width='100%' height='100%' style='border-collapse: collapse'>
															<tr>
																<td valign='bottom' width='434' colspan='2'>
														<img border='0' src='images/icon_error.gif' width='16' height='17'>
														<font size='1'><b>An error occurred!</b></font></td>
															</tr>
															<tr>
																<td width='19'>&nbsp;</td>
																<td width='434' valign='top'><b>$data</b></td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width='8'>&nbsp;</td>
										</tr>
										<tr>
											<td width='145'>
											&nbsp;</td>
											<td width='289'>
											&nbsp;</td>
											<td width='8'>&nbsp;</td>
										</tr>";
}

function msgbox($text, $url){
echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>"; 
}



function re_dir($url){
echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";

}

function MakePercent($Value, $Total)
{
    return ($Value * $Total) / 100;
}

function GetKDRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

function GetCharNameByCID($cid)
{
    $ncid = clean($cid);
    $a = mssql_fetch_assoc(mssql_query("SELECT Name FROM Character(nolock) WHERE CID = '$ncid'"));
    return $a[Name];
}

function FormatCharName($cid)
{
    $ncid = clean($cid);
    $res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character(nolock) ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));

    $name = $res[1];

    switch($res[0])
    {
        case 2:
            return "<font color='#00FF7F'>$name</font>";
        break;
        case 13:
            return "<font color='FF66FF'>$name</font>";
        break;
        case 4:
            return "<font color='#8968CD'>$name</font>";
        break;
        case 5:
            return "<font color='#FF6347'>$name</font>";
        break;
        case 6:
            return "<font color='#FFFF00'>$name</font>";
        break;
        case 7:
            return "<font color='#00CED1'>$name</font>";
        break;
        case 8:
            return "<font color='#8B8989'>$name</font>";
        break;
        case 9:
            return "<font color='#00008B'>$name</font>";
        break;
        case 14:
            return "<font color='red'>$name</font>";
        break;
        case 16:
            return "<font color='#8968CD'>$name</font>";
        break;
        case 255:
            return "<font color='#00FFFF'>$name</font>";
        break;
        case 254:
            return "<font color='#EE9A00'>$name</font>";
        break;
        case 252:
            return "<font color='#FFE4B5'>$name</font>";
        break;
        default:
            return $name;
        break;
    }
}

function GetClanPercent($Wins, $Losses)
{
    $total = $Wins + $Losses;

    return ($total == 0) ? "0%" : round((100 * $Wins) / $total, 2) . "%";
}

?>