<?
include "config.php";
?>
<?
if ($_GET['expand'] == 1){
?>
				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('images/subbar.png'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=ranking&sub=individual&expand=1">
					<img border="0" src="images/subbar/individualranking.jpg" width="128" height="13"></a><a href="index.php?do=ranking&sub=clan&expand=1"><img border="0" src="images/subbar/clanranking.jpg" width="99" height="13"></a><a href="index.php?do=ranking&sub=hof&expand=1"></a></td>
				</tr>

<? }

if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "individual";
        ShowIndividualRanking();
    break;
    case "clan";
        ShowClanRanking();
    break;
}
}


if(!function_exists("ShowIndividualRanking")){
function ShowIndividualRanking(){
$res = mssql_query("SELECT TOP 100 Name, Level, KillCount, DeathCount, XP, CID FROM Character WHERE Name != '' ORDER BY Level DESC");
    $count = 0;
    ?>


<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/individualranking.png"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/rankinglist.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/rankinlist_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse; font-size: 9px;" width="417" height="100%">
                                                                <?
                                                                    while($r = mssql_fetch_assoc($res)){
                                                                    $count++;
                                                                    ?>
																	<tr>
																		<td width="45">
																		<p align="center">
																		<?=$count?></td>
																		<td width="88">
																		<p align="center">
																		<b>
																		<span class="guild_name">
																		<a><font color="white"><?=$r['Name']?></a></span></b>
																		</td>
																		<td width="33">
																		<p align="center">
																		<?=$r['Level']?></td>
																		<td width="127">
																		<p align="center">
																		<?=$r['XP']?></td>
																		<td width="114">
																		<p align="center">
																		<span style="font-size: 7pt">
																		<?=$r['KillCount']?>/<?=$r['DeathCount']?>
																	  </span></td>
																	</tr> <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }

if(!function_exists("ShowClanRanking")){
function ShowClanRanking()
{
$res = mssql_query("SELECT TOP 100 Name, Point, Wins, CLID, Losses FROM Clan WHERE Name != '' ORDER BY Point DESC");
	$rank = 0;
    ?>
<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/clanranking.png" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/clanranking_list.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/clanranking_list_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse; font-size: 9px;" width="417" height="100%">
																	<? $rank = 0; ?>
                                                                    <? while($r = mssql_fetch_assoc($res)){   ?>

                                                                    <tr>
																		<td width="45">
																		<p align="center">
																		<?=++$rank?></td>
																		<td width="90">
																		<p align="center">
																		<b><a href="index.php?do=claninfo&id=<?=$r['CLID']?>"><font color="white"><?=htmlentities($r['Name'], ENT_QUOTES)?></b></td>
																		<td width="76">
																		<p align="center">
																		<? $res2 = mssql_query("SELECT * FROM Character WHERE CID = '".$r['MasterCID']."'");
                                                                            $c = mssql_fetch_assoc($res2);
                                                                            echo $c['Name'];
                                                                        ?></td>
																		<td width="71">
																		<p align="center">
																		<?=$r['Wins']?>/<?=$r['Losses']?></td>
																		<td width="40">
																		<p align="center">
																		<?
																			$matchTotal = $r['Wins'] + $r['Losses'] + $r['Draws'];
																			if ($matchTotal > 0)
																			{
																				echo(round($r['Wins'] / $matchTotal * 100));
																			}
																			else
																			{
																				echo(0);
																			}
																		?>%</td>
																		<td width="83">
																		<p align="center">
																		<?=$r['Point']?></td>
																	</tr>  <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }





?>