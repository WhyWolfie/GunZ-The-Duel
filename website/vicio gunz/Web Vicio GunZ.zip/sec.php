<? 
/////////////////////////////
function writeToLogFile($msg)
{
	$today = date("Y_m_d"); 
	$logfile = "logs/".$today."_Log_Sql_Injection.txt"; 
	$dir = '';
	$saveLocation=$logfile;
	$fp = @fopen( $saveLocation,"r");
	$Data = @fread($fp, 800000);

	if (!$handle = @fopen($saveLocation, "w+b"))
	{
		echo "error";
		exit;
	}
	else
	{
		if(@fwrite($handle,"$msg\r\n SQL Injection detected\r\n$Data")===FALSE) 
		{
			echo "geen error";
			exit;
		}
		@fclose($handle);
	}
}

function anti_injection($value)
{
        $value = preg_replace(sql_regcase("/(from|select|union|exec|varchar|0x|cast|update|set|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
        return( $value );
}


function valida($campos)
{
	foreach($campos as $c)
	{
		if(empty($c))
		{ 
			echo "<br>SQL Inject Detectado! Um log foi gravado e enviado ao administrador.<br />"; 
			$time = date("M j G:i:s Y"); 
			$ip = getenv('REMOTE_ADDR');
			$userAgent = getenv('HTTP_USER_AGENT');
			$referrer = getenv('HTTP_REFERER');
			$query = getenv('QUERY_STRING');
			$msg = "IP: " . $ip . " TIME: " . $time . " REFERRER: " . $referrer . " SEARCHSTRING: " . $query;
		
			writeToLogFile($msg);
			return false;
		}
		else
		{
        		return true;
		}
	}
}
?> 
