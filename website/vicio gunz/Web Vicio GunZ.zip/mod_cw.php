<?
$res = mssql_query("SELECT TOP 10 * FROM TotalRanking ORDER BY Rank ASC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/cw.png" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg"><p align="center"><br><?
$busca999 = mssql_query("SELECT TOP 7 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
                                    	<center>
                                    	<strong><?=$item22[0]?></strong></a> <strong><font color=cyan>vs</font></strong> <strong><?=$item22[1]?></strong></a></font>
                                    </center></div>
                                        <center><font color=#00FF00><strong><?=$item22[2]?></strong></font> <font color=blue><strong>/</strong></font> <font color=red><strong><?=$item22[3]?></strong></font></center>
                                    </div>
                                </li>
<center><?
}
?></center></p>
							  </td>
							</tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</table>