<?php
$gunzname = "Knight Gunz";  //Your Server Name

$_MSSQL['Host'] = "MARCOS-JMI7HXDO\SQLEXPRESS";
$_MSSQL['User'] = "sa";
$_MSSQL['Pass'] = "741852963z";
$_MSSQL['DB'] = "GunzDB";

$error1 = "Cant connect to database";
$error2 = "Cant find Database";

$con = mssql_connect($_MSSQL['Host'], $_MSSQL['User'], $_MSSQL['Pass']) or die($error1);
mssql_select_db($_MSSQL['DB']) or die($error2);
?>