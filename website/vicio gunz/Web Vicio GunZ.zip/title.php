<?
switch ($_GET['do']){
        case "":
            $pagetitle = "Inicio";
    break;
        case "register":
            $pagetitle = "Registro";
    break;
        case "downloads":
            $pagetitle = "Download";
    break;
        case "equipe":
            $pagetitle = "Equipe";
    break;
        case "ranking":
            $pagetitle = "Ranking";
    break;
        case "rzitemshop":
            $pagetitle = "Loja Donator";
    break;
        case "evitemshop":
            $pagetitle = "Loja Evento";
    break;
	    case "Chat Online":
            $pagetitle = "Chat Online";
    break;
	       case "gift";
            $pagetitle = "Presentear KG coins";
    break;
	       case "rzgift";
            $pagetitle = "Presentear KG coins";
    break;
	       case "evgift";
            $pagetitle = "Presentear EV Coins";
    break;
        case "rzadditem";
            $pagetitle = "Adicionar KG Shop Item";
    break;
        case "evadditem";
            $pagetitle = "Adicionar Ev Shop Item";
    break;
        case "userpanel";
            $pagetitle = "Painel do Usuario";
    break;
        case "login";
            $pagetitle = "Login";
    break;
        case "emblemas";
            $pagetitle = "Clam Emblem";
    break;
        case "muteuser";
            $pagetitle = "Mutar usuario";
    break;
        case "ipbanuser";
            $pagetitle = "Banir ip Usuario";
        case "tindex";
            $pagetitle = "User Painel";
        case "regras";
            $pagetitle = "Player Painel";

}

//

switch ($_GET['sub']){
        case "individual":
            $pagetitle = "Player Ranking";
    break;
        case "clan":
            $pagetitle = "Clan Ranking";
    break;
        case "color":
            $pagetitle = "Name Color";
    break;
        case "ev_coins";
            $pagetitle = "Trocar Pontos";
    break;
        case "details";
            $pagetitle = "Detalis";
    break;
        case "buyitem";
            $pagetitle = "Comprar item";
    break;
        case "announcement";
            $pagetitle = "An�ncios";
    break;
        case "update";
            $pagetitle = "Update";
    break;

}

//

switch ($_GET['action']){
        case "resetpwd":
            $pagetitle = "Reset Password";
    break;

}

//

switch ($_GET['act']){
        case "editinfo";
            $pagetitle = "Editar Conta";
    break;


}
?>