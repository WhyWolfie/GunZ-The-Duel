<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("MARCOS-JMI7HXDO\SQLEXPRESS","sa","741852963");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'DEDICADO\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = '741852963z';
$DB = 'GunzDB';
?>