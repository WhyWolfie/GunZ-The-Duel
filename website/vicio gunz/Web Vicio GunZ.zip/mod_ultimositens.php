<? include 'anti_sql.php'; ?>
<? include 'inject.php'; ?>
<?
if(!function_exists("ListLatestItens")){
function ListLatestItens(){


    $res = mssql_query("SELECT TOP 4 * FROM RZCashShop WHERE Opened = '1'");

    ?>
    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="11">&nbsp;</td>
											<td width="440" colspan="2">
											<img border="0" src="images/inf/ListAllItems.png"></td>
											<td width="30">&nbsp;</td>
										</tr>

										<tr>
											
										</tr>

											<td width="12" colspan="2"></td>
										</tr>


										<tr>
											<td width="449" colspan="2">&nbsp;
											</td>
										</tr>

										<tr>
                                                                                <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 2) {
                                                $count = 1;
                                                echo "
                                                    </tr><tr>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
											        </tr><tr>";
                                                ?>
                                                <td width="208">

											<table border="0" style="border-collapse: collapse" width="102%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="106" valign="top">
													<font color="#B452CD"><b><?=$item['Name']?></b></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Tipo: Item KG <?=$item['Tipo']?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Masculino";
                                                    break;
                                                    case "1";
                                                    $sex = "Feminino";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													N�vel: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Pre�o: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="106">
													<p align="center">
													<a href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="47" height="19"></a></td>
												</tr>
												<tr>
													<td width="106">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="106">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>
                                                <?
                                            }else{
                                                ?>
                                                <td width="208">
                                                											<table border="0" style="border-collapse: collapse" width="100%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="106" valign="top">
													<font color="#B452CD"><b><?=$item['Name']?></b></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Tipo: Item KG <?=$item['Tipo']?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Masculino";
                                                    break;
                                                    case "1";
                                                    $sex = "Feminino";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													N�vel: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Pre�o: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="110">
													<p align="center">
													<a href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="47" height="19"></a></td>
												</tr>
												<tr>
													<td width="110">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="110">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>                                                <?
                                                 $count++;
                                            }
                                        }   ?>
											<td width="30">
											&nbsp;<p>&nbsp;</p>
											<p>&nbsp;</p>
											<p></td>
										</tr>

										<tr>
											<td width="445" colspan="2">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
       <?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "";
        ListLatestItens();
    break;
}
}

?>