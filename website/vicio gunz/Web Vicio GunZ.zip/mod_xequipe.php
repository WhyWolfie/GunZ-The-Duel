<?php
include 'antisql.php';
include 'anti_inject.php';
include 'anti_injectx.php';
include "banned.php";
include "bannedip.php";
include "banneduser.php";
include 'inject.php';
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
<span><h3>
Knight GunZ - Informa��es
</span></h3>

<br>
<span><h3>
Contatos e Redes sociais:
</span></h3>

<p><a href="" target="_blank"><img src="icones/orkut.png" width="30" height="30"></a> <a href="http://twitter.com/#!/KnightGunzv2" target="_blank"><img src="icones/twitter.png" width="30" height="30"></a> </a> 
</a> <a href="" target="_blank"><img src="icones/facebook.png" width="30" height="30"></a></a>
</a> <a href="http://www.knightgunz.com/forum" target="_blank"><img src="icones/ipboard.png" width="30" height="30"></a> </a> </p>
<br>
<span><h3>
Knight GunZ - Suporte Online
</span></h3>
Suporte via Emails:
<br><a href="index.php?do=suporte"><u>Clique aqui!</u></a><br>
<br>
<span><h3>
Knight GunZ - Equipe
</span></h3>
Conhe�a nossa Equipe:
<br><a href="index.php?do=equipe"><u>Clique aqui!</u></a><br>

<br>
<span><h3>
F�rum Online
</span></h3>
Se voc� tem alguma d�vida, opini�o,<br> sugest�o, cr�tica, utilize nosso f�rum:
<br><a href="/forum"><u>Clique aqui!</u></a><br>



</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

