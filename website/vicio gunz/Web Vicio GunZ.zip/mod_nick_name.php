<? include "inject.php" ?>
<script>
function click() {
if (event.button==2||event.button==3) {
oncontextmenu='return false';
}
}
document.onmousedown=click
document.oncontextmenu = new Function("return false;")
</script> 
<?
if ($_SESSION['AID'] == ""){
    re_dir("Index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
</head>

	
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div align="center">
<?
//Mudan�a de NickName By SayntPark ;D

$login22 = antisql($_SESSION['UserID']);

$etapa = antisql($_GET['etapa']);

$aid22 = antisql($_SESSION['AID']);

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
echo "Voc� n�o tem personagens";
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?do=nick_name&etapa=1">
Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>

<input type="text" id="nick_new" value="Novo Nick" class="log_field" size="16" name="nick_new" value="" maxlength="12"><br><br>

<input type="submit" name="mudar" value="Trocar nick!" />
</form>
<br><br>

<font color=lime>Aten��o ir� ser cobrado  25 KG Coins pelo servi�o.</font>

<?
}

if($etapa == 1)
{

$cid22 = antisql($_POST['cid22']);

$nicknew = antisql($_POST['nick_new']);

$query22 = mssql_query("SELECT CID FROM Character WHERE Name = '$nicknew'");

if( mssql_num_rows($query22) < 1 )
{

$buscanome = "SELECT RzCoins FROM Login WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 25) 
{
	echo "Desculpe, nao foi possivel realizar sua compra.<br>";
	echo "Voce nao tem Coins sufuciente.<br>";
	echo "Adquira mais coins e volte novamente!<br>";
        echo "Obrigado.<br>";
?>
<a href="?do=nick_name">Voltar</a>
<?
}else{

$pattern = "[^a-zA-Z0-9]";
if(ereg($pattern,$nicknew) == TRUE)
{
die('Caracters n�o permitidos');
}

$query1 = mssql_query("UPDATE Character SET Name = '$nicknew' WHERE CID = '$cid22'");
$query2 = mssql_query("UPDATE Login SET RzCoins=RzCoins -25 WHERE UserID='$login22'");

echo "Obrigado, seu nick name ja foi atualizado. Caso esteja no jogo, relogue.";

}

}else{
echo "Desculpe, Este NickName ja est� em uso. Por favor escolha outro.";
}

}
?>
											  </div>
											  <div align="center"></div>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	