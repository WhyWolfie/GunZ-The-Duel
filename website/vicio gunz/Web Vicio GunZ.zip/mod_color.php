<?
//Name color By:SayntPark '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
Voc� ir� gastar <font color=red>35</font> KG Coins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="4">Roxo</option>
<option value="5">Laranja</option>
<option value="6">Amarelo</option>
<option value="7">Verde �gua</option>
<option value="8">Cinza</option>
<option value="9">Azul Escuro</option>
<option value="13">Rosa</option>
<option value="14">Vermelho</option>
<option value="16">Lilas</option>
<option value="17">Azul</option>
</select>
<br><br>
<font color="#8968CD"> Roxo</font><br><br>
<font color="#FF6347"> Laranja</font><br><br>
<font color="#FFFF00"> Amarelo</font><br><br>
<font color="#00CED1"> Verde �gua</font><br><br>
<font color="#8B8989"> Cinza</font><br><br>
<font color="#00008B"> Azul Escuro</font><br><br>
<font color="#FF00FF"> Rosa</font><br><br>
<font color="red"> Vermelho</font><br><br>
<font color="#8968CD"> Lilas</font><br><br>
<font color="#1E90FF"> Azul</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
<br>
<span style="color:#CD2990; background: transparent url(http://tinyurl.com/outgum)"><b>Name color - KnightGunZ</b></span></a><br><br>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Voc� comprou Admin com sucesso!!  Brinks HAHA";
die ();  

}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 35) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  KG Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -35 where AID='$aid22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Acesse site.aulagunz.com.br";
}
}
}


$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>