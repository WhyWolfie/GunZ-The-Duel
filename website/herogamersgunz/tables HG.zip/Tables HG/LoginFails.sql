USE [zzz]
GO

/****** Object:  Table [dbo].[LoginFails]    Script Date: 11/10/2017 19:22:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[LoginFails](
	[IP] [varchar](20) NULL,
	[UserID] [varchar](50) NULL,
	[Time] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

