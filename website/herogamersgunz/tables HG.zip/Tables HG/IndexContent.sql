USE [zzz]
GO

/****** Object:  Table [dbo].[IndexContent]    Script Date: 11/10/2017 19:25:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IndexContent](
	[Type] [tinyint] NULL,
	[ICID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [varchar](50) NULL,
	[User] [varchar](50) NULL,
	[Date] [datetime] NULL,
	[Text] [varchar](max) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

