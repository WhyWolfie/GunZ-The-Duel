USE [Gunz]
GO

/****** Object:  Table [dbo].[AccountBan]    Script Date: 11/10/2017 19:20:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[AccountBan](
	[AID] [int] NULL,
	[UserID] [varchar](50) NULL,
	[IP] [varchar](26) NULL,
	[BanReason] [varchar](max) NULL,
	[BanDate] [varchar](50) NULL,
	[Opened] [varchar](50) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

