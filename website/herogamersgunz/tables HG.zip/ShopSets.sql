USE [zzz]
GO

/****** Object:  Table [dbo].[ShopSets]    Script Date: 11/10/2017 19:23:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ShopSets](
	[SSID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](max) NULL,
	[Level] [int] NULL,
	[Price] [int] NULL,
	[Sex] [varchar](50) NULL,
	[ImageURL] [varchar](max) NULL,
	[Selled] [int] NULL,
	[HeadItemID] [int] NULL,
	[ChestItemID] [int] NULL,
	[HandItemID] [int] NULL,
	[LegItemID] [int] NULL,
	[FeetItemID] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

