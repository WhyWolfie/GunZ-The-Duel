USE [zzz]
GO

/****** Object:  Table [dbo].[ShopItems]    Script Date: 11/10/2017 19:23:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ShopItems](
	[CSSID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](64) NULL,
	[Description] [varchar](1024) NULL,
	[NewItemOrder] [tinyint] NULL,
	[ResSex] [tinyint] NULL,
	[ResLevel] [int] NULL,
	[Weight] [int] NULL,
	[Opened] [tinyint] NULL,
	[RegDate] [datetime] NULL,
	[RentType] [tinyint] NULL,
	[Slot] [varchar](30) NULL,
	[Damage] [int] NULL,
	[AP] [int] NULL,
	[FR] [int] NULL,
	[Delay] [int] NULL,
	[HP] [int] NULL,
	[PR] [int] NULL,
	[Magazine] [int] NULL,
	[MaxWeight] [int] NULL,
	[CR] [int] NULL,
	[MaxBullet] [int] NULL,
	[ReloadTime] [int] NULL,
	[LR] [int] NULL,
	[Control] [int] NULL,
	[Duration] [int] NULL,
	[Selled] [int] NULL,
	[ImageURL] [varchar](64) NULL,
	[BodyPart] [int] NULL,
	[Sex] [int] NULL,
	[Level] [int] NULL,
	[Price] [int] NULL,
	[zItemID] [int] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

