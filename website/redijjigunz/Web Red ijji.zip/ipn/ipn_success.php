<?php
mssql_connect("PROZOR\SQLEXPRESS","sa","sasa");
mssql_select_db("LOLZ");

if(isset($paypal['business']))
{
$account = $paypal['firstname'];
$item = $paypal['lastname'];
$split = explode(':',$item);
$test = $split[0];
$amount = $split[1];

mssql_query("UPDATE Login SET Coins='Coins + $amount' WHERE UserID='$account'");
}
else
{
	die('This page is not directly accessible');
}
?>