<p><strong><font size="6">Not Found</font></strong><br>
  <br>
The requested URL was not found on this server.<br>
</p>
<hr>
<p> 
  <em>You are Banned from My GunZ. By X-Weaver Staff</em></p>
