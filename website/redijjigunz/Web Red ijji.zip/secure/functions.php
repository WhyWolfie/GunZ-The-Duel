<?
function mssql_query_logged($query)
{

    //$f = fopen("userlogs/querylog.txt", "a+");
    //fprintf($f, "%s (sp_%s.php) - [AID=%s] %s [%s] - %s\r\n", $_SERVER[PHP_SELF],$_GET['sp'], $_SESSION['AID'],  date("d-m-y - H:i:S"), $_SERVER['REMOTE_ADDR'], $query);
    //fclose($f);
        
    return mssql_query($query);
}
if(!function_exists("re_dir") )
{
function re_dir($url)
{
    echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

function clean($value)
{
        $check = $value;

        $search = array('chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(',
        'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20',
        'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=',
        'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(',
        'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm',
        'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(',
        'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(',
        'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall',
        'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20',
        'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20',
        '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20',
        'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow',
        'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id',
        '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python',
        'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20',
        '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml',
        'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe',
        'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd',
        'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history',
        'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20',
        'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con',
        '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from',
        'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql=');

        $value = str_replace($search, '', $value);
        $value = preg_replace(sql_regcase("/(select|from|insert|delete|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables|name|password|login|account|login|clan|character|set|where|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
        $value = stripcslashes($value);
        $value = htmlspecialchars($value); 

        if( $check != $value )
        {
            $logf = fopen("userlogs/hacklogs.txt", "a+");
            fprintf($logf, "Date: %s IP: %s Code: %s, Fixed: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
alertbox("O.o","index.php");
        }

        return( $value );
}
function errorbox($error) {
    return "<tr>
<td width='434' colspan='2' align='center'>
					    <table width='250' height='45' border='0' align='center' class='errorbox'>
                          <tr>
                            <td align='left' class='estilo6' valign='top'>MESSAGE FROM X-WEAVER!</td>
                          </tr>
                          <tr>
                            <td align='center' class='estilo1'>$error</td>
                          </tr>
                        </table><br></td>
</tr>";
}
if(!function_exists("alertbox")){
function alertbox($text, $url)
{
    echo "<script>alert('$text');document.location = '$url'</script>";
    die("Javascript disabled");
} }

function SetTitle($title)
{
    $_SESSION[PageTitle] = $title;
}

function GetClanMasterByCLID($clid)
{
    $clanid = clean($clid);

    $res2 = mssql_query("SELECT ch.Name FROM Character(nolock) ch INNER JOIN Clan(nolock) cl ON ch.CID = cl.MasterCID WHERE cl.CLID = '$clanid'");

    $char = mssql_fetch_row($res2);


    return $char[0];
}

function GetCharNameByCID($cid)
{
    $ncid = clean($cid);
    $a = mssql_fetch_assoc(mssql_query("SELECT Name FROM Character(nolock) WHERE CID = '$ncid'"));
    return $a[Name];
}


function CheckIfExistClan($aid){
    $aid = clean($aid);
    $a = mssql_query("SELECT * FROM Character(nolock) WHERE AID = '$aid'");
    if( mssql_num_rows($a) > 0 )
    {
        while($char = mssql_fetch_assoc($a))
        {
            if(mssql_num_rows(mssql_query("SELECT * FROM Clan(nolock) WHERE MasterCID = '".$char[CID]."'")) == 1)
            {
                return true;
                break;
            }
        }
    }
    return false;
}


function GetClanPercent($Wins, $Losses)
{
    $total = $Wins + $Losses;

    return ($total == 0) ? "0%" : round((100 * $Wins) / $total, 2) . "%";
}

function FormatCharName($cid)
{
    $ncid = clean($cid);
    $res = mssql_fetch_row(mssql_query("SELECT ac.UGradeID, ch.Name From Character(nolock) ch INNER JOIN Account ac ON ac.AID = ch.AID WHERE ch.CID = '$ncid'"));

    $name = $res[1];

    switch($res[0])
    {
        case 255:
            return "<font color='#FF0000'>$name</font>";
        break;
        case 254:
            return "<font color='#00FF00'>$name</font>";
        break;
        case 253:
            return "<font color='#333333'>$name</font>";
        break;
        default:
            return $name;
        break;
    }
}

function GetKDRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

function SetURL($url)
{
    $_SESSION[URL] = $url;
}

function GetSexByID($sid)
{
    switch($sid)
    {
        case 0:
            return "Hombre";
        break;
        case 1:
            return "Mujer";
        break;
        case 2:
            return "All";
        break;
    }
}

function GetTypeByID($tid)
{
    switch($cat)
    {
        case 3:
            $type = "Armor";
        break;
        case 2:
            $img = "content_title_shop_meleewea.jpg";
            $type = "Melee";
        break;
        case 1:
            $img = "content_title_shop_rangedwe.jpg";
            $type = "Ranged";
        break;
        case 5:
            $img = "content_title_shop_speciali.jpg";
            $type = "Special";
        break;
        default:
            $img = "content_title_shop_armor.jpg";
            $type = "Armor";
        break;
    }

    return $type;
}


function UploadFTPFile($filename, $host, $user, $pass, $remotefile)
{
    $ftp = ftp_connect($host, 21, 30);

    if(!ftp_login($ftp, $user, $pass))
        return false;

    if(!ftp_pasv($ftp, false))
        return false;

    //@ftp_delete($ftp, $remotefile);

    if(!ftp_put($ftp, $remotefile, $filename, FTP_BINARY))
        return false;
    else
        ftp_close($ftp);
        return true;
}

function GetImageByType($ntype)
{
    if(substr($ntype, 0, 6) == "[NEWS]")
    {
        return "btn_news.jpg";
    }else{
        return "btn_update.jpg";
    }
}
function DeleteType($ptitle)
{
    if( str_replace(']', '', $ptitle) != $ptitle )
    {
        $titulo = explode(']', $ptitle);
        if (strlen($titulo[1]) <= 25)
        {
            return $titulo[1];
        }
        else
        {
            $titulon = substr( $titulo[1], 0, 25 );
            return $titulon."...";
        }
    }
    else
    {
        if (strlen($ptitle) <= 25)
        {
            return $ptitle;
        }
        else
        {
            $titulon = substr( $ptitle, 0, 25 );
            return $titulon."...";
        }
    }
}

function get_file_extension($filename)
{
    $path_info = pathinfo($filename);
    return $path_info['extension'];
}  
function textcolor($input_text){
    $output_text = 
        str_ireplace(
            array(
                "^0", //Grey
                "^1", //Red
                "^2", //Green
                "^3", //Blue
                "^4", //Yellow
                "^5", //Dark Red
                "^6", //Dark Green
                "^7", //Dark Blue
                "^8", //Dark Yellow
                "^9", //White
            ),
            array(
                "<font color='#808080'>", //Grey
                "<font color='#FF0000'>", //Red
                "<font color='#00FF00'>", //Green
                "<font color='#0000FF'>", //Blue
                "<font color='#FFFF00'>", //Yellow
                "<font color='#800000'>", //Dark Red
                "<font color='#008000'>", //Dark Green
                "<font color='#000080'>", //Dark Blue
                "<font color='#808000'>", //Dark Yellow
                "<font color='#FFFFFF'>", //White
            ),
            "$input_text</font>"
        );
    return print($output_text);
}  
function Porcentagem($vitorias, $derrotas)
{
    $total = $vitorias + $derrotas;

    return ($total == 0) ? "100%" : round((100 * $vitorias) / $total, 2) . "%";
}

function NomeCharCID($cid)
{
    $ncid = clean($cid);
    $a = mssql_fetch_assoc(mssql_query("SELECT * FROM Character WHERE CID = '$ncid'"));
    return $a[Name];
}  

?>