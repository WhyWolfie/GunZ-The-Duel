<?php
ob_start("ParseTitle"); 
function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("/Title/", $_SESSION[PageTitle], $content);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("/Title/", "ijji - Where Gamers Unite! - Index", $content);
        return $r;
    }
}
include "secure/functions.php";
include "secure/config.php";
include "secure/shield.php";
include "secure/ipban.php";
include "secure/ban.php";
?> 
<html>
<head>
<title>/Title/</title>
<link rel="shortcut icon" href="http://images.ijjimax.com/v5/common/favicon.ico" type="image/x-icon"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--[if lt IE 7]>
<script defer type="text/javascript" src="script/pngfix.js"></script>
<![endif]-->
<script type="text/javascript" src="secure/functions.js"></script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
</head>
<style type="text/css">
@import "style.css";
</style>
<!-- Announcement Part -->
<body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" onLoad="MM_preloadImages('img/topbar_navi02_on.gif','img/topbar_navi04_on.gif','img/topbar_navi05_on.gif','img/topbar_navi08_on.gif','img/topbar_navi10_on.gif')">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr valign="top">
    <td><table width="100%" height="191" border="0" align="center" cellpadding="0" cellspacing="0" style="background-repeat: repeat-x; background-image:url(img/top_bar.jpg); background-position:top;" >
  <tr>
    <td height="13" align="center" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td height="13" align="center" valign="center"><table width="771" height="45" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="243" valign="bottom" align="left"><a href="http://www.ragezone.com"><img src="img/logotype.jpg" width="200" height="40" border="0"></a></td>
        <td width="18" valign="bottom" align="right"></td>
        <td width="526" align="right"><table width="500" height="20" border="0" cellpadding="0" cellspacing="0" background="img/top_select_bar.jpg" style="background-repeat:no-repeat; background-position:center;">
          <tr>
            <td align="right"><a href="index.php?gunz=coins"><img src="img/blank.gif" width="70" height="20" border="0"></a><a href="index.php?gunz=register"><img src="img/blank.gif" width="102" height="20" border="0"></a><a href="index.php?gunz=myprofile"><img src="img/blank.gif" width="72" height="20" border="0"></a><a href="index.php?gunz=staff"><img src="img/blank.gif" width="67" height="20" border="0"></a><a href="index.php?gunz=recoverplayer"><img src="img/blank.gif" width="107" height="20" border="0"></a></td>
          </tr>
        </table>          </td>
      </tr>
    </table></td>
  </tr>
  <!-- //Announcement Part -->
  <!-- Top Banner part -->
  <tr>
    <td height="13" align="center" valign="bottom">
		<table width="780" height="41" border="0" align="center" cellpadding="0" cellspacing="0" style="background-image:url(img/bg_topnavbar.gif); background-position:center; background-repeat:no-repeat;">
      <tr>
        <td width="104" align="right" valign="bottom"><a href="index.php"><img src="img/topbar_navi00.gif" width="96" height="31" border="0"></a></td>
        <td width="10"></td>
        <td width="663" valign="bottom"><table width="200" border="0" align="left" cellpadding="0" cellspacing="0">
          <tr>
            <td><a href="index.php?gunz=rules" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('guide','','img/topbar_navi02_on.gif',1)"><img src="img/topbar_navi02.gif" alt="GameGuide" name="guide" width="86" height="41" border="0"></a><a href="http://forum.ragezone.com" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Forum','','img/topbar_navi04_on.gif',1)"><img src="img/topbar_navi04.gif" alt="Community" name="Forum" width="61" height="41" border="0"></a><a href="index.php?gunz=playerank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Ranking','','img/topbar_navi05_on.gif',1)"><img src="img/topbar_navi05.gif" alt="Ranking" name="Ranking" width="71" height="41" border="0"></a><a href="index.php?gunz=shop" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Shop','','img/topbar_navi08_on.gif',1)"><img src="img/topbar_navi08.gif" alt="ItemShop" name="Shop" width="79" height="41" border="0"></a><a href="http://gunzwiki.wetpaint.com" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Wiki','','img/topbar_navi10_on.gif',1)"><img src="img/topbar_navi10.gif" alt="GunZWiki" name="Wiki" width="75" height="41" border="0"></a></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
<!-- //Top Banner part -->
      <table width="100%" height="400" border="0" cellpadding="0" cellspacing="0" style="background-image:url(img/background00.jpg); background-repeat:repeat-x;">
        <tr valign="top">
          <td><table id="rimg" width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-image:url(img/header/ijji6.jpg); background-repeat:no-repeat; background-position:top center;">
  <tr>
    <td align="center" height="167" valign="bottom"><table width="780" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td align="right"><table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="160"></td>
            <td width="422" align="center" valign="bottom"><? echo @$errorbox ?></td>
            <td valign="top"><table width="190" border="0" align="right" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center">
                  <!-- Admin and GM Panel Zone -->
                  <?php if($_SESSION['UGradeID'] == 255 )
										  { ?>
                  <FORM METHOD="LINK" ACTION="admin/index.php">
                    <INPUT name="submit" TYPE="submit"  class="login2" VALUE="Admin Panel">
                  </FORM>
                  <? } ?>
                  <?php if($_SESSION['UGradeID'] == 254 && 252 )
										  { ?>
                  <FORM METHOD="LINK" ACTION="gmpanel/index.php">
                    <INPUT name="submit2" TYPE="submit"  class="login2" VALUE="GM Panel">
                  </FORM>
                  <? } ?>
                  <!-- //Admin and GM Panel Zone -->
                </td>
              </tr>
              <!-- Event Part -->
              <tr>
                <td align="center"><img src="img/blank.gif" width="190" height="120"></td>
              </tr>
            </table></td>
          </tr>
        </table>
        </td>
      </tr>
    </table></td>
  </tr>
  <!-- //Event Part -->
  
 <!-- Modules Part -->
  <tr>
    <td align="center"><table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><? if($_CONFIG[OfflinePage] == "")
{
if(isset($_GET['gunz']))
{
$do = $_GET['gunz'];
}else{
$do = "index";
}
if(file_exists("gunz/ijji_$do.php"))
{
include "gunz/ijji_$do.php";
{
}
}else{
alertbox("We are working on it...","index.php");
    die();
}
}
?></td>
      </tr>
    </table>
	<!-- //Modules Part -->
	
	<!-- Copyright Zone -->
      <table width="780" height="70" border="0" cellpadding="0" cellspacing="0" background="img/copyright.jpg" style="background-position:center; background-repeat:no-repeat;">
      <tr>
        <td width="160" height="10"></td>
        <td width="620"><table width="500" border="0" cellpadding="1" cellspacing="0">
          <tr>
            <td class="Estilo1">Bla Bla Bla</td>
          </tr>
          <tr>
            <td class="Estilo1">Bla Bla Bla</td>
          </tr>
          <tr>
            <td class="Estilo1">Bla Bla Bla</td>
          </tr>
          <tr>
            <td class="Estilo1">Bla Bla Bla</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" height="15"></td>
  </tr>
</table></td>
  </tr>
</table></td>
  </tr>
</table>
<!-- //Copyright Zone -->
</body>
</html>
<?php
ob_end_flush();
?> 