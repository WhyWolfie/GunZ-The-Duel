<?php
if( !session_start() )
{
    session_start();
}
require "../secure/config.php";
include "functions.php";

$connection = connect();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>:: Delete Clan :: Coded By Kyuma</title>
<style type="text/css">
<!--
body,td,th {
	color: #7E9092; font-family:Arial
}
a {
	color: #FFFFFF; font-family:Arial
}
body {
	background-color: #2A2C2B;
}
input {
    border: 1px solid #A0A0A4;
    color: #000000;
    background: #CCCCCC;
    font-family:Arial;
    font-size: 10pt;
}
-->
</style>
</head>

<body>

<?php

if( $_SESSION['AID'] == "" )
{
    if( isset($_POST['login']) )
    {
        login();
    }
    else
    {

?>
    <center>
    <p><b>FlameGaming GunZ - The Flame Inside You :: Delete Clan :: Coded By Kyuma<b></b></p>
    <form name="login" method="POST" action="index.php">
    <?php showmessage(); ?>
        <table width="30%" border="1" style="border-collapse: collapse" id="login">
            <tr>
                <td colspan="2" align="center"><b>User Login : </b></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td width="40%" align="center">Your User ID : </td>
                <td align="center"><input type="text" name="userid" /></td>
            </tr>
            <tr>
                <td align="center">Your Password : </td>
                <td align="center"><input type="password" name="password" /></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <input type="submit" name="login" value="Login" />
                </td>
            </tr>
        </table>
    </form>
    </center>
<?php
    }
}

if( $_SESSION['AID'] != "" )
{
    if( $_GET['do'] == "logout" )
    {
        logout();
    }

    if(isset($_POST['delete']))
    {
        $clid = clean_sql($_POST['clanid']);
        delete_clan($clid);
    }

    $list = getclanlist();
    $count = count($list);
    if($count == 0)
    {
        if( $_GET['do'] != "deleted" )
        {
            setmessage("Clan Search", "None Of Your Characters Is Clan Master");
        }
        logout();
        redirect("index.php");
        die();
    }
?>
    <center>
    <?php showmessage(); ?>
    <p>Select The Clan You Want To Delete : </p>
    <form method="post" name="delete" action="index.php">
        <select name="clanid">
        <?php
        for($i=0; $i < $count; $i++)
        {
            printf("<option value=\"%s\">Clan: %s - Master: %s</option><br />", $list[$i][1], $list[$i][2], $list[$i][0]);
        }
        ?>
        </select>
        <p><b>Warning : After Clicking Delete Clan, Your Clan Will Be Deleted And Can't Be Recovered Back</b></p>
        <input type="submit" name="delete" value="Delete Your Clan!" />
    </form>
    </center>
        </td>
    </tr>
    </table>
<?php
}
?>

</body>

</html>