<?
SetTitle("ijji - Where Gamers Unite! - Home");
?>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" valign="top"><? include"other/status.php" ?></td>
      </tr>
      <tr>
        <td align="center" height="5"></td>
      </tr>
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="center" valign="top"><table width="415" height="150" border="0" align="center" cellpadding="0" cellspacing="0" background="img/top_news_bg.jpg" style="background-repeat:no-repeat; background-position:center;">
              <tr>
                <td class="estilo1" align="center" valign="bottom"><?
                                                                $res = mssql_query_logged("SELECT TOP 4 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                  <table width="190" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="15"></td>
                    <td width="180" height="18" class="estilo1"><span class="menu"><a href="index.php?gunz=news&sub=announcement&id=<?=$n['ICID']?>">
                      <?=$n['Title']?>
                    </a></span></td>
                  </tr>
                </table>                      <? }?></td>
                <td class="estilo1" align="center" valign="bottom"><?
                                                                $res = mssql_query_logged("SELECT TOP 4 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>                  
                  <table width="190" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="15"></td>
                    <td width="180" height="18" class="estilo1"><span class="menu"><a href="index.php?gunz=news&sub=announcement&id=<?=$n['ICID']?>">
                            <?=$n['Title']?>
                          </a></span></td>
                  </tr>
                </table>                      <? }?></td>
              </tr>
              <tr>
                <td height="10" colspan="2" align="center" valign="bottom" class="estilo1"></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td align="left"><img src="img/mc_tit_prfeatures.gif" width="200" height="28"></td>
          </tr>
          <tr>
            <td align="center" valign="top"><?
$res = mssql_query("SELECT TOP 4 * FROM CashShop WHERE Opened = 1 ORDER BY CSID DESC");
?><table width="415" height="100%" style="border-width: 1px; border-style: solid; border-color:#001340;">
              <tr>
                <? while($item = mssql_fetch_assoc($res)) 
		{
			if ($count == 2) 
			{
				$count = 1;
				echo "</tr>";
		?>
                <td width="449" align="center">
                  <table width="200" border="0">
                    <tr>
                      <td width="68" rowspan="5" valign="top"><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="64" height="64" style="border-width: 1px; border-style: solid; border-color: #000000;"></a></td>
                      <td colspan="2" class="estilo1" align="left"> <b>
                        <a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>">
                        <?=$item['Name']?></a>
                      </b> </td>
                    </tr>
                    <tr>
                      <td width="71" class="estilo1" align="left">Type:</td>
                      <td width="47" class="estilo1" align="left"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Sex:</td>
                      <td class="estilo1" align="left"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Level:</td>
                      <td class="estilo1" align="left"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Price:</td>
                      <td class="estilo1" align="left"><?=$item['CashPrice']?></td>
                    </tr>
                </table></td>
                <? 
			}
			else
			{
            ?>
                <td width="449" height="100" align="center">
                  <table width="200" border="0">
                    <tr>
                      <td width="68" rowspan="5" valign="top"><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="64" height="64" style="border-width: 1px; border-style: solid; border-color: #000000;"></a></td>
                      <td colspan="2" class="estilo1" align="left"><b>
                        <a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>">
                        <?=$item['Name']?></a>
                      </b> </td>
                    </tr>
                    <tr>
                      <td width="71" class="estilo1" align="left">Type:</td>
                      <td width="47" class="estilo1" align="left"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Sex:</td>
                      <td class="estilo1" align="left"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Level:</td>
                      <td class="estilo1" align="left"><?=$item['ResLevel']?></td>
                    </tr>
                    <tr>
                      <td class="estilo1" align="left">Price:</td>
                      <td class="estilo1" align="left"><?=$item['CashPrice']?></td>
                    </tr>
                  </table></td>
                <?
				$count++;
				}
			}   
			?>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="10" align="center"></td>
          </tr>
          <tr>
            <td align="center"><img src="img/mc_controls_pic.gif" width="402" height="187"></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
