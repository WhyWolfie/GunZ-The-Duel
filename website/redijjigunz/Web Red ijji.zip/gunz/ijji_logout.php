<?
SetTitle("ijji - Where Gamers Unite! - Log Out");
if($_SESSION[AID] <> "")
{
    $u = $_SESSION[UserID];

    session_unset();

    if (isset($_COOKIE[session_name()]))
    {
        setcookie(session_name(), '', time()-42000, '/');
    }

    session_destroy();

    unset($_SESSION['UserID']);



alertbox("User, ".clean($u)." logout successfully.","index.php");
    die();
}else{
alertbox("You cant logout, because you aren't logged.","index.php");
    die();
}
?>