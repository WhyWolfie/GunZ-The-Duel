<? SetTitle("ijji - Where Gamers Unite! - Hall Of Fame"); ?>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

//-->
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('img/clanranking_select_on.jpg','img/ministart02.gif','img/playeranking_select_on.jpg')">
<table width="784" height="100%" border="0" align="center">
  <tr valign="top">
    <td width="160" align="center" valign="top" bgcolor="#232124"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
            <tr>
              <td align="center" height="58"></td>
            </tr>
          </table>
            <a href="index.php?gunz=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('START','','img/ministart02.gif',1)"><img src="img/ministart01.gif" alt="Download" name="START" border="0"  style=" float:none; margin-top:5; margin-left:-155; position:absolute;"></a></td>
      </tr>
      <tr>
        <td align="center" background="img/bg_content_wm.gif" bgcolor="#004f86" style="background-repeat:no-repeat; background-position:top;"><table width="160" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="top" height="2"></td>
          </tr>
          <tr>
            <td align="center" valign="top" bgcolor="#232124" ><img src="img/ltit_ranking.gif" width="150" height="42">
                <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" background="img/lbox01_t.gif" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.gif" bgcolor="#232124" style="background-repeat:no-repeat;"><a href="index.php?gunz=clanrank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ClanRank','','img/clanranking_select_on.jpg',1)"><img name="ClanRank" border="0" src="img/clanranking_select.jpg" alt="ClanRank"></a><br>
                        <a href="index.php?gunz=playerank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('PlayerRank','','img/playeranking_select_on.jpg',1)"><img name="PlayerRank" border="0" src="img/playeranking_select.jpg" alt="PlayerRank"></a><br>
                        <a href="index.php?gunz=hallofame"><img src="img/hallfame_select_on.jpg" width="130" height="26" border="0"></a> </td>
                  </tr>
                  <tr>
                    <td height="6" align="center" background="img/lbox01_b.gif" bgcolor="#232124" style="background-repeat:no-repeat; background-position:bottom"></td>
                  </tr>
              </table></td>
          </tr>
        </table></td>
      </tr>
    </table>	</td>
    <td align="center" valign="top" bgcolor="#FFFFFF" class="Estilo1" width="620" height="100%">
<? include"other/hallfame.php" ?></td>
  </tr>
</table>
