<? SetTitle("ijji - Where Gamers Unite! - Clan Home"); ?>
<?
$cinfo = clean($_GET['info']);
$query = mssql_query("SELECT * FROM Clan WHERE Name = '$cinfo' AND DeleteFlag=0");
$clans = mssql_fetch_object($query);
$clid = $clans->CLID;
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>CLAN HOME</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25">
				  <table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center"><table width="390" border="0" align="center" class="login2">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                               Clan, <?=$clans->Name?> 
                              Information</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="390" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="390" border="0" align="center">
                                  <tr>
                                    <td height="18" colspan="2" align="center" class="estilo1"><img src="<?=($clan->EmblemUrl == "") ? "./clan/emblem/no_emblem.png" : $clan->EmblemUrl?>" width="64" height="64"></td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Rank:</td>
                                    <td align="left" class="estilo1"><?=$clans->Ranking?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Points:</td>
                                    <td align="left" class="estilo1"><?=$clans->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Win:</td>
                                    <td align="left" class="estilo1"><?=$clans->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Losses:</td>
                                    <td align="left" class="estilo1"><?=$clans->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Draw:</td>
                                    <td align="left" class="estilo1"><?=$clans->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ratio:</td>
                                    <td align="left" class="estilo1"><?=Porcentagem($clans->Wins, $clan->Losses)?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Created:</td>
                                    <td align="left" class="estilo1"><?=$clans->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Members:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="390" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td align="center" class="estilo1">Character</td>
                                    <td align="center" class="estilo1">Rank</td>
                                    <td align="center" class="estilo1">Joined</td>
                                    <td align="center" class="estilo1">Points</td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");
while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><?=FormatCharName($char->CID)?></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                            </table></td>
                          </tr>
</table></td>
                    </tr>
                  </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
