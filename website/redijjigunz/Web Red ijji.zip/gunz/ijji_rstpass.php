<?
SetTitle("ijji - Where Gamers Unite! - New Password");
if ($_SESSION['AID'] <> ""){
    alertbox("Logout first!","index.php");
    die();
	}
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#2f5374" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" bgcolor="#232124" class="estilo6"><strong>NEW PASSWORD </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#232124" class="Estilo1"><table width="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#151515" class="login4">
  <tr>
    <td width="360" height="5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo1"><?
if($_POST['submit'] == ""){
?>
						<form method="POST" action="index.php?gunz=rstpass" name="newpass">
						<table width="360" border="0" cellpadding="1" cellspacing="0">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Username:</td>
                            <td class="Estilo1" align="right"><input name="userid" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Step 2" name="submit" class="Login"></td>
                          </tr>
                        </table>
						</form>  <?
            }elseif ($_POST['submit'] == "Step 2"){
                $userid = clean($_POST['userid']);
                if($userid == ""){
                    alertbox("Type your Username","index.php?rg=resetpass");
                }
                $res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");
                if (mssql_num_rows($res) == 0){
                    alertbox("Username ".ucfirst($userid)." doesn't exist.","index.php?rg=rstpass");
                }
                $_SESSION['ResetPwdUser'] = $userid;
                $info = mssql_fetch_assoc($res);
                ?>
				<form method="POST" action="index.php?gunz=rstpass" name="newpass">
                <table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
					     <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                  </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">E-Mail:</td>
                            <td class="Estilo1" align="right"><input name="email" type="text" class="Login" size="20" maxlength="40"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Question:</td>
                            <td class="Estilo1" align="right"><b>
                              <?=$info['SQ']?>
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Answer:</td>
                            <td class="Estilo1" align="right"><input name="sa" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Step 3" name="submit" class="Login"></td>
                          </tr>
                  </table>
				</form>
					 <?
                   }elseif ($_POST['submit'] == "Step 3"){
                        $sa = clean($_POST['sa']);
                        $email = clean($_POST['email']);
                        $res = mssql_query("SELECT * FROM Account WHERE Email = '$email' AND SA = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
														<form method="POST" action="index.php?gunz=rstpass" name="newpass">
<table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
						    <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                            </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">New Password:</td>
                            <td class="Estilo1" align="right"><input name="pw1" type="password" class="login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Retype:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="pw2" type="password" class="login" size="20" maxlength="20">
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Finish" name="submit" class="Login"></td>
                          </tr>
                        </table>
														</form>
														<?
                            }else{
                                alertbox("Incorrect E-Mail or Secret Answer.","index.php?gunz=rstpass");
                            }
                    }elseif ($_POST['submit'] == "Finish"){
                        if($_POST['pw1'] == $_POST['pw2']){
                            $pw1 = clean($_POST['pw1']);
                            mssql_query("UPDATE Login SET Password = '$pw1' WHERE UserID = '" . clean($_SESSION['ResetPwdUser']) . "'");
                            alertbox("Your password has been changed!","index.php");
                        }else{
                            alertbox("Fill in the blanks.","index.php?gunz=rstpass");
                        }
                    }
							?></td>
  </tr>
  <tr>
    <td height="5"></td>
  </tr>
</table>
</td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
