<? SetTitle("ijji - Where Gamers Unite! - Item Shop");
?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>

<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('img/shop_select_ranged_on.gif','img/shop_select_melee_on.gif','img/shop_select_armor_on.gif','img/shop_select_special_on.gif','img/ministart02.gif','img/eventshop_select_on.jpg','img/myitems_select_on.jpg')">
<table width="784" height="100%" border="0" align="center">
  <tr valign="top">
    <td width="160" align="center" valign="top" bgcolor="#232124"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
            <tr>
              <td align="center" height="58"></td>
            </tr>
          </table>
            <a href="index.php?gunz=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('START1','','img/ministart02.gif',1)"><img src="img/ministart01.gif" alt="Download" name="START1" border="0" id="START1"  style=" float:none; margin-top:5; margin-left:-155; position:absolute;"></a></td>
      </tr>
      <tr>
        <td align="center" background="img/bg_content_wm.gif" bgcolor="#004f86" style="background-repeat:no-repeat; background-position:top;"><table width="160" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="top" height="2"></td>
          </tr>
          <tr>
            <td align="center" valign="top" bgcolor="#232124"><a href="index.php?gunz=shop"><img src="img/ltit_itemshop.gif" width="150" height="42" border="0"></a>
                <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center" background="img/lbox01_t.gif" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.gif" style="background-repeat:no-repeat;"><a href="index.php?gunz=eshop&sub=listallitems&type=2" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('EventShop','','img/eventshop_select_on.jpg',1)"><img name="EventShop" border="0" src="img/eventshop_select.jpg" alt="EventShop"></a><br>
                        <a href="index.php?gunz=itemshop&sub=listallitems&type=2"><img src="img/shop_select_on.jpg" width="130" height="26" border="0"></a><br>
                        <a href="index.php?gunz=myitems" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('MyItems','','img/myitems_select_on.jpg',1)"><img name="MyItems" border="0" src="img/myitems_select.jpg" alt="MyItems"></a></td>
                  </tr>
                  <tr>
                    <td align="center" background="img/lbox01_b.gif" style="background-repeat:no-repeat; background-position:bottom" height="6"></td>
                  </tr>
                </table>
                <br>
                <img src="img/warning_banner.gif" width="140" height="91"></td>
          </tr>
          <tr>
            <td height="10" align="center" valign="top" bgcolor="#232124"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="center" valign="top" bgcolor="#FFFFFF" class="Estilo1" width="620" height="100%"><table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left"><img src="img/tit_itemcategory.gif" width="150" height="23"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr style="background-image:url(img/shop_select_topbg.png); background-repeat:repeat-x; background-position:bottom;">
            <td align="center"><a href="index.php?gunz=itemshop&sub=listallitems&type=2" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Ranged','','img/shop_select_ranged_on.gif',1)"><img name="Ranged" border="0" src="img/shop_select_ranged.gif" alt="Ranged"></a></td>
            <td align="center"><a href="index.php?gunz=itemshop&sub=listallitems&type=1" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Melee','','img/shop_select_melee_on.gif',1)"><img name="Melee" border="0" src="img/shop_select_melee.gif" alt="Melee"></a></td>
            <td align="center"><a href="index.php?gunz=itemshop&sub=listallitems&type=3" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Armor','','img/shop_select_armor_on.gif',1)"><img name="Armor" border="0" src="img/shop_select_armor.gif" alt="Armor"></a></td>
            <td align="center"><a href="index.php?gunz=itemshop&sub=listallitems&type=5" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Special','','img/shop_select_special_on.gif',1)"><img name="Special" border="0" src="img/shop_select_special.gif" alt="Special"></a></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="right" class="Estilo1" height="25">					
		<form name="itemtype"><select size="1" name="type" onChange="SwitchItem()" class="login">
											<optgroup label="">
											<option>SELECT A ITEM CATEGORY</option>
											<option value="1">Meele Weapons</option>
											<option value="2">Ranged Weapons</option>
											<option value="3">Armor</option>
											<option value="5">Special Items</option>
											</optgroup></select></form></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"><?
if(!function_exists("ListAllItems")){
function ListAllItems(){
    if(!isset($_GET['type'])){
        $type = "";
    }else{
        $type = "Slot = '".clean($_GET['type'])."' AND";
    }

    $res = mssql_query("SELECT * FROM CashShop WHERE ".$type." Opened = '1'");

    ?>
		<table width="570" border="0" align="center" class="login4">
	<?     while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 2) {
                                                $count = 1;
                                                echo "</tr>";
		?>
    <tr>
    <td align="center">
			<table width="250" border="0">
      <tr>
        <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
        <td colspan="2" class="estilo8" align="left">
          <b><?=$item['Name']?></b>        </td>
      </tr>
      <tr>
        <td width="64" class="estilo5" align="left">Type:</td>
        <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Sex:</td>
        <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Level:</td>
        <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Price:</td>
        <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
      </tr>
      <tr>
        <td colspan="2"><table width="100%" border="0" align="center">
          <tr>
            <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
            <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
            <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td colspan="2" height="20"></td>
        </tr>
    </table></td>                                                <?
                                            }else{
                                                ?>
    <td align="center"><table width="250" border="0">
      <tr>
        <td width="104" rowspan="7" valign="top"><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
        <td colspan="2" class="estilo8" align="left">
          <b><?=$item['Name']?></b>        </td>
      </tr>
      <tr>
        <td width="64" class="estilo5" align="left">Type:</td>
        <td width="68" class="estilo5" align="right"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Sex:</td>
        <td class="estilo5" align="right"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Level:</td>
        <td class="estilo5" align="right"><?=$item['ResLevel']?></td>
      </tr>
      <tr>
        <td class="estilo5" align="left">Price:</td>
        <td class="estilo5" align="right"><?=$item['CashPrice']?></td>
      </tr>
      <tr>
        <td colspan="2"><table width="100%" border="0" align="center">
          <tr>
            <td><a href="index.php?gunz=itemshop&sub=details&id=<?=$item['CSID']?>"><img src="img/btn_itmshp_details.gif" width="47" height="19" border="0"></a></td>
            <td><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
            <td><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
          </tr>
        </table></td>
        </tr>
      <tr>
        <td colspan="2" height="20"></td>
        </tr>
    </table><?
                                                 $count++;
                                            }
                                        }   ?></td>
  </tr>
</table>
  <?
    }  }
if(!function_exists("ShowItemsDetails")){
    function ShowItemsDetails(){
    if($_GET['id'] == ""){
        re_dir("index.php");
    }
    $itemid = clean($_GET['id']);
    $res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$itemid'");
    $item = mssql_fetch_assoc($res);
    ?>
    <table width="570" border="0" align="center" class="login4">
      <tr>
        <td align="center" class="estilo5"><table width="550" border="0">
          <tr>
            <td align="center" class="estilo5" valign="top"><table width="100" border="0" cellpadding="0" cellspacing="0" class="login4">
              <tr>
                <td><img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100" style="border-width: 1px; border-style: solid; border-color: #000000;"></td>
              </tr>
              <tr>
                <td height="10"></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="left"><a href="index.php?gunz=itemshop&sub=buyitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_buy02.gif" width="47" height="19" border="0"></a></td>
                    <td align="right"><a href="index.php?gunz=itemshop&sub=giftitem&itemid=<?=$item['CSID']?>"><img src="img/btn_itmshp_gift.gif" width="47" height="19" border="0"></a></td>
                  </tr>
                </table></td>
              </tr>
            </table></td>
            <td align="center" class="estilo5"><table width="300" border="0" class="login4">
              <tr>
                <td colspan="2" align="left" class="estilo8"><span class="item_name">
																<b><?=$item['Name']?></b></span></td>
              </tr>
              <tr>
                <td colspan="2" align="left" class="estilo5"><?=$item['Description']?></td>
              </tr>
              <tr>
                <td width="83" align="left" class="estilo5">Type:</td>
                <td width="107" align="right" class="estilo5"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
              </tr>
              <tr>
                <td align="left" class="estilo5">Sex:</td>
                <td align="right" class="estilo5"><?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
              </tr>
              <tr>
                <td align="left" class="estilo5">Level:</td>
                <td align="right" class="estilo5"><?=$item['ResLevel']?></td>
              </tr>
              <tr>
                <td align="left" class="estilo5">Weight:</td>
                <td align="right" class="estilo5"><?=$item['Weight']?></td>
              </tr>
              <tr>
                <td align="left" class="estilo5">Price:</td>
                <td align="right" class="estilo5"><?=$item['CashPrice']?></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2" align="center" class="estilo5"><table width="450" border="0" align="center" class="login4">
              <tr>
                <td width="109" class="Estilo5">Damage : </td>
                <td width="44" class="Estilo5"><?=$item['Damage']?></td>
                <td width="103" class="Estilo5">AP :</td>
                <td width="44" class="Estilo5"><?=$item['AP']?></td>
                <td width="103" class="Estilo5">FR : </td>
                <td width="50" class="Estilo5"><?=$item['FR']?></td>
              </tr>
              <tr>
                <td class="Estilo5">Delay : </td>
                <td class="Estilo5"><?=$item['Delay']?></td>
                <td class="Estilo5">HP : </td>
                <td class="Estilo5"><?=$item['HP']?></td>
                <td class="Estilo5">PR :</td>
                <td class="Estilo5"><?=$item['PR']?></td>
              </tr>
              <tr>
                <td class="Estilo5">Magazine : </td>
                <td class="Estilo5"><?=$item['Magazine']?></td>
                <td class="Estilo5">Max Weight : </td>
                <td class="Estilo5"><?=$item['MaxWeight']?></td>
                <td class="Estilo5">CR :</td>
                <td class="Estilo5"><?=$item['CR']?></td>
              </tr>
              <tr>
                <td class="Estilo5">Max Bullet : </td>
                <td class="Estilo5"><?=$item['MaxBullet']?></td>
                <td class="Estilo5">Reload Time : </td>
                <td class="Estilo5"><?=$item['ReloadTime']?></td>
                <td class="Estilo5">LR : </td>
                <td class="Estilo5"><?=$item['LR']?></td>
              </tr>
              <tr>
                <td class="Estilo5">Control : </td>
                <td class="Estilo5"><?=$item['Control']?></td>
                <td class="Estilo5">Duration : </td>
                <td class="Estilo5"><b>Unlimited</b></td>
                <td class="Estilo5" height="18"></td>
                <td class="Estilo5"></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2" align="center" class="estilo5"><a href="index.php?gunz=shop"><img src="img/btn_itmshp_back.gif" width="130" height="31" border="0"></a></td>
          </tr>
        </table></td>
      </tr>
    </table>
	    <?
}   }
if(!function_exists("showbuyitem")){
    function showbuyitem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
       if(isset($_POST['submit'])){
            $itemid = clean($_POST['ItemID']);
            $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['Coins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By LaMbDa FrOm SpAiN!!! :)");
            }
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$aid', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Account SET Coins = '$updatecoins' WHERE AID = '$aid'");
            alertbox("Item purchased correctly, you can get it in Central bank","index.php?gunz=itemshop&sub=listallitems&type=2");
			die();
       }
       ?>
<table width="570" border="0" align="center">
  <tr>
    <td align="center"><table width="450" border="0" class="login4">
      <tr>
        <td width="274" align="left" class="estilo5">Item Name: </td>
        <td width="266" align="left" class="estilo5"><b>
          <?=$item['Name']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Current Bill: </td>
        <td align="left" class="estilo5"><b>
          <?=$_SESSION['UserID']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Price:</td>
        <td align="left" class="estilo5"><b>
          <?=$item['CashPrice']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Coins You have: </td>
        <td align="left" class="estilo5"><b>
          <?=$acc['Coins']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Coins later: </td>
        <td align="left" class="estilo5"><b>
          <?
                                                    $result = $acc['Coins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "<b>Insufficient Coins</b>";
                                                    }else{
                                                        $boton = "<input type='submit' value='Buy Item' name='submit' class='login'>";
                                                    }

                                                        echo $acc['Coins']-$item['CashPrice'];?>
        </b></td>
      </tr>
      <tr>
        <td height="20" colspan="2" align="left" class="estilo5"></td>
        </tr>
      <tr>
        <td colspan="2" align="center" class="estilo5">													<font color="#FF0000"><b>
		  NOTE: If you buy an item and then do not want, or is mistaken, we are not responsible</b></font></td>
        </tr>
      <tr>
        <td height="20" colspan="2" align="left" class="estilo5"></td>
        </tr>
      <tr>
        <td colspan="2" align="center" class="estilo5"><form method="POST" action="index.php?gunz=itemshop&sub=buyitem">   
														<?=$boton?>
														<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
		  </form></td>
        </tr>
    </table></td>
  </tr>
</table>
<?
}   }
if(!function_exists("showgiftitem")){
    function showgiftitem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    $itemid = clean($_POST['ItemID']);
    $item2 = clean($_GET['itemid']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            alertbox("UserID $id doesnt exist","index.php?gunz=itemshop&sub=listallitems&type=2");
			die();
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['Coins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By NoLiFe_X!!! :)");
            }
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$UserAID', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Account SET Coins = '$updatecoins' WHERE AID = '$aid'");
            alertbox("Item purchased and gifted correctly, your friend can get it in Central bank","index.php?gunz=itemshop&sub=listallitems&type=2");
       die();
	    }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            alertbox("The character $id doesnt exist","index.php?gunz=itemshop&sub=listallitems&type=2");
			die();
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
       $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
            $res = mssql_query_logged("SELECT * FROM CashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['Coins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By NoLiFe_X!!! :)");
            }

            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$UserAID', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Account SET Coins = '$updatecoins' WHERE AID = '$aid'");
            alertbox("Item purchased and gifted correctly, your friend can get it in Central bank","index.php?gunz=itemshop&sub=listallitems&type=2");
        die();
		}
		
    }

}
?>
<table width="570" border="0" align="center">
  <tr>
    <td align="center"><table width="450" border="0" class="login4">
      <tr>
        <td width="274" align="left" class="estilo5">Item Name: </td>
        <td width="266" align="left" class="estilo5"><b>
          <?=$item['Name']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Current Bill: </td>
        <td align="left" class="estilo5"><b>
          <?=$_SESSION['UserID']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5"><select size="1" name="type" class="login">
          <option selected value="1">Gifting User ID </option>
          <option value="2">Gifting Character Name </option>
        </select></td>
        <td align="left" class="estilo5"><input type="text" name="id" size="26" class="login"></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Price:</td>
        <td align="left" class="estilo5"><b>
          <?=$item['CashPrice']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Coins You have: </td>
        <td align="left" class="estilo5"><b>
          <?=$acc['Coins']?>
        </b></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Coins later: </td>
        <td align="left" class="estilo5"><b>
          <?
                                                    $result = $acc['Coins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "<b>Insufficient Coins</b>";
                                                    }else{
                                                        $boton = "<input type='submit' value='Buy Item' name='submit' class='login'>";
                                                    }

                                                        echo $acc['Coins']-$item['CashPrice'];?>
        </b></td>
      </tr>
      <tr>
        <td height="20" colspan="2" align="left" class="estilo5"></td>
        </tr>
      <tr>
        <td colspan="2" align="center" class="estilo5"> <font color="#FF0000"><b> NOTE: If you buy an item and then do not want, or is mistaken, we are not responsible</b></font></td>
      </tr>
      <tr>
        <td height="20" colspan="2" align="left" class="estilo5"></td>
        </tr>
      <tr>
        <td colspan="2" align="center" class="estilo5"><form method="POST" action="index.php?gunz=itemshop&sub=buyitem">
            <?=$boton?>
            <input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID2">
        </form></td>
      </tr>
    </table></td>
  </tr>
</table><?
    }
}
if($_GET['expand'] == 0){
switch($_GET['sub']){
    case "listallitems";
        ListAllItems();
    break;
    case "details";
        ShowItemsDetails();
    break;
    case "buyitem";
        ShowBuyItem();
    break;
    case "giftitem";
        ShowGiftItem();
    break;
}
}
?>
</td>
      </tr>
    </table></td>
  </tr>
</table>
