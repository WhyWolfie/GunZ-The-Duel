<? SetTitle("ijji - Where Gamers Unite! - Recover Deleted Character");
if ($_SESSION['AID'] == ""){
    alertbox("Login first!","index.php");
    die();
	} 
else
{
    $qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($qchars) == 0 )
    {
	alertbox("You do not have any character in this account.","index.php");
    die();
	} 
    else
    {
    if( isset($_GET['cid']) )
    {
        $cid = clean($_GET['cid']);
        $qcharinfo = mssql_query_logged("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
        if( mssql_num_rows($qcharinfo) == 0 )
        {
	alertbox("The selected Character does not exist or does not belong to your account.","index.php");
    die();
	}
        $info = mssql_fetch_assoc($qcharinfo);

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
        {
	alertbox("A character with the selected name already exists, Unafortunately this character can not be recovered.","index.php");
    die();
	}
        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        else
        {
	alertbox("Your account has 4 active characters, that is the maximum allowed. You have to delete one of your characters to recover the selected one.","index.php");
    die();
	}
	alertbox("The selected character has been recovered successfully.","index.php");
    die();
	}
    else
    {
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>RECOVER CHARACTER</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25">
				Here you can catch characters that you have deleted or you have <br/>
        inadvertently erased. <br> You should know that in a GunZ account is allowed <br/>
        a maximum of 4 characters, so <br> if you have 4 active characters and
        <br/> want to recover one of the characters deleted, <br> 
        Delete an Active Character        <br/> 
        to give place to recover.</td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="10"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25"><table width="350" align="center" class="errorbox" id="table1">
        	<tr>
        	  <td colspan="4" align="center" class="Estilo1">List Of Characters </td>
        	  </tr>
        	<tr>
        	  <td height="5" colspan="4" align="center" class="Estilo1"></td>
      	  </tr>
        	<tr>
        		<td align="center" class="Estilo1"><b>Name</b></td>
        		<td align="center" class="Estilo1"><b>Level</b></td>
        		<td align="center" class="Estilo1"><b>Type</b></td>
        		<td align="center" class="Estilo1"><b>�Recover?</b></td>
        	</tr>
            <?

        while( $data = mssql_fetch_assoc($qchars) )
        {
            echo '
            	<tr>
            		<td align="center" class="Estilo1">';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo $data[DeleteName].'</td>';
                    }else{
                        echo $data[Name].'</td>';
                    }

                echo '<td align="center" class="Estilo1">'.$data[Level].'</td>
            		<td align="center" class="Estilo1">';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo 'Deleted</td>
                    <td align="center" class="Estilo1">';
                    }else{
                        echo 'Active</td>
                    <td align="center" class="Estilo1">';
                    }
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo '<a href="index.php?gunz=recoverplayer&cid='.$data[CID].'">Recover!</a></td>
            	</tr>';
                    }else{
                        echo 'Active</td>
            	</tr>';
                    }

        }
        ?>
        </table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
        <?
    }
}
}

?>