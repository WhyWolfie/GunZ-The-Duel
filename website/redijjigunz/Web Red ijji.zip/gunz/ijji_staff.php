<? SetTitle("ijji - Where Gamers Unite! - Staff List"); ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>STAFF LIST</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="250" border="0" bgcolor="#151515">
              <tr>
                <td width="195" align="center" class="Estilo1">Owner</td>
                <td width="195" align="left" class="Estilo1">X-Weaver, Ragezone </td>
              </tr>
              <tr>
                <td align="center" class="Estilo1"><font color="#FF0000">Admin</font></td>
                <td align="left" class="Estilo1">X-Weaver, Ragezone </td>
              </tr>
              <tr>
                <td align="center" class="Estilo1"><font color="#00FF00">GM</font></td>
                <td align="left" class="Estilo1">X-Weaver, Ragezone </td>
              </tr>
              <tr>
                <td align="center" class="Estilo1"><font color="#0099FF">Developer</font></td>
                <td align="left" class="Estilo1">X-Weaver, Ragezone </td>
              </tr>
              <tr>
                <td align="center" class="Estilo1"><font color="#CC9900">Forum Mod</font></td>
                <td align="left" class="Estilo1">X-Weaver, Ragez one </td>
              </tr>
              <tr>
                <td align="center" class="Estilo1"><font color="#000000">Raped</font></td>
                <td align="left" class="Estilo1">LOL</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
