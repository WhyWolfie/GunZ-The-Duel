<? SetTitle("ijji - Where Gamers Unite! - Buy Coins Step 2");
if ($_SESSION['AID'] == ""){
    alertbox("Login first!","index.php");
    die();
	} 
$aid = clean($_SESSION['AID']);
$query = mssql_query("SELECT * FROM Account WHERE AID='$aid'");
$row = mssql_fetch_assoc($query);
$userid = $row['UserID'];
$amount = $_POST['amount'];
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>BUY COINS | STEP 2 </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25"><form method="post" action="process.php"><table width="380" height="100%" border="0" cellpadding="6" cellspacing="6" bgcolor="#151515">
                  <tr>
                    <td align="left" class="Estilo1">Username:</td>
                    <td align="right" class="Estilo1"><input name="firstname" type="text" id="firstname" size="40" value="<?=$userid?>" class="login"></td>
                  </tr>
                  <tr><input name="lastname" type="hidden" id="lastname" size="40" value="Donatorcoins:<? 
			$coins = $amount * 10; 
			echo $coins;
			?>
            ">
                    <td align="left" class="Estilo1">Address 1: </td>
                    <td align="right" class="Estilo1"><input name="address1" type="text" id="address1"  size="40" class="login"></td>
                  </tr>
                  <tr>
                    <td align="left" class="Estilo1">Address 2: </td>
                    <td align="right" class="Estilo1"><input name="address2" type="text" id="address2"  size="40" class="login"></td>
                  </tr>
                  <tr>
                    <td align="left" class="Estilo1">City:</td>
                    <td align="right" class="Estilo1"><input name="city" type="text" size="40"  class="login"></td>
                  </tr>
                  <tr>
                    <td align="left" class="Estilo1">State:</td>
                    <td align="right" class="Estilo1"><input name="state" type="text" size="40"  class="login"></td>
                  </tr>
                  <tr>
                    <td align="left" class="Estilo1">E-Mail:</td>
                    <td align="right" class="Estilo1"><input name="email" type="text" id="email" size="40"  class="login"></td>
                  </tr>
                  <tr>
                    <td colspan="2" align="center" class="Estilo1"><input name="amount" id="amount" type="hidden" size="40" value="<? 
			
			echo $_POST['amount']; ?>">
            <input name="item_name" type="hidden" id="item_name" size="40" value="Donatorcoins:<? 
			$coins = $amount * 10; 
			echo $coins;
			?>
            "><input type="submit" name="submit" id="submit" value="Buy" class="login"></td>
                    </tr>
                </table></form>
				</td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
