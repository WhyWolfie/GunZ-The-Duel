<? SetTitle("ijji - Where Gamers Unite! - My Items");
	?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>MY ITEMS </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>                
            <td align="center" class="Estilo1"><table width="200" border="0" align="center" class="errorbox">
              <tr>
                <td><table width="380" border="0" cellspacing="0" cellpadding="0">
              <tr bgcolor="#333333">
                <td width="126" align="left" class="Estilo1">Name</td>
                <td width="115" align="center" class="Estilo1">Type</td>
                <td width="114" align="right" class="Estilo1">Expire</td>
              </tr>
              <tr>
                <td height="15" colspan="3" align="left" class="Estilo1">&nbsp;</td>
                </tr>
            </table>                  
                <?

    $res = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . clean($_SESSION['AID']) . "'"); ?>                                    <? while ($item = mssql_fetch_assoc($res)){
                                                        $res2 = mssql_query("SELECT * From CashShop WHERE CSID = '".clean($item['ShopItemID'])."'");
                                                        $item2 = mssql_fetch_assoc($res2);
														
                                                        ?>   <table width="380" height="20" border="0" cellpadding="0" cellspacing="0">
                  <tr>
                    <td width="126" align="left" class="Estilo1"><?=$item2['Name']?></td>
                    <td width="115" align="center" class="Estilo1"><?
                                                    switch ( $item2['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Armor";
                                                        break;
                                                        case "4";
                                                        $slot = "Set";
                                                        break;
                                                        case "5";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?>
                    </td>
                    <td width="114" align="right" class="Estilo1">Unlimited</td>
                  </tr>
                            </table>              <? } ?></td>
              </tr>
            </table>              </td>
          </tr>      
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>