<? SetTitle("ijji - Where Gamers Unite! - Buy Coins");
if ($_SESSION['AID'] == ""){
    alertbox("Login first!","index.php");
    die();
	} 
?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>BUY COINS | STEP 1 </strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                <td align="center" class="Estilo1" height="25"></td>
              </tr>
              <tr>
                <td align="center" class="Estilo1" height="25">
				<table width="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#151515">
  <tr>
    <td width="135" align="center" class="estilo2"></td>
    <td width="345" height="5" align="center" class="estilo2"></td>
  </tr>
  <tr>
    <td class="estilo2" align="center"></td>
    <td class="estilo2" align="center" height="20"></td>
  </tr>
  <tr>
    <td class="estilo1" align="center"><img src="img/bn_paypal.png" width="99" height="91"></td>
    <td class="estilo1" align="center" height="20"> The payment service PayPal is widely recognized to be quickly and safely. PayPal offers the use of the most popular for its credit card transactions. </td>
  </tr>
  <tr>
    <td class="estilo1" align="center" height="20"></td>
    <td class="estilo1" align="center"></td>
  </tr>
  <tr>
    <td height="20" colspan="2" align="center" class="estilo1"><?
								$error = $_GET['error'];
			 					 if(isset($_GET['error']) && $_GET['error'] == "form"){
								  echo "<br><font color=\"red\"><b>Please fill in all forms next time.</b></font>";
								  }
			  					?></td>
  </tr>
  <tr>
    <td height="20" colspan="2" align="center" class="estilo1">                                Amount of Donator Coins u want.<br>
                                <form method="POST" action="index.php?gunz=orderform">
                                <select name="amount" class="login">
                                <option value="0.1">10 | 1 Euro</option>
                                <option value="5">50 | 5 Euro</option>
                                <option value="10">100 | 10 Euro</option>
                                <option value="20">200 | 20 Euro</option>
                                <option value="25">250 | 25 Euro</option>
                                <option value="30">300 | 30 Euro</option>
                                <option value="40">400 | 40 Euro</option>
                                <option value="50">500 | 50 Euro</option>
                                </select>
                                <br /><br />
                                <input type="submit" value="Next Step" class="login"/>
                            </form></td>
  </tr>
  <tr>
    <td class="estilo2" align="center"></td>
    <td class="estilo2" align="center" height="5"></td>
  </tr>
</table></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
