<? SetTitle("ijji - Where Gamers Unite! - Viewing News");
if($_GET['sub'] == "announcement"){
    $res = mssql_query("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);  ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" class="estilo6"><strong>NEWS - UPDATES/ANNOUNCEMENTS</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" class="Estilo1"><table width="400" height="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#151515">
              <tr>
                <td><table width="380" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td height="25" align="center" class="Estilo1"></td>
              <tr>
                <td height="25" align="left" class="Estilo1"><?=$a['Title']?></td>
              <tr>
                <td height="10" align="center" class="Estilo1"></td>
              <tr>
                <td height="25" align="center" class="Estilo1"><?=$a['Text']?></td>
              <tr>
                <td height="10" align="center" class="Estilo1"></td>
              <tr>
                <td width="380" height="25" align="right" class="Estilo1">Submitted By <em><b><?=$a['User']?></b>, <?=$a['Date']?></em></td>             
            </table>
			<? }else{
    $res = mssql_query_logged("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
	        <table width="380" border="0" cellspacing="0" cellpadding="0" align="center">
              <tr>
                <td height="25" align="center" class="Estilo1"></td>
              <tr>
                <td height="25" align="left" class="Estilo1"><?=$a['Title']?></td>
              <tr>
                <td height="10" align="center" class="Estilo1"></td>
              <tr>
                <td height="25" align="center" class="Estilo1"><?=$a['Text']?></td>
              <tr>
                <td height="10" align="center" class="Estilo1"></td>
              <tr>
                <td width="380" height="25" align="right" class="Estilo1">Submitted By <em><b><?=$a['User']?></b>, <?=$a['Date']?></em></td>             
            </table><? }?></td>
              </tr>
            </table></td>
          </tr>                             
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
