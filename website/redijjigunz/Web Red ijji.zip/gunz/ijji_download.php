<? SetTitle("ijji - Where Gamers Unite! - Download"); ?>
<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
-->
</style>
<table width="802" height="500" border="0" align="center">
  <tr>
    <td width="100" align="center" valign="top">
      <table width="100" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10" align="center"></td>
        </tr>
      </table></td>
    <td width="160" height="26" align="center" valign="top"><? include"other/leftblock.php" ?></td>
    <td width="237" align="center" valign="top"><table width="422" height="724" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" bgcolor="#232124" valign="top"><table width="422" border="0">
          <tr>
            <td align="left" class="estilo2">
              <table width="415" height="40" border="0" cellpadding="0" cellspacing="0">
                <tr bgcolor="#000000">
                  <td height="10" colspan="2"></td>
                  </tr>
                <tr>
                  <td class="estilo2" width="27"><img src="img/mini_detail.gif" width="27" height="25"></td>
                  <td height="30" bgcolor="#232124" class="estilo6"><strong>DOWNLOAD ZONE</strong></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#232124" class="Estilo1"><table width="400" border="0">
                <tr>
                  <td align="center" class="Estilo1"><img src="img/dwonload_gunz.jpg" width="260" height="109" border="1px" style="border-color:#000000"></td>
                  <td align="center" class="Estilo1" valign="top"> <p>GunZ - Combining bullets and blades, GunZ delivers a new alternative shooting experience with an anime theme.<br>
                    Gun &amp; Sword Fighting | Fast 3D Action Quest Modes </p>                    </td>
                </tr>
                <tr>
                  <td colspan="2" align="center" class="Estilo1"><a href="http://mirror1.com"><img src="img/download_btn.png" width="100" height="25" border="0"></a><a href="http://mirror2.com"><img src="img/download_btn2.png" width="100" height="25" border="0"></a><a href="http://mirror3.com"><img src="img/download_btn3.png" width="100" height="25" border="0"></a></td>
                  </tr>
                <tr>
                  <td height="10" colspan="2" align="center" class="Estilo1"></td>
                </tr>
                <tr>
                  <td height="10" colspan="2" align="center" class="Estilo1">System Requirements <br>
                    Your computer must meet certain minimum requirements in order to play GunZ. <br>
Before you download and install GunZ, please verify your system specifications <br>
meet or exceed the following. </td>
                </tr>
                <tr>
                  <td height="5" colspan="2" align="center" class="Estilo1"></td>
                </tr>
                <tr>
                  <td colspan="2" align="center" bgcolor="#232124" class="Estilo1"><table width="375" cellpadding="0" class="login3">
                    <tr bgcolor="#000000">
                      <td align="center" bgcolor="#101010" class="Estilo6"></td>
                      <td align="center" class="Estilo6">Minimum</td>
                      <td align="center" class="Estilo6">Recommended</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Os</td>
                      <td colspan="2" align="center" class="Estilo1">Windows XP</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">DirectX</td>
                      <td colspan="2" align="center" class="Estilo1">DirectX 9.0c or above</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">CPU</td>
                      <td align="center" class="Estilo1">Pentium III 500 MHz</td>
                      <td align="center" class="Estilo1">Pentium III 800 MHz or higher</td>
                    </tr>
                    <tr>
                      <td height="22" align="center" bgcolor="#101010" class="Estilo6">RAM</td>
                      <td align="center" class="Estilo1">256MB</td>
                      <td align="center" class="Estilo1">512 MB or above</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Graphics Card</td>
                      <td align="center" class="Estilo1">Direct 3D 9.0 Compatible (Riva TNT)</td>
                      <td align="center" class="Estilo1">GeForce 4MX or higher</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Sound Card</td>
                      <td colspan="2" align="center" class="Estilo1">Direct3D Sound Compatible</td>
                    </tr>
                    <tr>
                      <td align="center" bgcolor="#101010" class="Estilo6">Mouse</td>
                      <td colspan="2" align="center" class="Estilo1">Windows Compatible (Wheel Mouse recommended)</td>
                    </tr>
                  </table></td>
                </tr>
              </table></td>
          </tr>
          <tr>
            <td align="center" bgcolor="#232124"><img src="img/mc_controls_pic.gif" width="402" height="187"></td>
          </tr>
          <tr>
            <td height="5" align="center" bgcolor="#232124"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
    <td width="190" align="center" valign="top"><? include"other/rightblock.php" ?></td>
    <td width="100" align="left" valign="top"><? include"mininew/rightnew.php" ?></td>
  </tr>
</table>
