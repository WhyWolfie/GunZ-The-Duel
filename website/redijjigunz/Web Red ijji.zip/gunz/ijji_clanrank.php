<? SetTitle("ijji - Where Gamers Unite! - Clan Ranking"); ?>

<script language="JavaScript" type="text/JavaScript">
<!--

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('img/ministart02.gif','img/hallfame_select_on.jpg','img/playeranking_select_on.jpg')">
<table width="784" height="100%" border="0" align="center">
  <tr valign="top">
    <td width="160" align="center" valign="top" bgcolor="#232124"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
            <tr>
              <td align="center" height="58"></td>
            </tr>
          </table>
            <a href="index.php?gunz=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('START','','img/ministart02.gif',1)"><img src="img/ministart01.gif" alt="Download" name="START" border="0"  style=" float:none; margin-top:5; margin-left:-155; position:absolute;"></a></td>
      </tr>
      <tr>
        <td align="center" background="img/bg_content_wm.gif" bgcolor="#004f86" style="background-repeat:no-repeat; background-position:top;"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center" valign="top" height="2"></td>
            </tr>
            <tr>
              <td align="center" valign="top" bgcolor="#232124"><img src="img/ltit_ranking.gif" width="150" height="42">
                  <table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center" background="img/lbox01_t.gif" style="background-repeat:no-repeat; background-position:top;" height="6"></td>
                    </tr>
                    <tr>
                      <td align="center" background="img/lbox01_b.gif" bgcolor="#232124" style="background-repeat:no-repeat;"><a href="index.php?gunz=clanrank"><img src="img/clanranking_select_on.jpg" width="130" height="26" border="0"></a><br>
                          <a href="index.php?gunz=playerank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('PlayerRank','','img/playeranking_select_on.jpg',1)"><img name="PlayerRank" border="0" src="img/playeranking_select.jpg" alt="PlayerRank"></a><br>
                          <a href="index.php?gunz=hallofame" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('hallfame','','img/hallfame_select_on.jpg',1)"><img name="hallfame" border="0" src="img/hallfame_select.jpg" alt="HallOfFame"></a></td>
                    </tr>
                    <tr>
                      <td height="6" align="center" background="img/lbox01_b.gif" bgcolor="#232124" style="background-repeat:no-repeat; background-position:bottom"></td>
                    </tr>
                </table></td>
            </tr>
        </table></td>
      </tr>
    </table>	</td>
    <td align="center" valign="top" bgcolor="#FFFFFF" class="Estilo1" width="620" height="100%"><table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left"><img src="img/tit_guildranking.gif" width="150" height="23"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="left" class="Estilo1" height="30"><img src="img/guild03_sub02.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"><?
                                            $res = mssql_query_logged("SELECT TOP 4 * FROM Clan WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND Ranking != 0 ORDER BY POINT DESC, Ranking ASC");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "clan/emblem/no_emblem.png" : $resa->EmblemUrl;

                                            if($Count == 4)
                                                break;
                                            else
                                                $Count++;
                                            }

                                            $firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[0][EmblemURL];
                                            $firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[1][EmblemURL];
                                            $firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[2][EmblemURL];
                                            $firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[3][EmblemURL];

                                            $firstclanname0 = ($FirstClan[0][Name] == "") ? "No Data" : $FirstClan[0][Name];
                                            $firstclanname1 = ($FirstClan[1][Name] == "") ? "No Data" : $FirstClan[1][Name];
                                            $firstclanname2 = ($FirstClan[2][Name] == "") ? "No Data" : $FirstClan[2][Name];
                                            $firstclanname3 = ($FirstClan[3][Name] == "") ? "No Data" : $FirstClan[3][Name];
                                            $toprank = '
					<table width="573" height="160" border="0" align="center" background="img/rank_bg_best.gif" style="background-position:center; background-repeat:no-repeat;">
    <td width="133" height="10"></td>
  <tr>
    <td width="143" align="center"><img src="./'.$firstclanemb0.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb1.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb2.'" width="64" height="64" style="border: 1px solid #000000"></td>
    <td width="143" align="center"><img src="./'.$firstclanemb3.'" width="64" height="64" style="border: 1px solid #000000"></td>
  </tr>
  <tr height="12">
    <td class="estilo5"><center><b><font color="#FF9900"><blink>1ST '.$firstclanname0.'</blink></font></b></center></td>
    <td class="estilo5"><center><b>2ND '.$firstclanname1.'</b></center></td>
    <td class="estilo5"><center><b>3RD '.$firstclanname2.'</b></center></td>
	<td class="estilo5"><center><b>4TH '.$firstclanname3.'</b></center></td>
  </tr>
      <td width="133" height="5"></td>
</table> ';
                                echo $toprank; ?></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="15"></td>
      </tr>
      <tr>
        <td align="center"><table width="573" height="45" border="0" align="center" cellpadding="0" cellspacing="0" background="img/box_sch.gif" class="Estilo1" style="background-repeat:no-repeat;">
  <tr>
    <td align="center"><form method="GET" name="rnksearch" action="index.php">
                                    <input type="hidden" name="gunz" value="clanrank" />
                                    <select name="type" class="login">
                                    <option value="1">Clan Name</option>
                                    </select>
                                    <input type="text" name="name" class="login"/>
                                    <input type="submit" value="Search" class="login"/>
                </form></td>
  </tr>
</table>
</td>
      </tr>
      <tr>
        <td height="30" align="left"><img src="img/ranking01_sub02.gif" width="150" height="16"></td>
      </tr>
      <tr>
        <td height="30" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="37" height="23" align="center" class="Estilo5"><b>Ranking</b></td>
            <td width="54" height="23" align="center" class="Estilo5"><b>Mark</b></td>
            <td width="108" height="23" align="center" class="Estilo5"><b>Clan Name</b></td>
            <td width="79" height="23" align="center" class="Estilo5"><b>Leader</b></td>
            <td width="85" height="23" align="center" class="Estilo5"><b>Win/Lossed %</b></td>
            <td width="59" height="23" align="center" class="Estilo5"><b>Points</b></td>
          </tr>
          <tr>
            <td colspan="6" valign="top">
              <table width="570" border="0" align="center" style="border-collapse: collapse">
                <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Ranking ASC";
                                                                }
                                                                else
                                                                {
                                                                    echo'
                                                               <tr>
                                            <td colspan="5" class="estilo5" align="center">
                                              - No Data -</td>
                                          </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if( $search == 0 )
                                                        {
                                                            switch( clean($_GET['page']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 20 AND Ranking <= 40";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 40 AND Ranking <= 60";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 60 AND Ranking <= 80";
                                                                break;
                                                                case "5":
                                                                    $ranks = "Ranking > 80 AND Ranking <= 100";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                            }
                                                            $res = mssql_query_logged("SELECT TOP 20 * FROM Clan(nolock) WHERE Ranking != 0 AND $ranks AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Point DESC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl;
                                                     ?>
                <tr>
                  <td colspan="6" align="center" class="Estilo1" height="6"></td>
                  </tr>
                <tr>
                  <td width="57" align="center" class="Estilo5">
                    <?=$clan->Ranking?>
                  </td>
                  <td width="59" align="center" class="Estilo5"><img src="<?=($clan->EmblemUrl == "") ? "./clan/emblem/no_emblem.png" : $clan->EmblemUrl;?>" width="34" height="30" style="border: 1px solid #000000"></td>
                  <td width="142" align="center" class="Estilo5">
                    <a href="index.php?gunz=clan&info=<?=$clan->Name?>"><font color="#505050"><b><?=$clan->Name?></b></font></a></td>
                  <td width="101" align="center" class="Estilo5"> <a href="index.php?gunz=player&info=<?=$clan->MasterCID?>">
                    <font color="#505050"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="111" align="center" class="Estilo5"><?=$clan->Wins . "/" . $clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                    </td>
                  <td width="74" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
                <tr>
                  <td height="35" colspan="6" align="center" class="estilo5">- No Data - </td>
                </tr>
                <?
                                                        }
                                                        ?>
            </table></td>
          </tr>
          <tr>
            <td colspan="6" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="35" align="center" class="login5"><?
                                    if( $search == 0 )
					                $name = clean($_GET['name']);
								    $type = clean($_GET['type']);
                                    { ?>
          <table width="500" border="0" cellpadding="0" cellspacing="0" align="center">
            <tr>
              <td height="8" align="center" background="img/rank_pgnavi_t.gif"style="background-repeat:repeat-x; background-position:top;"></td>
            </tr>
            <tr>
              <td height="30" align="center" class="estilo5" valign="baseline"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank"><font color="#333333">1-20</font></a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=2"><font color="#333333">20-40</font></a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=3"><font color="#333333">40-60</font></a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=4"><font color="#333333">60-80</font></a></td>
                      </tr>
                    </table></td>
                    <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=clanrank&page=5"><font color="#333333">80-100</font></a></td>
                      </tr>
                    </table></td>
                  </tr>
                </table>
                </td>
            </tr>
            <tr>
              <td background="img/rank_pgnavi_t.gif"style="background-repeat:repeat-x; background-position:bottom;" height="8"></td>
            </tr>
          </table>
          <?
                                    }
                                    ?></td>
      </tr>
    </table></td>
  </tr>
</table>
