<style type="text/css">
<!--
.Estilo1 {font-weight: bold}
body {
	background-color: #000000;
}
-->
</style>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#000000">
  <tr>
    <td align="center" bgcolor="#000000" class="estilo1"><font color="#CCCCCC" size="1" face="Verdana, Arial, Helvetica, sans-serif">Rules By *****<br>
                      <strong></br>
                      1] -No hacks here. Anything that is similar to, or is a type of massive hack, respawn hack, console and other abnormal gameplay is NOT allowed.
                      </strong><br>
                      </br>
1st Offence: IP Permanent ban.
<br>
</br>
2] -ALT codes spaces Glitch names (ASCIIs) are no longer allowed, /ASCII. Colored names are prohibted as well.
<br></br>
1st Offence: Permanent ban
<br></br>
3] -Spamming of the lobby's and/or channels is not allowed, and spamming the administrator while he is in the middle of work is not allowed either.
<br></br>
1st Offence: Warning
<br></br>
2nd Offence: Banned 1 day
<br></br>
3rd Offence: 3 Days Banned
<br></br>
4th Offence: Permanent ban
<br></br>
4] -Disrespecting the administrators and/or other members will get you warned, and banned if continued.
<br></br>
1st Offence: Warning
<br></br>
2nd Offence: 2+ Days Banned
<br></br>
3rd Offence: Permanent ban
<br></br>
5] -Swap is not ALLOWED
<br></br>
1st Offence: Infracted
<br></br>
2nd Offence: Level reset (Lvl 1, XP: 0, BT: 1000)
<br></br>
3rd Offence: Permanent ban
<br>
</br>
6] -Clan war Glitch (Leaving on example 2-0) And "Ninja-Step" is not ALLOWED
<br></br>
1st Offence: 7 Days Banned
<br></br>
2nd Offence: 1 Month Banned
<br></br>
3rd Offence: Permanent ban
<br></br>
7] - Force lagging is not allowed either.
<br></br>
1st Offence: 5 days banned.
<br></br>
2nd Offence: Permanent ban.
<br></br>
8] -Insulting members/staff is not ALLOWED
<br></br>
1st Offence: 1 Days Banned
<br></br>
2nd Offence: 7 Days Banned
<br></br>
3rd Offence: 15 Days Banned
<br></br>
4th Offence: Permanent ban</font></td>
  </tr>
</table>
