<script src="Scripts/AC_ActiveX.js" type="text/javascript"></script>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<table width="190" height="724" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#232124">
      <tr>
        <td width="190" align="center" valign="top"><table width="190" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="4"></td>
          </tr>
          <tr>
            <td align="center"><? include"other/userpanel.php" ?></td>
          </tr>
          <tr>
            <td height="4" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=clanrank"><img src="img/clanrank_banner.jpg" width="184" height="65" border="0"></a></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=playerank"><img src="img/playerran_banner.jpg" width="184" height="65" border="0"></a></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center"><a href="index.php?gunz=shop"><img src="img/shop_banner.jpg" width="184" height="65" border="0"></a></td>
          </tr>
          <tr>
            <td height="3" align="center"></td>
          </tr>
          <tr>
            <td height="10" align="center">&nbsp;</td>
          </tr>
          <tr>
            <td height="10" align="center"></td>
          </tr>
          <tr>
            <td height="5" align="center">&nbsp;</td>
          </tr>
          <tr>
            <td height="10" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table>