<?
$res = mssql_query("SELECT TOP 5 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY Level DESC");
$count = 0;
?>
<table width="150" height="112" border="0" cellpadding="0" cellspacing="0" background="img/player_bg.jpg" style="background-repeat:no-repeat; background-position:center">
  <tr>
    <td height="24" align="center"><table width="135" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="15"></td>
          <td align="right"><a href="index.php?gunz=playerank"><img src="img/btn_more08.gif" width="25" height="14" border="0"></a></td>
        </tr>
    </table></td>
  </tr>

  <tr>
    <td align="center"><table width="130" cellpadding="0" cellspacing="0">
      <tr>
        <td width="12"></td>
        <td width="89"></td>
        <td width="34"></td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td colspan="3" align="center" class="estilo1"><font color="#FFFFFF">- No Data -</font></td>
        </tr>
      <?
                                    }else{
                                    while($player = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
        <td width="12" height="16" valign="center"></td>
        <td width="89" height="10" align="left" class="estilo1"><font color="#FFFFFF"><a href="index.php?gunz=player&info=<?=$player['CID']?>"><?=$player['Name']?></a></font></td>
        <td width="34" align="right" class="estilo6">
          <font color="#FFFFFF"><?=$player['Level']?></font>
        </td>
      </tr>
      <? }} ?>
    </table></td>
  </tr>
  <tr>
    <td align="center" height="5"></td>
  </tr>
</table>
