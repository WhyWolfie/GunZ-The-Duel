<?
                            if( isset($_GET['date']) )
                            {
                                $date = clean($_GET['date']);
                                $date = explode("-", $date);
                                $month = $date[0];
                                $year = $date[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>
                            <table border="0" width="575" cellpadding="0" cellspacing="0">
							      <tr valign="top">
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left"><img src="img/tit_hof.gif" width="150" height="23"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Each month the Hall of Fame will include the top 100 clans from the previous month. The ranking is based on how many clan points you achieve within the month. This feature is currently collecting data and will be updated at the end of this month. <br>
          <br>
Play Clan wars to try to make our ijji's first Hall of Fame list! </td>
      </tr>
								      <tr>
        <td align="center" height="25"></td>
      </tr>
								<tr>
									<td width="575" align="left" valign="top">
                                    <form method="GET" name="honorrank" action="index.php">
                                    <input type="hidden" name="gunz" value="hallofame" />
<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" class="estilo5">  
                                    <input type="hidden" name="gunz" value="hallofame" />
                                    <b><?=$month?>.<?=$year?></b> Hall Of Fame</td>
            <td align="right" class="estilo5"><select name="date" onchange="document.honorrank.submit()" class="login">
                                    <option>Select Date</option>
                                    <?
                                    $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'.'.$halldata[Year].'</option>';
									}
                                    ?>
                                    </select>
	        </td>
          </tr>
   </table>
									</form>
                                    
                                    </td>

								<tr>
									<td width="575" valign="top">
                                        <table border="0">
											<tr>
												<td width="60" height="21" valign="bottom">
        <td height="20" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="37" height="23" align="center" class="Estilo5"><b>Ranking</b></td>
            <td width="108" height="23" align="center" class="Estilo5"><b>Clan Name</b></td>
            <td width="79" height="23" align="center" class="Estilo5"><b>Leader</b></td>
            <td width="85" height="23" align="center" class="Estilo5"><b>Win/Lossed %</b></td>
            <td width="59" height="23" align="center" class="Estilo5"><b>Points</b></td>
          </tr>
                        <?
                                switch( clean($_GET['page']) )
                                {
                                    case "":
                                        $ranks = "Ranking <= 20";
                                    break;
                                    case "2":
                                        $ranks = "Ranking > 20 AND Ranking <= 40";
                                    break;
                                    case "3":
                                        $ranks = "Ranking > 40 AND Ranking <= 60";
                                    break;
                                    case "4":
                                        $ranks = "Ranking > 60 AND Ranking <= 80";
                                    break;
                                    case "5":
                                        $ranks = "Ranking > 80 AND Ranking <= 100";
                                    break;
                                    default:
                                        $ranks = "Ranking <= 20";
                                    break;
                                }
                                $res = mssql_query_logged("SELECT * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                if(mssql_num_rows($res) <> 0)
                                {
                                    while($clan = mssql_fetch_object($res))
                                    {

                                        $clanemburl = ($clan->EmblemUrl == "") ? "noemblem.jpg" : $clan->EmblemUrl;
                                ?>
                <tr>
                  <td colspan="5" align="center" class="Estilo1" height="6"></td>
          </tr>
                <tr style="background-image:url(img/li_x_01.gif); background-position:bottom; background-repeat:repeat-x;">
                  <td width="64" align="center" class="Estilo5">
                    <b><?=$clan->Ranking?></b>
                  </td>
                  <td width="160" align="center" class="Estilo5">
                    <font color="#505050"><b><?=$clan->ClanName?></b></font></td>
                  <td width="106" align="center" class="Estilo5"> 
                    <font color="#505050"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="133" align="center" class="Estilo5"><?=$clan->Wins?>/<?=$clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                   </td>
                  <td width="85" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                                <?
                                    }
                                }
                                else
                                {
                                ?>
									<tr>
									<td width="575" align="center" colspan="7" class="estilo5">
									-No Data-</td>
									</tr>
                                <?
                                }

                            }
                            else
                            {
                                $querydate = mssql_query("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                $ddata = mssql_fetch_row($querydate);
                                $month = $ddata[0];
                                $year = $ddata[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>

	<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr valign="top">
        <td height="20"></td>
      </tr>
      <tr>
        <td align="left"><img src="img/tit_hof.gif" width="150" height="23"></td>
      </tr>
      <tr>
        <td align="center" class="Estilo1" height="25"></td>
      </tr>
      <tr>
        <td align="left" class="estilo5">Each month the Hall of Fame will include the top 100 clans from the previous month. The ranking is based on how many clan points you achieve within the month. This feature is currently collecting data and will be updated at the end of this month. <br>
          <br>
Play Clan wars to try to make our ijji's first Hall of Fame list! </td>
      </tr>
      <tr>
        <td align="center" height="20"></td>
      </tr>								
     			 			<form method="GET" name="honorrank" action="index.php"> <tr>
        <td height="35" align="center">	

						<table width="575" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="left" class="estilo5">  
                                    <input type="hidden" name="gunz" value="hallofame" />
                                    <b><?=$month?>.<?=$year?></b> Hall Of Fame</td>
            <td align="right" class="estilo5"><select name="date" onchange="document.honorrank.submit()" class="login">
                                    <option>Select Date</option>
                                    <?
                                    $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'.'.$halldata[Year].'</option>';
									}
                                    ?>
                                    </select>
			      </td>
          </tr>
   </table></td>
      </tr></form>
      <tr>
        <td height="30" align="center"><table width="570" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr align="center" background="img/top_li.gif" style="background-repeat:repeat-x;">
            <td width="37" height="23" align="center" class="Estilo5"><b>Ranking</b></td>
            <td width="108" height="23" align="center" class="Estilo5"><b>Clan Name</b></td>
            <td width="79" height="23" align="center" class="Estilo5"><b>Leader</b></td>
            <td width="85" height="23" align="center" class="Estilo5"><b>Win/Lossed %</b></td>
            <td width="59" height="23" align="center" class="Estilo5"><b>Points</b></td>
          </tr>
          <tr>
            <td colspan="5" valign="top">
              <table width="570" border="0" align="center" style="border-collapse: collapse">

                        <?
                                switch( clean($_GET['page']) )
                                {
                                    case "":
                                        $ranks = "Ranking <= 20";
                                    break;
                                    case "2":
                                        $ranks = "Ranking > 20 AND Ranking <= 40";
                                    break;
                                    case "3":
                                        $ranks = "Ranking > 40 AND Ranking <= 60";
                                    break;
                                    case "4":
                                        $ranks = "Ranking > 60 AND Ranking <= 80";
                                    break;
                                    case "5":
                                        $ranks = "Ranking > 80 AND Ranking <= 100";
                                    break;
                                    default:
                                        $ranks = "Ranking <= 20";
                                    break;
                                }
                                $res = mssql_query_logged("SELECT * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                if(mssql_num_rows($res) <> 0)
                                {
                                    while($clan = mssql_fetch_object($res))
                                    {

                                        $clanemburl = ($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl;
                                ?>                       
                <tr>
                  <td colspan="5" align="center" class="Estilo1" height="6"></td>
                  </tr>
                <tr style="background-image:url(img/li_x_01.gif); background-position:bottom; background-repeat:repeat-x;">
                  <td width="64" align="center" class="Estilo5">
                    <b><?=$clan->Ranking?></b>
                  </td>
                  <td width="160" align="center" class="Estilo5">
                    <font color="#505050"><b><?=$clan->ClanName?></b></font></td>
                  <td width="106" align="center" class="Estilo5"> 
                    <font color="#505050"><?=GetCharNameByCID($clan->MasterCID)?></font>
                  </a></td>
                  <td width="133" align="center" class="Estilo5"><?=$clan->Wins?>/<?=$clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                   </td>
                  <td width="85" align="center" class="Estilo5"><?=$clan->Point?></td>
                </tr>
                                <?
                                    }
                                }
                                else
                                {
                                ?>
                <tr>
                  <td height="35" colspan="5" align="center" class="estilo5">- No Data - </td>
                </tr>
                                <?
                                }

                            }
                        ?>

            </table>          </td>
          </tr>
          <tr>
            <td height="75" colspan="5" align="center"><table width="500" border="0" cellpadding="0" cellspacing="0" align="center">
              <tr>
                <td height="8" align="center" background="img/rank_pgnavi_t.gif"style="background-repeat:repeat-x; background-position:top;"></td>
              </tr>
              <tr>
                <td height="30" align="center" class="estilo5" valign="baseline"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>"><font color="#333333">1-20</font></a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=2"><font color="#333333">20-40</font></a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=3"><font color="#333333">40-60</font></a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=4"><font color="#333333">60-80</font></a></td>
                          </tr>
                      </table></td>
                      <td align="center"><table width="83" height="22" border="0" align="center" cellpadding="0" cellspacing="0">
                          <tr>
                            <td align="center" class="estilo5" style="background-repeat:no-repeat; background-position:center; font-weight: bold;" background="img/rank_pgnavi_box.gif" height="8"><a href="index.php?gunz=hallofame&date=<?=$date?>&page=5"><font color="#333333">80-100</font></a></td>
                          </tr>
                      </table></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td background="img/rank_pgnavi_t.gif"style="background-repeat:repeat-x; background-position:bottom;" height="8"></td>
              </tr>
          </table></td>
          </tr>
          <tr>
            <td colspan="5" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
    </table>