<?
include("poll_config.php");
if(!file_exists($file))
	{
	$fp=fopen($file,"w"); 
	fputs($fp,"0\n0\n0\n0"); 
	fclose($fp); 
	}


?><form method="POST" action="index.php?gunz=poll" name="poll">
<table width="146" border="0" cellpadding="0" cellspacing="0" background="img/poll_bgimg_u_gunz.gif" style="background-repeat: repeat-y; background-position:center;">
  <tr>
    <td colspan="2"><img src="img/poll_topimg_u_gunz.gif" width="146" height="21"></td>
  </tr>
  <tr>
    <td height="5" colspan="2" align="center" class="estilo1"></td>
  </tr>
  <tr>
    <td colspan="2" align="center" class="estilo1"><font color="#666666">Do u like this web?</font></td>
  </tr>
  <tr>
    <td colspan="2" align="center" class="estilo1">------------------------</td>
  </tr>
  <tr>
    <td width="43" align="center" class="estilo1"><input type="radio" name="En" value="E1" checked></td>
    <td width="103" align="left" class="estilo1"><font color="#666666"><? echo $c1;?></font></td>
  </tr>
  <tr>
    <td class="estilo1" align="center"><input type="radio" name="En" value="E2"></td>
    <td class="estilo1" align="left"><font color="#666666"><? echo $c2;?></font></td>
  </tr>
  <tr>
    <td class="estilo1" align="center"><input type="radio" name="En" value="E3"></td>
    <td class="estilo1" align="left"><font color="#666666"><? echo $c3;?></font></td>
  </tr>
  <tr>
    <td class="estilo1" align="center"><input type="radio" name="En" value="E4"></td>
    <td class="estilo1" align="left"><font color="#666666"><? echo $c4;?></font></td>
  </tr>
  <tr>
    <td height="5" colspan="2" align="center" class="estilo1">&nbsp;</td>
  </tr>
  <tr>
    <td height="22" colspan="2" align="center" class="estilo5">
	<input type="submit" value="OK" name="Bot" class="login"> 
	</td>
  </tr>
  <tr>
    <td height="5" colspan="2" align="center" class="estilo5"><a href="index.php?gunz=poll"><font color="#333333">View Result</font></a></td>
  </tr>
  <tr>
    <td height="5" colspan="2" align="center" class="estilo5"></td>
  </tr>
</table>
</form>
