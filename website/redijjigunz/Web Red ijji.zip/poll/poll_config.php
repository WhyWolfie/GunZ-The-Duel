<?
// POLL CONFIG
$file="poll/result.txt";

// POLL ANSWER
$c1="YES, I love it!"; //POLL n� 1
$c2="Its Great!!!"; //POLL n� 2
$c3="Not bad"; //POLL n� 3
$c4="bad, very bad!"; //POLL n� 4
?>