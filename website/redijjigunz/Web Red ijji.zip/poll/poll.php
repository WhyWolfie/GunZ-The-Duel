<?
include("poll_config.php");

$file2=file($file); 
$lineas=count($file2);
$n1=$file2[0];
$n2=$file2[1]; 
$n3=$file2[2];
$n4=$file2[3];


if($En=="E1") 
{$nn1=intval($n1)+1;}else{$nn1=intval($n1);} 
if($En=="E2") 
{$nn2=intval($n2)+1;}else{$nn2=intval($n2);} 
if($En=="E3")
{$nn3=intval($n3)+1;}else{$nn3=intval($n3);} 
if($En=="E4") 
{$nn4=intval($n4)+1;}else{$nn4=intval($n4);} 

	$fp=fopen($file,"w+");
	fwrite($fp,"$nn1\n$nn2\n$nn3\n$nn4"); 
	fclose($fp); 

$ntotal=$nn1+$nn2+$nn3+$nn4; 

?>
<table width="146" border="0" cellpadding="0" cellspacing="0" background="img/poll_bgimg_u_gunz.gif" style="background-repeat: repeat-y; background-position:center;">
  <tr>
    <td colspan="3"><strong><img src="img/poll_topimg_u_gunz.gif" width="146" height="21"></strong></td>
  </tr>
  <tr>
    <td height="5" colspan="4" align="center" class="estilo1"></td>
  </tr>
  <tr>
    <td colspan="4" align="center" class="estilo1"><font color="#666666">Do u like this web?</font></td>
  </tr>
  <tr>
    <td colspan="4" align="center" class="estilo1">------------------------</td>
  </tr>
  <tr>
    <td width="10" align="center" class="estilo5"></td>
    <td width="131" align="left" class="estilo5"><? echo $c1;?> = ( <b><? echo $nn1;?></b> )</td>
    <td width="10" align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="left" class="estilo5"></td>
    <td align="left" class="estilo5"><table width="100%" height="1" border="0" cellpadding="0" cellspacing="0"
    bgcolor="#FFFFFF">
      <tr>
        <td width="100%"><table border="0" cellpadding="0" cellspacing="0" width="<? echo $nn1*100/$ntotal;?>"
        bgcolor="#666666" height="3">
            <tr>
              <td></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="left" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td align="left" class="estilo5"><font face="Arial"><? echo $c2;?> = (<b> <? echo $nn2;?> </b>)</td>
    <td align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="left" class="estilo5"></td>
    <td align="left" class="estilo5"><table width="100%" height="1" border="0" cellpadding="0" cellspacing="0"
    bgcolor="#FFFFFF">
      <tr>
        <td width="100%"><table border="0" cellpadding="0" cellspacing="0" width="<? echo $nn2*100/$ntotal;?>"
        bgcolor="#666666" height="3">
            <tr>
              <td></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="left" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td align="left" class="estilo5"><? echo $c3;?> = (<b> <? echo $nn3;?> </b>) </td>
    <td align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="left" class="estilo5"></td>
    <td align="left" class="estilo5"><table width="100%" height="1" border="0" cellpadding="0" cellspacing="0"
    bgcolor="#FFFFFF">
      <tr>
        <td width="100%"><table border="0" cellpadding="0" cellspacing="0" width="<? echo $nn3*100/$ntotal;?>"
        bgcolor="#666666" height="3">
            <tr>
              <td></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="left" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td align="left" class="estilo5"><? echo $c4;?> = (<b> <? echo $nn4;?> </b>)</td>
    <td align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="left" class="estilo5"></td>
    <td align="left" class="estilo5"><table width="100%" height="1" border="0" cellpadding="0" cellspacing="0"
    bgcolor="#FFFFFF">
      <tr>
        <td width="100%"><table border="0" cellpadding="0" cellspacing="0" width="<? echo $nn4*100/$ntotal;?>"
        bgcolor="#666666" height="3">
            <tr>
              <td></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
    <td align="left" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td height="5" align="center" class="estilo5"></td>
    <td align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td align="center" class="estilo5">Total :<strong> ( <? echo $ntotal;?> )</strong></td>
    <td align="center" class="estilo5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo5"></td>
    <td height="5" align="center" class="estilo5"></td>
    <td align="center" class="estilo5"></td>
  </tr>
</table>
