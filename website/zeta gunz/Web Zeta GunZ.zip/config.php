<?
// CONEXION 
$host = "TU-PC\SQLEXPRESS";
$user = "sa";
$pw   = "717asdasn";
$db   = "GunzDB";
// CONFIG WEB
$SERVER = "ZetaGunZ";

// Links de descarga
$LINK1 = "#";
$LINK2 = "#";
$LINK3 = "#";
// Redes sociales
$facebook = "#";
$youtube = "#";
$twitter = "#";


$c = mssql_connect($host,$user,$pw);
mssql_select_db($db,$c);
// SECURE Y CONFIG NO TOCAR
function clean($sql)
{
$sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
$sql = trim($sql);
$sql = strip_tags($sql);
$sql = addslashes($sql);
return $sql;
}
function GetKDRatio($kills, $deaths)
{
    $total = $kills + $deaths;

    $percent = @round((100 * $kills) / $total, 2);

    if($kills == 0 && $deaths == 0)
    {
        return "0/0 (100%)";
    }else{
        return sprintf("%d/%d (%d%%)", $kills, $deaths, $percent);
    }
}

if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

?>