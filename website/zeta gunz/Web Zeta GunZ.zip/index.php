<?php
include_once ("config.php");
if(isset($_GET['action'])){
$page = $_GET['action'];
switch($page)
{
	case 'register':
	if(isset($_POST['register']))
	{
		$userid = clean($_POST['usuario']);
      $name   = clean($_POST['nombre']);
      $pais   = clean($_POST['pais']);
      $clave1 = clean($_POST['clave1']);
      $clave2 = clean($_POST['clave2']);
      $email1 = clean($_POST['email1']);
      $email2 = clean($_POST['email2']);
      $codigo = clean($_POST['codigo']);
      if(empty($userid) || empty($name) || empty($pais) || empty($clave1) || empty($clave2) || empty($email1) || empty($email2) || empty($codigo))
      {
         msgbox("No deje vacios los campos de registro.","index.php");
      }
      if(!is_numeric($codigo)){ msgbox("Error ingrese solo numeros en codigo.","index.php"); }elseif(strlen($codigo) != 8){ msgbox("Error ingrese 8 digitos en codigo secreto Pin GHOSTGUNZ","index.php"); }
      
     if(mssql_num_rows(mssql_query("SELECT * From Account WHERe UserID='".$userid."'")) != 0 || mssql_num_rows(mssql_query("SELECT * From Account WHERe Email='".$email1."'")) != 0)
      {
         msgbox("Error el userid o email ya esta siendo usado.","index.php");
      }
      if($clave1 != $clave2)
      {
         msgbox("Error contrase�as no son iguales","index.php");
      }
     if($email1 != $email2)
      {
         msgbox("Error Email no son iguales","index.php");
      }

      $reg = "INSERT INTO Account (UserID, UGradeID, PGradeID, Name, ZipCode, RegDate, Email, Codigo) VALUES ('$userid', '0', '0', '$name', '$pais', GETDATE(), '$email1', '$codigo')";
      if(mssql_query($reg))
      {
         $queryaccount = mssql_query("SELECT * From Account WHERE UserID='".$userid."'");
         $acc = mssql_fetch_object($queryaccount);
         $aid = $acc->AID;
         if(mssql_query("INSERT INTO Login (Userid, AID, Password) VALUES ('$userid', '$aid', '$clave1')"))
            msgbox("Bienvenido usuario: $userid  ha sido registrado con exito.","index.php");
      }

	} 
	break;
}
}
	
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"/>
<title><?=$SERVER?> LatinoAmerica</title>

<link rel='shortcut icon' type='image/x-icon' href='Images/favicon.ico'/>
<link href="Styles/bootstrap.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.html">
<link href="Styles/styles1.css" rel="stylesheet" type="text/css"/>
<script src="Scripts/jquery-1.7.1.min.js"></script>
<link rel="stylesheet" href="Styles/jquery.fancybox.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="Styles/bgstretcher.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="Styles/supersized.shutter.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="Styles/jquery.jscrollpane.css" type="text/css" media="screen"/>
<script src="Scripts/bgstretcher.js"></script>
<script type="text/javascript" src="Scripts/jquery.easing.min.js">
</script>
<script type="text/javascript" src="Scripts/jquery.fancybox.js"></script>
<script type="text/javascript" src="Scripts/jquery.jscrollpane.js"></script>
<script type="text/javascript" src="Scripts/jquery.mousewheel.js"></script>
<script type="text/javascript" src="Scripts/jquery.nuevoforo.js"></script>
<script language="Javascript">
   document.oncontextmenu = function() {
      return false
   }
   function right(e) {
      var msg = "Accion invalida!, no usar click derecho";
      if (navigator.appName == 'Netscape' && e.which == 3) {
         alert(msg); //- Si no quieres asustar a tu usuario entonces quita esta linea...
         return false;
      }
      else if (navigator.appName == 'Microsoft Internet Explorer' && event.button==2) {
         alert(msg); //- Si no quieres asustar al usuario que utiliza IE,  entonces quita esta linea...
                        //- Aunque realmente se lo merezca...
      return false;
      }
   return true;
}
document.onmousedown = right;
</script>
</head>
<body oncontextmenu='return false'>

<div id='header'>
<div id='lnkHome'></div>
<div id='lnkRegistro'></div>
<div id='lnkRanking'></div>
<div id='lnkGetGame'></div>
<div id='lnkSupport'></div>
<div id='lnkForum'></div>
</div>

<a id="prevslide" class="load-item"></a>
<a id="nextslide" class="load-item"></a>
<div id="mainBody" style="clear:both;">
<div id="dvHome">
<div style="padding-top:70px;">
<div id="HomeLogo"></div>
<div id="HomeTextBackground"></div>
<div id="HomeText">
<div style="width:660px;float:left;padding-left:40px;padding-right:20px;">
<div><img src="Images/about-the-game.png" style="padding-bottom:10px;"/></div>Gunz:es un videojuego del g�nero multijugador para Windows, similar a otros populares juegos de acci�n en tercera persona, pero incorporando algunas caracter�sticas propias de juegos de rol. Desarrollado por una empresa sur coreana, MAIET Entertainment. Nuestro servidor privado es de acceso gratuito y las donaciones solo cubren gastos de mantenimiento.
</div><div style="width:820px;float:left;clear:both;padding:20px 0px 0px 270px;">
<div><img src="Images/why-warz.png" style="padding-bottom:10px;"/></div>
<?=$SERVER?>: Somos un servidor con a�os de experiencia en entretenimiento. En esta <br>nueva version ya se han mejorado todo lo necesario para que seamos tu encuentro <br>de diversion con tus amigos y futuros amigos. Que esperas Unete Ya! Te esperamos <br>Lets Rock!.
</div>
</div>
<div id="girl"></div>
<div id="spot">
<a href="http://894c48f8.yyv.co/"><div id="videoPlay"></div></a>
</div>
<div id="VideoContent">
<div style="margin-left: 60px; margin-bottom: -10px;"><img src="Images/video.png" style=""/></div>
<div style="margin-left:88px;">
<a href="<?=$facebook?>"><img src="Images/facebook.png" width="25"> </a>
<a href="<?=$twitter?>"><img src="Images/twitter.png" width="25"> </a>
<a href="<?=$youtube?>"><img src="Images/youtube.png" width="25"> </a>
</div>
</div>
</div>
</div>

<div id="dvRegistro" style="display:none;">
<div id="featuresGuy"></div>
<div id="featuresContent">
<div id="scrollbarFeatures">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="FeaturesBack">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:55px;">
<span class="featureLabel">REGISTRO EN <?=$SERVER?></span>
</div>
<div class="FeatureText">
Al registrarte en <?=$SERVER?> estas aceptando los Terminos y Condiciones de Servicio de <?=$SERVER?> Latinoamerica<br>
Ingresar email valido con el cual activara su cuenta, y un CODIGO SECRETO de 8 digitos que pueda memorizar para poder recuperar sus datos en caso de perdida, olvido o robo.
<div style="float:right;padding-right:28px;padding-top:20px;">
<form class="form-horizontal" action="index.php?action=register" method="post" id="regform">
<fieldset>
<div class="control-group warning">
<label class="control-label" for="inputWarning">Usuario: </label>
<div class="controls">
<input type="text" name="usuario" maxlength="12" id="inputWarning">
<span class="help-inline"> </span>
</div>
</div>
<div class="control-group warning">
<label class="control-label" for="inputWarning">Nombre: </label>
<div class="controls">
<input type="text" name="nombre" maxlength="12" id="inputWarning">
<span class="help-inline"> </span>
</div>
</div>
<div class="control-group warning">
<label class="control-label" for="inputWarning">Pais: </label>
<div class="controls">
<select name="pais">
<option value="AF" selected>Afganist�n</option>
<option value="AL">Albania</option>
<option value="DE">Alemania</option>
<option value="AD">Andorra</option>
<option value="AO">Angola</option>
<option value="AI">Anguilla</option>
<option value="AQ">Ant�rtida</option>
<option value="AG">Antigua y Barbuda</option>
<option value="AN">Antillas Holandesas</option>
<option value="SA">Arabia Saud�</option>
<option value="DZ">Argelia</option>
<option value="AR">Argentina</option>
<option value="AM">Armenia</option>
<option value="AW">Aruba</option>
<option value="AU">Australia</option>
<option value="AT">Austria</option>
<option value="AZ">Azerbaiy�n</option>
<option value="BS">Bahamas</option>
<option value="BH">Bahrein</option>
<option value="BD">Bangladesh</option>
<option value="BB">Barbados</option>
<option value="BE">B�lgica</option>
<option value="BZ">Belice</option>
<option value="BJ">Benin</option>
<option value="BM">Bermudas</option>
<option value="BY">Bielorrusia</option>
<option value="MM">Birmania</option>
<option value="BO">Bolivia</option>
<option value="BA">Bosnia y Herzegovina</option>
<option value="BW">Botswana</option>
<option value="BR">Brasil</option>
<option value="BN">Brunei</option>
<option value="BG">Bulgaria</option>
<option value="BF">Burkina Faso</option>
<option value="BI">Burundi</option>
<option value="BT">But�n</option>
<option value="CV">Cabo Verde</option>
<option value="KH">Camboya</option>
<option value="CM">Camer�n</option>
<option value="CA">Canad�</option>
<option value="TD">Chad</option>
<option value="CL">Chile</option>
<option value="CN">China</option>
<option value="CY">Chipre</option>
<option value="VA">Ciudad del Vaticano (Santa Sede)</option>
<option value="CO">Colombia</option>
<option value="KM">Comores</option>
<option value="CG">Congo</option>
<option value="CD">Congo, Rep�blica Democr�tica del</option>
<option value="KR">Corea</option>
<option value="KP">Corea del Norte</option>
<option value="CI">Costa de Marf�l</option>
<option value="CR">Costa Rica</option>
<option value="HR">Croacia (Hrvatska)</option>
<option value="CU">Cuba</option>
<option value="DK">Dinamarca</option>
<option value="DJ">Djibouti</option>
<option value="DM">Dominica</option>
<option value="EC">Ecuador</option>
<option value="EG">Egipto</option>
<option value="SV">El Salvador</option>
<option value="AE">Emiratos �rabes Unidos</option>
<option value="ER">Eritrea</option>
<option value="SI">Eslovenia</option>
<option value="ES">Espa�a</option>
<option value="US">Estados Unidos</option>
<option value="EE">Estonia</option>
<option value="ET">Etiop�a</option>
<option value="FJ">Fiji</option>
<option value="PH">Filipinas</option>
<option value="FI">Finlandia</option>
<option value="FR">Francia</option>
<option value="GA">Gab�n</option>
<option value="GM">Gambia</option>
<option value="GE">Georgia</option>
<option value="GH">Ghana</option>
<option value="GI">Gibraltar</option>
<option value="GD">Granada</option>
<option value="GR">Grecia</option>
<option value="GL">Groenlandia</option>
<option value="GP">Guadalupe</option>
<option value="GU">Guam</option>
<option value="GT">Guatemala</option>
<option value="GY">Guayana</option>
<option value="GF">Guayana Francesa</option>
<option value="GN">Guinea</option>
<option value="GQ">Guinea Ecuatorial</option>
<option value="GW">Guinea-Bissau</option>
<option value="HT">Hait�</option>
<option value="HN">Honduras</option>
<option value="HU">Hungr�a</option>
<option value="IN">India</option>
<option value="ID">Indonesia</option>
<option value="IQ">Irak</option>
<option value="IR">Ir�n</option>
<option value="IE">Irlanda</option>
<option value="BV">Isla Bouvet</option>
<option value="CX">Isla de Christmas</option>
<option value="IS">Islandia</option>
<option value="KY">Islas Caim�n</option>
<option value="CK">Islas Cook</option>
<option value="CC">Islas de Cocos o Keeling</option>
<option value="FO">Islas Faroe</option>
<option value="HM">Islas Heard y McDonald</option>
<option value="FK">Islas Malvinas</option>
<option value="MP">Islas Marianas del Norte</option>
<option value="MH">Islas Marshall</option>
<option value="UM">Islas menores de Estados Unidos</option>
<option value="PW">Islas Palau</option>
<option value="SB">Islas Salom�n</option>
<option value="SJ">Islas Svalbard y Jan Mayen</option>
<option value="TK">Islas Tokelau</option>
<option value="TC">Islas Turks y Caicos</option>
<option value="VI">Islas V�rgenes (EE.UU.)</option>
<option value="VG">Islas V�rgenes (Reino Unido)</option>
<option value="WF">Islas Wallis y Futuna</option>
<option value="IL">Israel</option>
<option value="IT">Italia</option>
<option value="JM">Jamaica</option>
<option value="JP">Jap�n</option>
<option value="JO">Jordania</option>
<option value="KZ">Kazajist�n</option>
<option value="KE">Kenia</option>
<option value="KG">Kirguizist�n</option>
<option value="KI">Kiribati</option>
<option value="KW">Kuwait</option>
<option value="LA">Laos</option>
<option value="LS">Lesotho</option>
<option value="LV">Letonia</option>
<option value="LB">L�bano</option>
<option value="LR">Liberia</option>
<option value="LY">Libia</option>
<option value="LI">Liechtenstein</option>
<option value="LT">Lituania</option>
<option value="LU">Luxemburgo</option>
<option value="MK">Macedonia, Ex-Rep�blica Yugoslava de</option>
<option value="MG">Madagascar</option>
<option value="MY">Malasia</option>
<option value="MW">Malawi</option>
<option value="MV">Maldivas</option>
<option value="ML">Mal�</option>
<option value="MT">Malta</option>
<option value="MA">Marruecos</option>
<option value="MQ">Martinica</option>
<option value="MU">Mauricio</option>
<option value="MR">Mauritania</option>
<option value="YT">Mayotte</option>
<option value="MX">M�xico</option>
<option value="FM">Micronesia</option>
<option value="MD">Moldavia</option>
<option value="MC">M�naco</option>
<option value="MN">Mongolia</option>
<option value="MS">Montserrat</option>
<option value="MZ">Mozambique</option>
<option value="NA">Namibia</option>
<option value="NR">Nauru</option>
<option value="NP">Nepal</option>
<option value="NI">Nicaragua</option>
<option value="NE">N�ger</option>
<option value="NG">Nigeria</option>
<option value="NU">Niue</option>
<option value="NF">Norfolk</option>
<option value="NO">Noruega</option>
<option value="NC">Nueva Caledonia</option>
<option value="NZ">Nueva Zelanda</option>
<option value="OM">Om�n</option>
<option value="NL">Pa�ses Bajos</option>
<option value="PA">Panam�</option>
<option value="PG">Pap�a Nueva Guinea</option>
<option value="PK">Paquist�n</option>
<option value="PY">Paraguay</option>
<option value="PE">Per�</option>
<option value="PN">Pitcairn</option>
<option value="PF">Polinesia Francesa</option>
<option value="PL">Polonia</option>
<option value="PT">Portugal</option>
<option value="PR">Puerto Rico</option>
<option value="QA">Qatar</option>
<option value="UK">Reino Unido</option>
<option value="CF">Rep�blica Centroafricana</option>
<option value="CZ">Rep�blica Checa</option>
<option value="ZA">Rep�blica de Sud�frica</option>
<option value="DO">Rep�blica Dominicana</option>
<option value="SK">Rep�blica Eslovaca</option>
<option value="RE">Reuni�n</option>
<option value="RW">Ruanda</option>
<option value="RO">Rumania</option>
<option value="RU">Rusia</option>
<option value="EH">Sahara Occidental</option>
<option value="KN">Saint Kitts y Nevis</option>
<option value="WS">Samoa</option>
<option value="AS">Samoa Americana</option>
<option value="SM">San Marino</option>
<option value="VC">San Vicente y Granadinas</option>
<option value="SH">Santa Helena</option>
<option value="LC">Santa Luc�a</option>
<option value="ST">Santo Tom� y Pr�ncipe</option>
<option value="SN">Senegal</option>
<option value="SC">Seychelles</option>
<option value="SL">Sierra Leona</option>
<option value="SG">Singapur</option>
<option value="SY">Siria</option>
<option value="SO">Somalia</option>
<option value="LK">Sri Lanka</option>
<option value="PM">St. Pierre y Miquelon</option>
<option value="SZ">Suazilandia</option>
<option value="SD">Sud�n</option>
<option value="SE">Suecia</option>
<option value="CH">Suiza</option>
<option value="SR">Surinam</option>
<option value="TH">Tailandia</option>
<option value="TW">Taiw�n</option>
<option value="TZ">Tanzania</option>
<option value="TJ">Tayikist�n</option>
<option value="TF">Territorios franceses del Sur</option>
<option value="TP">Timor Oriental</option>
<option value="TG">Togo</option>
<option value="TO">Tonga</option>
<option value="TT">Trinidad y Tobago</option>
<option value="TN">T�nez</option>
<option value="TM">Turkmenist�n</option>
<option value="TR">Turqu�a</option>
<option value="TV">Tuvalu</option>
<option value="UA">Ucrania</option>
<option value="UG">Uganda</option>
<option value="UY">Uruguay</option>
<option value="UZ">Uzbekist�n</option>
<option value="VU">Vanuatu</option>
<option value="VE">Venezuela</option>
<option value="VN">Vietnam</option>
<option value="YE">Yemen</option>
<option value="YU">Yugoslavia</option>
<option value="ZM">Zambia</option>
<option value="ZW">Zimbabue</option>
</select>
<span class="help-inline"> </span>
</div>
</div>
<div class="control-group error">
<label class="control-label" for="inputError">Clave: </label>
<div class="controls">
<input type="password" name="clave1" maxlength="12" id="inputError">
<span class="help-inline"></span>
</div>
</div>
<div class="control-group error">
<label class="control-label" for="inputError">Repetir Clave: </label>
<div class="controls">
<input type="password" name="clave2" maxlength="12" id="inputError">
<span class="help-inline"></span>
</div>
</div>
<div class="control-group warning">
<label class="control-label" for="inputWarning">Email (valido): </label>
<div class="controls">
<input type="text" name="email1" maxlength="35" id="inputWarning">
<span class="help-inline"></span>
</div>
</div>
<div class="control-group warning">
<label class="control-label" for="inputWarning">Confirmar Email: </label>
<div class="controls">
<input type="text" name="email2" maxlength="35" id="inputWarning">
<span class="help-inline"></span>
</div>
</div>
<div class="control-group error">
<label class="control-label" for="inputError">Codigo Secreto: </label>
<div class="controls">
<input type="text" onkeypress="return isNumberKey(event)" name="codigo" maxlength="8" id="inputWarning">
<span class="help-inline"></span>
</div>
</div>

<div class="form-actions">
<button type="submit" class="btn btn-primary" name="register">Registrar</button>
<button class="btn" name="clear" type="reset">Cancelar</button>
</div>
</fieldset>
</form>
<script type="text/javascript">
   function isNumberKey(evt)
   {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if(!((event.keyCode>=48&&event.keyCode<=57)|| (event.keyCode==46)))
            return false;

         return true;
   }
   </script>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="dvRanking" style="display:none;">
<div id="featuresGuy2"></div>
<div id="mediaContent">
<div id="mediaScreenShots" style="">
<div id="scrollbar1">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="overview">
<div class="FeaturesBack">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:250px;">
<span class="featureLabel">LOS MEJORES JUGADORES</span>
<div class="FeatureText2">En la lista se encuentran los jugadores mas destacados de <?=$SERVER?> LatinoAmerica
<table class="table table-condensed">
<thead>
<tr>
<th> </th><th> </th><th> </th>
<th><font color=white>Rank</th>
<th><font color=white>Personaje</th>
<th><font color=white>Lvl</th>
<th><font color=white>Exp</th>
<th><font color=white>Kill / Death Ratio</th>
</tr>
</thead>
<tbody>

<?
$rankplayer = mssql_query("SELECT TOP 20  XP, Name, Level, KillCount, DeathCount From Character WHERE DeleteFlag ='0' Order By XP Desc");
$rp = 1;
while($p=mssql_fetch_array($rankplayer)){
?>
<tr> <tr> <td> </td><td> </td><td> </td><td><font color=orange><?=$rp++?></td><td>
<font color=orange><?=$p[1]?></td><td><font color=orange><?=$p[2]?>Lvl. </td><td><font color=orange><?=$p[0]?></td>
<td><font color=orange><?=GetKDRatio($p[3],$p[4])?></td>
<? }?>


</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="mediaVideos">
<div id="scrollbar1a">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="overview">
<div class="FeaturesBack2">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:250px;">
<span class="featureLabel">LOS MEJORES CLANES</span>
<div class="FeatureText2">En la lista se encuentran los clanes mas destacados de <?=$SERVER?> LatinoAmerica<BR><BR>
<table class="table table-condensed">
<thead>
<tr>
<th> </th><th> </th><th> </th>
<th><font color=white>Rank</th>
<th><font color=white>Emblema</th>
<th><font color=white>Nombre Clan</th>
<th><font color=white>Point</th>
<th><font color=white>Win / Losses Ratio</th>
</tr>
</thead>
<tbody>
   <?
   $rankclan = mssql_query("SELECT TOP 20 Name, Point, Losses, Wins From  Clan WHERE DeleteFlag='0' Order By Point Desc");
   $rc = 1;
      while($c = mssql_fetch_array($rankclan)){
   ?>
<tr> <td> </td><td> </td><td> </td><td><font color=orange><?=$rc++?></td><td>
<font color=orange><img src='http://i.imgur.com/Q3lHDBD.png' width=50 height=50></td><td><font color=orange><?=$c[0]?> </td><td><font color=orange><?=$c[1]?></td>
<td><font color=orange>88 / 28 (0)%<?=GetKDRatio($c[3],$c[2])?></td>

<? }?>


<tr> 
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="mediaWallpapers" style="overflow:auto; height:500px;display:none;">
<div id="scrollbar1">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="overview">
<div class="FeaturesBack3">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:250px;">
<span class="featureLabel">LOS MEJORES JUGADORES LADDER</span>
<div class="FeatureText2">En la lista se encuentran los jugadores en Ladder Clan mas destacados de <?=$SERVER?> LatinoAmerica
<table class="table table-condensed">
<thead>
<tr>
<th> </th><th> </th><th> </th>
<th><font color=white>Rank</th>
<th><font color=white>Personaje</th>
<th><font color=white>Ladder</th>
<th><font color=white>Lvl</th>
<th><font color=white>Kill / Death Ratio</th>
</tr>
</thead>
<tbody>
<tr> <td> </td><td> </td><td> </td><td><font color=orange>1</td><td>
<font color=orange>sacker</td><td><font color=orange>21 Pts. </td><td><font color=orange>60 Lvl.</td>
<td><font color=orange>2821 / 2105 (57.27)%</td><tr> </tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="mediaSketches">
<div id="scrollbar1">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="overview">
<div class="FeaturesBack4">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:250px;">
<span class="featureLabel">LOS MEJORES JUGADORES DUELTOURNAMENT</span>
<div class="FeatureText2">En la lista se encuentran los jugadores de DuelTournament mas destacados de <?=$SERVER?> LatinoAmerica
<table class="table table-condensed">
<thead>
<tr>
<th> </th><th> </th><th> </th>
<th><font color=white>Rank</th>
<th><font color=white>Personaje</th>
<th><font color=white>DT Points</th>
<th><font color=white>Trofeos</th>
<th><font color=white>Win / Losses Ratio</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div id="mediaMenu">
<div id='lnkShots'></div>
<div id='lnkVideos'></div>
<div id='lnkWallpapers'></div>
<div id='lnkSketches'></div>
</div>
</div></div>
<div id="dvGetGame" style="display:none;padding-left: 290px; padding-top: 220px;width:900px;">
<div id="featuresGuy3"></div>
<div id="featuresContent">
<div id="scrollbarFeatures">
<div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div>
<div class="viewport">
<div class="FeaturesBack">
<div style="padding-left:95px;">
<div style="float:left;padding-top:20px;padding-left:150px;">
<span class="featureLabel">DESCARGAR CLIENTE COMPLETO</span>
<div class="FeatureText4">
En la siguiente lista de descargas, podras obtener el instalador de <?=$SERVER?> LatinoAmerica, peso aproximado 530mb, incluye sonido y autoupdater:
<br><br><br>
<br>
<div align="center">
<b>Mediafire Instalador Full (30/07/13):</b><br><br>
<a href="<?=$LINK1?>"><img src="img/mediafireon.png" onmouseover="this.src='img/mediafireoff.png';" onmouseout="this.src='img/mediafireon.png';"/></a>
<br><br>
<b>MEGA Instalador Full (30/07/13):</b><br><br>
<a href="<?=$LINK2?>"><img src="img/mega.png" onmouseover="this.src='img/megaoff.png';" onmouseout="this.src='img/mega.png';"/></a>
<br><br>
<b>MULTIUPLOAD Instalador Full (30/07/13):</b><br><br>
<a href="<?=$LINK3?>"><img src="img/multion.png" onmouseover="this.src='img/multioff.png';" onmouseout="this.src='img/multion.png';"/></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 
<div id="dvSupport" style="display:none;padding-left: 290px; padding-top: 220px;width:900px;">
<div id="dvGameMsg" style="padding-top:40px;width:1070px;">
<img src="Images/warning.png"/>
<div id="btnBack"></div>
</div>
</div>
</div>
<div id="footer">
&#169;Zeta GunZ 2013-2014 <?=$SERVER?> LatinoAmerica - Todos los derechos reservados.
</div>
<div id="dvModal" class="Modal" style="width:850px;">
<div class="ModalContent" style="width:850px;height:477px;background-image:url('Images/frame.png');">
<div style="padding: 41px 22px 20px 30px; height: 393px;">
<img src="Images/sample.html" style="width: 794px; height: 395px;"/>
</div>
</div>
</div>
</body>

</html>
