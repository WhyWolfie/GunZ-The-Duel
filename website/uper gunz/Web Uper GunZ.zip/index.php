<?php
include("secure/config.php");
include("secure/functions.php");
include("secure/include.php");

if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "Fresh | Home - �La Batalla apenas comienza!", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" />
<title>%TITLE%</title>
<link href="favicon.ico" rel="shortcut icon" />
<script language="JavaScript">
<!--

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("No tienes suficientes Coins para comprar por " + SelectedDays + " Dias");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->
</script>
<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>

 <script language="javascript" type="text/javascript">
        //<!-- <![CDATA[
        function msgbox(mensaje) {
                alert(mensaje);
        };
        // ]]> -->
</script>


</head>
<link type="text/css" rel="stylesheet" href="website.css" />
<link type="text/css" rel="stylesheet" href="menu.css" />

<body>

<div id="menu">

<div id="display">

<table width="100%" border="0" align="center">
  <tr>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%"></td>
    <td width="14.18%"></td>
  </tr>
  <tr>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%"><a href="index.php?do=download">Launcher</a></td>
    <td width="14.18%"><a href="index.php?do=clanrank">Clan</a></td>
    <td width="14.18%"><a href="index.php?do=shopevent">Store Event</a></td>
    <td width="14.18%"><a href="#">Report</a></td>
    <td width="14.18%"><a href="http://www.facebook.com/QuanticGamerz">Facebook</a></td>
  </tr>
  <tr>
    <td width="14.18%">&nbsp;</td>
    <td width="14.18%"><a href="index.php?do=register">User Normal</a></td>
    <td width="14.18%"><a href="index.php?do=download">Client</a></td>
    <td width="14.18%"><a href="index.php?do=individualrank">Individual</a></td>
    <td width="14.18%"><a href="index.php?do=shopdonator">Store Donator</a></td>
    <td width="14.18%"><a href="#GunzGeneral Forum">General</a></td>
    <td width="14.18%"><a href="http://www.youtube.com">Youtube</a></td>
  </tr>
</table>


</div>

<div id="static" align="center">

<table width="100%" border="0" align="center">
  <tr>
    <td width="14.18%"><a href="index.php">HOME</a></td>
    <td width="14.18%"><a href="index.php?do=register">REGISTER</a></td>
    <td width="14.18%"><a href="index.php?do=download">DOWNLOAD</a></td>
    <td width="14.18%"><a href="index.php?do=individualrank">RANKING</a></td>
    <td width="14.18%"><a href="index.php?do=shopdonator">STORE</a></td>
    <td width="14.18%"><a href="#">FORUM</a></td>
    <td width="14.18%"><a href="#">OTHER</a></td>
  </tr>
</table>

</div>

</div>


<div id="background">

<div class="msgweb" align="center">

<? include "server.php"; ?>

</div>

</div>


<table height="340" align="center" width="1">
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>



<table id="showmensajee" align="center">
  <tr>
    <td align="center">
    
	<?
		if($_SESSION['SiteMessage']== "" && $_SESSION['AID'] == "")
		{/*
			SetMessage("", array("<a href=\"index.php\"><b>FreshGamers Gunz</b></a> Todos los Derechos Reservados. ",
			"Haz click <a href=\"index.php?do=register\"><b>aqu�</b>  para registrarte</a>",
			"Haz click <a href=\"index.php?do=register\"><b>AQUI</b> para ver Clanes de FreshGamers y los ultimos Clan War",
			"Haz click <a href=\"index.php?do=Shop\"><b>AQUI</b> para ver los nuevos Items Shop de FreshGamers Gunz"));*/
		}
		echo $_SESSION[SiteMessage];
		
		$_SESSION[SiteMessage]="";
    ?>
    
    </td>
  </tr>
</table>


<table id="contentbox" align="center">
  <tr valign="top" align="center">
   <td>
   
   
   
   <table width="240" align="center">
        <tr valign="top" align="center">
        <td>
        
        <div id="headerbox240" align="center"><a class="title">Login</a></div>
        <div id="contentbox240" align="center">
        
        <? include "blocks/block_login.php";?>
        
        </div>
        
        <div id="footerbox240" align="center"></div>
        </td>
      </tr>
    </table>
   
   
    
    <table width="240" align="center">
        <tr valign="top" align="center">
        <td>
        
        <div id="headerbox240nobg" align="center"></div>
        <div id="contentbox240" align="center">
        
        <? include "blocks/otherlinks_izquierda.php";?>
        
        </div>
        
        <div id="footerbox240" align="center"></div>
        </td>
      </tr>
    </table>
    
    </td>
    <td align="center" valign="top">
     <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();
                    ?>
                    <?
                }else{
                    SetMessage("Un Error ha ocurrido", array("El Modulo seleccionado no existe."));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>
    </td>
    <td align="center">
    
    <div id="headerbox240" align="center"><a class="title">Ranking Player</a></div>
    <div id="contentbox240" align="center">
    
   <? include 'blocks/block_rankingu.php' ?>
    
    </div>
    <div id="footerbox240" align="center"></div>
    
    <br />
    
     <div id="headerbox240" align="center"><a class="title">Ranking Clan</a></div>
    <div id="contentbox240" align="center">
    
	<? include "blocks/block_rankingc.php" ?>
    
    </div>
    <div id="footerbox240" align="center"></div>
    
    
    
    <br>
    
    
    
<table width="240" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox240nobg" align="center"></div>
    <div id="contentbox240" align="center">
    
    <? include "blocks/otherlinks_derecha.php";?>
    
    </div>
    
    <div id="footerbox240" align="center"></div>
    </td>
  </tr>
</table>
    
    
    
    </td>
  </tr>
</table>


<table id="showmensaje" align="center"  class="creditos">
  <tr>
    <td>Copyright 2013-2014, Quantic Gamerz. Sitio web dise�ado y modificado por <a href="http://www.facebook.com/andresblanco3l">3ln3n3</a></td>
  </tr>
</table>


</body>
</html>