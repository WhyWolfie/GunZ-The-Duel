<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?
SetTitle("FRESH - GunZ - Subir Emblema");
?>


<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Actualizar emblema del clan</a></div>
    <div id="contentbox500" align="center">
	
	<? include "Emblem/module_emblem.php" ?>
    
    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>


