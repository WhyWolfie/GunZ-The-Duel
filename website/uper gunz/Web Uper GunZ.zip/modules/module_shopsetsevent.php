<?
include("secure/include.php");
SetTitle("FreshGunZ - Tienda");
if( $_SESSION['AID'] == "" )
{
	SetURL("index.php?do=shopsetsevent");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

if ($_GET[sex] == ""){
$sexq = "";
}else{
$sexq = "WHERE Sex = '".strtolower(clean($_GET[sex]))."'";
}

$sex = strtolower(clean($_GET[sex]));

$res = mssql_query_logged("SELECT * FROM ShopSetsEvent(nolock) ".$sexq." ORDER BY SSID DESC");

$count = 1;
$page = 1;
while( $a = mssql_fetch_object( $res ) ){
    $set[$count][$page]['SSID']         =  $a->SSID;
    $set[$count][$page]['Name']         =  $a->Name;
    $set[$count][$page]['Level']        =  $a->Level;
    $set[$count][$page]['Price']        =  $a->Price;
    $set[$count][$page]['Sex']          =  $a->Sex;
    $set[$count][$page]['ImageURL']     =  $a->ImageURL;

    if ( $count == 6 ){
        $count = 1;
        $page++;
    }else{
        $count++;
    }

}

$cpage = ($_GET[page] == "") ? 1 : $_GET[page];

if($cpage > $page)
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopsetsevent");
    die();
}else if(!is_numeric($cpage))
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopsetsevent");
    die();
}

for ($i = 1; $i <= $page; $i++) {
    if($cpage == $i){
        $prefix = "<font color='#00FF00'><b>";
        $sufix = '</b></font>';
    }else{
        $prefix = "";
        $sufix = '';
    }
    $pagelinks.="[<a href='index.php?do=shopsetsevent&page=$i&sex=$sex'>$prefix$i$sufix</a>] ";
}

?>



<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop Set</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="500" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td colspan="2"><a href="index.php?do=shopevent">Items Event</a></td>
        <td colspan="2"><a href="index.php?do=shopsetsevent">Sets Event</a></td>
        <td colspan="2"><a href="index.php?do=shopdonator">Donator Shop</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">

			<form method="GET" name="setlist" action="index.php?do=shopsetsevent">
            <select size="1" name="sex" onchange="document.location = 'index.php?do=shopsetsevent&sex=' + document.setlist.sex.value;">
            <option value="" <?=($_GET[sex] == "") ? "selected" : ""?>>All
            </option>
            <option value="0" <?=($_GET[sex] == "male") ? "selected" : ""?>>Man</option>
            <option value="1" <?=($_GET[sex] == "female") ? "selected" : ""?>>Woman</option>
            </select>
            </form>
            
		</td>
	   </tr>
	   <tr>
        
		<?
        if($set[1][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[1][$cpage]['SSID']?>" title="<?=$set[1][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[1][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[1][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[1][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[1][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        
        <?
        if($set[2][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[2][$cpage]['SSID']?>" title="<?=$set[2][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[2][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[2][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[2][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[2][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        
		<?
        if($set[3][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[3][$cpage]['SSID']?>" title="<?=$set[3][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[3][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[3][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[3][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[3][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        </tr>
        
        
        <tr>
        
		<?
        if($set[4][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[4][$cpage]['SSID']?>" title="<?=$set[4][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[4][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[4][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[4][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[4][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        
        <?
        if($set[5][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[5][$cpage]['SSID']?>" title="<?=$set[5][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[5][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[5][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[5][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[5][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        
		<?
        if($set[6][$cpage]['Name'] <> "")
        {
        ?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buysetevent&setid=<?=$set[6][$cpage]['SSID']?>" title="<?=$set[6][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[6][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[6][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: Set Completo</div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[6][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[6][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>	
        </tr>
        
        <tr class="shopdisplaymenusite">
        	<td colspan="6"><?=$pagelinks?></td>		
   </tr>
</table>
</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>													
