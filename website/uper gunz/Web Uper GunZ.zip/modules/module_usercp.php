<?php
SetTitle("FreshGunZ - UserCP");
?>


<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Panel de usuario</a></div>
    <div id="contentbox500" align="center">
    
<form method="POST" action="index.php?do=changebt" name="changebt">

<table width="500">
  <tr class="subinfo">
    <td width="50%">Lista de Staff</td>
    <td width="50%"><a href="index.php?do=Staff">Click Here</a></td>
  </tr>
  <tr class="subinfo">
    <td>Recuperar personajes</td>
    <td><a href="index.php?do=recoverchar">Click Here</a></td>
  </tr>
  <tr class="subinfo">
    <td>Recuperar Contrase&ntilde;a</td>
    <td><a href="index.php?do=resetpwd">Click Here</a></td>
  </tr>
  <tr class="subinfo">
    <td>Comprar Donator Coins</td>
    <td><a href="index.php?do=donate">Click Here</a></td>
  </tr>
  <tr class="subinfo">
    <td>Cambiar name a un Pj</td>
    <td><a href="index.php?do=changename">Click Here</a></td>
  </tr>
</table>

</form>

		</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>