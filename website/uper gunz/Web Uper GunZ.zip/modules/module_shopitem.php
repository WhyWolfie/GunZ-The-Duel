<?
include("secure/include.php");

SetTitle("QuanticGamers Gunz- Lista de Items");

$sex = ($_GET[sex] == "") ? "2" : strtolower(clean($_GET[sex]));

$cat = ($_GET[cat] == "") ? "3" : strtolower(clean($_GET[cat]));

$sort = ($_GET[sort] == "") ? "0" : strtolower(clean($_GET[sort]));

$bodypart = ($_GET[bodypart] == "") ? "0" : strtolower(clean($_GET[bodypart]));

if($cat == 3 && $sex == "2")
{
    $sex = 3;
}

if($cat != 3 && $bodypart != 0)
{
$bodypart = 0;
}

if($sex == 3)
{
    $append = "";
}else{
    $append = "Sex = $sex AND";
}

$bodypart = ($bodypart < 0 || $bodypart > 5) ? "0" : $bodypart;

if( $bodypart == 0 )
{
    $bodypq = "";
}
else
{
    $bodypq = "AND BodyPart = $bodypart";
}

switch ($sort)
{
    case 0:
    $sortq = "ORDER BY CSSID DESC";
    break;
    case 1:
    $sortq = "ORDER BY CSSID ASC";
    break;
    case 2:
    $sortq = "ORDER BY Level ASC";
    break;
    case 3:
    $sortq = "ORDER BY Level DESC";
    break;
    case 4:
    $sortq = "ORDER BY Price ASC";
    break;
    case 5:
    $sortq = "ORDER BY Price DESC";
    break;
    default:
    $sortq = "ORDER BY CSSID DESC";
    break;
}

if($_GET[cat] == 2 || $_GET[cat] == 1 || $_GET[cat] == 5)
{
    $res = mssql_query_logged("SELECT * FROM ShopItems(nolock) WHERE Slot = $cat $sortq");
}else{
    $res = mssql_query_logged("SELECT * FROM ShopItems(nolock) WHERE $append Slot = $cat $bodypq $sortq");
}

$count = 1;
$page = 1;
while( $a = mssql_fetch_object( $res ) ){
    $set[$count][$page]['SSID']         =  $a->CSSID;
    $set[$count][$page]['Name']         =  $a->Name;
    $set[$count][$page]['Level']        =  $a->Level;
    $set[$count][$page]['Price']        =  $a->Price;
    $set[$count][$page]['Sex']          =  $a->Sex;
    $set[$count][$page]['ImageURL']     =  $a->ImageURL;

    if ( $count == 6 ){
        $count = 1;
        $page++;
    }else{
        $count++;
    }

}

$cpage = ($_GET[page] == "") ? 1 : $_GET[page];

if($cpage > $page)
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopitem");
    die();
}else if(!is_numeric($cpage))
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopitem");
    die();
}

for ($i = 1; $i <= $page; $i++) {
    if($cpage == $i){
        $prefix = "<font color='#00FF00'><b>";
        $sufix = '</b></font>';
    }else{
        $prefix = "";
        $sufix = '';
    }
    $pagelinks.="[<a href='index.php?do=shopitem&page=$i&sex=$sex&sort=$sort&bodypart=$bodypart&cat=$cat'>$prefix$i$sufix</a>] ";
}

switch($cat)
{
    case 3:
        $img = "content_title_shop_armor.jpg";
        $type = "Armadura";
    break;
    case 2:
        $img = "content_title_shop_meleewea.jpg";
        $type = "Espada y Dagas";
    break;
    case 1:
        $img = "content_title_shop_rangedwe.jpg";
        $type = "Armas de Fuego";
    break;
    case 5:
        $img = "content_title_shop_speciali.jpg";
        $type = "Especial";
    break;
    default:
        $img = "content_title_shop_armor.jpg";
        $type = "Armadura";
    break;
}

?>
<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop</a></div>
    <div id="contentbox500" align="center">
	<table width="400" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td><a href="index.php?do=shopsets">Sets</a></td>
        <td><a href="index.php?do=shopevent">Event Items</a></td>
        <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
        <td><a href="index.php?do=nicks">Extra</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr>
        <td colspan="6">
            
                <table width="100%" border="0">
                  <tr>
                    <td width="33.33">
                    
                        <form method="GET" name="setlist" action="index.php?do=shopitem">
                            <?
                            if($_GET[cat] == 3)
                            {
                            $bodypartjs = "'&bodypart=' + document.setlist.bodypart.value +";
                            ?>
                            <select name="bodypart" onChange="document.location = 'index.php?do=shopitem&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + '&bodypart=' + document.setlist.bodypart.value + '&cat=<?=$cat?>';">
                            <option value="0" <?=($_GET[bodypart] == "0") ? "selected" : ""?>>Todos</option>
                            </select>
                            <?
                            }
                            else
                            {
                            $bodypartjs = "";
                            }
                            ?>
                      </td>
                      <td width="33.33">
                            <select <?=($_GET[cat] == 5 || $_GET[cat] == 1 || $_GET[cat] == 2) ? "disabled " : ""?>size="1" name="sex" onChange="document.location = 'index.php?do=shopitem&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + '&bodypart=' + document.setlist.bodypart.value + '&cat=<?=$cat?>';">
                            <?
                            if($_GET[cat] != 3)
                            {
                            ?>
                             <? } ?>
                            <option value="" <?=($_GET[cat] == "") ? "selected" : ""?>>Seleccione Un Sexo</option>
                            <option value="0" <?=($_GET[cat] == "0") ? "selected" : ""?>>Hombre</option>
                            <option value="1" <?=($_GET[cat] == "2") ? "selected" : ""?>>Mujer</option>
                            </select>
                      </td>
                      <td width="33.33">
                            <select name="sort" onChange="document.location = 'index.php?do=shopitem&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + <?=$bodypartjs?> '&cat=<?=$cat?>';">
                            <option value="0" <?=($_GET[sort] == "0") ? "selected" : ""?>>Nuevos Primero</option>
                            <option value="1" <?=($_GET[sort] == "1") ? "selected" : ""?>>Viejos Primero</option>
                            <option value="2" <?=($_GET[sort] == "2") ? "selected" : ""?>>Nivel: Bajo Primero</option>
                            <option value="3" <?=($_GET[sort] == "3") ? "selected" : ""?>>Nivel: Alto Primero</option>
                            <option value="4" <?=($_GET[sort] == "4") ? "selected" : ""?>>Precio: Bajo Primero</option>
                            <option value="5" <?=($_GET[sort] == "5") ? "selecter" : ""?>>Precio: Alto Primero</option>
                            </select>
                        </form>
                    
                    </td>
                  </tr>
					<tr>
                        
				     <?
                        if($set[1][$cpage]['Name'] <> "")
                        {
                        ?>
                        
                        <td width="33.33" style="border:1px dashed #222;">
                            <a href="index.php?do=buyitem&itemid=<?=$set[1][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[1][$cpage]['Price']?> DonadorCoins">
                                <img border="0" src="images/shop/<?=$set[1][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                            </a>
                            <div class="nameitem">Nombre: <?=$set[1][$cpage]['Name']?></div>
                            <div class="sexitem">Sexo: <?=GetSexByID($set[1][$cpage]['Sex']);?></div>	
                            <div class="sexitem">Nivel: <?=$set[1][$cpage]['Level']?></div>											
                        </td>
                        
                    <?
                    }
                    ?>
                    
                    
                    
                    
                    
                    <?
                        if($set[2][$cpage]['Name'] <> "")
                        {
                        ?>
                        
                        <td width="33.33" style="border:1px dashed #222;">
                            <a href="index.php?do=buyitem&itemid=<?=$set[2][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[2][$cpage]['Price']?> DonadorCoins">
                                <img border="0" src="images/shop/<?=$set[2][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                            </a>
                            <div class="nameitem">Nombre: <?=$set[2][$cpage]['Name']?></div>
                            <div class="sexitem">Sexo: <?=GetSexByID($set[2][$cpage]['Sex']);?></div>	
                            <div class="sexitem">Nivel: <?=$set[2][$cpage]['Level']?></div>											
                        </td>
                
                    <?
                    }
                    ?>
                    
                    
                    
                    
                    
                    <?
                    if($set[3][$cpage]['Name'] <> "")
                    {
                    ?>
                    
                    <td width="33.33" style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$set[3][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[3][$cpage]['Price']?> DonadorCoins">
                            <img border="0" src="images/shop/<?=$set[3][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                        </a>
                        <div class="nameitem">Nombre: <?=$set[3][$cpage]['Name']?></div>
                        <div class="sexitem">Sexo: <?=GetSexByID($set[3][$cpage]['Sex']);?></div>	
                        <div class="sexitem">Nivel: <?=$set[3][$cpage]['Level']?></div>											
                    </td>
                
                    <?
                    }
                    ?>
                    
                    
                    </tr>
                  	<tr>
                    
                    
                    <?
                    if($set[4][$cpage]['Name'] <> "")
                    {
                    ?>
                    
                    <td width="33.33" style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$set[4][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[4][$cpage]['Price']?> DonadorCoins">
                            <img border="0" src="images/shop/<?=$set[4][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                        </a>
                        <div class="nameitem">Nombre: <?=$set[4][$cpage]['Name']?></div>
                        <div class="sexitem">Sexo: <?=GetSexByID($set[4][$cpage]['Sex']);?></div>	
                        <div class="sexitem">Nivel: <?=$set[4][$cpage]['Level']?></div>											
                    </td>
                
                    <?
                    }
                    ?>
                    
                    
                    <?
                    if($set[5][$cpage]['Name'] <> "")
                    {
                    ?>
                    
                    <td width="33.33" style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$set[5][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[5][$cpage]['Price']?> DonadorCoins">
                            <img border="0" src="images/shop/<?=$set[5][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                        </a>
                        <div class="nameitem">Nombre: <?=$set[5][$cpage]['Name']?></div>
                        <div class="sexitem">Sexo: <?=GetSexByID($set[5][$cpage]['Sex']);?></div>	
                        <div class="sexitem">Nivel: <?=$set[5][$cpage]['Level']?></div>											
                    </td>
                    
                    <?
                    }
                    ?>
                    
                    
                    
                    <?
                        if($set[6][$cpage]['Name'] <> "")
                        {
                        ?>
                        
                        <td width="33.33" style="border:1px dashed #222;">
                            <a href="index.php?do=buyitem&itemid=<?=$set[6][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[6][$cpage]['Price']?> DonadorCoins">
                                <img border="0" src="images/shop/<?=$set[6][$cpage]['ImageURL']?>" width="100" height="100" style="border: 2px solid #171516">
                            </a>
                            <div class="nameitem">Nombre: <?=$set[6][$cpage]['Name']?></div>
                            <div class="sexitem">Sexo: <?=GetSexByID($set[6][$cpage]['Sex']);?></div>	
                            <div class="sexitem">Nivel: <?=$set[6][$cpage]['Level']?></div>											
                        </td>
                        
                    <?
                    }
                    ?>
                    
                    
                  </tr>
                  <tr>
                    <td><div align="center"><?=$pagelinks?></div></td>
                  </tr>
                </table>
                </td>
              </tr>
           </table>
		</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>					

<?
$filhodaputa = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string)
{
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>
