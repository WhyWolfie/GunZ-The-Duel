<?php
include("secure/include.php");

SetTitle("Fresh GunZ - Comprar Item");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buysetsevent&itemid={$_GET[itemid]}");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

if(!isset($_POST[SetID]))
{
    if($_GET[setid] == "" || !is_numeric($_GET[setid]))
    {
        SetMessage("Message from Shop", array("Incorrect item information"));
        header("Location: index.php?do=shopsetsevent");
        die();
    }
}

if(isset($_POST[SetID]))
{
    $setid  = clean($_POST[SetID]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopSetsEvent(nolock) WHERE SSID = $setid");

    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error from Shop", array("Item not found"));
        header("Location index.php?do=shopsetsevent");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account  WHERE AID  = $accid"));

    $totalprice      = $ires->Price;
    $accountbalance = $ares->EventCoins;
    $afterbalance   = $accountbalance - $totalprice;


    if($afterbalance < 0)
    {
        SetMessage("Error tienda.", array("Usten no cuenta con coins suficientes para realizar esta operacion."));
        header("Location: index.php?do=buyset&setid=$setid");
        die();

    }else{
        mssql_query_logged("UPDATE Account SET EventCoins = EventCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
       // mssql_query_logged("UPDATE ShopSets SET Selled = Selled + 1 WHERE SSID = $setid");

        //Head
        if( $ires->HeadItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->HeadItemID}, GETDATE(), 1)");
        }
        //Chest
        if( $ires->ChestItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->ChestItemID}, GETDATE(), 1)");
        }
        //Hand
        if( $ires->HandItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->HandItemID}, GETDATE(), 1)");
        }
        //Leg
        if ( $ires->LegItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->LegItemID}, GETDATE(), 1)");
        }
        //Feet
        if ( $ires->FeetItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->FeetItemID}, GETDATE(), 1)");
        }

        SetMessage("Mensaje de tienda", array("El Set fue comprado con exito. SackerZ"));
        header("Location: index.php?do=shopsetsevent");
        die();

    }
}else{
    $setid  = clean($_GET[setid]);

    $ires = mssql_query_logged("SELECT * FROM ShopSets(nolock) WHERE SSID = $setid");

	// Reparacion by SackerZ
    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error en la tienda", array("Error no existe."));
        header("Location index.php?do=shopsetsevent");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));	$coins =$acd->EventCoins;
		
	
    $data = mssql_fetch_object($ires);
	$itemp = $data->Price;
	$balan = $coins-$itemp;
	
}

?>




<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop Set</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="490" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td colspan="2"><a href="index.php?do=shopevent">Items Event</a></td>
        <td colspan="2"><a href="index.php?do=shopsetsevent">Sets Event</a></td>
        <td colspan="2"><a href="index.php?do=shopdonator">Donator Shop</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">


<form method="POST" action="index.php?do=buyset" name="frmBuy">
		
        
<table width="490" border="0">
  <tr>
    <td rowspan="6" width="50%"><img border="0" src="images/shop/<?=$data->ImageURL?>" width="80" height="80" style="border: 2px solid #1D1B1C"></td> 
  </tr>
  <tr>
  	<td  width="50%">Nombre: <?=$data->Name?></td>
  </tr>
  <tr>
    <td>Tipo: Set Completo</td>
  </tr>
  <tr>
    <td>Sexo: <?=GetSexByID($data->Sex)?></td>
  </tr>
  <tr>
    <td>Level: <?=$data->Level?></td>
  </tr>
  <tr>
    <td>Costo: <?=$data->Price?></td>
  </tr>
      

   <tr>
	<td colspan="2" height="40">
    
		Item Permanente.

    </td>
   </tr>
   
   <tr>
		<td>
        Costo del Item:
        </td>
        <td colspan="2">
		<?=$itemp?>
		</td>
    </tr>
    <tr>
		<td>
        Tus Coins:
        </td>
        <td>
        <?=$coins?>
		</td>
    </tr>
    <tr>
		<td>
        Operacion:
        </td>
        <td>
        <?=$balan?>
    	</td>
    </tr>
    <tr>
    	<td colspan="2">
                                                                                        
       <a href="javascript:document.frmBuy.submit();">
<img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1764" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyset_on.jpg')"></a>
<a href="index.php?do=shopsetsevent">
<img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="dale1872" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'dale1872',/*url*/'images/btn_cancel_on.jpg')"></a>

		</td>
   </tr>
</table>



</td>
</table>

</form>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>



<script language="javascript">
UpdatePrice();
</script>