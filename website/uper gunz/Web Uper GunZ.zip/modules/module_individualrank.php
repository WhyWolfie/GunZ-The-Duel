<?php
include("secure/include.php");
SetTitle("FreshGunZ - Ranking Individual");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=individualrank");
    SetMessage("Ranking", array("Visualisar los Ranking Necesitas estar Logueado"));
    header('Location: index.php?do=login');
    die();
}

?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">
    
    <table width="500">
      <tr class="ranking" valign="top">
        <td colspan="2" width="33.3%">
        <a href="index.php?do=individualrank" class="newsupdates">Ranking Individual</a>
    	</td>
        <td colspan="2" width="33.3%">
        <a href="index.php?do=clanrank" class="newsupdates">Ranking De Clan</a>
    	</td>
        <td colspan="2" width="33.3%">
        <a href="index.php?do=halloffame" class="newsupdates">Salon de la Fama</a>
    	</td>
      </tr>
      <tr class="ranking">
      <form method="GET" name="indsearch" action="index.php">
      		<td colspan="3">
            <input type="hidden" name="do" value="individualrank" />
            <select name="type">
                <option value="1">Nombre de Personaje</option>
                <option value="2">Nombre de Cuenta</option>
            </select>��
            </td>
            <td colspan="3">
            <input type="text" name="name"/>��
          <input type="submit" value="Buscar" />        
        </td>
      </form>
      </tr>
      <tr class="rankingdisplay">
      	<td width="10%">Rank</td>
        <td width="20%">Nombre</td>
        <td width="10%">Level</td>
        <td width="15%">Exp</td>
        <td width="10%">Kill/Death</td>
        <td width="25%">Ultima Coneccion</td>
      </tr>
      
      <?
if( isset($_GET['type']) && isset($_GET['name']) )
{
$search = 1;
$type = clean($_GET['type']);
$name = clean($_GET['name']);
if($type == 1)
{
$squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE Name = '$name'";
}
elseif($type == 2)
{
$accountq = mssql_query("SELECT AID FROM Account(nolock) WHERE UserID = '$name'");
if( mssql_num_rows($accountq) == 1 )
{
$accountdata = mssql_fetch_row($accountq);
$aid = $accountdata[0];
$squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount, LastTime, Sex FROM Character(nolock) WHERE AID = '$aid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP ASC";
}
else
{
echo '
<tr>
<td width="528" colspan="5" class="estilo5">
<p align="center">
- No data -</td>
</tr>';
}
}
else
{
$search = 0;
}
}
else
{
$search = 0;
}

if($search == 0 )
{
switch( clean($_GET['pagetirado']) )
{
case "":
$ranks = "Ranking >= 1 AND Ranking <= 50";
break;
case "2":
$ranks = "Ranking > 20 AND Ranking <= 40";
break;
case "3":
$ranks = "Ranking > 40 AND Ranking <= 60";
break;
case "4":
$ranks = "Ranking > 60 AND Ranking <= 80";
break;
case "5":
$ranks = "Ranking > 80 AND Ranking <= 100";
break;
default:
$ranks = "Ranking <= 50";
break;
}


$res = mssql_query("SELECT TOP 100 * FROM Character a, Account b WHERE a.AID=b.AID AND b.UGradeID !=255|254|253|252 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
}
else
{
$res = mssql_query($squery);
}
if(mssql_num_rows($res) <> 0)
{
$count = 1;  
while($char = mssql_fetch_array($res))
{
if($char['Sex'] == 0)
{
$sexo = "<font color='#06f'>Hombre</font>";
}elseif($char['Sex'] == 1){
$sexo = "<font color='pink'>Mujer</font>";
}
?>              
      
      <tr class="rankingdisplay">
      	<td><?=$count?></td>
        <td><?=FormatCharName($char['CID'])?></td>
        <td><?=$char['Level']?></td>
        <td><?=$char['XP']?></td>
        <td><?=$char['KillCount']?>/<?=$char['DeathCount']?></td>
        <td><?=$char['LastTime']?></td>
      </tr>

<?
$count++;
}
}else{
?>

<?
msgbox("Personaje no Encontrado","index.php?do=individualrank");
?>
<?
}
?>
      
    </table>
	
    
    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>


