<?
include("secure/include.php");

SetTitle("QuanticGamers Gunz - Tienda Nombres");
?>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop</a></div>
    <div id="contentbox500" align="center">

  	<table width="400" border="0" align="center">
        <tr class="shopdisplaymenu shopdisplaymenusite">
          <td><a href="index.php?do=shopdonator">Donator Items</a></td>
          <td><a href="index.php?do=shopevent">Event Items</td>
          <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
          <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
          <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
          <td><a href="index.php?do=nicks">Extra</a></td>
        </tr>
        <tr class="shopdisplaymenu">
          <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
        </tr>    
        
        <tr>
          
          
          <td colspan="2" width="33.33" style="border:1px dashed #222;">
              <a href="index.php?do=buycolorname" title="250 DonadorCoins">
                  <img border="0" src="../images/shop/donador/changename.gif" alt="d" style="border: 2px solid #171516">
              </a>
              <div class="nameitem">Nombre a Color</div>
              <div class="nameitem">Tipo:Donator</div>
              <div class="sexitem">Sexo:Todos</div>	
              <div class="sexitem">Nivel:0</div>											
          </td>
          
          
          
          <td colspan="2" width="33.33" style="border:1px dashed #222;">
              <a href="index.php?do=jjang" title="250 EventCoins">
                  <img src="../images/shop/donador/changename.gif" alt="d"  border="0" style="border: 2px solid #171516" />
              </a>
              <div class="nameitem">Jjang</div>
              <div class="nameitem">Tipo:Evento</div>
              <div class="sexitem">Sexo:Todos</div>	
              <div class="sexitem">Nivel:0</div>											
          </td>
          
          
          
          <td colspan="2" width="33.33" style="border:1px dashed #222;">
              <a href="index.php?do=cambiodename" title="250 DonadorCoins">
                  <img src="../images/shop/donador/changename.gif" alt="d"  border="0" style="border: 2px solid #171516" />
              </a>
              <div class="nameitem">Cambiar Nombre</div>
              <div class="nameitem">Tipo:Donador</div>
              <div class="sexitem">Sexo:Todos</div>	
              <div class="sexitem">Nivel:0</div>											
                              
                              
           </tr>
       </div>
       </td>
       </tr>
      </td>
      </tr>
      </table>
      </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>
