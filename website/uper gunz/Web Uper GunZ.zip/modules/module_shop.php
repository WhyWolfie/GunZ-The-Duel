<?php
include("secure/include.php");

SetTitle("QuanticGamers Gunz - Item Shop");

$res = mssql_query("SELECT TOP 6 * FROM ShopItems(nolock) ORDER BY Selled DESC");

$count = 0;
                                                                                                                           
while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->CSSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}

$count = 6;

$res = mssql_query("SELECT TOP 7 * FROM ShopSets(nolock) ORDER BY Selled DESC");

while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->SSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}


?>
<style type="text/css">
<!--
.Estilo1 {color: #0099FF}
-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop</a></div>
    <div id="contentbox500" align="center">
	<table width="200" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td><a href="index.php?do=shopsets">Sets</a></td>
        <td><a href="index.php?do=shopevent">Event Items</a></td>
        <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
        <td><a href="index.php?do=nicks">Extra</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">
            <table width="500" border="0">
                   <tr> 
                   
                    <tr class="shopmasvendidos">
                        <td colspan="6">Items + Vendidos</td>
                    </tr>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>" title="<?=$items[0][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[0][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[0][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[0][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>" title="<?=$items[1][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[1][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[1][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[1][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>" title="<?=$items[2][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[2][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[2][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[2][Sex]?></div>												
                    </td>
                    
                   </tr>
                   
                   <tr> 
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>" title="<?=$items[3][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[3][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[3][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[3][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[4][ID]?>&cat=<?=$items[4][CatID]?>" title="<?=$items[4][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[4][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[4][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[4][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[5][ID]?>&cat=<?=$items[5][CatID]?>" title="<?=$items[5][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[5][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[5][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[5][Sex]?></div>												
                    </td>
                    
                   </tr>
                   
                </table>
                
                <table width="500">
                	<tr class="shopmasvendidos">
                    	<td colspan="6">Sets + Vendidos</td>
                    </tr>
                </table>
                
				<table width="500" border="0">
                   <tr> 
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[6][ID]?>&cat=<?=$items[6][CatID]?>" title="<?=$items[6][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[6][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[6][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[6][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[7][ID]?>&cat=<?=$items[7][CatID]?>" title="<?=$items[7][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[7][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[7][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[7][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[8][ID]?>&cat=<?=$items[8][CatID]?>" title="<?=$items[8][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[8][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[8][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[8][Sex]?></div>												
                    </td>
                    
                   </tr>
                   
                   <tr> 
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[9][ID]?>&cat=<?=$items[9][CatID]?>" title="<?=$items[9][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[9][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[9][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[9][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[10][ID]?>&cat=<?=$items[10][CatID]?>" title="<?=$items[10][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[10][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[10][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[10][Sex]?></div>												
                    </td>
                    
                    <td style="border:1px dashed #222;">
                        <a href="index.php?do=buyitem&itemid=<?=$items[11][ID]?>&cat=<?=$items[11][CatID]?>" title="<?=$items[11][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[11][ImageURL]?>" width="80" height="80">
                        </a>
                        <div class="nameitem">Nombre: <?=$items[11][Name]?></div>
                        <div class="sexitem">Sexo: <?=$items[11][Sex]?></div>												
                    </td>
                    
                   </tr>
                   
                </table>


</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>