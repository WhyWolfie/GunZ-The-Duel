<?php
include("secure/include.php");
if($_SESSION[AID] == ""){
	SetURL("index.php?do=shop");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
	}
$price = 	250; // precio
$typedecoins = "Coins"; // Typo de table
$name	= 	"QuanticGamers Gunz - Cambiar Nombre"; // Name
/*____________________________________________
*/
$q		=	mssql_query("SELECT * From Account WHERE AID='".$_SESSION[AID]."'");
$acc = mssql_fetch_object($q);
$dcoins = $acc->$typedecoins;
$total	= $dcoins - $price;
if(isset($_POST['comprar'])){
	if($dcoins < $price){
		SetMessage("Mensaje de la Tienda", array("No tienes suficientes DonadorCoins $total."));
        header("Location: index.php?do=nicks");
        die();	
	}
		if($_POST['userid'] == ""){
		SetMessage("Mensaje de la Tienda", array("No dejes el campo vacio."));
        header("Location: index.php?do=nicks");
        die();
		}
	mssql_query("UPDATE Character SET Name='".$_POST['userid']."' WHERE CID='".$_POST['id']."'");
	mssql_query("UPDATE Account SET Coins='".$total."' WHERE AID='".$_SESSION['AID']."'");
   msgbox("Su nombre fue cambiado con gran Exito!.","index.php?do=nicks");
        header("Location: index.php?do=nicks");
        die();
	
	}
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Cambio de Nombre</a></div>
    <div id="contentbox500" align="center">

<div align="center">
<form method="POST" action="index.php?do=cambiodename" name="frmBuy">
<table width="1" width="500" class="text c222">
<input type="hidden" name="comprar" />
  <tr>
    <td rowspan="4"><img alt="" border="0" src="../images/shop/donador/changename.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
  </tr>
  <tr>
    <td><?=$name?></td>
  </tr>
  <tr>
    <td>Tipo:Especial</td>
  </tr>
  <tr>
    <td>Precio:<?=$price?>DonadorCoins</td>
  </tr>
  <tr>
    <td>Selecciona tu personaje</td>
    <td><select name="id">
		<?php
			$que = mssql_query("SELECT * From Character WHERE AID='".$_SESSION[AID]."'");
			while($char = mssql_fetch_object($que)){
		?>
      	<option value="<?=$char->CID?>">
        	<?=$char->Name?>
        </option>
      <? } ?>
    </select>
    </td>
  </tr>
  <tr>
    <td>Nuevo nombre:</td><td><input name="userid" class="text" tabindex="1" size="16" maxlength="12" /></td>
  </tr>
  <tr>
  	<td colspan="2">&nbsp;</td>
  </tr>
  <tr>
  	<td colspan="2">Total:<?=$price?></td>
  </tr>
  <tr>
  	<td colspan="2">Balance Actual<?=$dcoins?></td>
  </tr>
  <tr>
  	<td colspan="2">Despues:<?=$total?></td>
  </tr>
  <tr>
  	<td colspan="2">
    <a href="javascript:document.frmBuy.submit();">
    	<img alt="" border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_buyitem2_off.jpg'" onmouseover="this.src='images/btn_buyitem2_on.jpg'">
    </a>
    <a href="index.php?do=shopitem">
    	<img alt="" border="0" src="images/btn_cancel_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_cancel_off.jpg'" onmouseover="this.src='images/btn_cancel_on.jpg'">
    </a>
    </td>
  </tr>
</table>
</form>
</div>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>