<!--CREATE CLAN CREATED BY NIGGA-->
<script type="text/javascript">
var r={'special':/[\W]/g}

function valid(o,w)

{

  o.value = o.value.replace(r[w],'');

}

function isAlphaNumeric(value)

{

  if (value.match(/^[a-zA-Z0-9]+$/))

    return true;

  else

    return false;

}

</script>
<?
if ($_SESSION['AID'] == ""){
    alertbox("Logueate primero!","index.php");
    die();
    }
$setember = clean($_SESSION['AID']);
$q2chars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '$setember'");
    if( mssql_num_rows($q2chars) == 0 )
    {
    alertbox("Create un personaje primero.","index.php");
    die();
    }
function sonumeros($btbt) {
$string = $btbt;

$btbt = eregi_replace('([^0-9])','',$btbt);

if( $string != $btbt )
        {           
alertbox("Only numbers.","index.php");
die();
        }

        return( $btbt );

}    
?> 

<table width="500" class="text" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">

<div align="center">
<form action="index.php?do=clancreate" method="post">
<table border="0">
<?php
$setember = clean($_SESSION['AID']);
$query = mssql_query("SELECT * FROM Character WHERE AID = '$setember' AND DeleteFlag = 0");
$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$setember' AND DeleteFlag = '0'");
?>
<tr><td>Character:<select class="text" name="CID">
<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?></select></td></tr></br></br>
<tr><td>Clan Name:<input name="NOME" type="text" class="text" onkeyup="valid(this,'special')" onblur="valid(this,'special')" size="20" maxlength="10">
</br>
</br><div align="center"><input type="submit" class="logon" name="criaraf" value="Create" /></td></tr></div>
</table>
</form>
</div>
</br>
</br>
<?php
if (isset($_POST['criaraf'])){
$NOME = clean($_POST['NOME']);
$cil = clean($_POST['CID']);
$CID = sonumeros($cil);

$pattern = "[^a-zA-Z0-9]";
if(ereg($pattern,$NOME) == TRUE)
{
die('Special characters in name field');
}

if(strlen($NOME) > 10){
    Echo "<div align=center><font color=white>The name is too long.</font></div>";
    die(); 
        }
if(strlen($NOME) < 4){
            Echo "<div align=center><font color=white>The name is too short.</font></div>";
    die(); 
        }
$lil = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$CID'");
$trin = mssql_query("SELECT Name FROM Clan WHERE Name = '$NOME'");
$otario = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$CID'");

if (mssql_num_rows($trin) >= 1){
Echo "<div align=center><font color=white>A clan with this name already exist.</font></div>";
    die(); 
        }
if (mssql_num_rows($lil) >= 1){
Echo "<div align=center><font color=white>You already have a clan.</font></div>";
    die(); 
        }
if (mssql_num_rows($otario) == 0 )
        {
    Echo "<div align=center><font color=white>This characters belongs to another account.</font></div>";
    die();
    }
$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$NOME', '$CID', GETDATE())");
$res = mssql_query("SELECT * FROM Clan(nolock) WHERE Name = '$NOME' AND MasterCID = '$CID'");
        $usr = mssql_fetch_assoc($res);
        $clid = $usr['CLID'];
$zuei = mssql_query("DELETE FROM ClanMember WHERE CLID = '$clid'");
mssql_query("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$CID', 1, GETDATE())");
if($sql){
    Echo "<div align=center><font color=white>The clan $NOME was created.</font></div>";
    die(); 
}else{
    Echo "<div align=center><font color=white>Error, please report it.</font></div>";
    die(); 
}
}
?>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>