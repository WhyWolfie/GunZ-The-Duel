<?php
include("secure/include.php");

SetTitle("Gunz - Comprar Item");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buyevent&itemid={$_GET[itemid]}");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

if(!isset($_POST[itemid]))
{
    if($_GET[itemid] == "" || !is_numeric($_GET[itemid]))
    {
        SetMessage("Mensaje de la Tienda", array("Incorrecta Informacion Del Item"));
        header("Location: index.php?do=shopitem");
        die();
    }
}

if(isset($_POST[itemid]))
{
    $itemid  = clean($_POST[itemid]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopEvents(nolock) WHERE CSSID = $itemid");

    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopevent");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID  = $accid"));

    $totalprice       = $ires->Price;
    $accountbalance = $ares->EventCoins;
    $afterbalance   = $accountbalance - $totalprice;
    $ugradeid = $ares->UGradeID;

    if ($itemid == 1 && $ugradeid == 2)
    {
        SetMessage("Mensaje de la Tienda", array("Ya Usted Posee Jjang No Tiene Por Que Comprarlo De Nuevo."));
        header("Location: index.php?do=buyevent&itemid=$itemid");
        die();
    }
    elseif($itemid == 1 && $ugradeid != 0)
    {
        SetMessage("Mensaje de la Tienda", array("No Puedes Comprara Un Jjang A Un Moderador O A Un Usuario Banneado."));
        header("Location: index.php?do=buyevent&itemid=$itemid");
        die();
    }

    if($afterbalance < 0)
    {
        SetMessage("Error de la Tienda", array("Usted no Posee DCoins suficientes para comprar este Item."));
        header("Location: index.php?do=buyevent&itemid=$itemid");
        die();

    }else{
        if( $itemid == 1 )
        {
            mssql_query_logged("UPDATE Account SET UGradeID = 2, EventCoins = EventCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopEvents SET Selled = Selled + 1 WHERE CSSID = $itemid");

            SetMessage("Mensaje de la Tienda", array("Compra Del Jjang Completa"));
            header("Location: index.php?do=shopevent");
            die();
        }
        else
        {
            mssql_query_logged("UPDATE Account SET EventCoins = EventCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopEvents SET Selled = Selled + 1 WHERE CSSID = $itemid");

            //Head
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 1)");


            SetMessage("Mensaje de la Tienda", array("Item purchased successfully, look at your storage in gunz for using it"));
            header("Location: index.php?do=shopevent");
            die();
        }

    }
}else{
    $itemid  = clean($_GET[itemid]);

    $ires = mssql_query_logged("SELECT * FROM ShopEvents(nolock) WHERE CSSID = $itemid");


    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopevent");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));

    $data = mssql_fetch_object($ires);
    switch($data->Slot)
{
    case 3:
        $type = "Armadura";
    break;
    case 2:
        $type = "Melee";
    break;
    case 1:
        $type = "Rango";
    break;
    case 5:
        $type = "Especial";
    break;
    default:
        $type = "Armadura";
    break;
}
}




?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">

<form method="POST" action="index.php?do=buyevent" name="frmBuy">

<table width="500" border="0" class="text c222">
  <tr>
    <td rowspan="6"><img border="0" src="images/shop/<?=$data->ImageURL?>" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
  </tr>
  <tr>
    <td><?=$data->Name?></td>
  </tr>
  <tr>
    <td>Tipo:<?=$type?></td>
  </tr>
  <tr>
    <td>Sexo:<?=GetSexByID($data->Sex)?></td>
  </tr>
  <tr>
    <td>Nivel:<?=$data->Level?></td>
  </tr>
  <tr>
    <td>
    	Precio:<span id="currentprice"><?=$data->Price?></span> EventCoins
		<input type="hidden" name="itemid" value="<?=$_GET[itemid]?>">
	</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Duracion (Dias): Permanente.</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Total:<span id="Total"><?=$data->Price?></span></td>
  </tr>
  <tr>
    <td colspan="2">Actual Balance:<span id="currbalance"><?=$acd->EventCoins?></span></span></td>
  </tr>
  <tr>
    <td colspan="2">Despues:<span id="afterpur"><?=(($acd->EventCoins) - ($data->Price))?></span></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">
    <a href="javascript:document.frmBuy.submit();">
		<img border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" id="img1764" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyitem2_on.jpg')">
    </a>
	<a href="index.php?do=shopevent">
	<img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover=	"FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')">
    </a>
    </td>
  </tr>
</table>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>