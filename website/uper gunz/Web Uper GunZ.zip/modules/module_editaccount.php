<?php
include("secure/include.php");
if($_SESSION[AID] == "")
{
    SetMessage("Message de Fresh GunZ", array("Porfavor, Logueate primero."));
    SetURL("index.php?do=editaccount");
    header("Location: index.php?do=login");
    die();
}

if(isset($_POST[Checksubmit]))
{
    $pass = clean($_POST[CheckPass]);
    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Login(nolock) WHERE UserID = '{$_SESSION[UserID]}' AND Password = '$pass'")) == 1)
    {
        $_SESSION[Modify] = $_SESSION[AID];
    }else{
        SetMessage("Por Favor Verifique La Informacion", array("Contrase�a incorrecta."));
        $_SESSION[Modify] = 0;
        header("Location: index.php?do=editaccount");
        die();
    }
}

if($_SESSION[Modify] != $_SESSION[AID])
{
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">

       <form method="POST" action="index.php?do=editaccount" name="editacc">
        <table width="500">
          <tr>
            <td>
                <font style="font-size:10px; color:#fff;">Escribe la contrase&ntilde;a:</font>
                <input name="CheckPass" class="text" type="password">
            </td>
          </tr>
          <tr>
            <td>
            <input type="submit" class="submit" value="Continuar">
            </td>
            </td>
          </tr>
        </table>
        <input type="hidden" name="Checksubmit" value="1"></form>

	</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>


<?
}else{



if(isset($_POST[submit]) && $_SESSION[Modify] == $_SESSION[AID])
{
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);

    $errors = array();

    if($pass[0] <> $pass[1])
        array_merge($errors, array("La contrase�a no Existe"));

    if(mssql_num_rows(mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'")) <> 0)
        array_merge($errors, array("El email esta en uso"));

    if($pass[0] <> "" || $pass[1] <> "")
        array_merge($errors, array("Porfavor Introduce tu contrase�a"));

    if($email <> "")
        array_merge($errors, array("Porfavor Introduce tu e-mail"));

    if($sq <> "")
        array_merge($errors, array("Porfavor Introduce tu Pregunta Secreta"));

    if($sa <> "")
        array_merge($errors, array("Porfavor Introduce tu Respuesta Secreta"));

    if(strlen($pass[0]) < 6)
        array_merge($errors, array("La Contrase�a debe ser minimo de 6 caracteres"));

    if(count($errors) == 0)
    {
        mssql_query_logged("UPDATE Account SET Email = '$email' WHERE AID = '{$_SESSION[AID]}'");

        if($_POST[C1] == "ON")
        {
	                  
	    mssql_query_logged("UPDATE Login SET Password = '".$pass[0]."' WHERE AID = '{$_SESSION[AID]}'");
            $_SESSION['Password'] = $pass[0];
        }
        if($_POST[C2] == "ON")
        {
            mssql_query_logged("UPDATE Account SET sq = '$sq', sa = '$sa' WHERE AID = '{$_SESSION[AID]}'");
        }
        SetMessage("Message De Sa GunZ", array("Cuenta Actualizada Perfectamente"));
        header("Location: index.php?do=editaccount");
        die();
    }else{
        SetMessage("Por Favor Verifique La Informacions", $errors);
        header("Location: index.php?do=editaccount");
        die();
    }
}else{
    SetTitle("FreshGunz - Editar Cuenta");
    $europe = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

    $p = GetCountryCodeByIP($_SERVER[REMOTE_ADDR]);
    if(in_array(strtoupper($p), $europe))
    {
        $country = sprintf("[<font color='#00FF00'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }else{
        $country = sprintf("[<font color='#FF0000'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }

    $r = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));
    $a = mssql_fetch_assoc(mssql_query_logged("SELECT * FROM Login(nolock) WHERE AID = {$_SESSION[AID]}"));

    $_MEMBER[UserID]        = $r[UserID];
    $_MEMBER[EMail]         = $r[Email];
    $_MEMBER[SA]            = $r[sa];
    $_MEMBER[SQ]            = $r[sq];
}


?>


<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Editar Cuenta</a></div>
    <div id="contentbox500" align="center">
    
    <form method="POST" action="index.php?do=editaccount" name="editacc">
        <table width="500">
          <tr class="text c222">
            <td>UserID</td>
            <td><?=$_MEMBER[UserID]?></td>
          </tr>
          <tr class="text c222">
          	<td>Editar contrase&ntilde;a</td>
            <td>
            <input type="checkbox" name="C1" value="ON" onclick="document.editacc.pass1.disabled = !document.editacc.pass1.disabled; document.editacc.pass2.disabled = !document.editacc.pass2.disabled; ">
			</td>
          </tr>
          <tr class="text c222">
            <td>Contrase&ntilde;a</td>
            <td><input disabled type="password" name="pass1" class="text"></td>
          </tr>
          <tr class="text c222">
            <td>Repite la contrase&ntilde;a</td>
            <td><input disabled type="password" name="pass2" class="text"></td>
          </tr>
            <tr class="text c222">
            <td></td>
            <td>
			<input type="text" name="email" value="<?=$_MEMBER[EMail]?>" class="text">
			</td>
          <tr class="text c222">
            <td>&nbsp;</td>
            <td><input type="checkbox" name="C2" value="ON" onclick="document.editacc.sq.disabled = !document.editacc.sq.disabled; document.editacc.sa.disabled = !document.editacc.sa.disabled; "></td>
          </tr>
          <tr class="text c222">
            <td>Pregunta Secreta</td>
            <td><input disabled type="text"  class="text" name="sq" value="<?=$_MEMBER[SQ]?>"></td>
          </tr>
          <tr class="text c222">
            <td>Respuesta Secreta</td>
            <td><input disabled type="text"  class="text" name="sa"></td>
          </tr>
          <tr>
            <td colspan="2">
            <!--<input border="0" src="images/btn_modifyacc_off.jpg" name="img123" width="136" height="22" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img123',/*url*/'images/btn_modifyacc_on.jpg')" type="image">-->
            <input name="img123" type="submit" class="submit" value="Guardar Cambios">
            </td>
          </tr>
        </table>
	<input type="hidden" name="submit" value="1"></form>

    </div>
    
    <div id="footerbox500" align="center"></div>
    
    
    </td>
  </tr>
</table>

<?}?>


											
