<head>
<meta http-equiv="Content-Language" content="es">
</head>

<?php
include("secure/include.php");
SetTitle("FreshGunZ - Hall of Fame");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=halloffame");
    SetMessage("Hall Of Fame", array("Para visualisar el Salon de la Fama Necesitas estar Logueado"));
    header("Location: index.php?do=login");
    die();
}
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">
    
    
    			<table width="500">
                  <tr class="ranking" valign="top">
                    <td colspan="2" width="33.3%">
                    <a href="index.php?do=individualrank" class="newsupdates">Ranking Individual</a>
                    </td>
                    <td colspan="2" width="33.3%">
                    <a href="index.php?do=clanrank" class="newsupdates">Ranking De Clan</a>
                    </td>
                    <td colspan="2" width="33.3%">
                    <a href="index.php?do=halloffame" class="newsupdates">Salon de la Fama</a>
                    </td>
                  </tr>
				</table>
    

				<table border="0" width="100%">
					<tr>
						<td width="100%" valign="top">
                        <?
                            if( isset($_GET['date']) )
                            {
                                $date = clean($_GET['date']);
                                $date = explode("-", $date);
                                $month = $date[0];
                                $year = $date[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>
                            <table border="0" width="100%">
								<tr>
									<td valign="top">
                                        <form method="GET" name="honorrank" action="index.php">
                                        <input type="hidden" name="do" value="halloffame" />
                                        
                                            <table align="center" border="0">
                                                <tr class="subinfo">
                                                    <td width="50%">Esta es la clasificaci�n del <?=$month?>/<?=$year?></td>
                                                    
                                                    <td width="50%">
                                                    Date: <select name="date" onchange="document.honorrank.submit()">
                                                    <option>Select Fecha</option>
                                                    <?
                                                    $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                                    while($halldata = mssql_fetch_assoc($listq))
                                                    {
                                                        echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'/'.$halldata[Year].'</option>';
                                                    }
                                                    ?>
                                                    </select>
                                                    </td>
                                                </tr>
                                            </table>
										</form>
                                    
                                    </td>
								</tr>
								<tr>
									<td>					
                                        <table border="0" width="100%">
											<tr class="ranking">
                                                <td width="15%">Ranking</td>
                                                
                                                <td width="15%">Emblem</td>
                                                
                                                <td width="15%">Nombre del Clan</td>
                                                
                                                <td width="15%">L�der</td>
                                                
                                                <td width="15%">Win/Losses</td>
                                                
                                                <td width="10%">Win %</td>
                                                
                                                <td width="15%">Puntos</td>
                                            </tr>
											<tr>
											<td width="100%" colspan="7" valign="top">
												
											<table border="0">
												<?
                                                switch( clean($_GET['page']) )
                                                {
                                                case "":
                                                $ranks = "Ranking <= 20";
                                                break;
                                                case "2":
                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                                break;
                                                case "3":
                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                                break;
                                                case "4":
                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                                break;
                                                case "5":
                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                                break;
                                                default:
                                                $ranks = "Ranking <= 20";
                                                break;
                                                }
                                                $res = mssql_query_logged("SELECT * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                                if(mssql_num_rows($res) <> 0)
                                                {
                                                while($clan = mssql_fetch_object($res))
                                                {
                                                
                                                $clanemburl = ($clan->EmblemUrl == "") ? "noemblem.jpg" : $clan->EmblemUrl;
                                                ?>
                                                <tr>
                                                    <td width="15%" align="center">
                                                    <?=$clan->Ranking?></td>
                                                    <td width="15%" align="center">
                                                    <img src="http://imgur.com/<?=$clanemburl?>" width="34" height="30"></td>
                                                    <td width="15%" align="center">
                                                    <?=$clan->ClanName?></td>
                                                    <td width="15%" align="center">
                                                    <?=GetCharNameByCID($clan->MasterCID)?></td>
                                                    <td width="10%" align="center">
                                                    <?=$clan->Wins?>/<?=$clan->Losses?></td>
                                                    <td width="15%" align="center">
                                                    <?=GetClanPercent($clan->Wins, $clan->Losses)?></td>
                                                    <td width="15%" align="center">
                                                    <?=$clan->Point?></td>
                                                </tr>
                                <?
                                    }
                                }
                                else
                                {
                                ?>
									<tr>
									<td width="507" align="center" colspan="7">
									No hay datos</td>
									</tr>
                                <?
                                }

                            }
                            else
                            {
                                $querydate = mssql_query("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                $ddata = mssql_fetch_row($querydate);
                                $month = $ddata[0];
                                $year = $ddata[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                        ?>
							<table border="0" width="100%">
								<tr>
									<td valign="top">
                                    <form method="GET" name="honorrank" action="index.php">
                                    <input type="hidden" name="do" value="halloffame" />
                                        <table align="center">
                                            <tr class="subinfo">
                                                <td width="50%">Esta es la clasificaci�n del <?=$month?>/<?=$year?></td>
                                                <td width="50%">
                                                Date: <select name="date" onchange="document.honorrank.submit()">
                                                <option>Select Fecha</option>
                                                <?
                                                $listq = mssql_query("SELECT Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                                while($halldata = mssql_fetch_assoc($listq))
                                                {
                                                    echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'/'.$halldata[Year].'</option>';
                                                }
                                                ?>
                                                </select>
                                                </td>
                                            </tr>
                                        </table>
									</form>
                                    
                                    </td>
								</tr>
								<tr>
									<td>

                                        <table border="0" >
											<tr class="ranking">
                                                <td width="15%">
                                                Ranking
                                                </td>
                                                <td width="15%">
                                                Emblem
                                                </td>
                                                <td width="15%">
                                                Nombre del Clan
                                                </td>
                                                <td width="15%">
                                                L�der
                                                </td>
                                                <td width="15%">
                                                Win/Losses
                                                </td>
                                                <td width="10%">
                                                Win %
                                                </td>
                                                <td width="15%">
                                                Puntos
                                                </td>
                                            </tr>
											<tr>
												<td width="100%" colspan="7" valign="top">
													<table border="0" width="100%">
														
                                                <?
                                                        switch( clean($_GET['page']) )
                                                        {
                                                            case "":
                                                                $ranks = "Ranking <= 20";
                                                            break;
                                                            case "2":
                                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                                            break;
                                                            case "3":
                                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                                            break;
                                                            case "4":
                                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                                            break;
                                                            case "5":
                                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $ranks = "Ranking <= 20";
                                                            break;
                                                        }
                                                        $res = mssql_query_logged("SELECT TOP 50 * FROM ClanHonorRanking(nolock) WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY Ranking ASC");
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "hqKqemp.png" : $clan->EmblemUrl;
                                                        ?>
                                                        <tr class="text c222">
															<td align="center">
															<?=$clan->Ranking?></td>
															<td width="15%" align="center">
															<div align="center">
													        <img src="http://imgur.com/<?=$clanemburl?>" width="34" height="30"></td>
															<td width="15%" align="center">
															<?=$clan->ClanName?></td>
															<td width="15%" align="center">
															<?=GetCharNameByCID($clan->MasterCID)?></td>
															<td width="15%" align="center">
															<?=$clan->Wins?>/<?=$clan->Losses?></td>
															<td width="10%" align="center">
															<?=GetClanPercent($clan->Wins, $clan->Losses)?></td>
															<td width="15%" align="center">
															<?=$clan->Point?></td>
														</tr>
                                                        <?
                                                            }
                                                        }
                                                        else
                                                        {
                                                        ?>
														<tr>
															<td width="100%" align="center" colspan="7">No data</td>
														</tr>
                                                        <?
                                                        }
                                                }
                                                        ?>
													</table>
												
												</td>
											</tr>
											</table>
                                     <tr class="subinfo">       
									<td>
 <a href="index.php?do=halloffame&date=<?=$date?>">[1-20]</a> - <a href="index.php?do=halloffame&date=<?=$date?>&page=2">[21-40]</a> - <a href="index.php?do=halloffame&date=<?=$date?>&page=3">[41-60]</a>
- <a href="index.php?do=halloffame&date=<?=$date?>&page=4">[61-80]</a> - <a href="index.php?do=halloffame&date=<?=$date?>&page=5">[81 - 100]</a></td>
								</tr>
</table>

</table>


</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>