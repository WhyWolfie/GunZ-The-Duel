<? 
$nombregunz		=		"Quantic Gunz";		
$precio			=		"10";  
$coins			=		"EventCoins";
$redirec		=		"nicks"; 
$numjjang		=		"2";
$namejjang		=		"Jjang";
?>