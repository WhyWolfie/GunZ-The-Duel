<?php
include("secure/include.php");
SetTitle("FreshGunz - Cambiar Nombre");
if(empty($_SESSION['AID'])){
	?>
	<script>
	alert('Necesitas logearte primero.');
	</script>
	<meta http-equiv="refresh" content="0;url=index.php"/>
	<?
	die();
}
$selectuFaragon = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
$rowcFaragon = mssql_fetch_array($selectuFaragon);
if($rowcFaragon['DonatorCoins'] <80){
	?>
	<script>
	alert('Para usar este modulo debes tener mas de 80 DCoins');
	</script>
	<meta http-equiv="refresh" content="0;url=index.php"/>
	<?
	die();
}


$resFaragon = mssql_query("SELECT * FROM Character WHERE DeleteFlag = 0 AND AID = '".$_SESSION['AID']."'");

?>
<table border="0" style="border-collapse: collapse" width="100%">
<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div></td>
						<td valign="top">
               <form method="post" action="">
<center>
<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#DF0101">
<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center"><span style="color:#FFFF00">
										<b><font face="Tahoma" size="2">Comprar Changename</font></b></td>
							  </tr>
							  <td bgcolor="#000000">
							  <div align="center">
<table style="padding:30px;background:#000000;color:white;"><span style="color:#FF0000">
<p> En este Modulo podran comprar el ChangeName que consiste en Canbiarle el <p>
Nombre a un personaje Como lo prefiera :D <p> Solo elija el personaje y Escriba el nombre que quiere colocarse <p>
Valor De la compra 80 DCoins
	<tr>
		<th bgcolor="#8000FF" style="padding:10px;">Cambiar Nombre</th>
	</tr>
	<tr>
                                                         <td bgcolor="#333" style="padding:5px;"><select name="pj">
				<?
				while($rowFaragon = mssql_fetch_array($resFaragon)){
					?>
						<option value="<?=$rowFaragon['Name']?>"><?=$rowFaragon['Name']?></option>
					<?
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<td bgcolor="#333" style="padding:5px;"><input type="text" name="nname"/></td>
	</tr>
	<tr>
		<td bgcolor="#333" style="padding:5px;"><input type="submit" name="enviar" value="Cambiar Nombre"/></td>
	</tr>
</table>
</form>
<br><br>
<span style="font-size: 9pt"><font color="#FF0000">Tus DCoins:</span></font><p><span style="color:#FFFF00"><?=$rowcFaragon['DonatorCoins']?><p><span style="font-size: 9pt"><span style="color:#FF0000">Precio: <span style="color:#FFFF00">80</span></font><p>
</table>
</center>
</td>			
<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>	
<?
if(isset($_POST['enviar'])){
	$pjFaragon = $_POST['pj'];
	$nnameFaragon = $_POST['nname'];
	$selectvFaragon = "SELECT * FROM Character WHERE Name = '".$nnameFaragon."'";
	$queryvFaragon = mssql_query($selectvFaragon);
	$rowsvFaragon = mssql_num_rows($queryvFaragon);
	if($rowsvFaragon>0){
		?>
		<script>
		alert('El nuevo nombre introducido ya existe.');
		</script>
		<meta http-equiv="refresh" content="0;url=index.php?do=changename"/>
		<?
		die();
	}
	$update1Faragon = "UPDATE Character SET Name = '".$nnameFaragon."' WHERE Name = '".$pjFaragon."'";
	mssql_query($update1Faragon);
	$update2Faragon = "UPDATE Account SET DonatorCoins = DonatorCoins - 80 WHERE AID = '".$_SESSION['AID']."'";
	mssql_query($update2Faragon);
	?>
	<script>
	alert('Nombre Cambiado Satisfactoriamente.');
	</script>
	<meta http-equiv="refresh" content="0;url=index.php"/>
	<?
}
?>
</div>
</td>
</table>
</table>