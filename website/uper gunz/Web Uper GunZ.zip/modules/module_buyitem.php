<?php
include("secure/include.php");

SetTitle("QuanticGamers Gunz - Comprar Item");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buyitem&itemid={$_GET[itemid]}");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

if(!isset($_POST[itemid]))
{
    if($_GET[itemid] == "" || !is_numeric($_GET[itemid]))
    {
        SetMessage("Mensaje de la Tienda", array("Incorrecta Informacion Del Item"));
        header("Location: index.php?do=shopitem");
        die();
    }
}

if(isset($_POST[itemid]))
{
    $itemid  = clean($_POST[itemid]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopItems(nolock) WHERE CSSID = $itemid");

    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopitem");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID  = $accid"));

    $totalprice       = $ires->Price;
    $accountbalance = $ares->Coins;
    $afterbalance   = $accountbalance - $totalprice;
    $ugradeid = $ares->UGradeID;

    if ($itemid == 1 && $ugradeid == 2)
    {
        SetMessage("Mensaje de la Tienda", array("Ya Usted Posee Jjang No Tiene Por Que Comprarlo De Nuevo."));
        header("Location: index.php?do=buyitem&itemid=$itemid");
        die();
    }
    elseif($itemid == 1 && $ugradeid != 0)
    {
        SetMessage("Mensaje de la Tienda", array("No Puedes Comprara Un Jjang A Un Moderador O A Un Usuario Banneado."));
        header("Location: index.php?do=buyitem&itemid=$itemid");
        die();
    }

    if($afterbalance < 0)
    {
        SetMessage("Error de la Tienda", array("Usted no Posee DCoins suficientes para comprar este Item."));
        header("Location: index.php?do=buyitem&itemid=$itemid");
        die();

    }else{
        if( $itemid == 1 )
        {
            mssql_query_logged("UPDATE Account SET UGradeID = 2, Coins = Coins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopItems SET Selled = Selled + 1 WHERE CSSID = $itemid");

            SetMessage("Mensaje de la Tienda", array("Compra Del Jjang Completa"));
            header("Location: index.php?do=shopitem");
            die();
        }
        else
        {
            mssql_query_logged("UPDATE Account SET Coins = Coins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopItems SET Selled = Selled + 1 WHERE CSSID = $itemid");

            //Head
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 1)");


            SetMessage("Mensaje de la Tienda", array("El Item a sido Comprado Satisfactoriamente, Tu item esta en el Storage"));
            header("Location: index.php?do=shopitem");
            die();
        }

    }
}else{
    $itemid  = clean($_GET[itemid]);

    $ires = mssql_query_logged("SELECT * FROM ShopItems(nolock) WHERE CSSID = $itemid");


    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopitem");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));

    $data = mssql_fetch_object($ires);
    switch($data->Slot)
{
    case 3:
        $type = "Armadura";
    break;
    case 2:
        $type = "Melee";
    break;
    case 1:
        $type = "Rango";
    break;
    case 5:
        $type = "Especial";
    break;
    default:
        $type = "Armadura";
    break;
}
}




?>
<script type="text/javascript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop</a></div>
    <div id="contentbox500" align="center">
    
	<table width="500" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td><a href="index.php?do=shopdonator">Donator Items</a></td>
        <td><a href="index.php?do=shopevent">Event Items</td>
        <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
        <td><a href="index.php?do=nicks">Extra</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">


            <table border="0" width="80%">
                <tr>
                    <td>
                    <div align="center">
                        <form method="POST" action="index.php?do=buyitem" name="frmBuy">

                            <table width="400" border="0">
                              <tr>
                                <td rowspan="6">
                                    <img border="0" src="images/shop/<?=$data->ImageURL?>" width="100" height="100" style="border: 2px solid #1D1B1C">
                                </td>
                              </tr>
                              <tr>
                                <td><?=$data->Name?></font></b></td>
                              </tr>
                              <tr>
                                <td>Tipo:<?=$type?></td>
                              </tr>
                              <tr>
                                <td>Sexo:<?=GetSexByID($data->Sex)?></td>
                              </tr>
                              <tr>
                                <td>Nivel:<?=$data->Level?></td>
                              </tr>
                              <tr>
                                <td>
                                    Precio:<span id="currentprice"><?=$data->Price?></span> DonadorCoins
                                    <input type="hidden" name="itemid" value="<?=$_GET[itemid]?>">
                                </td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">
                                    <div align="center">Duracion (Dias): Permanente.</div>
                                </td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">Total:<span id="Total"><?=$data->Price?></span></td>
                              </tr>
                              <tr>
                                <td colspan="2">Actual Balance:<span id="currbalance"><?=$acd->Coins?></span></td>
                              </tr>
                              <tr>
                                <td colspan="2">Despues:<span id="afterpur"><?=(($acd->Coins) - ($data->Price))?></span></td>
                              </tr>
                              <tr>
                                <td colspan="2">&nbsp;</td>
                              </tr>
                              <tr>
                                <td colspan="2">
                                
                                <a href="javascript:document.frmBuy.submit();">
                                    <img border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" id="img1764" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyitem2_on.jpg')">
                                </a>
                                <a href="index.php?do=shop">
                                    <img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')">
                                </a>
                                
                                </td>
                              </tr>
                            </table>
						</div>
					</td>
				</tr>
			</table> 
           </td>
         </tr>
        </table>

		</div>
    
    	<div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>                
			