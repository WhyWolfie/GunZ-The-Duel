<head>
	<meta http-equiv="Content-Language" content="es-cr">
</head>

<?php
include("secure/include.php");
SetTitle("FreshGunz - Clan Ranking");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=clanrank");
    SetMessage("Clan Ranking", array("Para Visualizar Clan Ranking Necesitas estar Logueado"));
    header("Location: index.php?do=login");
    die();
}
?>

<table width="500" align="center">
	<tr valign="top">
		<td>

            <div id="headerbox500" align="center">
            	<a class="title">Clan Ranking</a>
            </div>
            <div id="contentbox500" align="center">
            
            <table width="500">
              <tr class="ranking" valign="top">
                <td colspan="2" width="33.3%">
                <a href="index.php?do=individualrank" class="newsupdates">Ranking Individual</a>
                </td>
                <td colspan="2" width="33.3%">
                <a href="index.php?do=clanrank" class="newsupdates">Ranking De Clan</a>
                </td>
                <td colspan="2" width="33.3%">
                <a href="index.php?do=halloffame" class="newsupdates">Salon de la Fama</a>
                </td>
              </tr>
              </table>

                <table border="0" style="border-collapse: collapse" width="500">
                	<tr>
                		<td width="500" valign="top">
                	    	<table border="0" width="500">
                				<tr>
                					<td width="450" valign="top">
                
										<table border="0" width="450" height="146">
                                        	
											<?
                                            $res = mssql_query_logged("SELECT TOP 4 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                            
                                            $Count = 0;
                                            
                                            while($resa = mssql_fetch_object($res))
                                            {
                                            $FirstClan[$Count][Name]        = $resa->Name;
                                            $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "hqKqemp.png" : $resa->EmblemUrl;
                                            
                                            if($Count == 4)
                                            	break;
                                            else
                                            	$Count++;
                                            }
                                            
                                            $firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[0][EmblemURL];
                                            $firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[1][EmblemURL];
                                            $firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[2][EmblemURL];
                                            $firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[3][EmblemURL];
                                            
                                            $firstclanname0 = ($FirstClan[0][Name] == "") ? "No hay datos" : $FirstClan[0][Name];
                                            $firstclanname1 = ($FirstClan[1][Name] == "") ? "No hay datos" : $FirstClan[1][Name];
                                            $firstclanname2 = ($FirstClan[2][Name] == "") ? "No hay datos" : $FirstClan[2][Name];
                                            $firstclanname3 = ($FirstClan[3][Name] == "") ? "No hay datos" : $FirstClan[3][Name];
                                            
                                            
                                            $toprank = '
                                            <tr>
												<td width="144" valign="bottom" height="107">
												<div  align="center">
												<img src="http://imgur.com/'.$firstclanemb0.'" width="64" height="64" style="border: 1px solid #000000"></td>
												<td width="135" valign="bottom" height="107">
												<div align="center">
												<img src="http://imgur.com/'.$firstclanemb1.'" width="64" height="64" style="border: 1px solid #000000"></td>
												<td width="126" valign="bottom" height="107">
												<div align="center">
												<img src="http://imgur.com/'.$firstclanemb2.'" width="64" height="64" style="border: 1px solid #000000"></td>	
												</tr>
												<tr>
												<td width="450" colspan="4" height="40">
												<div align="center">
													<table border="0" width="450" height="100%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="128">
															<div align="center">
															<font color="#00FF00">
															<b>'.$firstclanname0.'</b></font></td>
															<td width="10">&nbsp;</td>
															<td width="126">
															<div align="center">
															<b>'.$firstclanname1.'</b></td>
															<td width="7">&nbsp;</td>
															<td width="122">
															<div align="center">
															<b>'.$firstclanname2.'</b></td>
															<td width="11">&nbsp;</td>
														</tr>
													</table>
                                            	</td>
                                            </tr>
										</table>
									</td>
								</tr>';
                                echo $toprank;
                                ?>
                                <tr>
                                    <td width="450" valign="top">
                                   
                                    
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="clanrank" />
                                    <select name="type">
                                    <option value="1">Nombre del Clan</option>
                                    <option value="2">Master del Clan</option>
                                    </select>��
                                    <input type="text" class="text" name="name"/>��
                                    <input type="submit" value="Buscar" />
                                    </td>
                                </tr>
                                <tr>
                                	<td width="450" valign="top">
                                    	<table border="0">
                                            <tr class="ranking">
                                                <td height="21" valign="bottom">
                                                Ranking
                                                </td>
                                                <td height="21" valign="bottom">
                                                Emblem
                                                </td>
                                                <td height="21" valign="bottom">
                                                Nombre del Clan
                                                </td>
                                                <td height="21" valign="bottom">
                                                L�der
                                                </td>
                                                <td height="21" valign="bottom">
                                                Win/Losses
                                                </td>
                                                <td height="21" valign="bottom">
                                                Win %
                                                </td>
                                                <td height="21" valign="bottom">
                                                Puntos
                                                </td>
											</tr>
											<?
                                            if( isset($_GET['type']) && isset($_GET['name']) )
                                            {
                                            $search = 1;
                                            $type = clean($_GET['type']);
                                            $name = clean($_GET['name']);
                                            
                                            if($type == 1)
                                            {
                                            $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                            }
                                            elseif($type == 2)
                                            {
                                            $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                            if( mssql_num_rows($charq) == 1 )
                                            {
                                            $characterdata = mssql_fetch_row($charq);
                                            $cid = $characterdata[0];
                                            $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Point DESC";
                                            }
                                            else
                                            {
                                                echo '
                                            <tr>
                                                <td width="480" colspan="5">
                                                <p align="center">
                                                No hay datos</td>
                                            </tr>';
                                            }
                                            }
                                            else
                                            {
                                            $search = 0;
                                            }
                                            }
                                            else
                                            {
                                            $search = 0;
                                            }
                                            
                                            if( $search == 0 )
                                            {
                                            switch( clean($_GET['page']) )
                                            {
                                            case "":
                                                $ranks = "Ranking <= 20";
                                            break;
                                            case "2":
                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                            break;
                                            case "3":
                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                            break;
                                            case "4":
                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                            break;
                                            case "5":
                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                            break;
                                            default:
                                                $ranks = "Ranking <= 20";
                                            break;
                                            }
                                            $res = mssql_query_logged("SELECT TOP 100 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) AND $ranks ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                            }
                                            else
                                            {
                                            $res = mssql_query_logged($squery);
                                            }
                                            if(mssql_num_rows($res) <> 0)
                                            {
                                            $count = 1;
                                            
                                            while($clan = mssql_fetch_object($res))
                                            {
                                            
                                            $clanemburl = ($clan->EmblemUrl == "") ? "noemblem.jpg" : $clan->EmblemUrl;
                                            $clanrank .= '
                                            <tr class="text c222">
                                            <td width="15%" align="center">
                                            <b>'.$count.'</b></td>
                                            <td width="15%" align="center">
                                            <div align="center">
                                            <img src="http://imgur.com/'.$clanemburl.'" width="34" height="30" style="border: 1px solid #000000"></td>
                                            <td width="22%" align="center">
                                            '.$clan->Name.'</td>
                                            <td width="15%" align="center">
                                            '.GetCharNameByCID($clan->MasterCID).'</td>
                                            <td width="5%" align="center">
                                            '.$clan->Wins . "/" . $clan->Losses.'</td>
                                            <td width="10%" align="center">
                                            '.GetClanPercent($clan->Wins, $clan->Losses).'</td>
                                            <td width="10%" align="center">
                                            '.$clan->Point.'</td>
                                            </tr>';
                                            $count++;
                                            }
                                            }else{
                                            
                                            msgbox("Clan o Master de Clan No Encontrado","index.php?do=clanrank");
                                            
                                            }
                                            echo $clanrank;
                                            ?>
                                		</table>
									</td>
								</tr>
								<?
                                if( $search == 0 )
                                {
                                ?>
                                <a href="index.php?do=clanrank"></a>
                                <?
                                }
                                ?>
							</table>
						</td>
					</tr>
				</table>

</div>

<div id="footerbox500" align="center"></div>
</td>
</tr>
</table>