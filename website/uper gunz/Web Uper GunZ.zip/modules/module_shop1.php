<?php
include("secure/include.php");
SetTitle("FreshGunZ - Tienda");
if( $_SESSION['AID'] == "" )
{
	SetURL("index.php?do=shop");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

$res = mssql_query("SELECT TOP 6 * FROM ShopItems(nolock) ORDER BY Selled DESC");

$count = 0;
                                                                                                                           
while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->CSSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}


?>


<table width="792" align="center">
  <tr valign="top">
    <td width="784">
    
    <div id="headerbox500" align="center"><a class="title">Shop</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="500" border="0">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td><a href="index.php?do=shop">Shop Home</a></td>
        <td><a href="index.php?do=shopdonator"></a></td>
        <td><a href="index.php?do=shopevent">Event Items</a></td>
        <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>
      <tr class="shopdisplaymenusite">
        <td colspan="6">&nbsp;<table border="0" style="border-collapse: collapse" width="778">
					<tr>
					  <td width="599" valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="771">
								<tr>
									<td style="background-image: url('images/content_title_shop_home.jpg'); background-repeat: no-repeat; background-position: center top" height="25" colspan="3">&nbsp;								  </td>
								</tr>
								
								<tr>
									<td style="background-repeat: repeat; background-position: center top" colspan="3"> </td>
							   	
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" colspan="3">
									<div align="center"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="614" valign="top">									</td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="614" valign="top">
									<div align="left"></td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" colspan="3" height="5"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="614" valign="top">
									<div align="center">
								    <table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" height="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top"><img border="0" src="images/shop/<?=$items[0][ImageURL]?>" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[0][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="120"><?=$items[0][Type]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="120"><?=$items[0][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Nivel:</td>
																					<td width="120"><?=$items[0][Level]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="120"><?=$items[0][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="10"><a href="index.php?do=buyitem&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1791',/*url*/'images/btn_buyitem3_on.jpg')" /></a></td>
																									<td width="52"><a href="index.php?do=infoitem&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>"><img src="images/btn_moreinfo3_off.jpg" name="img1792" width="56" height="23" border="0" id="img1792" onMouseOver="FP_swapImg(1,1,/*id*/'img1792',/*url*/'images/btn_moreinfo3_on.jpg')" onMouseOut="FP_swapImgRestore()" /></a></td>
																									<td width="90"><a href="index.php?do=giftitem&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1790',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>																				  </td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="120">&nbsp;</td>
																				</tr>
																			</table>
																		</div>																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/<?=$items[1][ImageURL]?>" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[1][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="120"><?=$items[1][Type]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="120"><?=$items[1][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Nivel:</td>
																					<td width="120"><?=$items[1][Level]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="120"><?=$items[1][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="10"><a href="index.php?do=buyitem&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791xD2" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1791xD2',/*url*/'images/btn_buyitem3_on.jpg')" /></a></td>
																									<td width="52"><a href="index.php?do=infoitem&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img1792xD1" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1792xD1',/*url*/'images/btn_moreinfo3_on.jpg')" /></a></td>
																									<td width="90"><a href="index.php?do=giftitem&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790xD3" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1790xD3',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																				  </td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="120">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/<?=$items[2][ImageURL]?>" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[2][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="120"><?=$items[2][Type]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="120"><?=$items[2][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Nivel:</td>
																					<td width="120"><?=$items[2][Level]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="120"><?=$items[2][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="10"><a href="index.php?do=buyitem&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791xDxD" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1791xDxD',/*url*/'images/btn_buyitem3_on.jpg')" /></a></td>
																									<td width="52"><a href="index.php?do=infoitem&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img1792xD" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1792xD',/*url*/'images/btn_moreinfo3_on.jpg')" /></a></td>
																									<td width="90"><a href="index.php?do=giftitem&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790xDxDxD" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1790xDxDxD',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																				  </td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="120">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
 																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/<?=$items[3][ImageURL]?>" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[3][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="120"><?=$items[3][Type]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="120"><?=$items[3][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Nivel:</td>
																					<td width="120"><?=$items[3][Level]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="120"><?=$items[3][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="10"><a href="index.php?do=buyitem&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img179111" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img179111',/*url*/'images/btn_buyitem3_on.jpg')" /></a></td>
																									<td width="52"><a href="index.php?do=infoitem&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img17921" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img17921',/*url*/'images/btn_moreinfo3_on.jpg')" /></a></td>
																									<td width="90"><a href="index.php?do=giftitem&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790111" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1790111',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																				  </td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="120">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
												  </table>
												</div>
												</td>
											</tr>
									  </table>

									</div>
								  </td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">&nbsp;									</td>
									<td style="background-repeat: repeat; background-position: center top" width="614">&nbsp;									</td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">&nbsp;									</td>
									<td style="background-repeat: repeat; background-position: center top" width="614">
									Sets Mas Comprados</td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" colspan="3" height="5">									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="10">
									<div align="center">
									&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="614">
									<div align="center">
								    <table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" height="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$items[4][ImageURL]?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[4][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="118">Complete Set</td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="118"><?=$items[4][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="118"><?=$items[4][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2"><a href="index.php?do=buyset&setid=<?=$items[4][ID]?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1773" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1773',/*url*/'images/btn_buyset_on.jpg')"></a></td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="118">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$items[5][ImageURL]?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[5][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="118">Complete Set</td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="118"><?=$items[5][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="118"><?=$items[5][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2"><a href="index.php?do=buyset&setid=<?=$items[5][ID]?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1773aav" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1773aav',/*url*/'images/btn_buyset_on.jpg')"></a></td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="118">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$items[6][ImageURL]?>" width="104" height="143" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[6][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="118">Complete Set</td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="118"><?=$items[6][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="118"><?=$items[6][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2"><a href="index.php?do=buyset&setid=<?=$items[6][ID]?>"> <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img177233" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img177233',/*url*/'images/btn_buyset_on.jpg')"></a></td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="118">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">
																		<img border="0" src="images/shop/<?=$items[7][ImageURL]?>" width="100" height="150" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td colspan="2">
																					<div align="left"><b><span class="item_name"><?=$items[7][Name]?></span></b></td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Tipo:</td>
																					<td width="118">Complete Set</td>
																				</tr>
																				<tr>
																					<td width="42" align="left">Sexo:</td>
																					<td width="118"><?=$items[7][Sex]?></td>
																				</tr>
																				<tr>
																					<td width="42" align="left"><span class="Estilo1" align="center">
																		Precio:</span></td>
																					<td width="118"><?=$items[7][Price]?></td>
																				</tr>
																				<tr>
																					<td colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td colspan="2"><a href="index.php?do=buyset&setid=<?=$items[7][ID]?>"><img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1773asd" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1773asd',/*url*/'images/btn_buyset_on.jpg')"></a></td>
																				</tr>
																				<tr>
																					<td width="42">&nbsp;</td>
																					<td width="118">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>

															</div>
															</td>
														</tr>
												  </table>
 												</div>
												</td>
											</tr>
									  </table>

									</div>
								  </td>
									<td style="background-repeat: repeat; background-position: center top" width="133">&nbsp;									</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" colspan="3"></td>
								</tr>
						  </table>
						</div>
					  </td>
				</tr>
</table></td>
      </tr>
      <!--<tr class="shopdisplaymenusite">
        <td colspan="6">Items + Vendidos</td>
      </tr>-->
    </table>
    
    
	<!--<table width="500" border="0">
  	   <tr> 
        
    	<td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>" title="<?=$items[0][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[0][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[0][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[0][Sex]?></div>												
        </td>
        
        <td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>" title="<?=$items[1][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[1][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[1][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[1][Sex]?></div>												
        </td>
        
        <td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>" title="<?=$items[2][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[2][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[2][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[2][Sex]?></div>												
        </td>
        
  	   </tr>
       
       <tr> 
        
    	<td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>" title="<?=$items[3][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[3][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[3][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[3][Sex]?></div>												
        </td>
        
        <td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[4][ID]?>&cat=<?=$items[4][CatID]?>" title="<?=$items[4][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[4][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[4][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[4][Sex]?></div>												
        </td>
        
        <td style="border:1px dashed #222;">
            <a href="index.php?do=buyitem&itemid=<?=$items[5][ID]?>&cat=<?=$items[5][CatID]?>" title="<?=$items[5][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[5][ImageURL]?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$items[5][Name]?></div>
            <div class="sexitem">Sexo: <?=$items[5][Sex]?></div>												
        </td>
        
  	   </tr>
       
	</table>-->
    
    
    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>