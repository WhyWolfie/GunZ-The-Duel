<?
include("secure/include.php");

SetTitle("QuanticGamers Gunz - Comprar Sets");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buyset&setid={$_GET[setid]}");
    SetMessage("Mensaje de la Tienda", array("Logueate antes de comprar, porfavor"));
    header("Location: index.php?do=login");
    die();
}

if(!isset($_POST[SetID]))
{
    if($_GET[setid] == "" || !is_numeric($_GET[setid]))
    {
        SetMessage("Mensaje de la Tienda", array("Item incorrecto"));
        header("Location: index.php?do=shopsets");
        die();
    }
}

if(isset($_POST[SetID]))
{
    $setid  = clean($_POST[SetID]);
    $accid  = clean($_SESSION[AID]);


    $ires = mssql_query_logged("SELECT * FROM ShopSets(nolock) WHERE SSID = $setid");

    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la tienda", array("Item no existe"));
        header("Location index.php?do=shopsets");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account  WHERE AID  = $accid"));

    $totalprice     = $ires->Price;
    $accountbalance = $ares->Coins;
    $afterbalance   = $accountbalance - $totalprice;

    if($afterbalance < 0)
    {
        SetMessage("Error from Shop", array("Usted no tiene suficientes Coins para comprar este art�culo"));
        header("Location: index.php?do=buyset&setid=$setid");
        die();

    }else{
        mssql_query_logged("UPDATE Account SET Coins = Coins - $totalprice WHERE AID = {$_SESSION[AID]}");
        mssql_query_logged("UPDATE ShopSets SET Selled = Selled + 1 WHERE SSID = $setid");

        //Head
        if( $ires->HeadItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod, Cnt)VALUES" .
                        "($accid, {$ires->HeadItemID}, GETDATE(), NULL, 1)");
        }
        //Chest
        if( $ires->ChestItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod, Cnt)VALUES" .
                        "($accid, {$ires->ChestItemID}, GETDATE(), NULL, 1)");
        }
        //Hand
        if( $ires->HandItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod, Cnt)VALUES" .
                        "($accid, {$ires->HandItemID}, GETDATE(), NULL, 1)");
        }
        //Leg
        if ( $ires->LegItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod, Cnt)VALUES" .
                        "($accid, {$ires->LegItemID}, GETDATE(), NULL, 1)");
        }
        //Feet
        if ( $ires->FeetItemID != 0 )
        {
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, RentHourPeriod, Cnt)VALUES" .
                        "($accid, {$ires->FeetItemID}, GETDATE(), NULL, 1)");
        }

        SetMessage("Mensaje de la tienda", array("Art�culo comprado con �xito, mira a su almacenamiento en gunz para usarlo"));
        header("Location: index.php?do=shopsets");
        die();

    }
}else{
    $setid  = clean($_GET[setid]);

    $ires = mssql_query_logged("SELECT * FROM ShopSets(nolock) WHERE SSID = $setid");


    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error en la tienda", array("set no existe"));
        header("Location index.php?do=shopsets");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));

    $data = mssql_fetch_object($ires);
}




?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Set</a></div>
    <div id="contentbox500" align="center">

<form method="POST" action="index.php?do=buyset" name="frmBuy">

<table width="500" class="text c222">
  <tr>
    <td rowspan="6"><img border="0" src="images/shop/<?=$data->ImageURL?>" width="100" height="150" style="border: 2px solid #1D1B1C"></td>
  </tr>
   <tr>
    <td><?=$data->Name?></td>
  </tr>
   <tr>
    <td>Tipo:Set Completo</td>
  </tr>
   <tr>
    <td>Sexo:<?=$data->Sex?></td>
  </tr>
   <tr>
    <td>Nivel:<?=$data->Level?></td>
  </tr>
   <tr>
    <td>Precio:<span id="currentprice"><?=$data->Price?></span> DonadorCoins
<input type="hidden" name="SetID" value="<?=$_GET[setid]?>">  </td>
  </tr>
   <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Duracion (Dias): Permanente.</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Total:<span id="Total"><?=$data->Price?></span></td>
  </tr>
  <tr>
    <td colspan="2">Actual Balance:<span id="currbalance"><?=$acd->Coins?></span></td>
  </tr>
  <tr>
    <td colspan="2">Despues:<span><?=(($acd->Coins) - ($data->Price))?></span></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">
    <a href="javascript:document.frmBuy.submit();">
        <img border="0" src="images/btn_buyset_off.jpg" width="79" height="23" id="img1764" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyset_on.jpg')"></a>
    
    <a href="index.php?do=shopsets">
        <img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="dale1872" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'dale1872',/*url*/'images/btn_cancel_on.jpg')">
	</a>
</td>
  </tr>
</table>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>

   <script language="javascript">
        UpdatePrice();
   </script>
   <?
// By sacker
?>