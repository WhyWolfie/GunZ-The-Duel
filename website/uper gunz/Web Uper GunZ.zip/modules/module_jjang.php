<? 
include "configjjang.php";
include("secure/include.php");

if( $_SESSION['AID'] == "" )
{
    
    SetMessage("Mensaje Compra", array("Usted necesita loguearse para comprar."));
    header("Location: index.php?do=login");
    die();
}
$query00 = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION['AID']}' AND CharNum != '-1' AND Name != '' ");

  if (mssql_num_rows($query00) < 1) {
    SetMessage("Mensaje", array("Usted no tiene ningun PJ."));
    header("Location: index.php?do=$redirec");
    die();
  }
SetTitle("$nombregunz - Comprar JJang");

 if (isset($_POST['submit'])) {
      $aid = ($_SESSION['AID']);
	  $mygrade = ($_SESSION['UGradeID']);
      $grade = ($_POST['color']);
      $precio = intval($precio);
	  $cssid = intval(1);
      
	     
      
	  switch($grade){
		case 2;
		$grade = 2;
		break;  
		default:
        SetMessage("Mensajer", array("La Identificaci�n del color no es v�lido!"));
        header("Location: index.php?do=jjang");
        die();	  
	  }
      if (!is_numeric($grade)) {
          SetMessage("Mensaje", array("Nombre del color no es v�lido!"));
          header("Location: index.php?do=jjang");
          die();
      }
       
      elseif($mygrade == 254 || $mygrade == 255 || $mygrade == 252 || $mygrade == 2 )  {
		  SetMessage("Mensaje Compra name color", array("No puedes comprar name color"));
          header("Location: index.php?do=jjang");
          die();  
	  }
	    
	  else
	if (empty($grade)) {
          SetMessage("Mensaje Comprar", array("!"));
          header("Location: index.php?do=jjang");
          die();
      } else {
         
          $query = mssql_query("SELECT $coins FROM Account(nolock) WHERE AID = '$aid'");
		  $skr = mssql_fetch_row($query);
          $info = mssql_fetch_assoc($query);
          $updatecoins = $info['$coins'] - $precio;
          
          if ($skr[0] < $precio) {
          SetMessage("Mensaje Compra name color", array("Usted no tiene $coins suficientes para comprar"));
          header("Location: index.php");
          die();
          } else {
           
              $addcolor = mssql_query_logged("UPDATE Account SET $coins = $coins - $precio WHERE AID = $aid");
					mssql_query("UPDATE Account SET UGradeID = '$grade' WHERE AID = '$aid'");
			 $by = "Echo por FireWork";
              if ($addcolor) {
				 
				  $_SESSION[UGradeID] = $grade;
                  msgbox("Has Comprado tu Jjang (EventWinner) Con Exito!.","index.php?do=nicks");
                  header("Location: index.php?do=$redirec");
                  die();
              } else {
                  SetMessage("Mensaje Compra name color", array("Hubo problemas con la compra."));
                  header("Location: index.php?do=$redirec");
                  die();
              }
          }
      }
  } else {
    
     
      $query01 = mssql_query("SELECT $coins, UGradeID FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
      $infoacc = mssql_fetch_object($query01);
	  
	  

  }
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">

<form method="POST" action="index.php?do=jjang" name="jjang">

<table width="500" class="text c222">
  <tr>
    <td rowspan="5"><img border="0" src="images/shop/donador/changename.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
  </tr>
   <tr>
    <td>Jjang</td>
  </tr>
   <tr>
    <td>Tipo:Especial</td>
  </tr> 
  <tr>
    <td>Duracion:Permanente</td>
  </tr> 
  <tr>
    <td>Precio:<? echo $precio?> EventCoins</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">
    Elije:
	<input name="color" type="radio" value="<? echo $numjjang ?>" checked="checked">
		<? echo $namejjang ?>
    </input>	
    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">Total:<? echo $precio?></td>
  </tr>
  <tr>
    <td colspan="2">Actual Balance:<?=$infoacc->$coins?></td>
  </tr>
  <tr>
    <td colspan="2">Despues:<?=$infoacc->$coins-$precio?></td>
  </tr>
  <tr>
    <td colspan="2">
    <input type="image" id="img1764" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyitem2_on.jpg')" onmouseout="FP_swapImgRestore()" src="images/btn_buyitem2_off.jpg" alt="buy color name" width="79" height="23" value="submit" name="submit"/>
	<a href="index.php?do=shopitem">
		<img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')">
    </a>
    </td>
  </tr>
</table>
								
</form>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>					