<? 
include "skrconfignamecolor.php";
include("secure/include.php");
?>
<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=buycolorname");
    SetMessage("Mensaje Compra name color", array("Usted necesita loguearse para comprar name color."));
    header("Location: index.php?do=login");
    die();
}
$query00 = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION['AID']}' AND CharNum != '-1' AND Name != '' ");

  if (mssql_num_rows($query00) < 1) {
    SetMessage("Mensaje Compra name color", array("Usted no tiene ningun PJ."));
    header("Location: index.php?do=$redirec");
    die();
  }
SetTitle("$namegz - Nombre a Color");

 if (isset($_POST['submit'])) {
      $aid = ($_SESSION['AID']);
	  $mygrade = ($_SESSION['UGradeID']);
      $grade = ($_POST['color']);
      $price = intval($price);
	  $cssid = intval(1);
      
	     
      
	  switch($grade){
		case $num_color_1;
		$grade = $num_color_1;
		break;  
		case $num_color_2;
		$grade = $num_color_2;
		break; 		  
		case $num_color_3;
		$grade = $num_color_3;
		break; 	
		case $num_color_4;
		$grade = $num_color_4;
		break; 
		case $num_color_5;
		$grade = $num_color_5;
		break; 
		case $num_color_6;
		$grade = $num_color_6;
		break; 
		case $num_color_7;
		$grade = $num_color_7;
		break; 
		case $num_color_8;
		$grade = $num_color_8;
		break;
		case $num_color_9;
		$grade = $num_color_9;
		break; 
		case $num_color_10;
		$grade = $num_color_10;
		break;
		case $num_color_11;
		$grade = $num_color_11;
		break;
		case $num_color_12;
		$grade = $num_color_12;
		break;
		case $num_color_13;
		$grade = $num_color_13;
		break;
		case $num_color_14;
		$grade = $num_color_14;
		break;
		case $num_color_15;
		$grade = $num_color_15;
		break;
		case $num_color_16;
		$grade = $num_color_16;
		break;
		case $num_color_17;
		$grade = $num_color_17;
		break;		
		default:
        SetMessage("Mensaje Compra name color", array("La Identificación del color no es válido!"));
        header("Location: index.php?do=buycolorname");
        die();	  
	  }
      if (!is_numeric($grade)) {
          SetMessage("Mensaje Compra name color", array("Nombre del color no es válido!"));
          header("Location: index.php?do=buycolorname");
          die();
      }
       
      elseif($mygrade == 254 || $mygrade == 255 || $mygrade == 252 )  {
		  SetMessage("Mensaje Compra name color", array("No puedes comprar name color"));
          header("Location: index.php?do=buycolorname");
          die();  
	  }
	    
	  else
	if (empty($grade)) {
          SetMessage("Mensaje Compra name color", array("No seleccione un color!"));
          header("Location: index.php?do=buycolorname");
          die();
      } else {
         
          $query = mssql_query("SELECT $typecoins FROM Account(nolock) WHERE AID = '$aid'");
		  $skr = mssql_fetch_row($query);
          $info = mssql_fetch_assoc($query);
          $updatecoins = $info['$typecoins'] - $price;
          
          if ($skr[0] < $price) {
          SetMessage("Mensaje Compra name color", array("Usted no tiene $typecoins suficientes para comprar name color"));
          header("Location: index.php");
          die();
          } else {
           
              $addcolor = mssql_query_logged("UPDATE Account SET $typecoins = $typecoins - $price WHERE AID = $aid");
					mssql_query("UPDATE Account SET UGradeID = '$grade' WHERE AID = '$aid'");
			 $by = "";
              if ($addcolor) {
				 
				  $_SESSION[UGradeID] = $grade;
                   msgbox("Su nombre a color fue comprado con gran Exito!.","index.php?do=nicks");
                  header("Location: index.php?do=$redirec");
                  die();
              } else {
                  SetMessage("Mensaje Compra name color", array("Hubo problemas con la compra."));
                  header("Location: index.php?do=$redirec");
                  die();
              }
          }
      }
  } else {
    
     
      $query01 = mssql_query("SELECT $typecoins, UGradeID FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
      $infoacc = mssql_fetch_object($query01);
	  
	  

  }
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Nombre a color</a></div>
    <div id="contentbox500" align="center">

<form method="POST" action="index.php?do=buycolorname" name="buycolorname">

<table width="500" class="text c222">
	<tr>
		<td rowspan="6"><img border="0" src="images/shop/Especial/buycolorname.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
	</tr>
	<tr>
		<td>Nombre a Color</td>
	</tr>
	<tr>
		<td>Tipo: Especial</td>
	</tr>
	<tr>
		<td>Duracion:Permanente</td>
	</tr>
	<tr>
		<td>Nivel:0</td>
	</tr>
	<tr>
		<td>Precio:<? echo $price?> DonadorCoins</td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2">
			<div align="center">Elije: <select name="color" class="cero">
                                <option selected value="">Seleccionar color</option>
                                <option  value="<? echo $num_color_1 ?>"><? echo $name_color_1 ?></option>
                                <option  value="<? echo $num_color_2 ?>"><? echo $name_color_2 ?></option>
                                <option  value="<? echo $num_color_3 ?>"><? echo $name_color_3 ?></option>
                                <option  value="<? echo $num_color_4 ?>"><? echo $name_color_4 ?></option>
                                <option  value="<? echo $num_color_5 ?>"><? echo $name_color_5 ?></option>
                                <option  value="<? echo $num_color_6 ?>"><? echo $name_color_6 ?></option>
                                <option  value="<? echo $num_color_7 ?>"><? echo $name_color_7 ?></option>
                                <option  value="<? echo $num_color_8 ?>"><? echo $name_color_8 ?></option>
                                <option  value="<? echo $num_color_9 ?>"><? echo $name_color_9 ?></option>
                                <option  value="<? echo $num_color_10 ?>"><? echo $name_color_10 ?></option>
								<option  value="<? echo $num_color_11 ?>"><? echo $name_color_11 ?></option>
                                <option  value="<? echo $num_color_12 ?>"><? echo $name_color_12 ?></option>
                                <option  value="<? echo $num_color_13 ?>"><? echo $name_color_13 ?></option>
                                <option  value="<? echo $num_color_14 ?>"><? echo $name_color_14 ?></option>
                                <option  value="<? echo $num_color_15 ?>"><? echo $name_color_15 ?></option>
                                <option  value="<? echo $num_color_16 ?>"><? echo $name_color_16 ?></option>
                                <option  value="<? echo $num_color_17 ?>"><? echo $name_color_17 ?></option>                               </select></div>
		</td>
	</tr>
	<tr>
		<td colspan="2">Total:<? echo $price?></td>
	</tr>
	<tr>
		<td colspan="2">Actual Balance<?=$infoacc->$typecoins?></td>
	</tr>
	<tr>
		<td colspan="2">Despues:<?=$infoacc->$typecoins-$price?></td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2">
        
        <input type="image" id="img1764" src="images/cart.gif" alt="buy color name" width="79" height="23" value="submit" name="submit"/>
									
		<a href="index.php?do=shopitem">
		<img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')"></a>
        
        </td>
	</tr>
</table>

</form>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>