<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?
SetTitle("FRESH - GunZ - Subir Emblema");
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Emblem Upload</a></div>
    <div id="contentbox500" align="center">

<table border="0" width="100%">
	<tr>
		<td valign="top">
			<div align="center">
				<table width="83%">
				
					<tr class="text c222">
						<td>
							<div align="center">
								<p>Porfavor Primero debe Subir El Emblema del Clan:</p>
								<p>&nbsp;</p>
								<p><?php
									   echo '
										  <table border="0" width="240">
										   <tr><td>
											  <table>
											   <tr><td>
												
												
									   ';
									 //Select User AID
									 $seluaid = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION[AID]."'");
									 $uaid = mssql_fetch_object($seluaid);
									 //Select User CID
									 $selucid = mssql_query("SELECT * FROM Character WHERE AID='".$uaid->AID."' AND DeleteFlag='0'");
									  echo '<br />
									  <table border="0" align="center">
										<form action="index.php?do=emblems2" method="post" enctype="multipart/form-data">
										  <tr><td><div><select name="clanname">
									  ';
									 while($ucid = mssql_fetch_object($selucid)){
									 //Select User Clan
									 $seluclan = mssql_query("SELECT * FROM Clan WHERE MasterCID='".$ucid->CID."' AND DeleteFlag='0'");
									 while($uclan = mssql_fetch_object($seluclan)){
													 
										echo '
											<option value="'.$uclan->Name.'">'.$uclan->Name.'</option>
										';
									   
									 }}
									   echo '</select></div></td>
										  <td><input type="text" name="link" /></td>
										  <td><input type="submit" name="insert" value="Subir!" /></td></tr>
										</form>
										</table>
										   <br />
										';
									
									//Upload
									echo '<div class="errmess">';
									 if(isset($_POST['insert'])){
									 $clanname = ($_POST['clanname']);
									 $emblem = ($_POST['link']);
									 
										  
										  $sqluploademb = mssql_query("UPDATE Clan SET EmblemUrl='$emblem' WHERE Name='$clanname'");
										  $sqluploademb = ("UPDATE Clan SET EmblemChecksum='1' WHERE Name='$clanname'");
										  echo "Emblem Uploaded!";	 
										  
									 }
									echo '</div>';
									 
										echo ' <br />
												
											   </td></tr>
											  </table>
											</td></tr>
										  </table>
									   ';
									?>
                                    </p>
									</div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <p align="center">&nbsp;</td>
                </tr>
            </table>
                    
		</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>