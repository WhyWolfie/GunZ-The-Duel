<? 
// Configuracion de Price redireccion y type de coins   By sacker.
$namegz			=		"Quantic Gunz";		// Name del GunZ Por Default viene con Galaxia Gunz
$price			=		"250";  // PRECIO DEL NAME COLOR
$typecoins		=		"Coins"; // Tabla del tipo de Coins Existe 3, Coins, EventCoins y DonatorCoins
$redirec		=		"nicks"; // Cuando compre o aiga problemas a dnd qieress q vaya del do
//____________________________________________________________
// CONFIGURACION NAME COLOR BY SACKER

$num_color_1	=		"3"; // NumeroUgrade Color 1
$num_color_2	=		"4"; // NumeroUgrade Color 1
$num_color_3	=		"5"; // NumeroUgrade Color 1



//Name del color 

$name_color_1	=		"Amarillo"; // Nombre del primer color
$name_color_2	=		"Rosado"; // Nombre del primer color
$name_color_3	=		"Azul"; // Nombre del primer color


// Todos los creditos a Sacker  :  s4cker@hotmail.com  
?>