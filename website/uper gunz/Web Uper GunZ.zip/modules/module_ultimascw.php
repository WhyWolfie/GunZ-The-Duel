<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Ultimos Clan War</a></div>
    <div id="contentbox500" align="center">

<table width="450"> 
  <tr class="clanwar" height="25"> 
    <td width="40" align="center" class="win">Win</td> 
    <td width="150" align="center" class="win">&nbsp;Clan Ganador</td> 
    <td width="20"></td> 
    <td width="150" align="center" class="losse">Clan Perdedor</td> 
    <td width="40" align="center" class="losse">Losse</td> 
  </tr> 
   
</table> 
<?php 
$busca999 = mssql_query("SELECT TOP 7 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC"); 
$busca998 = mssql_fetch_row($busca999); 

while($item22 = mssql_fetch_row($busca999)) 
{ 

?> 
<table width="450"> 
  <tr class="clanwar"> 
    <td width="40" align="center" class="win"><?=$item22[2]?></td> 
    <td width="150" align="center" class="win"><?=$item22[0]?></td> 
    <td width="20" align="center">Vs</td> 
    <td width="150" align="center" class="losse"><?=$item22[1]?></td> 
    <td width="40" align="center" class="losse">- <?=$item22[3]?></td> 
  </tr> 
   
</table> 

<? 
} 
?>


</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>