<?
include("secure/include.php");

if($_SESSION[UserID] <> "")
{
    msgbox("Para Registrarte Debes estar deslogeado. Click en Aceptar para Deslogearte.","index.php?do=logout");
	
}

if(isset($_POST[submit]))
{
    $user           = clean($_POST[userid]);
    $names          = clean($_POST[namea]);
    $pass[0]        = clean($_POST[pass1]);
    $pass[1]        = clean($_POST[pass2]);
    $email          = clean($_POST[email]);
    $sq             = clean($_POST[sq]);
    $sa             = clean($_POST[sa]);

    if($pass[0] != $pass[1]){
        SetMessage("Register", array("Las contrase�as no coinciden"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE UserID = '$user'") ) <> 0 ){
        SetMessage("Register", array("The UserID $userid is already in use"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ( mssql_num_rows( mssql_query_logged("SELECT * FROM Account(nolock) WHERE Email = '$email'") ) <> 0 ){
        SetMessage("Register", array("The Email $email is already in use"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($user == ""){
        SetMessage("Register", array("Por Favor introduzca un nombre de Usuario"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($pass[0] == "" || $pass[1] == ""){
        SetMessage("Register", array("Por Favor introduzca una clave"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($email == ""){
        SetMessage("Register", array(".Porfavor introduzca un E-mail"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($sq == ""){
        SetMessage("Register", array("Por favor, introduzca una pregunta secreta"));
        header("Location: index.php?do=register");
        die();
    }
    elseif ($sa == ""){
        SetMessage("Register", array("Por favor, introduzca una respuesta secreta"));
        header("Location: index.php?do=register");
        die();
    }
    elseif (strlen($user) < 3){
        SetMessage("Register", array("El ID de usuario es demasiado corto (minimo 6 caracteres)"));
        header("Location: index.php?do=register");
        die();
    }
    elseif (strlen($pass[0]) < 3){
        SetMessage("Register", array("La contrase�a es demasiado corta (minimo 6 caracteres)"));
        header("Location: index.php?do=register");
        die();
    }
    else{

            $registered = 1;
           mssql_query("INSERT INTO Account (UserID, Name, Email, UGradeID, PGradeID, RegDate, sa, sq, Coins, EventCoins, DonatorCoins)Values ('$user', '$names','$email', 0, 0, GETDATE(), '$sa', '$sq', 0, 0, 0)");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            $dias = 12;
            $dias = $dias * 24;
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '520058', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '520558', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '521050', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '521051', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '521550', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '521551', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '522041', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '522541', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '523044', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '523045', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '523544', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '523545', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '524044', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '524544', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '789852', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '895583', GETDATE(), '120', '1')");
            mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '287350', GETDATE(), '120', '1')");
			mssql_query("INSERT INTO Login ([UserID], [AID], [Password])Values ('$user', '$aid', '$pass[0]')");
        SetMessage("Register", array("La cuenta $user se ha creado con �xito, Recuerda revisar su Storage"));
        header("Location: index.php");
        die();
    }

}else{
    SetTitle("Fresh Gunz - Registro");

    $europe = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

    $p = GetCountryCodeByIP($_SERVER[REMOTE_ADDR]);
    if(in_array(strtoupper($p), $europe))
    {
        $country = sprintf("[<font color='#00FF00'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }else{
        $country = sprintf("[<font color='#FF0000'>%s</font>] %s", $p, GetCountryNameByIP($_SERVER[REMOTE_ADDR]));
    }
}



?>
<style type="text/css">
<!--
.Estilo1 {font-size: 12px}
-->
</style>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Registro</a></div>
    <div id="contentbox500" align="center">

<table border="0" class="text" width="100%">
					<tr>
						<td valign="top">
						<div align="center">
							<table border="0" width="100%">
								<tr>
									<td>
									<div align="center">
										<form method="POST" action="index.php?do=register" name="register">
											<table border="0" width="408" height="100%">
											<tr>
												<td width="401" colspan="5" height="62">
												<div align="center">
													<table border="0" width="404" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="378">
															<p align="center">
															<font color="#FF0000" size="-4">
															Recuerda Que 
															Ninguno De los miembros del Staff Te 
															Pedira Tu 
															Contrase�a! Asi Que 
															De Ninguna Manera 
															Nunca Se La Digas A 
															Nadie!</font></td>
															<td width="9">&nbsp;</td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img13"></td>
												<td width="183" align="center">
												<div align="center">UserID</td>
												<td width="183" align="left">
												<input type="text" name="userid" size="19" class="text"></td>
												
												<td width="16">&nbsp;</td>
												
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9"><img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img13"></td>
												<td width="183" align="center">Nombre</td>
												<td width="183" align="center"><input name="namea" type="text" class="text" id="namea" size="19"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="center">
												Contrase�a</td>
												<td width="183" align="center">
												<input type="password" name="pass1" size="19" class="text"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												Repita Contrase�a</td>
												<td width="183" align="left">
												<input type="password" name="pass2" size="19" class="text"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												E-Mail</td>
												<td width="183" align="left">
												<input type="text" name="email" size="19" class="text"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">
												<div align="left">
												<font color="#FFFF00">
												<span style="font-size: 7pt">Por 
												Favor Introduzca Un Email 
												Valido!</span></font></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="402" colspan="5">
												<p align="center">
												<img border="0" src="images/mis_sepline.jpg" width="391" height="2"></td>
											</tr>
											<tr>
												<td width="402" colspan="5" height="62" >
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="404" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="378">
															<p align="center"><font color="#FFFF00">
															Recuerden Que La 
															Pregunta Y Respuesta 
															Secreta Los Ayuda A 
															Recuperar Su Cuenta 
															Si Se Les Ah 
															Olvidado!</td>
															<td width="9">&nbsp;</td>
														</tr>
													</table>
												</div>
												</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												Pregunta Secreta</td>
												<td width="183" align="left">
												<input type="text" name="sq" size="19" class="text"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="183" align="left">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">
												<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
												<td width="183" align="left">
												Respuesta Secreta</td>
												<td width="183" align="left">
												<input type="text" name="sa" size="19" class="text"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="366" colspan="2">
												<p align="center">
												<input border="0" name="img123" type="submit" class="submit" value="Crear cuenta"></td>
												<td width="16">&nbsp;</td>
											</tr>
											<tr>
												<td width="11">&nbsp;</td>
												<td width="9">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="183">&nbsp;</td>
												<td width="16">&nbsp;</td>
											</tr>
										</table>
											<input type="hidden" name="submit" value="1"></form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
				</table>
<?
$filhodaputa = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>