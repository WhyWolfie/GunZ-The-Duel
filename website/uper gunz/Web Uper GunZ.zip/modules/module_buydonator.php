<?php
include("secure/include.php");

SetTitle("Fresh GunZ - Comprar Item");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=buydonator&itemid={$_GET[itemid]}");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
}

if(!isset($_POST[itemid]))
{
    if($_GET[itemid] == "" || !is_numeric($_GET[itemid]))
    {
        SetMessage("Mensaje de la Tienda", array("Incorrecta Informacion Del Item"));
        header("Location: index.php?do=shopdonator");
        die();
    }
}

if(isset($_POST[itemid]))
{
    $itemid  = clean($_POST[itemid]);
    $accid  = clean($_SESSION[AID]);

    $ires = mssql_query_logged("SELECT * FROM ShopDonator(nolock) WHERE CSSID = $itemid");

    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopdonator");
        die();
    }

    $ires = mssql_fetch_object($ires);

    $ares = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID  = $accid"));

    $totalprice       = $ires->Price;
    $accountbalance = $ares->DonatorCoins;
    $afterbalance   = $accountbalance - $totalprice;
    $ugradeid = $ares->UGradeID;

    if ($itemid == 999 && $ugradeid == 2)
    {
        SetMessage("Mensaje de la Tienda", array("Ya Usted Posee Jjang No Tiene Por Que Comprarlo De Nuevo."));
        header("Location: index.php?do=buydonator&itemid=$itemid");
        die();
    }
    elseif($itemid == 999 && $ugradeid != 0)
    {
        SetMessage("Mensaje de la Tienda", array("No Puedes Comprara Un Jjang A Un Moderador O A Un Usuario Banneado."));
        header("Location: index.php?do=buydonator&itemid=$itemid");
        die();
    }

    if($afterbalance < 0)
    {
        SetMessage("Error de la Tienda", array("Usted no Posee DCoins suficientes para comprar este Item."));
        header("Location: index.php?do=buydonator&itemid=$itemid");
        die();

    }else{
        if( $itemid == 999 )
        {
            mssql_query_logged("UPDATE Account SET UGradeID = 2, DonatorCoins = DonatorCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopDonator SET Selled = Selled + 1 WHERE CSSID = $itemid");

            SetMessage("Mensaje de la Tienda", array("Compra Del Jjang Completa"));
            header("Location: index.php?do=shopdonator");
            die();
        }
        else
        {
            mssql_query_logged("UPDATE Account SET DonatorCoins = DonatorCoins - $totalprice WHERE AID = {$_SESSION[AID]}");
            mssql_query_logged("UPDATE ShopItems SET Selled = Selled + 1 WHERE CSSID = $itemid");

            //Head
            mssql_query_logged("INSERT INTO AccountItem(AID, ItemID, RentDate, Cnt)VALUES" .
                        "($accid, {$ires->zItemID}, GETDATE(), 1)");


            SetMessage("Mensaje de la Tienda", array("El Item a sido Comprado Satisfactoriamente, Tu item esta en el Storage"));
            header("Location: index.php?do=shopdonator");
            die();
        }

    }
}else{
    $itemid  = clean($_GET[itemid]);

    $ires = mssql_query_logged("SELECT * FROM ShopDonator(nolock) WHERE CSSID = $itemid");


    if(mssql_num_rows($ires) == 0)
    {
        SetMessage("Error de la Tienda", array("Item not found"));
        header("Location index.php?do=shopdonator");
        die();
    }

    $acd = mssql_fetch_object(mssql_query_logged("SELECT * FROM Account(nolock) WHERE AID = {$_SESSION[AID]}"));

    $data = mssql_fetch_object($ires);
    switch($data->Slot)
{
    case 3:
        $type = "Armadura";
    break;
    case 2:
        $type = "Melee";
    break;
    case 1:
        $type = "Rango";
    break;
    case 5:
        $type = "Especial";
    break;
    default:
        $type = "Armadura";
    break;
}
}




?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop Donator</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="490" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td colspan="2"><a href="index.php?do=shopdonator">Items Donator</a></td>
        <td colspan="2"><a href="index.php?do=shopsets">Sets Donator</a></td>
        <td colspan="2"><a href="index.php?do=shopevent">Event Shop</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">


<form method="POST" action="index.php?do=buydonator" name="frmBuy">
		
        
<table width="490" border="0">
  <tr>
    <td rowspan="6" width="50%"><img border="0" src="images/shop/<?=$data->ImageURL?>" width="80" height="80" style="border: 2px solid #1D1B1C"></td> 
  </tr>
  <tr>
  	<td  width="50%">Nombre: <?=$data->Name?></td>
  </tr>
  <tr>
    <td>Tipo: <?=$type?></td>
  </tr>
  <tr>
    <td>Sexo: <?=GetSexByID($data->Sex)?></td>
  </tr>
  <tr>
    <td>Level: <?=$data->Level?></td>
  </tr>
  <tr>
    <td>Costo: <?=$data->Price?></td>
  </tr>
      

   <tr>
	<td colspan="2" height="40">
        
        Item permanente
        
    </td>
   </tr>
   
   <tr>
		<td>
        Costo del Item:
        </td>
        <td colspan="2">
		<?=$data->Price?>
		</td>
    </tr>
    <tr>
		<td>
        Tus Coins:
        </td>
        <td>
        <?=$acd->DonatorCoins?>
		</td>
    </tr>
    <tr>
		<td>
        Operacion:
        </td>
        <td>
        <?=(($acd->DonatorCoins) - ($data->Price))?>
    	</td>
    </tr>
    <tr>
    	<td colspan="2">
                                                                                        
        <a href="javascript:document.frmBuy.submit();">
        <img border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" id="img1764" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'images/btn_buyitem2_on.jpg')"></a>
        <a href="index.php?do=shopdonator">
        <img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')"></a>

		</td>
   </tr>
</table>



</td>
</table>

</form>

</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>