<?php
include("secure/include.php");
SetTitle("Fresh GunZ - Donator Items Lista");

$sex = ($_GET[sex] == "") ? "2" : strtolower(clean($_GET[sex]));
$sex = ($sex < 0 || $sex > 2) ? "0" : $sex;

$sort = ($_GET[sort] == "") ? "0" : strtolower(clean($_GET[sort]));

$bodypart = ($_GET[bodypart] == "") ? "0" : strtolower(clean($_GET[bodypart]));
$bodypart = ($bodypart < 0 || $bodypart > 6) ? "0" : $bodypart;

if($sex == 2 && $bodypart == 0)
{
    $conditions = "";
}
elseif($sex == 2 && $bodypart != 0)
{
    $conditions = "WHERE BodyPart = $bodypart";
}
elseif($sex != 2 && $bodypart == 0)
{
    $conditions = "WHERE Sex = $sex";
}
elseif($sex != 2 && $bodypart != 0)
{
    $conditions = "WHERE Sex = $sex AND BodyPart = $bodypart";
}

switch ($sort)
{
    case 0:
    $sortq = "ORDER BY CSSID DESC";
    break;
    case 1:
    $sortq = "ORDER BY CSSID ASC";
    break;
    case 2:
    $sortq = "ORDER BY Level ASC";
    break;
    case 3:
    $sortq = "ORDER BY Level DESC";
    break;
    case 4:
    $sortq = "ORDER BY Price ASC";
    break;
    case 5:
    $sortq = "ORDER BY Price DESC";
    break;
    default:
    $sortq = "ORDER BY CSSID DESC";
    break;
}

$res = mssql_query_logged("SELECT * FROM ShopDonator(nolock) $conditions $sortq");


$count = 1;
$page = 1;
while( $a = mssql_fetch_object( $res ) ){
    $set[$count][$page]['SSID']         =  $a->CSSID;
    $set[$count][$page]['Name']         =  $a->Name;
    $set[$count][$page]['Level']        =  $a->Level;
    $set[$count][$page]['Price']        =  $a->Price;
    $set[$count][$page]['Sex']          =  $a->Sex;
    $set[$count][$page]['ImageURL']     =  $a->ImageURL;

    if ( $count == 6 ){
        $count = 1;
        $page++;
    }else{
        $count++;
    }

}

$cpage = ($_GET[page] == "") ? 1 : $_GET[page];

if($cpage > $page)
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopdonator");
    die();
}else if(!is_numeric($cpage))
{
    SetMessage("Error from Shop", array("Incorrect page number"));
    header("Location: index.php?do=shopdonator");
    die();
}

for ($i = 1; $i <= $page; $i++) {
    if($cpage == $i){
        $prefix = "<font color='#00FF00'><b>";
        $sufix = '</b></font>';
    }else{
        $prefix = "";
        $sufix = '';
    }
    $pagelinks.="[<a href='index.php?do=shopdonator&page=$i&sex=$sex&sort=$sort&bodypart=$bodypart'>$prefix$i$sufix</a>] ";
}

$type = "Donator";

?>
<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Shop Donator</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="500" border="0" align="center">
      <tr class="shopdisplaymenu shopdisplaymenusite">
        <td><a href="index.php?do=shop">Shop Home</a></td>
        <td><a href="index.php?do=shopdonator">Donator Items</a></td>
        <td><a href="index.php?do=shopevent">Event Items</td>
        <td><a href="index.php?do=shopitem&cat=2">Sword Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=1">Ranged Shop</a></td>
        <td><a href="index.php?do=shopitem&cat=5">Special Items</a></td>
      </tr>
      <tr class="shopdisplaymenu">
        <td height="132" colspan="6"><img border="0" src="images/FreshGz.GIF" width="490" height="130"></td>
      </tr>    
      
      <tr class="shopdisplaymenusite">
        <td colspan="6">
        
        
        <form method="GET" name="setlist" action="index.php?do=shopdonaor">
									
<select name="bodypart" onChange="document.location = 'index.php?do=shopdonator&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + '&bodypart=' + document.setlist.bodypart.value;">
<option value="0" <?=($_GET[bodypart] == "0") ? "selected" : ""?>>Todos</option>
<option value="6" <?=($_GET[bodypart] == "6") ? "selected" : ""?>>No Armaduras</option>
<option value="1" <?=($_GET[bodypart] == "1") ? "selected" : ""?>>Armadura: Cabeza</option>
<option value="2" <?=($_GET[bodypart] == "2") ? "selected" : ""?>>Armadura: Cuerpo</option>
<option value="3" <?=($_GET[bodypart] == "3") ? "selected" : ""?>>Armadura: Manos</option>
<option value="4" <?=($_GET[bodypart] == "4") ? "selected" : ""?>>Armadura: Piernas</option>
<option value="5" <?=($_GET[bodypart] == "5") ? "selected" : ""?>>Armadura: Pies</option>
</select>
Sexo:
<select <?=($_GET[bodypart] == 0 || $_GET[bodypart] == 6) ? "disabled " : ""?>size="1" name="sex" onChange="document.location = 'index.php?do=shopdonator&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + '&bodypart=' + document.setlist.bodypart.value;">
<?
if($_GET[bodypart] == 0 || $_GET[bodypart] == 6)
{
?>
<option value="2" <?=($_GET[sex] == "2") ? "selected" : ""?>>Hombre y Mujer</option> <? } ?>
<option value="2" <?=($_GET[sex] == "2") ? "selected" : ""?>>Hombre y Mujer</option>
<option value="0" <?=($_GET[sex] == "0") ? "selected" : ""?>>Hombre</option>
<option value="1" <?=($_GET[sex] == "1") ? "selected" : ""?>>Mujer</option>
</select>
Ordenar:

<select name="sort" onChange="document.location = 'index.php?do=shopdonator&sex=' + document.setlist.sex.value + '&sort=' + document.setlist.sort.value + '&bodypart=' + document.setlist.bodypart.value;">
<option value="0" <?=($_GET[sort] == "0") ? "selected" : ""?>>Nuevos Primero</option>
<option value="1" <?=($_GET[sort] == "1") ? "selected" : ""?>>Viejos Primero</option>
<option value="2" <?=($_GET[sort] == "2") ? "selected" : ""?>>Nivel: Bajo Primero</option>
<option value="3" <?=($_GET[sort] == "3") ? "selected" : ""?>>Nivel: Alto Primero</option>
<option value="4" <?=($_GET[sort] == "4") ? "selected" : ""?>>Precio: Bajo Primero</option>
<option value="5" <?=($_GET[sort] == "5") ? "selected" : ""?>>Precio: Alto Primero</option>
</select>

</form>
        
        
        </td>
      </tr>
      
						


  	   <tr> 
		<?
		if($set[1][$cpage]['Name'] <> "")
		{
		?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buydonator&itemid=<?=$set[1][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[1][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[1][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[1][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[1][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[1][$cpage]['Level']?></div>	
        									
        </td>
		<?
		}
		?>
        
        
       	<?
		if($set[2][$cpage]['Name'] <> "")
		{
		?>	
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
         
            <a href="index.php?do=buydonator&itemid=<?=$set[2][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[2][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[2][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[2][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[2][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[2][$cpage]['Level']?></div>
           										
        </td>
		<?
		}
		?>
        
        
       	<?
		if($set[3][$cpage]['Name'] <> "")
		{
		?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
         	
            <a href="index.php?do=buydonator&itemid=<?=$set[3][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[3][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[3][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[3][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[3][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[3][$cpage]['Level']?></div>
            									
        </td>
		<?
		}
		?>		
   </tr>
   <tr> 
        
        <?
		if($set[4][$cpage]['Name'] <> "")
		{
		?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buydonator&itemid=<?=$set[4][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[4][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[4][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[4][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[4][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[4][$cpage]['Level']?></div>
            											
        </td>
		<?
		}
		?>
        
        
        <?
		if($set[5][$cpage]['Name'] <> "")
		{
		?>
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        	
            <a href="index.php?do=buydonator&itemid=<?=$set[5][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[5][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[5][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[5][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[5][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[5][$cpage]['Level']?></div>
            											
        </td>
		<?
		}
		?>
        
        
        <?
		if($set[6][$cpage]['Name'] <> "")
		{
		?>	
    	<td style="border:1px dashed #222;" width="33.3%" colspan="2">
        
            <a href="index.php?do=buydonator&itemid=<?=$set[6][$cpage]['SSID']?>&cat=<?=$cat?>" title="<?=$set[6][$cpage]['Price']?> Coins"> <img class="shop" border="0" src="images/shop/<?=$set[6][$cpage]['ImageURL']?>" width="80" height="80">
            </a>
            <div class="nameitem">Nombre: <?=$set[6][$cpage]['Name']?></div>
            <div class="sexitem">Tipo: <?=$type?></div>
            <div class="sexitem">Sexo: <?=GetSexByID($set[6][$cpage]['Sex']);?></div>
            <div class="sexitem">Level: <?=$set[6][$cpage]['Level']?></div>
            											
        </td>
		<?
		}
		?>
      </tr>
        <tr class="shopdisplaymenusite">
        	<td colspan="6"><?=$pagelinks?></td>		
   </tr>
</table>
</div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>