<?php
include("secure/include.php");
if($_SESSION[AID] != "")
{
    header("Location: index.php");
    die();
}

if(isset($_POST[submit]))
{
    $user = clean($_POST[userid]);
    $pass = clean($_POST[pass]);

    $ip = $_SERVER['REMOTE_ADDR'];

    // Borrar fails antiguos
    mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );

    // Buscar fails para la ip actual
    $strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
    $strikedata = mssql_fetch_object($strikeq);

    if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
    {
        SetMessage("You may not login", array("You have failed to login 5 times in the last 15 minutes", "You have to wait 15 minutes to try again"));
        header("Location: index.php");
        die();
    }

    $loginquery = mssql_query_logged("SELECT l.UserID, l.AID, c.UGradeID, l.Password FROM Login(nolock) l INNER JOIN Account(nolock) c ON l.AID = c.AID WHERE l.UserID = '$user' AND l.Password = '$pass'");
    if(mssql_num_rows($loginquery) == 1)
    {
        $logindata = mssql_fetch_row($loginquery);

        $_SESSION[UserID] = $logindata[0];
        $_SESSION[AID] = $logindata[1];
        $_SESSION[UGradeID] = $logindata[2];
        $_SESSION[Password] = md5(md5($logindata[3]));

        $url = ($_SESSION[URL] == "") ? "index.php" : $_SESSION[URL];
        $_SESSION[URL] = "";

        header("Location: $url");
        die();
    }else{
        mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
        SetMessage("Mensaje Del Login", array("Incorrecto UserID o Contrase�a"));
        header("Location: index.php?do=login");
        die();
    }
}else{
    SetTitle("Fresh GunZ - Log in");
}


?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Login panel</a></div>
    <div id="contentbox500" align="center">
    
    
    <form method="POST" action="index.php?do=login" name="login">
    
    <table width="500" class="in">
      <tr>
        <td colspan="2"><input type="text" class="text" name="userid" placeholder="UserID"></td>
      </tr>
      <tr>
        <td colspan="2"><input type="password" class="text" name="pass" placeholder="clave"></td>
      </tr>
      <tr>
        <td colspan="2" height="50"><input class="submit" type="submit" value="Join" name="img1762"></td>
      </tr>
      <tr class="subinfo">
        <td width="50%"><a href="index.php?do=register">Nuevo Usuario?</a></td>
        <td width="50%"><a href="index.php?do=login&act=resetpwd">Contrase�a Perdida?</a></td>
      </tr>
    </table>
	
    <input type="hidden" name="submit" value="1"></form>
    
    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>

                                       
