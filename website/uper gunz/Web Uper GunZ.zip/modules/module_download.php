<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?php
include("secure/include.php");
SetTitle("Fresh GunZ - Descargas");
?>

<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">Descargas</a></div>
    <div id="contentbox500" align="center">
    
    
    <table width="490" height="557" background="gunz/images/info_dw_fd.png">
      <tr>
        <td height="135">&nbsp;</td>
      </tr>
      <tr>
        <td>
        <a href="https://mega.co.nz/#!aAl1RD4B!QSeajngsxJ-TPRaic4nWv1Vdtu02oDCyoh3XYArCzJI">
    		<img src="Gunz/images/descargas_seccion/boton/1.png" width="145" height="32" border="0">
    	</a>
    	</td>
        <td>
        <a href="http://www.multiupload.nl/ABUW7S0BG0">
        	<img src="Gunz/images/descargas_seccion/boton/2.png" width="145" height="32" border="0">
        </a>
    	</td>
        </tr>
        <tr>
        <td>
        <a href="http://dfiles.eu/files/pv4negbu3">
    		<img src="Gunz/images/descargas_seccion/boton/3.png" width="145" height="32" border="0">
    	</a>
    	</td>
        <td>
        <a href="http://uploaded.net/file/0cq4h9g8">
    		<img src="Gunz/images/descargas_seccion/boton/4.png" width="145" height="32" border="0">
    	</a>
    	</td>
      </tr>
      <tr>
      	<td height="100%"></td>
      </tr>
    </table>

    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>