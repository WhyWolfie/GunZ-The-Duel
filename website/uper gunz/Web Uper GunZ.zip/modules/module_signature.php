<?php
include("secure/include.php");
include("secure/config.php");
include "configsing.php";
?><head>
<script type="text/javascript">
    function UpdateSignature()
    {
        var cid = document.signature.charlist.value;
        var firma = document.getElementById("firma");
        firma.innerHTML = '<img src="<?=$url?>/genericsing.php?cid='+ cid + '" />';
        document.signature.forumcode.value = '[URL="<?=$url?>/"][IMG]<?=$url?>/genericsing.php?cid=' + cid + '[/IMG][/URL]';
        document.signature.directlink.value = "<?=$url?>/genericsing.php?cid=" + cid + "";
    }

</script>
</head>
<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=signature");
    SetMessage("Mensaje del sistema", array("Tienes que estar logueado para utilizar esta funcion"));
    header("Location: index.php?do=login");
    die();
}

SetTitle("Fresh GunZ - Signature");

    $qbt01 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");

    if( mssql_num_rows($qbt01) < 1 )
    {
        SetMessage("Mensaje del sistema", array("No tienes personajes"));
        header("Location: index.php");
        die();
    }

?>


<table width="500" align="center">
  <tr valign="top">
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">
    
<form name="signature">   
    <table width="500" border="0">
      <tr class="text blanco">
        <td width="50%">Selecciona el personaje</td>
        <td width="50%">
           	<select size="1" name="charlist" onchange="UpdateSignature()">
			<?
			while( $databt01 = mssql_fetch_row($qbt01) )
			{
			?>
			<option value="<?=$databt01[0]?>"><?=$databt01[1]?></option><br />';
			<?
			}
			?>
			</select>
        </td>
      </tr>
      <tr class="text c222">
      	<td colspan="2"><span id="firma"></span></td>
      </tr>
      <tr class="text blanco" style="background:#09F;">
        <td colspan="2">Para copiar el Link Presiona Ctrl + C</td>
      </tr>
      <tr class="text c222">
        <td colspan="2">Codigo para los Foros:</td>
      </tr>
      <tr>
        <td colspan="2">
			<input type="text" class="text" name="forumcode" onclick="javascript:select();" readonly="readonly" />
		</td>
      </tr>
      <tr class="text c222">
        <td colspan="2">Link Directo:</td>
      </tr>
      <tr>
        <td colspan="2">
        	<input type="text" class="text" name="directlink" onclick="javascript:select();" readonly="readonly"/>
		</td>
      </tr>
      <script type="text/javascript">
			UpdateSignature();
		</script>
    </table>
</form>

    
    
    </div>
    
    <div id="footerbox500" align="center"></div>
    </td>
  </tr>
</table>