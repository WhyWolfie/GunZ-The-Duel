﻿<?php
include("secure/include.php");
$res = mssql_query("SELECT TOP 6 * FROM shopdonator WHERE Opened = 1 ORDER BY Price ASC");

$count = 0;
                                                                                                                           
while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->CSSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}


    $res = mssql_query("SELECT TOP 6 * FROM shopdonator(nolock) ORDER BY Price ASC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $c[$count][ID]          = $a->CSSID;
        $c[$count][ImageURL]    = $a->ImageURL;
        $c[$count][Name]        = $a->Name;
        $c[$count][Slot]        = GetTypeByID($a->Slot);
        $c[$count][Sex]         = GetSexByID($a->Sex);
        $c[$count][Level]       = $a->Level;
        $c[$count][Price]       = $a->Price;

        $count++;
    }
?>
<table width="500" align="center">
  <tr>
    <td>
    
    <div id="headerbox500" align="center"><a class="title">News & Updates</a></div>
    <div id="contentbox500" align="center">
    
    <table width="500" border="0">
  	<tr>
   	<td valign="top">
    
     	<table width="225" border="0" align="center">
         <?
		$res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
		while($n = mssql_fetch_assoc($res)){
		?>
  		<tr>
    	<td>
        <a href="#" class="newsupdates">
		<a class="newsupdates" href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"><img src="images/inconos/anuncios_razer.png" alt="a" width="10" height="10" border="0" /> <?=$n['Title']?>
		</a>
		<?}?>
        </td>
  		</tr>
</table>
    
    </td>

    <td valign="top">
    
    <table width="225" border="0" align="center">
         <?
		$res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
		while($n = mssql_fetch_assoc($res)){
		?>
  		<tr>
    	<td>
        <a href="#" class="newsupdates">
		<a class="newsupdates" href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"><img src="images/inconos/foro_alerta.png" alt="a" width="10" height="10" border="0" /> <?=$n['Title']?>
		</a>
		<?}?>
        </td>
  		</tr>
		</table>
    
    </td>
  	</tr>
	</table>

    
    </div>
    
    <div id="footerbox500" align="center"></div>
    
    
    <br />
    
		<div id="headerbox500" align="center"><a class="title">facebook</a></div>
        <div id="contentbox500" align="center">
        
        <center>
        <iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2FQuanticGamerz&amp;width=450&amp;height=80&amp;colorscheme=light&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;send=true&amp;appId=191366434306152" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
        </center>
        
    	</div>
    
   		<div id="footerbox500" align="center"></div>
    
    
    
    
    <br />
    
    <div id="headerbox500" align="center"><a class="title">Articulos en oferta</a></div>
    <div id="contentbox500" align="center">
    
    <table width="500" border="0">
  	<tr>  
    
    	<td style="border:1px dashed #222;">
        <a href="index.php?do=buydonator&itemid=<?=$items[0][ID]?>&cat=<?=$items[0][CatID]?>" title="<?=$items[0][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[0][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[0][Name]?></div>												
        </td>
    
    	<td style="border:1px dashed #222;">
        <a href="index.php?do=buydonator&itemid=<?=$items[1][ID]?>&cat=<?=$items[1][CatID]?>" title="<?=$items[1][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[1][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[1][Name]?></div>
        </td>
        
    	<td style="border:1px dashed #222;">
        <a href="index.php?do=buydonator&itemid=<?=$items[2][ID]?>&cat=<?=$items[2][CatID]?>" title="<?=$items[2][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[2][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[2][Name]?></div>
        </td>
  	</tr>
  	<tr>
    	<td style="border:1px dashed #222;">
        <a href="index.php?do=buydonator&itemid=<?=$items[3][ID]?>&cat=<?=$items[3][CatID]?>" title="<?=$items[3][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[3][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[3][Name]?></div>
        </td>
        
    	<td style="border:1px dashed #222;"> 
        <a href="index.php?do=buydonator&itemid=<?=$items[4][ID]?>&cat=<?=$items[4][CatID]?>" title="<?=$items[4][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[4][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[4][Name]?></div>
        </td>
        
    	<td style="border:1px dashed #222;"> 
        <a href="index.php?do=buydonator&itemid=<?=$items[5][ID]?>&cat=<?=$items[5][CatID]?>" title="<?=$items[5][Price]?> Coins"> <img class="shop" border="0" src="images/shop/<?=$items[5][ImageURL]?>" width="64" height="64">
		</a>
        <div class="nameitem"><?=$items[5][Name]?></div>
        </td>
  	</tr>
</table>

  
    </div>
    <div id="footerbox500" align="center"></div>
    
    </td>
  </tr>
</table> 