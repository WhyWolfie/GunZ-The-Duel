<?
mssql_connect("TU-PC\SQLEXPRESS","sa","asdsa");
mssql_select_db("GunzDB");
?>
