<style type="text/css">
<!--
.Estilo2 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
<p align="center"><img src="/images/inconos/Lock.png" alt="Bloqueado" width="82" height="80" /><span class="Estilo2">USTED NO ESTA AUTORIZADO A INGRESAR A ESTA SECCION. </span><br>
  <br>
El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP.<br>
</p>
<hr>
<p> 
  <em>Error 401 - vuelva a www.razergunz.com, Staff general de RazerGamers. </em></p>
