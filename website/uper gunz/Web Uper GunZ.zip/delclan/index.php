<?php
if( !session_start() )
{
    session_start();
}
require "../secure/config.php";
include "functions.php";
include "../secure/anti_inject.php";
include "../secure/sql_check.php";

$connection = connect();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>GunZ Nionsoft - Borrar Clan</title>
<style type="text/css">
<!--
body,td,th {
	color: #CCCCCC; font-family:Arial
}
a {
	color: #FFFFFF; font-family:Arial
}
body {
	background-color: #151515;
}
input {
    border: 1px solid #A0A0A4;
    color: #000000;
    background: #CCCCCC;
    font-family:Arial;
    font-size: 10pt;
}
-->
</style>
</head>

<body>

<?php

if( $_SESSION['AID'] == "" )
{
    if( isset($_POST['login']) )
    {
        login();
    }
    else
    {

?>
    <center>
    <p>&nbsp;</p>
    <form name="login" method="POST" action="index.php">
    <?php showmessage(); ?>
    </form>
    </center>
<?php
    }
}

if( $_SESSION['AID'] != "" )
{
    if( $_GET['do'] == "logout" )
    {
        logout();
    }

    if(isset($_POST['delete']))
    {
        $clid = clean_sql($_POST['clanid']);
        delete_clan($clid);
    }

    $list = getclanlist();
    $count = count($list);
    if($count == 0)
    {
        if( $_GET['do'] != "deleted" )
        {
            setmessage("Buscar Clan", "El Personaje no es el Lider");
        }
        logout();
        redirect("index.php");
        die();
    }
?>
    <center>
    <?php showmessage(); ?>
    <p>Seleccionar el Clan a Borrar : </p>
    <form method="post" name="delete" action="index.php">
        <select name="clanid">
        <?php
        for($i=0; $i < $count; $i++)
        {
            printf("<option value=\"%s\">Clan: %s - Lider: %s</option><br />", $list[$i][1], $list[$i][2], $list[$i][0]);
        }
        ?>
        </select>
        <p><b>Cuidado : El Clan Borrado no se puede Recuperar.</b></p>
        <input type="submit" name="delete" value="Borrar Clan" />
    </form>
    </center>
        </td>
    </tr>
    </table>
<?php
}
?>

</body>

</html>