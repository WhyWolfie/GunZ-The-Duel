<?php

  ////////////////////
 // MAIN Functions //
////////////////////

function connect()
{
    global $_MSSQL;

    $resource = odbc_connect("Driver={SQL Server};Server={$_MSSQL[Host]}; Database={$_MSSQL[DBNa]}", $_MSSQL[User], $_MSSQL[Pass]) or die(odbc_errormsg());
    return $resource;

}

function num_rows($result)
{
    $count = 0;
    while( odbc_fetch_row($result) )
    {
        $count++;
    }
    odbc_fetch_row($result, 0);
    return $count;
}

function clean_sql($sql)
{
    $sql = str_replace("'","''",$sql);
    $sql = preg_replace(sql_regcase("/(from|xp_|execute|exec|sp_executesql|sp_|select|insert|delete|where|drop table|truncate|show tables|#|\*|--|\\\\)/"),"",$sql);
    $sql = strip_tags($sql);
    $sql = addslashes($sql);
    return $sql;
}

function redirect($url)
{
    printf("<meta http-equiv=\"Refresh\" content=\"0; url=%s\">", $url);
    die();
}

function writetolog($log)
{
    $date = date("d-m-y - H:i:s");
    $logfile = fopen("logs/log.txt","a+");
    $logtext = "$date - {$_SERVER['REMOTE_ADDR']} : $log\r\n";
    fputs($logfile, $logtext);
	fclose($logfile);
}

function setmessage($title, $message)
{
    $_SESSION[Message] =
    "<br /><table border=\"1\" width=\"40%\" id=\"message\" style=\"border-collapse: collapse\">
	<tr>
		<td><b><i>GunZ Fresh</i></b></td>
	</tr>
	<tr>
		<td>Su Clan Fue Borrado Satisfactoreamente.</td>
	</tr>
</table><br />";

}

function showmessage()
{
    if( $_SESSION[Message] != "" )
    {
        printf("%s", $_SESSION[Message]);
        unset($_SESSION[Message]);
    }
}

   ////////////////////
  // End OF         //
 // MAIN Functions //
////////////////////

  /////////////////////
 // LOGIN Functions //
/////////////////////

function login()
{
    global $_CONFIG, $connection;
    $userid = clean_sql($_POST['userid']);
    $password = clean_sql($_POST['password']);

    if( $userid == "" || $password == "" )
    {
        setmessage("Entrar", "Entrar Primero");
        redirect("index.php");
        die();
    }

    $loginquery = odbc_exec($connection, "
                    SELECT AID FROM {$_CONFIG[LoginTable]}(nolock)
                    WHERE UserID = '$userid' AND Password = '$password'
                    ");
    if( num_rows($loginquery) == 1 )
    {
        $logindata = odbc_fetch_row($loginquery);
        $_SESSION[AID] = odbc_result($loginquery, 1);
        writetolog("The user with AID {$_SESSION[AID]} has logged in");
        redirect("index.php");
    }
    else
    {
        setmessage("Login", "Invalid UserID / Password");
        redirect("index.php");
        die();
    }
}

function logout()
{
    unset($_SESSION[AID], $_SESSION[UserID]);
    redirect("index.php");
}

   /////////////////////
  // End OF          //
 // LOGIN Functions //
/////////////////////

  /////////////////////
 // CLAN Functions  //
/////////////////////

function getclanlist()
{
    global $_CONFIG, $connection;

    $info = array();
    $i = 0;

    $charsq = odbc_exec($connection, "
                SELECT ch.Name, cl.CLID, cl.Name FROM {$_CONFIG[CharTable]} ch INNER JOIN {$_CONFIG[ClanTable]} cl
                ON ch.CID = cl.MasterCID WHERE ch.AID = {$_SESSION[AID]} AND ch.DeleteFlag = 0");
    while( odbc_fetch_row($charsq) )
    {
        $info[$i] = array(odbc_result($charsq, 1), odbc_result($charsq, 2), odbc_result($charsq, 3));
        $i++;
    }

    return $info;
}

function delete_clan($clid)
{
    global $_CONFIG, $connection;

    $verif = odbc_exec($connection, "
                SELECT cl.Name FROM {$_CONFIG[CharTable]} ch INNER JOIN {$_CONFIG[ClanTable]} cl
                ON ch.CID = cl.MasterCID WHERE cl.CLID = '$clid' AND ch.AID = {$_SESSION[AID]}");

    if( num_rows($verif) == 1 )
    {
        odbc_exec($connection, "DELETE FROM {$_CONFIG[ClanTable]} WHERE CLID = '$clid'");
        odbc_exec($connection, "DELETE FROM {$_CONFIG[ClanmemberTable]} WHERE CLID = '$clid'");


        writetolog("The user with AID: {$_SESSION[AID]} has deleted the clan with CLID: $clid");
        setmessage("Clan Deletion", "The clan $name has been successfully deleted");
        redirect("index.php?do=deleted");
        die();
    }
    else
    {
        writetolog("The user with AID: {$_SESSION[AID]} has unsuccessfully tried to delete the clan with CLID $clid");
        setmessage("Clan Deletion", "The clan that you selected doesn't exist or you are not the master of it");
        redirect("index.php");
        die();
    }
}
?>