<table width="240" border="0">
   <tr class="ranking">
    <td width="20%">Emblem</td><td width="60%">Clan Name</td><td width="25%">Points</td>
   </tr>
<?
$res = mssql_query_logged("SELECT TOP 5 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");

$Count = 0;

while($resa = mssql_fetch_object($res))
{
$FirstClan[$Count][Name]        = $resa->Name;
$FirstClan[$Count][Point]       = $resa->Point;
$FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "hqKqemp.png" : $resa->EmblemUrl;

if($Count == 4)
	break;
else
	$Count++;
}

$firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[0][EmblemURL];
$firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[1][EmblemURL];
$firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[2][EmblemURL];
$firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[3][EmblemURL];
$firstclanemb4 = ($FirstClan[4][EmblemURL] == "") ? "hqKqemp.png" : $FirstClan[4][EmblemURL];

$firstclanname0 = ($FirstClan[0][Name] == "") ? "No hay datos" : $FirstClan[0][Name];
$firstclanname1 = ($FirstClan[1][Name] == "") ? "No hay datos" : $FirstClan[1][Name];
$firstclanname2 = ($FirstClan[2][Name] == "") ? "No hay datos" : $FirstClan[2][Name];
$firstclanname3 = ($FirstClan[3][Name] == "") ? "No hay datos" : $FirstClan[3][Name];
$firstclanname4 = ($FirstClan[4][Name] == "") ? "No hay datos" : $FirstClan[4][Name];

$firstclanPoint0 = ($FirstClan[0][Point] == "") ? "No hay datos" : $FirstClan[0][Point];
$firstclanPoint1 = ($FirstClan[1][Point] == "") ? "No hay datos" : $FirstClan[1][Point];
$firstclanPoint2 = ($FirstClan[2][Point] == "") ? "No hay datos" : $FirstClan[2][Point];
$firstclanPoint3 = ($FirstClan[3][Point] == "") ? "No hay datos" : $FirstClan[3][Point];
$firstclanPoint4 = ($FirstClan[4][Point] == "") ? "No hay datos" : $FirstClan[4][Point];



$toprank = '
	<tr class="rankingdisplay">
  		<td><img src="http://i.imgur.com/'.$firstclanemb0.'" width="20" height="20"></td>
		<td>'.$firstclanname0.'</td>
		<td>'.$firstclanPoint0.'</td>
  	</tr>
	
	<tr class="rankingdisplay">
  		<td><img src="http://i.imgur.com/'.$firstclanemb1.'" width="20" height="20"></td>
		<td>'.$firstclanname1.'</td>
		<td>'.$firstclanPoint1.'</td>
  	</tr>
	
	<tr class="rankingdisplay">
  		<td><img src="http://i.imgur.com/'.$firstclanemb2.'" width="20" height="20"></td>
		<td>'.$firstclanname2.'</td>
		<td>'.$firstclanPoint2.'</td>
  	</tr>
	
	<tr class="rankingdisplay">
  		<td><img src="http://i.imgur.com/'.$firstclanemb3.'" width="20" height="20"></td>
		<td>'.$firstclanname3.'</td>
		<td>'.$firstclanPoint3.'</td>
  	</tr>
	
	<tr class="rankingdisplay">
  		<td><img src="http://i.imgur.com/'.$firstclanemb4.'" width="20" height="20"></td>
		<td>'.$firstclanname4.'</td>
		<td>'.$firstclanPoint4.'</td>
  	</tr>

	
</tr>';
echo $toprank;
?>
</table>



<!--

<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<table width="240" border="0">
   <tr class="ranking">
    <td width="20%">Emblem</td><td width="60%">Clan Name</td><td width="25%">Points</td>
   </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
    <tr class="rankingdisplay">
        <td colspan="2">
        	No hay datos &laquo;
        </td>
    </tr>
     <?
		}else{
		while($user = mssql_fetch_assoc($res)){
	?>

<tr class="rankingdisplay">
  <td><img src="http://i.imgur.com/<?=$user['EmblemUrl']?>" width="20" height="20"></td><td><?=$user['Name']?></td><td><?=$user['Point']?></td>
  </tr>
      <?}}?>
</table>


-->


<!--<iframe width="180" height="170" src="http://www.youtube.com/embed/3OJ1XnwRt4E" frameborder="0" allowfullscreen></iframe>
<table>
<tr>
									<td width="500" bgcolor="#000000">&nbsp;</td>
</tr>
<td><a href="index.php?do=shop"><img src="images/shop_banner.jpg" width="185" height="70" /></a></td>
</tr>
<td><a href="index.php?do=signature"><img src="images/sign_banner.jpg" width="185" height="70" /></a></td>
</tr>
<td><a href="index.php?do=ultimascw"><img src="images/cw_banner.PNG" width="185" height="70" /></a></td>
</tr>
<td><a href="index.php?do=emblems"><img src="images/subiremblema.PNG" width="185" height="70" /></a></td>
</table>-->
