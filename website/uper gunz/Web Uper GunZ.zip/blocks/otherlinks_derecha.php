<table>
	<tr>
        <td>
       	 <a href="index.php?do=donate"><img src="img/extralinks/ldsms.png" /></a>
    	</td>
     </tr>
    <tr>
        <td>
            <a href="index.php?do=recover"><img src="img/extralinks/lrp.png" /></a>
        </td>
    </tr>
</table>
    
    