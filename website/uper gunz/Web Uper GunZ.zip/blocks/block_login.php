<?
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "banneduser.php";

if($_SESSION[AID] == "")
{
?>

<script type="text/javascript">
						
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

</script>

<form name="login" method="POST" action="index.php?do=login">
<table width="240" border="0" align="center">
<tr>
<td width="83">
<input name="userid" class="text" placeholder="username"></td>
</tr>
<tr>
<td width="83">
<input name="pass" class="text" placeholder="password" type="password"></td>
</tr>
<tr>
<td width="152" height="30" colspan="2">
<input name="img812" type="submit" class="submit" value="Join"></td></td>
</tr>
<tr align="center">
<td><a href="index.php?do=resetpwd" class="recover">Recover password</a></td>
</tr>
<!--<td width="179"><div align="center"><a href="Index.php?do=donate" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Donaciones01','','/Gunz/images/blocks_imagenes/Donaciones01.png',1)"><img src="/Gunz/images/blocks_imagenes/Donaciones.png" name="Donaciones01" width="175" height="203" border="0"></a><a href="index.php?do=donate"></a></div></td>
</tr>
<tr>
<td width="179" height="21" ><p><a href="Index.php?do=Staff" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Staff de EnergyGamers','','/Gunz/images/blocks_imagenes/PersonalStaff01.png',1)"><img src="/Gunz/images/blocks_imagenes/PersonalStaff.png" name="Staff de EnergyGamers" width="175" height="221" border="0"></a><a href="index.php?do=staff"></a></p>
<p align="center">&nbsp;</p></td>-->
				
</table>
							<input type="hidden" name="submit" value="1">
							</form>
<?
}else{

    $query1 = mssql_query_logged("SELECT * FROM AccountItem(nolock) WHERE AID = '{$_SESSION[AID]}'");
    $query2 = mssql_query_logged("SELECT Coins, EventCoins, DonatorCoins FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
    $_MEMBER[NumItems]      = mssql_num_rows($query1);
    $_MEMBER[AccountData]   = mssql_fetch_assoc($query2);
?>


<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("imageclan");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "http://i.imgur.com/ + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>


<script type="text/javascript">

    YAHOO.namespace("example.container");


    function HidePanel()
    {
        YAHOO.example.container.ChangeEmblem.hide();
        document.getElementById("content").innerHTML = "";
    }

    function ShowPanel(clanid) {

        if (!YAHOO.example.container.wait) {

            // Initialize the temporary Panel to display while waiting for external content to load

            YAHOO.example.container.wait =
                    new YAHOO.widget.Panel("wait",
                                                    { width: "240px",
                                                      fixedcenter: true,
                                                      close: false,
                                                      draggable: false,
                                                      zindex:4,
                                                      modal: true,
                                                      visible: false
                                                    }
                                                );

            YAHOO.example.container.wait.setHeader("Loading, please wait...");
            YAHOO.example.container.wait.setBody("<img src=\"http://us.i1.yimg.com/us.yimg.com/i/us/per/gr/gp/rel_interstitial_loading.gif\"/>");
            YAHOO.example.container.wait.render(document.body);

        }


        if (!YAHOO.example.container.ChangeEmblem) {

            // Initialize the temporary Panel to display while waiting for external content to load

            YAHOO.example.container.ChangeEmblem =
                    new YAHOO.widget.Panel("wait",
                                                    { width: "430px",
                                                      fixedcenter: true,
                                                      close: false,
                                                      draggable: false,
                                                      zindex:4,
                                                      modal: true,
                                                      visible: false
                                                    }
                                                );

            YAHOO.example.container.ChangeEmblem.setHeader("Change Emblem");
            YAHOO.example.container.ChangeEmblem.setBody("<div id=\""></div>");
            YAHOO.example.container.ChangeEmblem.render(document.body);

        }

       // Define the callback object for Connection Manager that will set the body of our content area when the content has loaded


        var content = document.getElementById("content");

        content.innerHTML = "";

        var callback = {
            success : function(o) {
                content.innerHTML = o.responseText;
                content.style.visibility = "visible";
                YAHOO.example.container.wait.hide();
                YAHOO.example.container.ChangeEmblem.show();
            },
            failure : function(o) {
                content.innerHTML = o.responseText;
                content.style.visibility = "visible";
                YAHOO.example.container.wait.hide();
                YAHOO.example.container.ChangeEmblem.show();
            }
        }

        content.innerHTML = "<center><b><font face=\"Tahoma\" size=\"2\" color=\"#FFFFFF\">Loading content</font></b></center></br><center><img src=\"http://us.i1.yimg.com/us.yimg.com/i/us/per/gr/gp/rel_interstitial_loading.gif\"/></center>";

        YAHOO.example.container.ChangeEmblem.show();

        // Connect to our data source and load the data
        var conn = YAHOO.util.Connect.asyncRequest("GET", "emblemupload.php?clid=" + clanid, callback);
    }

</script>


<table width="240" border="0" class="in">
  <tr>
    <td colspan="2">Welcome, <font color="#0066ff"> <?=$_SESSION[UserID]?></font></td>
  </tr>
  <tr>
    <td valign="top" colspan="2">
	<?
	if(CheckIfExistClan($_SESSION[AID]))
	{
	?>
    <img src="../noemblem.jpg" name="imageclan" width="55" height="55" id="imageclan" style="border: 1px solid #000000">
    </td>
    </tr>
    <tr>
    <td colspan="2">
    <select onChange="UpdateClan()" id="clanlist" size="1" name="selclan" style="color: #FFFFFF; font-family: Verdana; font-size: 7pt; border: 1px solid #000000; background-color: #101010">
	<?
    $qr = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
    if( mssql_num_rows($qr) > 0 )
    {
    while($char = mssql_fetch_assoc($qr))
    {
    $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
    if( mssql_num_rows($queryc) > 0 )
    {
    $a = mssql_fetch_assoc($queryc);
    $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));
    
    $_CLAN[Name]       = $b[Name];
    $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
    $_CLAN[CLID]       = $a[CLID];
    $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "noemblem.jpg" : $b[EmblemUrl];
    
    $info = implode("-|-", $_CLAN);
    
    if($_CLAN[Name] <> "")
    echo "<option value = '$info'>{$_CLAN[Name]}</option>";
    }
    }
    }
    ?>
    </select>
    <br>
    <a href="/Gunz/index.php?do=emblem"><img src="images/btn_editclan_off.jpg" width="95" height="17"/></a>
    
	</td>
  </tr>
  <?
}else{
?>
  <tr>
    <td height="30">
    
    No tienes clan
    
    </td>
    </tr>
	<?
	}
	?>
</td>
  </tr>
  <td height="30">
    
    <a href="index.php?do=clancreate" class="recover">Crear mi Clan</a>
    
    </td>
  <tr>
  	<td colspan="2"><a href="index.php?do=UserCP"><img src="images/user.png" width="140" height="25" /></a></td>
  </tr>
   <tr>
  	<td colspan="2">DonatorCoins:<font color="#0066ff">
<?=$_MEMBER[AccountData][DonatorCoins]?></font></td>
  <tr>
   <tr>
  	<td colspan="2">Event Coins:<font color="#0066ff">
<?=$_MEMBER[AccountData][EventCoins]?></font></td>
  <tr>
   <tr>
  	<td colspan="2">Coins:<font color="#0066ff">
<?=$_MEMBER[AccountData][Coins]?></font></td>
  <tr>
  <tr>
  	<td colspan="2">TU AID: <font color="#0066ff"><?=$_SESSION[AID]?></font></td>
  <tr>
  <tr>
  	<td colspan="2"><?
	echo '
	<tr>
	<td width="73" colspan="2">
	Items:
	<b><font color="#0066ff">
	'.$_MEMBER[NumItems].'</font></b></td>
	</tr>'; 
	?>
    </td>
  <tr>
  <tr>
  	<td colspan="2"><a href="index.php?do=changebt" class="comprarcoins">Comprar Coins</a>
</td>
  <tr>
  <tr>
  	<td colspan="2">
    <a href="index.php?do=editaccount" class="editlogout">Edit Account</a>
    <a href="index.php?do=logout" class="editlogout">Logout</a>
</td>
  <tr>
<!--  <tr>
  	<td colspan="2"><a href="Index.php?do=donate" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Donaciones01','','/Gunz/images/blocks_imagenes/Donaciones01.png',1)"><img src="/Gunz/images/blocks_imagenes/Donaciones.png" name="Donaciones01" width="175" height="203" border="0"></a><a href="index.php?do=donate"></a>
</td>
  <tr>
  <tr>
  	<td colspan="2"><a href="/index.php?do=Staff" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Staff de FreshGamers','','/Gunz/images/blocks_imagenes/PersonalStaff01.png',1)"><img src="/Gunz/images/blocks_imagenes/PersonalStaff.png" name="Staff de FreshGamers" width="175" height="221" border="0"></a><a href="/index.php?do=Staff"></a>
</td>
  <tr>-->
</table>

<script language="javascript">
UpdateClan();
</script>


<?
}
?>