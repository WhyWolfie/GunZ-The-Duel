<table>
	<tr>
        <td>
            <a href="index.php?do=signature"><img src="img/extralinks/pu.png" /></a>
        </td>
    </tr>
    <tr>
    	<td>
        <a href="index.php?do=shopdonator"><img src="img/extralinks/imteshop2.png" /></a>
        </td>
    </tr>

</table>
