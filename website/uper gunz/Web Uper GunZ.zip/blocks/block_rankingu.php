<table width="240" border="0">
   <tr class="ranking">
    <td width="20%">DT</td><td width="60%">Character</td><td width="25%">Level</td>
   </tr>
<?
$query = mssql_query("SELECT TOP 5 * FROM Character WHERE DeleteFlag = 0 ORDER BY XP DESC");

while($query2 = mssql_fetch_assoc($query))
{
 
$aid = $query2['AID'];
$cid = $query2['CID'];
 
$dtquery = mssql_query("SELECT PreGrade FROM DtCharacterInfo WHERE CID = '$cid'");
$dtquery2 = mssql_fetch_row($dtquery);
 
switch($dtquery2[0])
{
        case 10:
        $dtquery3 = "Images/class/22.jpg";
        break;
        case 9:
        $dtquery3 = "Images/class/33.jpg";
        break;
        case 8:
        $dtquery3 = "Images/class/44.jpg";
        break;
        case 7:
        $dtquery3 = "Images/class/55.jpg";
        break;
        case 6:
        $dtquery3 = "Images/class/66.jpg";
        break;
        case 5:
        $dtquery3 = "Images/class/77.jpg";
        break;
        case 4:
        $dtquery3 = "Images/class/88.jpg";
        break;
        case 3:
        $dtquery3 = "Images/class/99.jpg";
        break;
        case 2:
        $dtquery3 = "Images/class/111.jpg";
        break;
        case 1:
        $dtquery3 = "Images/class/222.jpg";
        break;
}
 
 
?>
  <tr class="rankingdisplay">
  <td><img src="<?=$dtquery3?>" width="20" height="20"></td><td><?=FormatCharName($query2['CID'])?></td><td><?=$query2['Level']?></td>
  </tr>
<?}?>      
</table>
