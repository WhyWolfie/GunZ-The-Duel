<?php
include("func.php");

if(!empty($_FILES['image']['tmp_name']))
{
    $imagen = subirimg($_FILES['image']['tmp_name']);
    if(!empty($imagen))
    {
        echo "URL: ".$imagen;
    }else{
        echo "Error al Subir la Imagen :/";
    }
}
?>
<style type="text/css">
.Rojo {
	font-size:10px;
	color: #F00;
}
</style>

<div style="color:#666; font-size:10px;">

<form method="post" enctype="multipart/form-data">
    <input type="file" name="image">
    <p>
    <input type="submit" class="submit" value="Subir Imagen">
    </p>
</form>

<table width="500" border="0">
  <tr height="30">
    <td><span class="Rojo">SOLO IMAGENES 100x100 Formato PNG</span></td>
  </tr>
  <tr height="30">
    <td>Recuerde que solo nesesitas lo que esta despues del /..</td>
  </tr>
  <tr height="30">
    <td>http://i.imgur.com/<span class="Rojo">ooZiVRF.jpg</span> Solo Lo que esta en rojo es lo que colocaras abajo!</td>
  </tr>
  <tr height="30">
    <td>Ya tiene Su Link? Dirijase al Paso 2</td>
  </tr>
  <tr height="30" class="subinfo">
    <td><a href="index.php?do=emblems2">Paso Siguiente</a></td>
  </tr>
</table>


</div>