<table width="600" border="0" class="text cfff" id="server">
  <tr>
    <td>Usuarios Online
    
    <?php
		//Total Players
		$query = mssql_query("SELECT * FROM ServerStatus"); 
		$row = mssql_fetch_row($query); 
		$players = $row[1]; 
		echo "$players / 1000"; 
	?>
    
    </td>
    <td>
    
    <?php 
		//Total Accounts
		$query = mssql_query("SELECT * FROM Account"); 
		$num_rows = mssql_num_rows($query); 
		echo "Cuentas creadas: ".$num_rows."<n>
		<p>"; 
	?>
    
    </td>
    <td>
    
    <?php
		//Total Characters
		$query = mssql_query("SELECT * FROM Character"); 
		$num_rows = mssql_num_rows($query); 
		echo "Personajes creados: ".$num_rows."<n><p>";
	?>
    
    </td>
  </tr>
</table>


