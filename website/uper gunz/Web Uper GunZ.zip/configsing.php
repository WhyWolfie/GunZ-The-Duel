<?php
// Config Siganture
$url	=	"http://quantic-gz.sytes.net";
$img 	=	"images/sing.png";

?>