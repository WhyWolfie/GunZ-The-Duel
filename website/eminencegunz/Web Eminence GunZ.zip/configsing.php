<?php
// Config Siganture
$url	=	"http://eminencegunz.net";
$img 	=	"images/sing.png";

?>