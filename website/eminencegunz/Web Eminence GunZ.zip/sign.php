<?php
include "secure/functions.php";
include "secure/config.php";

    $cid = clean($_GET['cid']);
    $res = mssql_query_logged("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
    $res2 = mssql_query_logged("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'");
    $clan = mssql_fetch_assoc($res2);
    $res3 = mssql_query_logged("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'");
    $claninfo = mssql_fetch_assoc($res3);
    
    $img = "images/sign.png";

    if($cid == "")
       $cid = 1;

    if($claninfo == "")
       $claninfo = "-";

header("Content-type: images/sing.png");
$i = imagecreatefrompng($img);

$name = $char['Name'];
$level = $char['Level'];
$clan = $claninfo['Name'];
$ranking = $char['Ranking'];
$preto = imagecolorallocate($i, 0,0,0);
$azul = imagecolorallocate($i, 255,255,255);
$fonte = "starcraft.ttf";
imagettftext($i, 11, 0, 80, 95,$azul,$fonte,$name);
imagettftext($i, 11, 0, 270, 95,$azul,$fonte,$level);
imagettftext($i, 11, 0, 80, 128,$azul,$fonte,$clan);
imagettftext($i, 11, 0, 270, 128,$azul,$fonte,$ranking);
imagepng($i);
imagedestroy($i);
?>
