<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>EminenceGunZ - Servidor en pleno mantenimiento general !</title>
<style type="text/css">
<!--
.Estilo1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	color: #666666;
	font-size: 10px;
}
-->
</style>
</head>

<body>
<div align="center"><span class="Estilo1">Servidor en pleno mantenimiento general !</span>
</div>
</body>
</html>
