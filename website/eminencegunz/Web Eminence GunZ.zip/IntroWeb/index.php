<!DOCTYPE html>
<html class="csstransforms csstransforms3d csstransitions">
 <head>
    <script async src=
	http://api.twitter.com/1/statuses/user_timeline.json?screen_name=ansimuz&amp;count=3&amp;include_rts=1&amp;callback=jQuery  
	17105902378750033677_1379804137259&amp;_=1379804138167">
	</script>
		<meta charset="utf-8">
		<title>Eminence Gaming</title>
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
		<link rel="stylesheet" href="css/social-icons.css" type="text/css" media="screen">
		<script type="text/javascript" src="js/jquery-1.5.1.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui-1.8.13.custom.min.js"></script>
		<script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript" src="js/jquery.scrollTo-1.4.2-min.js"></script>
		<script type="text/javascript" src="js/jquery.cycle.all.js"></script>
		<script type="text/javascript" src="js/custom.js"></script>
		<script src="js/jquery.isotope.min.js"></script>
		<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen">
		<script src="js/nivo-slider/jquery.nivo.slider.js" type="text/javascript"></script>
		<link rel="stylesheet" href="css/tabs.css" type="text/css" media="screen">
		<script type="text/javascript" src="js/tabs.js"></script>
		<script type="text/javascript" src="js/prettyPhoto/js/jquery.prettyPhoto.js"></script>
		<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
		<link rel="stylesheet" media="screen" href="css/superfish.css"> 
		<link rel="stylesheet" media="screen" href="css/superfish-left.css"> 
		<script type="text/javascript" src="js/superfish-1.4.8/js/hoverIntent.js"></script>
		<script type="text/javascript" src="js/superfish-1.4.8/js/superfish.js"></script>
		<script type="text/javascript" src="js/superfish-1.4.8/js/supersubs.js"></script>
		<link rel="stylesheet" href="js/poshytip-1.0/src/tip-twitter/tip-twitter.css" type="text/css">
		<link rel="stylesheet" href="js/poshytip-1.0/src/tip-yellowsimple/tip-yellowsimple.css" type="text/css">
		<script type="text/javascript" src="js/poshytip-1.0/src/jquery.poshytip.min.js"></script>
		<link rel="stylesheet" href="css/jquery.tweet.css" media="all" type="text/css"> 
		<script src="js/tweet/jquery.tweet.js" type="text/javascript"></script> 
		<link rel="stylesheet" href="js/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen">
		<script type="text/javascript" src="js/jquery.fancybox-1.3.4/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
	    <style type="text/css">
        .Estilo2 {color: #0066CC}
        </style>
        <style id="poshytip-css-tip-twitter" type="text/css">div.tip-twitter{visibility:hidden;position:absolute;top:0;left:0;
		}div.tip-twitter table, div.tip-twitter td{margin:0;font-family:inherit;font-size:inherit;font-weight:inherit;font-style:inherit;
		font-variant:inherit;}div.tip-twitter td.tip-bg-image span{display:block;font:1px/1px sans-serif;height:10px;width:10px;overflow:
		hidden;}div.tip-twitter td.tip-right{background-position:100% 0;}div.tip-twitter td.tip-bottom{background-position:100% 100%;
		}div.tip-twitter td.tip-left{background-position:0 100%;}div.tip-twitter div.tip-inner{background-position:-10px -10px;
		}div.tip-twitter div.tip-arrow{visibility:hidden;position:absolute;overflow:hidden;font:1px/1px sans-serif;}</style>
		<style id="poshytip-css-tip-yellowsimple" type="text/css">div.tip-yellowsimple{visibility:hidden;position:absolute;top:0;left:0;
		}div.tip-yellowsimple table, div.tip-yellowsimple td{margin:0;font-family:inherit;font-size:inherit;font-weight:inherit;font-style
		:inherit;font-variant:inherit;}div.tip-yellowsimple td.tip-bg-image span{display:block;font:1px/1px sans-serif;height:10px;width:
		10px;overflow:hidden;}div.tip-yellowsimple td.tip-right{background-position:100% 0;}div.tip-yellowsimple td.tip-bottom{
		background-position:100% 100%;}div.tip-yellowsimple td.tip-left{background-position:0 100%;}div.tip-yellowsimple div.tip-inner
		{background-position:-10px -10px;}div.tip-yellowsimple div.tip-arrow{visibility:hidden;position:absolute;overflow:hidden;font:
		1px/1px sans-serif;}
        </style>
      </head>
    	<body class="home">
			<div id="header">
				<div class="wrapper">
					<a href="index.php">
					   <img src="img/logo.png" alt="EminenceGaming" name="logo" id="logo">
                    </a>
                </div>
			</div>
			<div id="menu">
				<div id="menu-holder">
					<div class="wrapper">
						<ul id="nav" class="sf-menu sf-js-enabled sf-shadow">
							<li class="current-menu-item"><a href="index.php">Inicio<span class="subheader">Portal</span></a></li>
							<li class=""><a href="#">Juegos<span class="subheader">Servidores</span></a>
								<ul style="display: none; visibility: hidden;">
								 <li><a href="http://eminecnegunz.net/" target="_blank"><span>Gunz The Duel</span></a></li>
								 <li><a href="http://eg-eminencegaming.com.ar/Foro/" target="_blank"><span> Mu Season 6 Epi 3</span></a></li>
								  <li><a href="http://eg-eminencegaming.com.ar/" target="_blank"><span> Counter Strike Zombie Myztical</span></a></li>
								   <li><a href="http://eg-eminencegaming.com.ar/" target="_blank"><span> Counter Strike Servidor Publico</span></a></li>
								</ul>
							</li>
							<li><a href="Noticias.php">Noticias<span class="subheader">Importantes</span></a></li>
							<li><a href="staff-1.php">Staff <span class="subheader">Personal</span></a></li>
							<li><a href="#">Wallpapers<span class="subheader">Descarga</span></a>
								<ul style="display: none; visibility: hidden;">
									<li><a href="#"><span> 800x600</span></a></li>
									<li><a href="#"><span> 1240x800 </span></a></li>
									<li><a href="#"><span> 1440x900 </span></a></li>
								</ul>
							</li>
							<li><a href="http://eg-eminencegaming.com.ar/foro/" target="_blank">Soporte Técnico<span class="subheader">Foro Oficial </span></a></li>
						</ul>

					</div>

				</div>

			</div>

			
			
			


			<div id="slider-block">
				<div id="slider-holder">
					<div id="slider" class="nivoSlider" style="position: relative; background-image: url(images/01.jpg); background-position: initial initial; background-repeat: no-repeat no-repeat;">
						<a href="http://eg-eminencegaming.com.ar/foro/" style="display: none;"><img src="images/02.jpg" title="El día esperado llego, La Actualización de EminenceGunZ esta completamente lista. Que esperas para entrar" alt="" style="display: none;"></a>
						<a href="http://eg-eminencegaming.com.ar/foro/" class="nivo-imageLink" style="display: none;"><img src="images/03.jpg" title="EminenceGunZ la Mejor Experiencia en GunZ Online Que Esperas para Descargar Nuestros Servidores Online" alt="" style="display: none;"></a>
						<a href="https://www.facebook.com/EminenceGunZ" class="nivo-imageLink" style="display: none;"><img src="images/04.jpg" title="EminenceGaming Tiene mas de 2.500 Fans , Ayúdanos a llegar a los 3.000" alt="" style="display: none;"></a>
						<a href="Event.php" class="nivo-imageLink" style="display: block;"><img src="images/05.jpg" title="EminenceGaming te Trae CounterStriker Zombie Myztical y Counter Strike Servidor Publico que esperas para Descargarlo.!" alt="" style="display: none;"></a>
					<div class="nivo-slice" style="width: 60px; height: 0px; opacity: 0; background-image: url(images/01.jpg); bottom: 0px; top: 0px; left: 0px; background-position: 0px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 60px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -60px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 120px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -120px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 180px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -180px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 240px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -240px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 300px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -300px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 360px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -360px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 420px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -420px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 480px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -480px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 540px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -540px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 600px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -600px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 660px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -660px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 720px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -720px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 780px; width: 60px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -780px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-slice" style="left: 840px; width: 66px; height: 0px; opacity: 0; background-image: url(http://chosik-gamers.net/images/01.jpg); bottom: 0px; top: 0px; background-position: -840px 0%; background-repeat: no-repeat no-repeat;"></div><div class="nivo-caption" style="opacity: 0.7;"><p style="display: block; opacity: 1;">Disfruta de nuestro mes de Maratón de Eventos en ChosikGunz</p></div><div class="nivo-directionNav" style="display: none;"><a class="nivo-prevNav">Prev</a><a class="nivo-nextNav">Next</a></div><div class="nivo-controlNav"><a class="nivo-control active" rel="0">1</a><a class="nivo-control" rel="1">2</a><a class="nivo-control" rel="2">3</a><a class="nivo-control" rel="3">4</a></div></div>
				</div>
			</div>

			<div id="main">

				<div class="wrapper">

					<div class="clear"></div>
					<div id="headline">
						<span class="main">Bienvenidos Ah EminenceGaming</span>
						<span class="sub">EminenceGaming - Comunidad en Desarrollo en Juegos Online!</span>
						<a href="https://www.facebook.com/EminenceGaming" id="link" class="link-button-big"><span><span class="Estilo2">Like !</span></span></a>					</div>

					<div id="content">
						
							<ul class="tabs">
								<li><a href="#" class="current"><span>Juegos Online!</span></a></li>
							</ul>

							<div class="panes">

								<div style="display: block;">
									<ul class="blocks-thumbs thumbs-rollover">
										<li>
											<a href="http://eminencegunz.net/" class="thumb" title="click sobre la imagen para ingresar al sitio web"><img src="img/index/Gunz.png" alt="Post" style="opacity: 1;"></a>
											<div class="excerpt">
												<a href="single.html" class="header">Eminence GunZ The Duel</a>
												Es un juego de accion que te permite revivir lo que estas haciendo en el juego, trae consigo mucha adrenalina , divertidos modos de juego y mas.
											</div>
											<a href="http://eminencegunz.net/" class="link-button"><span>Sitio Web →</span></a>
										</li>
										<li>
											<a href="#" class="thumb" title="click sobre la imagen para ingresar al sitio web"><img src="img/index/CounterStrike.jpg" alt="Post" style="opacity: 1;"></a>
											<div class="excerpt">
												<a href="#" class="header">Counter Strike Zombie Myztical y Counter Strike Servidor Publico</a>
												es un videojuego de aventura medieval en 3D tipo MMORPG.Contamos con la ultima version accesible para todos los usuarios, nuevos set, mapas, eventos y mas.
											</div>
											<a href="#" class="link-button"><span>Sitio Web →</span></a>
										</li>
									</ul>
								</div>

								<div style="display: none;">
									<div class="plain-text">

									</div>
								</div>

								<div style="display: none;">
									<ul class="blocks-thumbs thumbs-rollover">
										<li>
											<a href="" class="thumb" title="An image"><img src="img/dummies/282x150.gif" alt="Post"></a>
											<div class="excerpt">

									</div></li></ul>
								</div>

								
							</div>

		
		
					</div>
				</div>
			</div>

			<div id="twitter">
				<div class="wrapper">
				  <div id="tweets">
						<ul class="tweet_list"></ul>
				  <ul class="tweet_list"></ul></div>
			  </div>
			</div>

			<div id="footer">
				<div class="wrapper">
					<ul id="footer-cols">
						<li class="col">
							<h6>Actualizaciones</h6>
							<ul>
								<li class="page_item"><a href="Update.php">[ACT] Nueva Version de Eminence GunZ</a></li>
								<li class="page_item"><a href="Update.php" style="margin-left: 0px;">[ACT] Nuevo Launcher en EminenceGunZ</a></li>
								<li class="page_item"><a href="Update.php" style="margin-left: 0px;">[ACT] Nuevos Modos De Juegos</a></li>
								<li class="page_item"><a href="Update.php" style="margin-left: 0px;">[ACT] Nuevos Comandos</a></li>
								<li class="page_item"><a href="Update.php">[ACT] No tenemos ninguna actualización</a></li>
								<li class="page_item"><a href="Update.php">[ACT] No tenemos ninguna actualización</a></li>
							</ul>
						</li>
						
						<li class="col">
							<h6>Anuncios</h6>
							<ul>
								<li class="page_item"><a href="Noticias.php">[ANU] SB/UC Parchados en EminenceGunZ</a></li>
								<li class="page_item"><a href="Noticias.php">[ANU] Próximamente Donaciones vía SMS</a></li>
								<li class="page_item"><a href="Noticias.php">[ANU] Próximamente Donaciones vía Tarjetas Telefonicas(Solo Venezuela)</a></li>
								<li class="page_item"><a href="Noticias.php" style="margin-left: 0px;">[ANU] Mas de 800 Seguidores en Facebook</a></li>
							</ul>
						</li>
						<li class="col">
							<h6>Evento del Mes</h6>
							<ul>
								<li class="page_item"><a href="Event.php">[EVENTO] Enganchados</a></li>
								<li class="page_item"><a href="Event.php">[EVENTO] Atrapados</a></li>
								<li class="page_item"><a href="Event.php">[TORNEO] Torneo Relampago</a></li>
								<li class="page_item"><a href="Event.php">[EVENTO] Streak Clan War</a></li>
							</ul>
						</li>
					</ul>
				</div>
			</div>

			<div id="bottom">

				<div class="wrapper">
					<div id="bottom-text">Copyright © <a href="https://www.facebook.com/EminenceGaming?fref=ts">Maiet Entertainment, Inc</a> Web Rediseñada por SkipChop/Juan</div>

					<ul class="social ">
						<li><a href="https://www.facebook.com/EminenceGunZ?fref=ts" class="poshytip  facebook" title="Facebook EminenceGunZ"></a></li>
					</ul>

					<div id="to-top" class="poshytip" title="Subir"></div>
				</div>

			</div>

	
	
<div id="fancybox-tmp"></div><div id="fancybox-loading"><div></div></div><div id="fancybox-overlay"></div><div id="fancybox-wrap"><div id="fancybox-outer"><div class="fancybox-bg" id="fancybox-bg-n"></div><div class="fancybox-bg" id="fancybox-bg-ne"></div><div class="fancybox-bg" id="fancybox-bg-e"></div><div class="fancybox-bg" id="fancybox-bg-se"></div><div class="fancybox-bg" id="fancybox-bg-s"></div><div class="fancybox-bg" id="fancybox-bg-sw"></div><div class="fancybox-bg" id="fancybox-bg-w"></div><div class="fancybox-bg" id="fancybox-bg-nw"></div><div id="fancybox-content"></div><a id="fancybox-close"></a><div id="fancybox-title"></div><a href="javascript:;" id="fancybox-left"><span class="fancy-ico" id="fancybox-left-ico"></span></a><a href="javascript:;" id="fancybox-right"><span class="fancy-ico" id="fancybox-right-ico"></span></a></div></div></body></html>