<table background="images/md_ir.jpg"  width="174" height="143" border="0">
<tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="4" rowspan="6">&nbsp;</td>
        <td height="4" colspan="2">&nbsp;</td>
      </tr>
     <?
$query = mssql_query("SELECT TOP 5 * FROM Character WHERE DeleteFlag = 0 ORDER BY XP DESC");

while($query2 = mssql_fetch_assoc($query))
{
 
$aid = $query2['AID'];
$cid = $query2['CID'];
 
$dtquery = mssql_query("SELECT PreGrade FROM DtCharacterInfo WHERE CID = '$cid'");
$dtquery2 = mssql_fetch_row($dtquery);
 
switch($dtquery2[0])
{
        case 10:
        $dtquery3 = "Images/class/22.jpg";
        break;
        case 9:
        $dtquery3 = "Images/class/33.jpg";
        break;
        case 8:
        $dtquery3 = "Images/class/44.jpg";
        break;
        case 7:
        $dtquery3 = "Images/class/55.jpg";
        break;
        case 6:
        $dtquery3 = "Images/class/66.jpg";
        break;
        case 5:
        $dtquery3 = "Images/class/77.jpg";
        break;
        case 4:
        $dtquery3 = "Images/class/88.jpg";
        break;
        case 3:
        $dtquery3 = "Images/class/99.jpg";
        break;
        case 2:
        $dtquery3 = "Images/class/111.jpg";
        break;
        case 1:
        $dtquery3 = "Images/class/222.jpg";
        break;
}
 
 
?>
	  <tr>
	  <td width="8" align="left">
  															<img src="<?=$dtquery3?>" height="15" width="15"></td>
  															<td width="102" align="left"><span class="Estilo6"><?=FormatCharName($query2['CID'])?></span>
         			      <td width="19"><span class="Estilo6">Lv.<?=$query2['Level']?>&nbsp;</span></td>
						   
										<td width="2"></td>
										<td width="3">										</td>
		</tr><?}?>
                                   
									<tr>
    </table>    <td height="39"></tr>
</table>
