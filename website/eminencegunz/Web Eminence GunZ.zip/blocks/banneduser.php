<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_loguedD.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>Eminence GunZ - Cuenta Banneada</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
</style>
						<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_loguedH.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>

										  <td width="8">&nbsp;</td>
										</tr>
<font color="#FFD204"><font face="Tahoma"><b>Banned , <?=$_SESSION[UserID]?> </b></font></font></span><td>
										<tr>
											<td width="30">&nbsp;
											</td>
											<td width="30">&nbsp;</td>
										</tr>
										<tr>
											<td width="30">
                                                                                           <span style="font-size: 7pt">Actualmente su cuenta esta Baneada.
											<p>Creo que ya sabe c�mo lleg� a este punto.</p>
                                                                                        <p>Siempre se puede hacer una nueva cuenta desde la p�gina de registro.</p>
                                                                                        <p>Para mas informacion revise nuestros <a href="http://eg-eminencegaming.com.ar/foro/">Foros</a>.</p>
                                                                                        <p>Desloguearse <a href="index.php?do=logout">Aqui</a>.</p>
                                                                                        <p>Tenga un buen Dia.</p>
											<p>ATT: Staff SkipChop</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="30" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="25">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
							</tr>
						</table>
					</div></form>


    <?
    die();
}

?>