<?
mssql_connect("TU-PC\SQLEXPRESS","sa","asdada");
mssql_select_db("GunzDB");
?>
