<?php
include_once('includes/config.inc.php'); 

//Global Configuration File
include_once('includes/global_config.inc.php');

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$address1 = $_POST['address2'];
$address2 = $_POST['address2'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$email = $_POST['email'];
$amount = $_POST['amount'];
$itemname = $_POST['item_name'];

if(empty($firstname) || empty($lastname) || empty($address1) || empty($address2) || empty($city) || empty($state) || empty($email)){
echo "
<script language=\"javascript\">
window.location=\"index.php?gunz=coins&error=form\";
</script>
";
} else {
?>
<html>
<head><title>::PHP PayPal::</title></head>
<body onLoad="document.paypal_form.submit();">
<form method="post" name="paypal_form" action="<?=$paypal[url]?>">

<?php 
//show paypal hidden variables

showVariables(); 

?> 

<center><font face="Verdana, Arial, Helvetica, sans-serif" size="2" color="#000000"><b>Processing Data wait . . . </b></font></center>

</form>
</body>   
</html>
<?
}
?>
