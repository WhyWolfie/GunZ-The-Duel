<style type="text/css">
<!--
.Estilo2 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>
<style type="text/css">
<!--
.Estilo6 {
	font-size: 11px;
	color: #FFFFFF;
}
-->
</style>
<p align="center"><img src="images/inconos/Lock.png" alt="Bloqueado" width="82" height="80" />
<br>
	<span class="Estilo2">USTED NO ESTA AUTORIZADO A INGRESAR A ESTA SECCION. </span><br>
  <br>
El enlace solicitado esta bloqueado para esta direcci&oacute;n de IP.<br>
</p>
<hr>
<p> 
  <p align="center">  <br>Error 401 - vuelva a eminencegunz.net, este mensaje es patrocinado por el Staff general de Eminence GunZ.<br></p>
<div class='post-body entry-content' expr:id='&quot;post-body-&quot; + data:post.id' itemprop='articleBody' oncontextmenu='return false' ondragstart='return false' onselectstart='return false'>
<table border="0" cellpadding="0" cellspacing="0" width="800">
<SCRIPT language=JavaScript>
<!--
function click() {
if (event.button== 2 ) {
alert( ' Lo siento, no se puede usar ese bot�n!' );
}
}
document.onmousedown=click
// -->
</SCRIPT>
<script language="Javascript">

<!-- Begin

document.oncontextmenu = function(){return false}

// End 

</script>

<script type="text/javascript">

// IE Evitar seleccion de texto

document.onselectstart=function(){

if (event.srcElement.type != "text" && event.srcElement.type != "textarea" && event.srcElement.type != "password")

return false

else return true;

};

// FIREFOX Evitar seleccion de texto

if (window.sidebar){

document.onmousedown=function(e){

var obj=e.target;

if (obj.tagName.toUpperCase() == "INPUT" || obj.tagName.toUpperCase() == "TEXTAREA" || obj.tagName.toUpperCase() == "PASSWORD")

return true;

/*else if (obj.tagName=="BUTTON"){

return true;

}*/

else

return false;

}

}

// End 

</script>





<!-- EVITAR ARRASTRAR Y SOLTAR

<script language="Javascript">

<!-- Begin

document.ondragstart = function(){return false}

// End 

</script>
