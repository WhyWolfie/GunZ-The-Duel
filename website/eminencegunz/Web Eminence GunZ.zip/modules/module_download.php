<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?php
include("secure/include.php");
SetTitle("Eminence GunZ - Descargas");
?>

<body onLoad="MM_preloadImages('../images/boton_donar02.png')">
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Descargas de EminenceGunZ Cliente Completo</font></b></td>
							  </tr>
								<tr>
									<td>
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="506" height="645">
                                       
                                        <tr>
                                          <td height="554" valign="top" background="images/descargas_seccion/info_dw_fd.png" bgcolor="#333333"><p><img src="images/descargas_seccion/info_dw_01.png" alt="dw" width="508" height="69"></p>
                                          <p>&nbsp;</p>
                                          <p>&nbsp;</p>
                                          <table width="494" height="183" align="center">
                                            <tr>
                                              <th width="484" valign="top" scope="col"><table width="457" align="center">
                                                <tr>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/1.png" alt="1" width="145" height="32" border="0"></a></th>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/2.png" alt="2" width="145" height="32" border="0"></a></th>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/3.png" width="145" height="32" border="0"></a></th>
                                                  <tr>
                                                </tr>
												<tr>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/4.png" width="145" height="32" border="0"></a></th>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/5.png" width="145" height="32" border="0"></a></th>
                                                  <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/6.png" width="145" height="32" border="0"></a></th>

                                                </tr>
                                                <tr>
                                               	<th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/7.png" width="145" height="32" border="0"></a></th>
                                                <th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/8.png" width="145" height="32" border="0"></a></th>
                                             	<th width="145" scope="col"><a href="Link Aqui"><img src="images/descargas_seccion/boton/9.png" width="145" height="32" border="0"></a></th>
                                                 

                                                </tr>
                                              </table></th>
                                            </tr>
                                          </table>                                          
                                          <p>&nbsp;</p></td>
                                        </tr>
                                      </table>
									</form>
									</div>
								  </td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_loginFr.php" ?>
						</div>
						</td>
					</tr>
</table>