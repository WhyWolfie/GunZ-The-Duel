<?php
include("secure/include.php");
SetTitle("EminenceGunZ - Ranking Individual");
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=individualrank");
    SetMessage("Ranking", array("Visualisar los Ranking Necesitas estar Logueado"));
    header("Location: index.php?do=login");
    die();
}

?><head>
<meta http-equiv="Content-Language" content="es" />
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
</head>


<table border="0" style="border-collapse: collapse" width="778">
					<tr>
						<td width="164" style="background-image: url('images/md_content_menu _r.PNG'); background-repeat: no-repeat; background-position: center top" valign="top">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="164">
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">&nbsp;</td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">
									<a href="index.php?do=individualrank">
									<img border="0" src="images/btn_individualrank_on.jpg" id = "76176img" width="131" height="21" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_individualrank_on.jpg')" /></td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127">
									<a href="index.php?do=clanrank">
									<img border="0" src="images/btn_clanranking_off.jpg" id="7816img271" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img271',/*url*/'images/btn_clanranking_on.jpg')" /></a></td>
									<td width="17">&nbsp;</td>
								</tr>
								<tr>
									<td width="14">&nbsp;</td>
									<td width="127"><a href="index.php?do=halloffame"><img src="images/btn_halloffame_off.jpg" alt="" border="0" id="hall" onmouseover="FP_swapImg(1,1,/*id*/'hall',/*url*/'images/btn_halloffame_on.jpg')" onmouseout="FP_swapImgRestore()" /></a>									</td>
								  <td width="17">&nbsp;</td>
								</tr>
                          </table>
                        </div>
                        </td>
                        <td width="4">&nbsp;<p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p></p></td>
                        <td width="599" valign="top">
                        <div align="center">
                            <table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
                                <tr>
                                    <td style="background-image: url('images/content_title_ranking2.jpg'); background-repeat: no-repeat; background-position: center top" height="32" width="601" colspan="3">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;<p>&nbsp;</p>
                                    <p></p></td>
                                  <td style="background-repeat: repeat; background-position: center top" width="583" valign="top"><img src="images/mis_rankinglegend.jpg" /></td>
                                    <td style="background-repeat: repeat; background-position: center top" width="7" rowspan="6">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td width="583" height="15" valign="top" style="background-repeat: repeat; background-position: center top">
                                    <div align="center">
        <form method="GET" name="indsearch" action="index.php">
          <input type="hidden" name="do" value="individualrank" />
                    <select name="type">
                        <option value="1">Nombre de Personaje</option>
                        <option value="2">Nombre de Cuenta</option>
                    </select>��
          <input type="text" name="name"/>��
          <input type="submit" value="Buscar" />
          
        </form><p></td>
                              </tr>
                                <tr>
                                  <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
                                   
            <div id="wrapper-cent">
             
             
             
                                    
             <!-- Content Box Starts -->
                <div id="cont-frame">
                    <div id="cont-top"><div id="cont-title"></div>
                    </div>
                    <div id="cont-body">
                        <div id="news-wrap">
                        <div id="ranking-table-title"></div>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0" id="ranking-table">
                              <tr class="titles">
                                <td width="4%">&nbsp;</td>
								<td width="4%">Ranking&nbsp;</td>
                                <td width="19%"><span class="Estilo7">Nombre</span></td>
                                <td width="5%"><span class="Estilo7">Lvl</span></td>                                
                                <td width="12%"><span class="Estilo7">Exp</span></td>
                                <td width="13%"><span class="Estilo7">Kill/Death</span></td>
                                <td width="36%"><span class="Estilo7">Ultima Coneccion </span></td>
                              </tr>
                              <tr>
							   <td width="4%">&nbsp;</td>
                                <td width="4%">&nbsp;</td>
                                <td width="19%">&nbsp;</td>
                                <td width="5%">&nbsp;</td>                                
                                <td width="12%">&nbsp;</td>
                                <td width="13%">&nbsp;</td>
                                <td width="36%">&nbsp;</td>
                              </tr>
  <br />
                  <tr>
                              <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $accountq = mssql_query("SELECT AID FROM Account(nolock) WHERE UserID = '$name'");
                                                                if( mssql_num_rows($accountq) == 1 )
                                                                {
                                                                $accountdata = mssql_fetch_row($accountq);
                                                                $aid = $accountdata[0];
                                                                $squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount, LastTime, Sex FROM Character(nolock) WHERE AID = '$aid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP ASC";
                                                                }
                                                                else
                                                                {
                                                                    echo '
                                                                <tr>
                                                                    <td width="528" colspan="5" class="estilo5">
                                                                    <p align="center">
                                                                    - No data -</td>
                                                                </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {
                                                        switch( clean($_GET['pagetirado']) )
                                                        {
                                                            case "":
                                                                $ranks = "Ranking >= 1 AND Ranking <= 50";
                                                            break;
                                                            case "2":
                                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                                            break;
                                                            case "3":
                                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                                            break;
                                                            case "4":
                                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                                            break;
                                                            case "5":
                                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $ranks = "Ranking <= 50";
                                                            break;
                                                        }


                                                           $res = mssql_query("SELECT TOP 100 * FROM Character a, Account b WHERE a.AID=b.AID AND b.UGradeID !=255|254|253|252 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");
                                                            }
                                                            else
                                                            {
                                                                $res = mssql_query($squery);
                                                            }
                                                              if(mssql_num_rows($res) <> 0)
                                                              {
                                                                $count = 1;  
                                                                while($char = mssql_fetch_array($res))
                                                                  {
                                                                    if($char['Sex'] == 0)
  {
  $sexo = "<font color='#06f'>Hombre</font>";
  }elseif($char['Sex'] == 1){
  $sexo = "<font color='pink'>Mujer</font>";
 }
                ?>              <td>&nbsp;</td>
								<td><?=$count?></td>
                                <td><?=FormatCharName($char['CID'])?></td>
                                <td><?=$char['Level']?></td>
                                <td><?=$char['XP']?></td>
                                <td><?=$char['KillCount']?>/<?=$char['DeathCount']?></td>
                                <td><?=$char['LastTime']?></td>
                  </tr>
                  <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
          <?
          msgbox("Personaje no Encontrado","index.php?do=individualrank");
          ?>
          <?
                                                        }
                                                        ?>
                            </table>
                            <div id="ranking-table-footer"></div>
                           
                            <br class="clear" />
                        </div>
                    </div>
                    <div id="cont-footer"></div>
                </div>
             <!-- Content Box Ends -->
             
             <div id="copyright"></div>
            </div>                                </td>
                                </tr>
                                <tr>
                                  <td style="background-repeat: no-repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
                                    <p></p></td>
                                </tr>
                                <tr>
                                    <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
                                </tr>
                                <tr>
                                    <td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
                                </tr>
													  </table>
						</div>					  </td>						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login2.php" ?>
						</div>
					</tr>
</table>