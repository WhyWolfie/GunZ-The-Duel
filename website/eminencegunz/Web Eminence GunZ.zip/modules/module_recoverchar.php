<?php
include("secure/include.php");
SetTitle("Eminence GunZ - Recuperar Personajes");

if($_SESSION[AID] == "")
{
    SetURL("index.php?do=recoverchar");
    SetMessage("Recuperar Personajes", array("Debes estar conectado para recuperar personajes"));
    header("Location: index.php?do=login");
    die();
}
else
{
    $qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($qchars) == 0 )
    {
        SetMessage("Recuperar Personajes", array("Usted no tiene ning�n personaje en esta cuenta"));
        header("Location: index.php");
        die();
    }
    else
    {

    if( isset($_GET['cid']) )
    {
        $cid = clean($_GET['cid']);
        $qcharinfo = mssql_query_logged("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
        if( mssql_num_rows($qcharinfo) == 0 )
        {
            SetMessage("Recuperar Personajes", array("El personaje seleccionado no existe o no pertenece a su cuenta"));
            header("Location: index.php");
            die();
        }

        $info = mssql_fetch_assoc($qcharinfo);

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
        {
            SetMessage("Recuperar Personajes", array("Un personaje con el nombre seleccionado ya existe", "Desafortunadamente, este personaje no se puede recuperar"));
            header("Location: index.php?do=recoverchar");
            die();
        }

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        else
        {
            SetMessage("Recuperar Personajes", array("Su cuenta tiene 4 personajes activos, es decir, el m�ximo permitido", "Usted tiene que eliminar uno de tus personajes para recuperar la seleccionada"));
            header("Location: index.php?do=recoverchar");
            die();
        }

        SetMessage("Recuperar Personajes", array("El Personaje seleccionado se ha recuperado con �xito"));
        header("Location: index.php?do=recoverchar");
        die();
    }
    else
    {


    ?>
<style type="text/css">
<!--
.Estilo1 {
	font-size: 10px;
	font-weight: bold;
	color: #666666;
}
.Estilo3 {font-size: 12px}
-->
</style>

    <table border="0" style="border-collapse: collapse" width="100%">
    <tr>
        <td width="183" valign="top">
    	<div align="center">
    	<? include "blocks/block_rankingu.php" ?>
    	<? include "blocks/block_rankingc.php" ?>
    	</div>
    	</td>
    	<td valign="top">
        <div align="center">
		<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
		<tr>
		    <td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
			<div align="center"><span style="color:#FFFF00">
			<b><font face="Tahoma" size="2">Recuperaci�n de Personajes</font></b></td>
		</tr>
        <tr>
        <td align="center" width="75%">
        <p>
        <br /><br />
        <span style="color:#80BFFF">Aqu� podr�s recuperar personajes que has borrado
o te han borrado involuntariamente.
Debes de saber que en una cuenta de <span style="color:#FF0000">F<span style="color:#F7F8E0">resh <span style="color:#FF0000">G<span style="color:#F7F8E0">unZ <span style="color:#80BFFF">se permite
un m�ximo de 4 personajes, por lo tanto
si ya tienes 4 personajes activos y deseas recuperar
uno de los personajes borrados,
deber�s borrar un personaje activo
para dar lugar al que recuperar�s.</span></p>

        <span style="color:#FFFF00">Lista de personajes:</span><br />
        <br />
        <table align="center" border="1" width="60%" style="templatemo_footer_wrapper" id="table1">
        	<tr>
        		<td><span class="Estilo3"><b>Nombre</b></span></td>
        		<td><span class="Estilo3"><b>Level</b></span></td>
        		<td><span class="Estilo3"><b>Tipo</b></span></td>
        		<td><span class="Estilo3"><b>�Recuperar?</b></span></td>
        	</tr>
            <?

        while( $data = mssql_fetch_assoc($qchars) )
        {
            echo '
            	<tr>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo $data[DeleteName].'</td>';
                    }else{
                        echo $data[Name].'</td>';
                    }

                echo '<td>'.$data[Level].'</td>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo 'Borrado</td>
                    <td>';
                    }else{
                        echo 'Activo</td>
                    <td>';
                    }
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo '<a href="index.php?do=recoverchar&cid='.$data[CID].'">Recuperar!</a></td>
            	</tr>';
                    }else{
                        echo 'Activo</td>
            	</tr>';
                    }

        }
        ?>
        </table>
        <br /><br /></td></tr></table></div>
	  </td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
	  </tr>
</table>
        <?
    }
}
}

?>
