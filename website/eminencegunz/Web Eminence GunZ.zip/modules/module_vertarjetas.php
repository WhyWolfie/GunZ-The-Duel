<?php
// No tocar
if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }

//
if($_SESSION['AID'] == ""){
	msgbox("Para ingresar debes estar logueado.","index.php?do=login");
	die();
	}else{
	$very = mssql_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
	$acc = mssql_fetch_object($very);
	if($acc->UGradeID !== 255){
		msgbox("Usted no tiene permiso para ingresar.","index.php");
			}
			echo "<table align='center'  style='font-size:12px'><tr><td><b>";
	include "FreshDonacionestarjetasmovistarrevisaradiario20134aP4dinerobueno.txt";
	echo "</b></td></tr></table>";
		}

?>