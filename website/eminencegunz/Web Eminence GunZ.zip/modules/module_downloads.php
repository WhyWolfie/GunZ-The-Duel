<?
header("Location: http://www.facebook.com/SkipChop");
?>