<?php
include("secure/include.php");
SetTitle("Eminence GunZ  - Estado Del Servidor");
?>
<table width="724" border="0" align="center" cellspacing="0">
  <tr>
    <td width="722"><table width="722" border="0" align="center" cellspacing="0">
      <tr>
        <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
        <td width="353" valign="top"><div align="center">
            <table width="0" height="24" border="0" align="center">
              <tr valign="top">
                <td width="28" height="20"><div align="center"><? include"server.php" ?>
                  </div></td>
              </tr>
            </table>
        </div></td>
        <td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_loginFr.php" ?>
						</div>
						</td>
      </tr>
    </table></td>
  </tr>
</table>
