<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?
SetTitle("Eminence - GunZ - Descargas");
?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="83%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Emblem Upload</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
									  <p>Porfavor Primero debe Subir El Emblema del Clan:</p>
									  <p>&nbsp;</p>
									  <p><?php
   echo '
	  <table border="0" width="240">
	   <tr><td>
		  <table>
		   <tr><td>
			
			
   ';
 //Select User AID
 $seluaid = mssql_query("SELECT * FROM Account WHERE AID='".$_SESSION[AID]."'");
 $uaid = mssql_fetch_object($seluaid);
 //Select User CID
 $selucid = mssql_query("SELECT * FROM Character WHERE AID='".$uaid->AID."' AND DeleteFlag='0'");
  echo '<br />
  <table border="0" align="center">
	<form action="index.php?do=emblems2" method="post" enctype="multipart/form-data">
	  <tr><td><div><select name="clanname">
  ';
 while($ucid = mssql_fetch_object($selucid)){
 //Select User Clan
 $seluclan = mssql_query("SELECT * FROM Clan WHERE MasterCID='".$ucid->CID."' AND DeleteFlag='0'");
 while($uclan = mssql_fetch_object($seluclan)){
                 
    echo '
		<option value="'.$uclan->Name.'">'.$uclan->Name.'</option>
	';
   
 }}
   echo '</select></div></td>
	  <td><input type="text" name="link" /></td>
	  <td><input type="submit" name="insert" value="Subir!" /></td></tr>
	</form>
	</table>
	   <br />
    ';

//Upload
echo '<div class="errmess">';
 if(isset($_POST['insert'])){
 $clanname = ($_POST['clanname']);
 $emblem = ($_POST['link']);
 
	  
	  $sqluploademb = mssql_query("UPDATE Clan SET EmblemUrl='$emblem' WHERE Name='$clanname'");
	  $sqluploademb = ("UPDATE Clan SET EmblemChecksum='1' WHERE Name='$clanname'");
	  echo "Emblem Uploaded!";	 
      
 }
echo '</div>';
 
	echo ' <br />
			
		   </td></tr>
		  </table>
		</td></tr>
	  </table>
   ';
?></p>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>