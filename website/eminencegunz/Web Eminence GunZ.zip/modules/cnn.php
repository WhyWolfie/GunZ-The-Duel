<?
// Conex�o & Protect -- N�o mexer 
include "config/config.php";
$cnn=@mssql_connect($iphost,$usersql,$senhasql) or die('Error al conectar a sql');
$db=@mssql_select_db($dbsql,$cnn) or die('Error de conexi�n con la base de datos');
include('secure/sql_check.php');
include('secure/anti_inject.php');
include("secure/anti_sql.php");
include("secure/anti_inject_sql.php");
include("secure/inject.php");
require("criminalteam.php");
/////////////////////////////////
?>