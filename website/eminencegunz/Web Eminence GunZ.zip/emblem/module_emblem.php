<?php
include("func.php");

if(!empty($_FILES['image']['tmp_name']))
{
    $imagen = subirimg($_FILES['image']['tmp_name']);
    if(!empty($imagen))
    {
        echo "URL: ".$imagen;
    }else{
        echo "Error al Subir la Imagen :/";
    }
}
?>
<style type="text/css">
.Rojo {	color: #F00;
}
</style>

<form method="post" enctype="multipart/form-data">
    <input type="file" name="image">
    <br />
    <button type="submit">Subir</button>
</form>

<span class="Rojo">SOLO IMAGENES 100x100 Formato PNG</span>


<p>Recuerde que solo nesesitas lo que esta despues del /.. </p>
<p> http://i.imgur.com/<span class="Rojo">ooZiVRF.jpg</span> Solo Lo que esta en rojo es lo que colocaras abajo!</p>
<p>Ya tiene Su Link? Dirijase al Paso 2</p>
<p>&nbsp;</p>
<p><a href="index.php?do=emblems2">Paso Siguiente</a></p>
<p>&nbsp;</p>
