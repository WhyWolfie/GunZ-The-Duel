<?

@session_start();

//MSSQL Server configuration

$_MSSQL[Host]               = "37.59.88.61";
$_MSSQL[User]               = "hggunzweb";
$_MSSQL[Pass]               = "BeaT67%$**as";
$_MSSQL[DBNa]               = "hgGunZDB";

//MySQL Server configuration

$_MYSQL[Host]               = "WIN-Y6RRBUKP02F\SQLEXPRESS";
$_MYSQL[User]               = "sa";
$_MYSQL[Pass]               = "adrian123$$";
$_MYSQL[DBNa]               = "GunzDB";

//Configuration

$_CONFIG[NewsFID]           = 2;
$_CONFIG[EventsFID]         = 0;
$_CONFIG[vBulletinPrefix]   = "HGF";
$_CONFIG[ForumURL]          = "http://radiality.crearforo.org";

//Offline page
$_CONFIG[OfflinePage]       = "";




$r = mysql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mysql_select_db($_MSSQL[DBNa], $r);

?>