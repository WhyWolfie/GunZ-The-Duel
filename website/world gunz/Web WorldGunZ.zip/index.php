<?php
ob_start("ParseTitle");
function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("//Title", $_SESSION[PageTitle], $content);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("//Title", "World GunZ", $content);
        return $r;
    }
}
include "secure/functions.php";
include "secure/config.php";
include "secure/ban.php";
include "secure/ipban.php";
include "secure/shield.php";
?> 
<html>
<head>
<link rel="shortcut icon" href="img/fav.ico" type="image/x-icon" />
<title>//Title</title>
<script type="text/javascript" src="ajax/utilities.js"></script>
<script type="text/javascript" src="ajax/container.js"></script>
<script type="text/javascript" src="secure/functions.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
@import "style.css";
</style>
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
</head>
<body leftmargin="0" rightmargin="0" topmargin="0" bottommargin="0">
<div align="center">
    <tr>
      <td align="center"><table width="700" height="35" border="0" cellpadding="0" cellspacing="0" background="img/top_menu.png" style="background-repeat:no-repeat; background-position:center">
  <tr>
    <td align="center" class="Estilo4"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','700','height','35','src','img/menu','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','img/menu' ); //end AC code
</script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="700" height="35">
      <param name="movie" value="img/menu.swf">
      <param name="quality" value="high">
      <embed src="img/menu.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="700" height="35"></embed>
    </object></noscript></td>
  </tr>
</table>
  <table width="200" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center"><table width="700" height="150" border="0" cellpadding="0" cellspacing="0" background="img/toplogo.png" style="background-repeat:no-repeat; background-position:center">
        <tr>
          <td height="1"></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td align="center" height="5" class="Estilo1"></td>
    </tr>
    <tr>
      <td align="center" background="img/top_menu2.png" style="background-position:center; background-repeat:no-repeat" height="140"><table width="681" height="130" border="0">
        <tr>
          <td width="320" class="Estilo1" align="center"><? include"minipages/top5player.php" ?></td>
          <td width="181"><span class="Estilo1"><img src="img/surprises/00.png" width="320" height="130"></span></td>
          <td width="180" class="Estilo1" align="center"><? include"minipages/top5clan.php" ?></td>
        </tr>
      </table></td>
    </tr>
    <tr>
      <td align="center" height="5" class="Estilo1"></td>
    </tr>
    <tr>
      <td style="background-image:url(img/tables_top.png); background-position:top center; background-repeat:no-repeat" height="13"></td>
    </tr>
    <tr>
      <td style="background-image:url(img/tables_center.png); background-position:center; background-repeat:repeat-y" class="Estilo1" align="center"><table width="690" height="10" border="0" cellpadding="0" cellspacing="0">
        <tr>
          
          <td width="510" align="center" class="Estilo1" valign="top"><? if($_CONFIG[OfflinePage] == "")
{
if(isset($_GET['rg']))
{
$do = $_GET['rg'];
}else{
$do = "index";
}
if(file_exists("pages/rg_$do.php"))
{
include "pages/rg_$do.php";
{
}
}else{
alertbox("We are working on it...","index.php");
    die();
}
}
?></td>
		<td width="190" align="center" class="Estilo1" valign="top"><table width="190" border="0" cellpadding="0" cellspacing="0" bgcolor="#151515" align="center" class="login4">
            <tr>
              <td height="6"></td>
            </tr>
            <tr>
              <td align="center"><? include"minipages/playerpanel.php" ?></td>
            </tr>
            <tr>
              <td height="5"></td>
            </tr>
            <tr>
              <td align="center"><? include"minipages/serverstat.php" ?></td>
            </tr>
            <tr>
              <td height="6"></td>
            </tr>
            <tr>
              <td height="6" align="center"><param name="movie" value="http://www.youtube.com/v/LRQkqqHHPPI&hl=es_ES&fs=1&"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/LRQkqqHHPPI&hl=es_ES&fs=1&" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="180" height="180"></embed></object></td></td>
            </tr>
            <tr>
              <td height="6" align="center"></td>
            </tr>
            <tr>
            <tr>
              <td height="6"></td>
            </tr>
          </table></td>
        </tr>
      </table>
    
		<tr>
          <td style="background-image:url(img/tables_down.png); background-position:top center; background-repeat:no-repeat" height="14"></td>
        </tr>
        <tr>
          <td width="189" height="5"></td>
        </tr>
        <tr>
          <td class="Estilo1" align="center" height="35" valign="top"><font color="#333333">World GunZ  Owned by Devil and Lifeless!
 All righst reserved.<br>
              <em>- GunZ is a Registered Trademark of MAIET Entertainment
 - </em></font></td>
        </tr>
      </table>
</div>
</body>
</html>
<?php
ob_end_flush();
?> 