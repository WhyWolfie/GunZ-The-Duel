<?
SetTitle("World GunZ - Download");
?>
<table width="490" border="0" align="center" bgcolor="#151515" class="login4">
  <tr>
    <td height="5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo2">Download - Select a mirror</td>
  </tr>
  <tr>
    <td align="center" class="estilo1"><table width="470" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td background="img/download_detail.png" style="background-repeat:no-repeat; background-position:center" width="150" height="100"></td>
        <td align="center" class="estilo1"><a href="http://www.zshare.net/download/70139794a561e244/"><img src="img/download_btn.png" width="100" height="25" border="0"></a><a href="http://www.megaupload.com/?d=J56ZH66H"><img src="img/download_btn2.png" width="100" height="25" border="0"></a><a href="http://www.filefront.com/15176675/WG_V1.exe"><img src="img/download_btn3.png" width="100" height="25" border="0"></a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" class="estilo1"><p>System Requirements<br>Your computer must meet certain minimum requirements in order to play GunZ.
  Before you download and install GunZ, please verify your system specifications
  meet or exceed the following. </p></td>
  </tr>
  <tr>
    <td align="center" class="estilo1"><table width="375" class="login4">
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4"></td>
        <td align="center" bgcolor="#000000" class="Estilo4">Minimum</td>
        <td align="center" bgcolor="#000000" class="Estilo4">Recommended</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">Os</td>
        <td colspan="2" align="center" bgcolor="#202020" class="Estilo1">Windows XP</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">DirectX</td>
        <td colspan="2" align="center" bgcolor="#202020" class="Estilo1">DirectX 9.0c or above</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">CPU</td>
        <td align="center" bgcolor="#202020" class="Estilo1">Pentium III 500 MHz</td>
        <td align="center" bgcolor="#202020" class="Estilo1">Pentium III 800 MHz or higher</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">RAM</td>
        <td align="center" bgcolor="#202020" class="Estilo1">256MB</td>
        <td align="center" bgcolor="#202020" class="Estilo1">512 MB or above</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">Graphics Card</td>
        <td align="center" bgcolor="#202020" class="Estilo1">Direct 3D 9.0 Compatible (Riva TNT)</td>
        <td align="center" bgcolor="#202020" class="Estilo1">GeForce 4MX or higher</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">Sound Card</td>
        <td colspan="2" align="center" bgcolor="#202020" class="Estilo1">Direct3D Sound Compatible</td>
      </tr>
      <tr>
        <td align="center" bgcolor="#000000" class="Estilo4">Mouse</td>
        <td colspan="2" align="center" bgcolor="#202020" class="Estilo1">Windows Compatible (Wheel Mouse recommended)</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" class="estilo1">
<img src="img/control.png" width="400" height="185"></td>
  </tr>
  <tr>
    <td height="5"></td>
  </tr>
</table>