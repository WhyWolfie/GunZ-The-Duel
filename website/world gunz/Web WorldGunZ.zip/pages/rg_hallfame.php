<?
SetTitle("World GunZ - Hall Of Fame");
?><head>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>

<table width="490" border="0" align="center" cellpadding="0" cellspacing="0" class="login4">
  <tr>
    <td align="center"><table width="480" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2"><strong>Hall Of Fame </strong></td>
      </tr>
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2">Choose: <a href="index.php?rg=ranking">Player Ranking</a> - <a href="index.php?rg=clanranking">Clan Ranking</a> - <a href="index.php?rg=hallfame">Hall Of Fame </a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><form method="GET" name="honorrank" action="index.php">
                                    <input type="hidden" name="rg" value="hallfame" />
                                    <option>Viewing ranking from</option>
                                    <?
                                    $listq = mssql_query_logged("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'/'.$halldata[Year].'</option>';
									}
                                $querydate = mssql_query_logged("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                $ddata = mssql_fetch_row($querydate);
                                $month = $ddata[0];
                                $year = $ddata[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                                    ?>
                                    </select></form></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><table width="480" border="0" align="center" cellpadding="0" cellspacing="0" class="login3">
          <tr align="center">
            <td width="37" height="21" align="center" valign="bottom" class="Estilo1"><b>Rank</b></td>
            <td width="54" height="21" align="center" valign="bottom" class="Estilo1"><b>Emblem</b></td>
            <td width="108" height="21" align="center" valign="bottom" class="Estilo1"><b>Clan </b></td>
            <td width="79" height="21" align="center" valign="bottom" class="Estilo1"><b>Leader</b></td>
            <td width="85" height="21" align="center" valign="bottom" class="Estilo1"><b>Win/Lossed %</b></td>
            <td width="59" height="21" align="center" valign="bottom" class="Estilo1"><b>Points</b></td>
          </tr>
          <tr align="center">
            <td height="10" colspan="6"></td>
          </tr>
          <tr>
            <td colspan="6" valign="top">
              <table width="480%" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
<?
 switch( clean($_GET['p']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 25";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 25 AND Ranking <= 50";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 50 AND Ranking <= 75";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 75 AND Ranking <= 100";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                            }
$res2 = mssql_query_logged("SELECT TOP 25 * FROM ClanHonorRanking WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY RANKING DESC");
$count = 0;                                                                 
while($r = mssql_fetch_assoc($res2)){
                                                                       $clanemburl = ($clan->EmblemUrl == "") ? "clan/emblem/no_emblem.png" : $clan->EmblemUrl;?>
                <tr>
                  <td width="44" align="center" class="Estilo1">
                    <?=$r['Ranking']?>
                  </td>
                  <td width="58" align="center" class="Estilo1"><img src="http://192.168.0.199/<?=($r['EmblemUrl'] == "") ? "clan/emblem/no_emblem.png" : $r['EmblemUrl'];?>" width="34" height="30"></td>
                  <td width="123" align="center" class="Estilo1">
                    <b>
                    <a href="index.php?rg=cinfo&cinfo=<?=$r['ClanName']?>"><?=$r['ClanName']?></a>
                    </b></td>
                  <td width="91" align="center" class="Estilo1"><a href="index.php?rg=pinfo&cid=<?=$clan->MasterCID?>">
                    <? $res3 = mssql_query_logged("SELECT * FROM Character WHERE CID = '".$r['MasterCID']."'");
                                                                            $c = mssql_fetch_assoc($res3);
                                                                            echo FormatCharName($c['CID']);
                                                                        ?>
                    </a>              </td>
                  <td width="94" align="center" class="Estilo1"><?=$r['Wins'] . "/" . $r['Losses']?>
(<?=GetClanPercent($r['Wins'], $r['Losses'])?>)</td>
                  <td width="70" align="center" class="Estilo1"><?=$r['Point']?></td> <?
} 
?>                 
                </tr>

                <tr>
                  <td colspan="6" class="estilo1" align="center" height="10"></td>
                </tr>

            </table></td>
          </tr>
          <tr>
            <td colspan="6" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><br>
          <a href="index.php?rg=hallfame">[1-25]</a> - <a href="index.php?rg=hallfame&p=2">[26-50]</a> - <a href="index.php?rg=hallfame&p=3">[51-75]</a> - <a href="index.php?rg=hallfame&p=4">[76-100]</a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
    </table></td>
  </tr>
</table>                                          