<?
SetTitle("World GunZ - New Password");
if($_SESSION[AID] <> "")
{
alertbox("Logout first! <.<","index.php");
    die();
}
?>
<table width="490" border="0" align="center" bgcolor="#151515" class="login4">
  <tr>
    <td height="5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo2">New Password</td>
  </tr>
  <tr>
    <td align="center" class="estilo1"><?
if($_POST['submit'] == ""){
?>
						<form method="POST" action="index.php?rg=resetpass" name="newpass">
						<table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                            </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Username:</td>
                            <td class="Estilo1" align="right"><input name="userid" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Step 2" name="submit" class="Login"></td>
                          </tr>
                        </table>
						</form>  <?
            }elseif ($_POST['submit'] == "Step 2"){
                $userid = clean($_POST['userid']);
                if($userid == ""){
                    alertbox("Type your Username","index.php?rg=resetpass");
                }
                $res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");
                if (mssql_num_rows($res) == 0){
                    alertbox("Username ".ucfirst($userid)." doesn't exist.","index.php?rg=resetpass");
                }
                $_SESSION['ResetPwdUser'] = $userid;
                $info = mssql_fetch_assoc($res);
                ?>
				<form method="POST" action="index.php?rg=resetpass" name="newpass">
                <table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
					     <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                            </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">E-Mail:</td>
                            <td class="Estilo1" align="right"><input name="email" type="text" class="Login" size="20" maxlength="40"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Question:</td>
                            <td class="Estilo1" align="right"><b>
                              <?=$info['PS']?>
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Answer:</td>
                            <td class="Estilo1" align="right"><input name="rs" type="text" class="Login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Step 3" name="submit" class="Login"></td>
                          </tr>
                        </table>
				</form>
					 <?
                   }elseif ($_POST['submit'] == "Step 3"){
                        $sa = clean($_POST['rs']);
                        $email = clean($_POST['email']);
                        $res = mssql_query("SELECT * FROM Account WHERE Email = '$email' AND RS = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
														<form method="POST" action="index.php?rg=resetpass" name="newpass">
<table width="360" border="0" cellspacing="0" cellpadding="1">
                          <tr>
                            <td class="Estilo1" align="left"><? echo @$alertbox ?></td>
                            <td height="35" class="Estilo1" align="right"></td>
                          </tr>
						    <tr>
                            <td colspan="2" align="center" class="Estilo1">You must fill all!</td>
                            </tr>
                          <tr>
                            <td class="Estilo1" align="left" height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">New Password:</td>
                            <td class="Estilo1" align="right"><input name="pw1" type="password" class="login" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Retype:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="pw2" type="password" class="login" size="20" maxlength="20">
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"  height="35"></td>
                            <td class="Estilo1" align="right"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Finish" name="submit" class="Login"></td>
                          </tr>
                        </table>
														</form>
														<?
                            }else{
                                alertbox("Incorrect E-Mail or Secret Answer.","index.php?rg=resetpass");
                            }
                    }elseif ($_POST['submit'] == "Finish"){
                        if($_POST['pw1'] == $_POST['pw2']){
                            $pw1 = clean($_POST['pw1']);
                            mssql_query("UPDATE Login SET Password = '$pw1' WHERE UserID = '" . clean($_SESSION['ResetPwdUser']) . "'");
                            alertbox("Your password has been changed!","index.php");
                        }else{
                            alertbox("Fill in the blanks.","index.php?rg=resetpass");
                        }
                    }
							?></td>
  </tr>
  <tr>
    <td height="5"></td>
  </tr>
</table>
