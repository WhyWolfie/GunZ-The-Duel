<?
SetTitle("World GunZ - Profile");
if ($_SESSION['AID'] == ""){
    alertbox("Log in first!","index.php");
    die();
}
?>
<?
$alertbox = "";
$er = 0;
$registered = 0;
if(isset($_POST['submit'])){
    $pass[0]        = clean($_POST['pass1']);
    $pass[1]        = clean($_POST['pass2']);
    $email          = clean($_POST['email']);
    $country        = clean($_POST['country']);
    $name           = clean($_POST['name']);
    $age            = clean($_POST['age']);
    $sex            = clean($_POST['sex']);
    $ps             = clean($_POST['ps']);
    $rs             = clean($_POST['rs']);
	$address        = clean($_POST['address']);
    $zipcode        = clean($_POST['zipcode']);
	
   if($_POST['C1'] == "ON")
        {
        if($pass1 == $pass2){
        }else{
alertbox("Passwords do not match.","index.php?rg=profile");
            $era = 1;
        }
        if(strlen($pass1) < 6){
alertbox("Tu contrase�a es muy corta (6 caracter minimo).","index.php?rg=profile");
            $era = 1;
        }
        if($pass1 == "" Or $pass2 == ""){
alertbox("Type your Password.","index.php?rg=profile");
            $era = 1;
        }
        if ($era == 0){
            mssql_query("UPDATE Login SET Password = '$pass1' WHERE AID = '". $_SESSION['AID']."'" );
        }else{
            $er = 1;
		}
		        if($email == ""){
alertbox("Type your E-mail.","index.php?rg=profile");
            $er = 1;
        }
		        if($name == ""){
alertbox("Type your Name.","index.php?rg=profile");
            $er = 1;
        }
						        if($address == ""){
alertbox("Type your Address.","index.php?rg=profile");
            $er = 1;
        }
				        if($zipcode == ""){
alertbox("Type your ZipCode.","index.php?rg=profile");
            $er = 1;
        }
   if($_POST['C2'] == "ON")
        {
if($ps == ""){
alertbox("Type your Secret Question.","index.php?rg=profile");
$ert =1;
}

if($rs == ""){
alertbox("Type your Secret Answer.","index.php?rg=profile");
$ert = 1;
}         
		 if ($ert == 0){
                mssql_query("UPDATE Account SET RS = '$rs', PS= '$ps' WHERE AID = '". $_SESSION['AID']."'" );
            }else{
                $er =1;
            }

        }
		
   if($er == 0){
            $registered = 1;
        mssql_query("UPDATE Account SET Name = '$name', Email = '$email', Age = '$age', Sex = '$sex', Country= '$country', ZipCode= '$zipcode', Address= '$address' WHERE AID = '". $_SESSION['AID']."'" );
		}
       alertbox("Your account has been updated!","index.php?rg=profile");
        }else{
            $alertbox = alertbox("Enable Password to Update your account","index.php?rg=profile");
die();
        }
}else{

    $z = mssql_fetch_assoc(mssql_query("SELECT * FROM Account WHERE AID = {$_SESSION['AID']}"));
    $x = mssql_fetch_assoc(mssql_query("SELECT * FROM Login WHERE AID = {$_SESSION['AID']}"));

    $fr['UserID']        = $z[UserID];
    $fr['EMail']         = $z[Email];
    $fr['Password']      = $x[Password];
    $fr['Name']          = $z[Name];
	$fr['Age']           = $z[Age];
    $fr['Sex']           = $z[Sex];
	$fr['Country']       = $z[Country];
    $fr['ps']            = $z[PS];
    $fr['rs']            = $z[RS];
    $fr['address']       = $z[Address];
    $fr['zipcode']       = $z[ZipCode];
	
}

?>
<table width="490" border="0" align="center" class="login4">
                            <tr>
                              <td align="center" valign="top">
							  <form name="reg" method="POST" action="index.php?rg=profile">
						<table width="470" border="0" cellspacing="1" cellpadding="0">
                          <tr>
                            <td colspan="2" align="center"><? echo @$alertbox ?></td>
                          </tr>
                          <tr bgcolor="#000000">
                            <td colspan="2" align="center" class="Estilo1">Warning: <font color="#FF0000">Never give your password to anyone. A member of Staff will never ask for your password!</font></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="left" class="Estilo1" height="10"></td>
                          </tr>
                          <tr>
                            <td width="188" class="Estilo1" align="left">Username:</td>
                            <td width="182" class="Estilo1" align="right"><font size="2">
                              <?=$fr['UserID']?>
                            </font></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">E-Mail:</td>
                            <td class="Estilo1" align="right"><input name="email" type="text" class="Login" value="<?=$fr['EMail']?>" size="20" maxlength="30"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"></td>
                            <td class="Estilo1" align="right"><input type="checkbox" name="C1" onclick="Contra()" value="ON">
      Edit Password?</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Password:</td>
                            <td class="Estilo1" align="right"><input name="pass1" type="password" disabled class="Login" value="<?=$fr['Password']?>" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Retype Password: </td>
                            <td class="Estilo1" align="right"><input name="pass2" type="password" disabled class="Login" value="<?=$fr['Password']?>" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Name:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="name" type="text" class="Login" value="<?=$fr['Name']?>" size="20" maxlength="20">
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Age:</td>
                            <td class="Estilo1" align="right"><b>
                              <select size="1" name="age" value="<?=$fr['Age']?>" class="Login">
                                <option value='<?=$fr['Age']?>'>
                                <?=$fr['Age']?>
                                </option>
                                <option value='1'>1</option>
                                <option value='2'>2</option>
                                <option value='3'>3</option>
                                <option value='4'>4</option>
                                <option value='5'>5</option>
                                <option value='6'>6</option>
                                <option value='7'>7</option>
                                <option value='8'>8</option>
                                <option value='9'>9</option>
                                <option value='10'>10</option>
                                <option value='11'>11</option>
                                <option value='12'>12</option>
                                <option value='13'>13</option>
                                <option value='14'>14</option>
                                <option value='15'>15</option>
                                <option value='16'>16</option>
                                <option value='17'>17</option>
                                <option value='18'>18</option>
                                <option value='19'>19</option>
                                <option value='20'>20</option>
                                <option value='21'>21</option>
                                <option value='22'>22</option>
                                <option value='23'>23</option>
                                <option value='24'>24</option>
                                <option value='25'>25</option>
                                <option value='26'>26</option>
                                <option value='27'>27</option>
                                <option value='28'>28</option>
                                <option value='29'>29</option>
                                <option value='30'>30</option>
                                <option value='31'>31</option>
                                <option value='32'>32</option>
                                <option value='33'>33</option>
                                <option value='34'>34</option>
                                <option value='35'>35</option>
                                <option value='36'>36</option>
                                <option value='37'>37</option>
                                <option value='38'>38</option>
                                <option value='39'>39</option>
                                <option value='40'>40</option>
                                <option value='41'>41</option>
                                <option value='42'>42</option>
                                <option value='43'>43</option>
                                <option value='44'>44</option>
                                <option value='45'>45</option>
                                <option value='46'>46</option>
                                <option value='47'>47</option>
                                <option value='48'>48</option>
                                <option value='49'>49</option>
                                <option value='50'>50</option>
                                <option value='51'>51</option>
                                <option value='52'>52</option>
                                <option value='53'>53</option>
                                <option value='54'>54</option>
                                <option value='55'>55</option>
                                <option value='56'>56</option>
                                <option value='57'>57</option>
                                <option value='58'>58</option>
                                <option value='59'>59</option>
                                <option value='60'>60</option>
                                <option value='61'>61</option>
                                <option value='62'>62</option>
                                <option value='63'>63</option>
                                <option value='64'>64</option>
                                <option value='65'>65</option>
                                <option value='66'>66</option>
                                <option value='67'>67</option>
                                <option value='68'>68</option>
                                <option value='69'>69</option>
                                <option value='70'>70</option>
                                <option value='71'>71</option>
                                <option value='72'>72</option>
                                <option value='73'>73</option>
                                <option value='74'>74</option>
                                <option value='75'>75</option>
                                <option value='76'>76</option>
                                <option value='77'>77</option>
                                <option value='78'>78</option>
                                <option value='79'>79</option>
                                <option value='80'>80</option>
                                <option value='81'>81</option>
                                <option value='82'>82</option>
                                <option value='83'>83</option>
                                <option value='84'>84</option>
                                <option value='85'>85</option>
                                <option value='86'>86</option>
                                <option value='87'>87</option>
                                <option value='88'>88</option>
                                <option value='89'>89</option>
                                <option value='90'>90</option>
                                <option value='91'>91</option>
                                <option value='92'>92</option>
                                <option value='93'>93</option>
                                <option value='94'>94</option>
                                <option value='95'>95</option>
                                <option value='96'>96</option>
                                <option value='97'>97</option>
                                <option value='98'>98</option>
                                <option value='99'>99</option>
                                <option value='100'>100</option>
                              </select>
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Sex:</td>
                            <td class="Estilo1" align="right"><select size="1" name="sex" value="<?=$fr['Sex']?>" class="Login">
                                <option selected value="<?=$fr['Sex']?>">
                                <?=$fr['Sex']?>
                                </option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                
                            </select></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Country:</td>
                            <td class="Estilo1" align="right"><b>
                              <select name="country" value="<?=$fr['Country']?>" class="Login">
                                <option value="<?=$fr['Country']?>" selected>
                                <?=$fr['Country']?>
                                </option>
                                <option value="Albania">Albania</option>
                                <option value="Algeria">Algeria</option>
                                <option value="Andoria">Andorra</option>
                                <option value="Angola">Angola</option>
                                <option value="Anguilla">Anguilla</option>
                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                <option value="Argentina">Argentina </option>
                                <option value="Amenia">Armenia</option>
                                <option value="Aruba">Aruba</option>
                                <option value="Australia">Australia </option>
                                <option value="Austria">Austria</option>
                                <option value="Azerbaijan Republic">Azerbaijan Republic</option>
                                <option value="Bahamas">Bahamas</option>
                                <option value="Bahrain">Bahrain</option>
                                <option value="Barbados">Barbados</option>
                                <option value="Belgium">Belgium</option>
                                <option value="Belize">Belize</option>
                                <option value="Benin">Benin</option>
                                <option value="Bermuda">Bermuda</option>
                                <option value="Bhutan">Bhutan</option>
                                <option value="Bolivia">Bolivia</option>
                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                <option value="Botswana">Botswana</option>
                                <option value="Brazil">Brazil</option>
                                <option value="British Virgin Islands">British Virgin Islands</option>
                                <option value="Brunei">Brunei</option>
                                <option value="Bulgaria">Bulgaria</option>
                                <option value="Burkina Faso">Burkina Faso </option>
                                <option value="Burundi">Burundi</option>
                                <option value="Cambodia">Cambodia</option>
                                <option value="Canada">Canada</option>
                                <option value="Cape Verde">Cape Verde</option>
                                <option value="Cayman islands">Cayman Islands</option>
                                <option value="Chad">Chad</option>
                                <option value="Chile">Chile</option>
                                <option value="China">China</option>
                                <option value="Colombia">Colombia</option>
                                <option value="Comoros">Comoros</option>
                                <option value="Cook Islands">Cook Islands</option>
                                <option value="Costa Rica">Costa Rica</option>
                                <option value="Croatia">Croatia</option>
                                <option value="Cyprus">Cyprus</option>
                                <option value="Czech Republic">Czech Republic</option>
                                <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                                <option value="Denmark">Denmark</option>
                                <option value="Djibouti">Djibouti</option>
                                <option value="Dominica">Dominica</option>
                                <option value="Dominican Republic">Dominican Republic</option>
                                <option value="Ecuador">Ecuador</option>
                                <option value="El Salvador">El Salvador</option>
                                <option value="Eritrea">Eritrea</option>
                                <option value="Estonia">Estonia</option>
                                <option value="Estados Unidos">Estados Unidos</option>
                                <option value="Ethiopia">Ethiopia</option>
                                <option value="Falkland">Falkland Islands </option>
                                <option value="Faroe Islands">Faroe Islands</option>
                                <option value="Federated States of Micronesia">Federated States of Micronesia</option>
                                <option value="Fiji">Fiji</option>
                                <option value="Finland">Finland</option>
                                <option value="France">France</option>
                                <option value="French Guiana">French Guiana</option>
                                <option value="French Polynesia">French Polynesia</option>
                                <option value="Gabon Republic">Gabon Republic</option>
                                <option value="Gambia">Gambia</option>
                                <option value="Germany">Germany</option>
                                <option value="Gibraltar">Gibraltar </option>
                                <option value="Greece">Greece</option>
                                <option value="Greenland">Greenland </option>
                                <option value="Grenada">Grenada</option>
                                <option value="Guadeloupe">Guadeloupe</option>
                                <option value="Guatemala">Guatemala </option>
                                <option value="Guinea">Guinea</option>
                                <option value="Guinea Bissau">Guinea Bissau </option>
                                <option value="Guyana">Guyana</option>
                                <option value="Honduras">Honduras</option>
                                <option value="Hong Kong">Hong Kong </option>
                                <option value="Hungary">Hungary</option>
                                <option value="Iceland">Iceland</option>
                                <option value="India">India</option>
                                <option value="Indonesia">Indonesia </option>
                                <option value="Ireland">Ireland</option>
                                <option value="Israel">Israel</option>
                                <option value="Italy">Italy</option>
                                <option value="Jamaica">Jamaica</option>
                                <option value="Japan">Japan</option>
                                <option value="Jordan">Jordan</option>
                                <option value="Kazakhstan">Kazakhstan </option>
                                <option value="Kenya">Kenya</option>
                                <option value="Kiribati">Kiribati</option>
                                <option value="Korea">Korea</option>
                                <option value="Kuwait">Kuwait</option>
                                <option value="Kyrgyztan">Kyrgyzstan</option>
                                <option value="Laos">Laos</option>
                                <option value="Latvia">Latvia</option>
                                <option value="Lesotho">Lesotho</option>
                                <option value="Liechtenstein">Liechtenstein</option>
                                <option value="Lithuania">Lithuania</option>
                                <option value="Luxembourg">Luxembourg</option>
                                <option value="Madagascar">Madagascar</option>
                                <option value="Malawi">Malawi</option>
                                <option value="Malaysia">Malaysia</option>
                                <option value="Maldives">Maldives</option>
                                <option value="Mali">Mali</option>
                                <option value="Malta">Malta</option>
                                <option value="Marshall Islands">Marshall Islands</option>
                                <option value="Martinique">Martinique</option>
                                <option value="Mauritania">Mauritania</option>
                                <option value="Mauritius">Mauritius</option>
                                <option value="Mayotte">Mayotte</option>
                                <option value="Mexico">Mexico</option>
                                <option value="Mongolia">Mongolia</option>
                                <option value="Montserrat">Montserrat</option>
                                <option value="Moroco">Morocco</option>
                                <option value="Mozambique">Mozambique</option>
                                <option value="Namibia">Namibia</option>
                                <option value="Nauru">Nauru</option>
                                <option value="Nepal">Nepal</option>
                                <option value="Netherlands">Netherlands </option>
                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                <option value="New Celedonia">New Caledonia</option>
                                <option value="New Zealand">New Zealand</option>
                                <option value="Nicaragua">Nicaragua</option>
                                <option value="Niger">Niger</option>
                                <option value="Niue">Niue</option>
                                <option value="Norfolk Island">Norfolk Island</option>
                                <option value="Norway">Norway</option>
                                <option value="Oman">Oman</option>
                                <option value="Palau">Palau</option>
                                <option value="Panama">Panama</option>
                                <option value="Papua New Guinea">Papua New Guinea</option>
                                <option value="Peru">Peru</option>
                                <option value="Philippines">Philippines</option>
                                <option value="Pitcairn Islands">Pitcairn Islands</option>
                                <option value="Poland">Poland</option>
                                <option value="Portugal">Portugal</option>
                                <option value="Qatar">Qatar</option>
                                <option value="Republic of the Congo">Republic of the Congo</option>
                                <option value="Reunion">Reunion</option>
                                <option value="Romania">Romania</option>
                                <option value="Russia">Russia</option>
                                <option value="Rwanda">Rwanda</option>
                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                <option value="WS">Samoa</option>
                                <option value="San Marino">San Marino</option>
                                <option value="Sao Tome and Prncipe">Sao Tome and Prncipe</option>
                                <option value="Saudi Arabia">Saudi Arabia</option>
                                <option value="Senegal">Senegal</option>
                                <option value="Seychelles">Seychelles</option>
                                <option value="Sierra Leone">Sierra Leone</option>
                                <option value="Singapore">Singapore</option>
                                <option value="Slovakia">Slovakia</option>
                                <option value="Slovenia">Slovenia</option>
                                <option value="Solomon Islands">Solomon Islands</option>
                                <option value="SO">Somalia</option>
                                <option value="South Africa">South Africa</option>
                                <option value="South Korea">South Korea</option>
                                <option value="Spain">Spain</option>
                                <option value="Sri Lanka">Sri Lanka</option>
                                <option value="St. Helena">St. Helena</option>
                                <option value="St. Kitts and Nevis">St. Kitts and Nevis</option>
                                <option value="St. Lucia">St. Lucia</option>
                                <option value="St. Pierre and Miquelon">St. Pierre and Miquelon</option>
                                <option value="Suriname">Suriname</option>
                                <option value="Svalbard and Jan Mayen Islands">Svalbard and Jan Mayen Islands</option>
                                <option value="Swaziland">Swaziland</option>
                                <option value="SE">Sweden</option>
                                <option value="Switzerland">Switzerland</option>
                                <option value="Taiwan">Taiwan</option>
                                <option value="Tajikistan">Tajikistan</option>
                                <option value="Tanzania">Tanzania</option>
                                <option value="Thailand">Thailand</option>
                                <option value="Togo">Togo</option>
                                <option value="Tonga">Tonga</option>
                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                <option value="Tunisia">Tunisia</option>
                                <option value="Turkey">Turkey</option>
                                <option value="Turkmenistan">Turkmenistan</option>
                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                <option value="Tuvalu">Tuvalu</option>
                                <option value="Uganda">Uganda</option>
                                <option value="Ukraine">Ukraine</option>
                                <option value="United States">United States</option>
                                <option value="United Arab Emirates">United Arab Emirates</option>
                                <option value="United Kingdom">United Kingdom </option>
                                <option value="Uruguay">Uruguay</option>
                                <option value="Vanuatu">Vanuatu</option>
                                <option value="Venezuela">Venezuela</option>
                                <option value="Vatican City State">Vatican City State</option>
                                <option value="Vietnam">Vietnam</option>
                                <option value="Wallis and Futuna Islands">Wallis and Futuna Islands</option>
                                <option value="Yemen">Yemen</option>
                                <option value="Zambia">Zambia</option>
                              </select>
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">ZipCode:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="zipcode" type="text" class="Login" value="<?=$fr['zipcode']?>" size="20" maxlength="5">
                            </b></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Address:</td>
                            <td class="Estilo1" align="right"><b>
                              <input name="address" type="text" class="Login" value="<?=$fr['address']?>" size="20" maxlength="20">
                            </b></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="left" class="Estilo1" height="10"></td>
                          </tr>
                          <tr bgcolor="#000000">
                            <td colspan="2" align="center" class="Estilo1"><font color="#FF0000">Secret Questions and Answer are used to recover your Password. </font></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1" height="10"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left"></td>
                            <td class="Estilo1" align="right"><input type="checkbox" name="C2" onclick="Secret()" value="ON">
      Edit?</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Question: </td>
                            <td class="Estilo1" align="right"><input name="ps" type="text" disabled class="Login" id="ps" value="<?=$fr['ps']?>" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="left">Secret Answer: </td>
                            <td class="Estilo1" align="right"><input name="rs" type="text" disabled class="Login" id="rs" value="<?=$fr['rs']?>" size="20" maxlength="20"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="left" class="Estilo1" height="20"></td>
                          </tr>
                          <tr>
                            <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Update" name="submit" class="Login"></td>
                          </tr>
                        </table>
</form>
						</td>
                      </tr>
</table>