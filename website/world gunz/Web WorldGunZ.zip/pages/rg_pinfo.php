<?
SetTitle("World GunZ - Player Information");
    ?>
	<?
    $cid = clean($_GET['cid']);
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    mssql_query("UPDATE Character SET Views = Views + 1 WHERE CID = $cid");
    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
<table width="490" border="0" bgcolor="#151515" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                                <?=FormatCharName($char['CID'])?> Information</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Personal Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Name:</td>
                                    <td align="left" class="estilo1"><?=$char2['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">E-Mail:</td>
                                    <td align="left" class="estilo1"><?=$char2['Email']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Sex:</td>
                                    <td align="left" class="estilo1"><?=$char2['Sex']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Age:</td>
                                    <td align="left" class="estilo1"><?=$char2['Age']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Rank:</td>
                                    <td align="left" class="estilo1"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Member";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "254";
                                                        $ugradeid = "GM";
                                                        break;
							case "253";
                                                        $ugradeid = "Banned";
                                                        break;
							case "3";
                                                        $ugradeid = "Developer";
                                                        break;
							case "255";
                                                        $ugradeid = "Administrator";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Country:</td>
                                    <td align="left" class="estilo1"><?=$char2['Country']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">User Number: </td>
                                    <td align="left" class="estilo1"><?=$char['AID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Visit:</td>
                                    <td align="left" class="estilo1"><?=$char['Views']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Created: </td>
                                    <td align="left" class="estilo1"><?=$char2['RegDate']?></td>
                                  </tr>
                                </table></td>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Character Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Name:</td>
                                    <td align="left" class="estilo1"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Level:</td>
                                    <td align="left" class="estilo1"><?=$char['Level']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ranking:</td>
                                    <td align="left" class="estilo1"><?=$char['Ranking']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Exp:</td>
                                    <td align="left" class="estilo1"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Kill/Death:</td>
                                    <td align="left" class="estilo1"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Clan:</td>
                                    <td align="left" class="estilo1"><a href="index.php?rg=cinfo&cinfo=<?=$claninfo['Name']?>"><?=$claninfo['Name']?></a></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Character Number: </td>
                                    <td align="left" class="estilo1"><?=$char['CID']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Created: </td>
                                    <td align="left" class="estilo1"><?=$char['RegDate']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Last Login: </td>
                                    <td align="left" class="estilo1"><?=$char['LastTime']?></td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table></td>
                          </tr>
</table>
