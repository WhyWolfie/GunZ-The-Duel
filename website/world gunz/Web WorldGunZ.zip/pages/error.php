<?php
alertbox("Invalid Payment!","index.php");
    die();
?>

