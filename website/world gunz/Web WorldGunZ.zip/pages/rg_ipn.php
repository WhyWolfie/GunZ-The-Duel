<?php
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

$item_name = $_POST['item_name'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$userid = $_POST['custom'];

if (!$fp) {
} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
$res = fgets ($fp, 1024);
if (strcmp ($res, "VERIFIED") == 0) {
$res = mssql_query_logged("SELECT * FROM PayPal WHERE TransactionID = '$txn_id'");
if (mssql_num_rows($res) >= 1){
include 'success.php';
}else{
/////////////////////////
$query = mssql_query_logged("SELECT [SCoins] FROM [Account] WHERE [AID] = '$userid'");
$item = mssql_fetch_assoc($query);
$coins = $item['SCoins'];
$amountcoins = $_POST['mc_gross'];
$coins += $amountcoins*10;
mssql_query_logged("UPDATE [Account] SET [SCoins] = $coins WHERE [AID] = '$userid'");
/////////////////////////
mssql_query_logged("INSERT INTO PayPal (TransactionID, Amount, Email)Values ('$txn_id', '$payment_amount', '$payer_email')");
include 'success.php';
}
}
else if (strcmp ($res, "INVALID") == 0) {
include 'error.php';
}
}
fclose ($fp);
}
?>