<?
SetTitle("World GunZ - Clan Information");
    ?>
<?
$cinfo = clean($_GET['cinfo']);
$query = mssql_query("SELECT * FROM Clan WHERE Name = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$clid = $clan->CLID;
?> 
<table width="490" border="0" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                               Clan, <?=$clan->Name?> 
                              Information</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="475" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="450" border="0" align="center">
                                  <tr>
                                    <td height="18" colspan="2" align="center" class="estilo1"><img src="clan/emblem/<?=($clan->EmblemUrl == "") ? "clan/emblem/no_emblem.png" : $clan->EmblemUrl?>" width="64" height="64"></td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                         <tr>
                                    <td align="left" class="estilo1">Rank:</td>
                                    <td align="left" class="estilo1"><?=$clan->Ranking?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Points:</td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Win:</td>
                                    <td align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Losses:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Draw:</td>
                                    <td align="left" class="estilo1"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ratio:</td>
                                    <td align="left" class="estilo1"><?=Porcentagem($clan->Wins, $clan->Losses)?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Created:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Members:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="450" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td align="center" class="estilo1">Character</td>
                                    <td align="center" class="estilo1">Rank</td>
                                    <td align="center" class="estilo1">Joined</td>
                                    <td align="center" class="estilo1">Points</td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><a href="index.php?rg=pinfo&cid=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                            </table></td>
                          </tr>
</table>
