<?
SetTitle("World GunZ Donate Page");
if($_SESSION['AID'] == "")
{
alertbox("Log in first...","index.php");
    die();
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " WG Coins";
        document.donation.item_number.value = coins;
    }

</script>
<table width="490" border="0" bgcolor="#151515" align="center" class="login4">
  <tr>
    <td width="135" align="center" class="estilo2"></td>
    <td width="345" height="5" align="center" class="estilo2"></td>
  </tr>
  <tr>
    <td colspan="2" align="center" class="estilo2">Donate to World GunZ </td>
  </tr>
  <tr>
    <td class="estilo2" align="center"></td>
    <td class="estilo2" align="center" height="20"></td>
  </tr>
  <tr>
    <td class="estilo1" align="center"><img src="img/bn_paypal.png" width="99" height="91"></td>
    <td class="estilo1" align="center" height="20"> The payment service PayPal is widely recognized to be quickly and safely. PayPal offers the use of the most popular for its credit card transactions. </td>
  </tr>
  <tr>
    <td class="estilo1" align="center" height="20"></td>
    <td class="estilo1" align="center"></td>
  </tr>
  <tr>
    <td height="20" colspan="2" align="center" class="estilo1"><form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <input type="hidden" name="cmd" value="_xclick" />
                                                <input type="hidden" name="business" value="mick.thomson@hotmail.com" />
                                                <input type="hidden" name="lc" value="US">
                                                <input type="hidden" name="currency_code" value="EUR" />
                                                <input type="hidden" name="no_note" value="1" />
                                                <input type="hidden" name="no_shipping" value="1" />
                                                <input type="hidden" name="tax" value="0.00" />
                                                <input type="hidden" name="bn" value="PP-BuyNowBF" />
                                                <input type="hidden" name="return" value="http://yoursite.net/gunz/index.php?rg=ipn" />
                                                <input type="hidden" name="cancel_return" value="http://yoursite.net/gunz/" />
                                                <input type="hidden" name="notify_url" value="http://yoursite.net/gunz/index.php?rg=ipn" />
                                                <input type="hidden" name="rm" value="2" />

                                                Donate:<br>
                                                <select name="amount" onchange="updateForm();" class="Login">
                                                    <option value="1.00">1 EUR</option>
                                                    <option value="2.00" selected>2 EUR</option>
                                                    <option value="5.00">5 EUR</option>
                                                    <option value="10.00">10 EUR</option>
                                                    <option value="20.00">20 EUR</option>
                                                    <option value="50.00">50 EUR</option>
                                                    
											
                                                </select>
                                                <br /><br>
                                                With this donation, you will get <span id="coins">25</span> WG Coins

                                                <input type="hidden" name="item_name" value="25 WGCoins">
                                                <input type="hidden" name="item_number" value="25">
                                                <input type="hidden" name="custom" value="<?php echo $_SESSION['AID']; ?>">
                                                <script type="text/javascript">
                                                    updateForm();
                                                </script><br><br>
												<input name="submit" type="submit" id="submit" value="Donate now" class="login">
    </form></td>
  </tr>
  <tr>
    <td class="estilo2" align="center"></td>
    <td class="estilo2" align="center" height="5"></td>
  </tr>
</table>
