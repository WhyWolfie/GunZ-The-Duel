<table width="490" height="469" border="0" align="top" cellpadding="0" cellspacing="0" class="login4">
  <tr valign="top">
                <td></td>
              </tr>
    &nbsp;</td>
  <td height="2"></tr>
  <tr>
    <td height="467" valign="top"><table width="480" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="top">
          <table width="480" height="30" border="0" cellpadding="0" cellspacing="0" background="img/news_title.png" class="login2" style="background-repeat:no-repeat; background-position:top center">
            <tr>
              <td class="estilo1" align="center" width="10"></td>
              <td class="estilo1" align="center" width="10"><font color="#0099FF">&raquo;</font></td>
              <td width="389" align="center" class="estilo1">ANNOUNCEMENTS // </td>
              <td width="81" align="left" class="estilo1"><a href="forum/index.php"><img src="img/moreinfo.gif" width="66" height="10" border="0"></a></td>
            </tr>
          </table>
          <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
          <table width="480" height="30" border="0" bgcolor="#050505">
            <tr>
              <td width="10" align="left" class="estilo1"></td>
              <td width="10" align="left" class="estilo1"></td>
              <td width="460" height="5" align="left" class="estilo1"></td>
            </tr>
            <tr>
              <td class="estilo1" align="left"></td>
              <td class="estilo2" align="left"><font color="#0099FF">&gt;</font></td>
              <td class="estilo2" align="left"><span class="menu"><a href="index.php?rg=news&sub=announcement&id=<?=$n['ICID']?>">
                <?=$n['Title']?>
              </a></span></td>
            </tr>
          </table>
          <? }?></td>
      </tr>
      <tr>
        <td align="center" height="60"></td>
      </tr>
      <tr>
        <td align="center" height="10"><table width="480" height="30" border="0" cellpadding="0" cellspacing="0" background="img/news_title.png" class="login2" style="background-repeat:no-repeat; background-position:top center">
            <tr>
              <td class="estilo1" align="center" width="10"></td>
              <td class="estilo1" align="center" width="10"><font color="#0099FF">&raquo;</font></td>
              <td width="389" align="center" class="estilo1">UPDATES // </td>
              <td width="81" align="left" class="estilo1"><a href="forum/index.php"><img src="img/moreinfo.gif" width="66" height="10" border="0"></a></td>
            </tr>
          </table>
            <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
            <table width="480" height="30" border="0" bgcolor="#050505">
              <tr>
                <td width="10" align="left" class="estilo1"></td>
                <td width="10" align="left" class="estilo1"></td>
                <td width="460" height="5" align="left" class="estilo1"></td>
              </tr>
              <tr>
                <td class="estilo1" align="left"></td>
                <td class="estilo2" align="left"><font color="#0099FF">&gt;</font></td>
                <td class="estilo2" align="left"><span class="menu"><a href="index.php?rg=news&sub=update&id=<?=$n['ICID']?>"></a><a href="index.php?rg=news&sub=update&id=<?=$n['ICID']?>">
                  <?=$n['Title']?></a></span></td>
              </tr>
            </table>
            <? }?></td>
      </tr>
    </table>
    <table width="480" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="479" rowspan="2" align="center" class="estilo2"><div align="center"></div></td>
        <td width="1" height="4" align="center" class="estilo2"></td>
      </tr>
      <tr>
        <td height="170" align="center" class="estilo2"></td>
      </tr>
    </table>    </td>
  </tr>
</table>
