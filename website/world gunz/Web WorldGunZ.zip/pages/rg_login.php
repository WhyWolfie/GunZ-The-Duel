<?
SetTitle("World GunZ - Login");
if($_SESSION[AID] <> "")
{
header("Location: index.php");
die();
}

if(isset($_POST[submit]))
{
$user = clean($_POST[userid]);
$pass = clean($_POST[pass]);

$q = mssql_query("SELECT * FROM Login WHERE UserID = '$user' AND Password = '$pass'");
if(mssql_num_rows($q) == 1)
{
$d = mssql_fetch_assoc($q);
$_SESSION[UserID] = $d[UserID]; $_SESSION[pass] = $d[Password];
$_SESSION[AID] = $d[AID];
$q1 = mssql_fetch_assoc(mssql_query("SELECT UGradeID FROM Account WHERE AID = '{$_SESSION[AID]}'"));
$_SESSION[UGradeID] = $q1[UGradeID];

$url = ($_SESSION[URL] == "") ? "index.php" : $_SESSION[URL];
$_SESSION[URL] = "";

header("Location: $url");
die();
}else{
alertbox("Incorrect Username or password.","index.php");
    die();
}
}

?>