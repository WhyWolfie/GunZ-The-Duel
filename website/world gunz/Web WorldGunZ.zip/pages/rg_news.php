<?
SetTitle("World GunZ - News");
    ?>
<?
if($_GET['sub'] == "announcement"){
    $res = mssql_query("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
<table width="490" border="0" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                                           <?=$a['Title']?></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top" height="10"><table width="475" border="0" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="left" class="estilo1">Submitted By <b><?=$a['User']?></b>, <?=$a['Date']?></td>
                              </tr>
                              <tr>
                                <td align="center" class="estilo1" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" class="estilo1"><?=$a['Text']?></td>
                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top" height="10"></td>
                          </tr>
</table>

<?
}else{
    $res = mssql_query_logged("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
<table width="490" border="0" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                                           <?=$a['Title']?></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top" height="10"><table width="475" border="0" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="left" class="estilo1">Submitted By <b><?=$a['User']?></b>, <?=$a['Date']?></td>
                              </tr>
                              <tr>
                                <td align="center" class="estilo1" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" class="estilo1"><?=$a['Text']?></td>
                              </tr>
                            </table></td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top" height="10"></td>
                          </tr>
</table>
<? }?>