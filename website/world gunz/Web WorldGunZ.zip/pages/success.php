<?php
alertbox("Success! WG Coins added to your account, thanks you for donate!","index.php");
    die();
?>

