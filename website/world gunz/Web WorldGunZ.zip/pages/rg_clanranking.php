<?
SetTitle("World GunZ Clan Ranking");
?><head>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>


<table width="490" border="0" align="center" cellpadding="0" cellspacing="0" class="login4">
  <tr>
    <td align="center"><table width="480" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2"><strong>Clan Ranking</strong></td>
      </tr>
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2">Choose: <a href="index.php?rg=ranking">Player Ranking</a> - <a href="index.php?rg=clanranking">Clan Ranking</a> - <a href="index.php?rg=hallfame">Hall Of Fame </a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><form method="GET" name="rnksearch" action="index.php">
                        <input type="hidden" name="rg" value="crank" />

                          <select name="type" class="Login">
                            <option value="1">Clan name</option>
                          </select>
                          <input type="text" name="name" class="Login" />
                          <input name="submit" type="submit" value="Search" class="login"/>
                    </form></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><table width="480" border="0" align="center" cellpadding="0" cellspacing="0" class="login3">
          <tr align="center">
            <td width="37" height="21" align="center" valign="bottom" class="Estilo1"><b>Rank</b></td>
            <td width="54" height="21" align="center" valign="bottom" class="Estilo1"><b>Emblem</b></td>
            <td width="108" height="21" align="center" valign="bottom" class="Estilo1"><b>Clan </b></td>
            <td width="79" height="21" align="center" valign="bottom" class="Estilo1"><b>Leader</b></td>
            <td width="85" height="21" align="center" valign="bottom" class="Estilo1"><b>Win/Lossed %</b></td>
            <td width="59" height="21" align="center" valign="bottom" class="Estilo1"><b>Points</b></td>
          </tr>
          <tr align="center">
            <td height="10" colspan="6"></td>
          </tr>
          <tr>
            <td colspan="6" valign="top">
              <table width="480%" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
                <?
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Ranking ASC";
                                                                }
                                                                else
                                                                {
                                                                    echo'
                                                               <tr>
                                            <td colspan="5" class="estilo1" align="center">
                                              - No Data -</td>
                                          </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {
                                                            switch( clean($_GET['p']) )
                                                            {
                                                            case "":
                                                                $rank = "Ranking >= 1 AND Ranking <= 25";
                                                            break;
                                                            case "2":
                                                                $rank = "Ranking > 25 AND Ranking <= 50";
                                                            break;
                                                            case "3":
                                                                $rank = "Ranking > 50 AND Ranking <= 75";
                                                            break;
                                                            case "4":
                                                                $rank = "Ranking > 75 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $rank = "Ranking <= 25";
                                                            break;
                                                            }
                                                            $res = mssql_query_logged("SELECT TOP 25 * FROM Clan WHERE $rank AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY POINT DESC, Ranking ASC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "sin_emblema.png" : $clan->EmblemUrl;
                                                     ?>
                <tr>
                  <td width="44" align="center" class="Estilo1">
                    <?=$clan->Ranking?>
                  </td>
                  <td width="58" align="center" class="Estilo1"><img src="clan/emblem/<?=($clan->EmblemUrl == "") ? "/clan/emblem/no_emblem.png" : $clan->EmblemUrl;?>" width="34" height="30" style="border: 1px solid #000000"></td>
                  <td width="123" align="center" class="Estilo1">
                    <a href="index.php?rg=cinfo&cinfo=<?=$clan->Name?>"><?=$clan->Name?></a></td>
                  <td width="91" align="center" class="Estilo1"> <a href="index.php?rg=pinfo&cid=<?=$clan->MasterCID?>">
                    <?=GetCharNameByCID($clan->MasterCID)?>
                  </a></td>
                  <td width="94" align="center" class="Estilo1"><?=$clan->Wins . "/" . $clan->Losses?>                    <?=GetClanPercent($clan->Wins, $clan->Losses)?>                    </td>
                  <td width="70" align="center" class="Estilo1"><?=$clan->Point?></td>
                </tr>
                <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
                <tr>
                  <td colspan="6" class="estilo1" align="center">- No Data - </td>
                </tr>
                <?
                                                        }
                                                        ?>
            </table></td>
          </tr>
          <tr>
            <td colspan="6" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><?
                                            if( $search == 0 )
                                            {
										    $name = clean($_GET['name']);
                                            ?>
          <?
                                            }
                                            ?>          <br>
          <a href="index.php?rg=clanranking">[1-25]</a> - <a href="index.php?rg=clanranking&p=2">[26-50]</a> - <a href="index.php?rg=clanranking&p=3">[51-75]</a> - <a href="index.php?rg=clanranking&p=4">[76-100]</a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
    </table></td>
  </tr>
</table>