<?
SetTitle("World GunZ - Staff List");
?>
<table width="490" border="0" align="center" bgcolor="#151515" class="login4">
  <tr>
    <td align="center" class="estilo1" height="5"></td>
  </tr>
  <tr>
    <td align="center" class="estilo2">Staff List </td>
  </tr>
  <tr>
    <td align="center" class="estilo2" height="18"></td>
  </tr>
  <tr>
    <td align="center" class="estilo2"><table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center" class="estilo2">Name</td>
        <td align="center" class="estilo2">Rank</td>
      </tr>
      <tr>
        <td align="center" class="estilo2" height="10"></td>
        <td align="center" class="estilo2"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1">Devil</td>
        <td align="center" class="estilo1">Owner</td>
      </tr>
      <tr>
        <td align="center" class="estilo1">Lifeless</td>
        <td align="center" class="estilo1">Owner</td>
      </tr>
      <tr>
        <td align="center" class="estilo1">Musie</td>
        <td align="center" class="estilo1">Co-Owner</td>
      </tr>
      <tr>
        <td align="center" class="estilo1">Isumi</td>
        <td align="center" class="estilo1">Game Master</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" class="estilo2" height="5"></td>
  </tr>
</table>
