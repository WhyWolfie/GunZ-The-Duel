<?
SetTitle("World GunZ - My Items");
if($_SESSION['AID'] == "")
{
alertbox("You dont got items (you dont got account)","index.php");
    die();
}
function ShowViewItems(){
    $res = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . clean($_SESSION['AID']) . "'");
	}              
    ?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*5
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RGCoins";
        document.donation.item_number.value = coins;
    }

</script>
<table width="490" border="0" bgcolor="#151515" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">My Premiums/Donator Items</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center"><table width="350" border="0" cellspacing="0" cellpadding="0">
                              <tr>
                                <td colspan="3" align="center" class="Estilo1"><table width="355" border="0" cellspacing="0" cellpadding="0">
                                  <tr>
                                    <td width="126" align="left" class="Estilo1">Name</td>
                                    <td width="115" align="center" class="Estilo1">Type</td>
                                    <td width="114" align="right" class="Estilo1">Expire</td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="Estilo1" height="20"></td>
                                    <td align="center" class="Estilo1"></td>
                                    <td align="right" class="Estilo1"></td>
                                  </tr>
                                </table></td>
								                                                    <? while ($item = mssql_fetch_assoc($res)){
                                                        $res2 = mssql_query("SELECT * From CashShop WHERE CSSID = '".$item['ShopItemID']."'");
                                                        $item2 = mssql_fetch_assoc($res2);
                                                        ?>
                              <tr>
                                <td width="126" align="left" class="Estilo1"><?=$item2['Name']?></td>
                                <td width="115" align="center" class="Estilo1"><?=$item2['Slot']?></td>
                                <td width="114" align="right" class="Estilo1"><?=$item['RentHourPeriod']?></td>
                                <? } ?>
                              </tr>
                            </table></td>
                          </tr>
</table>
