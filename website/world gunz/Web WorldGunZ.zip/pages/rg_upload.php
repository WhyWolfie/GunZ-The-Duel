<?
SetTitle("World GunZ - Emblem Upload");
if($_SESSION['AID'] == "")
{
alertbox("Log In first!","index.php");
    die();
	}
	include"secure/config.php";
	include"secure/sec.php";        
    ?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " WG Coins";
        document.donation.item_number.value = coins;
    }

</script>
<table width="490" border="0" bgcolor="#151515" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">Upload Clan Emblem </td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center"><table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center"><? 
$conn = @mssql_connect($DBHost, $DBUser, $DBPass); 
@mssql_select_db($DB); 



if (isset($_GET['step'])) {
	$argv = explode('-',$_GET['step']);
	settype($argv,'array'); 
	$_GET['step'] = @$argv[0];
	$_GET['url'] = @$argv[1];
	$_GET['do'] = @$argv[2];
	$_GET['mess'] = @$argv[3];
}
$step = !isset($_GET['step']) ? home : $_GET['step'] ;
		if ($step == '1') { echo'

<FORM METHOD=POST ACTION="index.php?rg=upload&step=2">
<table width="350" border="0" cellspacing="0" cellpadding="0" align="center">
    <tr>
    <td colspan="2" align="center" class="Estilo1">Log in to upload your clan emblem! </td>
    </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left">User:</td>
    <td class="Estilo1" align="right"><input name="user" type="textfield" class="login"/></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left">Password:</td>
    <td class="Estilo1" align="right"><input name="pass" type="password" class="login"/></td>
  </tr>
  <tr>
    <td class="Estilo1" align="left" height="20"></td>
    <td class="Estilo1" align="right"></td>
  </tr>
    <tr>
    <td colspan="2" align="center" class="Estilo1"><input name="submit" type="submit" value="Login" class="login"/></td>
    </tr>
</table></form> '; 
 } if ($step == '2') { 
 
$user1 = clean($_POST['user']);
$pass1 = clean($_POST['pass']);
    if (valida(Array($user1,$pass1)) == TRUE)
{

 $query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");
			while($r = mssql_fetch_array($query)){
if (mssql_num_rows($query) == 1){
						
						$query2 = mssql_query("
SELECT     Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID
FROM         ClanMember INNER JOIN
                      Clan ON ClanMember.CLID = Clan.CLID INNER JOIN
                      Login INNER JOIN
                      Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
					  if (mssql_num_rows($query2) >= '1'){
					  echo '<form enctype="multipart/form-data" action="index.php?rg=upload&step=done" method="POST">
  <p class="estilo1">Select the file:<br>
    <input name="uploaded" type="file" class="login"/>
  </p>
  <p><br />
    <input type="submit" value="Upload" class="login"/>
    </p><select name="clan" class="login">'
;
							for($i='';$i < @mssql_num_rows($query2);++$i){
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
							echo '<option value="'.$row[4].'">';echo $row[4];echo'</option>' ;
							

							}echo'</select></form>';
							}}else { echo " ERROR GEEN CLAN ";} }
							}
			;
		}  
	
	; 
	
	if ($step == 'done') { 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = $_POST['clan'];
$target = "C:/xampp/htdocs/gunz/clan/emblem/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$filename = basename( $_FILES['uploaded']['name']) ;
$ok=1;
if (!($_FILES['uploaded']['size']  > '104000'))
{
//echo "Tu imagen es muy grande!.<br>";
$ok=1;
if(($_FILES['uploaded']['type'] == "image/jpeg"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
if(($_FILES['uploaded']['type'] == "image/GIF"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
if(($_FILES['uploaded']['type'] == "image/PNG"))
{ 
$ok=1;
//echo "Error de tipo de imagen.<br>";
}
}
else { $ok=0;}

//


if ($ok==0)
{
echo "Sorry, the file was not sent!<br />";
echo "Please, check the size of your emblem.";
}
else
{
if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
{
echo "The File ".basename( $_FILES['uploadedfile']['name']). " has uploaded successfully!<br />";
echo "Listo y frito";
mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
mssql_query ("UPDATE Clan SET EmblemUrl = '$filename' WHERE Name = '$CLID'");
}
else
{
echo "Sorry, this account does not exist or dont have access to upload the emblem.";
}}
};
?></td>
                              </tr>
                            </table></td>
                          </tr>
</table>
