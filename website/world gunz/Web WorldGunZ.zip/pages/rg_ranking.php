<?
SetTitle("World GunZ - Player Ranking");
?><head>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>


<table width="490" border="0" align="center" cellpadding="0" cellspacing="0" class="login4">
  <tr>
    <td align="center"><table width="480" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2"><strong>Player Ranking</strong></td>
      </tr>
      <tr>
        <td align="center" class="estilo2" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo2">Choose: <a href="index.php?rg=ranking">Player Ranking</a> - <a href="index.php?rg=clanranking">Clan Ranking</a> - <a href="index.php?rg=hallfame">Hall Of Fame </a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1">Legend: <font color="#F88D1A">Administrator</font> - <font color="#9E19EA">GameMaster</font> - <font color="#04EEFF">Developer</font> - <font color="#0683F8">Donator</font> - <font color="#97FC22">Event Winner</font> - <font color="#FFFFFF">Member</font> - <font color="#333333">Muted</font></td>
</td> 
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="rg" value="ranking" class="login"/>
                                    <select name="type" class="login">
                                    <option value="1">Character name</option>
                                    </select>
                                    <input type="text" name="name" class="login"/>
                                    <input type="submit" value="Search" class="login"/>
					                </form></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><table width="470" border="0" cellpadding="0" cellspacing="0" class="login3">
          <tr align="center">
            <td width="72" height="21" valign="bottom" align="center" class="Estilo1"> <b>Rank</b></td>
            <td width="155" height="21" valign="bottom" align="center" class="Estilo1"> <b>Name</b></td>
            <td width="61" height="21" valign="bottom" align="center" class="Estilo1"> <b>Level</b></td>
            <td width="121" height="21" valign="bottom" align="center" class="Estilo1"> <b>Exp</b></td>
            <td width="125" height="21" valign="bottom" align="center" class="Estilo1"> <b>Kill/Death %</b></td>
            </tr>
          <tr>
            <td colspan="5" valign="top">
              <table width="470" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
                <tr>
                  <td width="63" height="10"></td>
                  <td width="137"></td>
                  <td width="53"></td>
                  <td width="107"></td>
                  <td width="109"></td>
                </tr>
                <?
                                                          if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            if($type == 1)
														
                                                            {
                                                                $squery = "SELECT CID, Level, XP, KillCount, Ranking, PlayTime, DeathCount FROM Character WHERE Name = '$name'";
                                                            }

                                                                else
                                                                {
                                                                    echo'
                                                               <tr>
                                            <td colspan="5">
                                              <p align="center" class="Estilo1">- No Data -</td>
                                          </tr>';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {switch( clean($_GET['p']) )
                                                        {
                                                            case "":
                                                                $rank = "Ranking >= 1 AND Ranking <= 25";
                                                            break;
                                                            case "2":
                                                                $rank = "Ranking > 25 AND Ranking <= 50";
                                                            break;
                                                            case "3":
                                                                $rank = "Ranking > 50 AND Ranking <= 75";
                                                            break;
                                                            case "4":
                                                                $rank = "Ranking > 75 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $rank = "Ranking <= 25";
                                                            break;
                                                        }
                                                        $res = mssql_query("SELECT TOP 25 CID, Level, XP, Ranking, KillCount, DeathCount FROM Character WHERE $rank ORDER BY  XP DESC");
														  }
                                                          else
                                                            {
                                                                $res = mssql_query_logged($squery);
                                                            }
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count = 1;
                                                            while($char = mssql_fetch_object($res))
                                                            {
                                                        ?>
                <tr>
                  <td width="63" align="center" class="Estilo1"> <b>
                    <?=$char->Ranking?>
                  </b> </td>
                  <td width="137" align="center" class="Estilo1"> <a href="index.php?rg=pinfo&cid=<?=$char->CID?>">
                    <?=FormatCharName($char->CID)?>
                  </a></td>
                  <td width="53" align="center" class="Estilo1">
                    <?=$char->Level?></td>
                  <td width="107" align="center" class="Estilo1">
                    <?=number_format($char->XP, 0, ",", ".")?></td>
                  <td width="109" align="center" class="Estilo1">
                    <?=GetKDRatio($char->KillCount, $char->DeathCount)?></td>
                </tr>
                <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
                <tr>
                  <td colspan="5" align="center" class="estilo1">- No Data - </td>
                </tr>
                <?
                                                        }
                                                        ?>
            </table></td>
            </tr>
          <tr>
            <td colspan="5" valign="top" height="10"></td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td align="center" class="estilo1"><?
                                    if( $search == 0 )
							        $name = clean($_GET['name']);
                                    { ?>
                                    <?
                                    }
                                    ?><br>
                                    <a href="index.php?rg=ranking">[1-25]</a> - <a href="index.php?rg=ranking&p=2">[26-50]</a> - <a href="index.php?rg=ranking&p=3">[51-75]</a> - <a href="index.php?rg=ranking&p=4">[76-100]</a></td>
      </tr>
      <tr>
        <td align="center" class="estilo1" height="10"></td>
      </tr>
    </table></td>
  </tr>
</table>