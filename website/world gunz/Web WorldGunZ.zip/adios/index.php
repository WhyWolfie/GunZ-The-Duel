<?php
if( !session_start() )
{
    session_start();
}
require "config.php";
include "functions.php";

$connection = connect();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Final World GunZ - Clan Delete</title>
<style type="text/css">
@import "estilo.css";
</style>
</head>

<body>

<?php

if( $_SESSION['AID'] == "" )
{
    if( isset($_POST['login']) )
    {
        login();
    }
    else
    {

?>
    <center>
    <p class="Estilo3"><b>Final World GunZ Clan Delete<b></b></p>
    <form name="login" method="POST" action="index.php">
    <?php showmessage(); ?>
        <table width="300" border="0" style="border-collapse: collapse" id="login">
            <tr>
                <td colspan="2" align="center"><b class="Estilo3">User Login : </b></td>
            </tr>
            <tr>
                <td colspan="2" height="20"></td>
            </tr>
            <tr>
                <td width="40%" align="left" class="Estilo1">User: </td>
                <td align="right"><input name="userid" type="text" size="20" maxlength="20" class="login"/></td>
            </tr>
            <tr>
                <td align="left" class="Estilo1">Password: </td>
                <td align="right"><input name="password" type="password" size="20" maxlength="20" class="login"/></td>
            </tr>
            <tr>
                <td colspan="2" height="20"></td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                <input type="submit" name="login" value="Enter" class="login"/>
                </td>
            </tr>
            <tr>
              <td colspan="2" align="center" height="35"><p><a href="http://yoursite.net/gunz">Return to web?</a></p></td>
            </tr>
      </table>
    </form>
    </center>
<?php
    }
}

if( $_SESSION['AID'] != "" )
{
    if( $_GET['do'] == "logout" )
    {
        logout();
    }

    if(isset($_POST['delete']))
    {
        $clid = clean_sql($_POST['clanid']);
        delete_clan($clid);
    }

    $list = getclanlist();
    $count = count($list);
    if($count == 0)
    {
        if( $_GET['do'] != "deleted" )
        {
            setmessage("Search CLan", "Any of your Char got Clan");
        }
        logout();
        redirect("http://lo.net");
        die();
    }
?><br><br>
    <center>
    <?php showmessage(); ?>
    <p class="Estilo1">Select the Clan you want to Delete: </p>
    <form method="post" name="delete" action="index.php" class="login">
        <select name="clanid">
        <?php
        for($i=0; $i < $count; $i++)
        {
            printf("<option value=\"%s\">Clan: %s - Master: %s</option><br />", $list[$i][1], $list[$i][2], $list[$i][0]);
        }
        ?>
        </select><br>
        <p><b><font color="#FF0000">Warning! When you delete your clan , you cant recover it</font></b></p>
        <input type="submit" name="delete" value="Delete" class="login">
    </form><br>
    <p><a href="http://yoursite.net/gunz">Return to web?</a></p>
    </center>
        </td>
    </tr>
    </table>
<?php
}
?>

</body>

</html>