<?php

   ///////////////////////////////////
  // Clan Delete System         /////
 /// -- Configuration File  -- /////
///////////////////////////////////

//MSSQL Server configuration

$_MSSQL[Host]   = "PCNAME\SQLEXPRESS";    // MSSQL Server HOST, it can be an IP Address or a computer name
$_MSSQL[User]   = "sa";                   // MSSQL User
$_MSSQL[Pass]   = "yourpass";                   // MSSQL Password
$_MSSQL[DBNa]   = "GunzDB";             // Gunz Database Name

// Here you set the language for the panel
// If you set this to english, the panel will try to load lang/english.php
$_CONFIG[Language]  = "english";

// Gunz Database Configuration
$_CONFIG[LoginTable]    = "Login";
$_CONFIG[CharTable]     = "Character";
$_CONFIG[ClanTable]    = "Clan";
$_CONFIG[ClanmemberTable]    = "ClanMember";

?>
