<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
$servercount = $servercount + $srv['CurrPlayer'];
}
function Acortar($cadena){
return substr($cadena,0,12) ."...";
}
?>
<table width="180" height="130" border="0" align="center" cellpadding="0" cellspacing="0" background="img/server_bg.png">
  <tr>
    <td align="center" height="30"></td>
  </tr>
  <tr>
    <td align="center"><table width="160" border="0">
      <tr>
        <td width="85" align="left" class="estilo1">User's Online: </td>
        <td width="75" align="right" class="estilo1"><?=$servercount?> / 1000</td>
      </tr>
      <tr>
        <td align="left" class="estilo1">Server Status: </td>
        <td align="right" class="estilo1"><? 
$ip = "127.0.0.1"; 
$port = "6000"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000">Offline</font>'; 
else{ 
echo '<font color="#00FF00">Online</font>'; 
fclose($sock); 
} 
?></td>
      </tr>
      <tr>
        <td align="left" class="estilo1">NAT Status: </td>
        <td align="right" class="estilo1"><? 
$ip = "127.0.0.1"; 
$port = "7778"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000">Offline</font>'; 
else{ 
echo '<font color="#00FF00">Online</font>'; 
fclose($sock); 
} 
?></td>
      </tr>
      <tr>
        <td align="left" class="estilo1">Server Rate: </td>
        <td align="right" class="estilo1">20x</td>
      </tr>
    </table></td>
  </tr>
</table>
