<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND Ranking != 0 ORDER BY POINT DESC");
$count = 0;
?>
<table width="180" height="130" border="0" cellpadding="0" cellspacing="0" background="img/top5clanbg.png" style="background-repeat:no-repeat; background-position:center">
  <tr>
    <td height="24" align="center"><table width="160" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td height="10"></td>
          <td align="right"><a href="index.php?rg=clanranking"><img src="img/more.gif" width="40" height="10" border="0"></a></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><table width="160" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" align="center">
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td width="33" align="center" class="Estilo1"> - No Data - </td>
      </tr>
      <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){
									$count++;

                                    ?>
      <tr>
        <td width="33" align="left" class="Estilo1">
          <?=$count?>
        </td>
        <td width="104" align="left" class="Estilo1"> <a href="index.php?rg=cinfo&cinfo=<?=$clan['Name']?>">
          <?=$clan['Name']?>
        </a> </td>
        <td width="23" align="right" class="Estilo1"><b>
          <?=$clan['Point']?>
        </b></td>
      </tr>
      <? }} ?>
    </table></td>
  </tr>
  <tr>
    <td align="center" height="15"valign="bottom"></td>
  </tr>
</table>
