<?
if($_SESSION[AID] == "")
{
?>
<style type="text/css">
@import "e_style.css";
</style>
<form name="login" method="POST" action="index.php?rg=login"><table width="180" height="130" border="0" align="center" cellpadding="0" cellspacing="0" background="img/loginzone_bg.png" style="background-repeat:no-repeat; background-position:center">
  <tr>
    <td width="475" align="center">
      <table width="150" border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
											<tr>
												<td width="154" colspan="2" height="30"></td>
											</tr>
											<tr>
												<td width="154">
												  <input name="userid" type="text" class="Login" style="float: left; background-image:url(img/mini_user.png); background-repeat:no-repeat" tabindex="1" value="" size="12" maxlength="12"></td>
												<td width="154" rowspan="2" valign="top" align="center">
												  <input name="login" type="image" id="login" src="img/login_button.png" align="right" width="40" height="40" border="0">
												</td>
											</tr>
											<tr>
												<td width="154" height="22">
											  <input name="pass"  type="password" class="Login" style="float: left; background-image:url(img/mini_pass.png); background-repeat:no-repeat" tabindex="2" size="12" maxlength="12"><input type="hidden" name="submit" value="1"></td>
											</tr>
											<tr>
												<td width="154" colspan="2" height="5">
												</td>
											</tr>
											<tr>
												<td width="154" colspan="2" height="15" valign="middle">
													<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse">
														<tr>
															<td width="2" height="20"></td>
															<td class="Estilo1">-</td>
															<td class="estilo1">
															<a href="index.php?rg=register">Join now! </a></td>
														</tr>
														<tr>
															<td width="2" height="20"></td>
															<td class="Estilo1">-</td>
															<td class="estilo1">
															<a href="index.php?rg=resetpass">Forgot your password? </a></td>
														</tr>
													</table>
												</td>
											</tr>
	    </table>
	  </td>
  </tr>
</table>
</form>
<?
}else{
$res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$a=mssql_fetch_assoc($res9);

$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
$d=mssql_fetch_assoc($res);
$items = mssql_num_rows($res9);

$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query2 = mssql_query_logged("SELECT SCoins, ECoins FROM Account WHERE AID = '{$_SESSION[AID]}'");
$_PLAYER[Account]   = mssql_fetch_assoc($query2);
?>
							<table width="180" height="300" border="0" align="center" cellpadding="0" cellspacing="0" background="img/loginzone_bg_on.png" style="background-repeat:no-repeat; background-position:topcenter">
                              <tr>
                                <td valign="top"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td height="30" class="Estilo1" align="center"></td>
                                  </tr>
                                  <tr>
                                    <td width="212" height="15" align="center" bgcolor="#151515" class="Estilo1">
        Hello, <?=$_SESSION[UserID]?>!
                                   </td>
                                  </tr>
                                  <tr>
                                    <td height="25"></td>
                                  </tr>
                                  <tr>
                                    <td><?
                                                    if(CheckIfExistClan($_SESSION[AID]))
                                                    {
                                                ?>
                                        <table width="100%" height="100%" border="0" align="center" style="border-collapse: collapse">
                                          <tr>
                                            <td width="102" align="center">
                                                <select onchange="UpdateClan()" id="clanlist" size="1" name="selclan" class="Login">
                                                  <?
                                                            $re = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
                                                            if( mssql_num_rows($re) > 0 )
                                                            {
                                                            while($char = mssql_fetch_assoc($re))
                                                            {
                                                                     $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
                                                                     if( mssql_num_rows($queryc) > 0 )
                                                                     {
                                                                        $a = mssql_fetch_assoc($queryc);
                                                                        $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));
												                                                                         $_CLAN[Name]       = $b[Name];
                                                                         $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
                                                                         $_CLAN[CLID]       = $a[CLID];
                                                                         $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "no_emblem.png" : $b[EmblemUrl];

                                                                         $info = implode("-|-", $_CLAN);

                                                                         if($_CLAN[Name] <> "")
                                                                            echo "<option value = '$info'>{$_CLAN[Name]}</option>";
                                                                     }
                                                                }
                                                            }
                                                            ?>
                                                </select></td>
                                            <td width="54" rowspan="3" align="center"><img id="emblema" src='$emblemurl' width="50" height="50" style="border: 1px #000000"></td>
                                          </tr>
                                          <tr>
                                            <td width="102" height="8"></td>
                                          </tr>
                                          <tr>
                                            <td width="102" align="center"><a href="index.php?rg=upload&step=1"><img src="img/bn_uploademblem.png" width="85" height="20" border="0"></a></td>
                                          </tr>
                                          <tr>
                                            <td height="25" colspan="2"><table width="155" border="0" align="center">
                                                <tr>
                                                  <td width="46" height="21" align="left" class="Estilo1">Leader:</td>
                                                  <td width="104" id="clanmaster" align="right" class="Estilo1">
                                                  </td>
                                                </tr>
                                            </table></td>
                                          </tr>
                                        </table>
                                        <?
                                                    }else{
                                                    ?>
                                        <table border="0" style="border-collapse: collapse" width="100%" height="100%">
                                          <tr>
                                            <td height="59" align="center" class="Estilo1">You are not in a clan.
Join one or create your own!</td>
                                          </tr>
                                          <td height="20"></td>
                                        </table>
                                        <?
                                                    }
                                                    ?>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td height="50" valign="top"><table width="170" height="20" border="0" align="center" class="Login3">
                                        <tr>
                                          <td width="85" class="Estilo1">Event Coins:</td>
                                          <td width="60" align="right" class="Estilo1"><?=$_PLAYER[Account][ECoins]?></td>
                                        </tr>
                                        <tr>
                                          <td height="20" class="Estilo1">WG Coins: </td>
                                          <td class="Estilo1" align="right"><?=$_PLAYER[Account][SCoins]?></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                                  <tr>
                                    <td height="2" valign="top"></td>
                                  </tr>
                                  <tr>
                                    <td height="60" valign="top"><table width="165" border="0" align="center" cellpadding="0">
                                        <tr>
                                          <td width="75" align="center"><? if($_SESSION['UGradeID'] == 255 )
										  { ?>
<a href="lofaszkucko/index.php"><img src="img/bn_admin.png" width="75" height="20" border="0"></a>                                        <?
                                                    }
                                                    ?>
                                         <? if($_SESSION['UGradeID'] == 254 && 252 )
										  { ?>
                                         <a href="gmpanel/index.php"><img src="img/bn_gm.png" width="75" height="20" border="0"></a>                                         <?
                                                    }
                                                    ?></td>
                                          <td width="75" align="center"></td>
                                        </tr>
                                        <tr>
                                          <td align="center"><a href="index.php?rg=myitems"><img src="img/bn_myitems.png" width="75" height="20" border="0"></a></td>
                                          <td align="center"><a href="index.php?rg=profile"><img src="img/bn_profile.png" width="75" height="20" border="0"></a></td>
                                        </tr>
                                        <tr>
                                          <td align="center"><a href="adios/index.php"><img src="img/bn_delclan.png" width="75" height="20" border="0"></a></td>
                                          <td align="center"><a href="index.php?rg=donate"><img src="img/bn_buyrg.png" width="75" height="20" border="0"></a></td>
                                        </tr>
                                        <tr>
                                          <td colspan="2" align="center"><a href="index.php?rg=logout"><img src="img/bn_logout.png" width="75" height="20" border="0"></a></td>
                                        </tr>
                                    </table></td>
                                  </tr>
                                </table></td>
                              </tr>
</table>
<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("emblema");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "clan/emblem/" + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>
<script language="javascript">
									UpdateClan();
								</script>
<?
}
?>