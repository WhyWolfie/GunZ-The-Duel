<?
SetTitle("World GunZ - Banned");
?>
  <table width="200" border="0" align="center">
    <tr>
      <td height="105"></td>
    </tr>
    <tr>
      <td height="158" align="center"><table width="380" height="150" border="0" align="center" background="img/bg_ban.png" style="background-repeat:no-repeat; background-position:topcenter">
        <tr>
          <td height="21"></td>
        </tr>
        <tr>
          <td align="center" class="Estilo1"><p><em>You <b></b>have been banned from World GunZ<br>
            </em><br>
            </p>
          </td>
        </tr>
        <tr>
          <td align="center" class="Estilo1"><em></em> </td>
        </tr>
      </table>
      </td>
    </tr>
  </table>