<?php

  $crlf=chr(13).chr(10);
  $itime=3;  //Minimum number of seconds between one-visitor visits
  $imaxvisit=10;  //Maximum visits in $itime x $imaxvisits seconds
  $ipenalty=($itime * $imaxvisit);  //Minutes for waitting
  $iplogdir="userlogs/";
  $iplogfile="AttackersIPs.Log";
  
  $to      = 'Your E-mail';  
  $headers = 'From: World GunZ DDOS Shield' . "\r\n";
  $subject = "Warning of Possible DoS Attack at $today:$min:$sec";
  

  //Warning Messages:
  $message1='<font color="red">World GunZ is under heavy bandwidth usage or being DDOS attacked!</font><br>';
  $message2='Please wait ... ';
  $message3=' seconds or try again after some minutes from now.<br>';
  $message4='<font color="blue">Protected by DDOS Shield.</font><br>If you are a human, change IP.<br>We temporarily banned this IP <b>'.$_SERVER["REMOTE_ADDR"].' </b>from DoS attack.';
  $message5= 'World GunZ under heavy bandwidth usage or being DDOS attacked! By this IP address: '.$_SERVER["REMOTE_ADDR"];
  $message6='<br><img src="userlogs/cross.gif" alt="" border="0">'; 
//---------------------- End of Initialization ---------------------------------------  

  //Get file time:
  $ipfile=substr(md5($_SERVER["REMOTE_ADDR"]),-3);  // -3 means 4096 possible files
  $oldtime=0;
  if (file_exists($iplogdir.$ipfile)) $oldtime=filemtime($iplogdir.$ipfile);

  //Update times:
  $time=time();
  if ($oldtime<$time) $oldtime=$time;
  $newtime=$oldtime+$itime;

  //     Check human or bot:
  if ($newtime>=$time+$itime*$imaxvisit)
  {
    //     To block visitor:
    touch($iplogdir.$ipfile,$time+$itime*($imaxvisit-1)+$ipenalty);
    header("HTTP/1.0 503 Service Temporarily Unavailable");
    header("Connection: close");
    header("Content-Type: text/html");
    echo '<html><head><title>World GunZ DDOS Shield</title></head><body><p align="center"><strong>'
          .$message1.'</strong>'.$br;
    echo $message2.$ipenalty.$message3.$message4.$message6.'</p></body></html>'.$crlf;
   //     Mailing Warning Message to the Site Administrator
     {
	@mail($to, $subject, $message5, $headers);	
     }
    //     logging:
    $fp=@fopen($iplogdir.$iplogfile,"a");
    if ($fp!==FALSE)
    {
      $useragent='<unknown user agent>';
      if (isset($_SERVER["HTTP_USER_AGENT"])) $useragent=$_SERVER["HTTP_USER_AGENT"];
      @fputs($fp,$_SERVER["REMOTE_ADDR"].' on '.date("D, d M Y, H:i:s").' as '.$useragent.$crlf);
    }
    @fclose($fp);
    exit();

  }

  //Modify file time:
  touch($iplogdir.$ipfile,$newtime);

?>