<?

@session_start();

//MSSQL Server configuration

$_MSSQL[Host]               = "TU-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "PASS";
$_MSSQL[DBNa]               = "DB";

$r = mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mssql_select_db($_MSSQL[DBNa], $r);

//MySQL Server configuration

$_MYSQL[Host]               = "localhost";
$_MYSQL[User]               = "root";
$_MYSQL[Pass]               = "pasword";
$_MYSQL[DBNa]               = "foro";

//Configuration

$_CONFIG[NewsFID]           = 2;
$_CONFIG[EventsFID]         = 0;
$_CONFIG[vBulletinPrefix]   = "xxxxx";
$_CONFIG[ForumURL]          = "http://xxx.tk/";

//Offline page
$_CONFIG[OfflinePage]       = "";

$path['root'] = 'firma/';
$path['emblems'] = 'clan/emblema/';

// Gunz Database Configuration
$_CONFIG[LoginTable]    = "Login";
$_CONFIG[CharTable]     = "Character";
$_CONFIG[ClanTable]    = "Clan";
$_CONFIG[ClanmemberTable]    = "ClanMember";
$color[255] = array(255,153,51); // Administrator
$color[254] = array(255,153,51); // Developer/Gamemaster
$color[253] = array(255,255,255); // Banned
$color[252] = array(255,153,51); // Hidden GM
$color[2]   = array(0,68,255); // User With Jjang
$color[0]   = array(255,255,255); // Normal User

$table['account']    = 'dbo.Account';
$table['character']  = 'dbo.Character';
$table['clanmember'] = 'dbo.ClanMember';
$table['clan']       = 'dbo.Clan';

?>