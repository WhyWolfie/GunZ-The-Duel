
  <div id='boxxing'>
   <ul>
     <li>Splat Gunz - Chat Online </li>
   </ul> 

   <p>&nbsp;</p>
 <table width="612" align="center"  cellpadding="2" cellspacing="5"  style="border: 1px solid #279B61" class="hover">
  <tr>
	<th align="center" bgcolor="#f90" ><p>Chat - Splat Gunz Oficial </p>
	  <p>
	    <embed wmode="transparent" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="540" height="405" name="chat" FlashVars="id=165301289&rl=Brazilian" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" />                
	      <br>	  
	      <br>
	    
          </p></th>
  </tr>
</table>
<p>&nbsp;</p>
  </div>