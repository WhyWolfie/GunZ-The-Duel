<style type="text/css">
<!--
.style1 {color: #000000}
-->
</style>

  <div id='boxxing'>
   <ul><li>Download</li></ul> 

  <table width="612" align="center" bgcolor="000" cellpadding="2" cellspacing="5" style="border: 1px solid #279B61" class="hover">
	<tr>
	  <th width="186" align="center" bgcolor="#cccccc"><span class="style1">Nome do Arquivo</span></th>
	  <th width="186" align="center" bgcolor="#cccccc"><span class="style1">Descri&ccedil;&atilde;o do Arquivo</span></th>
	  <th width="164" align="center" bgcolor="#cccccc"><span class="style1">Tamanho do Arquivo</span></th>
	  <th width="240" align="center" bgcolor="#cccccc"><span class="style1">Link do Arquivo</span></th>
	</tr>

	<tr>
	  <td align="center" bgcolor="<?php echo $cor; ?>" ><font color="#FFFFFF">SplatGunz-Install</font></td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><font color="#FFFFFF">Splat Gunz Client Beta </font> </td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><font color="#FFFFFF">320 MB </font></td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><a href="http://www.multiupload.com" target="_blank">[Multiupload]</a></td>
	</tr>
	
  </table>
<p>&nbsp;</p>
 <ul>
<span class="top_ul">Requerimentos b&aacute;sicos</span>
</ul>
<table width="612" align="center"  cellpadding="2" cellspacing="5" bordercolor="#316AC5" class="hover"  style="border: 1px solid #279B61">
  <tr>
	<th align="center" bgcolor="#333333" >Tipo</th>
	<th align="center" bgcolor="#333333">M&iacute;nimo Requerido</th>
	<th align="center" bgcolor="#333333" >Recomendado</th>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">CPU</td>
	<td align="center" bgcolor="#333333">Pentium III - 700 MHz</td>
	<td align="center" bgcolor="#333333">Pentium IV - 2.0 GHz ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">RAM</td>
	<td align="center" bgcolor="#333333">256MB</td>
	<td align="center" bgcolor="#333333">512MB ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">Sistema Operacional</td>
	<td align="center" bgcolor="#333333">Win9x</td>
	<td align="center" bgcolor="#333333">Win2000/XP</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">VGA</td>
	<td align="center" bgcolor="#333333">32MB</td>
	<td align="center" bgcolor="#333333">128MB ou superior</td>
  </tr>
  <tr>
	<td height="19" align="center" bgcolor="#333333">Conex&atilde;o</td>
	<td align="center" bgcolor="#333333">56k</td>
	<td align="center" bgcolor="#333333">Banda larga ou superior</td>
  </tr>
</table>
<p>&nbsp;</p>
  </div>