<?

if( $_SESSION['AID'] == "" )
{
msgBox("Esta Pagina � s� para Us�arios Logado, Logue-se para acessa esta pagina.","index.php?do=login");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " WGCoins";
        document.donation.item_number.value = coins;
    }

</script>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">

</head>
<style type="text/css">
<!--
.style14 {color: #FFFFFF}
-->
    </style>
	  <div id='boxxing'>
   <ul><li>Doa��o</li></ul> 

	<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">&nbsp;</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div align="center">
                                              <table width="432" border="0">
                                                <tr>
                                                  <td colspan="3"><em><b>Buy SG Coins by PayPal </b></em></td>
                                                </tr>
                                                <tr>
                                                  <td width="59" rowspan="2"><img src="images/pay_2.gif" width="91" height="89" /></td>
                                                  <td width="357"> <p>O servi&ccedil;o de pagamentos PayPal &eacute; amplamente reconhecida pela sua r&aacute;pida e segura.&nbsp;PayPal oferece-lhe a utiliza&ccedil;&atilde;o das empresas mais populares para suas transa&ccedil;&otilde;es de cart&atilde;o de cr&eacute;dito.</p>
                                                    <p><br />
                                                    <strong>scolha um dos nossos diversos planos de pagamento abaixo:</strong> </p></td>
                                                </tr>
                                                <tr>
                                                  <td>                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <input type="hidden" name="cmd" value="_xclick" />
                                                <input type="hidden" name="business" value="viniciusgp@live.com" />
                                                <input type="hidden" name="lc" value="US">
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="no_note" value="1" />
                                                <input type="hidden" name="no_shipping" value="1" />
                                                <input type="hidden" name="tax" value="0.50" />
                                                <input type="hidden" name="bn" value="PP-BuyNowBF" />
                                                <input type="hidden" name="return" value="http://night-gamerz.sytes.net/index.php?rg=ipn" />
                                                <input type="hidden" name="cancel_return" value="http://night-gamerz.sytes.net" />
                                                <input type="hidden" name="notify_url" value="http://night-gamerz.sytes.net/index.php?rg=ipn" />
                                                <input type="hidden" name="rm" value="2" />

                                                Donate:&nbsp;
                                                <select name="amount" onChange="updateForm();" class="Login">
                                                    <option value="10.00">10 Reais</option>
                                                    <option value="20.00">20 Reais</option>
                                                    <option value="30.00">30 Reais</option>
                                                    <option value="40.00">40 Reais</option>
                                                    <option value="50.00">50 Reais</option>
                                                </select>
                                                <br />
10 Reais 110 SG Coins + 20 EvCoins
<p>20 Reais 220 SG Coins + 40 EvCoins</p>
<p>30 Reais 350 SG Coins + 60 EvCoins</p>
<p>40 Reais 500 SG Coins + 80 EvCoins</p>
<p>50 Reais 650 SG Coins + 100 EvCoins

                                                <input type="hidden" name="item_name" value="SGCoins">
                                                <input type="hidden" name="item_number" value="5">
                                                <input type="hidden" name="custom" value="<?php echo $_SESSION['AID']; ?>">
                                                <script type="text/javascript">
                                                    updateForm();
                                                </script>
                                                <br /><br />
                                                  <input name="submit" type="submit" id="submit" value="Compra SG Coins">
                                                </form></td>
                                                </tr>
                                              </table>
											  </div>
											  <div align="center"></div>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											  <p align="left"><strong>Como comprar Cash?</strong><br>
											    Usando o PagSeguro voc&ecirc; poder&aacute; fazer pagamentos r&aacute;pidos e de forma f&aacute;cil.<br>
											    O pagamento pode ser feito atrav&eacute;s de Boleto, Transfer&ecirc;ncia Banc&aacute;ria, Cart&atilde;o de Cr&eacute;dito ou Transfer&ecirc;ncia de Saldo, o PagSeguro &eacute; uma &oacute;tima op&ccedil;&atilde;o, e seus cr&eacute;ditos chegaram r&aacute;pido, sem necessidade de confirmar nada, apenas Escolha o plano desejado e clique em comprar..</p>
											  <p align="left"><strong>Cash ... O que &eacute;? E por que precisamos dela?</strong><br>
											    O Cash &eacute; voluntariamente, sem contrapartida de retorno. Ele est&aacute; aqui para nos ajudar a pagar as contas mensais de nossos servidores. Sem elas e sem seu apoio, n&oacute;s n&atilde;o ser&iacute;amos capazes de ter recursos para pagar as contas, mensalmente, e nosso servidor n&atilde;o estaria aqui, ou pelo menos, n&atilde;o seria t&atilde;o popular e bem sucedido, pois n&oacute;s n&atilde;o poderiamos ter um servidor capaz de suportar muitos jogadores sem quedas e lags.</p>
											  <p align="left"><strong>Acordo de compra de Cash&nbsp;<br>
											    </strong>Ao enviar um donativo para o Splat GunZ, voc&ecirc; concorda que n&atilde;o t&ecirc;m direito a receber qualquer coisa de n&oacute;s, por&eacute;m, uma recompensa ser&aacute; dada &agrave; aqueles que doam como um agradecimento por seu apoio cont&iacute;nuo. Esta forma de doa&ccedil;&atilde;o &eacute; completamente volunt&aacute;ria, como explicado anteriormente, e &eacute; usada para melhorar nosso servidor.</p>
											  <p align="left"><strong>Ao fazer uma doa&ccedil;&atilde;o voc&ecirc; concorda com os termos apresentados nas declara&ccedil;&otilde;es seguintes:</strong><br>
											      <em>1. Voc&ecirc; n&atilde;o vai tentar recuperar o sua compra abrindo disputa.<br>
											        2. Voc&ecirc; entende que se trata de uma compra volunt&aacute;ria e n&atilde;o &eacute; reembols&aacute;vel ou discut&iacute;vel, em qualquer momento ou por qualquer motivo.<br>
											        3. Qualquer tentativa de fraude ao sistema de doa&ccedil;&atilde;o vai levar a remo&ccedil;&atilde;o permanente de sua conta de nossa rede.<br>
											        4. Ser um doador n&atilde;o lhe d&aacute; nenhum privil&eacute;gio. Voc&ecirc; ser&aacute; amea&ccedil;a, tal como qualquer outro jogador.<br>
											        5. Se seus itens em resposta a uma doa&ccedil;&atilde;o foi roubado / perdido / extraviado / sumiu /entre outros, n&atilde;o seremos respons&aacute;veis por sua recupera&ccedil;&atilde;o.<br>
											        6. Se voc&ecirc; n&atilde;o concordar com esses termos, n&atilde;o nos envie uma doa&ccedil;&atilde;o. Ao enviar uma doa&ccedil;&atilde;o, voc&ecirc; concorda com este acordo.</em><br>
										      </p>
											  <p align="left">Depois de ter lido, entendido e concordado com o nosso acordo, voc&ecirc; pode enviar a sua doa&ccedil;&atilde;o. Clique no bot&atilde;o "COMPRAR" abaixo para doar.<br>
											    Selecione a forma de pagamento que mais lhe agrada .</p>
											  <p align="left">PagSeguro</p>
											<p align="left">SG Coins: 110 + 20 EvCoins ~&gt; Valor: R$10,00 <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                            <form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" method="post">
                                              <div align="left">
  <input type="hidden" name="email_cobranca" value="viniciusgp@live.com" />
  <input type="hidden" name="tipo" value="CP" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id_1" value="1" />
  <input type="hidden" name="item_descr_1" value="SG Coins 110" />
  <input type="hidden" name="item_quant_1" value="1" />
  <input type="hidden" name="item_valor_1" value="1000" />
  <input type="hidden" name="item_frete_1" value="000" />
  <input type="image" src="images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
                                              </div>
                                            </form>
                                            <div align="left">
                                              <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                              <br>
                                              SG Coins: 220 + 40 EvCoins ~&gt; Valor: R$20,00
                                              <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                            </div>
                                            <form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" method="post">
                                              <div align="left">
  <input type="hidden" name="email_cobranca" value="viniciusgp@live.com" />
  <input type="hidden" name="tipo" value="CP" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id_1" value="1" />
  <input type="hidden" name="item_descr_1" value="SG Coins 220" />
  <input type="hidden" name="item_quant_1" value="1" />
  <input type="hidden" name="item_valor_1" value="2000" />
  <input type="hidden" name="item_frete_1" value="000" />
  <input type="image" src="images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
                                              </div>
                                            </form>
                                            <div align="left">
                                              <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                              <br>
                                              SG Coins: 350 + 60 EvCoins ~&gt; Valor: R$30,00
                                              <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                            </div>
                                            <form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" method="post">
                                              <div align="left">
  <input type="hidden" name="email_cobranca" value="viniciusgp@live.com" />
  <input type="hidden" name="tipo" value="CP" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id_1" value="1" />
  <input type="hidden" name="item_descr_1" value="SG Coins 350" />
  <input type="hidden" name="item_quant_1" value="1" />
  <input type="hidden" name="item_valor_1" value="3000" />
  <input type="hidden" name="item_frete_1" value="000" />
  <input type="image" src="images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
                                              </div>
                                            </form>
                                              
                                              <div align="left">
                                                <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                                <br>
                                                SG Coins: 500 + 80 EvCoins ~&gt; Valor: R$40,00
                                                <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                                </div>
                                              <form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" method="post">
                                                  <div align="left">
  <input type="hidden" name="email_cobranca" value="viniciusgp@live.com" />
  <input type="hidden" name="tipo" value="CP" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id_1" value="1" />
  <input type="hidden" name="item_descr_1" value="SG Coins 500" />
  <input type="hidden" name="item_quant_1" value="1" />
  <input type="hidden" name="item_valor_1" value="4000" />
  <input type="hidden" name="item_frete_1" value="000" />
  <input type="image" src="images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
                                                  </div>
                                              </form>
                                                <div align="left">
                                                  <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                                  <br>
                                                  SG Coins: 650 + 100 EvCoins ~&gt; Valor: R$50,00
                                                  <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                                  </div>
                                              <form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/checkout.jhtml" method="post">
                                                  <div align="left">
  <input type="hidden" name="email_cobranca" value="viniciusgp@live.com" />
  <input type="hidden" name="tipo" value="CP" />
  <input type="hidden" name="moeda" value="BRL" />
  <input type="hidden" name="item_id_1" value="1" />
  <input type="hidden" name="item_descr_1" value="SG Coins 650" />
  <input type="hidden" name="item_quant_1" value="1" />
  <input type="hidden" name="item_valor_1" value="5000" />
  <input type="hidden" name="item_frete_1" value="000" />
  <input type="image" src="images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
                                                  </div>
                                              </form>
                                                <div align="left">
                                                  <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                                  </p>
                                                    </div>
                                                <p><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
                                            <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
&nbsp;                                            </p>
                                            <p align="left"><strong>Recebendo seus Cash&nbsp;</strong><br>
                                              Ap&oacute;s realizar a doa&ccedil;&atilde;o, envie um e-mail para&nbsp;<strong>phuma@live.com</strong>&nbsp;com os dados da transa&ccedil;&atilde;o, e o tanto de coins a serem inseridas da seguinte maneira:</p>
                                            <br>
                                            <table width="400" align="center">
                                              <tbody>
                                                <tr>
                                                  <td><strong>Assunto:</strong></td>
                                                  <td>Doa&ccedil;&atilde;o Splat GunZ </td>
                                                </tr>
                                                <tr>
                                                  <td><strong>Us&uacute;ario:</strong></td>
                                                  <td>--------</td>
                                                </tr>
                                                <tr>
                                                  <td><strong>Quantia depositada:</strong></td>
                                                  <td>R$ ----</td>
                                                </tr>
                                                <tr>
                                                  <td><strong>Data e hor&aacute;rio do dep&oacute;sito:</strong></td>
                                                  <td>dd/mm/aaaa, hh/mm.</td>
                                                </tr>
                                                <tr>
                                                  <td><strong>Dados da transa&ccedil;&atilde;o ou Imagem do recibo Scaneada:</strong></td>
                                                  <td>--------</td>
                                                </tr>
                                              </tbody>
                                            </table>
                                            </center></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	