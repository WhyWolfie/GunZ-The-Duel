<?

if( $_SESSION['AID'] == "" )
{
msgBox("Esta Pagina � s� para Us�arios Logado, Logue-se para acessa esta pagina.","index.php?do=login");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<style type="text/css">
<!--
body {
	background-color: #333333;
}
.style4 {color: #CCCCCC}
.style5 {color: #FFFFFF}
-->
</style>

  <div id='boxxing'>
   <ul>
     <li>Equipe Splat Gunz </li>
   </ul> 

   <p>&nbsp;</p>
   <div align="center">
     <table width="600" border="0">
       <tr>
         <td><div align="center"><span style="text-shadow: 1px 1px 3px #FF6600;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Administradores</b></span></span></div></td>
       </tr>
       <tr>
         <td height="22"><div align="center"><font color="#FFFFFF">Phuma - Fundador Geral </font></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style4">#</div></td>
       </tr>
       <tr>
         <td><div align="center"><span style="text-shadow: 1px 1px 3px #FFF000;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Cordenador</b></span></span></div></td>
       </tr>
       <tr>
         <td><div align="center">Hotmail</div></td>
       </tr>
       
       
       <tr>
         <td>        </td>
       </tr>
       <tr>
         <td> <div align="center"><span style="text-shadow: 1px 1px 3px #0099FF;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b> Games Master</b></span></span></div></td>
       </tr>
       
       <tr>
         <td><div align="center"><font color="#FFFFFF">Lucas - GM Lider </font></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style4">#</div></td>
       </tr>
       <tr>
         <td><div align="center" class="style5">#</div></td>
       </tr>
       <tr>
         <td><div align="center" class="style5">#</div></td>
       </tr>
       <tr>
         <td><div align="center"><span style="text-shadow: 1px 1px 3px #009900;"><span style=" background: transparent url(http://tinyurl.com/outgum);color:#FFFFFF;"><b>Moderadores </b></span></span></div></td>
       </tr>
       <tr>
         <td><div align="center" class="style5">ReiDiogo</div></td>
       </tr>
        </table>
   </div>
   <p>&nbsp;</p>
  </div>