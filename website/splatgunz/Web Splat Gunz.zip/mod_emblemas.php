<!-- INICIO SCRIPT CONTEUDO -->
<h1>Cl� Emblema!</h1>
<br>
<ul>
<? 
if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
require_once "sec.php";
$action = anti_injection($_GET['act']);
$step = anti_injection($_GET['step']);
$step = $_GET['step'];
if($step == "")
{
	$step = 1;
}
if ($step == '1') 
{
?>
<FORM METHOD=POST ACTION="?do=emblemas&step=2">
<br />
<br />
<p><font color="#FFFFFF">Etapa 1/3</font></p>
<p>
<font color="#FFFFFF">Usu�rio:</font> <input name="user" type="textfield" maxlength="14"/><p>

<font color="#FFFFFF">Senha:</font> <input name="pass" type="password" maxlength="14" />
<p>
<input type="submit" value="Proximo ->" />
<br />
</form>

<?
}
if ($step == "2") 
{

	$user1 = anti_injection($_POST['user']);
	$pass1 = anti_injection($_POST['pass']);
    if (valida(Array($user1,$pass1)) == TRUE)
	{
		$query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");

		if (mssql_num_rows($query) < 1)
		{
			echo "<br>login ou senha incorretos!";
		}
		else
		{
			$query2 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
			if (mssql_num_rows($query2) >= '1')
			{ 
			?>
<form enctype="multipart/form-data" action="?do=emblemas&step=done" method="POST">
					<p><br />
                                        <p><font color="#FFFFFF">Etapa 2/3</font></p>
					 <p><font color="#FFFFFF">Por favor insira o emblema:</font> </p>
						<input name="uploaded" type="file" />
    </p>
					<p>
					  <select name="clan">
					    
					    	<? 
						for($i=''; $i < @mssql_num_rows($query2); $i++)
						{
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
						?>
						<option value="<?=$row[4]?>"><?=$row[4]?></option>
                        			<?
						}
						?>
				      </select>
                      <br />
    </p>
					<p><font color="#FFFFFF">Voc� pode fazer upload de imagens 64x64 at� 60kb.</font></p><br />
					  <br />
					  <input type="submit" value="Enviar" /><br />
					  <br />
    </p>
</form>
			<? 
			}
			else 
			{ 
				echo "<p>Voc� n�o � o L�der do Clan</p>";
			} 
		}
	}
}

if ($step == "done") 
{ 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = anti_injection($_POST['clan']);
	$target = "upload/";
	$target = $target . basename( $_FILES['uploaded']['name']) ;
        $target22 = "upload/";
        $target22 = $target22 . basename( $_FILES['uploaded']['name']) ;
	$ok=1;


	$partes = pathinfo( $_FILES['uploaded']['name'] );
	$extensao = $partes['extension'];

	$extensoes = array('jpg', 'jpeg', 'png', 'gif');

	if($_FILES['uploaded']['size']  > "60720")
	{
		$err .= "A imagem � muito larga.<br>";
		$ok = 0;
	}

	if( !in_array(strtolower($extensao), $extensoes) )
	{
		$err .= "<p>Formato de imagem n�o aceita.</p><br>";
		$ok = 0;
	}

	
	if ($ok == 0)
	{
		echo "<p>Desculpe, sua imagem n�o foi aceita.<br />Verifique os erros:</p><br /><br />";
		echo "$err";
	}
	else
	{
		if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
			{
				echo "<p>Seu emblema foi inserido com sucesso.</p><br />";
				mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
				mssql_query("UPDATE Clan SET EmblemUrl = '".$target22."' WHERE Name = '$CLID'");
			}
			else
			{
				echo "<p>Desculpe, ocorreu um problema, tente novamente.</p>";
			}
	}
}
}
?>
</font>	
</ul>

<!-- FIM SCRIPT CONTEUDO -->
</div>		
