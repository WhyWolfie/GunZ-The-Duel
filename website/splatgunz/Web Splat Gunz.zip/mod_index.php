<?
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
?>
<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<style type="text/css">
<!--
.style10 {color: #FF9900}
-->
</style>



<div id='boxxing'>
   <ul><li>Ultimas Noticias</li></ul> 
			<table border="0" style="border-collapse: collapse" width="100%" height="100%" id="table2">
								<tr>
								  <td align="center" background="images/mn_info.jpg" height="76" style="background-image: url(''); background-repeat: no-repeat; background-position: center top"><table border="0" width="553" style="border-collapse: collapse">
                                    <tr>
                                      <td width="547" background="images/cont_bg.png"><div align="center">
                                          <table border="0" style="border-collapse: collapse" width="535" height="100%">
                                            <tr>
                                              <td width="524">&nbsp;
                                                  <div align="center">
                                                    <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="525" height="151">
                                                      <tr>
                                                        <td width="261" height="24">Noticias</td>
                                                        <td width="10" height="24">&nbsp;</td>
                                                        <td width="231" height="24">Atualiza&ccedil;&oacute;es</td>
                                                      </tr>
                                                      <tr>
                                                        <td width="261" valign="top"><table border="0" style="border-collapse: collapse" width="261" height="92%">
                                                            <tr>
                                                              <td width="3">&nbsp;</td>
                                                              <td width="248" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"><font size="1" face="Verdana">&raquo;</font></span><font face="Verdana" size="1"><font color="#FFFFFF"> <a href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                              <?=$n['Title']?>
                                                                    </a></font></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                        <td width="10">&nbsp;</td>
                                                        <td width="231" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                                            <tr>
                                                              <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"> <font size="1" face="Verdana">&raquo;</font></span> <a href="index.php?do=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                      <?=$n['Title']?>
                                                                    </font></a></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                      </tr>
                                                    </table>
                                              </div></td>
                                              <td width="10">&nbsp;</td>
                                            </tr>
                                          </table>
                                      </div></td>
                                    </tr>
                                  </table></td>
								</tr>

				      <br>
					</div>
                    <div align="center"></div>
				  <p></td>
				</tr>
				<tr>
					<td width="481" valign="top">
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
						  </tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="5">&nbsp;</td>
											<td width="430">
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">
											&nbsp;<div align="center"></div>											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">&nbsp;											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
						  </tr>
						</table>
					    <br>
					</div></td>
              </tr>
			</table>
			  <?php include "mod_ultimositens.php" ?>
			  <? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>
