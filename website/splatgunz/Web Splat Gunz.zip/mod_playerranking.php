<?
$res = mssql_query_logged("SELECT TOP 10 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							
								<td>
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="43"><div align="center"><font color="#FFFFFF">Rank</font></div></td>
										<td width="102"><font color="#FFFFFF">Nome</font></td>
										<td width="34"><div align="center"><font color="#FFFFFF">Level</font></div></td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="43">&nbsp;</td>
										<td width="102"><center>No data</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
<td width="43"><div align="center"><b>
  <font color="#FF9900">
    <?=++$count ?>
    </font>
</b></div></td>
									  
<td width="102"><font color="#FFFFFF"><?=$clan['Name']?></font>
</td>

<td width="34">
		    <p align="center"><font color="#FFFFFF">
	        </font><font color="#FFFFFF">
	        <?=$clan['Level']?>
	        </font></td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="43">&nbsp;</td>
										<td width="102">&nbsp;</td>
										<td width="34">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"><a href="?do=players">Ver Mais</a></p>
							  </td>
							</tr>


</table>
<br>
