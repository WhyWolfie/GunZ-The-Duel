<?php
//Configura��o de Conex�o com GunzDB by Phuma.
$PhumaHost = mssql_connect("Tu-PC\SQLEXPRESS","sa","2asdn");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Configura��o de Conex�o com GunzDB by Phuma.
$PhumaHost = 'TU-PC\SQLEXPRESS'; //Host do SQL Server (Exemplo: PHUMA\SQL2005)
$PhumaLogin = 'sa'; //Seu Login do SQL Server 
$PhumaSenha = '27asdn'; //Sua Senha do SQL Server 
$PhumaGunzDB = 'GunzDB'; //Your GunZ DB 


?>