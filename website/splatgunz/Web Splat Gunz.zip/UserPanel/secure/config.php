<?php
$gunzname = "Zona Servers";  //Your Server Name

$_MSSQL['Host'] = "COMPUTADOR\SQLEXPRESS";
$_MSSQL['User'] = "sa";
$_MSSQL['Pass'] = "123456";
$_MSSQL['DB'] = "GunzDB";

$error1 = "Cant connect to database";
$error2 = "Cant find Database";

$con = mssql_connect($_MSSQL['Host'], $_MSSQL['User'], $_MSSQL['Pass']) or die($error1);
mssql_select_db($_MSSQL['DB']) or die($error2);
?>