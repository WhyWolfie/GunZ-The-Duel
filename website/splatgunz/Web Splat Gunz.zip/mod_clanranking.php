<? include "inject.php" ?>
<?
$res = mssql_query("SELECT TOP 5 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
							</tr>
							<tr>
								<td>
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>
										  Not Clan 
										  .
										</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4"><img src="<?=($clan['EmblemUrl'] == "") ? "no_emblem.png" : $clan['EmblemUrl']?>" width="25" height="25"></td>
										<td width="142"><font color="#FFFFFF">&nbsp;&nbsp;<?=$clan['Name']?></font></td>
										<td width="41">
										<p align="center"><b><font color="#FFFFFF"><?=number_format($clan['Point'],0,'','.');?></font></b></td>
									</tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table><p align="center"><a href="?do=clans">Ver Mais</a></p>
							  </td>
							</tr>

</table>