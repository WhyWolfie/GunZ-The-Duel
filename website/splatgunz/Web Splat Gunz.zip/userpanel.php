<table>
<tr>
   <td>
   <a href='index.php?page=editinfo'>Edit Info</a>
   </td><td>
   <div class='line'></div>
   </td><td>
   <a href='index.php?page=changepassword'>Change Password</a>
   </td><td>
   <div class='line'></div>
   </td><td>
   <a href='index.php?page=stats'>User Stats</a>
   </td><td>
   <div class='line'></div>
   </td><td>
   <a href='index.php?page=changesex'>Change Sex</a>
   </td><td>
   <div class='line'></div>
   </td><td>
   <a href='index.php?page=clan'>Delete Clan</a>
   </td><td>
   <div class='line'></div>
   </td><td>
   <a href='index.php?page=logout'>Logout</a>
   </td>    
</tr> 
</table>
</div>

";
}elseif($page == "changepassword"){
  include("inc/changepassword.php");
  Title("UserPanel &bull; Change Password");
}elseif($page == "stats"){
  include("inc/stats.php");
  Title("UserPanel &bull; User Stats");
}elseif($page == "changesex"){
  include("inc/changesex.php");
  Title("UserPanel &bull; Change Sex");
}elseif($page == "clan"){
  include("inc/clan.php");
  Title("UserPanel &bull; Delete Clan");
}elseif($page == "logout"){
  include("inc/logout.php");
  Title("UserPanel &bull; Logout");
}elseif($page == "editinfo"){
  include("inc/editinfo.php");
  Title("UserPanel &bull; Edit Info");
}
?> 
 </div>
</div>

<div id="table_footer"></div>
<div id="footer">
  <!-- Please to not remove credits -->
  Copyright &copy; 2011 <?php echo $gunzname; ?>  UserPanel &bull; Created By <a href="mailto:Z-e-w-a@hotmail.com">Rauno Leinasaar</a>
</div>
<?php
}else{
  include("inc/login.php");
}
?>
</body>
</html>