
<div id='box_01'>
 <ol>Painel de Controle</ol>
</div>
<div id='box_02'>
  <? include "mod_ILogin.php" ?>
</div>
<div id='box_03'></div>
<div id='box_01'>
 <ol><font color="#000000">Servidores</font></ol>
</div>

<div id='div'>
  <ul>
    <li><b>&nbsp;&raquo; Server Status:</b> 
      <font color="#FF0000">Offline</font>    </li>
    <li><b>&nbsp;&raquo; Jogadores Online:</b> 
      <?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo " <strong>$servercount";
    ?>
    </li>
    <li>&nbsp;&raquo; Total de Contas: 
      <? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>"; 

?>
    </li>
    <li>&nbsp;&raquo; Total de Characters: 
      <?php
 
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>";

?>
    </li>
    <li>&nbsp;&raquo; Total de Cl&atilde;s: <b>
      <?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>";

?>
    </b></li>
    <li>&nbsp;&raquo; Record Online: <? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<?=$b['PlayerCount']?></li>
  </ul>
</div>
<div id='box_03'></div>
<div id='box_01'>
 <ol><font color="#000000">Top Cl�s</font></ol>
</div>
<div id='box_02'>
  <ul>
	<li>
	  <? include "mod_clanranking.php" ?>
	</li>
  </ul>
</div>
<div id='box_03'></div>
<div id='box_01'>
 <ol><font color="#000000">Top Jogadores</font></ol>
</div>
<div id='box_02'>
  <ul><li>
    <? include "mod_playerranking.php" ?>
    <div align="center"></div>
	</li>
  </ul>
</div>