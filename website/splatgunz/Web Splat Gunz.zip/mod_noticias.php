<?
//Script desenvolvido por Gaspar ;D

$ID11 = $_GET['ID'];

$busca44 = mssql_query("SELECT Titulo, Noticia, autor FROM Noticias WHERE ID = '$ID11'");
$busca45 = mssql_fetch_row($busca44);
?>

<font size=2>
<?=$busca45[0]?> - Autor: <?=$busca45[2]?><br><br>
<?=$busca45[1]?>
</font>
