<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/adminpanel.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<center><a href="vc tem Cp?" target="_blank"><img src="images/btn_adminpanel.png" name="img4" border="0" id="img4" onMouseOver="FP_swapImg(1,1,/*id*/'img4',/*url*/'images/btn_adminpanel_hover.png')" onMouseOut="FP_swapImgRestore()"></a><br></br></center>
										<input type="radio" value="addecoin" checked name="do">Enviar EV Coins<br>
										<input type="radio" value="banuser" name="do">Ban User<br>
										<input type="radio" value="muteuser" name="do">Mute User<br>
										<input type="radio" value="ipbanuser" name="do">IP Ban User<br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Go" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
								</td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							