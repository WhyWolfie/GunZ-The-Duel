<?
//Script By:Gaspar ;D

if (!(isset($_POST['titulo'])))
{
?>
<form id="site_Login" name="site_Login" method="post" action="?do=addnoticia_222">
<input type="text" id="titulo" value="Titulo" class="log_field" size="16" name="titulo" value="" maxlength="50"><br>
<input type="text" id="noticia" value="Noticia" class="log_field" size="70" name="noticia" value="" maxlength="99999"><br><br>
<input type="submit" name="logar" value="Adicionar!" />
</form>
<?
}else{

$login22 = $_SESSION["login"];

$busca3 = mssql_query("SELECT PGradeID FROm Account WHERE UserID = '$AID'");
$busca4 = mssql_fetch_row($busca3);

if ($busca4[0] == 255){

$titulo = Filtrrar($_POST['titulo']);
$noticia = Filtrrar($_POST['noticia']);

$busca11 = mssql_query("SELECT ID FROM Noticias ORDER BY ID DESC");
$busca12 = mssql_fetch_row($busca11);

$Mais = $busca12[0] + 1;

mssql_query("INSERT INTO Noticias (ID, Titulo, Noticia, Autor) VALUES ('$Mais', '$titulo', '$noticia', '$login22')");
echo "Noticia adicionada com sucesso!<br>";

}else{
echo "Voce nao tem permissao para acessar esta area";
}
}
?>