<?
if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
if(isset($_POST['submit'])){
    $Titulo = clean($_POST['Titulo']);
    $Tipo = clean($_POST['Tipo']);
    $Texto = clean($_POST['Texto']);
    $Usuario = $_SESSION['UserID'];
    mssql_query_logged("INSERT INTO Suporte ([Tipo], [Usuario], [Data], [Texto], [Titulo])VALUES($Tipo, '$Usuario', GETdate(), '$Texto', '$Titulo')");
    msgbox("Suporte Enviado com sucesso","index.php?do=suporte");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" Tipo="Texto/css" href="images/style.css">
</head>

<div id='boxxing'>
   <ul><li>Suporte</li></ul>  

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">

							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=suporte"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="431" colspan="3">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="112" align="right">
											Titulo</td>
											<td width="4">&nbsp;
											</td>
											<td width="316">
											<input type="text" name="Titulo" size="40"></td>
										</tr>
                                                                                
										<tr>
											<td width="112" align="right">
											Tipo</td>
											<td width="4">&nbsp;
											</td>
											<td width="316">
											<select size="1" name="Tipo">
											<option selected value="1">Denuncia Jogador
											</option>
											<option value="2">Mensagem para staff
											</option>
											<option value="3">Comprar Coins
											</option>
											<option value="4">Pedidos
											</option>
											</select></td>
										</tr>

										<tr>
											<td width="112" align="right" valign="top">
											Texto</td>
											<td width="4">&nbsp;
											</td>
											<td width="316">
											<textarea rows="8" name="Texto" cols="35"></textarea>
										<font style='color: red'>Obs: Se voc� selecionar a op��o Comprar Coins apenas mande seu emai para n�is que entraremos em contato com voc�.</font></td>
                                                                                </tr>

										<tr>
											<td width="112">&nbsp;
											</td>
											<td width="4">&nbsp;
											</td>
											<td width="316">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="ENVIAR" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>

						</table>
					</div>
<?
}
}
?>