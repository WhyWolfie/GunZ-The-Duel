<?

if( $_SESSION['AID'] == "" )
{
msgBox("N�o � possivel ler informa��es do us�ario Logue-se Primeiro no Splat Gunz!","index.php?do=login");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
  <div id='boxxing'>
   <ul><li>Informa��es do usu�rio:</li></ul>
   
   

  <div id='boxxing'><font color="#FFFFFF"><?
//Informa��es do usu�rio. Coded By Gaspar


$query1 = mssql_query("SELECT Name, Age, RegDate, UGradeID, Sex FROM Account WHERE AID = '$AID'");
$query2 = mssql_fetch_row($query1);


echo "<left>";
echo "Nome: $query2[0] <br>";
echo "Idade: $query2[1] <br>";
echo "Sexo: $query2[4] <br>";
echo "Cadastrado em: $query2[2] <br>";

switch($query2[3]){
case 255: $rank = "<font color=#00FFFF>Administrador"; break;
case 254: $rank = "<font color=#00EE00>Game Master"; break;
case 253: $rank = "<font color=gray><strike>Banido"; break;
case 104: $rank = "<font color=gray>Chat Blocked"; break;
case 2: $rank = "<font color=yellow>Event Winner"; break;
case 0: $rank = "<font color=white>Player"; break;
}

echo "Ranking: $rank </font><br><br>";
echo "</center>";
?></font>