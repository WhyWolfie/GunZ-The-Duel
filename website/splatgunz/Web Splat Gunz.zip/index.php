<?php
include "config.php";
include "_functions.php";
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
include "title.php";
include 'antisql.php';
include 'inject.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sheep Gaming - Index</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />  
<!-- styles -->
<link href="modules/css/lightbox.css" rel="stylesheet" type="text/css" />
<link href="modules/css/css.css" rel="stylesheet" type="text/css" />
<link href="modules/css/sexyalertbox.css" rel="stylesheet" type="text/css" />
<link href="modules/js/dark.css" rel="stylesheet" type="text/css" />
<link href="modules/js/coda.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="imagens.css" /> 
<script language="JavaScript" src="imagens.js"></script>

<!-- jquery -->
<script type="text/javascript" src="modules/js/jquery.js"></script>  
<script type="text/javascript" src="modules/js/jquery.easing.1.3.js"></script>           
<script type="text/javascript" src="modules/js/sexyalertbox.v1.2.jquery.js"></script>
<script type="text/javascript" src="modules/js/sexy-tooltips.v1.1.jquery.js"></script> 
<script type="text/javascript" src="modules/js/jquery.lightbox-0.5.js"></script>
<script type="text/javascript" src="modules/js/tool2.js"></script>  
<script type="text/javascript" src="modules/js/ajax.js"></script>  


<style type="text/css">
<!--
body,td,th {
	color: #FFFFFF;
}
a:link {
	color: #FF9900;
}
a:visited {
	color: #FF9900;
}
a:hover {
	color: #FFCC00;
}
a:active {
	color: #FF6600;
}
-->
</style></head>
<body>
<div align='center'>
 <div id='menu'>
   <ul>
	 <li><a class="active" href="?">Inicio</a></li>
	 <li><a href="?do=registro">Criar Conta</a></li>
	 <li><a href='?do=download'>Baixar Jogo</a></li>
	 <li><a href='?do=ranking'>Ranking</a></li>
	 <li><a href='?do=doa��o'>Comprar Coins</a></li>
	 <li><a href='?do=extra'>Extras</a></li>
	 <li><a href="?do=equipe">STAFF</a></li>
	
   </ul>
 </div>
<div id='wrapper'>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<td valign='top' width="220px"><?php include('paginas/sidebar.php');?></td>
	<td valign='top' width="100%">
	  <div id='meio'>
	    <? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "mod_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
	  </div>	</td>
  </tr>
</table>
</div>
<div id='footer'>   
  <ol><br>
  <font size="+1">Sheep Gaming 2013 - Todos os Direitos Reservados.
  |  <a href="javascript: void('Gnee')" onClick="Sexy.alert('<h3>Programa&ccedil;&atilde;o by: Phuma - Vinicius!</h3>'); return false;"><font color="#FF9900">Powered by: Phuma</font></a> <font size="+2">  
</div>
</div>
</body>
</html>
<?php
    ob_end_flush();
?>


