<?php

class infos
		{
			public function pegar_classe($classe)
			{
								switch((int)$classe){
								case 0: $class = "Dark Wizard";
								break;
								case 1: $class = "Soul Master";
								break;
								case 2: $class = "Grand Master"; 
								break;
								case 3: $class = "Grand Master"; 
								break;
								case 16: $class = "Dark Knight"; 
								break;
								case 17: $class = "Blade Knight"; 
								break;
								case 18: $class = "Blade Master";
								break;
								case 19: $class = "Blade Master";
								break;
								case 32: $class = "Fairy Elf"; 
								break;
								case 33: $class = "Muse Elf";
								break;
								case 34: $class = "High Elf";
								break;
								case 35: $class = "High Elf";
								break;
								case 48: $class = "Magic Gladiator"; 
								break;
								case 49: $class = "Duel Master";
								break;
								case 50: $class = "Duel Master";
								break;
								case 64: $class = "Dark Lord"; 
								break;
								case 65: $class = "Lord Emperor";
								break;
								case 66: $class = "Lord Emperor";
								break;
								case 80: $class = "Summoner";
								break;
								case 81: $class = "Blood Summoner"; 
								break;
								case 82: $class = "Dimension Master"; 
								break;
								case 83: $class = "Dimension Master"; 
								break;
								case 96: $class = "Rage Fighter";
								break;
								case 98: $class = "Fist Master";  
								break;}    
										
		return $class;
			
			}
			
		   function pegar_mapa($mapa)
		{
			switch((int)$mapa){
				case 0: $mapa ="Lorencia";
								break;
								case 1: $mapa ="Dungeon";
								break;
								case 2: $mapa ="Davias";
								break;
								case 3: $mapa ="Noria";
								break;
								case 4: $mapa ="Losttower";
								break;
								case 6: $mapa ="Stadium";
								break;
								case 7: $mapa ="Atlans";
								break;
								case 8: $mapa ="Tarkan";
								break;
								case 10: $mapa ="Icarus";
								break;
								case 24: $mapa ="Kalima 1";
								break;
								case 25: $mapa ="Kalima 2";
								break;
								case 26: $mapa ="Kalima 3";
								break;
								case 27: $mapa ="Kalima 4";
								break;
								case 28: $mapa ="Kalima 5";
								break;
								case 29: $mapa ="Kalima 6";
								break;
								case 30: $mapa ="Valey of Loren";
								break;
								case 31: $mapa ="Land of Trial";
								break;
								case 33: $mapa ="Aida";
								break;
								case 34: $mapa ="CryWolf";
								break;
								case 37: $mapa ="KantruLand";
								break;
								case 38: $mapa ="KantruRuin";
								break;
								case 41: $mapa ="Barracks";
								break;
								case 42: $mapa ="Refuge";
								break;
								case 51: $mapa ="Elbeland";
								break;}
								return $mapa;
		}     
			
			function online_of($char)
			{
				
				switch($char){
				case 0: $sta = '<font color="#f00">Offline</font>';
				break;
				case 1: $sta = '<font color="#00FF00">Online</font>';
				break;}    
				return $sta;
			}
		   function pegar_vip($vip)
			{
				global $VIPS;
				switch((int)$vip){
				case 0: $vip = "Free";
				break;
				case 1: $vip = $VIPS["NOME"]["VIP1"];
				break;
				case 2: $vip = $VIPS["NOME"]["VIP2"];
				break;
				case 3: $vip = $VIPS["NOME"]["VIP3"];
				break;
				case 4: $vip = $VIPS["NOME"]["VIP4"];
				break;
				case 5: $vip = $VIPS["NOME"]["VIP5"];
				break;
				}
				return $vip;
			}
		   
		   function perfil($perfil)
		   {
				switch((int)$perfil){
				 case 0:  $perfil = '<font color="#f00">Desativado</font>';
				break;
				case 1:  $perfil = '<font color="#00FF00">Ativado</font>';
				break;}
				return $perfil;
		   } 
		   
		   function patente_gens($valor)
		   {
			global $conexao;
			$patente = $conexao->ExecuteReader("select ".TABELA_GRADUATION_GENS." as patente from MuOnline.dbo.".TABELA_SISTEMA_GENS." where ".COLUNA_NOME_SISTEMA_GENS."=?",$valor);   
		    $patente = $patente->fetchObject();  
        	switch($patente->patente)
				{
					case 14: $pat = "Soldado";
					break;
					case 13: $pat = "Sargento";
					break;
					case 12: $pat = "Tenente";
					break;
					case 11: $pat = "Oficial";
					break;
					case 10: $pat = "Guarda";
					break;
					case 9: $pat = "Guerreiro";
					break;
					case 8: $pat = "Guerreiro Superior";
					break;
					case 7: $pat = "Guerreiro Comandante";
					break;
					case 6: $pat = "Bar&atilde;o";
					break;
					case 5: $pat = "Visconde";
					break;
					case 4: $pat = "Conde";
					break;
					case 3: $pat = "Marqu&ecirc;s";
					break;
					case 2: $pat = "Duque";
					break;
					case 1: $pat = "Grande Duque";
					break;
					default: $pat = "Indefinido";
					break;
				}
			return $pat;
			
			
		   }
	   function pegar_familia($char)    	   
		 {
			global $conexao;
			$banchar = $conexao->ExecuteReader("select ".TABELA_FAMILIA_GENS." as Familia from MuOnline.dbo.".TABELA_SISTEMA_GENS." where ".COLUNA_NOME_SISTEMA_GENS."=?",$char);
			$banchar = $banchar->fetchObject();
            switch($banchar->Familia)
				{
					case NUMER_FAMILIA_VANERT: $Familia = "Vanert";
					break;
					case NUMERO_FAMILIA_DUPRIAN: $Familia = "Duprian";
					break;
					default: $Familia = "Desconhecido";
					break;
				}   
			return $Familia;				
		 }
	function pegar_status($ctl)
		{
			switch((int)$ctl)
				{
					case 0: $x =  "Player";
					break;
					case 1: $x =  "Banido";
					break;
					case NUMERO_PARA_ADM: $x =  '<font color="#f00">Administrador</font>';
					break;
					case NUMERO_PARA_GM: $x =  '<font color="blue">Game Master</font>';
					break;
					default: $x =  "Player";
					break;
				}
				return $x;
		}
		
	}



?>
