<?php 
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
class siege
{
	
	function castle()
	{
		global $conexao;
		$q1 = $conexao->ExecuteScalar("select owner_guild FROM MuOnline.dbo.mucastle_data");
		$g =  $conexao->ExecuteReader("select G_Mark from MuOnline.dbo.guild where G_Name=?",$q1);
        $g =  $g->fetchObject();
		echo "<div id='boxxing'>
			<ul>
			<li>Castle Siege</li></ul>
		<ol>
  <table width=\"90%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"10\">
	<div class=\"siege\">
	<div style=\"position:relative; top:49px; left:350px; width: 200px;\"><a href=\"?gne=guild_info&name=".$q1."\">".$q1."</a></div>
	 <div style=\"position:relative; top:65px; left:350px; width: 200px;\">".utf8_decode(CASTLE_SIEGE_PROXIMO_EVENTO)."</div>
	 </div> 
  </table>
</ol>
</div>";
	
	}
}
  ?>

