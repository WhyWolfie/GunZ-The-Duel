<?php 


function sendMail($login,$senha,$email,$id,$senhabau,$email)
{
	
require_once('class.phpmailer.php');

$mail = new PHPMailer();

$mail->IsSMTP(); 
$mail->SMTPAuth = true;
$mail->Host = constant("Host_smtp");
$mail->Port = constant("Port_smtp");

$mail->Username = constant("username_login");
$mail->Password = constant("username_password");;


$mail->From = email_form; 
$mail->FromName = utf8_decode(Nome_Email);

$mail->IsHTML(true);

$mail->Subject = "Recuperar Dados";
$mail->Body = "<html>
		<head>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
		<meta name=\"author\" content=\"".NAME."\" />
		</head>
	
		<body>
		<div align=\"center\">
		<div style=\"background: #fff; border: 7px solid #6c6c6c; padding: 1px; width: 500px;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500px\">
		<tr>
		<td colspan=\"2\">&nbsp;</td>
		</tr>
		<tr>
		<td colspan=\"2\" style=\"padding: 10px; font-family: Tahoma; font-size: 10px;\" align=\"left\"><strong>".NAME."</strong>,<br /><br />
		<strong>Login:</strong> $login<br /><br />
		<strong>Senha:</strong> $senha<br /><br />
		<strong>E-mail:</strong> $email<br />
		<strong>Id: </strong>$id<br /><br />
		<strong>Senha do Bau: </strong>$senhabau<br /><br />
		</tr>
		<tr>
		<td colspan=\"2\"><div style=\"padding: 1px; background-color: #eaeaea;\"></div></td>
		</tr>
		<tr>
		<td align=\"left\" style=\"padding: 5px; font-family: Tahoma; font-size: 10px;\">&copy; 20011 - ".NAME."</td>
		<td align=\"right\" style=\"padding: 5px; font-family: Tahoma; font-size: 10px;\">{$server}</td>
		</tr>
		</table>
		</div>
		</div>
		</body>
		</html>";
$mail->AddAddress(utf8_decode($email),$login);

if(!$mail->Send()){
		echo'<div class="error_q">Erro ao Enviar, Tente novamente mais Tarde.</div></p>';
	
	}else{
	echo '<div class="ok"><style="color:#333;">[&loz;]Senha Enviada Para o E-mail Cadastrado na Conta!</div>';        
		
	}
}


function sendMailCadastro($login,$host,$email)
{
	
require_once('class.phpmailer.php');

$mail = new PHPMailer();

$mail->IsSMTP(); 
$mail->SMTPAuth = true;
$mail->Host = constant("Host_smtp");
$mail->Port = constant("Port_smtp");

$mail->Username = constant("username_login");
$mail->Password = constant("username_password");;


$mail->From = email_form; 
$mail->FromName = utf8_decode(Nome_Email);

$mail->IsHTML(true);

$mail->Subject = utf8_decode("Ativação da Conta");
$mail->Body = utf8_decode("<html>
		<head>
		<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
		<meta name=\"author\" content=\"".NAME."\" />
		</head>
	
		<body>
		<div align=\"center\">
		<div style=\"background: #fff; border: 7px solid #6c6c6c; padding: 1px; width: 500px;\">
		<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"500px\">
		<tr>
		<td colspan=\"2\">&nbsp;</td>
		</tr>
		<tr>
		<td colspan=\"2\" style=\"padding: 10px; font-family: Tahoma; font-size: 10px;\" align=\"left\"><strong>".NAME."</strong>,<br /><br />
		Seu Cadastro Foi Realizado com Sucesso:
		<br>
		Login: ".$login."
		<br>
		------------------------------------------------
		<br>
		Instruções de ativação
		<br>
		------------------------------------------------
		<br>
		<br>

		Nós precisamos que você valide esta solicitação para nos comprovar que você foi quem realmente solicitou esta ação. Isto nos protege contra spam e uso malicioso.

		Para ativar sua conta simplesmente clique no link abaixo:
		<br>
		<br>

		<a href=\"".$host."\">".$host."</a>
		<br>
		<br>
		Caso você não consiga clicar no link, copie e cola em seu navegador.
		Caso você não tenha se cadastrado no servidor ".NAME.", desconsidere está mensagem.

		Obrigado.
		Tenha um bom jogo
		</tr>
		<tr>
		<td colspan=\"2\"><div style=\"padding: 1px; background-color: #eaeaea;\"></div></td>
		</tr>
		<tr>
		<td align=\"left\" style=\"padding: 5px; font-family: Tahoma; font-size: 10px;\">&copy; 20011 - ".NAME."</td>
		<td align=\"right\" style=\"padding: 5px; font-family: Tahoma; font-size: 10px;\">{$server}</td>
		</tr>
		</table>
		</div>
		</div>
		</body>
		</html>");
$mail->AddAddress(utf8_decode($email),$login);


if(!$mail->Send())
	{	
	}
	else
	{
	}
	
}

 ?>

