<?php
    
    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */
    
    /**
    * Classe utilizada para navega��o de dados MSSQL
    */
    class MssqlRecordset 
        extends IRecordset
    {
        
        /**
        * Constr�i o objeto
        * 
        * @param mixed $database
        * @param mixed $result
        * @return MssqlRecordset
        */
        public function __construct( &$database, $result )
        {
            parent::__construct ( $database, $result );
            $this->FieldCount = mssql_num_fields($result);
            for($i = 0; $i < $this->GetFieldCount(); $i++)
            {
                $this->Fields[] = mssql_field_name($result, $i);   
            }
            $this->RowCount = mssql_num_rows($result);
        }           
        
        /**
        * Retorna um objeto
        * @return mixed
        */
        public final function FetchObject()
        {
            $result = mssql_fetch_object($this->Result);
            if(!$result)
            {
                return false;
            }
            return $result;
        }
        
        /**
        * Retorna uma array numerica com os valores
        * @return mixed
        */
        public final function FetchRow()
        {
            $result = mssql_fetch_row($this->Result);
            if(!$result)
            {
                return false;
            }
            return $result;            
        }
        
        /**
        * Retorna uma array nomeada com os valores
        * @return mixed
        */
        public final function FetchAssoc()
        {
            $result = mssql_fetch_assoc($this->Result);
            if(!$result)
            {
                return false;
            }
            return $result;            
        }
        
        /**
        * Retorna uma array nomeada e enumerada com os valores
        * @return mixed
        */
        public final function FetchArray($mode = FetchMode::FM_ARRAY_BOTH)
        {
            $result = null;
            
            switch($mode) 
            {
            case FetchMode::FM_ARRAY_NUMERIC:
                $result = mssql_fetch_array($this->Result, MSSQL_NUM);
                break;
            case FetchMode::FM_ARRAY_ASSOCIATIVE:
                $result = mssql_fetch_array($this->Result, MSSQL_ASSOC);
                break;
            case FetchMode::FM_ARRAY_BOTH:
                $result = mssql_fetch_array($this->Result, MSSQL_BOTH);
                break;
            }
            
            if(!$result)
            {
                return false;
            }
            
            return $result;
                        
        }        
        
    }

?>