<?php

    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */

    /**
    * Classe de configura��o de conex�o MYSQL
    */
    class MysqlSettings 
        extends ISettings
    {
        
        /// Conex�o persistente
        protected $Persistent;
        
        /// Nova conex�o
        protected $NewLink;
        
        /**
        * Construtor do objeto
        * 
        * @param mixed $host
        * @param mixed $name
        * @param mixed $user
        * @param mixed $password
        * @param mixed $port
        * @param mixed $persistent
        * @param mixed $new
        * @return MssqlSettings
        */
        public function __construct($host = "127.0.0.1", $name = "", $user = "root", $password = "", $port = 3306, $persistent = false, $new = false)
        {
            $this->Persistent = $persistent;
            $this->NewLink = $new;
            parent::__construct($host, $name, $user, $password, $port);
        }
                            
        /**
        * Conex�o persistente?
        * 
        */
        public function IsPersistent()
        {
            return $this->Persistent;
        }
        
        /** 
        * Novo link?
        * 
        */
        public function IsNewLink()
        {
            return $this->NewLink;
        }
        
        /**
        * Muda aonex�o persistente
        * 
        * @return MssqlSettings  
        */
        public function SetPersistent($value)
        {
            $this->Persistent = $value;
            return $this;
        }
        
        /** 
        * Muda o novo link
        * 
        * @return MssqlSettings  
        */
        public function SetNewLink($value)
        {
            $this->NewLink = $value;
            return $this;
        }
        
    }
    
?>