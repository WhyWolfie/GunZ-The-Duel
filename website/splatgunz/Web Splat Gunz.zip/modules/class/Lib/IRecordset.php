<?php

    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */
    
    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */
    
    /**
    * M�todo de aplica��o
    */
    final class FetchMode
    {
        
        const FM_ARRAY_NUMERIC = 2;
        const FM_ARRAY_ASSOCIATIVE = 4;
        const FM_ARRAY_BOTH = 6;
        
        const FM_OBJECT = 1;
        const FM_ASSOCIATIVE = 0;
        
    }
    
    /**
    * Posi��o do cursor
    * @deprecated
    */
    final class CursorPosition
    {
        
        const CP_BEGIN = 1;
        const CP_END = 2;
        
    }
    
    /**
    * Classe utilizada para navega��o nos records da query
    */
    abstract class IRecordset
    {
        
        /// Resultado da query original (resource) 
        protected $Result = null;
        
        /// Refer�ncia para o banco de dados em que se est� sendo executado a query
        protected $Database = null;
        
        /// N�mero de Fields
        protected $FieldCount = 0;

        /// Nomes de cada campo
        protected $Fields = array();
        
        /// N�mero de linhas
        protected $RowCount = 0;
        
        /**
        * Retorna a quantidade de campos 
        * 
        * @return int
        */
        public function GetFieldCount()
        {
            return $this->FieldCount;
        }
        
        /**
        * Retorna os nomes dos campos
        * 
        * @return array
        */
        public function GetFields()
        {
            return $this->Fields;
        }
        
        /**
        * Retorna a quantidade de linhas retornadas
        * 
        * @return int
        */
        public function GetRowCount()
        {
            return $this->RowCount;
        }
        
        /**
        * Retorna o resource criado pela query
        * 
        * @return resource
        */
        public function GetRawResult()
        {
            return $this->Result;
        }
        
        /**
        * Constr�i o objeto
        * 
        * @param IDatabase &$database
        * @param mixed $res
        * @return IRecordset
        */
        public function __construct ( &$database, $res )
        {
            $this->Result = $res;
            $this->Database = $database;   
        }
        
        /**
        * Destr�i o objeto
        * 
        */
        public function __destruct()
        {
            $this->GetDatabase()->FreeResult($this->Result);            
        }
        
        
        /**
        * Retorna a refer�ncia para a conex�o com o banco de dados
        * @return IDatabase
        */
        public function GetDatabase()
        {
            return $this->Database;
        }
        
        /**
        * Retorna um objeto
        * @return mixed
        */
        public abstract function FetchObject();
        
        /**
        * Retorna uma array numerica com os valores
        * @return mixed
        */
        public abstract function FetchRow();
        
        /**
        * Retorna uma array nomeada com os valores
        * @return mixed
        */
        public abstract function FetchAssoc();
        
        /**
        * Retorna uma array nomeada e enumerada com os valores
        * @return mixed
        */
        public abstract function FetchArray();
        
    }
    
?>