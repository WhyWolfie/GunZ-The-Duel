<?php
    
    /*
    PHP5 Database Simplifier
    Copyright (C) 2009-2010  DarK TeaM Softwares

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    */

    /**
    * Programado por Wolf / Coded by Wolf
    * DarK TeaM Softwares
    * www.dtex.com.br
    * 
    * Mantenha os cr�ditos / Keep credits
    * 
    * �ltima revis�o / Last Revision: 
    * 31/12/2009 - 17:32:00 (GMT-3)
    */
    
    /**
    * Classe base para um objeto representante de uma conex�o a um banco de dados
    */
    abstract class IDatabase
    {
        
        /// Objeto de conex�o com o banco
        protected $Link = null;
        
        /// Configura��es do banco de dados
        protected $Settings = null;
        
        /// Quantidade de queries executada com sucesso
        protected $QuerySuccessCount = 0;
        
        /// Quantidade de queries executada com falha
        protected $QueryFailCount = 0;
        
        /**
        * Constr�i o objeto base (deve ser chamado no ::__construct())
        * 
        * @param IDbSettings $settings  Configura��es do banco de dados
        * @return IDatabase
        */
        public function __construct(ISettings $settings)        
        {
            $this->Link = null;
            $this->Settings = $settings;
        }
        
        /**
        * Retorna o Link da conex�o
        */
        public function GetConnection()
        {
            return $this->Link;
        }
        
        /**
        * Seta a conex�o
        * 
        * @param $con Conex�o
        */
        protected function SetConnection($con = null)
        {
            $this->Link = $con;            
        }
        
        /**
        * Incrementa a quantidade de queries com sucesso
        * 
        */
        protected function QuerySuccessIncrement()
        {
            $this->QuerySuccessCount++;
        }
        
        /**
        * Retorna a quantidade de queries executada com sucesso
        * 
        * @return int
        */
        public function GetQuerySuccessCount()
        {
            return $this->QuerySuccessCount;
        }
        
        /**
        * Incrementa a quantidade de queries com falha
        */
        protected function QueryFailIncrement()
        {
            $this->QueryFailCount++;
        }
        
        /**
        * Retorna a quantidade de queries executada com falha
        * 
        * @return int 
        */
        public function GetQueryFailCount()
        {
            return $this->QueryFailCount;
        }
        
        /**
        * Retorna a quantidade total de queries executada
        * 
        * @return int 
        */
        public function GetQueryCount()
        {
            return $this->GetQuerySuccessCount() + $this->GetQueryFailCount();
        }
        
        /**
        * Retorna TRUE caso o objeto esteja conectado a um banco de dados.
        * @return boolean
        */
        public abstract function IsConnected();
        
        /**
        * Conecta-se a um banco de dados
        * 
        * @param IDbSettings $settings  Configura��es (manter null caso ja esteja configurado)
        * @return boolean
        */
        public abstract function Connect(ISettings $settings = null);
        
        /**
        * Desconecta-se do banco de dados
        * @return void
        */
        public abstract function Disconnect();
        
        /**
        * Executa uma query
        * 
        * @param $str Comando
        * @return resource
        */
        protected abstract function Query($str);
        
        /**
        * Executa uma procedure no banco de dados
        * 
        * @param string $name   Nome da procedure
        * @return IRecordset
        */
        public abstract function ExecuteProcedureReader($name);
        
        /**
        * Executa uma procedure no banco de dados n�o retornando nada
        *                           
        * @param string $name
        * @return void
        */
        public abstract function ExecuteProcedureNonQuery($name);
        
        /**
        * Executa uma query e retorna um IRecordset no caso de sucesso, ou FALSE no caso de falha.
        * 
        * @param string $command    Comando a ser executado
        * @return IRecordset
        */
        public abstract function ExecuteReader($command); 
        
        /**
        * Executa uma query que n�o retornar� resultados. (Ex.: UPDATE ...)
        * 
        * @param string $command
        * @return void
        */
        public abstract function ExecuteNonQuery($command); 
        
        /**
        * Executa uma query na qual o valor retornado � o valor da primeira coluna e da primeira linha
        * 
        * @param string $command    Comando a ser executado
        * @return object
        */
        public abstract function ExecuteScalar($command);
        
        /**
        * Muda o banco de dados atual
        * 
        * @param string $name   Nome do banco de dados
        * @return boolean
        */
        public abstract function SelectDatabase($name);
        
        /**
        * Inicializa uma transa��o
        * 
        * @param $name  Nome da transa��o
        */
        public abstract function BeginTransaction($name = null);
        
        /**
        * Finaliza uma transa��o
        * 
        */
        public abstract function RollbackTransaction($name = null);
        
        /**
        * Salva uma transa��o
        * 
        */
        public abstract function CommitTransaction($name = null);
        
        /**
        * Libera um resultado de query
        * 
        * @param mixed $result
        */
        public abstract function FreeResult($result);
        
        /**
        * Retorna a descri��o do �ltimo erro ocorrido
        * @return string
        */
        public abstract function GetLastError();
        
        /**
        * Retorna a descri��o do �ltimo erro ocorrido
        * @return string 
        */
        public abstract function GetLastMessage();
        
        /**
        * Retorna o �ltimo id inserido no banco de dados (null em caso de falha)
        * 
        * @return int
        */
        public abstract function GetLastInsertedId();
        
        /**
        * Protege contra SQL-Injection
        * 
        * @param mixed $string String a ser protegida
        * @return string
        */
        public abstract function EscapeString($string);
        
        /**
        * Protege contra SQL-Injection
        * 
        * @param mixed $string String a ser protegida
        * @return string
        */
        public abstract function EscapeCharacter();
        
        /**
        * Faz o parse e prote��o dos argumenos
        * 
        * @param mixed $arguments
        * @param mixed $shiftcount
        * @return array
        */
        public final static function ParseArguments(IDatabase $class, $arguments, $shiftcount = 0)
        {
            
            $finalargs = array();
            
            if(sizeof($arguments) <= $shiftcount)
            {
                return $finalargs;
            }
            
            for($i = 0; $i < $shiftcount; $i++)
            {
                unset($arguments[$i]);
            }
            
            foreach($arguments as $argument_key => $argument)
            {
                
                $value = $argument;
                
                if(get_class($argument) == 'Argument')
                {
                    $value = $argument->GetValue();
                    switch($argument->GetType())
                    {
                    case ArgumentType::AT_NUMBER:
                        $value = str_replace($class->EscapeCharacter(), $class->EscapeCharacter() . $class->EscapeCharacter(), $value); 
                        break;
                    case ArgumentType::AT_BINARY:
                        $value = "0x" . strtoupper(bin2hex($value));
                        break;
                    case ArgumentType::AT_BINARY_FORMATTED:
                        if(ctype_xdigit($value))
                        {
                            $value = "0x" . $value;
                        }
                        else
                        {
                            throw new Exception("Argumento do tipo AT_BINARY_FORMATTED contem caracteres inv�lidos para execu��o.");
                        }
                        break;
                    case ArgumentType::AT_STRING:
                    default:
                        $value = $class->EscapeString($value);
                        break;
                    }
                }
                else
                {
                    if(is_string($value))
                    {
                        $value = $class->EscapeString($value);
                    }
                    else if(is_int($value))
                    {
                        $value = str_replace($class->EscapeCharacter(), $class->EscapeCharacter() . $class->EscapeCharacter(), $value); 
                    }
                    else
                    {
                        $value = $class->EscapeString($value);
                    }
                }
                
                $finalargs[] = $value;
                
            }
            
            return $finalargs;
            
        }
        
        /**
        * Formata a query para execu��o
        *         
        * @param mixed $query
        * @param mixed $arguments
        * @return mixed
        */
        public static function FormatQuery($query, $arguments)
        {
            if(sizeof($arguments) > 0)
            {
				$pos = 0;
                for($i = 0; $i < sizeof($arguments); $i++)
                {
                    $pos = strpos($query, '?', $pos);
                    if($pos === false)
                    {
                        break;
                    }
                    $query = substr_replace($query, $arguments[$i], $pos, 1);
					$pos = $pos += strlen($arguments[$i]);
                }
            }
            return $query;            
        }
        
    }

?>