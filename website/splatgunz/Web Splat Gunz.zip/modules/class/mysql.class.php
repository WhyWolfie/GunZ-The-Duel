<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
class myconexao {
	
	protected $cone;
	protected $db;
	
		function myconexao(){
		self::conectar();
		self::banco();
		}
	function conectar(){
		$this->cone = mysql_connect(IP_FORUM,LOGIN_FORUM,SENHA_FORUM);
		if($this->cone == false) {
		exit('Nao foi possivel conectar no Mysql');
		}
		}    
	function banco(){
		$this->db = mysql_select_db(BD_FORUM,$this->cone);
		if($this->db == false){
		exit('Nao foi possivel conectar ao DataBase');
		}
	}
	
}
?>