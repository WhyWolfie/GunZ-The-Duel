<?php 
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
class sorteio
{
	function mostrar_log()
		{
		echo '<h1>Vizualizar Logs</h1>
			</br>
			<table width="100%" border="0" cellspacing="2" cellpadding="0">
			  <tr style="background:#666; color:#FFF; font:12px Arial, Helvetica, sans-serif; font-weight:bold;">
				<td align="center">Login:</td>
				<td align="center">Nome:</td>
				<td align="center">Resets:</td>
				<td align="center">Master Resets:</td>
				<td align="center">Golds:</td>
				<td align="center">Vip:</td>
				<td align="center">DiasVip:</td>
				<td align="center">Dia:</td>
				<td align="center">hora:</td>
				  </tr>';
				$log = mssql_query("select nome,login,resets,golds,vip,diasvip,dia,hora,mr from GneeSite.dbo.gnee_log order by hora");
				while($linha = mssql_fetch_row($log))
				{
					$nome = $linha[1];
					$login = $linha[0];
					$resets = $linha[2];
					$gold = $linha[3];
					$diasvip = $linha[5];
					$dia = $linha[6];
					$hora = $linha[7];
					$mr = $linha[8];
					$i++;
						if($i % 2 ==0){$cor = 'style="background:#f4f4f4;"';}
							else{$cor = 'style="background:#e6fff2"';}

				echo "<tr ".$cor.">
				
				<td align=\"center\">".$nome."</td>
				<td align=\"center\">".$login."</td>
				<td align=\"center\">".$resets."</td>
				<td align=\"center\">".$mr."</td>
				<td align=\"center\">".$gold."</td>
				<td align=\"center\">".$info_char->pegar_vip($linha[4])."</td>
				<td align=\"center\">".$diasvip."</td>
				<td align=\"center\">".$dia."</td>
				<td align=\"center\">".$hora."</td>
			  </tr>";
	
			} 
		}
	function sortear_mr($codigo,$num,$online)
		{
			$today = @date("d.m.y");
			$today1 = @date("H:i:s");
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
				{
				    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
				}
			if(empty($num))
				{
				    return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar o Valor a Ser Sorteado!</div>';
				}
            if($num < 0)
				{
				    return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar um  Valor Possitivo!</div>';
				}    
			if(isset($online))
						{
							$q = mssql_query("SELECT character.name,memb_info.memb___id from character 
							INNER JOIN memb_info ON memb_info.memb___id = character.AccountID COLLATE database_default 
							INNER JOIN memb_stat on memb_stat.memb___id = memb_info.memb___id COLLATE database_default 
							WHERE memb_stat.ConnectStat = 1 ORDER BY newID()");
							$q2 = mssql_fetch_row($q);
							if($q2[0] == 0)
							{    
								return '<center><div class="error_q">[&loz;]Nenhuma Conta Online No Momento</div>';
							}
							else
							 {
							$add = mssql_query("update character set ".coluna_mr."=".coluna_mr."+".$num." where name='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora,mr) values ('$q2[0]','$q2[1]','0','0','0','0','$today','$today1','$num')");
							return '<center><div class="ok">[&loz;]</strong>O Char '.$q2[0].' foi Sorteado com '.$num.' Master Resets!</div>';
							}
						}
			if(!isset($online))
				{
				$q = mssql_query("select character.name,memb_info.memb___id from character
							INNER JOIN memb_info ON memb_info.memb___id = character.AccountID COLLATE database_default ORDER BY newID()");
							$q2 = mssql_fetch_row($q);
							$add = mssql_query("update character set ".coluna_mr."=".coluna_mr."+".$num." where name='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora,mr) values ('$q2[0]','$q2[1]','0','0','0','0','$today','$today1','$num')");
							return '<center><div class="ok">[&loz;]</strong>O Char '.$q2[0].' foi Sorteado com '.$num.' Master Resets!</div>';			
				}
		}
	
	function sorteio_reset($codigo,$num,$online)
		{
		  global $conexao;
		  $today = @date("d.m.y");
		  $today1 = @date("H:i:s");
		  if($_SESSION["captcha_site"] != $codigo)
			 {
				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			 }
		  if(empty($num))
			{
				return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar o Valor a Ser Sorteado!</div>';
			}
           if($num < 0)
        	 {
        	    return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar um  Valor Possitivo!</div>';
        	 }  
			if(isset($online))
			   {
					$q = mssql_query("SELECT character.name,memb_info.memb___id from character 
					INNER JOIN memb_info ON memb_info.memb___id = character.AccountID COLLATE database_default 
					INNER JOIN memb_stat on memb_stat.memb___id = memb_info.memb___id COLLATE database_default 
					WHERE memb_stat.ConnectStat = 1 ORDER BY newID()");
					$q2 = mssql_fetch_row($q);
					if($q2[0] == 0)
						{
							return '<center><div class="error_q">[&loz;]Nenhuma Conta Online No Momento</div>';
						}
					else 
						{
							$add = mssql_query("update character set ".coluna_reset."=".coluna_reset."+".$num." where name='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('$q2[0]','$q2[1]','$num','0','0','0','$today','$today1')");
							return '<center><div class="ok">[&loz;]</strong>O Char '.$q2[0].' foi Sorteado com '.$num.' Resets!</div>';
						}
			   }                
			if(!isset($online))
			{
				$q = mssql_query("select character.name,memb_info.memb___id from character
				INNER JOIN memb_info ON memb_info.memb___id = character.AccountID COLLATE database_default ORDER BY newID()");
				$q2 = mssql_fetch_row($q);
				$add = mssql_query("update character set ".coluna_reset."=".coluna_reset."+".$num." where name='".$q2[0]."'");
				$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('$q2[0]','$q2[1]','$num','0','0','0','$today','$today1')");
				return '<center><div class="ok">[&loz;]</strong>O Char '.$q2[0].' foi Sorteado com '.$num.' Resets!</div>';
		
			}
		}	
	function gold_sorteio($codigo,$num,$online)
		{
		 $today = @date("d.m.y");
		 $today1 = @date("H:i:s");
		  if($_SESSION["captcha_site"] != $codigo)
			 {
				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			 }
		  if(empty($num))
			{
				return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar o Valor a Ser Sorteado!</div>';
			}
          if($num < 0)
        	 {
        	    return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar um  Valor Possitivo!</div>';
        	 }   
			if(isset($online))
			{
				$log = mssql_query("select memb___id from memb_stat where ConnectStat >= 1 ORDER BY newID()");
				$log1 = mssql_fetch_row($log);
				if($log1 == 0)
					{
						return '<center><div class="error_q">[&loz;]</strong>N&atilde;o tem nenhuma conta conectada.</div>';
					}   
				$add = mssql_query("UPDATE ".tabela_gold." set ".gold_coluna."=".gold_coluna."+'".$num."' where ".gold_login."='".$log1[0]."'");
				$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora,mr) values ('','$log1[0]','0','$num','0','0','$today','$today1','')");
				return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$log1[0].'</strong> Sorteado com <strong>'.$num.'</strong> Golds.</div>';
			}
		 if(!isset($online))
			{
				$log = mssql_query("select memb___id from memb_info ORDER BY newID()");
				$log1 = mssql_fetch_row($log);
				$add = mssql_query("UPDATE ".tabela_gold." set ".gold_coluna."=".gold_coluna."+'".$num."' where ".gold_login."='".$log1[0]."'");
				$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora,mr) values ('','$log1[0]','0','$num','0','0','$today','$today1','')");
				return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$log1[0].'</strong> Sorteado com <strong>'.$num.'</strong> Golds.</div>';
			}   
		}
	function sorteio_vip($codigo,$vipa,$num,$online)
		{
			  global $conexao;	
			  global $VIPS;
			  if($_SESSION["captcha_site"] != $codigo)
    			 {
    				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
    			 }
			 $today = @date("d.m.y");
			 $today1 = @date("H:i:s");
			 switch($vipa)
				{
					case 0: $vipa2 = "Free";
					break;
					case 1: $vipa2 = $VIPS["NOME"]["VIP1"];
					break;
					case 2: $vipa2 = $VIPS["NOME"]["VIP2"];
					break;
					case 3: $vipa2 = $VIPS["NOME"]["VIP3"];
					break;
					case 4: $vipa2 = $VIPS["NOME"]["VIP4"];
					break;
					case 5: $vipa2 = $VIPS["NOME"]["VIP5"];
					break;
				}   
			 if(empty($num))
				{
					return '<center><div class="error_q">[&loz;]Por Favor Preencher Todos os Campos</div>';    
				}
             if($num < 0)
            	 {
            	    return '<center><div class="error_q">[&loz;]</strong> Por Favor Informar um  Valor Possitivo!</div>';
            	 }    
			 if(isset($online))
				{
			
					$q = mssql_query("select memb___id from memb_stat where ConnectStat >=1 ORDER BY newID()");
					$q2 = mssql_fetch_row($q);
					if($q2[0] == 0)
					{
						return '<center><div class="error_q">[&loz;]Nenhuma Conta Online No Momento</div>';
					}
					
					$vip = mssql_query("select ".vip." from ".tabela_vip." where ".vip_login."='".$q2[0]."'");
					$vip2 = mssql_fetch_row($vip);
					if($vip2[0] == 0)
						{
							$a = mssql_query("update ".tabela_vip." set ".vip."=".$vipa.",".DiasVip."=".$num." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de '.$vipa2.'.</div>';
						}
					if($vip2[0] < $vipa)
						{
							$a = mssql_query("update ".tabela_vip." set ".vip."=".$vipa.",".DiasVip."=".$num."+".DiasVip." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de '.$vipa2.'.</div>';
						}
					else
						{
							$a = mssql_query("update ".tabela_vip." set ".vip."=".$vipa.",".DiasVip."=".$num."+".DiasVip." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de '.$vipa2.'.</div>';
						}	 
			   }    	
			  if(!isset($online))
				{
					$q = mssql_query("select memb___id from memb_info ORDER BY newID()");
					$q2 = mssql_fetch_row($q);
					$vip = mssql_query("select ".vip." from ".tabela_vip." where ".vip_login."='".$q2[0]."'");
					$vip2 = mssql_fetch_row($vip);
					if($vip2[0] == 0)
						{
							$a = mssql_query("update ".tabela_vip." set ".vip."=".$vipa.",".DiasVip."=".$num." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de '.$vipa2.'.</div>';
						}
					elseif($vip2[0] > $vipa)
						{
							$a = mssql_query("update ".tabela_vip." set ".DiasVip."=".DiasVip."+".$num." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de Vip</div>';
						}
					else
						{
							$a = mssql_query("update ".tabela_vip." set ".vip."=".$vipa.",".DiasVip."=".DiasVip."+".$num." where ".vip_login."='".$q2[0]."'");
							$add2 = mssql_query("insert into gnee_log (nome,login,resets,golds,vip,diasvip,dia,hora) values ('','$q2[0]','0','0','$vipa','$num','$today','$today1')");    
							return '<center><div class="ok">[&loz;]</strong> Login <strong>'.$q2[0].'</strong> Sorteado com <strong>'.$num.'</strong> dias de '.$vipa2.'.</div>';                
						}
				
				}					
		}
} ?>                        