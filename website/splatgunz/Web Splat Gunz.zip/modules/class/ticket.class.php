<?php

class ticket extends funcao
{
	
	function user_enviar_coment($comentario,$id,$personagem)
	{
		global $conexao,$bbcode;
		$data = @date("d-m-Y");
		if(empty($comentario))
    		{
    	       	return  '<div class="error_q">[&loz;]Todos Os campos S&atilde;o Obrigatorios.</div>';
    		}
	   $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_ticket_resp (login,data,mensagem,id_outro,personagem) values (?,?,?,?,?)",$this->login,$data,$bbcode->arrumar_acentos_color($comentario),(int)$id,$personagem);    
	   $conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_ticket set status='1' where id=?",(int)$id);
							header("Location: ?gne=ver_ticket&id=".$id."");
	}
	function abrir_ticket($codigo,$char,$assunto,$mensagem,$foto)
		{
		 global $conexao,$bbcode;
		 $data = @date("ymd");
		 if($_SESSION["captcha_site"] != $codigo)
			{
		      	return  '<div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		  elseif(empty($mensagem))
			{            
				return  '<div class="error_q">[&loz;]Mensagem Em Branco.</div>';
			}
			$check_num = $conexao->ExecuteScalar("select count(*) from GneeSite.dbo.gnee_ticket where login=? and status !=3",$this->login);
		   
		   if($check_num >= MAX_TICKET) 
			{
				return  '<div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode ter mais doque '.MAX_TICKET.' Ticket(s) Aberto(s) ao mesmo Tempo.</div>';
			}
				
				$pasta = foto_denuncia;
				$foto;
				$permisao = array('image/jpg','image/jpeg','image/pjpeg','image/png');
				$type = $foto['type'];  
				$tmp = $foto['tmp_name'];
				$name = $foto['name'];                  	
			 if(!empty($name) && in_array($type,$permisao))
					{
					 $nome = md5(uniqid(rand(),true)).".jpg";
					 upload_jpg($tmp,$nome,800,600,$pasta); 
		          $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_ticket (assunto,mensagem,login,personagem,status,data,anexo) values (?,?,?,?,'0',?,?)",$bbcode->arrumar_acentos_color($assunto),$bbcode->arrumar_acentos_color($mensagem),$this->login,$char,$data,$nome);
			  header("Location: ?gne=ticket");
					}
			  else
					{
					   return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';
					}                                                    
		  }
	function enviar_resp_adm($comentario,$id)
		{
			global $conexao,$bbcode;
			$nome = $conexao->ExecuteScalar("select name from MuOnline.dbo.character where ctlcode > 1 and Accountid=?",$this->login);
			$data = @date("d-m-Y");
			if(empty($comentario))
				{
				     return '<div class="error_q">[&loz;]Todos Os campos S&atilde;o Obrigatorios.</div>';
				}
			$conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_ticket_resp (login,data,mensagem,id_outro,personagem)  values (?,?,?,?,?)",$this->login,$data,$bbcode->arrumar_acentos_color($comentario),(int)$id,$nome);    
			$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_ticket set status='2' where id=?",(int)$id);
							header("Location: ?gne=paineladm/ver_ticket&id=".$id."");
											
		}
	
	function deletar_ticket($id) 							  
		{
		   global $conexao;
		   $conexao->ExecuteNonQuery("DELETE FROM  GneeSite.dbo.gnee_ticket where id=?",(int)$id);
		$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_ticket_resp where id_outro=?",(int)$id);
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Ticket Deletado com Sucesso.</h1>'); });</script>"; 
			return "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/ticket\">";
		}   
	function rejeitar_ticket($id)
		{
			global $conexao;
			$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_ticket set status='3' where id=?",(int)$id);
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Ticket Rejeitado com Sucesso.</h1>'); });</script>"; 
			return "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/ticket\">";  
		}    
	function abrir_ticket_fechado($id)
		{
			global $conexao;
			$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_ticket set status='0' where id=?",(int)$id);  
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Ticket Aberto com Sucesso.</h1>'); });</script>"; 
			return "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/ticket\">";
		}	
		
}
?>        