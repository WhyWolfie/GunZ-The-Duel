<?php

class compra extends funcao
{
	function abrir_compra($banco,$em,$prod,$valor,$data,$envelopebb,$docbb,$ctritau,$docitau,$terminalcaixa,$doccaixa,$terminalbrad
		,$transbrad,$agtomadora,$nseq,$mensagem,$foto,$hora,$sant,$sant1)   
		{
		  global $conexao,$bbcode;  
		  $date = @date("Y-m-d");
          $pasta = foto_comprovante;
		  $foto;
		  $permisao = array('image/jpg','image/jpeg','image/pjpeg','image/png');
		  $type = $foto['type'];  
		  $tmp = $foto['tmp_name'];
		  $name = $foto['name'];
          $prod = "Golds";
		  if(empty($valor) || empty($date) || empty($hora))
			 {
			     return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos.</center>';
			 }
		  if($banco == "Bradesco")
		   {
				 
				if(empty($terminalbrad) || empty($transbrad) || empty($agtomadora) || empty($nseq))
    				{
    					return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos.</center>';
    				}
				else
					{
						if(!empty($name) && in_array($type,$permisao))
						 {
							 $nome = md5(uniqid(rand(),true)).".jpg";
							 upload_jpg($tmp,$nome,800,600,$pasta);
								$conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_pag (valor,mensagem,data,status,login,date,banco,pagem,termbrad,ntrans,agtomadora,nseq,produto,foto,hora) 
													values (?,?,?,'0',?,?,?,?,?,?,?,?,?)",(int)$valor,$bbcode->arrumar_acentos_color($mensagem),$data,$this->login,$date,$banco,$em,$bbcode->arrumar_acentos_color($terminalbrad),$bbcode->arrumar_acentos_color($transbrad),$bbcode->arrumar_acentos_color($agtomadora),$nseq,$prod,$nome,$hora);
								header("Location: ?gne=compras"); 
						 }
						 else
							{
								return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';
							}
					}
			}
		elseif($banco == "Banco do Brasil")
			{
				if(empty($envelopebb) || empty($docbb))
					{
						return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos. '.$envelopebb.$docbb.'</center>';
					}
					else
						{
							if(!empty($name) && in_array($type,$permisao))
								{
									 $nome = md5(uniqid(rand(),true)).".jpg";
									 upload_jpg($tmp,$nome,800,600,$pasta);
									$conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_pag (valor,mensagem,data,status,login,date,banco,pagem,nenvelope,ndocumento,produto,foto,hora) 
															 values (?,?,?,'0',?,?,?,?,?,?,?,?,?)",(int)$valor,$bbcode->arrumar_acentos_color($mensagem),$data,$this->login,$date,$banco,$em,$bbcode->arrumar_acentos_color($envelopebb),$bbcode->arrumar_acentos_color($docbb),$prod,$nome,$hora);
									header("Location: ?gne=compras");
								}
						   else
								{
									 return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>'; 
								}     
						}
			}
		elseif($banco == "Itau")
			{
					if(empty($ctritau) || empty($docitau))
					 {
						 return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos.</center>';
					 }
					else
						{
							if(!empty($name) && in_array($type,$permisao))
								{
									 $nome = md5(uniqid(rand(),true)).".jpg";
									 upload_jpg($tmp,$nome,800,600,$pasta);
									 $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_pag (valor,mensagem,data,status,login,date,banco,pagem,ctr,ndocumento,produto,foto,hora) 
														 values (?,?,?,'0',?,?,?,?,?,?,?,?,?)",(int)$valor,$bbcode->arrumar_acentos_color($mensagem),$data,$this->login,$date,$banco,$em,$bbcode->arrumar_acentos_color($ctritau),$bbcode->arrumar_acentos_color($docitau),$prod,$nome,$hora);
									 header("Location: ?gne=compras"); 
								}
							else
								{
									 return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';         
								}         
						}
			}
		elseif($banco == "Caixa")
			{
					if(empty($terminalcaixa) || empty($doccaixa))
					{
						return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos.</center>';
					}
					else
						{
							if(!empty($name) && in_array($type,$permisao))
								{
									 $nome = md5(uniqid(rand(),true)).".jpg";
									 upload_jpg($tmp,$nome,800,600,$pasta);
									 $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_pag (valor,mensagem,data,status,login,date,banco,pagem,termbrad,ndocumento,produto,foto,hora) 
																	  values (?,?,?,'0',?,?,?,?,?,?,?,?,?)"
                                                                      ,(int)$valor,$bbcode->arrumar_acentos_color($mensagem),$data,$this->login,$date,$banco,$em,$bbcode->arrumar_acentos_color($terminalcaixa),$bbcode->arrumar_acentos_color($doccaixa),$prod,$nome,$hora);
									header("Location: ?gne=compras");
								}
						   else
							 {
								 return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';         	
							 }     
						}
			} 
            
            
        elseif($banco == "Santander")
            {
                    if(empty($sant) || empty($sant1))
                    {
                        return '<center><div class="error_q">[&loz;]Por Favor Preencher os Campos.</center>';
                    }
                    else
                        {
                            if(!empty($name) && in_array($type,$permisao))
                                {
                                     $nome = md5(uniqid(rand(),true)).".jpg";
                                     upload_jpg($tmp,$nome,800,600,$pasta);
                                    $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_pag (valor,mensagem,data,status,login,date,banco,pagem,termbrad,nenvelope,produto,foto,hora) 
                                                                      values (?,?,?,'0',?,?,?,?,?,?,?,?,?)"
                                                                      ,(int)$valor,$bbcode->arrumar_acentos_color($mensagem),$data,$this->login,$date,$banco,$em,$bbcode->arrumar_acentos_color($sant1),$bbcode->arrumar_acentos_color($sant),$prod,$nome,$hora);
                                    header("Location: ?gne=compras");
                                }
                           else
                             {
                                 return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&aacute;lida.</div>';             
                             }     
                        }
            }    
            
                                 
			
		}
		
	function confirmar($id,$pag,$gold,$login)
		{
		   global $conexao; 
		   if($pag == 2 || $pag ==3)
			{
				echo utf8_decode("<script language=\"javascript\">jQuery(function() { mensagem('<h1>Pagamento Rejeitado ou Já Foi Confirmado.</h1>'); });</script>");
			}
			else
			{    
				$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_pag set status='3' where id=?",(int)$id);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$gold*qtd_1_gold,$login);
				
				echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Deposito Confirmado com Sucesso.</h1>'); });</script>";
				echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/compras\">"; 
			}
		}	
	function rejeitar($id)
		{
			global $conexao; 
			$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_pag set status='2' where id=?",(int)$id);
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Deposito Rejeitado Com Sucesso.</h1>'); });</script>";
			echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/compras\">"; 
		}	
		
	function abrir($id)
		{
			global $conexao; 
			$conexao->ExecuteNonQuery("update GneeSite.dbo.gnee_pag set status='1' where id=?",(int)$id);    
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Deposito Aberto com Sucesso.</h1>'); });</script>";
			echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/compras\">"; 
		}	
	function deletar($id)
		{
			global $conexao; 
			$a = $conexao->ExecuteScalar("select foto from GneeSite.dbo.gnee_pag where id=?",(int)$id);
			unlink(foto_comprovante."/".$a);
			$conexao->ExecuteNonQuery("DELETE FROM  GneeSite.dbo.gnee_pag where id=?",(int)$id);
			echo "<script language=\"javascript\">jQuery(function() { mensagem_alert('<h1>Deposito Deletado Com Sucesso.</h1>'); });</script>";
			echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"1;URL=?gne=paineladm/compras\">"; 
		}	
		
}


?>			

