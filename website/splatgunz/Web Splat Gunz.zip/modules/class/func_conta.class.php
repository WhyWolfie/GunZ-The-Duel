<?php

class func_conta extends funcao
{
	
	function limpar_bau($codigo)
	{
		global $conexao;
	   if($_SESSION["captcha_site"] != $codigo)
    	   {
    		  return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
    	   } 
	   
	   $conexao->ExecuteNonQuery("update MuOnline.dbo.warehouse set items=convert(varbinary(".TAMANHO_BAU."), replicate(0xFF, ".TAMANHO_BAU.")),Money=0 where AccountID=?",$this->login);
		return '<center><div class="ok">[&loz;]O ba&uacute; foi Limpo com Sucesso.</div>';
						
	}
	
	function alterar_senha($codigo,$email,$senha,$nsenha,$nsenha2)
	{
		global $conexao;
		$dados = $conexao->ExecuteReader("select memb__pwd,mail_addr from MuOnline.dbo.memb_info where memb___id=?",$this->login);
        $dados = $dados->FetchObject();    
		if(empty($email) || empty($senha) || empty($nsenha) || empty($nsenha2))
			{
			 return '<center><div class="error_q">[&loz;]Todos os Campos S&atilde.o Obr&iacutelgatorios.</div>';   
			}
		elseif($_SESSION["captcha_site"] != $codigo)
		   {
			return '<center><div class="error_q">[&loz;]Co&oacute;digo Incorreto.</div>';
		   } 
		elseif(strlen($nsenha) <4)
			{
		  return '<center><div class="error_q">[&loz;]A senha deve contem no m&iacute;nimo 4 caracteres.</center>';
			}
		elseif($nsenha <> $nsenha2)
			{
			 return '<center><div class="error_q">[&loz;]As senha N&atilde;o Correspondem.</center>';
			}        
		elseif($senha <> $dados->memb__pwd || $email <> $dados->mail_addr)  
			{        
			 return '<center><div class="error_q">[&loz;]E-mail ou Senha Incorretos.</center>';
			}
		elseif($nsenha == $dados->memb__pwd)
			{
			 return '<center><div class="error_q">[&loz;]A senha nova n&atilde;o pode ser igual a antiga.</center>';   
			}
		 else
			 {
			  $conexao->ExecuteNonQuery("update MuOnline.dbo.memb_info set memb__pwd=? where memb___id=?",$nsenha,$this->login);
			  return '<center><div class="ok">[&loz;]Senha Alterada com Sucesso.</center>';  
			 }           
	}
									 
	function reparar_bau($codigo)
	{
		global $conexao;
		if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}   
             
		/*	
		for($x = 0;$x < TAMANHO_BAU / 216; ++$x)
		{
			$a = $x * 255;
			$b = $a + 255;
			$result = $conexao->ExecuteReader("select substring(Items,?,?) from warehouse where accountid=?",(int)$a,(int)$b,$this->login);
            $result = $result->FetchRow();
			$inventory = $inventory.$result[0];
		}
		$hexa = strtoupper(bin2hex($inventory));
	
		for($i = 0; $i < strlen($inventory) * 2; $i++)
		{
			if (($i % 20 == 0))
			{
				$hex_item = substr($hexa, $i, 20);
				if (strlen($hex_item) >= 20)
				{
					$hex_final .= substr($hex_item, 0, 4)."FF".substr($hex_item, 6);
				}
			}
		}
		
		$conexao->ExecuteNonQuery("update warehouse set items=0x? where accountid=?",(int)$hex_final,$this->login);
        */
		return '<center><div class="ok">[&loz;]Bau Reparado com Sucesso.</div>';
	}
	
	function recuperar_senha($codigo,$login_recuperar,$email)
		{
		global $conexao;
		$check_rec_email = $conexao->ExecuteReader("select memb__pwd,sno__numb from MuOnline.dbo.memb_info where memb___id=? and mail_addr=?",$login_recuperar,$email);    
		$check_pw_bau = $conexao->ExecuteScalar("select pw from MuOnline.dbo.warehouse where AccountID=?",$login_recuperar);
		if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		elseif(empty($login_recuperar) || empty($email))   
			{
			 return '<center><div class="error_q">[&loz;]Todos os Campos S&atilde.o Obr&iacutelgatorios.</div>';      
			}
		elseif($check_rec_email->GetRowCount() < 1)
			{
			  return '<center><div class="error_q">[&loz;]Login Ou E-mail N&atilde;o encontrados.</div>';    
			} 
        $check_rec_email = $check_rec_email->fetchObject();      
		sendMail($login_recuperar,$check_rec_email->memb__pwd,$email,$check_rec_email->sno__numb,$check_pw_bau,$email);         
		}
	function alterar_bau($codigo)
		{
		global $conexao;    
		if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}

			$conexao->ExecuteNonQuery("update MuOnline.dbo.warehouse set items=items2,items2=items where accountid=?",$this->login);
			return '<center><div class="ok">[&loz;]Ba&uacute; Alterado com Sucesso.</div>';
		}    
	function deslogar_conta($codigo)
		{
		global $conexao;    
		if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		  $conexao->ExecuteNonQuery( "update MuOnline.dbo.memb_stat set ConnectStat=0 where memb___id=?",$this->login);
		  return '<center><div class="ok">[&loz;]Conta Deslogada com Sucesso.</div>';     
		}    
	function deletar_ss($id)
		{
			global $conexao;
			$check = $conexao->ExecuteReader("select * from GneeSite.dbo.gnee_screen where id=? and login=?",(int)$id,$this->login);
				if($check->GetRowCount() < 1)
					{
							return '<center><div class="error_q">[&loz;]Essa Screen n&oacute;o pertence a sua Conta.</div>';
					}
			$del = $conexao->ExecuteScalar("select nome from GneeSite.dbo.gnee_screen where id=? and login=?",(int)$id,$this->login);
			unlink(lugar_ss."/".$del);        
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_screen where id=? and login=?",(int)$id,$this->login);
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_screen_votado where idss=?",(int)$id);
			$conexao->ExecuteNonQuery("DELETE FROM GneeSite.dbo.gnee_screen_resp where id=?",(int)$id);
						header("Location: ?gne=gere_ss");        
		}
	function cadastrar_ss($codigo,$char,$desc,$img)
		{   
			global $conexao,$bbcode;
			$data = @date("d-m-Y");
			if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		  $permisao = array('image/jpg','image/jpeg','image/pjpeg','image/png','image/gif' );
		  $type = $_FILES['screenfoto']['type'];
		  $tmp = $img['tmp_name'];
		  $name = $img['name'];
		  
			$a = explode("/",$type);
			$a[1];
								
				if($a[1] == "jpg" || $a[1] == "jpeg" || $a[1] == "pjpeg" || $a[1] == "png")
				  {
					$tipo = "jpg";   
				  }
				elseif($a[1] == "gif")
				  {
					 $tipo = "gif";
				  }
			if(!empty($name) && in_array($type,$permisao))
				{
				  $nome = md5(uniqid(rand(),true)).".".$tipo;
					if($tipo == "jpg")
					  {
					   upload_jpg($tmp,$nome,800,600,lugar_ss);    
					  }
					 elseif($tipo == "gif")
					  {
					   upload_gif($tmp,$nome,800,600,lugar_ss);   
					  }
					 $conexao->ExecuteNonQuery("insert into GneeSite.dbo.gnee_screen (nome,login,votos,data,descricao,personagem) VALUES (?,?,0,?,?,?)",$nome,$this->login,$data,$bbcode->arrumar_acentos_color($desc),$char);
					header("Location: ?gne=gere_ss");        
				 }
			else 
				 {
			return '<center><div class="error_q">[&loz;]Tipo de Imagem Inv&iacute;lida.</div>';
				  }
				
		}
	 function comprar_vip($codigo,$vip)
		{
			global $conexao;
			global $VIPS;
			$a = $conexao->ExecuteScalar("select ".gold_coluna." from MuOnline.dbo.".tabela_gold." where ".gold_login."=?",$this->login);    
		  if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
		    $check_vip = $conexao->ExecuteScalar("select ".vip_coluna." from MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$this->login); 
			if($check_vip > 0)
			 {
			 return '<center><div class="error_q">[&loz;]Voc&ecirc; j&aacute; tem Vip, Espere acabar para Comprar Mais.</div>';         
			 }
			 if($vip == "30_1")
				{    
				if($a < $VIPS["PRECO"]["PRECO_VIP1"])
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=1,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)$VIPS["DIAS"]["DIAS_VIP1"],$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)$VIPS["PRECO"]["PRECO_VIP1"],$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                
				}
			 if($vip == "30_2")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP2"])
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=2,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)$VIPS["DIAS"]["DIAS_VIP2"],$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)$VIPS["PRECO"]["PRECO_VIP2"],$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "30_3")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP3"])
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=3,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)$VIPS["DIAS"]["DIAS_VIP3"],$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)$VIPS["PRECO"]["PRECO_VIP3"],$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "30_4")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP4"])
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=4,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)$VIPS["DIAS"]["DIAS_VIP4"],$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)$VIPS["PRECO"]["PRECO_VIP4"],$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "30_5")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP5"])
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=5,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)$VIPS["DIAS"]["DIAS_VIP5"],$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)$VIPS["PRECO"]["PRECO_VIP5"],$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "60_1")
				{    
				if($a < $VIPS["PRECO"]["PRECO_VIP1"]*2)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=1,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP1"]*2),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP1"]*2),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                
				}
			 if($vip == "60_2")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP2"]*2)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=2,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP2"]*2),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP2"]*2),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "60_3")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP3"]*2)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=3,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP3"]*2),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP3"]*2),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "60_4")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP4"]*2)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=4,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP4"]*2),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP4"]*2),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "60_5")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP5"]*2)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=5,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP5"]*2),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP5"]*2),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}   
			 if($vip == "90_1")
				{    
				if($a[0] < $VIPS["PRECO"]["PRECO_VIP1"]*3)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=1,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP1"]*3),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP1"]*3),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                
				}
			 if($vip == "90_2")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP2"]*3)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=2,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP2"]*3),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP2"]*3),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "90_3")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP3"]*3)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=3,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP3"]*3),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP3"]*3),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "90_4")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP4"]*3)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=4,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP4"]*3),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP4"]*3),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}
			 if($vip == "90_5")
				{
				 if($a < $VIPS["PRECO"]["PRECO_VIP5"]*3)
					{
				   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold.' Insuficientes..</div>';               
					}    
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=5,".data_vip."=".data_vip." + ? where ".vip_login."=?",(int)($VIPS["DIAS"]["DIAS_VIP5"]*3),$this->login);
				$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna." - ? where ".gold_login."=?",(int)($VIPS["PRECO"]["PRECO_VIP5"]*3),$this->login);    
				return '<center><div class="ok">[&loz;]Vip Adicionado com Sucesso.</div>';                   
				}        
		}                           

	function comprar_bau($codigo)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
			{
			return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
			}
			$check_bau = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.".TABELA_BAU_EXTRA." where ".LOGIN_BAU_EXTRA."='".$this->login."'");
			$check_gold = $conexao->ExecuteScalar("select ".gold_coluna." from MuOnline.dbo.".tabela_gold." where ".gold_login."='".$this->login."'");
			if($check_bau > MAXIMO_QTD_BAU)
				{
				  return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode comprar Mais Bau\'s.</div>';
				}
			elseif($check_gold < PRECO_BAU)
				{
				  return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem '.nome_gold.' Suficientes.</div>';     
				}                        
					$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."-".PRECO_BAU." where ".gold_login."=?",$this->login);
					$conexao->ExecuteNonQuery("insert into MuOnline.dbo.".TABELA_BAU_EXTRA." (".LOGIN_BAU_EXTRA.",".ITEMS_BAU_EXTRA.") VALUES (?,convert(varbinary(".TAMANHO_BAU."), replicate(0xFF, ".TAMANHO_BAU.")))",$this->login);
					return '<center><div class="ok">[&loz;]Ba&uacute; Comprado com Sucesso.</div>';
							   
		}
	 function transferir_gold($codigo,$conta,$num)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
    			{
    				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
    			}
            if($num < 0)
                {
                    return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>'; 
                }
			$check_conta = $conexao->ExecuteScalar("select count(*) from MuOnline.dbo.memb_info where memb___id=?",$conta);
			if($check_conta < 1)
				{
					 return '<center><div class="error_q">[&loz;]Conta '.$conta.' n&atilde;o encontrada.</div>';   
				}
			$check_gold = $conexao->ExecuteScalar("select ".gold_coluna." from MuOnline.dbo.".tabela_gold." where ".gold_login."=?",$this->login);  
			if($check_gold < $num)
				{
				    return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem essa Quantidade de Golds.</div>';
				}    
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."-? where ".gold_login."=?",(int)$num,$this->login);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$num,$conta);
			return '<center><div class="ok">[&loz;]Golds Transferidos.</div>'; 
		}
	function transferir_vip($codigo,$conta,$num)
		{
			global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
    			{
    				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
    			}
			$check_conta = $conexao->ExecuteReader("select memb___id from MuOnline.dbo.memb_info where memb___id=?",$conta);
			if($check_conta->GetRowCount() < 1)
				{
					 return '<center><div class="error_q">[&loz;]Conta '.$conta.' n&atilde;o encontrada.</div>';   
				}
			$check_vip = $conexao->ExecuteReader("select ".vip_coluna." as Vip,".data_vip." as Dia from MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$this->login);    
			$check_vip = $check_vip->fetchObject();
            if($check_vip->Vip < 1 )
				{
					 '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o &eacute; Vip.</div>';
				}
            if($num < 0)  
                {
                     return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o pode Transferir Valores Negativos.</div>';
                }  
			if($check_vip->Dia < $num )
				{
					return '<center><div class="error_q">[&loz;]Voc&ecirc; n&atilde;o tem essa Quantidade de Dias Vip.</div>';
				}  
			$x = ($check_vip->Dia - $num); 
			($x >= 1) ? $a = $check_vip->Vip : $a = 0 ;   
            $check_vip_conta = $conexao->ExecuteReader("select ".vip_coluna." as Vip from MuOnline.dbo.".tabela_vip." where ".vip_login."=?",$conta);
            $check_vip_conta = $check_vip_conta->FetchObject();
            ($check_vip_conta->Vip < $check_vip->Vip) ? $vip = $check_vip->Vip : $vip = $check_vip_conta->Vip ;   
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".data_vip."=".data_vip."-?,".vip_coluna."=? where ".vip_login."=?",(int)$num,(int)$a,$this->login);
			$conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_vip." set ".vip_coluna."=?,".data_vip."=".data_vip."+? where ".vip_login."=?",(int)$vip,(int)$num,$conta);
			return '<center><div class="ok">[&loz;]Dias Vip Transferidos.</div>';
			
		}	
    function converter_unidades($codigo,$qtd)		
		{
		  global $conexao;
			if($_SESSION["captcha_site"] != $codigo)
    			{
    				return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
    			}
            $check = $conexao->ExecuteReader("select ".gold_coluna2." as Cash from MuOnline.dbo.".tabela_gold2." where ".gold_login2."=?",$this->login);    
            $check = $check->fetchObject();
            if($check->Cash < $qtd || $qtd < 0)
                {
                   return '<center><div class="error_q">[&loz;]Quantidade de '.nome_gold2.' Insuficientes para Troca.</div>'; 
                }    
            $conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold." set ".gold_coluna."=".gold_coluna."+? where ".gold_login."=?",(int)$qtd,$this->login);
            $conexao->ExecuteNonQuery("update MuOnline.dbo.".tabela_gold2." set ".gold_coluna2."=".gold_coluna2."-? where ".gold_login2."=?",(int)(QTD_GOLD_CASH*$qtd),$this->login);                       
            return utf8_decode('<script language="javascript">jQuery(function() { mensagem_alert(\'Moedas Convertidas Com Sucesso\'); });</script>');    
		}
     function trocar_senha_bau($codigo,$senha)
        {
          global $conexao;
            if($_SESSION["captcha_site"] != $codigo)
                {
                    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
                }
             elseif(strlen($senha) < 4)
                {
                    return '<center><div class="error_q">[&loz;]A senha do Ba&uacute; Deve ser igual a 4 Characteres.</div>';
                }   
             elseif(preg_match("/^[0-9]{4}$/",$senha) == false)
                 {
                    return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'<b>Senha</b> so Pode Ser Numericos <b>(0-9)</b>\'); });</script>'); 
                 }
            else
                {
                    $conexao->ExecuteNonQuery("Update MuOnline.dbo.warehouse Set pw=? where accountid=?",$senha,$this->login);
                    return '<center><div class="ok">[&loz;]Senha Alterada com Sucesso.</div>';
                }             
        }  
     function trocar_personal_id($codigo,$id,$id2)
        {
          global $conexao;
          $id_conta = $conexao->ExecuteScalar("Select sno__numb from MuOnline.dbo.memb_info where memb___id=?",$this->login);
            if($id_conta == NULL || $id_conta == 0)
                {
                    $id = $id_conta;
                }
            if($_SESSION["captcha_site"] != $codigo)
                {
                    return '<center><div class="error_q">[&loz;]C&oacute;digo Incorreto.</div>';
                }
            elseif($id <> $id_conta)
                {
                    return '<center><div class="error_q">[&loz;]Personal ID N&atilde;o corresponde ao Cadastrado</div></center>';
                }    
             elseif(strlen($id2) < 7)
                {
                    return '<center><div class="error_q">[&loz;]O Personal ID Deve ser igual a 7 Characteres.</div>';
                }   
             elseif(preg_match("/^[0-9]{7}$/",$id2) == false)
                 {
                    return utf8_decode('<script language="javascript">jQuery(function() { mensagem(\'<b>Personal ID</b> so Pode Ser Numericos <b>(0-9)</b>\'); });</script>'); 
                 }
            else
                {
                    $conexao->ExecuteNonQuery("Update MuOnline.dbo.memb_info Set sno__numb=? where memb___id=?",$id2,$this->login);
                    return '<center><div class="ok">[&loz;]Perosnal ID Alterada com Sucesso.</div>';
                }             
        }      
}

?>                          
											   