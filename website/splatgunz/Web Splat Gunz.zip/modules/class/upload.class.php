<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}
 function upload_jpg($tmp,$nome,$largura,$altura,$pasta){
			$img = 	imagecreatefromjpeg($tmp);
			$x = imagesx($img);
			$y = imagesy($img);
			$nova = imagecreatetruecolor($largura,$altura);
			imagecopyresampled($nova,$img,0,0,0,0,$largura,$altura,$x,$y);
			imagejpeg($nova,"$pasta/$nome");
			imagedestroy($nova);
			imagedestroy($img);	
			return($nome);
}
 
 
	  
 function upload_gif($tmp,$nome,$largura,$altura,$pasta){           
            $img =     imagecreatefromgif($tmp);
            $x = imagesx($img);
            $y = imagesy($img);            
            $nova = imagecreatetruecolor($largura,$altura);
            imagecopyresampled($nova,$img,0,0,0,0,$largura,$altura,$x,$y);
            imagegif($nova,"$pasta/$nome");
            imagedestroy($nova);
            imagedestroy($img);    
            return($nome);
   }
?>