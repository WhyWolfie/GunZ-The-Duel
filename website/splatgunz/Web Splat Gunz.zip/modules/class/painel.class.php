<?php session_start(); ?>

<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
	exit();
}

class login{
	
	
				function logar(){
				global $conexao;
						
				  $formulario =      '<form action="" name="painel" method="post">   
									 <div align="center"><div style="margin-left: 20px;"align="left" >Login:</div>
									 <input type="text" name="login_painel" maxlength="10" class="texto" />
									 <div style="margin-left: 20px;" align="left">Senha:</div>
									 <input name="senha" type="password" maxlength="10" class="texto"/>
									 <input type="hidden" name="enviar" />
									 <br><input name="enviar" value="Entrar" type="submit" /></br></br>
									 <a href="?gne=rec_senha";">Esqueceu sua senha?</a></div>
									 </form>';            
								
 
							  if(isset($_POST['enviar'])){
							$login_painel = trim($_POST['login_painel']);
							$senha = trim($_POST['senha']);
							if(empty($login_painel) || empty($senha)){
								echo "<center>Por favor Preencher toos os Campos </center>";
								echo "</br>";
								}
						else {
						$checklogin = $conexao->ExecuteReader("select memb___id from MuOnline.dbo.memb_info where memb___id=? and memb__pwd=?",$login_painel,$senha);
						
						if($checklogin->GetRowCount() < 1){
							echo "<center> Login Ou senha Incorretos</center>";
							unset($_SESSION['GneeSite_login']);
							unset($_SESSION['GneeSite_senha']);
							echo "</br>";}
						else {
							$_SESSION['GneeSite_login'] = $login_painel;
							$_SESSION['GneeSite_senha'] = $senha;
							
							}
						}    
						
							}
						
						
						if(!isset($_SESSION['GneeSite_login']) && !isset($_SESSION['GneeSite_senha']))
							{
							    echo $formulario;
                            }
					   else {
							$login_painel = $_SESSION['GneeSite_login'];
							$senha = $_SESSION['GneeSite_senha'];
							$dados = $conexao->ExecuteReader("select login,nivel from GneeSite.dbo.gnee_admin where login='".$login_painel."'");
							$dados = $dados->fetchObject();
							
							echo '<table>
				<tr>
				<td class="top_ul3">Ol&aacute; <strong>'.$login_painel.'</strong></td>  
				<td><a href="?sair=1">Deslogar</a></td>
				</tr>
				<tr>
			   <td></br><a href="?gne=account" >Gerenciar Conta</a></td>
				</tr>         
				<tr>
			   <td><a href="?gne=character" >Gerenciar Personagem</a></td>
				</tr>
				<tr>
				<td>-----------------------</td>
				</tr>
				<tr>
			   <td>    <a href="?gne=ticket" >Gerenciar Ticket</a></td>
				</tr>
				<tr>
			   <td>    <a href="?gne=compras">Gerenciar Compras</a></td>
				</tr>
				<td>-----------------------</td>
				<tr>
				
			   <td>    <a href="?gne=paineladm">';
               if($dados->nivel >= 1)
               { 
			   echo ($dados->nivel == 1) ? "Painel de Game Master"  : "Painel de Administra&ccedil&atilde;o";
               }
			   echo '</a></td>
				</tr>
			   
				</table>';
							if(isset($_GET['sair']))
	{
		unset($_SESSION['GneeSite_login']);
		unset($_SESSION['GneeSite_senha']);
		session_destroy();
		echo '<script>location="index.php"</script>';
	}
							
							}
						}}
				
						?>