<?php
//NighT GamerZ Spain Config
$link = mssql_connect("COMPUTADOR\SQLEXPRESS","sa","123456");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'COMPUTADOR\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = '123456'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZ DB 


?>