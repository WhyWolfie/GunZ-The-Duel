<?
if ($_SESSION['AID'] == ""){
?>
<style type="text/css">
@import "final.css";
</style><form name="login" method="POST" action="index.php?do=login">
<table width="187" height="202" border="0">
  <tr>
    <th background="login_panel.png" scope="col">  
    <td height="21" 

valign="top">&nbsp;</td>
  </tr>
  <tr>
    <th width="0" background="login_panel.png" scope="col"><td width="177" height="175" 

valign="top" background="img/login_panel.png">		<div align="center">
<br>
<br>
<br>
<table width="100" border="0">
                                      <tr>
                                        <th scope="col"><table border="0" 

style="border-collapse: collapse;" width="158">
                                          <tr>
                                            <td height="29"><input 

name="userid" class="textLogin" style="float: left; background-color: #350001; layer-background-color: #003366; border: 1px none #000000;" tabindex="1" size="11"></td>
                                            <td 

width="58" rowspan="2" >
                                              <div 

align="left">
                                                <table width="25" border="0">
                                                  <tr>
                                                    <input name="log" 

type="image" id="log" onMouseOver="FP_swapImg(1,1,/*id*/'log',/*url*/'img/log_on.png')" 

onmouseout="FP_swapImgRestore()" src="img/log.png" align="middle" width="57" height="47" 

border="0">
                                                  </tr>
                                                </table>
                                            </div></td>
                                          </tr>
                                          <tr>
                                            <td 

width="90" height="34"><input name="pass" size="11" class="textLogin" style="float: left; background-color: #350001; layer-background-color: #003366; border: 1px none #000000;" type="password" 

tabindex="2"></td>
                                          </tr>
                                          <tr>
                                            <td height="56" 

colspan="2"><table border="0" style="border-collapse: collapse" width="100%">
                                                <tr>
                                                  <td width="0" height="25"></td>
                                        � �
                                                  <td width="10"><div align="center"><span style="font-size: 7pt"><form name="form1" method="post" action="">
   <a 

href="index.php?do=register"></a></span><img border="0" src="img/arrow.png" width="10" height="10"></div></td>
                                                  <td><div align="center"><a href="register.php" class="Estilo1">New User, Sign Up Now?</a></span></td>
                                                </tr>
                                                <tr>
                                                  <td width="0" height="29"></td>
                                                  <td width="10"><div align="center"><img border="0" src="img/arrow.png" 

width="10" height="10"></div></td>
                                                  <td width="175" align="left"><div align="center"><span style="font-size: 7pt"><a href="index.php?do=password" class="Estilo1">Forgot your Password?</a></span></div></td>
                                                </tr>
                                            </table></td>
                                          </tr>
                                          <tr>
                                            <td height="20" colspan="2">&nbsp;</td>
                                          </tr>
                                        </table></th>
                                      </tr>
          </table>
    </div>					

			  </td>
	</tr>
</table>
<input type="hidden" name="submit" value="1"></form>
<?
}else{
$res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$a=mssql_fetch_assoc($res9);

$res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
$d=mssql_fetch_assoc($res);

$res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");


?>
<div align="right">
<body>
  <p>&nbsp;</p>
  <table width="179" height="143" border="0" align="right">
    <tr>
      <th width="173" height="139" background="img/in.png" scope="col"><table width="170" border="0">
        <tr>
          <th height="49" colspan="2" scope="col"><table width="160" height="24" border="0" align="center">
        <tr>
          <th width="213" height="20" scope="col"><br>
            Welcome
            <?=$_SESSION['UserID']?>, <a href="index.php?do=logout">Logout?</a> </th>
        </tr>
          </table></th>
        </tr>
        <tr>
          <th width="74" scope="col"><div align="center"><font color="#CCCCCC"><img src="<? $emblem ?>" name="markimage" width="32" height="32" border="2" id="markimage" style="border: 2px 

solid #131112"></font></div></th>
          <th width="85" height="62" scope="col"><div align="center">
            <form name="claninfo" id="claninfo">
              <select size="1" name="clanname" id="clanname" onChange="SwitchClan()">
                  <?                                                  
while( $clan = mssql_fetch_assoc( $res2 )){

                                                        if( $clan['Grade'] == 1 ){
                                                            $admin = "Master";
                                                        }else{
														    if( $clan['Grade'] == 9){
                                                            $admin = "Master";
                                                            }else{
															$admin = "Member";
															}
															}
                                                        
                                                        $res3 = mssql_query("SELECT * FROM Clan WHERE CLID = 

'".$clan['CLID']."'");
                                                        $claninfo = mssql_fetch_assoc($res3);


                                                        if( $claninfo['EmblemUrl'] == "" ){
                                                            $emblem = "img/no_emblem.jpg";
                                                        }else{
                                                            $emblem = "http://emblempage.com" . $claninfo['EmblemUrl'];
                                                        }
                                                        echo "<option 

value='".$clan['CLID']."|".$d['Name']."|".$admin."|".$emblem."'>".$claninfo['Name']."</option>\n";
                                                    }
                                                    ?>
                </select>
              </form>
          </div></th>
        </tr>
      </table>      
        <table width="170" border="0" align="center">
          <tr>
            <th scope="col"><table width="167" border="0" align="left">
              <tr>
                <th width="81" scope="col"><a href="emblem/index.php"><img src="img/emblem.png" width="80" height="20" border="0"></a></th>
                <th width="76" height="20" scope="col">
                  <? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254){include"staffpanel.php";echo "</br>";} ?>
                </th>
              </tr>
              <tr>
                <th height="14" colspan="2" scope="col"><a href="index.php?do=profile"><img src="img/edit.png" width="80" height="20" border="0"></a></th>
              </tr>
            </table></th>
          </tr>
        </table></th>
    </tr>
</table>
</body>
							
						</form><script language="javascript">
                        SwitchClan();
                        </script>

<?
}

?>		</div>
