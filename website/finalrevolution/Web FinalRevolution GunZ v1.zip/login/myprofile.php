<?

if(isset($_POST[Checksubmit]))
{
    $pass = clean($_POST[CheckPass]);
    if(mssql_num_rows(mssql_query("SELECT * FROM Login WHERE UserID = '{$_SESSION[UserID]}' AND Password = '$pass'")) == 1)
    {
        $_SESSION[Modify] = 1;
    }else{
        SetMessage("Announcement", array("You have entered an incorrect user or password."));
        $_SESSION[Modify] = 0;
        header("Location: index.php?do=profile");
        die();
    }
}

if($_SESSION[Modify] <> 1)
{
?>
<style type="text/css">
<!--
.Estilo1 {
	font-size: 10px;
	color: #999999;
	font-family: verdana;
}
.Estilo90 {	font-size: 10px;
	font-weight: bold;
	font-family: verdana;
}
.Estilo2 {
	font-size: 10px;
	font-family: verdana;
}
.Estilo3 {color: #999999}
.Estilo9 {font-size: 9px; font-family: verdana; color: #999999; }
-->
</style>

<table width="44%" border="0" align="center" style="border-collapse: collapse">
					<tr>
						<td width="418" valign="top">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="70%" bordercolor="#000000">
								<tr>
									<td background="img/large.png" height="24" style="background-image: url('img/large.png'); background-repeat: no-repeat; background-position: center top">
									  <div align="center"><strong><font size="2" face="Tahoma">Verify Account </font></strong></div></td>
								</tr>
								<tr>
									<td>
									<div align="center">
										<form method="POST" action="index.php?do=profile" name="editacc">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">&nbsp;
												</td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td style="background-repeat: no-repeat; background-position: center top" colspan="3"> <div align="center" class="Estilo2 Estilo3">Never give your personal information to anyone!!! <br>
												  Final Revolution Staff Never ask for your password.</div></td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">
												  <div align="center" class="Estilo1">For security purposes, you must re-verify your account EVERY TIME you edit your account information.</div></td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">&nbsp;
												</td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td width="146">
												<div align="right">
												<span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot;</font></font></span> <span class="Estilo2">Password</span></td>
												<td width="33">&nbsp;
												</td>
												<td width="185">
										          <div align="right">
										            <input name="CheckPass" size="20" class="textLogin" style="float: left" type="password">
							                    </div></td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">&nbsp;
												</td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">
												<div align="center">
												<input name="I1" type="image" id="ok1" onmouseover="FP_swapImg(1,1,/*id*/'ok1',/*url*/'img/ok.png')" onmouseout="FP_swapImgRestore()" src="img/ok.png" align="middle" width="130" height="30" border="0"></td>
												<td width="13">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9">&nbsp;
												</td>
												<td colspan="3">&nbsp;
												</td>
												<td width="13">&nbsp;
												</td>
											</tr>
											</table>
											<input type="hidden" name="Checksubmit" value="1"></form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
</table>
<?
}else{



if(isset($_POST[submit]) && $_SESSION[Modify] == 1)
{
    $pass[0]        = clean($_POST['pass1']);
    $pass[1]        = clean($_POST['pass2']);
    $email          = clean($_POST['email']);
	$name           = clean($_POST['name']);
    $age            = clean($_POST['age']);
	$country        = clean($_POST['country']);
	$sex            = clean($_POST['sex']);
	$zip            = clean($_POST['zip']);
    $address        = clean($_POST['address']);
	
    $errors = array();

    if($pass[0] <> $pass[1])
        array_merge($errors, array("You have entered different passwords."));

    if(mssql_num_rows(mssql_query("SELECT * FROM Account WHERE Email = '$email'")) <> 0)
        array_merge($errors, array("E-mail $email in use."));

    if($pass[0] <> "" || $pass[1] <> "")
        array_merge($errors, array("Put the password."));

    if($email <> "")
        array_merge($errors, array("Put the E-mail."));
		
    if(strlen($pass[0]) < 6)
        array_merge($errors, array("The password is too short (6-letter minimum)"));

    if(count($errors) == 0)
    {
        mssql_query("UPDATE Account SET Name = '$name', Email = '$email', Age = '$age', Sex = '$sex', Country='$country', ZipCode = '$zip', Address = '$address' WHERE AID = '".$_SESSION['AID']."'" );
		
        if($_POST[C1] == "ON")
        mssql_query("UPDATE Login SET Password = '".$pass[0]."' WHERE AID = '{$_SESSION[AID]}'");

        SetMessage("Announcement", array("Account updated successfully!"));
        header("Location: index.php?do=profile");
        die();
    }else{
        SetMessage("Please correct these errors!", $errors);
        header("Location: index.php?do=profile");
        die();
    }
}else{

    $z = mssql_fetch_assoc(mssql_query("SELECT * FROM Account WHERE AID = {$_SESSION['AID']}"));
    $x = mssql_fetch_assoc(mssql_query("SELECT * FROM Login WHERE AID = {$_SESSION['AID']}"));

    $fr['UserID']        = $z[UserID];
    $fr['EMail']         = $z[Email];
    $fr['Password']      = $x[Password];
    $fr['Name']          = $z[Name];
	$fr['Age']           = $z[Age];
    $fr['Sex']           = $z[Sex];
	$fr['Coutry']        = $z[Country];
    $fr['ZipCode']       = $z[ZipCode];
    $fr['Address']       = $z[Address];
	
}


?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td valign="top">
						<div align="center">
							<table width="43%" border="0" align="center" bordercolor="#000000" style="border-collapse: collapse">
								<tr>
									<td>
									<div align="center">
										<form method="POST" action="index.php?do=profile" name="editacc">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td colspan="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195">&nbsp;</td>
												<td width="168">&nbsp;</td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">
												<img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
												<td width="195" align="left">
												<div align="left">UserID : </td>
												<td width="168" align="left">
												  <div align="center"><b>
											      <?=$fr['UserID']?>
											    </b></div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195" align="left">&nbsp;</td>
												<td width="168" align="left">&nbsp;</td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195" align="left">&nbsp;</td>
												<td width="168" align="left">
											      <div align="center">
											        <input type="checkbox" name="C1" value="ON" onclick="document.editacc.pass1.disabled = !document.editacc.pass1.disabled; document.editacc.pass2.disabled = !document.editacc.pass2.disabled; ">
										        <span class="Estilo1">Edit password? </span></div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">
												  <img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
												<td width="195" align="left">
												Password : </td>
												<td width="168" align="left">
												  <div align="right">
												    <input disabled type="password" name="pass1" size="19" value="<?=$fr['Password']?>" class="textLogin">
										        </div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">
												  <img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
												<td width="195" align="left">
												Repeat Password :</td>
												<td width="168" align="left">
												  <div align="right">
												    <input disabled type="password" name="pass2" size="19" value="<?=$fr['Password']?>" class="textLogin">
										        </div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195" align="left">&nbsp;</td>
												<td width="168" align="left">&nbsp;</td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">
												  <img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
												<td width="195" align="left">
												E-Mail : </td>
												<td width="168" align="left">
												  <div align="right">
												    <input type="text" name="email" size="19" value="<?=$fr['EMail']?>" class="textLogin">
										        </div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195" align="left">&nbsp;</td>
												<td width="168" align="left">
												<div align="left">
												<div align="right"><span class="Estilo9"> Put a correct E-mail. </span></div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td colspan="2" align="left"><hr align="center" noshade>												  <br></td><td width="9">&nbsp;</td>
											</tr>
											<tr>
											  <td>&nbsp;</td>
											  <td><img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
											  <td align="left">Name : </td>
											  <td align="left">
										        <div align="right"><b>
									            <input type="text" name="name" size="19" value="<?=$fr['Name']?>" class="textLogin">
									            </b>											    <br>
							                  </div></td><td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="right">&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td><img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
											  <td align="left">Age :</td>
											  <td align="right"><div align="right"><b>
								              <input type="text" name="age" size="8" value="<?=$fr['Age']?>" class="textLogin">
									          </b></div></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="right">&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td><img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
											  <td align="left">Gender : </td>
											  <td align="right"><input type="text" name="sex" size="5" value="<?=$fr['Sex']?>" class="textLogin"></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="right"><span class="Estilo9">For Male put &quot;0&quot; and for <br>
										      female put &quot;1&quot;.<br>
										      <br> 
										      </span></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td><img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
											  <td align="left">Zip Code    : </td>
											  <td align="right"><input type="text" name="zip" size="18" value="<?=$fr['ZipCode']?>">
										      <br></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="right">&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td><img border="0" src="img/miniarrows2.png" width="11" height="10" id="img13"></td>
											  <td align="left">Adress  :</td>
											  <td align="right"><input type="text" name="address" size="18" value="<?=$fr['Address']?>">
										      <br></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="right">&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td colspan="2" align="left"><div align="center" class="Estilo1"><span class="Estilo96 Estilo101">Name, Age Gender and Country can be used to recover lost or forgotten passwords.</span></div></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td align="left">&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195" align="left">&nbsp;</td>
												<td width="168" align="left">&nbsp;</td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td colspan="2" align="left"><div align="center">
												  <input name="ok" type="image" onmouseover="FP_swapImg(1,1,/*id*/'ok',/*url*/'img/ok_on.png')" onmouseout="FP_swapImgRestore()" src="img/ok.png" align="middle" width="130" height="30" border="0">
											    </div></td>
												<td width="9">&nbsp;</td>
											</tr>
											<tr>
											  <td height="75">&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td colspan="2"><div align="center">
										      </div></td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
											  <td height="43">&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  <td>&nbsp;</td>
											  </tr>
											<tr>
												<td width="2">&nbsp;</td>
												<td width="12">&nbsp;</td>
												<td width="195">&nbsp;</td>
												<td width="168">&nbsp;</td>
												<td width="9">&nbsp;</td>
											</tr>
										</table>
											<input type="hidden" name="submit" value="1"></form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
</table>
</td>    <?}?>