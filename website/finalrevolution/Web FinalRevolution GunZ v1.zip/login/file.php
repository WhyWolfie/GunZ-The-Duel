<div align="center"><a href="index.php?do=download"><img src="img/file.png" width="160" height="60" border="0"></a></div>
