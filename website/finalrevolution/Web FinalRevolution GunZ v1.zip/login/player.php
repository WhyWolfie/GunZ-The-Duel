<?
$res = mssql_query("SELECT TOP 5 * FROM Character ORDER BY Level Desc");
?>
<style type="text/css">
@import "final.css";
</style>
<table background="img/playerrank.png"  width="175" height="124" border="0">
  <tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="14" rowspan="6">&nbsp;</td>
        <td height="33" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No Data &laquo; </div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
        <td width="106"><div align="left">
            <?=$user['Name']?>
        </div></td>
        <td width="35"><b> <font color="#FFFF00">
          <?=$user['Level']?>
        </font> </b></td>
      </tr>
      <?}}?>
    </table>    </tr>
</table>
