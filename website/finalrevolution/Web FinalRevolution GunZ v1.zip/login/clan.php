<?
$res = mssql_query("SELECT TOP 5 * FROM Clan ORDER BY Point DESC");
?><style type="text/css">
@import "final.css";
</style>
<table background="img/clanrank.png"  width="175" height="124" border="0">
  <tr>
    <td><table width="169" height="85" border="0" style="border-collapse: collapse">
      <tr>
        <td width="14" rowspan="6">&nbsp;</td>
        <td height="32" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="22" colspan="2"> <div align="left" class="Estilo2">No Data &laquo; </div></td>
        </tr>
      <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
        <td width="98"><div align="left"><?=$clan['Name']?>
        </div></td>
        <td width="43"><b>
          <font color="#FFFF00"><?=$clan['Point']?></font>
        </b></td>
      </tr>
      <?}}?>
    </table>
  </tr>
</table>
