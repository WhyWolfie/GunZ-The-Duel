<?
date_default_timezone_set( "America/Sao_Paulo" );
if (isset($_POST['submit'])){
$asunto = clean($_POST['asunto']);
$email = clean($_POST['email']);
$texto = clean($_POST['text']);
if (!$asunto == "" or $email == "" or $texto == ""){
        $cabeceras = "Content-type: text/html\r\n";
        $mensaje = "Posted on: ".date("j F, Y")."<br>_________________<br>".$texto."<br>_________________<br><br><b>Sender: $email</b>";
        if (@mail("yenpaulletino@hotmail.com",$asunto,$mensaje,$cabeceras)) {
            $error = "<b>The message was sent. </b> </br> Thank you for contacting us, we will respond as soon as possible";
        }else{
            $error = "<b>Failed to send message</b>";
        }
}else{
    $error = "You must fill in all fields";
}}

?>
<table width="394" height="100%" border="0" align="center" style="border-collapse: collapse">
  <tr>
    <td width="4" rowspan="7">&nbsp;</td>
    <td width="380"></td>
  </tr>
  <tr>
    <td width="380">&nbsp; </td>
  </tr>
  <tr>
    <td width="380">
      <form method="POST" action="index.php?do=staff">
        <table border="0" style="border-collapse: collapse" width="89%" id="table13">
          <tr>
            <td width="17"><? echo $faq['general_faq'] ?></td>
            <td colspan="4"><span class="Estilo1"> Contact Final Revolution GunZ Web Staff </span></td>
          </tr>
          <tr>
            <td width="17">&nbsp;</td>
            <td colspan="4">&nbsp;</td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td width="65" height="16"><span class="Estilo2"> Subject:</span></td>
            <td height="16" colspan="3">
              <select size="1" name="asunto">
                <option value="Problem with the Web">Website Problem </option>
                <option value="Bug">Bug</option>
				<option value="Bug">Hack</option>
                <option value="Suggestion">Suggestion </option>
                <option value="Other...">Other... </option>
            </select></td>
          </tr>
          <tr>
            <td width="17">&nbsp;</td>
            <td width="65">&nbsp;</td>
            <td colspan="3">&nbsp;</td>
          </tr>
          <tr>
            <td width="17">&nbsp;</td>
            <td width="65"><span class="Estilo1">Your<br> 
            e-mail:</span></td>
            <td colspan="3">
              <input type="text" name="email" size="20"></td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td width="65" height="16"></td>
            <td height="16" colspan="3"></td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td width="65" height="16" valign="top"><span class="Estilo1"> Content:</span></td>
            <td height="16" colspan="3">
              <textarea rows="10" name="text" cols="30"></textarea></td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td width="65" height="16"></td>
            <td width="31" height="16"></td>
            <td width="94" height="16"></td>
            <td width="106" height="16"></td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td height="16" colspan="4"> <font face="Tahoma" size="2" color="#FF0000"> <? echo @$error ?></font></td>
          </tr>
          <tr>
            <td width="17" height="16"></td>
            <td height="16" colspan="4">
              <p align="center">
                <input type="submit" value="Send E-Mail" name="submit">
            </td>
          </tr>
        </table>
    </form></td>
  </tr>
  <tr>
    <td width="380">&nbsp; </td>
  </tr>
</table>
