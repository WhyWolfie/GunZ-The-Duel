<style type="text/css">
@import "final.css";
</style>
<FORM METHOD=POST ACTION="<?php echo $_SERVER['PHP_SELF']; ?>?op=register&act=register">
  <div align="center">
    <table border=0 align="center" cellspacing=0>
    <tr>
      <td colspan=4 background: #000000;">&nbsp;</td>
    </tr>
    <tr>
      <td colspan=4 background: #000000;"><div align="center"><span class="Estilo83 Estilo88">Fields marked with an asterisk <span class="Estilo89">*</span> are required. </span></div></td>
    </tr>
    <tr>
    <td colspan=4 background: #000000;"><CENTER>
              <p>&nbsp; </p>
            </CENTER></td>
    </tr>
    <tr>
      <td width="12">&nbsp;</td>
          <td width="141"><span class="Estilo90"><font color="#FFFFFF">&nbsp;&middot; User ID<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td width="288"><div align="right">
            <INPUT TYPE="text" NAME="login"&nbsp;>
          </div></td>
        <td width="14">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><div align="right"><span class="Estilo96"><span class="Estilo77"><span class="Estilo88">May consist of a-z, 0-9 and underscores.<br>
        <br>
      </span></span></span></div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Password<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <INPUT TYPE="password" NAME="senha1">
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td height="21">&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right"><span class="Estilo86"><span class="Estilo97">Enter a password between 6 and 20 characters.<br>
      </span></span><br>
      </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Retype 
            Password<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <INPUT TYPE="password" NAME="senha2">
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right"><span class="Estilo98"><span class="Estilo100">Confirm your password for security.<br>
        <br>
      </span></span></div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>E-mail<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <INPUT TYPE="text" NAME="email">
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td height="21">&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right"><span class="Estilo88">Enter a correct E-mail.<br>
        </span><br> 
        </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td> <span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Name<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <input name="name" type="text" id="name">
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right" class="Estilo88">Enter your full Name.<br>
        <br> 
        </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Age<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <input name="age" type="text" id="age">
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right" class="Estilo88">Enter your Age.<br>
        <br> 
        </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
          <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Country<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
          <td><div align="right">
            <select name="country">
              <option value="">Country...</option>
              <option value="AF">Afghanistan</option>
              <option value="AL">Albania</option>
              <option value="DZ">Algeria</option>
              <option value="AS">American Samoa</option>
              <option value="AD">Andorra</option>
              <option value="AG">Angola</option>
              <option value="AI">Anguilla</option>
              <option value="AG">Antigua & Barbuda</option>
              <option value="AR">Argentina</option>
              <option value="AA">Armenia</option>
              <option value="AW">Aruba</option>
              <option value="AU">Australia</option>
              <option value="AT">Austria</option>
              <option value="AZ">Azerbaijan</option>
              <option value="BS">Bahamas</option>
              <option value="BH">Bahrain</option>
              <option value="BD">Bangladesh</option>
              <option value="BB">Barbados</option>
              <option value="BY">Belarus</option>
              <option value="BE">Belgium</option>
              <option value="BZ">Belize</option>
              <option value="BJ">Benin</option>
              <option value="BM">Bermuda</option>
              <option value="BT">Bhutan</option>
              <option value="BO">Bolivia</option>
              <option value="BL">Bonaire</option>
              <option value="BA">Bosnia & Herzegovina</option>
              <option value="BW">Botswana</option>
              <option value="BR">Brazil</option>
              <option value="BC">British Indian Ocean Ter</option>
              <option value="BN">Brunei</option>
              <option value="BG">Bulgaria</option>
              <option value="BF">Burkina Faso</option>
              <option value="BI">Burundi</option>
              <option value="KH">Cambodia</option>
              <option value="CM">Cameroon</option>
              <option value="CA">Canada</option>
              <option value="IC">Canary Islands</option>
              <option value="CV">Cape Verde</option>
              <option value="KY">Cayman Islands</option>
              <option value="CF">Central African Republic</option>
              <option value="TD">Chad</option>
              <option value="CD">Channel Islands</option>
              <option value="CL">Chile</option>
              <option value="CN">China</option>
              <option value="CI">Christmas Island</option>
              <option value="CS">Cocos Island</option>
              <option value="CO">Columbia</option>
              <option value="CC">Comoros</option>
              <option value="CG">Congo</option>
              <option value="CK">Cook Islands</option>
              <option value="CR">Costa Rica</option>
              <option value="CT">Cote D'Ivoire</option>
              <option value="HR">Croatia</option>
              <option value="CU">Cuba</option>
              <option value="CB">Curacao</option>
              <option value="CY">Cyprus</option>
              <option value="CZ">Czech Republic</option>
              <option value="DK">Denmark</option>
              <option value="DJ">Djibouti</option>
              <option value="DM">Dominica</option>
              <option value="DO">Dominican Republic</option>
              <option value="TM">East Timor</option>
              <option value="EC">Ecuador</option>
              <option value="EG">Egypt</option>
              <option value="SV">El Salvador</option>
              <option value="GQ">Equatorial Guinea</option>
              <option value="ER">Eritrea</option>
              <option value="EE">Estonia</option>
              <option value="ET">Ethiopia</option>
              <option value="FA">Falkland Islands</option>
              <option value="FO">Faroe Islands</option>
              <option value="FJ">Fiji</option>
              <option value="FI">Finland</option>
              <option value="FR">France</option>
              <option value="GF">French Guiana</option>
              <option value="PF">French Polynesia</option>
              <option value="FS">French Southern Ter</option>
              <option value="GA">Gabon</option>
              <option value="GM">Gambia</option>
              <option value="GE">Georgia</option>
              <option value="DE">Germany</option>
              <option value="GH">Ghana</option>
              <option value="GI">Gibraltar</option>
              <option value="GB">Great Britain</option>
              <option value="GR">Greece</option>
              <option value="GL">Greenland</option>
              <option value="GD">Grenada</option>
              <option value="GP">Guadeloupe</option>
              <option value="GU">Guam</option>
              <option value="GT">Guatemala</option>
              <option value="GN">Guinea</option>
              <option value="GY">Guyana</option>
              <option value="HT">Haiti</option>
              <option value="HW">Hawaii</option>
              <option value="HN">Honduras</option>
              <option value="HK">Hong Kong</option>
              <option value="HU">Hungary</option>
              <option value="IS">Iceland</option>
              <option value="IN">India</option>
              <option value="ID">Indonesia</option>
              <option value="IA">Iran</option>
              <option value="IQ">Iraq</option>
              <option value="IR">Ireland</option>
              <option value="IM">Isle of Man</option>
              <option value="IL">Israel</option>
              <option value="IT">Italy</option>
              <option value="JM">Jamaica</option>
              <option value="JP">Japan</option>
              <option value="JO">Jordan</option>
              <option value="KZ">Kazakhstan</option>
              <option value="KE">Kenya</option>
              <option value="KI">Kiribati</option>
              <option value="NK">Korea North</option>
              <option value="KS">Korea South</option>
              <option value="KW">Kuwait</option>
              <option value="KG">Kyrgyzstan</option>
              <option value="LA">Laos</option>
              <option value="LV">Latvia</option>
              <option value="LB">Lebanon</option>
              <option value="LS">Lesotho</option>
              <option value="LR">Liberia</option>
              <option value="LY">Libya</option>
              <option value="LI">Liechtenstein</option>
              <option value="LT">Lithuania</option>
              <option value="LU">Luxembourg</option>
              <option value="MO">Macau</option>
              <option value="MK">Macedonia</option>
              <option value="MG">Madagascar</option>
              <option value="MY">Malaysia</option>
              <option value="MW">Malawi</option>
              <option value="MV">Maldives</option>
              <option value="ML">Mali</option>
              <option value="MT">Malta</option>
              <option value="MH">Marshall Islands</option>
              <option value="MQ">Martinique</option>
              <option value="MR">Mauritania</option>
              <option value="MU">Mauritius</option>
              <option value="ME">Mayotte</option>
              <option value="MX">Mexico</option>
              <option value="MI">Midway Islands</option>
              <option value="MD">Moldova</option>
              <option value="MC">Monaco</option>
              <option value="MN">Mongolia</option>
              <option value="MS">Montserrat</option>
              <option value="MA">Morocco</option>
              <option value="MZ">Mozambique</option>
              <option value="MM">Myanmar</option>
              <option value="NA">Nambia</option>
              <option value="NU">Nauru</option>
              <option value="NP">Nepal</option>
              <option value="AN">Netherland Antilles</option>
              <option value="NL">Netherlands</option>
              <option value="NV">Nevis</option>
              <option value="NC">New Caledonia</option>
              <option value="NZ">New Zealand</option>
              <option value="NI">Nicaragua</option>
              <option value="NE">Niger</option>
              <option value="NG">Nigeria</option>
              <option value="NW">Niue</option>
              <option value="NF">Norfolk Island</option>
              <option value="NO">Norway</option>
              <option value="OM">Oman</option>
              <option value="PK">Pakistan</option>
              <option value="PW">Palau Island</option>
              <option value="PS">Palestine</option>
              <option value="PA">Panama</option>
              <option value="PG">Papua New Guinea</option>
              <option value="PY">Paraguay</option>
              <option value="PE">Peru</option>
              <option value="PH">Philippines</option>
              <option value="PO">Pitcairn Island</option>
              <option value="PL">Poland</option>
              <option value="PT">Portugal</option>
              <option value="PR">Puerto Rico</option>
              <option value="QA">Qatar</option>
              <option value="RE">Reunion</option>
              <option value="RO">Romania</option>
              <option value="RU">Russia</option>
              <option value="RW">Rwanda</option>
              <option value="NT">St Barthelemy</option>
              <option value="EU">St Eustatius</option>
              <option value="HE">St Helena</option>
              <option value="KN">St Kitts-Nevis</option>
              <option value="LC">St Lucia</option>
              <option value="MB">St Maarten</option>
              <option value="PM">St Pierre & Miquelon</option>
              <option value="VC">St Vincent & Grenadines</option>
              <option value="SP">Saipan</option>
              <option value="SO">Samoa</option>
              <option value="AS">Samoa American</option>
              <option value="SM">San Marino</option>
              <option value="ST">Sao Tome & Principe</option>
              <option value="SA">Saudi Arabia</option>
              <option value="SN">Senegal</option>
              <option value="SC">Seychelles</option>
              <option value="SS">Serbia & Montenegro</option>
              <option value="SL">Sierra Leone</option>
              <option value="SG">Singapore</option>
              <option value="SK">Slovakia</option>
              <option value="SI">Slovenia</option>
              <option value="SB">Solomon Islands</option>
              <option value="OI">Somalia</option>
              <option value="ZA">South Africa</option>
              <option value="ES">Spain</option>
              <option value="LK">Sri Lanka</option>
              <option value="SD">Sudan</option>
              <option value="SR">Suriname</option>
              <option value="SZ">Swaziland</option>
              <option value="SE">Sweden</option>
              <option value="CH">Switzerland</option>
              <option value="SY">Syria</option>
              <option value="TA">Tahiti</option>
              <option value="TW">Taiwan</option>
              <option value="TJ">Tajikistan</option>
              <option value="TZ">Tanzania</option>
              <option value="TH">Thailand</option>
              <option value="TG">Togo</option>
              <option value="TK">Tokelau</option>
              <option value="TO">Tonga</option>
              <option value="TT">Trinidad & Tobago</option>
              <option value="TN">Tunisia</option>
              <option value="TR">Turkey</option>
              <option value="TU">Turkmenistan</option>
              <option value="TC">Turks & Caicos Is</option>
              <option value="TV">Tuvalu</option>
              <option value="UG">Uganda</option>
              <option value="UA">Ukraine</option>
              <option value="AE">United Arab Emirates</option>
              <option value="GB">United Kingdom</option>
              <option value="US">United States of America</option>
              <option value="UY">Uruguay</option>
              <option value="UZ">Uzbekistan</option>
              <option value="VU">Vanuatu</option>
              <option value="VS">Vatican City State</option>
              <option value="VE">Venezuela</option>
              <option value="VN">Vietnam</option>
              <option value="VB">Virgin Islands (Brit)</option>
              <option value="VA">Virgin Islands (USA)</option>
              <option value="WK">Wake Island</option>
              <option value="WF">Wallis & Futana Is</option>
              <option value="YE">Yemen</option>
              <option value="ZR">Zaire</option>
              <option value="ZM">Zambia</option>
              <option value="ZW">Zimbabwe</option>
            </select>
          </div></td>
        <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><span class="Estilo96"></span></td>
      <td><div align="right" class="Estilo88">Select your Country.<br>
        <br> 
        </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><span class="Estilo90"><font color="#FFFFFF"><font color="#FFFFFF">&nbsp;&middot; </font>Gender<span class="Estilo83 Estilo88"><span class="Estilo89">*</span></span></font></span></td>
      <td><div align="right">
          <select name="sex" id="sex">
            <option value="0">Male</option>
            <option value="1">Female</option>
          </select>
      </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><div align="right" class="Estilo88">Select your sex.<br>
        <br> 
        </div></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td colspan=4><div align="center" class="Estilo96 Estilo101"><br>
          <span class="Estilo1">Name, Age Gender and Country can be used to recover lost or forgotten passwords.<br>
          <span class="Estilo2 Estilo3">Never give your personal information to anyone!!! <br>
Final Revolution Staff Never ask for your password.</span><br>
          </span></div></td>
    </tr>
    <tr>
      <td colspan=4>&nbsp;</td>
    </tr>
    <tr>
    <td colspan=4><CENTER>
      <input name="Cadastrar" value="Register" type="submit">
    </CENTER></td>
    </tr>
    </table>
  </div>
</FORM>
<div align="center">
  <?php
if ($_GET['act'] == 'register')
{
	$user = anti_injection($_POST['login']);
    $pass1 = anti_injection($_POST['senha1']);
    $pass2 = anti_injection($_POST['senha2']);
    $email = anti_injection($_POST['email']);
	$age = anti_injection($_POST['age']);
	$country = anti_injection($_POST['country']);
	$name = anti_injection($_POST['name']);
	$sex = anti_injection($_POST['sex']);
	
    if (valida(Array($user,$pass1,$pass2,$email)) == true)
    {
        if ($pass1 == $pass2)
        {
            if (ereg("([0-9,a-z,A-Z])", $user))
            {
                if (ereg("^([0-9,a-z,A-Z]+)([.,_]([0-9,a-z,A-Z]+))*[@]([0-9,a-z,A-Z]+)([.,_,-]([0-9,a-z,A-Z]+))*[.]([0-9,a-z,A-Z]){2}([0-9,a-z,A-Z])?$", $email))
                {
                    $query = mssql_query("SELECT UserID FROM Account WHERE UserID='$user'");
                    $num_rows = mssql_num_rows($query);
                    if ($num_rows == 0)
                    {
                        $query = mssql_query("SELECT * FROM Account WHERE EMail='$email'");
                        $num_rows = mssql_num_rows($query);
                        if ($num_rows == 0)
                        {
                            $query = mssql_query("DECLARE @RC int DECLARE @UserID varchar(20) DECLARE @Password varchar(20) DECLARE @Cert tinyint DECLARE @Name varchar(30) DECLARE @Age smallint DECLARE @Country char(3) DECLARE @Sex tinyint DECLARE @Email varchar(50) DECLARE @Ret int EXECUTE @RC = spWebInsertAccount @UserID = '$user' ,@Password = '$pass1' ,@Cert = '1' ,@Name = '$name' ,@Age = '$age' ,@Country = '$country' ,@Sex = '$sex' ,@Email = '$email' ,@Ret = '1'");
                            if (!$query)
                            {
                                echo "Error on account register, try later!<br>";
                            }
                            else
                            {
                                echo "Account have been created successfully!<br>";
								echo "You will be directed to the main page in 5 seconds!<br>";
								?>
</div>
<meta http-equiv="refresh" content="5;URL=index.php"/>
<div align="center">
  <?php
								}
								
                            }
                        }
                        else
                        {
                            echo "E-mail in use!<br>";
                        }
                    }
                    else
                    {
                        echo "User in use!<br>";
                    }
                }
                else
                {
                    echo "Invalid E-mail!<br>";
                }
            }
            else
            {
                echo "Only use Numbers and Letters in User ID!<br>";
            }
        }
        else
        {
            echo "Password not equal with other!<br>";
        }
    }

$query = mssql_query("SELECT * FROM Account");
$num_rows = mssql_num_rows($query);
echo "Total Accounts: ".$num_rows."<br>";


// Funo Anti Injection

function anti_injection($sql)
{
$sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
$sql = trim($sql);
$sql = strip_tags($sql);
$sql = addslashes($sql);
return $sql;
}

// Verificar Campos Vazios

function valida($campos){
  foreach($campos as $c){
      if(empty($c)){
        echo "All fields needed!<br>";
        return false;
      }else{
        return true;
      }
  }
}
?>
</div>
