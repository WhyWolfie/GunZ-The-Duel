<?php
//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'JHOWROB-PC\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQLEXPRESS)
$DBUser = 'sa'; //Your DB User 
$DBPass = 'r96312067'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZ DB 
$conn = @mssql_connect($DBHost, $DBUser, $DBPass); 
@mssql_select_db($DB); 


?>




 
       
       
       
       
       
       
       
       
       
      