Hello guys this is my last and final release for GunZ
This web maked in 2 Full Days xD really very difficult but is for all ppl of here xD
Web Designed By ~DN

Containt:
-Update, News, Forum News
-Server Status
-User Online
-Download page with mirror's
-Ranking: Clan and Player
-Play Live! to play via Web= COMING SOON
-Register Page
-User CP
-Can Emblem Upload (Only Master = when u loged in user cp u can see)
-Admin Panel V3 By emisand (Only Admin or Mod can see it when u logged in usercp)
-Can Edit your account profile
-Delete Clan
-Lost Password, u can recover your password again ^^
-Disabled Right Button of Mouse for Segurity.

Need to Edit Forgot Password! page


Credits By ~DN
