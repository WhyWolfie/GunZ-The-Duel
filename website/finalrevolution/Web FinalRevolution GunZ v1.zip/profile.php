<?
    }




//Edit Account Info

function ShowEditAccountInfo(){
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $country = clean($_POST['country']);
    $sq = clean($_POST['sq']);
    $sa = clean($_POST['sa']);
    $name = clean($_POST['name']);
    $zip = clean($_POST['zip']);
    $age = clean($_POST['age']);
    $sex = clean($_POST['sex']);
    $address = clean($_POST['address']);

   if($_POST['C1'] == "ON"){

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            $errorcode.="The passwords do not match</br>";
            $era = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Please enter a password of 6 or more characters.</br>";
            $era =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please enter a password.</br>";
            $era = 1;
        }

        if ($era == 0){
            mssql_query("UPDATE Login SET Password = '$pw1'");
        }else{
            $er =1;
        }
   }


        if($email == ""){
            $errorcode.="Please enter an E-Mail.</br>";
            $er = 1;
        }


        if($_POST['C2'] == "ON"){


            if($sq == ""){
                $errorcode.="Please enter a secret question.</br>";
                $ert =1;
            }

            if($sa == ""){
                $errorcode.="Please enter a secret answer.</br>";
                $ert = 1;
            }

            if ($ert == 0){
                mssql_query("UPDATE Account SET sa = '$sa', sq = '$sq'");
            }else{
                $er =1;
            }


        }

        if($er == 0){
            $registered = 1;
            mssql_query("UPDATE Account SET Name = '$name', Email = '$email', Age = '$age', Sex = '$sex', ZipCode = '$zip', Address = '$address'");
            //mssql_query("INSERT INTO Login ([UserID],[AID],[Password],[euCoins])VALUES('$user','$aid','$pw1',0)");
            msgbox("Account information updated","index.php?do=profile");
        }else{
            $errorbox = ErrorBox($errorcode);
        }
    $res1 = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
    $res2 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
    $data = mssql_fetch_assoc($res1);
    $data2 = mssql_fetch_assoc($res2);
        ?>