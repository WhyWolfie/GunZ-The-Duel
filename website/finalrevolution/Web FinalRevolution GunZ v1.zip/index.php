<?
include "config.php";
include "functions.php";

function ParseTitle($content)
{
if($_SESSION[PageTitle] <> "")
{
$r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
//$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
$_SESSION[PageTitle] = "";
return $r;
}else{
$r = str_replace("%TITLE%", "Final Revolution GunZ Web", $content);
//$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
return $r;
}
}
ob_start("ParseTitle");
?>
<head>
<title>Final Revolution GunZ Web &laquo; Index</title>
<style type="text/css">
@import "final.css";
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
var p,i,x; if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
var i,img,nbArr,args=MM_nbGroup.arguments;
if (event == "init" && args.length > 2) {
if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
nbArr[nbArr.length] = img;
for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
if (!img.MM_up) img.MM_up = img.src;
img.src = img.MM_dn = args[i+1];
nbArr[nbArr.length] = img;
} }
} else if (event == "over") {
document.MM_nbOver = nbArr = new Array();
for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
if (!img.MM_up) img.MM_up = img.src;
img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
nbArr[nbArr.length] = img;
}
} else if (event == "out" ) {
for (i=0; i < document.MM_nbOver.length; i++) {
img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
} else if (event == "down") {
nbArr = document[grpName];
if (nbArr)
for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
document[grpName] = nbArr = new Array();
for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
if (!img.MM_up) img.MM_up = img.src;
img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
nbArr[nbArr.length] = img;
} }
}

function MM_swapImgRestore() { //v3.0
var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>

<script type="text/javascript" src="ajax/utilities.js"></script>
<script type="text/javascript" src="ajax/container.js"></script>
<script type="text/javascript" src="functions.js"></script>
</head>

<body onLoad="MM_preloadImages('img/home_on.png','img/ranking_on.png','img/download_on.png','img/register_on.png')">
<div align="center">
  <p align="center"><img src="img/left.gif" width="50" height="40"><a href="index.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('home','','img/home_on.png',1)"><img src="img/Home.png" name="home" width="110" height="40" border="0"></a><a href="http://yourforum.com" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('forum','','img/forum_on.png',0)"><img src="img/forum.png" name="forum" width="110" height="40" border="0"></a><a href="index.php?do=clanrank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('ranking','','img/ranking_on.png',1)"><img src="img/ranking.png" name="ranking" width="110" height="40" border="0"></a><a href="index.php?do=download" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('download','','img/download_on.png',1)"><img src="img/download.png" name="download" width="110" height="40" border="0"></a><a href="register.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('register','','img/register_on.png',1)"><img src="img/register.png" name="register" width="110" height="40" border="0"></a><img src="img/right.gif" width="50" height="40"></p>

  <p align="center"><img src="img/space.gif" width="1" height="1"><img src="img/space.gif" width="500" height="220"></p>
  <div align="center">
    <div align="center">
      <table width="554" border="0">
        <tr>
          <th width="548" scope="col"><marquee>
          <span class="Estilo7">Bem vindos Servidor em BETA TESTE ! Caso encontre Bugs Reporte a um administrator !...</span><img src="img/=).gif" width="51" height="49">
          </marquee></th>
        </tr>
      </table>
      <table width="693" border="0">
      </div>
    </div>
  <tr>
    <th width="687" height="103" scope="col"><div align="center">
    <div align="center">
    <div align="center">
    
  <table border="0" cellpadding="0" cellspacing="0" width="800">
    <table width="100" border="0" align="center">
      </div>
      </div>
      <tr><? echo $_SESSION[SiteMessage];$_SESSION[SiteMessage]=""?>
<tr>
<td width="10">&nbsp;</td>

  <div align="center">
  <td width="778">
    
<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        <td width="800" colspan="3">&nbsp;
        </td>
        </tr>
        <? 
if($_CONFIG[OfflinePage] == "")
{
if(isset($_GET['do']))
{
$do = $_GET['do'];
}else{
$do = "index";
}

if(file_exists("gunz/fr_$do.php"))
{
include "gunz/fr_$do.php";
{
}
}else{
SetMessage("Page Not Found", array("Page '$do' does not exist!"));
header("Location: index.php");
}
}
?>
        
</td>
        </tr>
    </table>
  </div>  <tbody>
  <tr>
  <td width="800" colspan="3">
  </td>
  </tr>

  <div align="center">
    <table width="100" border="0">
        <tr>
          <th scope="col"><img src="img/line.png" width="450" height="19"></th>
        </tr>
        <tr>
          <th scope="col"><font face="Visitor TT1 BRK">@Copyright 2008 ~~ 20013 Gunz The Duel*BETA*. All Rights Reserved.</font></th>
        </tr>
        <tr>
          <th scope="col"><span class="Estilo6"><img src="img/credits.gif" width="450" height="18"></span></th>
        </tr>
      </table>
  </div>
</body>
