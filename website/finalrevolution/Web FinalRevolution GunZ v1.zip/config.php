<?

@session_start();

//MSSQL Server configuration

$_MSSQL[Host]               = "TU-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "pw";
$_MSSQL[DBNa]               = "DB";

//MySQL Server configuration

$_MYSQL[Host]               = "localhost";
$_MYSQL[User]               = "root";
$_MYSQL[Pass]               = "pasword";
$_MYSQL[DBNa]               = "foro";

//Configuration

$_CONFIG[NewsFID]           = 2;
$_CONFIG[EventsFID]         = 0;
$_CONFIG[vBulletinPrefix]   = "xxxxx";
$_CONFIG[ForumURL]          = "http://xxx.tk/";

//Offline page
$_CONFIG[OfflinePage]       = "";




$r = mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mssql_select_db($_MSSQL[DBNa], $r);

?>