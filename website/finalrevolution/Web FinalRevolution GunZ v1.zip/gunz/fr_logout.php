<?
if($_SESSION[AID] <> "")
{
    $u = $_SESSION[UserID];
    $_SESSION[UserID] = "";
    $_SESSION[AID] = "";
    $_SESSION[UGradeID] = "";
    SetMessage("Announcement", array("User ".clean($u)." disconnected successfully."));
    header("Location: index.php");
    die();
}else{
    SetMessage("Announcement", array("You cannot logout that you are not logged in!"));
    header("Location: index.php");
    die();
}

?>