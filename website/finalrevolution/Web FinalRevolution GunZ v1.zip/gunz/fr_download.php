<style type="text/css">
@import "final.css";
</style>
</style><?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
$servercount = $servercount + $srv['CurrPlayer'];
}

function Acortar($cadena){
return substr($cadena,0,12) ."...";
}



?>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body onLoad="MM_preloadImages('file:///C|/AppServ/www/Revolution/page/img/play_on.png')">
<table width="931" border="0" align="center">
  <tr>
    <th width="925" height="884" scope="col"><table width="840" border="0" align="center">
      <tr>
        <th width="834" height="878" scope="col"><table width="818" border="0" align="center" valign="top"> 
            <tr>
              <th width="172" background="img/bar.png" bgcolor="#111111" scope="col"><table width="100" border="0" align="center" >
                <tr>
                  <th height="475" scope="col"><table width="186" border="0" align="center" >
                    <tr>
                      <th width="180" height="403" scope="col"><table width="166" border="0" align="center">
                          <tr>
                            <th height="20" scope="col">&nbsp;</th>
                          </tr>
                          <tr>
                            <th width="160" height="20" scope="col"><br>
                                <?
include "login/file.php"
?></th>
                          </tr>
                          <tr>
                            <th height="38" scope="col"><br>
                                <a href="http://www.yourclienthere.com"><img src="img/direct.png" width="160" height="50" border="0"></a> </th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><p>
                                <br>
                                <?
include "login/howtoplay.php"
?>
                                <br>
                                <br>
                            </p></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col">
                              <table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/clan.php"
?></th>
                                </tr>
                            </table>
                              <br></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/player.php"
?></th>
                                </tr>
                            </table></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><br>
                                <table width="100" border="0" align="center">
                                  <tr>
                                    <th scope="col"><?
include "login/staff.php"
?></th>
                                  </tr>
                                </table></th>
                          </tr>
                        </table>
                          <p><br>
                            <br>
                          </p>
                          </th>
                    </tr>
                  </table>
                  <p>&nbsp;</p>
                      <p><br>
                        <br>
                        <br>
                        <br>
                      </p></th>
                </tr>
              </table>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></th>
              <th width="436" height="857" background="img/bar3.png" bgcolor="#350001" scope="col"><table width="100" border="0">
                  <tr>
                    <th height="82" scope="col"><span class="Estilo2"><br>
                      <br>
                      <img src="img/downloadg.png" width="430" height="60"></span>
                      <hr noshade></th>
                  </tr>
                </table>
                <span class="Estilo2"><span class="Estilo1"><br>
                <br>
                <img src="img/miniarrows.png" width="11" height="10"></span> Download Patch : </span>
                <table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><div align="center"><a href="http://patch.com"><img src="img/patch.png" width="120" height="30" border="0"></a></div></th>
                  </tr>
                  </table>                
                  <br>
                  <span class="Estilo2"><span class="Estilo1"><img src="img/miniarrows.png" width="11" height="10"></span> Download Client : </span><br>
                <table width="270" height="50" border="0" align="center">
                  <tr>
                    <th width="120" height="46" scope="col"><div align="center"><a href="http://mirror1.com"><img src="img/mirror1.png" width="120" height="30" border="0"></a></div></th>
                    <th width="77" scope="col"><div align="center"><a href="http://mirror2.com"><img src="img/mirror2.png" width="120" height="30" border="0"></a></div></th>
                    <th width="59" scope="col"><div align="center"><a href="http://mirror3.com"><img src="img/mirror3.png" width="120" height="30" border="0"></a></div></th>
                  </tr>
                </table>
                <hr noshade>                <p align="left" class="Estilo1"> <img src="img/miniarrows.png" width="11" height="10"> <span class="Estilo81">Requirements <br>
                  <br>
                </span></p>                
                <p align="left" class="Estilo75">Before installing GunZ, please compare your system specifications with the following ones. A computer that meet these minimum requirements or above is required to play GunZ. <br>
                </p>
                <table width="100" border="0" align="center">
                  <tr>
                    <th scope="col"><table width="418" height="141" border="0" align="center" bordercolor="#00CCFF">
                        <tr bgcolor="#710003">
                          <th width="94" bgcolor="#000000" scope="col"><span class="Estilo37">FR</span></th>
                          <th width="161" bgcolor="#000000" scope="col"><span class="Estilo65"> Minimum Requirements </span></th>
                          <th width="149" height="23" bgcolor="#000000" scope="col"><span class="Estilo65"> Recommended Requirements </span></th>
                        </tr>
                        <tr bgcolor="#710003">
                          <th bgcolor="#000000" scope="col"><span class="Estilo65"> OS </span></th>
                          <td height="14" colspan="2" bgcolor="#710003" class="Estilo61" scope="col">
                            <div align="center" class="Estilo40 Estilo66 Estilo31  Estilo74">Windows 2000, Windows XP </div></td>
                        </tr>
                        <tr bgcolor="#710003">
                          <td bgcolor="#000000" scope="col"><div align="center" class="Estilo67 Estilo74"><strong> Direct X </strong></div></td>
                          <td height="14" colspan="2" bgcolor="#710003" scope="col"><div align="center" class="Estilo40 Estilo66 Estilo31  Estilo74"> DirectX 9.0c or above</div></td>
                        </tr>
                        <tr bgcolor="#710003">
                          <th bgcolor="#000000" scope="col"><span class="Estilo65"> CPU </span></th>
                          <td bgcolor="#710003" scope="col"><div align="center" class="Estilo40 Estilo66 Estilo31  Estilo74"> Pentium III 500 MHz </div></td>
                          <td height="14" bgcolor="#710003" scope="col"><div align="center" class="Estilo65"> Pentium III 800 MHz or higher </div></td>
                        </tr>
                        <tr bgcolor="#710003">
                          <td bgcolor="#000000" scope="col"><div align="center" class="Estilo65"><strong> RAM </strong></div></td>
                          <td bgcolor="#710003" scope="col"><div align="center" class="Estilo65"> 256 MB </div></td>
                          <td height="14" bgcolor="#710003" scope="col"><div align="center" class="Estilo65"> 512 MB or above </div></td>
                        </tr>
                        <tr bgcolor="#710003">
                          <td bgcolor="#000000" scope="col"><div align="center" class="Estilo65"><strong> Graphics Card </strong></div></td>
                          <td bgcolor="#710003" scope="col"><div align="center" class="Estilo65"> Direct 3D 9.0 Compatible (Riva TNT) </div></td>
                          <td height="14" bgcolor="#710003" scope="col"><div align="center" class="Estilo65"> GeForce 4MX or higher </div></td>
                        </tr>
                        <tr bgcolor="#710003">
                          <th bgcolor="#000000" class="Estilo61" scope="col"><span class="Estilo65"><strong> Sound Card </strong></span></th>
                          <th height="14" colspan="2" bgcolor="#710003" scope="col"><span class="Estilo37"> Direct3D Sound Compatible </span></th>
                        </tr>
                        <tr bgcolor="#710003">
                          <th bgcolor="#000000" scope="col"><span class="Estilo65"> Mouse </span></th>
                          <th height="16" colspan="2" bgcolor="#710003" scope="col"><span class="Estilo37"> Windows Compatible (Wheel Mouse recommended) </span></th>
                        </tr>
                    </table></th>
                  </tr>
                </table>                
              <p align="left" class="Estilo75 Estilo76"> <br>
                * GunZ does not support GamePad or JoyStick. <br>
* When operating the game on a PC with minimum specifications, make sure you set the resolution at the lowest. (640x480, 16bit color) </p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p><br>
                <br>
                <br>
                <br>
              </p>              </th>
              <th width="196" background="img/bar2.png" bgcolor="#00111C" scope="col"><table width="100" border="0">
                <tr>
                  <th height="73" scope="col"><?
include "login/login.php"
?>
                      <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th height="73" scope="col"><span class="Estilo7">
                    <center>
                    </center>
                    </span>
                      <table width="180" height="103" border="0" align="center">
                        <tr>
                          <th width="174" background="img/status.png" scope="col"><span class="Estilo7">
                            <?
include "gunz/status.php"
?>
                          </span></th>
                        </tr>
                      </table>
                      <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/userrank.php"
?></th>
                    </tr>
                  </table>
                    <br></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/clanrank.php"
?></th>
                    </tr>
                  </table>                  </th>
                </tr>
                <tr>
                  <th scope="col"><br>
                    <table width="100" border="0" align="center">
                      <tr>
                        <th scope="col"><?
include "login/donate.php"
?></th>
                      </tr>
                  </table></th></tr>
                <tr>
                  <th height="41" scope="col">&nbsp;</th>
                </tr>
              </table>
              <div align="center">
                    <p><br>
                    </p>
                    <p><br>
                      <br>
                      <br>
                      <br>
                      <br>
                    </p>
                  </div></th>
            </tr>
        </table>
          <div align="center"></div></th>
      </tr>
    </table>    </th>
  </tr>
</table>
