<?

if($_SESSION[AID] <> "")
{
header("Location: index.php");
die();
}

if(isset($_POST[submit]))
{
$user = clean($_POST[userid]);
$pass = clean($_POST[pass]);

$q = mssql_query("SELECT * FROM Login WHERE UserID = '$user' AND Password = '$pass'");
if(mssql_num_rows($q) == 1)
{
$d = mssql_fetch_assoc($q);
$_SESSION[UserID] = $d[UserID]; $_SESSION[pass] = $d[Password];
$_SESSION[AID] = $d[AID];
$q1 = mssql_fetch_assoc(mssql_query("SELECT UGradeID FROM Account WHERE AID = '{$_SESSION[AID]}'"));
$_SESSION[UGradeID] = $q1[UGradeID];

$url = ($_SESSION[URL] == "") ? "index.php" : $_SESSION[URL];
$_SESSION[URL] = "";

header("Location: $url");
die();
}else{
SetMessage("Announcement", array("You have entered an incorrect user or password."));
header("Location: index.php?do=login");
die();
}
}else{
SetTitle("Final Revolution - Member Login");
}


?>
<style type="text/css">
@import "final.css";
</style>
<body>
<table width="100%" border="0" align="center" style="border-collapse: collapse">
<tr>
<td valign="top">
<div align="center">
<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
<tr>
<td height="24" style="background-image: url('img/large.png'); background-repeat: repeat-x; background-position: center top"><div align="center"><b><font face="Tahoma" size="2">Member Login</font></b></div></td>
</tr>
<tr>
<td bgcolor="#350001">
<div align="center">
<form method="POST" action="index.php?do=login" name="login">
<table width="722" height="100%" border="0" align="center" style="border-collapse: collapse; float:left">
<tr>
<td width="231" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="103" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="10" style="background-repeat: no-repeat; background-position: center top">
</td>
<td width="351" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
<td width="231" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="103" style="background-repeat: no-repeat; background-position: center top">
<div align="right">
<div align="left"><img src="img/miniarrows.png" width="11" height="10"> User ID:</div></td>
<td width="10" style="background-repeat: no-repeat; background-position: center top">
</td>
<td width="351" style="background-repeat: no-repeat; background-position: center top">
<div align="left">
<div align="left">
  <input type="text" name="userid" size="20" class="textLogin">
</div></td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
<td width="231" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="103" style="background-repeat: no-repeat; background-position: center top">
<div align="right">
<div align="left"><img src="img/miniarrows.png" width="11" height="10"> Password:</div></td>
<td width="10" style="background-repeat: no-repeat; background-position: center top">
</td>
<td width="351" style="background-repeat: no-repeat; background-position: center top">
<div align="left">
<div align="left">
  <input type="password" name="pass" size="20" class="textLogin">
</div></td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
<td width="231" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="103" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="10" style="background-repeat: no-repeat; background-position: center top">
</td>
<td width="351" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
<td colspan="4" style="background-repeat: no-repeat; background-position: center top">
<div align="center">
<div align="center">
<input name="log" 

type="image" id="log" onMouseOver="FP_swapImg(1,1,/*id*/'log',/*url*/'img/login_on.png')" 

onmouseout="FP_swapImgRestore()" src="img/login.png" align="middle" width="130" height="30" 

border="0">
</div></td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
<td style="background-repeat: no-repeat; background-position: center top" colspan="5" height="10">
</td>
</tr>
<tr>
<td width="231" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
<td style="background-repeat: no-repeat; background-position: center top" colspan="3">
<p align="left"></td>
<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
</td>
</tr>
<tr>
  <td colspan="4" style="background-repeat: no-repeat; background-position: center top"><div align="center"><a href="index.php?do=register">New user Sing Up Now?</a> | <a href="index.php?do=password">Forgot your Password?</a> <br>
    <br>
  </div></td>
  <td style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
</tr>
</table>
<input type="hidden" name="submit" value="1"></form>
</div>
</td>
</tr>
</table>
</div>
</td>
</tr>
</table>
