<style type="text/css">
@import "final.css";
</style><?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
$servercount = $servercount + $srv['CurrPlayer'];
}

function Acortar($cadena){
return substr($cadena,0,12) ."...";
}



?>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body>
<table width="832" border="0" align="center">
  <tr>
    <th width="826" height="529" scope="col"><table width="820" border="0" align="center">
        <tr>
          <th width="814" height="523" scope="col"><table width="814" border="0" align="center" valign="top">
              <tr>
                <th width="172" rowspan="4" background="img/bar.png" bgcolor="#111111" scope="col"><table width="186" border="0" align="center" >
                    <tr>
                      <th width="180" height="403" scope="col"><table width="166" border="0" align="center">
                          <tr>
                            <th height="20" scope="col">&nbsp;</th>
                          </tr>
                          <tr>
                            <th width="160" height="20" scope="col"><br>
                                <?
include "login/file.php"
?></th>
                          </tr>
                          <tr>
                            <th height="38" scope="col"><br>
                                <a href="http://www.yourclienthere.com"><img src="img/direct.png" width="160" height="50" border="0"></a> </th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><p> <br>
                                    <?
include "login/howtoplay.php"
?>
                                    <br>
                                    <br>
                            </p></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col">
                              <table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/clan.php"
?></th>
                                </tr>
                              </table>
                              <br></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/player.php"
?></th>
                                </tr>
                            </table></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><br>
                                <table width="100" border="0" align="center">
                                  <tr>
                                    <th scope="col"><?
include "login/staff.php"
?></th>
                                  </tr>
                              </table></th>
                          </tr>
                        </table>
                          <p><br>
                              <br>
                        </p></th>
                    </tr>
                  </table>
                    <br>
                </th>
                <th width="432" height="89" scope="col"><table width="432" height="87" border="0" align="center">
                    <tr>
                      <th width="426" height="83" background="img/online.png" scope="col"><div align="center">
                          <table width="412" border="0">
                            <tr>
                              <th width="406" height="77" scope="col"><table width="400" height="74" border="0">
                                  <tr>
                                    <th width="78" scope="col"><span class="Estilo2"><font size="5" face="arial" color="#FF0000">
                                      <?=$servercount?>
                                      </font> <b><font size="2" face="Verdana" color="#FFFFFF"></font></b></span>
                                    <th width="155" height="44" scope="col"><p align="center"><span class="Estilo2"><font size="5" face="arial"><span class="Estilo1"><b><font size="2" face="Verdana" color="#FFFFFF">Players Online</font></b></span></font></span>
                                    <td width="153" rowspan="3"><p align="center">     <? if($_SESSION['AID'] == ""){
                                    $string = "javascript:UserLogin()";
                                }else{
                                    $string = "javascript:LaunchGunZ()";
                                }?>
								<a href="<?=$string?>" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('playlive','','img/play_on.png',0)"><img name="playlive" border="0" src="img/play.png"></a></p></td>
                                  </tr>
                                  <tr>
                                    <td height="19" colspan="2"><div align="center"><span class="Estilo5"><a href="http://yourclienthere.com">Direct Client Download (200mb) </a></span></div></td>
                                  </tr>
                                  <tr>
                                    <td height="2" colspan="2"><div align="center"></div>
                                        <div align="center"></div></td>
                                  </tr>
                              </table></th>
                            </tr>
                          </table>
                      </div></th>
                    </tr>
                </table></th>
                <th width="196" rowspan="4" background="img/bar2.png" bgcolor="#00111C" scope="col"><div align="center">
                    <table width="100" border="0">
                      <tr>
                        <th height="73" scope="col"><?
include "login/login.php"
?>
                            <span class="Estilo7"> </span></th>
                      </tr>
                      <tr>
                        <th height="73" scope="col"><span class="Estilo7">
                          <center>
                          </center>
                          </span>
                            <table width="180" height="103" border="0" align="center">
                              <tr>
                                <th width="174" background="img/status.png" scope="col"><span class="Estilo7">
                                  <?
include "gunz/status.php"
?>
                                </span></th>
                              </tr>
                            </table>
                            <span class="Estilo7"> </span></th>
                      </tr>
                      <tr>
                        <th scope="col"><table width="100" border="0" align="center">
                            <tr>
                              <th scope="col"><?
include "login/userrank.php"
?></th>
                            </tr>
                          </table>
                            <br></th>
                      </tr>
                      <tr>
                        <th scope="col"><table width="100" border="0" align="center">
                            <tr>
                              <th scope="col"><?
include "login/clanrank.php"
?></th>
                            </tr>
                        </table></th>
                      </tr>
                      <tr>
                        <th scope="col"><br>
                            <table width="100" border="0" align="center">
                              <tr>
                                <th scope="col"><?
include "login/donate.php"
?></th>
                              </tr>
                          </table></th>
                      </tr>
                      <tr>
                        <th height="41" scope="col">&nbsp;</th>
                      </tr>
                    </table>
                    <p>&nbsp; </p>
                </div></th>
              </tr>
              <tr>
                <th height="180" bgcolor="#350001" scope="col"><table width="430" height="220" border="0" align="center" background="img/updates.png">
                    <tr>
                      <th width="417" height="176" scope="col"><table width="390" height="138" border="0" align="center" valign="top">
                          <tr>
                            <th height="37" scope="col"><span class="Estilo3"><img src="news/frgw.png" width="165" height="35"></span></th>
                            <th scope="col">&nbsp;</th>
                            <th scope="col"><img src="news/merry.png" width="165" height="35"></th>
                          </tr>
                          <tr>
                            <th width="168" height="95" scope="col"><p align="center" class="Estilo3">1.Bem vindos servidor de Gunz(BETA) TESTE  ~BR.<br>
                                    <br>
                            </p></th>
                            <th width="37" scope="col">&nbsp; </th>
                            <th width="171" scope="col"><div align="center">
                                <p><br>
                                    <span class="Estilo3">1.Caso de Bugs Relate um administrado do servidor <br>
                                  Ass: <br>
                                  <br>
                                  2. Bugs.test <br>
                                  <br>
                                  </span></p>
                            </div></th>
                          </tr>
                      </table></th>
                    </tr>
                </table></th>
              </tr>
              <tr>
                <th height="26" bgcolor="#350001" scope="col"><p><img src="img/entertainment.png" width="430" height="55"></p>
                    <blockquote>
                      <p><img src="img/line2.png" width="350" height="10"></p>
                  </blockquote></th>
              </tr>
              <tr>
                <th height="195" bgcolor="#350001" scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><div align="center"><img src="img/control.gif" width="402" height="187"></div></th>
                    </tr>
                </table></th>
              </tr>
            </table>
              <div align="center"></div></th>
        </tr>
    </table></th>
  </tr>
</table>
