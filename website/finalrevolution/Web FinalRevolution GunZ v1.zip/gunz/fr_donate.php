<style type="text/css">
@import "final.css";
</style><?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
$servercount = $servercount + $srv['CurrPlayer'];
}

function Acortar($cadena){
return substr($cadena,0,12) ."...";
}



?>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body onLoad="MM_preloadImages('file:///C|/AppServ/www/Revolution/page/img/play_on.png')">
<table width="931" border="0" align="center">
  <tr>
    <th width="925" height="662" scope="col"><table width="840" border="0" align="center">
      <tr>
        <th width="834" height="656" scope="col"><table width="818" border="0" align="center" valign="top"> 
            <tr>
              <th width="172" background="img/bar.png" bgcolor="#111111" scope="col"><table width="100" border="0" align="center" >
                <tr>
                  <th height="475" scope="col"><table width="186" border="0" align="center" >
                    <tr>
                      <th width="180" height="403" scope="col"><table width="166" border="0" align="center">
                          <tr>
                            <th height="20" scope="col">&nbsp;</th>
                          </tr>
                          <tr>
                            <th width="160" height="20" scope="col"><br>
                                <?
include "login/file.php"
?></th>
                          </tr>
                          <tr>
                            <th height="38" scope="col"><br>
                                <a href="http://www.yourclienthere.com"><img src="img/direct.png" width="160" height="50" border="0"></a> </th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><p>
                                <br>
                                <?
include "login/howtoplay.php"
?>
                                <br>
                                <br>
                            </p></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col">
                              <table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/clan.php"
?></th>
                                </tr>
                            </table>
                              <br></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/player.php"
?></th>
                                </tr>
                            </table></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><br>
                                <table width="100" border="0" align="center">
                                  <tr>
                                    <th scope="col"><?
include "login/staff.php"
?></th>
                                  </tr>
                                </table></th>
                          </tr>
                        </table>
                          <p><br>
                            <br>
                          </p>
                          </th>
                    </tr>
                  </table>
                  <p>&nbsp;</p>
                      <p><br>
                        <br>
                        <br>
                        <br>
                      </p></th>
                </tr>
              </table>
                <p>&nbsp;</p>
                <p>&nbsp;</p>
                <p>&nbsp;</p></th>
              <th width="436" height="636" background="img/bar3.png" bgcolor="#350001" scope="col"><table width="100" border="0">
                  <tr>
                    <th height="82" scope="col"><span class="Estilo2"><br>
                      <br>
                      <img src="img/donagunz.png" width="430" height="60"></span>
                      <hr noshade></th>
                  </tr>
                </table>
                <p class="Estilo2">&nbsp;</p>
                <table width="424" height="600" border="0" align="center" background="img/donagunzbg.png" style="background-repeat: no-repeat; background-position: center top">
                  <tr>
                    <th width="423" height="206" scope="col"><p>Put here your Paypal Donate for people can donate to your Gunz</p>
                      <p>and you can edit the Top image </p>
                      <p>&quot;Donate To GunZ&quot; you can edit in PSD is in PSD Folder xD Giant</p>
                      <p> Banner edit and put Donate to Your GunZ Name.</p>                      <span class="Estilo84">                    </span></th>
                  </tr>
                </table>                <p>&nbsp;</p>
              <p>&nbsp;</p>
              <p><br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
              </p>              </th>
              <th width="196" background="img/bar2.png" bgcolor="#00111C" scope="col"><table width="100" border="0">
                <tr>
                  <th height="73" scope="col"><?
include "login/login.php"
?>
                      <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th height="73" scope="col"><span class="Estilo7">
                    <center>
                    </center>
                    </span>
                      <table width="180" height="103" border="0" align="center">
                        <tr>
                          <th width="174" background="img/status.png" scope="col"><span class="Estilo7">
                            <?
include "gunz/status.php"
?>
                          </span></th>
                        </tr>
                      </table>
                      <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/userrank.php"
?></th>
                    </tr>
                  </table>
                    <br></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/clanrank.php"
?></th>
                    </tr>
                  </table>                  </th>
                </tr>
                <tr>
                  <th scope="col"><br>
                    <table width="100" border="0" align="center">
                      <tr>
                        <th scope="col"><?
include "login/donate.php"
?></th>
                      </tr>
                  </table></th></tr>
                <tr>
                  <th height="41" scope="col">&nbsp;</th>
                </tr>
              </table>
              <div align="center">
                    <p><br>
                    </p>
                    <p><br>
                      <br>
                      <br>
                      <br>
                      <br>
                    </p>
                  </div></th>
            </tr>
        </table>
          <div align="center"></div></th>
      </tr>
    </table>    </th>
  </tr>
</table>
