<?

if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

?>
<style type="text/css">
@import "final.css";
</style><?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
$servercount = $servercount + $srv['CurrPlayer'];
}

function Acortar($cadena){
return substr($cadena,0,12) ."...";
}



?>
<script language="JavaScript" type="text/JavaScript">
<!--



function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
//-->
</script>
<body onLoad="MM_preloadImages('file:///C|/AppServ/www/Revolution/page/img/play_on.png')">
<table width="840" border="0" align="center">
  <tr>
    <th width="834" height="790" scope="col"><table width="834" border="0" align="center">
      <tr>
        <th width="828" height="784" scope="col"><table width="828" border="0" align="center" valign="top"> 
            <tr>
              <th width="192" background="img/bar.png" bgcolor="#111111" scope="col"><table width="100" border="0" align="center" >
                <tr>
                  <th height="256" scope="col"><table width="186" border="0" align="center" >
                    <tr>
                      <th width="180" height="256" scope="col"><table width="166" border="0" align="center">
                          <tr>
                            <th height="20" scope="col">&nbsp;</th>
                          </tr>
                          <tr>
                            <th width="160" height="20" scope="col"><br>
                                <?
include "login/file.php"
?></th>
                          </tr>
                          <tr>
                            <th height="38" scope="col"><br>
                                <a href="http://www.yourclienthere.com"><img src="img/direct.png" width="160" height="50" border="0"></a> </th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><p>
                                <?
include "login/howtoplay.php"
?>
                                <br>
                                <br>
                            </p></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col">
                              <table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/clan.php"
?></th>
                                </tr>
                            </table></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><table width="100" border="0" align="center">
                                <tr>
                                  <th scope="col"><?
include "login/player.php"
?></th>
                                </tr>
                            </table></th>
                          </tr>
                          <tr>
                            <th height="20" scope="col"><table width="100" border="0" align="center">
                              <tr>
                                <th scope="col"><?
include "login/staff.php"
?></th>
                              </tr>
                            </table></th>
                          </tr>
                        </table>
                          <p>&nbsp;</p>
                          <p>&nbsp;</p></th>
                    </tr>
                  </table>
                  <p>&nbsp;</p>
                      <p>&nbsp;</p></th>
                </tr>
              </table></th>
              <th width="436" height="764" background="img/bar4.png" bgcolor="#350001" scope="col"><table width="100" border="0" align="center">
                  <tr>
                    <th height="106" scope="col"><span class="Estilo2"><br>
                      <br>
                      <img src="img/profile.png" width="430" height="60"></span>
                      <hr noshade></th>
                  </tr>
                </table>
                <br>
                <p class="Estilo84">                <table width="424" height="600" border="0" align="center" background="img/myprofile.png" style="background-repeat: no-repeat; background-position: center top">
                  <tr>
                    <th width="423" height="206" scope="col"><span class="Estilo84"><?
					  include"login/myprofile.php"
					  ?>
                    </span></th>
                  </tr>
                </table>
                </th>
              <th width="186" background="img/bar2.png" bgcolor="#00111C" class="Estilo84" scope="col"><table width="100" border="0">
                <tr>
                  <th height="73" scope="col"><?
include "login/login.php"
?>
                      <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th height="73" scope="col">
                    <center>
                    </center>
                    <table width="180" height="103" border="0" align="center">
                      <tr>
                        <th width="174" background="img/status.png" scope="col"><span class="Estilo7">
                          <?
include "gunz/status.php"
?>
                        </span></th>
                      </tr>
                    </table>
                    <span class="Estilo7"> </span></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/userrank.php"
?></th>
                    </tr>
                  </table></th>
                </tr>
                <tr>
                  <th scope="col"><table width="100" border="0" align="center">
                    <tr>
                      <th scope="col"><?
include "login/clanrank.php"
?></th>
                    </tr>
                  </table>                  </th>
                </tr>
                <tr>
                  <th scope="col"><br>
                    <table width="100" border="0" align="center">
                      <tr>
                        <th scope="col"><?
include "login/donate.php"
?></th>
                      </tr>
                  </table></th></tr>
              </table>
              <div align="center">
                    <p><br>
                    <br>
                      <br>
                    </p>
                    <p>&nbsp; </p>
              </div></th>
            </tr>
        </table>
          <div align="center" class="Estilo84"></div></th>
      </tr>
    </table>    </th>
  </tr>
</table>
