<?

if($_SESSION[AID] <> "")
{
    SetMessage("Announcement", array("If you want to recover your password Log Out first..."));
    header("Location: index.php");
    die();
}

SetTitle("Final Revolution GunZ Web - Retrieve Password");

if( $_GET['step'] == 3 ){
if(isset($_POST[submit]))
{
    $userid     = $_SESSION['RstUserID'];
    $email      = clean($_POST[email]);
    $zip        = $_SESSION[zipcode];
    $address    = clean($_POST[address]);
    $pass1      = clean($_POST[pass1]);
    $pass2      = clean($_POST[pass2]);
    $name       = clean($_POST[name]);

$errorcount = 0;

    if($userid == ""){
        $errorcount++;
        SetMessage("Announcement", array("Put the user ID."));
        header("Location: index.php?do=password");
        die();
    

}

    if($email == ""){
        $errorcount++;
        SetMessage("Announcement", array("Put the E-mail."));
        header("Location: index.php?do=password");
        die();
    }

    if($zip == 

""){
        $errorcount++;
        SetMessage("Announcement", array("Put the ZipCode."));
        header("Location: index.php?do=password");
        die();
    }

    if($address == ""){
       

 $errorcount++;
        SetMessage("Announcement", array("Put the address"));
 

       header("Location: index.php?do=password");
        die();
    }

    if(strlen($pass1) < 6){
        

$errorcount++;
        SetMessage("Announcement", array("Put a password longer (6 points min)"));
        header("Location: index.php?do=password");
        die();
    }

    

if(mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UserID = '$userid'")) == 0){
        $errorcount++;
      SetMessage("Announcement", array("UserID '$userid' not found!"));
        header("Location: index.php?do=password");
        die();
    }

    if($pass1 != $pass2){
        $errorcount++;
SetMessage("Announcement", array("Put the 2 passwords.));
        

header("Location: index.php?do=password");
        die();
    }

    if($errorcount == 0){

    $rs1 = mssql_query("SELECT * FROM Account WHERE UserID = '$userid' AND Email = '$email' AND Zip = '$zip' AND Address = 

'$address' AND Name = '$name'");

    if(mssql_num_rows($rs1) == 0)
    {
         SetMessage("Announcement", array("Incorrect data, checks to enter the correct and try again."));
      header("Location: index.php?do=password");   
         die();
    }else{

        mssql_query("UPDATE Login SET Password = '$pass1' 

WHERE UserID = '$userid'");
        SetMessage("Announcement", array("Password updated for '$userid'"));
        header("Location: index.php?do=login");
        die();
    }


    }
}else{
    

header("Location: index.php?do=password");
    die();
}
}elseif( $_GET['step'] == 2 ){
    

if(isset($_POST[submit])){
        $userid     = clean($_POST[userid]);

        if($userid == ""){
           

 SetMessage("Announcement", array("Put the Name of the user"));
            header("Location: index.php?do=password");
            die();
        }

        $query005 = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");

        if(mssql_num_rows($query005) == 0){
            SetMessage("Announcement", array("User '$userid' not found."));
            header("Location: index.php?do=password");
			die();
        }

        $RstData = mssql_fetch_assoc($query005);
        $_SESSION['RstUserID'] = $userid;
}

?>
<table 

width="58%" border="0" align="center" style="border-collapse: collapse">
					<tr>
					  <td 

valign="top">
						<div align="center">
					

		<table border="1" style="border-collapse: collapse" width="60%" bordercolor="#000000">
	

							<tr>
							

		<td background="img/large.png" height="24" style="background-image: 

url('img/large.png'); background-repeat: no-repeat; background-position: center top">
			

						<div align="center">
						

				        <div align="center"><b><font face="Tahoma" size="2">Retrieve Password </font></b></div></td>
		

						</tr>
								

<tr>
									<td>
			

						<div align="center">
						

				<form method="POST" action="index.php?do=password&step=3" name="resetpwd">
	

										<table border="0" 

style="border-collapse: collapse; float:left" width="408" height="100%">
					

						<tr>
								

				<td width="5" style="background-repeat: no-repeat; background-position: center 

top">&nbsp;
						  </td>
	

											<td 

style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td 

style="background-repeat: no-repeat; background-position: center top" colspan="5" 

background="images/mis_eumember.jpg" height="62">
								

				<div align="center">
								

					<table border="0" style="border-collapse: collapse" width="402" 

height="100%">
													

	<tr>
													

		<td width="10">&nbsp;</td>
									

						<td width="377">&nbsp;</td>
					

										<td width="9">&nbsp;</td>
	

							</tr>
	

													<tr>
	

														

<td width="10">&nbsp;</td>
											

				<td width="377" rowspan="2">
							

								<div align="center">
				

											<div align="center">Please fill in all fields with the necessary information.</div></td>
								

							<td width="9">&nbsp;</td>
				

										</tr>
				

										<tr>
				

											<td 

width="10">&nbsp;</td>
												

			<td width="9">&nbsp;</td>
								

						</tr>
								

						<tr>
								

							<td width="10">&nbsp;</td>
				

											<td 

width="377">&nbsp;</td>
											

				<td width="9">&nbsp;</td>
							

							</tr>
							

						</table>
							

					</div>
									

			</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

									</td>
				

								<td width="178" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

		<td width="7" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

										</td>
			

								</tr>
						

					<tr>
									

			<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
	

					  </td>
		

										<td width="13" 

style="background-repeat: no-repeat; background-position: center top">
						

						<img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">
	

											User ID</td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="center">
				

								<?=$userid?></td>
				

								<td width="7" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

	</tr>
											<tr>
		

										<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
	

											</td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">
										

		              <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top" align="left">
							

					E-Mail</td>
								

				                <td width="178" style="background-repeat: no-repeat; background-position: 

center top" align="left">
											

	                              <div align="right">
	                                <input type="text" name="email" size="20" class="textLogin">
                                  </div></td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
											  <td 

style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; 

background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;</td>
											  <td 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;</td>
											  <td style="background-repeat: no-repeat; 

background-position: center top">&nbsp;</td>
										  </tr>
											<tr>
											  <td 

style="background-repeat: no-repeat; background-position: center top">&nbsp;</td>
											  <td style="background-repeat: no-repeat; 

background-position: center top"> <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
											  <td style="background-repeat: 

no-repeat; background-position: center top" align="left"> Name </td>
											  <td 

style="background-repeat: no-repeat; background-position: center top" align="left"><div align="right">
											    <input type="text" name="name" size="20" class="textLogin">
										      </div></td>
											  <td style="background-repeat: no-repeat; 

background-position: center top">&nbsp;</td>
										  </tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
	

											</td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">
										

		              <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top" align="left">
							

					ZipCode</td>
							

					            <td width="178" style="background-repeat: no-repeat; 

background-position: center top" align="left">
									

			                      <div align="right">
			                        <input type="text" name="zip" size="20" class="textLogin">
		                          </div></td>
								

				<td width="7" style="background-repeat: no-repeat; background-position: 

center top">&nbsp;</td>
											</tr>
		

									<tr>
					

							<td width="5" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

									</td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top" align="left">&nbsp;
							

					</td>
								

				<td width="178" style="background-repeat: no-repeat; background-position: 

center top" align="left">&nbsp;
											

	</td>
												

<td width="7" style="background-repeat: no-repeat; background-position: center top">&nbsp;
				

								</td>
					

						</tr>
								

			<tr>
											

	<td width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

					  </td>
				

								<td width="13" style="background-repeat: 

no-repeat; background-position: center top">
									

			                      <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
			

									<td width="183" 

style="background-repeat: no-repeat; background-position: center top" align="left">
				

								Address</td>
				

								    <td width="178" style="background-repeat: 

no-repeat; background-position: center top" align="left">
							

					                  <div align="right">
					                    <input type="text" name="address" size="20" class="textLogin">
                      </div></td>
		

										<td width="7" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

				</tr>
										

	<tr>
												<td 

width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
				

								</td>
					

							<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
	

					  </td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td 

style="background-repeat: no-repeat; background-position: center top" colspan="5" 

background="images/mis_eumember.jpg" height="64">
								

				<div align="center">
								

					<table border="0" style="border-collapse: collapse" width="402" 

height="100%">
													

	<tr>
													

		<td width="10">&nbsp;</td>
									

						<td width="377">&nbsp;</td>
					

										<td width="9">&nbsp;</td>
	

							</tr>
	

													<tr>
	

														

<td width="10">&nbsp;</td>
											

				<td width="377" rowspan="2">
							

								<div align="center">
				

                                <div align="center">Enter the new password for your account, <br>
                                  please remember
  it!
                                </div></td>
								

							<td width="9">&nbsp;</td>
				

										</tr>
				

										<tr>
				

											<td 

width="10">&nbsp;</td>
												

			<td width="9">&nbsp;</td>
								

						</tr>
								

						<tr>
								

							<td width="10">&nbsp;</td>
				

											<td 

width="377">&nbsp;</td>
											

				<td width="9">&nbsp;</td>
							

							</tr>
							

						</table>
							

					</div>
									

			</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
	

											</td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">
										

		              <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top" align="left">
							

					Password</td>
							

					            <td width="178" style="background-repeat: no-repeat; 

background-position: center top" align="left">
									

			<input type="password" name="pass1" size="20" class="textLogin"></td>
			

									<td width="7" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

				</tr>
										

	<tr>
												<td 

width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
				

								</td>
					

							<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
	

					  </td>
		

										<td width="178" 

style="background-repeat: no-repeat; background-position: center top" align="left">&nbsp;
				

								</td>
					

							<td width="7" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

</tr>
											<tr>
			

									<td width="5" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="13" style="background-repeat: no-repeat; 

background-position: center top">
										

		              <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top" align="left">
							

					Repeat Password </td>
						

						        <td width="178" style="background-repeat: no-repeat; 

background-position: center top" align="left">
									

			<input type="password" name="pass2" size="20" class="textLogin"></td>
			

									<td width="7" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

				</tr>
										

	<tr>
												<td 

width="5" style="background-repeat: no-repeat; background-position: center top">&nbsp;
				

								</td>
					

							<td width="13" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="183" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

					  </td>
				

								<td width="178" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

		<td width="7" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

					  </td>
			

								</tr>
						

					<tr>
									

			<td style="background-repeat: no-repeat; background-position: center top" 

colspan="5">
												<p 

align="center">
												

<input border="0" src="img/okk.png" name="I1" id="okk" width="130" height="30" 

onmouseout="FP_swapImgRestore()" 

onmouseover="FP_swapImg(1,1,/*id*/'okk',/*url*/'img/okk_on.png')" type="image"></td>
	

										</tr>
				

							<tr>
							

					<td width="5" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

							  </td>
				

								<td width="183" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

		<td width="178" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

							  </td>
			

									<td width="7" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

				</tr>
										

	</table>
											<input 

type="hidden" name="submit" value="1">
				</form>
									

</div>			</td>
					

		  </tr>
						  </table>
			

			</div>
					  </td>
	</tr>
</table>
                <?
    }else{
         
    

     die();
    }
}else{
?>
                <table width="58%" border="0" align="center" style="border-collapse: collapse">
	

				<tr>
						<td width="418" valign="top">
			

			<div align="center">
							<table 

border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
				

				<tr>
									<td 

background="img/large.png" height="24" style="background-image: url('images/content_bar.jpg'); 

background-repeat: no-repeat; background-position: center top">
						

			<div align="center">
			<div align="center"><strong><font size="2" face="Tahoma">Retrieve Password </font></strong></div></td>
					

			</tr>
								<tr>
			

						<td>
						

			<div align="center">
									

	<form method="POST" action="index.php?do=password&step=2" name="resetpwd">
				

							<table border="0" style="border-collapse: collapse; 

float:left" width="408" height="100%">
										

	<tr>
												<td 

width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
				

								</td>
					

							<td width="376" style="background-repeat: no-repeat; 

background-position: center top" colspan="3">&nbsp;
									

			</td>
										

		<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

					  </td>
			

							  </tr>
						

					<tr>
									

			<td width="398" style="background-repeat: no-repeat; background-position: center top" 

colspan="5" background="images/mis_eumember.jpg" height="62">
							

					<div align="center">
							

						<table border="0" style="border-collapse: collapse" 

width="402" height="100%">
											

			<tr>
											

				<td width="10">&nbsp;</td>
							

								<td width="377">&nbsp;</td>
			

												<td 

width="9">&nbsp;</td>
												

		</tr>
												

		<tr>
												

			<td width="10">&nbsp;</td>
								

							<td width="377" rowspan="2">
				

											<div align="center">
	

														

                                            <div align="center">Please fill in all fields with the necessary information.</div></td>
						

									<td width="9">&nbsp;</td>
		

							</tr>
		

												<tr>
		

													<td 

width="10">&nbsp;</td>
												

			<td width="9">&nbsp;</td>
								

						</tr>
								

						<tr>
								

							<td width="10">&nbsp;</td>
				

											<td 

width="377">&nbsp;</td>
											

				<td width="9">&nbsp;</td>
							

							</tr>
							

						</table>
							

					</div>
									

			</td>
											

</tr>
											<tr>
			

									<td width="9" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="10" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="184" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

									</td>
				

								<td width="185" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

		<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

										</td>
			

								</tr>
						

					<tr>
									

			<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
	

					  </td>
		

										<td width="10" 

style="background-repeat: no-repeat; background-position: center top">
						

						                  <img border="0" src="img/miniarrows.png" width="11" 

height="10" id="img1764"></td>
											

	<td width="184" style="background-repeat: no-repeat; background-position: center top" align="left">
	

											User ID</td>
		

										<td width="185" 

style="background-repeat: no-repeat; background-position: center top" align="left">
				

								<input type="text" name="userid" size="20" 

class="textLogin"></td>
											

	<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

					  </td>
				

							</tr>
							

				<tr>
										

		<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

					  </td>
			

									<td width="10" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

					<td width="184" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="185" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

					  </td>
				

								<td width="13" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

	</tr>
											<tr>
		

										<td width="401" 

style="background-repeat: no-repeat; background-position: center top" colspan="5">
				

								<p align="center">
				

								<input border="0" 

src="img/okk.png" name="I1" id="okk" width="130" height="30" 

onmouseout="FP_swapImgRestore()" 

onmouseover="FP_swapImg(1,1,/*id*/'okk',/*url*/'img/okk_on.png')" type="image"></td>
	

										</tr>
				

							<tr>
							

					<td width="9" style="background-repeat: no-repeat; 

background-position: center top">&nbsp;
										

		</td>
											

	<td width="10" style="background-repeat: no-repeat; background-position: center top">&nbsp;
			

							  </td>
				

								<td width="184" style="background-repeat: 

no-repeat; background-position: center top">&nbsp;
									

			</td>
										

		<td width="185" style="background-repeat: no-repeat; background-position: center top">&nbsp;
		

							  </td>
			

									<td width="13" 

style="background-repeat: no-repeat; background-position: center top">&nbsp;
						

						</td>
							

				</tr>
										

	</table>
											<input 

type="hidden" name="submit" value="1"></form>
									

</div>
								  </td>
					

			</tr>
							</table>
			

			</div>
						</td>
	</tr>
		

		</table>
                <?
                }
                ?>