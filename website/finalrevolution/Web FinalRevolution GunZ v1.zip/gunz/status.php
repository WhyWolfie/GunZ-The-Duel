<style type="text/css">
@import "final.css";
</style>
<br>
<div align="center">
  <table width="153" border="0">
  <tr>
    <th width="107" scope="col"><div align="left"><font face: "verdana"><font color="#00FF00" size="1">  Hard Server :</font> </font></div></th>
    <th width="36" scope="col"><font face: "verdana">
      <? 
$ip = "127.0.0.1"; 
$port = "6000"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1"> Offline!</font>'; 
else{ 
echo '<font color="#00FF00" size="1"> Online!</font>'; 
fclose($sock); 
} 
?>
    </font></th>
  </tr>
  <tr>
    <th height="20" scope="col"><div align="left"><font face: "verdana"><font color="#FFFF00" size="1"> Clan Server :</font></font></div></th>
    <th scope="col"><font face: "verdana">
      <? $ip = "127.0.0.1"; 
$port = "6005"; 
if (! $sock = @fsockopen($ip, $port, $num, $error, 5)) 
echo '<font color="#FF0000" size="1"> Offline!</font>'; 
else{ 
echo '<font color="#00FF00" size="1"> Online!</font>'; 
fclose($sock); 
} 
?>
    </font></th>
  </tr>
  <tr>
    <th height="14" colspan="2" scope="col"><font face: "verdana"><font color="#0066FF" size="1">Rate Exp: 10x</font></font></th>
    </tr>
</table>
</div>
