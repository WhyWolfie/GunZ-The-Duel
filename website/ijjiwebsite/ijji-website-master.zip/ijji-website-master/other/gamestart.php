 <td height="60" align="center" valign="top"><table width="160" height="58" border="0" align="left" cellpadding="0" cellspacing="0" background="img/playlive_bg_subp01a_160px.gif" style="background-position:top; background-repeat:no-repeat; filter: alpha(opacity=80); -moz-opacity:0.80; opacity:0.80;">
      <tbody><tr>
        <td align="center" height="58"></td>
      </tr>
    </tbody></table><a href="download.php" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('START','','img/ministart02.gif',1)"><img src="img/ministart01.gif" alt="Download" name="START" border="0" style=" float:none; margin-top:5; margin-left:-155; position:absolute;"></a></td>