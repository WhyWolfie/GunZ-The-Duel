<?php
 if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {
	header("Location: index.php");
	exit();
 }
?>
	
	<!-- Copyright Zone -->
      <table width="780" height="70" border="0" cellpadding="0" cellspacing="0" background="img/copyright.jpg" style="background-position:center; background-repeat:no-repeat;">
      <tr>
        <td width="160" height="10"></td>
        <td width="620"><table width="500" border="0" cellpadding="1" cellspacing="0">
          <tr>
            <td class="Estilo1"><b>Copyright 2020 ijji website. Modified and fixed by Tannous. All right reserved.</b></td>
          </tr>
          <tr>
            <td class="Estilo1"><em>GunZ is a registered trademarks of MAIET entertainment, Inc.</em></td>
          </tr>
          <tr>
            <td class="Estilo1"><em>All content related belong to NHN USA, Inc...</em></td>
          </tr>
          <tr>
            <td class="Estilo1">GunZ is a free server. I hope you have fun.</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="center" height="15"></td>
  </tr>
</table></td>
  </tr>
</table></td>
</table>
</body>
</html>