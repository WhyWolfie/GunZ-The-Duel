<?php
/**
 * WebEngine CMS
 * https://webenginecms.org/
 * 
 * @version 1.2.1
 * @author Lautaro Angelico <http://lautaroangelico.com/>
 * @copyright (c) 2013-2020 Lautaro Angelico, All Rights Reserved
 * 
 * Licensed under the MIT license
 * http://opensource.org/licenses/MIT
 */

// Module Title
include('config.php');

$connect = odbc_connect("Driver={SQL Server};Server={$host}; Database={$dbname}", $user, $pass) or die("Can't connect the MSSQL server.");

echo '<div class="page-title"><span>Activate Account</span></div>';
if (isset($_POST['submit'])) {
	$user           = $_POST['user'];

	if ($user == "") {
		echo '<script language="javascript">';
		echo 'alert("Fill in all fields");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	if ($user != $_SESSION['username']) {
		echo '<script language="javascript">';
		echo 'alert("Username does not exist");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	$res1 = odbc_exec($connect, "SELECT * FROM MEMB_INFO WHERE memb___id = '" .$user . "'");
	$usr1 = odbc_fetch_array($res1);
	$pass = $usr1['memb__pwd'];
	$email = $usr1['mail_addr'];
	

    $res = odbc_exec($connect, "SELECT * FROM Login WHERE UserID = '" . $user . "'");
    if (odbc_num_rows($res) >= 1) {
		echo '<script language="javascript">';
		echo 'alert("Username already activate");';
		echo 'document.location = ""';
		echo '</script>';
		die();
    }
       
	$regacc =  odbc_exec($connect, "INSERT INTO Account (UserID, Name, Email, UGradeID, PGradeID, Cash, Event, RegDate) VALUES ('$user', '$user', '$email', 0, 0, 0, 0, GETDATE())");
	$res3 = odbc_exec($connect, "SELECT * FROM Account WHERE UserID = '$user'");
	$usr = odbc_fetch_array($res3);
	$aid = $usr['AID'];
    odbc_exec($connect, "INSERT INTO Login (UserID, AID, Password) VALUES ('$user', '$aid', '$pass')");

	$update = odbc_exec($connect, "SELECT * FROM MEMB_INFO WHERE memb___id = '" .$user . "'");
	$res2 = odbc_exec($connect, "UPDATE MEMB_INFO SET bloc_code = (bloc_code - 1) WHERE memb___id = '" .$user . "'");
	
	echo '<script language="javascript">';
	echo 'alert("Account has been active successfully");';
	echo 'document.location = ""';
	echo '</script>';
	die();

}


?>
<form name="reg" method="POST" action="">
						<table width="400" border="0" align="center">
                            
							<tr>
                              <td width="193" align="left" class="Estilo1">Username:</td>
                              <td class="Estilo1" align="right"><input name="user" type="text" class="Login" size="20" maxlength="20"></td>
                            </tr>
                            
                            <tr>
                              <td colspan="2" align="left" class="Estilo1" height="10"></td>
                            </tr>
                            
                            <tr>
                              <td colspan="2" align="center" class="Estilo1" height="10"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="Estilo1"><input type="submit" value="Activate" name="submit" class="Login"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="Estilo1"></td>
                            </tr>
                    </tbody></table>
						</form>