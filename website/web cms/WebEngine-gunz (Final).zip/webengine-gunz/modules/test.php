<?php
include('config.php');
if(!isset($_SESSION['username'])) {
	echo '<script language="javascript">';
	echo 'alert("You must be logged in");';
	echo 'document.location = ""';
	echo '</script>';
	die();
}


if (isset($_POST['submit'])) {

		$char           = $_POST['char'];
		$cash           = $_POST['cash'];

		$res = odbc_exec($connect, "SELECT * FROM Account WHERE UserID = '" .$_SESSION['username']. "'");
		$usr = odbc_fetch_array($res);
		$aid = $usr['AID'];

		$get1 = odbc_exec($connect, "SELECT * FROM Character WHERE AID  = '" .$aid. "' AND CharNum = 0 AND DeleteFlag = 0");
		$usr1 = odbc_fetch_array($get1);
		$charname1 = $usr1['Name'];
		$get2 = odbc_exec($connect, "SELECT * FROM Character WHERE AID  = '" .$aid. "' AND CharNum = 1 AND DeleteFlag = 0");
		$usr2 = odbc_fetch_array($get2);
		$charname2 = $usr2['Name'];
		$get3 = odbc_exec($connect, "SELECT * FROM Character WHERE AID  = '" .$aid. "' AND CharNum = 2 AND DeleteFlag = 0");
		$usr3 = odbc_fetch_array($get3);
		$charname3 = $usr3['Name'];
		$get4 = odbc_exec($connect, "SELECT * FROM Character WHERE AID  = '" .$aid. "' AND CharNum = 3 AND DeleteFlag = 0");
		$usr4 = odbc_fetch_array($get4);
		$charname4 = $usr4['Name'];

		$res5 = odbc_exec($connect, "SELECT * FROM Account WHERE UserID = '" .$_SESSION['username']. "'");
		$usr5 = odbc_fetch_array($res5);
		$cashchar = $usr5['Cash'];

		$res6 = odbc_exec($connect, "SELECT * FROM Character WHERE Name = '" .$_POST['char']. "'");
		$usr6 = odbc_fetch_array($res6);
		$lcchar = $usr6['LC'];
		if (odbc_num_rows($res6) == 0) {
		echo '<script language="javascript">';
		echo 'alert("Character Name does not exist \n \nTên nhân vật không tồn tại");';
		echo 'document.location = ""';
		echo '</script>';
		die();

		if ($cash >= $lcchar) {
			echo '<script language="javascript">';
			echo 'alert("Not enough Ladder Coins \nYou need to keep at least 1 Ladder Coin in your character \n \nKhông đủ Ladder Coins \nBạn cần giữ lại ít nhất 1 Ladder Coin trong nhân vật");';
			echo 'document.location = ""';
			echo '</script>';
			die();
		}
    }
	
	
	
	echo '<div class="col-xs-8 col-xs-offset-2" style="margin-top:30px;">';
		echo '<form class="form-horizontal" action="" method="post">';
			echo '<div class="form-group">';
				echo '<label for="webengineRegistration1" class="col-sm-4 control-label">'.lang('ladder_txt_2',true).'</label>';
				echo '<select name="char" class="login">';
					echo '<option value=""'.$charname1.'"">'.$charname1.'</option>';
					echo '<option value=""'.$charname2.'"">'.$charname2.'</option>';
					echo '<option value=""'.$charname3.'"">'.$charname3.'</option>';
					echo '<option value=""'.$charname4.'"">'.$charname4.'</option>';
					echo '<span id="helpBlock" class="help-block">'.langf('ladder_txt_3',true).'</span>';
				echo '</select>';
			echo '</div>';
			echo '<div class="form-group">';
				echo '<label for="webengineRegistration3" class="col-sm-4 control-label">'.lang('ladder_txt_6',true).'</label>';
				echo '<div class="col-sm-8">';
					echo '<input type="number" class="form-control" id="webengineRegistration3" name="cash" required>';
					echo '<span id="helpBlock" class="help-block">'.lang('ladder_txt_7',true).'</span>';
				echo '</div>';
			echo '</div>';
			echo '<div class="form-group">';
				echo '<div class="col-sm-offset-4 col-sm-8">';
					echo '<button type="submit" name="submit" value="submit" class="btn btn-primary">'.lang('ladder_txt_8',true).'</button>';
				echo '</div>';
			echo '</div>';
		echo '</form>';
	echo '</div>';
}

?>

