<?php
/**
 * WebEngine CMS
 * https://webenginecms.org/
 * 
 * @version 1.2.2
 * @author Lautaro Angelico <http://lautaroangelico.com/>
 * @copyright (c) 2013-2020 Lautaro Angelico, All Rights Reserved
 * 
 * Licensed under the MIT license
 * http://opensource.org/licenses/MIT
 */
include('config.php');
if(!isset($_SESSION['username'])) {
	echo '<script language="javascript">';
	echo 'alert("You must be logged in");';
	echo 'document.location = ""';
	echo '</script>';
	die();
}

echo '<div class="page-title"><span>'.lang('ladder_txt_1',true).'</span></div>';

$connect = odbc_connect("Driver={SQL Server};Server={$host}; Database={$dbname}", $user, $pass) or die("Can't connect the MSSQL server.");

if (isset($_POST['submit'])) {
	$char           = $_POST['char'];
	$cash           = $_POST['cash'];
	//$user           = $_POST['user'];

	if ( $cash == "" OR $char == "" ) {
		echo '<script language="javascript">';
		echo 'alert("Fill in all fields \n \nKhông được bỏ trống");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	/*if ($user != $_SESSION['username']) {
		echo '<script language="javascript">';
		echo 'alert("Username does not exist");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}*/

	$res1 = odbc_exec($connect, "SELECT * FROM Account WHERE UserID = '" .$_SESSION['username']. "'");
	$usr1 = odbc_fetch_array($res1);
	$cashchar = $usr1['Cash'];

	$res2 = odbc_exec($connect, "SELECT * FROM Character WHERE Name = '" .$char . "'");
	$usr2 = odbc_fetch_array($res2);
	$lcchar = $usr2['LC'];
	if (odbc_num_rows($res2) == 0) {
		echo '<script language="javascript">';
		echo 'alert("Character Name does not exist \n \nTên nhân vật không tồn tại");';
		echo 'document.location = ""';
		echo '</script>';
		die();
    }

	if ($cash >= $lcchar) {
		echo '<script language="javascript">';
		echo 'alert("Not enough Ladder Coins \nYou need to keep at least 1 Ladder Coin in your character \n \nKhông đủ Ladder Coins \nBạn cần giữ lại ít nhất 1 Ladder Coin trong nhân vật");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	$doicash = odbc_exec($connect, "UPDATE Account SET Cash = (Cash + '" .$cash. "') WHERE UserID = '" .$_SESSION['username']. "'");
	$doiladder = odbc_exec($connect, "UPDATE Character SET LC = (LC - '" .$cash. "') WHERE Name = '" .$char. "'");
	echo '<script language="javascript">';
	echo 'alert("Transfer successfully '.$cash.' Cash to '.$char.' \n \nChuyển thành công '.$cash.' Cash đến nhân vật '.$char.'");';
	echo 'document.location = ""';
	echo '</script>';
	die();

}
echo '<div class="col-xs-8 col-xs-offset-2" style="margin-top:30px;">';
		echo '<form class="form-horizontal" action="" method="post">';
			/*echo '<div class="form-group">';
				echo '<label for="webengineRegistration1" class="col-sm-4 control-label">'.lang('ladder_txt_2',true).'</label>';
				echo '<div class="col-sm-8">';
					echo '<input type="text" class="form-control" id="webengineRegistration1" name="user" required>';
					echo '<span id="helpBlock" class="help-block">'.langf('ladder_txt_3',true).'</span>';
				echo '</div>';
			echo '</div>';*/
			echo '<div class="form-group">';
				echo '<label for="webengineRegistration2" class="col-sm-4 control-label">'.lang('ladder_txt_4',true).'</label>';
				echo '<div class="col-sm-8">';
					echo '<input type="text" class="form-control" id="webengineRegistration2" name="char" required>';
					echo '<span id="helpBlock" class="help-block">'.lang('ladder_txt_5',true).'</span>';
				echo '</div>';
			echo '</div>';
			echo '<div class="form-group">';
				echo '<label for="webengineRegistration3" class="col-sm-4 control-label">'.lang('ladder_txt_6',true).'</label>';
				echo '<div class="col-sm-8">';
					echo '<input type="number" class="form-control" id="webengineRegistration3" name="cash" required>';
					echo '<span id="helpBlock" class="help-block">'.lang('ladder_txt_7',true).'</span>';
				echo '</div>';
			echo '</div>';
			echo '<div class="form-group">';
				echo '<div class="col-sm-offset-4 col-sm-8">';
					echo '<button type="submit" name="submit" value="submit" class="btn btn-primary">'.lang('ladder_txt_8',true).'</button>';
				echo '</div>';
			echo '</div>';
		echo '</form>';
	echo '</div>';
?>


	
	
<!--<form name="reg" method="POST" action="">
						<table  border="0" align="center">
                            
							<tr>
                              <td width="100" align="left" class="col-sm-4 control-label">Username:</td>
                              <td class="col-sm-4 control-label" align="right"><input name="user" type="text" class="Login" size="20" maxlength="20"></td>
                            </tr>
							<tr>
                              <td width="100" align="left" class="col-sm-4 control-label">Character:</td>
                              <td class="col-sm-4 control-label" align="right"><input name="char" type="text" class="Login" size="20" maxlength="20"></td>
                            </tr>
							<tr>
                              <td width="100" align="left" class="col-sm-4 control-label">Ladder:</td>
                              <td class="col-sm-4 control-label" align="right"><input type="number" name="cash" type="text" class="Login" size="20" maxlength="20"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="col-sm-4 control-label"><input type="submit" value="Convert" name="submit" class="Login"></td>
                            </tr>
                            <tr>
                              <td colspan="2" align="center" class="col-sm-4 control-label"></td>
                            </tr>
                    </tbody></table>
						</form>
-->