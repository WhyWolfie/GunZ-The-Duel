<?php
/**
 * WebEngine CMS
 * https://webenginecms.org/
 * 
 * @version 1.2.1
 * @author Lautaro Angelico <http://lautaroangelico.com/>
 * @copyright (c) 2013-2020 Lautaro Angelico, All Rights Reserved
 * 
 * Licensed under the MIT license
 * http://opensource.org/licenses/MIT
 */

// Module Title
include('config.php');

echo '<div class="page-title"><span>'.lang('active_txt_1',true).'</span></div>';
if (isset($_POST['submit'])) {
	$user           = $_POST['user'];

	if ($user == "") {
		echo '<script language="javascript">';
		echo 'alert("Fill in all fields \n \nChưa điền tên tài khoản");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	if ($user != $_SESSION['username']) {
		echo '<script language="javascript">';
		echo 'alert("Username does not exist \n \nKhông đúng tài khoản của bạn");';
		echo 'document.location = ""';
		echo '</script>';
		die();
	}

	$res1 = odbc_exec($connect, "SELECT * FROM MEMB_INFO WHERE memb___id = '" .$user . "'");
	$usr1 = odbc_fetch_array($res1);
	$pass = $usr1['memb__pwd'];
	$email = $usr1['mail_addr'];
	

    $res = odbc_exec($connect, "SELECT * FROM Login WHERE UserID = '" . $user . "'");
    if (odbc_num_rows($res) >= 1) {
		echo '<script language="javascript">';
		echo 'alert("Username already activate \n \nTài khoản của bạn đã được kích hoạt rồi");';
		echo 'document.location = ""';
		echo '</script>';
		die();
    }
       
	$regacc =  odbc_exec($connect, "INSERT INTO Account (UserID, Name, Email, UGradeID, PGradeID, Cash, Event, RegDate) VALUES ('$user', '$user', '$email', 0, 0, 0, 0, GETDATE())");
	$res3 = odbc_exec($connect, "SELECT * FROM Account WHERE UserID = '$user'");
	$usr = odbc_fetch_array($res3);
	$aid = $usr['AID'];
    odbc_exec($connect, "INSERT INTO Login (UserID, AID, Password) VALUES ('$user', '$aid', '$pass')");

	$update = odbc_exec($connect, "SELECT * FROM MEMB_INFO WHERE memb___id = '" .$user . "'");
	$res2 = odbc_exec($connect, "UPDATE MEMB_INFO SET bloc_code = (bloc_code - 1) WHERE memb___id = '" .$user . "'");
	
	echo '<script language="javascript">';
	echo 'alert("Account has been active successfully \n \nKích hoạt tài khoản thành công");';
	echo 'document.location = ""';
	echo '</script>';
	die();

}
	echo '<div class="col-xs-8 col-xs-offset-2" style="margin-top:30px;">';
		echo '<form class="form-horizontal" action="" method="post">';
			echo '<div class="form-group">';
				echo '<label for="webengineRegistration1" class="col-sm-4 control-label">'.lang('active_txt_2',true).'</label>';
				echo '<div class="col-sm-8">';
					echo '<input type="text" class="form-control" id="webengineRegistration1" name="user" required>';
					echo '<span id="helpBlock" class="help-block">'.langf('active_txt_3',true).'</span>';
				echo '</div>';
			echo '<div class="form-group">';
				echo '<div class="col-sm-offset-4 col-sm-8">';
					echo '<button type="submit" name="submit" value="submit" class="btn btn-primary">'.lang('active_txt_4',true).'</button>';
				echo '</div>';
			echo '</div>';
		echo '</form>';
	echo '</div>';

