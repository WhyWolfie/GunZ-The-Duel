<?
include "secure/functions.php";
include "secure/config.php";

    $cid = clean($_GET['cid']);
	
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	
    $res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'");
    $clan = mssql_fetch_assoc($res2);
	
    $res3 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'");
    $claninfo = mssql_fetch_assoc($res3);
	
	$res4 = mssql_query("SELECT * FROM Account WHERE UGradeID = '".$_SESSION['UGradeID']."'");
    $acc = mssql_fetch_assoc($res4);
	
	$ugrade = $acc['UGradeID'];
	$pgrade = $acc['PGradeID'];
	
	$grade = GetRankByGrade($ugrade);
	$sex = GenderShowChar($char['CID']);

    $img = "img/tag.png";

    if($cid == "")
       $cid = 1;

    if($claninfo == "")
       $claninfo = "-";

header("Content-type: image/png");
$i = imagecreatefrompng($img);

$name = $char['Name'];
$level = levelstats($char['XP']);
$xp = $char['XP'];
$clan = $claninfo['Name'];
$kills = $char['KillCount'];
$deaths = $char['DeathCount'];
$tokens = $char['Tokens'];
$prestige = $char['PLevel'];
	if($prestige >= 11)
		$prestige = "Max";
$white = imagecolorallocate($i, 255,255,255);
$orange = imagecolorallocate($i, 255,119,0);
$grey = imagecolorallocate($i, 80,80,80);
$font = "fonts/BEBASNEUE.OTF";

imagettftext($i, 11, 0, 220, 30,$white,$font,'Sex : '.$sex);
imagettftext($i, 11, 0, 220, 45,$white,$font,'Clan : '.$clan);
imagettftext($i, 11, 0, 220, 75,$white,$font,'Level : '.$level);
imagettftext($i, 11, 0, 220, 90,$white,$font,'EXP : '.$xp);
imagettftext($i, 11, 0, 220, 120,$white,$font,'Kills : '.$kills);
imagettftext($i, 11, 0, 220, 135,$white,$font,'Deaths : '.$deaths);
imagettftext($i, 11, 0, 220, 160,$white,$font,'Tokens : '.$tokens);

imagettftext($i, 13, 0, 15, 136,$orange,$font,$name);
imagettftext($i, 14, 0, 15, 155,$grey,$font, $grade);
imagettftext($i, 20, 0, 15, 180,$white,$font,'Prestige '.$prestige);

imagepng($i);
imagedestroy($i);
?>
