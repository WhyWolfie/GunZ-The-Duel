<?
session_start();
header('Cache-control: private');

include "secure/config.php";
include "secure/functions.php";

include "other/title_links.php";
include "other/copyrights.php";

if(isset($_GET['gunz']))
{
	$do = $_GET['gunz'];
} else 
{
	$do = "index";
}

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
		<html>
			<head>
				<link rel="shortcut icon" href="img/icon/01_favicon.ico" type="image/x-icon"/>
				<title>'.$_GUNZ[NAME].' | /Title/</title>
				<style type="text/css">
					<!--
						@import \'css/style.css\';';
						if($_MODE[BGMODE] == 1) { echo '@import \'css/bg.css\';'; }
						echo '@import \'css/main.css\';
						@import \'css/header.css\';
						@import \'css/content.css\';
						@import \'css/footer.css\';
						@import \'css/navigation.css\';
						@import \'css/usermenu.css\';';
						if(!isset($_GET['gunz'])) { echo '@import \'css/topranks.css\'; @import \'css/recentitems.css\';'; }
						if($_GET['gunz'] == "register" || $_GET['gunz'] == "accountinfo" || $_GET['gunz'] == "tags" || $_GET['gunz'] == "usercp" || $_GET['gunz'] == "success" || $_GET['gunz'] == "error") { echo '@import \'css/accountinfo.css\';'; }
						if($_GET['gunz'] == "members" || $_GET['gunz'] == "resetpass") { echo '@import \'css/members.css\';'; }
						if($_GET['gunz'] == "downloads") { echo '@import \'css/downloads.css\';'; }
						if($_GET['gunz'] == "rankings" || $_GET['gunz'] == "player" || $_GET['gunz'] == "clan") { echo '@import \'css/rankings.css\';'; }
						if($_GET['gunz'] == "individuals") { echo '@import \'css/players.css\';'; }
						if($_GET['gunz'] == "guilds") { echo '@import \'css/clans.css\';'; }
						if($_GET['gunz'] == "store" || $_GET['gunz'] == "itemshop" || $_GET['gunz'] == "eventshop" || $_GET['gunz'] == "prestigeshop" ) { echo '@import \'css/shop.css\';'; }
						if($_GET['gunz'] == "emupload") { echo '@import \'css/clanemblem.css\';'; }
						if($_GET['gunz'] == "donate" || $_GET['gunz'] == "orderform" ) { echo '@import \'css/donation.css\';'; }
						if($_MODE[WEB] == 0) { echo '@import \'css/maintenance.css\';'; }
					echo '-->
				</style>
				<!--[if gte IE 9]>
					<script type="text/javascript" src="scripts/jquery-2.0.2.min.js"></script>
				<![endif]-->
				<!--[if lte IE 8]>
					<script type="text/javascript" src="scripts/jquery-1.10.1.min.js"></script>
				<![endif]-->
				<script type="text/javascript" src="scripts/jquery-1.3.2.min.js"></script>
			</head>		
			<body>
				<center>';
					include "block/userblock.php";
					echo '<div id="header">';
						include "other/header.php";
					echo '</div>
					<div id="content">
						<div class="content clearfix">';
							if($_MODE[WEB] == 1) 
							{
								include "other/navigation.php";
								include "other/userside.php";
								if(file_exists("include/gunz_".$do.".php"))
								{
									include "include/gunz_".$do.".php";
								} else 
								{
									alertbox("If you are getting this message, it means that we are still in progress of working on this page for you guy to have access to. Please bear with us.","{$_SERVER['HTTP_REFERER']}");
								}					
							} elseif($_MODE[WEB] == 0)
							{
								include "mode/mod_maintenance.php";
							}
						echo '</div>
					</div>
					<div id="footer">
						<div class="footer"></div>
					</div>
				</center>
			</body>
		</html>';
?>