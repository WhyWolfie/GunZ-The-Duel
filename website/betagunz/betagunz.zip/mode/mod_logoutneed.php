<?
	if($_SESSION['AID'] <> "")
	{
		alertbox("This page is unavailable to you because you are logged in. Please logout to access this page.",$_TITLE[INDEX]);
	}
?>