<div id="maintenance">
	<div class="maintenance">
		<p>
			Website is currently offline at this very moment. Please visit our forum to get the latest information. <br/>
			<a href="<? echo $_LINK[FORUM]; ?>">Click here to visit our forum or community</a>
		</p>
	</div>
</div>