<?
	if($_SESSION['AID'] == "")
	{
		alertbox("You do not have access to this page because you are not logged in.","index.php");
	}
?>