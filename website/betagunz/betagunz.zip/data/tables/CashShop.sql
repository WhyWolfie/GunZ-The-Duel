BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE [dbo].[CashShop] ADD
	[Name] [varchar](256) NULL,
	[TotalPoint] [int] NULL,
	[ResSex] [tinyint] NULL,
	[ResRace] [tinyint] NULL,
	[ResLevel] [int] NULL,
	[Slot] [tinyint] NULL,
	[Weight] [int] NULL,
	[BountyPrice] [int] NULL,
	[Damage] [int] NULL,
	[Delay] [int] NULL,
	[EffectID] [int] NULL,
	[Controllability] [int] NULL,
	[Magazine] [int] NULL,
	[ReloadTime] [int] NULL,
	[SlugOutput] [tinyint] NULL,
	[Gadget] [int] NULL,
	[HP] [int] NULL,
	[AP] [int] NULL,
	[MaxWeight] [int] NULL,
	[SF] [int] NULL,
	[FR] [int] NULL,
	[CR] [int] NULL,
	[PR] [int] NULL,
	[LR] [int] NULL,
	[BlendColor] [int] NULL,
	[ModelName] [varchar](64) NULL,
	[Description] [varchar](max) NULL,
	[MaxBullet] [int] NULL,
	[LimitSpeed] [tinyint] NULL,
	[IsCashItem] [tinyint] NULL,
	[Control] [int] NULL,
	[Duration] [varchar](64) NULL,
	[Selled] [varchar](50) DEFAULT((0))
GO
COMMIT


