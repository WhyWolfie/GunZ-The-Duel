USE [GunzDB]
GO

/****** Object:  Table [dbo].[EventCashShop]    Script Date: 7/6/2013 7:04:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[EventCashShop](
	[CSID] [int] NOT NULL,
	[ItemID] [int] NOT NULL,
	[NewItemOrder] [tinyint] NULL,
	[EventPrice] [int] NOT NULL,
	[WebImgName] [varchar](64) NULL,
	[Opened] [tinyint] NULL,
	[RegDate] [datetime] NULL,
	[RentType] [tinyint] NULL,
	[Name] [varchar](256) NULL,
	[TotalPoint] [int] NULL,
	[ResSex] [tinyint] NULL,
	[ResRace] [tinyint] NULL,
	[ResLevel] [int] NULL,
	[Slot] [tinyint] NULL,
	[Weight] [int] NULL,
	[BountyPrice] [int] NULL,
	[Damage] [int] NULL,
	[Delay] [int] NULL,
	[EffectID] [int] NULL,
	[Controllability] [int] NULL,
	[Magazine] [int] NULL,
	[ReloadTime] [int] NULL,
	[SlugOutput] [tinyint] NULL,
	[Gadget] [int] NULL,
	[HP] [int] NULL,
	[AP] [int] NULL,
	[MaxWeight] [int] NULL,
	[SF] [int] NULL,
	[FR] [int] NULL,
	[CR] [int] NULL,
	[PR] [int] NULL,
	[LR] [int] NULL,
	[BlendColor] [int] NULL,
	[ModelName] [varchar](64) NULL,
	[Description] [varchar](max) NULL,
	[MaxBullet] [int] NULL,
	[LimitSpeed] [tinyint] NULL,
	[IsCashItem] [tinyint] NULL,
	[Control] [int] NULL,
	[Duration] [varchar](64) NULL,
	[Selled] [varchar](50) NOT NULL,
 CONSTRAINT [EventCashShop_PK] PRIMARY KEY CLUSTERED 
(
	[CSID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[EventCashShop] ADD  CONSTRAINT [DF_EventCashShop_Selled]  DEFAULT ((0)) FOR [Selled]
GO


