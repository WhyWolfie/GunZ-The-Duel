USE [GunzDB]
GO

/****** Object:  Table [dbo].[PayPal]    Script Date: 6/5/2013 10:21:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[PayPal](
	[PPID] [int] IDENTITY(1,1) NOT NULL,
	[AID] [int] NOT NULL,
	[Date] [datetime] NULL,
	[TransactionID] [varchar](60) NULL,
	[Amount] [varchar](max) NULL,
	[Email] [varchar](max) NULL,
 CONSTRAINT [PK_PayPal] PRIMARY KEY CLUSTERED 
(
	[PPID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


