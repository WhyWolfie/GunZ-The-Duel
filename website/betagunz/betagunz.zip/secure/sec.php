<?
function writeToLogFile($msg)
{
    $today = date("Y_m_d"); 
    $logfile = "../userslogs/".$today."_log_SQL_INJECTIONS.txt"; 
    $dir = '';
    $saveLocation=$logfile;
    $fp = @fopen( $saveLocation,"r");
    $Data = @fread($fp, 800000);

	if (!$handle = @fopen($saveLocation, "w+b"))
    {
		echo "error";
		exit;
	}
	else
	{
		if(@fwrite($handle,"$msg\r\n SQL Injection detected\r\n$Data")===FALSE) 
		{
			echo "geen error";
			exit;
		}
		@fclose($handle);
	}
}

function anti_injection($sql)
{
	$sql = preg_replace(sql_regcase("/(select|from|insert|delete|union|0x|cast|exec|varchar|insert into|delete from|update account|update login|update character|ugradeid|drop table|show tables|name|password|login|account|login|clan|character|set|where|#|\*|--|\\\\)/"),"",$sql);
	$sql = trim($sql);
	$sql = strip_tags($sql);
	$sql = addslashes($sql);
	$sql = str_replace("'", "''", $sql);
	return $sql;
}

function valida($campos)
{
	foreach($campos as $c)
	{
		if(empty($c))
		{ 
			alertbox("SQL injection detected.","index.php");
			die();
			
			$time = date("M j G:i:s Y"); 
			$ip = getenv('REMOTE_ADDR');
			$userAgent = getenv('HTTP_USER_AGENT');
			$referrer = getenv('HTTP_REFERER');
			$query = getenv('QUERY_STRING');
			
			$msg = "IP: " . $ip . " TIME: " . $time . " REFERRER: " . $referrer . " SEARCHSTRING: " . $query;
			writeToLogFile($msg);
			return false;
		}
		else
		{
			return true;
		}
} 	}
?> 
