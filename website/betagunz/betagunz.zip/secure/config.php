<?
/* ------------------------------------------------------------------------------------------------------------------------------------------------ *
 *	This is the configuration file to most of this Gunz website	features. In order to use this, you must set the settings by yourself to your 		*
 *	settings and database information manually. If you are having troubles setting up the files, please be sure to look at the errors that the 		*
 *	website is telling you. It will help you a lot when you look at the errors. It will most likely display the syntax errors that you're having 	*
 *	troubles with. These files were mainly used for EnixGunZ files and database. You will probably encounter some problems with missing database	* 
 *	tables and other columns in the tables. There should be comments that will help you with understanding the main function and codes of the 		*
 *	website. Any problems that you have will have to be dealt with yourself as I cannot provide support to fix your mistakes. This website is 		*
 *	fully designed and coded by MakakiyoGFX or Anju from RaGEZONE forums. Any creditial of others will not provide support to the one that uses 	*
 *	this. This belongs to the creator which is Anju or MakakiyoGFX. Please be mature and take full responsibility of the things you use from 		*
 *	others' inventation. By	this, you will not add your own name into the credits unless you have made your own changes and modification to the 	*
 *	coding such as adding your own features that isn't coded by MakakiyoGFX's codes.																*
 *																																					* 
 *	MOST SETTINGS ARE CHANGABLE HERE. IF YOU KNOW WHAT YOU'RE DOING TO APPLY WHATEVER YOU WANT, GO AHEAD. ELSE YOU WILL MOST LIKELY CAUSE ERRORS  	*
 * ------------------------------------------------------------------------------------------------------------------------------------------------ */

date_default_timezone_set('America/Denver');

//MSSQL Server configuration
	$_MSSQL[Host]	= "TU-PC\SQLEXPRESS";
	$_MSSQL[User]   = "sa";
	$_MSSQL[Pass]	= "asdada";
	$_MSSQL[DBNa]   = "GunzDB";

//MSSQL connection
$_ERROR[MSG]=	'Could not connect to the database.';
$_MSSQLCON 	= 	mssql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die($_ERROR[MSG]);
				mssql_select_db($_MSSQL[DBNa], $_MSSQLCON);
$_ODBCCON	=	odbc_connect("Driver={SQL Server}; Server={$_MSSQL[Host]}; Database={$_MSSQL[DBNa]}", $_MSSQL[User], $_MSSQL[Pass]) or die($_ERROR[MSG]);

// Plugins Configuration. Modes are dependent on the type of features that is applied for
$_MODE[BGMODE]			=	0;				//1 - fixed, 0 - none. Sets the background image to either scroll with the page or not
$_MODE[WEB]				= 	1;				//1 - On, 0 - Off. Sets the website in maintenance mode or online mod0
$_MODE[CHECKPASS]		=	1;				//1 - checkpass-2.0.0.min.js, 0 - checkpass-1.0.0.min.js
$_MODE[PRESTIGE]		=	1;				//1 - On, 0 - Off. Sets the mode available or unavailable to users
$_MODE[CONVERT]			=	0;				//1 - Tokens (ECoins), 0 - Coins (Coins)

$_MODE[COINS]			=	10;				/* 	Setting the value will show how much it cost for the name change with coins. */
$_MODE[UNBANCOST]		=	10 * 10;		/* 	Setting the value will show the cost of how much it will be for the unban with coins */
$_MODE[PTOKENS]			=	5;				/*	Setting the value will show the multiplier for prestige tokens being converted to either coins or tokens */
$_MODE[DONATECOINS]		=	1;				/*	Setting the value will multiply the number of coins with the given value */
/*	Note: you can also do something like this "5 * 10" to make it 50 for example. */

$_MODE[EXPMIN]			=	23139900;		/*	EXP points value of the minimum requirement to prestige or rebirth your character */
/*	Note: you can check your MinEXP in your dbo.Level database table */

//Server configuration and ports for the server information. Do not change unless you know what you're doing
$_SERV[IP]				=	"127.0.0.1"; 	//Server IP or Domain
$_AGENT[PORT]			=	7777;			//Agent Port. Default: 7777
$_LOC[PORT]				=	8900; 			//Locator Port. Default: 8900
$_MATCH[PORT]			=	6000; 			//Server Port. Default: 6000

// Below is the dictionary for when you click on the restore database. You have to make sure it's the dictionary where the MSSQL created the folder of the database.
$_DICT['FULL']			=	"C:\Program Files (x86)\Microsoft SQL Server\MSSQL11.SQLEXPRESS\MSSQL\Backup";
/* -------------------------------------------------------------------------------------------------------------------------------------------------------------------- *
 *	It is recommended to have the location before to the database files like MSSQL11."FOLDERNAME". Otherwise there will be access denied permission for you to backup	*
 *	Note: DO NOT ADD "\" at the end of the dictionary location. For example, "C:\BACKUP\". There is a reason why there isn't a "\" after the word "Backup", so do not 	*
 *	try it yourself. You'll know what I'm talking about if you try it yourself																							*
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------- */
 
//Configuration Server name and title
$_GUNZ[NAME]		=	"GunZ";
$_GUNZ[SERV]		=	"Servername";
$_GUNZ[YEAR]		=	"2003";
$_SOFT[FORUM]		=	"IP.Board 3.3.0";

//Downloadable links. Changable is available
$_LINKS[DOWN01]		=	"http://www.mediafire.com";
$_LINKS[DOWN02]		=	"http://www.depositfile.com";
$_LINKS[DOWN03]		=	"http://www.gigasize.com";

//Below are the _LINKs you can edit for other sites such as Facebook, Youtube, etc...
$_LINK[FACEBOOK]		=	"http://www.facebook.com/"; //facebook url
$_LINK[YOUTUBE]			=	"http://www.youtube.com/"; //youtube channel url
$_LINK[TWITTER]			=	"https://twitter.com/"; //twitter url
$_LINK[VOTE]			=	"http://www.YOURVOTESITE.com"; //vote url

$_LINK[WEB]				=	"http://www.YOURSERVERNAMEDOMAIN.com"; //main website/domain url
$_LINK[GUNZ]			=	"http://www.YOURGUNZDOMAIN.com"; //main url to your gunz server
$_LINK[FORUM]			=	"http://www.YOURFORUMURL.com"; //forum url


$_URL[YOUTUBEVID]		=	"http://www.youtube.com/embed/o9mPN60MLvc"; //youtube video url

//Facebook Integration Configuration settings
$_FACEBOOK[APPID]		=	"561615743882799";
$_FACEBOOK[SECRET]		=	"dd7b086c7101c6df2391925351aa463b";

?>