<div style="text-align: left; border-color: rgb(255, 153, 0);">
	<h3>GUNZ� MEMBERSHIP AGREEMENT</h3>
	<p><b>1) -No hacks here. Anything that is similar to, or is a type of massive hack, respawn hack, console and other abnormal gameplay is NOT allowed.</b></p>
	<p><em>-1st Offence: IP Permanent ban.</em></p>
	<p><b>2) -ALT codes spaces Glitch names (ASCIIs) are no longer allowed, /ASCII. Colored names are prohibted as well.</b></p>
	<p><em>-1st Offence: Permanent ban</em></p>
	<p><b>3) -Spamming of the lobby's and/or channels is not allowed, and spamming the administrator while he is in the middle of work is not allowed either.</b></p>
	<p><em>-1st Offence: Warning</em></p>
	<p><em>-2nd Offence: Banned 1 day</em></p>
	<p><em>-3rd Offence: 3 Days Banned</em></p>
	<p><em>-4th Offence: Permanent ban</em></p>
	<p><b>4) -Disrespecting the administrators and/or other members will get you warned, and banned if continued.</b></p>
	<p><em>-1st Offence: Warning</em></p>
	<p><em>-2nd Offence: 2+ Days Banned</em></p>
	<p><em>-3rd Offence: Permanent ban</em></p>
	<p><b>5) -Swap is not ALLOWED</b></p>
	<p><em>-1st Offence: Infracted</em></p>
	<p><em>-2nd Offence: Level reset (Lvl 1, XP: 0, BT: 1000)</em></p>
	<p><em>-3rd Offence: Permanent ban</em></p>
	<p><b>6) -Clan war Glitch (Leaving on example 2-0) And "Ninja-Step" is not ALLOWED</b></p>
	<p><em>-1st Offence: 7 Days Banned</em></p>
	<p><em>-2nd Offence: 1 Month Banned</em></p>
	<p><em>-3rd Offence: Permanent ban</em></p>
	<p><b>7) - Force lagging is not allowed either.</b></p>
	<p><em>-1st Offence: 5 days banned.</em></p>
	<p><em>-2nd Offence: Permanent ban.</em></p>
	<p><b>8) -Insulting members/staff is not ALLOWED</b></p>
	<p><em>-1st Offence: 1 Days Banned</em></p>
	<p><em>-2nd Offence: 7 Days Banned</em></p>
	<p><em>-3rd Offence: 14 Days Banned</em></p>
	<p><em>-4th Offence: Permanent ban</em></p>
	<p><b>9) -Impersonating staff members is prohibited.</b></p>
	<p><em>-1st Offence: Warning/Mute</em></p>
	<p><em>-2nd Offence: 1 Days Banned</em></p>
	<p><em>-3rd Offence: 7 Days Banned</em></p>
	<p><em>-4th Offence: Permanent ban</em></p>
	<p><b>10) -Spamming/begging any other players is not allowed too.</b></p>
	<p><em>-1st Offence:Warning</em></p>
	<p><em>-2nd Offence:Mute for 1 day</em></p>
	<p><em>-3rd Offence:Mute for 1 week.</em></p>
	<p><em>-4th Offence:Permanent mute.</em></p>
	<p><b>11) -Not allowed to shared accounts</b></p>
	<p><em>-1st Offence: 7 days Banned</em></p>
	<p><em>-2nd Offence: Permanent ban</em></p>
</div>