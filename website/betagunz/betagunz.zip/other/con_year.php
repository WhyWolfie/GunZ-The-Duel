<?

$curryear = date("Y");

for ($x = 1900; $curryear >= $x; $curryear--) 
{
    echo '<option value="'.$curryear.'" ';
		if($_SESSION <> "") {
			if($fr['BirthYear'] == $curryear) { echo 'selected'; }
		}
	echo '>'.$curryear.'</option>';
}

?>