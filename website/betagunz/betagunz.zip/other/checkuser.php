<?
	include	'../secure/config.php';

	if(isset($_POST['user']))
	{
		$user = $_POST['user'];
		$check_for_username = mssql_query("SELECT UserID FROM Account WHERE UserID = '$user'");

		if(mssql_num_rows($check_for_username))
		{
			echo '1';//If there is a&nbsp; record match in the Database - Not Available
		} else
		{
			echo '0';//No Record Found - Username is available
		}
	}
?>