<?
echo '<div id="navMenu">
	<p><a href="'.$_TITLE[INDEX].'">Home</a></p>
	<p><a href="'.$_LINK[FORUM].'">Forum</a></p>
	<p><a href="'.$_TITLE[LOAD].'">Downloads</a></p>
	<p><a href="'.$_TITLE[RANKS].'">Rankings</a></p>
	<p><a href="'.$_TITLE[STORE].'">Store</a></p>
	<p><a href="'.$_LINK[VOTE].'">Vote</a></p>';
echo '</div>';
?>