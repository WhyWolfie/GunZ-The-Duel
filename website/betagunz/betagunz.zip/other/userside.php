<?
echo '<div id="userMenu">';
	if($_SESSION['UserID'] == "")
	{
		echo '<p><a href="'.$_TITLE[REGIST].'">Sign Up Now!</a></p>
			<p><a href="'.$_TITLE[MEMBER].'">Member Login</a></p>';
	} elseif($_SESSION['UserID'] <> "")
	{
		echo '
		<p><a href="'.$_TITLE[ACCDET].'">Account Info</a></p>
		<p><a href="'.$_TITLE[DONATE].'">Support Us</a></p>
		<p><a href="'.$_TITLE[SIGN].'">GunZ Tag</a></p>
		<div class="spacingNav"></div>
		<p><a href="'.$_TITLE[USERCP].'">User Panel</a></p>
		<p><a href="'.$_TITLE[LOGOUT].'">Logout</a></p>';
	}
echo '
	<div class="spacingNav"></div>
	<p><a href="'.$_LINK[FACEBOOK].'">Facebook </a></p>
	<p><a href="'.$_LINK[YOUTUBE].'">Youtube</a></p>
	<p><a href="'.$_LINK[TWITTER].'">Twitter</a></p>
</div>';
?>