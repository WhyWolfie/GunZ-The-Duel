<div class="blockPadding">
	<b>System Requirements</b>
	<hr>
	<ul class="listMember">
		<li class="sysinfo">Windows XP, Vista, 7, or 8</li>
		<li class="sysinfo">DirectX 9.0c or above</li>
		<li class="sysinfo">Pentium III 800 MHz or higher</li>
		<li class="sysinfo">1GB RAM or higher</li>
		<li class="sysinfo">GeForce 4MX or higher - Graphic</li>
		<li class="sysinfo">Direct3D Sound - Sound card</li>
		<li class="sysinfo">Windows Compatible Wheel Mouse</li>
		<li class="sysinfo">1GB HD space or higher</li>
		<li class="sysinfo">Internet connection - 128KB/s+</li>
	</ul>
</div>