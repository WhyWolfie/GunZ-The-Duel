<?
	echo '<div class="header">
		<img src="img/logo_gunz.png"/>
		<div class="headfooter">';
		include "other/footer.php";
		echo '</div>
		</div>';
?>