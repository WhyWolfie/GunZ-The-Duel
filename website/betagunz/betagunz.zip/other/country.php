<option value="Albania" <? if($fr['Country'] || $user['Country'] == "Albania") { echo 'selected'; } ?>>Albania</option>
<option value="Algeria" <? if($fr['Country'] || $user['Country'] == "Algeria") { echo 'selected'; } ?>>Algeria</option>
<option value="Andoria" <? if($fr['Country'] || $user['Country'] == "Andoria") { echo 'selected'; } ?>>Andorra</option>
<option value="Angola" <? if($fr['Country'] || $user['Country'] == "Angola") { echo 'selected'; } ?>>Angola</option>
<option value="Anguilla" <? if($fr['Country'] || $user['Country'] == "Anguilla") { echo 'selected'; } ?>>Anguilla</option>
<option value="Antigua and Barbuda" <? if($fr['Country'] || $user['Country'] == "Antigua and Barbuda") { echo 'selected'; } ?>>Antigua and Barbuda</option>
<option value="Argentina" <? if($fr['Country'] || $user['Country'] == "Argentina") { echo 'selected'; } ?>>Argentina </option>
<option value="Amenia" <? if($fr['Country'] || $user['Country'] == "Amenia") { echo 'selected'; } ?>>Armenia</option>
<option value="Aruba" <? if($fr['Country'] || $user['Country'] == "Aruba") { echo 'selected'; } ?>>Aruba</option>
<option value="Australia" <? if($fr['Country'] || $user['Country'] == "Australia") { echo 'selected'; } ?>>Australia </option>
<option value="Austria" <? if($fr['Country'] || $user['Country'] == "Austria") { echo 'selected'; } ?>>Austria</option>
<option value="Azerbaijan Republic" <? if($fr['Country'] || $user['Country'] == "Azerbaijan Republic") { echo 'selected'; } ?>>Azerbaijan Republic</option>
<option value="Bahamas" <? if($fr['Country'] || $user['Country'] == "Bahamas") { echo 'selected'; } ?>>Bahamas</option>
<option value="Bahrain" <? if($fr['Country'] || $user['Country'] == "Bahrain") { echo 'selected'; } ?>>Bahrain</option>
<option value="Barbados" <? if($fr['Country'] || $user['Country'] == "Barbados") { echo 'selected'; } ?>>Barbados</option>
<option value="Belgium" <? if($fr['Country'] || $user['Country'] == "Belgium") { echo 'selected'; } ?>>Belgium</option>
<option value="Belize" <? if($fr['Country'] || $user['Country'] == "Belize") { echo 'selected'; } ?>>Belize</option>
<option value="Benin" <? if($fr['Country'] || $user['Country'] == "Benin") { echo 'selected'; } ?>>Benin</option>
<option value="Bermuda" <? if($fr['Country'] || $user['Country'] == "Bermuda") { echo 'selected'; } ?>>Bermuda</option>
<option value="Bhutan" <? if($fr['Country'] || $user['Country'] == "Bhutan") { echo 'selected'; } ?>>Bhutan</option>
<option value="Bolivia" <? if($fr['Country'] || $user['Country'] == "Bolivia") { echo 'selected'; } ?>>Bolivia</option>
<option value="Bosnia and Herzegovina" <? if($fr['Country'] || $user['Country'] == "Bosnia and Herzegovina") { echo 'selected'; } ?>>Bosnia and Herzegovina</option>
<option value="Botswana" <? if($fr['Country'] || $user['Country'] == "Botswana") { echo 'selected'; } ?>>Botswana</option>
<option value="Brazil" <? if($fr['Country'] || $user['Country'] == "Brazil") { echo 'selected'; } ?>>Brazil</option>
<option value="British Virgin Islands" <? if($fr['Country'] || $user['Country'] == "British Virgin Islands") { echo 'selected'; } ?>>British Virgin Islands</option>
<option value="Brunei" <? if($fr['Country'] || $user['Country'] == "Brunei") { echo 'selected'; } ?>>Brunei</option>
<option value="Bulgaria" <? if($fr['Country'] || $user['Country'] == "Bulgaria") { echo 'selected'; } ?>>Bulgaria</option>
<option value="Burkina Faso" <? if($fr['Country'] || $user['Country'] == "Burkina Faso") { echo 'selected'; } ?>>Burkina Faso </option>
<option value="Burundi" <? if($fr['Country'] || $user['Country'] == "Burundi") { echo 'selected'; } ?>>Burundi</option>
<option value="Cambodia" <? if($fr['Country'] || $user['Country'] == "Cambodia") { echo 'selected'; } ?>>Cambodia</option>
<option value="Canada" <? if($fr['Country'] || $user['Country'] == "Canada") { echo 'selected'; } ?>>Canada</option>
<option value="Cape Verde" <? if($fr['Country'] || $user['Country'] == "Cape Verde") { echo 'selected'; } ?>>Cape Verde</option>
<option value="Cayman Islands" <? if($fr['Country'] || $user['Country'] == "Cayman Islands") { echo 'selected'; } ?>>Cayman Islands</option>
<option value="Chad" <? if($fr['Country'] || $user['Country'] == "Chad") { echo 'selected'; } ?>>Chad</option>
<option value="Chile" <? if($fr['Country'] || $user['Country'] == "Chile") { echo 'selected'; } ?>>Chile</option>
<option value="China" <? if($fr['Country'] || $user['Country'] == "China") { echo 'selected'; } ?>>China</option>
<option value="Colombia" <? if($fr['Country'] || $user['Country'] == "Colombia") { echo 'selected'; } ?>>Colombia</option>
<option value="Comoros" <? if($fr['Country'] || $user['Country'] == "Comoros") { echo 'selected'; } ?>>Comoros</option>
<option value="Cook Islands" <? if($fr['Country'] || $user['Country'] == "Cook Islands") { echo 'selected'; } ?>>Cook Islands</option>
<option value="Costa Rica" <? if($fr['Country'] || $user['Country'] == "Costa Rica") { echo 'selected'; } ?>>Costa Rica</option>
<option value="Croatia" <? if($fr['Country'] || $user['Country'] == "Croatia") { echo 'selected'; } ?>>Croatia</option>
<option value="Cyprus" <? if($fr['Country'] || $user['Country'] == "Cyprus") { echo 'selected'; } ?>>Cyprus</option>
<option value="Czech Republic" <? if($fr['Country'] || $user['Country'] == "Czech Republic") { echo 'selected'; } ?>>Czech Republic</option>
<option value="Democratic Republic of the Congo" <? if($fr['Country'] || $user['Country'] == "Democratic Republic of the Congo") { echo 'selected'; } ?>>Democratic Republic of the Congo</option>
<option value="Denmark" <? if($fr['Country'] || $user['Country'] == "Denmark") { echo 'selected'; } ?>>Denmark</option>
<option value="Djibouti" <? if($fr['Country'] || $user['Country'] == "Djibouti") { echo 'selected'; } ?>>Djibouti</option>
<option value="Dominica" <? if($fr['Country'] || $user['Country'] == "Dominica") { echo 'selected'; } ?>>Dominica</option>
<option value="Dominican Republic" <? if($fr['Country'] || $user['Country'] == "Dominican Republic") { echo 'selected'; } ?>>Dominican Republic</option>
<option value="Ecuador" <? if($fr['Country'] || $user['Country'] == "Ecuador") { echo 'selected'; } ?>>Ecuador</option>
<option value="El Salvador" <? if($fr['Country'] || $user['Country'] == "El Salvador") { echo 'selected'; } ?>>El Salvador</option>
<option value="Eritrea" <? if($fr['Country'] || $user['Country'] == "Eritrea") { echo 'selected'; } ?>>Eritrea</option>
<option value="Estonia" <? if($fr['Country'] || $user['Country'] == "Estonia") { echo 'selected'; } ?>>Estonia</option>
<option value="Estados Unidos" <? if($fr['Country'] || $user['Country'] == "Estados Unidos") { echo 'selected'; } ?>>Estados Unidos</option>
<option value="Ethiopia" <? if($fr['Country'] || $user['Country'] == "Ethiopia") { echo 'selected'; } ?>>Ethiopia</option>
<option value="Falkland" <? if($fr['Country'] || $user['Country'] == "Falkland") { echo 'selected'; } ?>>Falkland Islands </option>
<option value="Faroe Islands" <? if($fr['Country'] || $user['Country'] == "Faroe Islands") { echo 'selected'; } ?>>Faroe Islands</option>
<option value="Federated States of Micronesia" <? if($fr['Country'] || $user['Country'] == "Federated States of Micronesia") { echo 'selected'; } ?>>Federated States of Micronesia</option>
<option value="Fiji" <? if($fr['Country'] || $user['Country'] == "Fiji") { echo 'selected'; } ?>>Fiji</option>
<option value="Finland" <? if($fr['Country'] || $user['Country'] == "Finland") { echo 'selected'; } ?>>Finland</option>
<option value="France" <? if($fr['Country'] || $user['Country'] == "France") { echo 'selected'; } ?>>France</option>
<option value="French Guiana" <? if($fr['Country'] || $user['Country'] == "French Guiana") { echo 'selected'; } ?>>French Guiana</option>
<option value="French Polynesia" <? if($fr['Country'] || $user['Country'] == "French Polynesia") { echo 'selected'; } ?>>French Polynesia</option>
<option value="Gabon Republic" <? if($fr['Country'] || $user['Country'] == "Gabon Republic") { echo 'selected'; } ?>>Gabon Republic</option>
<option value="Gambia" <? if($fr['Country'] || $user['Country'] == "Gambia") { echo 'selected'; } ?>>Gambia</option>
<option value="Germany" <? if($fr['Country'] || $user['Country'] == "Germany") { echo 'selected'; } ?>>Germany</option>
<option value="Gibraltar" <? if($fr['Country'] || $user['Country'] == "Gibraltar") { echo 'selected'; } ?>>Gibraltar </option>
<option value="Greece" <? if($fr['Country'] || $user['Country'] == "Greece") { echo 'selected'; } ?>>Greece</option>
<option value="Greenland" <? if($fr['Country'] || $user['Country'] == "Greenland") { echo 'selected'; } ?>>Greenland </option>
<option value="Grenada" <? if($fr['Country'] || $user['Country'] == "Grenada") { echo 'selected'; } ?>>Grenada</option>
<option value="Guadeloupe" <? if($fr['Country'] || $user['Country'] == "Guadeloupe") { echo 'selected'; } ?>>Guadeloupe</option>
<option value="Guatemala" <? if($fr['Country'] || $user['Country'] == "Guatemala") { echo 'selected'; } ?>>Guatemala </option>
<option value="Guinea" <? if($fr['Country'] || $user['Country'] == "Guinea") { echo 'selected'; } ?>>Guinea</option>
<option value="Guinea Bissau" <? if($fr['Country'] || $user['Country'] == "Guinea Bissau") { echo 'selected'; } ?>>Guinea Bissau </option>
<option value="Guyana" <? if($fr['Country'] || $user['Country'] == "Guyana") { echo 'selected'; } ?>>Guyana</option>
<option value="Honduras" <? if($fr['Country'] || $user['Country'] == "Honduras") { echo 'selected'; } ?>>Honduras</option>
<option value="Hong Kong" <? if($fr['Country'] || $user['Country'] == "Hong Kong") { echo 'selected'; } ?>>Hong Kong </option>
<option value="Hungary" <? if($fr['Country'] || $user['Country'] == "Hungary") { echo 'selected'; } ?>>Hungary</option>
<option value="Iceland" <? if($fr['Country'] || $user['Country'] == "Iceland") { echo 'selected'; } ?>>Iceland</option>
<option value="India" <? if($fr['Country'] || $user['Country'] == "India") { echo 'selected'; } ?>>India</option>
<option value="Indonesia" <? if($fr['Country'] || $user['Country'] == "Indonesia") { echo 'selected'; } ?>>Indonesia </option>
<option value="Ireland" <? if($fr['Country'] || $user['Country'] == "Ireland") { echo 'selected'; } ?>>Ireland</option>
<option value="Israel" <? if($fr['Country'] || $user['Country'] == "Israel") { echo 'selected'; } ?>>Israel</option>
<option value="Italy" <? if($fr['Country'] || $user['Country'] == "Italy") { echo 'selected'; } ?>>Italy</option>
<option value="Jamaica" <? if($fr['Country'] || $user['Country'] == "Jamaica") { echo 'selected'; } ?>>Jamaica</option>
<option value="Japan" <? if($fr['Country'] || $user['Country'] == "Japan") { echo 'selected'; } ?>>Japan</option>
<option value="Jordan" <? if($fr['Country'] || $user['Country'] == "Jordan") { echo 'selected'; } ?>>Jordan</option>
<option value="Kazakhstan" <? if($fr['Country'] || $user['Country'] == "Kazakhstan") { echo 'selected'; } ?>>Kazakhstan </option>
<option value="Kenya" <? if($fr['Country'] || $user['Country'] == "Kenya") { echo 'selected'; } ?>>Kenya</option>
<option value="Kiribati" <? if($fr['Country'] || $user['Country'] == "Kiribati") { echo 'selected'; } ?>>Kiribati</option>
<option value="Korea" <? if($fr['Country'] || $user['Country'] == "Korea") { echo 'selected'; } ?>>Korea</option>
<option value="Kuwait" <? if($fr['Country'] || $user['Country'] == "Kuwait") { echo 'selected'; } ?>>Kuwait</option>
<option value="Kyrgyztan" <? if($fr['Country'] || $user['Country'] == "Kyrgyztan") { echo 'selected'; } ?>>Kyrgyzstan</option>
<option value="Laos" <? if($fr['Country'] || $user['Country'] == "Laos") { echo 'selected'; } ?>>Laos</option>
<option value="Latvia" <? if($fr['Country'] || $user['Country'] == "Latvia") { echo 'selected'; } ?>>Latvia</option>
<option value="Lesotho" <? if($fr['Country'] || $user['Country'] == "Lesotho") { echo 'selected'; } ?>>Lesotho</option>
<option value="Liechtenstein" <? if($fr['Country'] || $user['Country'] == "Liechtenstein") { echo 'selected'; } ?>>Liechtenstein</option>
<option value="Lithuania" <? if($fr['Country'] || $user['Country'] == "Lithuania") { echo 'selected'; } ?>>Lithuania</option>
<option value="Luxembourg" <? if($fr['Country'] || $user['Country'] == "Luxembourg") { echo 'selected'; } ?>>Luxembourg</option>
<option value="Madagascar" <? if($fr['Country'] || $user['Country'] == "Madagascar") { echo 'selected'; } ?>>Madagascar</option>
<option value="Malawi" <? if($fr['Country'] || $user['Country'] == "Malawi") { echo 'selected'; } ?>>Malawi</option>
<option value="Malaysia" <? if($fr['Country'] || $user['Country'] == "Malaysia") { echo 'selected'; } ?>>Malaysia</option>
<option value="Maldives" <? if($fr['Country'] || $user['Country'] == "Maldives") { echo 'selected'; } ?>>Maldives</option>
<option value="Mali" <? if($fr['Country'] || $user['Country'] == "Mali") { echo 'selected'; } ?>>Mali</option>
<option value="Malta" <? if($fr['Country'] || $user['Country'] == "Malta") { echo 'selected'; } ?>>Malta</option>
<option value="Marshall Islands" <? if($fr['Country'] || $user['Country'] == "Marshall Islands") { echo 'selected'; } ?>>Marshall Islands</option>
<option value="Martinique" <? if($fr['Country'] || $user['Country'] == "Martinique") { echo 'selected'; } ?>>Martinique</option>
<option value="Mauritania" <? if($fr['Country'] || $user['Country'] == "Mauritania") { echo 'selected'; } ?>>Mauritania</option>
<option value="Mauritius" <? if($fr['Country'] || $user['Country'] == "Mauritius") { echo 'selected'; } ?>>Mauritius</option>
<option value="Mayotte" <? if($fr['Country'] || $user['Country'] == "Mayotte") { echo 'selected'; } ?>>Mayotte</option>
<option value="Mexico" <? if($fr['Country'] || $user['Country'] == "Mexico") { echo 'selected'; } ?>>Mexico</option>
<option value="Mongolia" <? if($fr['Country'] || $user['Country'] == "Mongolia") { echo 'selected'; } ?>>Mongolia</option>
<option value="Montserrat" <? if($fr['Country'] || $user['Country'] == "Montserrat") { echo 'selected'; } ?>>Montserrat</option>
<option value="Moroco" <? if($fr['Country'] || $user['Country'] == "Moroco") { echo 'selected'; } ?>>Morocco</option>
<option value="Mozambique" <? if($fr['Country'] || $user['Country'] == "Mozambique") { echo 'selected'; } ?>>Mozambique</option>
<option value="Namibia" <? if($fr['Country'] || $user['Country'] == "Namibia") { echo 'selected'; } ?>>Namibia</option>
<option value="Nauru" <? if($fr['Country'] || $user['Country'] == "Nauru") { echo 'selected'; } ?>>Nauru</option>
<option value="Nepal" <? if($fr['Country'] || $user['Country'] == "Nepal") { echo 'selected'; } ?>>Nepal</option>
<option value="Netherlands" <? if($fr['Country'] || $user['Country'] == "Netherlands") { echo 'selected'; } ?>>Netherlands </option>
<option value="Netherlands Antilles" <? if($fr['Country'] || $user['Country'] == "Netherlands Antilles") { echo 'selected'; } ?>>Netherlands Antilles</option>
<option value="New Celedonia" <? if($fr['Country'] || $user['Country'] == "New Celedonia") { echo 'selected'; } ?>>New Caledonia</option>
<option value="New Zealand" <? if($fr['Country'] || $user['Country'] == "New Zealand") { echo 'selected'; } ?>>New Zealand</option>
<option value="Nicaragua" <? if($fr['Country'] || $user['Country'] == "Nicaragua") { echo 'selected'; } ?>>Nicaragua</option>
<option value="Niger" <? if($fr['Country'] || $user['Country'] == "Niger") { echo 'selected'; } ?>>Niger</option>
<option value="Niue" <? if($fr['Country'] || $user['Country'] == "Niue") { echo 'selected'; } ?>>Niue</option>
<option value="Norfolk Island" <? if($fr['Country'] || $user['Country'] == "Norfolk Island") { echo 'selected'; } ?>>Norfolk Island</option>
<option value="Norway" <? if($fr['Country'] || $user['Country'] == "Norway") { echo 'selected'; } ?>>Norway</option>
<option value="Oman" <? if($fr['Country'] || $user['Country'] == "Oman") { echo 'selected'; } ?>>Oman</option>
<option value="Palau" <? if($fr['Country'] || $user['Country'] == "Palau") { echo 'selected'; } ?>>Palau</option>
<option value="Panama" <? if($fr['Country'] || $user['Country'] == "Panama") { echo 'selected'; } ?>>Panama</option>
<option value="Papua New Guinea" <? if($fr['Country'] || $user['Country'] == "Papua New Guinea") { echo 'selected'; } ?>>Papua New Guinea</option>
<option value="Peru" <? if($fr['Country'] || $user['Country'] == "Peru") { echo 'selected'; } ?>>Peru</option>
<option value="Philippines" <? if($fr['Country'] || $user['Country'] == "Philippines") { echo 'selected'; } ?>>Philippines</option>
<option value="Pitcairn Islands" <? if($fr['Country'] || $user['Country'] == "Pitcairn Islands") { echo 'selected'; } ?>>Pitcairn Islands</option>
<option value="Poland" <? if($fr['Country'] || $user['Country'] == "Poland") { echo 'selected'; } ?>>Poland</option>
<option value="Portugal" <? if($fr['Country'] || $user['Country'] == "Portugal") { echo 'selected'; } ?>>Portugal</option>
<option value="Qatar" <? if($fr['Country'] || $user['Country'] == "Qatar") { echo 'selected'; } ?>>Qatar</option>
<option value="Republic of the Congo" <? if($fr['Country'] || $user['Country'] == "Republic of the Congo") { echo 'selected'; } ?>>Republic of the Congo</option>
<option value="Reunion" <? if($fr['Country'] || $user['Country'] == "Reunion") { echo 'selected'; } ?>>Reunion</option>
<option value="Romania" <? if($fr['Country'] || $user['Country'] == "Romania") { echo 'selected'; } ?>>Romania</option>
<option value="Russia" <? if($fr['Country'] || $user['Country'] == "Russia") { echo 'selected'; } ?>>Russia</option>
<option value="Rwanda" <? if($fr['Country'] || $user['Country'] == "Rwanda") { echo 'selected'; } ?>>Rwanda</option>
<option value="Saint Vincent and the Grenadines" <? if($fr['Country'] || $user['Country'] == "Saint Vincent and the Grenadines") { echo 'selected'; } ?>>Saint Vincent and the Grenadines</option>
<option value="Samoa" <? if($fr['Country'] || $user['Country'] == "Samoa") { echo 'selected'; } ?>>Samoa</option>
<option value="San Marino" <? if($fr['Country'] || $user['Country'] == "San Marino") { echo 'selected'; } ?>>San Marino</option>
<option value="Sao Tome and Prncipe" <? if($fr['Country'] || $user['Country'] == "Sao Tome and Prncipe") { echo 'selected'; } ?>>Sao Tome and Prncipe</option>
<option value="Saudi Arabia" <? if($fr['Country'] || $user['Country'] == "Saudi Arabia") { echo 'selected'; } ?>>Saudi Arabia</option>
<option value="Senegal" <? if($fr['Country'] || $user['Country'] == "Senegal") { echo 'selected'; } ?>>Senegal</option>
<option value="Seychelles" <? if($fr['Country'] || $user['Country'] == "Seychelles") { echo 'selected'; } ?>>Seychelles</option>
<option value="Sierra Leone" <? if($fr['Country'] || $user['Country'] == "Sierra Leone") { echo 'selected'; } ?>>Sierra Leone</option>
<option value="Singapore" <? if($fr['Country'] || $user['Country'] == "Singapore") { echo 'selected'; } ?>>Singapore</option>
<option value="Slovakia" <? if($fr['Country'] || $user['Country'] == "Slovakia") { echo 'selected'; } ?>>Slovakia</option>
<option value="Slovenia" <? if($fr['Country'] || $user['Country'] == "Slovenia") { echo 'selected'; } ?>>Slovenia</option>
<option value="Solomon Islands" <? if($fr['Country'] || $user['Country'] == "Solomon Islands") { echo 'selected'; } ?>>Solomon Islands</option>
<option value="Somalia" <? if($fr['Country'] || $user['Country'] == "Somalia") { echo 'selected'; } ?>>Somalia</option>
<option value="South Africa" <? if($fr['Country'] || $user['Country'] == "South Africa") { echo 'selected'; } ?>>South Africa</option>
<option value="South Korea" <? if($fr['Country'] || $user['Country'] == "South Korea") { echo 'selected'; } ?>>South Korea</option>
<option value="Spain" <? if($fr['Country'] || $user['Country'] == "Spain") { echo 'selected'; } ?>>Spain</option>
<option value="Sri Lanka" <? if($fr['Country'] || $user['Country'] == "Sri Lanka") { echo 'selected'; } ?>>Sri Lanka</option>
<option value="St. Helena" <? if($fr['Country'] || $user['Country'] == "St. Helena") { echo 'selected'; } ?>>St. Helena</option>
<option value="St. Kitts and Nevis" <? if($fr['Country'] || $user['Country'] == "St. Kitts and Nevis") { echo 'selected'; } ?>>St. Kitts and Nevis</option>
<option value="St. Lucia" <? if($fr['Country'] || $user['Country'] == "St. Lucia") { echo 'selected'; } ?>>St. Lucia</option>
<option value="St. Pierre and Miquelon" <? if($fr['Country'] || $user['Country'] == "St. Pierre and Miquelon") { echo 'selected'; } ?>>St. Pierre and Miquelon</option>
<option value="Suriname" <? if($fr['Country'] || $user['Country'] == "Suriname") { echo 'selected'; } ?>>Suriname</option>
<option value="Svalbard and Jan Mayen Islands" <? if($fr['Country'] || $user['Country'] == "Svalbard and Jan Mayen Islands") { echo 'selected'; } ?>>Svalbard and Jan Mayen Islands</option>
<option value="Swaziland" <? if($fr['Country'] || $user['Country'] == "Swaziland") { echo 'selected'; } ?>>Swaziland</option>
<option value="Sweden" <? if($fr['Country'] || $user['Country'] == "Sweden") { echo 'selected'; } ?>>Sweden</option>
<option value="Switzerland" <? if($fr['Country'] || $user['Country'] == "Switzerland") { echo 'selected'; } ?>>Switzerland</option>
<option value="Taiwan" <? if($fr['Country'] || $user['Country'] == "Taiwan") { echo 'selected'; } ?>>Taiwan</option>
<option value="Tajikistan" <? if($fr['Country'] || $user['Country'] == "Tajikistan") { echo 'selected'; } ?>>Tajikistan</option>
<option value="Tanzania" <? if($fr['Country'] || $user['Country'] == "Tanzania") { echo 'selected'; } ?>>Tanzania</option>
<option value="Thailand" <? if($fr['Country'] || $user['Country'] == "Thailand") { echo 'selected'; } ?>>Thailand</option>
<option value="Togo" <? if($fr['Country'] || $user['Country'] == "Togo") { echo 'selected'; } ?>>Togo</option>
<option value="Tonga" <? if($fr['Country'] || $user['Country'] == "Tonga") { echo 'selected'; } ?>>Tonga</option>
<option value="Trinidad and Tobago" <? if($fr['Country'] || $user['Country'] == "Trinidad and Tobago") { echo 'selected'; } ?>>Trinidad and Tobago</option>
<option value="Tunisia" <? if($fr['Country'] || $user['Country'] == "Tunisia") { echo 'selected'; } ?>>Tunisia</option>
<option value="Turkey" <? if($fr['Country'] || $user['Country'] == "Turkey") { echo 'selected'; } ?>>Turkey</option>
<option value="Turkmenistan" <? if($fr['Country'] || $user['Country'] == "Turkmenistan") { echo 'selected'; } ?>>Turkmenistan</option>
<option value="Turks and Caicos Islands" <? if($fr['Country'] || $user['Country'] == "Turks and Caicos Islands") { echo 'selected'; } ?>>Turks and Caicos Islands</option>
<option value="Tuvalu" <? if($fr['Country'] || $user['Country'] == "Tuvalu") { echo 'selected'; } ?>>Tuvalu</option>
<option value="Uganda" <? if($fr['Country'] || $user['Country'] == "Uganda") { echo 'selected'; } ?>>Uganda</option>
<option value="Ukraine" <? if($fr['Country'] || $user['Country'] == "Ukraine") { echo 'selected'; } ?>>Ukraine</option>
<option value="United Arab Emirates" <? if($fr['Country'] || $user['Country'] == "United Arab Emirates") { echo 'selected'; } ?>>United Arab Emirates</option>
<option value="United Kingdom" <? if($fr['Country'] || $user['Country'] == "United Kingdom") { echo 'selected'; } ?>>United Kingdom </option>
<option value="United States" <? if($fr['Country'] || $user['Country'] == "United States") { echo 'selected'; } ?>>United States</option>
<option value="Uruguay" <? if($fr['Country'] || $user['Country'] == "Uruguay") { echo 'selected'; } ?>>Uruguay</option>
<option value="Vanuatu" <? if($fr['Country'] || $user['Country'] == "Vanuatu") { echo 'selected'; } ?>>Vanuatu</option>
<option value="Vatican City State" <? if($fr['Country'] || $user['Country'] == "Vatican City State") { echo 'selected'; } ?>>Vatican City State</option>
<option value="Venezuela" <? if($fr['Country'] || $user['Country'] == "Venezuela") { echo 'selected'; } ?>>Venezuela</option>
<option value="Vietnam" <? if($fr['Country'] || $user['Country'] == "Vietnam") { echo 'selected'; } ?>>Vietnam</option>
<option value="Wallis and Futuna Islands" <? if($fr['Country'] || $user['Country'] == "Wallis and Futuna Islands") { echo 'selected'; } ?>>Wallis and Futuna Islands</option>
<option value="Yemen" <? if($fr['Country'] || $user['Country'] == "Yemen") { echo 'selected'; } ?>>Yemen</option>
<option value="Zambia" <? if($fr['Country'] || $user['Country'] == "Zambia") { echo 'selected'; } ?>>Zambia</option>