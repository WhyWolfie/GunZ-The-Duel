<?

$_TITLE[INDEX]	=	"index.php";

$_TITLE[LOGIN]	=	"index.php?gunz=login";
$_TITLE[LOGOUT]	=	"index.php?gunz=logout";

$_TITLE[REGIST]	=	"index.php?gunz=register";
$_TITLE[MEMBER]	=	"index.php?gunz=members";

$_TITLE[RESETP]	=	"index.php?gunz=resetpass";

$_TITLE[LOAD]	=	"index.php?gunz=downloads";
$_TITLE[RANKS]	=	"index.php?gunz=rankings";
$_TITLE[STORE]	=	"index.php?gunz=store";
//$_TITLE[UPDATE]	=	"index.php?gunz=updates";
//$_TITLE[NEWS]	=	"index.php?gunz=news";

$_TITLE[ACCDET]	=	"index.php?gunz=accountinfo";
$_TITLE[DONATE]	=	"index.php?gunz=donate";
$_TITLE[BILLING]=	"index.php?gunz=orderform";
$_TITLE[PROCESS]=	"index.php?gunz=process";
$_TITLE[SIGN]	=	"index.php?gunz=tags";
$_TITLE[CLANEMB]=	"index.php?gunz=emupload";

$_TITLE[USERCP]	=	"index.php?gunz=usercp";
$_TITLE[ACP]	=	"index.php?gunz=admincp";
$_TITLE[MCP]	=	"index.php?gunz=modcp";
$_TITLE[GMCP]	=	"index.php?gunz=gmcp";

$_TITLE[VIP]	=	"index.php?gunz=itemshop";
$_TITLE[EVENT]	=	"index.php?gunz=eventshop";
$_TITLE[PRESTIGE]=	"index.php?gunz=prestigeshop";
$_TITLE[NAMECHANGE]="index.php?gunz=playername";

$_TITLE[INDIV]	=	"index.php?gunz=individuals";
$_TITLE[GUILD]	=	"index.php?gunz=guilds";

$_TITLE[CHAR]	=	"index.php?gunz=player";
$_TITLE[CLAN]	=	"index.php?gunz=clan";


?>