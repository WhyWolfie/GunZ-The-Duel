<?
	echo '<p>'.$_GUNZ[NAME].' � '.$_GUNZ[YEAR].', '.$_GUNZ[SERV].'. All Rights Reserved.</p>
		<p>Images and context belongs to respective owners.</p>
		<p>'.$copyRights.'.</p>
		<p>Community Forum Software powered by '.$_SOFT[FORUM].'</p>';
?>