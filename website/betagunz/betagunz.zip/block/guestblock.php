<div class="blockPadding">
	<b>Why Join <? echo $_GUNZ[NAME]; ?>?</b>
	<hr>
	<ul class="listMember">
		<li class="sysinfo">Play <? echo $_GUNZ[NAME]; ?> for free!</li>
		<li class="sysinfo">Multiplayer Third-Person RPG</li>
		<li class="sysinfo">Game EXP rate is 30x</li>
		<li class="sysinfo">Unique weapons, items, and sets</li>
		<li class="sysinfo">Game updates, and more!</li>
		<li class="sysinfo">Events, tournaments, or challenges</li>
	</ul>
</div>
<? include "other/requiresystem.php"; ?>