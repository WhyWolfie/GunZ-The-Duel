<?
	if ($check=@fsockopen($_SERV[IP],$_MATCH[PORT],$ERROR_NO,$ERROR_STR,(float)0.5))
	{ 
		fclose($check); 
		$serv['count'] = 0;
									
		$servinfo = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
		$srv = mssql_fetch_assoc($servinfo);

		$serv['count'] = $serv['count'] + $srv['CurrPlayer'];

		$status = "<font class='servOn'>Online</font></span>
				<span>|</span>
				<span>".$serv['count']." / ".$srv['MaxPlayer'];
	} else 
	{ 
		$status = "<font class='servOff'>Offline</font>";
	} 
	
	$uMenu = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
	$userMenu = mssql_fetch_assoc($uMenu);
	
	$emburl = ($userMenu['ImgURL'] == "") ? "clan/emblem/no_avatar.jpg" : $userMenu['ImgURL'];
	
echo '<div id="userNavMenu">
		<div class="userNavMenu clearfix">';
	if($_SESSION['AID'] <> "")
	{
		echo '<div class="userTextMenu">
			<div id="imgURL"><img src="'.$emburl.'" border="0" width="20" height="20" /></div>
			<span><a href="'.$_TITLE[ACCDET].'">'.GetUserByAID($userMenu['AID']).'</a></span>
			<span>|</span>
			<span>';
			if($_SESSION[UGradeID] == 255 || $_SESSION[UGradeID] == 254 || $_SESSION[UGradeID] == 252) 
			{ 
				if($_SESSION[UGradeID] == 255) { $_CPLINK = $_TITLE[ACP]; } 
				elseif ($_SESSION[UGradeID] == 254) { $_CPLINK = $_TITLE[MCP]; }
				elseif ($_SESSION[UGradeID] == 252) { $_CPLINK = $_TITLE[GMCP]; }
			}
			echo '<a href="'.$_CPLINK.'">Grade : '.FormatRankUser($userMenu['AID']).'</a></span>
			<span>|</span>
			<span>Coins : '.$userMenu['Coins'].'</span>
			<span>|</span>
			<span>Tokens : '.$userMenu['ECoins'].'</span>
		</div>
		<div class="userTextOpt">
			<script type="text/javascript" src="scripts/timeset-1.0.0.min.js"></script>
			<span>Status: '.$status.'</span>
			<span>|</span>
			<span id="timer">Server Time: '.(date("H:i:s")).'</span>
		</div>';
	} else
	{
		echo '<div class="userTextMenu">
				<span>Status: '.$status.'</span>
			</div>
			<div class="userTextOpt">
				<script type="text/javascript" src="scripts/timeset-1.0.0.min.js"></script>
				<span id="timer">Server Time: '.(date("H:i:s")).'</span>
			</div>';
	}
	echo '</div>
</div>';
?>