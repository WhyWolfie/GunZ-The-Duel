<div class="blockPadding">
	<b>Client Mirrors</b>
	<hr>
	<ul class="listMember">
		<li class="urlLinks">- Mirror 1: <a href="<? echo $_LINKS[DOWN01]; ?>">Click here</a></li>
		<li class="urlLinks">- Mirror 2: <a href="<? echo $_LINKS[DOWN02]; ?>">Click here</a></li>
		<li class="urlLinks">- Mirror 3: <a href="<? echo $_LINKS[DOWN03]; ?>">Click here</a></li>
	</ul>
</div>
<? include "other/requiresystem.php"; ?>