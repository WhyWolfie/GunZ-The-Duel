<? 
SetTitle("Create an account");
include "mode/mod_logoutneed.php";
	
$alertbox = "";
$er = 0;
$registered = 0;
if($_GET['action'] == "complete")
{
	$user           = clean($_POST['user']);
	$pass1          = clean($_POST['pass1']);
	$pass2          = clean($_POST['pass2']);
	$email          = clean($_POST['email']);
	$conemail		= clean($_POST['conemail']);
	$country        = clean($_POST['country']);
	$name           = clean($_POST['name']);
	$sex            = clean($_POST['sex']);
	$question       = clean($_POST['question']);
	$answer         = clean($_POST['answer']);
	$address        = clean($_POST['address']);
	$zipcode        = clean($_POST['zipcode']);
	
	$birthyear		= clean($_POST['birthyear']);
	$birthmonth		= clean($_POST['birthmonth']);
	$birthday		= clean($_POST['birthday']);
	
	$age = getAge($birthyear, $birthmonth, $birthday);

	$res = mssql_query("SELECT * FROM Login WHERE UserID = '".clean($user)."'");
	$res1 = mssql_query("SELECT * FROM Account WHERE Email = '".clean($email)."'");
	
	if($user == "")
	{
		alertbox("Username is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	if (mssql_num_rows($res) >= 1)
	{
		alertbox("Username already exist. Please use a different username.",$_TITLE[REGIST]);
		$er = 1;
	}
	
	if($pass1 != $pass2)
	{
		alertbox("Password does not match.",$_TITLE[REGIST]);
		$er = 1;
	} elseif($pass1 == "" || $pass2 == "")
	{
		alertbox("Password is empty.",$_TITLE[REGIST]);
		$er = 1;
	}

	if($email == "")
	{
		alertbox("E-mail is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	if (mssql_num_rows($res1) >= 1)
	{
		alertbox("E-mail already in use. Please use a different e-mail.",$_TITLE[REGIST]);
		$er = 1;
	}
	if($conemail == "")
	{
		alertbox("You did not re-enter your e-mail.",$_TITLE[REGIST]);
		$er = 1;
	}
	if($email != $conemail)
	{
		alertbox("E-mails do not match.",$_TITLE[REGIST]);
		$er = 1;
	}
	
	if($name == "")
	{
		alertbox("Full name is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	if($address == "")
	{
		alertbox("Street address is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	if($zipcode == "")
	{
		alertbox("ZIP code is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	if(strlen($pass1) < 6)
	{
		alertbox("Password must be at least 6 characters with letters and/or numbers.",$_TITLE[REGIST]);
		$er =1;
	}

	if($answer == "")
	{
		alertbox("Security answer is empty.",$_TITLE[REGIST]);
		$er = 1;
	}
	
	require_once('other/recaptcha.php');
	$privatekey = "6LepMAgAAAAAAGQa4_jAZoG-HnX3Jgz2Ut0Ho5YO";
	$resp = recaptcha_check_answer ($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"]);
	if (!$resp->is_valid) 
	{
		alertbox("Recaptcha does not match.",$_TITLE[REGIST]);
		$er =1;
	} elseif ($resp == "")
	{
		alertbox("Recaptcha is empty.", $_TITLE[REGIST]);
		die();
	}

	if($er == 0)
	{
		$registered = 1;
		mssql_query("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, SQ, SA, Address, ZipCode, BirthYear, BirthMonth, BirthDay)Values('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$question', '$answer', '$address', '$zipcode', '$birthyear', '$birthmonth', '$birthday')");
		$res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
		$usr = mssql_fetch_assoc($res);
		$aid = $usr['AID'];
		mssql_query("INSERT INTO Login ([UserID],[AID],[Password])VALUES('$user','$aid','$pass1')");
	} else
	{
		$alert = alertbox($text, $url);
		die();
	}
}
if ($registered == 0) 
{ 
?>
<script type="text/javascript" src="scripts/checkuser-1.0.0.min.js"></script>
<?
	if($_MODE[CHECKPASS] == 0)
	{
		echo '<script type="text/javascript" src="scripts/checkpass-1.0.0.min.js"></script>';
	} elseif($_MODE[CHECKPASS] == 1)
	{
		echo '<style type"text/css">
				<!--
					@import \'css/checkpass.css\';
				-->
				</style>
				<script type="text/javascript" src="scripts/checkpass-2.0.0.min.js"></script>
				<script type="text/javascript">
				$(document).ready( function() {
					$("#pass1").passStrength({
						userid: "#user",
						baseStyle: "results"
					});
				});';
	}
?>
</script>
<div id="midBlockCon">
	<div class="midBlockContent">
	<form name="reg" method="POST" action="<? echo $_TITLE[REGIST]; ?>&action=complete" class="registerForm">
		<table width="99%" cellspacing="5" style="font-size: 10px;">
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Create a username<br/>
					<input style="width:210px" class="login1" type="text" id="user" name="user">
				</td>
				<td align="left" width="70%">Availability Status: <span id="availabilityStatus">&nbsp;</span></td>
			<tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Your current email<br/>
					<input style="width:210px" class="login1" type="text" name="email"><br/><br/>
					Re-enter your email<br/>
					<input style="width:210px" class="login1" type="text" name="conemail">
				</td>
				<td align="left" width="70%">Emails are used to get reset your password along with your security Q&A, but you are required to have an email.</td>
			<tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Choose a password<br/>
					<input style="width:210px" class="login1" type="password" id="pass1" name="pass1"><br/><br/>
					Re-enter password<br/>
					<input style="width:210px" class="login1" type="password" id="pass2" name="pass2">
				</td>
				<td align="left" width="70%">
					<div class="passStr"><div id="passStatus"></div></div><br/>
					This bar above is showing you the strength of your password. We recommend that you create a password that is unique. Never give your password to anyone.
				</td>
			</tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Full name<br/>
					<input style="width:210px" class="login1" type="text" name="name"><br/><br/>
					Birthday<br/>
					<select name="birthmonth" class="login2" style="width:80px;">
						<option value="1">January</option>
						<option value="2">February</option>
						<option value="3">March</option>
						<option value="4">April</option>
						<option value="5">May</option>
						<option value="6">June</option>
						<option value="7">July</option>
						<option value="8">August</option>
						<option value="9">September</option>
						<option value="10">October</option>
						<option value="11">November</option>
						<option value="12">December</option>
					</select>
					<select name="birthday" class="login2" style="width: 45px;">
						<option value='1'>1</option>
						<option value='2'>2</option>
						<option value='3'>3</option>
						<option value='4'>4</option>
						<option value='5'>5</option>
						<option value='6'>6</option>
						<option value='7'>7</option>
						<option value='8'>8</option>
						<option value='9'>9</option>
						<option value='10'>10</option>
						<option value='11'>11</option>
						<option value='12'>12</option>
						<option value='13'>13</option>
						<option value='14'>14</option>
						<option value='15'>15</option>
						<option value='16'>16</option>
						<option value='17'>17</option>
						<option value='18'>18</option>
						<option value='19'>19</option>
						<option value='20'>20</option>
						<option value='21'>21</option>
						<option value='22'>22</option>
						<option value='23'>23</option>
						<option value='24'>24</option>
						<option value='25'>25</option>
						<option value='26'>26</option>
						<option value='27'>27</option>
						<option value='28'>28</option>
						<option value='29'>29</option>
						<option value='30'>30</option>
						<option value='31'>31</option>
					</select>
					<select name="birthyear" class="login2" style="width: 60px;">
						<? include "other/con_year.php"; ?>
					</select><br/><br/>
					Gender<br/>
					<select name="sex" class="login2 selection" style="width:218px">
						<option value="0">Male</option>
						<option value="1">Female</option>
					</select>
				</td>
				<td align="left" width="70%"></td>
			</tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Street Address<br>
					<input style="width:210px" class="login1" type="text" name="address"><br/><br/>
					ZIP code<br>
					<input style="width:210px" class="login1" type="text" name="zipcode"><br/><br/>
					Country<br>
					<select style="width:218px" name="country" class="login2">
						<option selected value="United States">United States</option>
						<? include "other/country.php"; ?>
					</select>
				</td>
				<td align="left" width="70%"></td>
			</tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr>
				<td align="left" width="30%" class="colOneTable">
					Security Question<br/>
					<select style="width:218px" id="question" name="question" type="text" class="login2 selection">
						<option value="What is the name of your school?">What is the name of your school?</option>
						<option value="What is your favorite color?">What is your favorite color?</option>
						<option value="What is your favorite team?">What is your favorite team?</option>
						<option value="What is the name of your pet?">What is the name of your pet?</option>
						<option value="What city were you born in?">What city were you born in?</option>
					</select>
					<br/><br/>
					Security Answer<br/>
					<input style="width:210px" name="answer" type="password" class="login1" id="answer">
				</td>
				<td align="left" width="70%">Security question and answer are used to recover your password.</td>
			</tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr width="100%">
				<td align="left" colspan="2">
					<? 
						require_once('other/recaptcha.php');
						$publickey = "6LepMAgAAAAAAG8JszlL7PQKy_UsrS6rndEisQjL";
						echo recaptcha_get_html($publickey);
					?>
				</td>
			</tr>
			<tr><td colspan="2"><hr></td></tr>
			<tr align="center">
				<td align="center" colspan="2">
					<br>
					<div style="text-align: left;">
						Please review the agreement(s) below and agree by selecting the checkbox(es) at the bottom of the page. You must agree with the terms of these agreements to continue.
					</div><br>
					<div class="box">
						<? include "other/agreement.php"; ?>
					</div>
				</td>
			</tr>
			<tr align="center">
				<td align="left" colspan="2" height="50">
					<div style="float: left;">
						<input type="checkbox" name="agreement" value="1" onclick="document.reg.submit.disabled = !document.reg.submit.disabled;"/>I agree and am older than 12 years old
					</div>
					<div style="float: right;">
						<input type="submit" value="Create account" name="submit" id="submit" class="login">
					</div>
				</td>
			</tr>
		</table>
	</form>
	</div>
</div>
<?
} else 
{
	alertbox("Registration completed. You can now play ".$_GUNZ[NAME]." with the account you created.", $_TITLE[INDEX]);
	die();
} 
?>