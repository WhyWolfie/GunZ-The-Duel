<div class="rightBlock">
	<div class="blockCon textLeft">
		<? include "block/downloadsblock.php"; ?>
	</div>
</div>
<div id="leftColBlock">
	<div class="leftColBlock">
		<span>Download <? echo $_GUNZ[NAME]; ?> Client</span>
		<hr>
		<div>
			Here is where you can download the client and install it into your computer or PC to start playing. Your computer must meet certain minimum requirements to play GunZ. 
			It is recommended to have at least higher than the minimum to have great performance with the game without any problems.
		</div>
		<hr>
		<div>Below is the system minmum and recommended that you need in order for you to play GunZ properly.</div>
		<div>
			<table align="center" width="100%" cellpadding="0" id="downloads">
				<tr>
					<td align="center" width="115"></td>
					<td align="center" class="columnHead">Minimum</td>
					<td align="center" class="columnHead">Recommended</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">OS</td>
					<td colspan="2" align="center" class="columnCon">Windows XP, Windows 7, Windows 8</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">DirectX</td>
					<td colspan="2" align="center" class="columnCon">DirectX 9.0c+</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">CPU</td>
					<td align="center" class="columnCon">Pentium III 500 MHz</td>
					<td align="center" class="columnCon">Pentium III 500 MHz+</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">RAM</td>
					<td align="center" class="columnCon">256MB</td>
					<td align="center" class="columnCon">512MB+</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">Graphics Card</td>
					<td align="center" class="columnCon">Direct 3D 9.0 Compatible</td>
					<td align="center" class="columnCon">GeForce 4MX+</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">Sound Card</td>
					<td colspan="2" align="center" class="columnCon">Direct3D Sound Compatible</td>
				</tr>
				<tr height="20">
					<td align="center" class="columnHead">Mouse Device</td>
					<td colspan="2" align="center" class="columnCon">Windows Compatible (Wheel Mouse)</td>
				</tr>
			</table>
		</div>
		<hr>
		<div>
			<center><img src="img/content/mc_controls_pic.gif" border="0"/></center>
		</div>
	</div>
</div>