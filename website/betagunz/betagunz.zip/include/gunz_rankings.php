<? SetTitle("Top Rankings"); ?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Top Rankings</span>
		<hr>
		<p>Here is where the top 10 players and clans will be displayed here. More information about the clan or players are in the 'more info' link.</p>
		<hr>
		<div class="rankingPage clearfix">
			<div class="columnRank">
				<p>Individuals <span class="floatRight"><a href="<? echo $_TITLE[INDIV]; ?>">More info</a></span></p>
				<hr>
				<center>
					<div>
						<div class="numRank">#</div>
						<div class="nameRank">Name</div>
						<div class="levelRank">Position</div>
						<div class="xpRank">EXP. Points</div>
						<div class="ratioRank">Ratio</div>
						<div class="sexRank">Sex</div>
					</div>
					<?
						$charnum = 1;
						$indiv = mssql_query("SELECT TOP 10 * FROM Character ORDER BY XP DESC");
						
						if(mssql_num_rows($indiv) == 0)
						{
							echo '<div>No data</div>';
						} else
						{
							while($players = mssql_fetch_assoc($indiv))
							{
								echo '<div>
										<div class="numRank">'.$charnum.'</div>
										<div class="nameRank"><a href="'.$_TITLE[CHAR].'&id='.$players['CID'].'">'.$players['Name'].'</a></div>
										<div class="levelRank"><font color="orange">Lv</font> '.levelStats($players['XP']).'</div>
										<div class="xpRank">'.number_format($players['XP'],0,'',',').'</div>
										<div class="ratioRank">'.GetKDR($players['KillCounts'],$players['DeathCount']).'</div>
										<div class="sexRank">'.GenderShowChar($players['CID']).'</div>
									</div>';
								$charnum++;
							}
						}
					?>
				</center>
			</div>
			<div class="columnRank">
				<p>Guilds <span class="floatRight"><a href="<? echo $_TITLE[GUILD]; ?>">More info</a></span></p>
				<hr>
				<center>
					<div>
						<div class="numRank">#</div>
						<div class="levelRank">Mark</div>
						<div class="xpRank">Name</div>
						<div class="sexRank">Position</div>
						<div class="ratioRank">Ratio</div>
						<div class="nameRank">Leader</div>
					</div>
					<?
						$clannum = 1;
						$guild = mssql_query("SELECT TOP 10 * FROM Clan ORDER BY Point DESC, CLID ASC");
						
						if(mssql_num_rows($guild) == 0)
						{
							echo '<div>No data</div>';
						} else
						{
							while($clans = mssql_fetch_assoc($guild))
							{
								$clanemburl = ($clans['EmblemUrl'] == "") ? "clan/emblem/no_emblem.png" : $clans['EmblemUrl'];
								echo '<div>
										<div class="numRank">'.$clannum.'</div>
										<div class="levelRank"><img src="'.$clanemburl.'" width="15" height="15" border="0"/></div>
										<div class="xpRank"><a href="'.$_TITLE[CLAN].'&id='.$clans['CLID'].'">'.$clans['Name'].'</a></div>
										<div class="sexRank"><font color="lime">Pts</font> '.number_format($clans['Point'],0,'',',').'</div>
										<div class="ratioRank">'.GetClanPercent($clans['Wins'],$clans['Losses']).'</div>
										<div class="nameRank"><a href="'.$_TITLE[CHAR].'&id='.$clans['MasterCID'].'">'.GetClanMasterByCLID($clans['MasterCID']).'</a></div>
									</div>';
								$clannum++;
							}
						}
					?>
				</center>
			</div>
		</div>
	</div>
</div>