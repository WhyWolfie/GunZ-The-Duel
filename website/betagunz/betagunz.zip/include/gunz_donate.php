<?
SetTitle("Donate to ".$_GUNZ[SERV]."");
include "mode/mod_loginneed.php";
?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Support us by donating</span>
		<hr>
		<div class="donateimg"><img src="img/paypal/logo_paypal.png"></div>
		<div>
			<p>The payment service PayPal is widely recognized to be quickly and safely. PayPal offers the use of the most popular for its credit card transactions.
			By donating, you have accept to support us and help improve the game features if possible. All donations are put into the server and client. 
			There will be no refunds after you have donated, so in addition, we will reward you from your donation(s) with VIP features of the game.</p>
			
			<p>The cash coins should go right into your account once the money has been sent and confirm. Be sure to be still logged in while you are donating in order 
			to get the coins into your account as soon as possible without having any problems or waiting for someone to send them to you. Your satisfaction is our high 
			priority.</p>
			
			<p>With the donations that you have provided to us, we are able to keep the server and game going for a long period as well. You will also be able to buy stuff 
			that people don't have access to without donation, which would give you more of an advantage against your opponents. If you have just suddenly lost your paid 
			items, please be sure to have proof of you having the item in your inventory or storage in order to get your item. We will be able to check if you really lost 
			it or not. If you are pulling pranks or jokes against us, we won't provide support to you for the imaturity of your actions. So choose wisely for what you are 
			about to do, and the consequences against those actions.</p>
			<hr>
			<form method="post" action="<? echo $_TITLE[BILLING]; ?>" class="proceedButton">
				<input type="submit" class="login" value="I agree and accept the terms and conditions above and proceed" />
			</form>
		</div>
	</div>
</div>