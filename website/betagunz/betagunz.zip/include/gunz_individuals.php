<?
SetTitle("Individual Rankings");
if(isset($_GET['type']) && isset($_GET['name']))
{
	$search = 1;
	$type = clean($_GET['type']);
	$name = clean($_GET['name']);
	
	if($name == "")
	{
		alertbox("No valid input is filled in the search box.", $_TITLE[INDIV]);
	}

	if($type == 1)
	{
		$squery = "SELECT * FROM Character(nolock) WHERE Name = '$name'";
	} elseif($type == 2) 
	{
		$accountq = mssql_query("SELECT * FROM Account(nolock) WHERE UserID = '$name'");
		if(mssql_num_rows($accountq) == 1)
		{
			$accountdata = mssql_fetch_assoc($accountq);
			$aid = $accountdata['AID'];
			$squery = "SELECT * FROM Character(nolock) WHERE AID = '$aid' AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC, KillCount DESC, Sex ASC";
		} else
		{
			echo '<tr><td align="center" colspan="10"><p align="center">No data</td></tr>';
		}
	} else 
	{ 
		$search = 0;
	}
} else 
{
		$search = 0;
}
if($search == 0) 
{
	$res = mssql_query("SELECT TOP 100 * FROM Character WHERE (DeleteFlag=0  OR DeleteFlag=NULL) ORDER BY XP DESC, KillCount DESC, Sex ASC");
} else 
{
	$res = mssql_query($squery);
}
echo '<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Individual Rankings</span>
		<hr>
		<span id="searchZone">
			<form method="GET" name="indsearch" action="'.$_TITLE[INDIV].'" class="float_right">
				<input type="hidden" name="gunz" value="individuals" />
					<select name="type" class="login2">
						<option value="1">Character name</option>
						<option value="2">Account name</option>
					</select>
				<input type="text" name="name" class="login2"/>
				<input type="submit" value="Search" class="login" />
			</form>
		</span>
		<hr>
		<table width="100%" align="center" cellspacing="5" cellpadding="0" id="playertable">
			<tr align="center">
				<td align="center" width="20"><b>#</b></td>';
				if($_MODE[PRESTIGE] == 1) { echo '<td align="center" width="30"><b>-</b></td>'; }
				echo '<td align="center" width="80"><b>Name</b></td>
				<td align="center" width="20"><b>Level</b></td>
				<td align="center" width="90"><b>EXP Points</b></td>
				<td align="center" width="45"><b>Sex</b></td>
				<td align="center" width="70"><b>Kills</b></td>
				<td align="center" width="70"><b>Deaths</b></td>
				<td align="center" width="40"><b>Ratio</b></td>
				<td align="center" width="50"><b>Time</b></td>
			</tr>
			<tr>
				<td colspan="30"><hr></td>
			</tr>';
			if(mssql_num_rows($res) <> 0) 
			{
				$count = 1;
				while($char = mssql_fetch_assoc($res))
				{
					echo '<tr height="20">
							<td align="center">'.$count.'</td>';
							if($_MODE[PRESTIGE] == 1) { echo '<td align="center">'.switchPrestige($char['PLevel']).'</td>'; }
							echo '<td align="center"><a href="'.$_TITLE[CHAR].'&id='.$char['CID'].'">'.FormatCharName($char['CID']).'</a></td>
							<td align="center">'.levelstats($char['XP']).'</td>
							<td align="center">'.number_format($char['XP'], 0, "", ",").'</td>
							<td align="center">'.GenderShowChar($char['CID']).'</td>
							<td align="center">'.number_format($char['KillCount'], 0, "", ",").'</td>
							<td align="center">'.number_format($char['DeathCount'], 0, "", ",").'</td>
							<td align="center">'.GetKDR($char['KillCount'], $char['DeathCount']).'</td>
							<td align="center">'.$char['PlayTime'].'</td>
						</tr>';
					$count++;
				}
			} else 
			{
				echo '<tr><td height="35" colspan="10" align="center">No data</td></tr>';
			}
		echo '</table>
	</div>
</div>';
?>