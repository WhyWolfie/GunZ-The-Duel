<?
SetTitle("Members' Central");
include "mode/mod_logoutneed.php";
?>
<div id="leftColBlock">
	<div class="leftColBlock clearfix">
		<div class="lineSeparator"></div>
		<div id="leftColumn" class="floatLeft">
			<div class="h3">Sign in</div>
			<div class="h2">To an existing account</div>
			<form name="login" method="POST" action="<? echo $_TITLE[LOGIN]; ?>">
				<center>
				<div class="userInput">
					<div>Account name</div>
					<div><input class="login1" type="text" name="userid" style="width: 265px;"></div>
				</div>
				<div class="userInput">
					<div>Password</div>
					<div><input class="login1" type="password" name="pass" style="width: 265px;"></div>
				</div>
				</center>
				<div class="buttonMargin textRight">
					<input class="login" type="submit" name="submit" value="Sign In">
				</div>
			</form>
		</div>
		<div id="leftColumn" class="floatRight">
			<div class="h3">Create</div>
			<div class="h2">A new free account</div>
			<center>
				<div class="userInput">
					It's free to join and fun to play. Continue on to the registration to create an account for <? echo $_GUNZ[NAME]; ?> and start playing.
				</div>
				<div class="userInput">
					Be sure that you have at least the minimum or recommended requirements for you to run the game properly without having any problems.
				</div>
			</center>
			<div class="textRight">
				<form method="post" action="<? echo $_TITLE[REGIST]; ?>"><input type="submit" class="login" value="Join <? echo $_GUNZ[NAME]; ?>"/></form>
			</div>
		</div>
	</div>
	<div class="forgetPassArea"><a href="<? echo $_TITLE[RESETP]; ?>">Forgot Password?</a></div>
</div>
<div class="rightBlock">
	<div class="blockCon textLeft">
		<? include "block/guestblock.php"; ?>
	</div>
</div>