<?
	if($_GET['id'] == "")
	{
		header("Location: index.php");
	} else
	{
		$cid = $_GET['id'];
		
		$account = mssql_fetch_assoc(mssql_query("SELECT * FROM Character ch, Account acc WHERE acc.AID = ch.AID AND CID = '$cid'"));
		
		$char = mssql_query("SELECT * FROM Character WHERE CID = '$cid'");
		$player = mssql_fetch_assoc($char);
		
		$clan = mssql_query("SELECT * FROM ClanMember clm, Clan cl WHERE cl.CLID = clm.CLID AND clm.CID = '$cid'");
		$guild = mssql_fetch_assoc($clan);
		
		$accurl = ($account['ImgURL'] == "") ? "clan/emblem/no_avatar.jpg" : $account['ImgURL'];
		
		echo '<div id="midBlockCon">
			<div class="midBlockContent clearfix">
				<span>'.$player['Name'].'\'s Details</span>
				<hr>
				<div class="formRow">
					<div class="formRowTitle">
						<div>Level: </div>';
						if($_MODE[PRESTIGE] == 1) { echo '<div>Prestige </div>'; }
						echo '<div>Sex: </div>
						<div>EXP. Points:</div>
						<div>Kills:</div>
						<div>Deaths:</div>
						<div>Ratio:</div>
						<div>Clan:</div>
						<div>Clan Position:</div>
						<div>Character Number:</div>
						<div>Created </div>
						<div>Play time:</div>
						<div>Last played </div>
						<div>Views:</div>
					</div>
					<div class="formRowFields">
						<div>'.$player['Level'].'</div>';
						if($_MODE[PRESTIGE] == 1) { echo '<div>'.$player['PLevel'].'</div>'; }
						echo '<div>'.GenderShowChar($player['CID']).'</div>
						<div>'.number_format($player['XP'], 0, "", ",").'</div>
						<div>'.number_format($player['KillCount'], 0, "", ",").'</div>
						<div>'.number_format($player['DeathCount'], 0, "", ",").'</div>
						<div>'.GetKDR($player['KillCount'], $player['DeathCount']).'</div>
						<div><a href="'.$_TITLE[CLAN].'&id='.$guild['CLID'].'">'.$guild['Name'].'</a></div>
						<div>'.GetCharGradeFromCLID($guild['Grade']).'</div>
						<div>'.number_format($player['CID'], 0, "", ",").'</div>
						<div>'.time_elapsed_string(strtotime($player['RegDate'])).'</div>
						<div>'.$player['PlayTime'].'</div>
						<div>'.time_elapsed_string(strtotime($player['LastTime'])).'</div>
						<div>'.$player['Views'].'</div>
					</div>
					<div class="formRowDesc">
						<span class="descArrow">�</span> Account Information
						<div>Name: '.$account['Name'].'</div>
						<div>Rank: '.FormatRankUser($account['AID']).'</div>
						<div>Email: '.$account['Email'].'</div>
						<div>Age: '.$account['Age'].' years old</div>
						<div>Sex: '.GenderShow($account['Sex']).'</div>
						<div>Member Since: '.date("F Y",strtotime($account['RegDate'])).'</div>
						<div>Last played: '.time_elapsed_string(strtotime($account['LastLoginTime'])).'</div>
						<div><img src="'.$accurl.'" width="50" height="50" border="0"/></div>
					</div>
				</div>
			</div>
		</div>';
		
		mssql_query("UPDATE Character SET Views = Views + 1 WHERE CID = '$cid'");
	}
?>