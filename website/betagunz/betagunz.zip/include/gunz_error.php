<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Donation Error</span>
		<hr>
		<center id="errorMessage">
			<p>You have cancel your payment, therefore, the donation was cancelled.</p>
			<p>Coins has not been added since you have cancelled the payment, or your information was declined by Paypal.</p>
		</center>
	</div>
</div>