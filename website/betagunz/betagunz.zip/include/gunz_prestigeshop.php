<?
SetTitle("Prestige Shop");
include "mode/mod_loginneed.php";
if($_MODE[PRESTIGE] == 0)
{
	alertbox("The prestige shop is unavailable. You will not have access to this page any longer.","{$_SERVER['HTTP_REFERER']}");
}

if($_GET['action'] == "reset")
{
	$charmax = clean($_POST['charmax']);
	
	$query = mssql_query("SELECT * FROM Character WHERE CID = '$charmax'");
	$char = mssql_fetch_assoc($query);
	
	$charuser = $char['CID'];
	
	mssql_query("UPDATE Character SET Level = 1, XP = 0, BP = 10000000, KillCount = 0, DeathCount = 0, PLevel = 0 WHERE CID = '$charuser'");
	alertbox("Character status has been successfully resetted.",$_TITLE[PRESTIGE]);
}

if($_GET['action'] == "coins")
{
	$char1 = clean($_POST['char1']);
	
	$query2 = mssql_query("SELECT * FROM Character WHERE CID = '$char1'");
	$charinfo = mssql_fetch_assoc($query2);
	
	$query3 = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
	$accinfo = mssql_fetch_assoc($query3);
	
	$tokens = $charinfo['Tokens'];
	$upcoins = $tokens * $_MODE[PTOKENS];
	
	if($_MODE[CONVERT] == 0)
	{
		$updcoins = "Coins = Coins + '$upcoins'";
	} elseif($_MODE[CONVERT] == 1)
	{
		$updcoins = "ECoins = ECoins + '$upcoins'";
	}

	
	if($tokens > 0)
	{	
		mssql_query("UPDATE Character SET Tokens = Tokens - '$tokens' WHERE CID = '$char1'");
		mssql_query("UPDATE Account SET ".$updcoins." WHERE AID = '".$_SESSION['AID']."'");
		alertbox("Prestige tokens has been converted converted to ",$_TITLE[PRESTIGE]);
	}
}

$res = mssql_query("SELECT * FROM Character WHERE PLevel = 15 AND (DeleteFlag = 0 OR DeleteFlag = NULL) AND AID = '{$_SESSION['AID']}'");
$res1 = mssql_query("SELECT * FROM Character WHERE PLevel > 0 AND Tokens > 0 AND DeleteFlag = 0 AND AID = '{$_SESSION['AID']}'");

echo '<style type="text/css">
		<!--
			@import \'css/accountinfo.css\';
		-->
	</style>
	<div id="midBlockCon">
		<div class="midBlockContent minHeight">
			<span>Prestige Area</span>
			<hr>
			<p>The following options below are the only things you are allowed to do with your prestige characters. If there are any misleading information that needs to be fixed, 
			please nofity the staff member as soon as possible.</p>
			<hr>
			<form method="post" action="'.$_TITLE[PRESTIGE].'&action=reset">
				<div class="formRow">
					<div class="formRowTitle">Character name: </div>
					<div class="formRowFields">';
						if(mssql_num_rows($res) == 0)
						{
							echo '<input class="login1" value="No characters available" disabled>';
						} else
						{
							echo '<select name="charmax" class="login2">';
							while($resetchar = mssql_fetch_assoc($res)) 
							{
								echo '<option value="'.$resetchar['CID'].'">'.$resetchar['Name'].' (Prestige '.$resetchar['PLevel'].')</option>';
							}
							echo '</select>
							<input type="submit" name="reset" class="login" value="Reset"/>';
						}
					echo '</div>
					<div class="formRowDesc"><span class="descArrow">�</span> Resetting your character status will reset everything. It does require you to be max Prestige (15).</div>
				</div>
			</form>
			<hr>
			<form method="post" action="'.$_TITLE[PRESTIGE].'&action=coins">
				<div class="formRowOne">
					<div class="formRowTitle">Character name: </div>
					<div class="formRowFields">';
					if(mssql_num_rows($res1) == 0)
					{
						echo '<input class="login1" value="No characters available" disabled>';
					} else
					{
						echo '<select name="char1" class="login2">';
							while($chcoins = mssql_fetch_assoc($res1))
							{
								echo '<option value="'.$chcoins['CID'].'">'.$chcoins['Name'].' (Tokens: '.$chcoins['Tokens'].')</option>';
							} 
						echo '</select>
						<input type="submit" name="coins" class="login" value="Get Coins"/>';
					}
					
					$resultstat = 1 * $_MODE[PTOKENS];
					if($_MODE[CONVERT] == 0)
					{
						$resulttext = 'coins';
					} elseif($_MODE[CONVERT] == 1)
					{
						$resulttext = 'tokens';
					}
					echo '</div>
					<div class="formRowDesc"><span class="descArrow">�</span> You must have at least 1 token in your character to get cash coins. 1 token = '.$resultstat.' '.$resulttext.'.</div>
				</div>
			</form>
		</div>
	</div>';
	
?>