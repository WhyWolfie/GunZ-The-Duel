<?
SetTitle("Control Panel");
include "mode/mod_loginneed.php";

if($_GET['action'] == "prestige")
{
	$prestigech = clean($_POST['prestigech']);
	
	mssql_query("UPDATE Character SET Level = 1, XP = 0, PLevel = PLevel + 1, Tokens = Tokens + 1 WHERE CID = '$prestigech'");
	alertbox("Character successfully prestige. Enjoy!",$_TITLE[USERCP]);
}

if($_GET['action'] == "gift" )
{
	$giftuser = clean($_POST[giftuser]);
	$coins = clean($_POST[giftcoins]);
	$user = $_SESSION['UserID'];
	
	$res = mssql_query("SELECT * FROM Account WHERE UserID = '$giftuser'");
	
	if($res == 0) 
	{
		alertbox("Account name that you put does not exist in the database.",$_TITLE[USERCP]);
	} else 
	{
		if($coins == "")
		{
			alertbox("You must put in a value in order to gift coins to the user.",$_TITLE[USERCP]);
		}
		if(!(int)$coins)
		{
			alertbox("The coin value input is not an integer. Please put a number.",$_TITLE[USERCP]);
		} elseif((int)$coins) 
		{
			if($coins > 0)
			{
				$query = mssql_query("SELECT Coins FROM Account WHERE UserID = '$user'");
				$row = mssql_fetch_assoc($query);
				if($row['Coins'] >= $coins)
				{
					$q = mssql_query("SELECT Coins FROM Account WHERE UserID = '$giftuser'");
					$res = mssql_fetch_assoc($q);
					$updatecoins = $res['Coins'] + $coins;
					$upusercoins = $row['Coins'] - $coins;
					$query1 = mssql_query("UPDATE Account SET Coins = '$updatecoins' WHERE UserID = '$giftuser'");
					$query2 = mssql_query("UPDATE Account SET Coins = '$upusercoins' WHERE UserID = '$user'");
					
					alertbox("Coins successfully gifted to the user.",$_TITLE[USERCP]);
				} else 
				{
					alertbox("You do not have enough coins to gift.",$_TITLE[USERCP]);
				}
			}  else
			{
				alertbox("Coin value must be greater than 0.",$_TITLE[USERCP]);
			}
		} else 
		{
			alertbox("The amount needs to be an integer greater than equal to 1.",$_TITLE[USERCP]);
		}
	}
}

if($_GET['action'] == "changesex" )
{
	$sexchar = clean($_POST[sexchar]);
	$gender = clean($_POST[gender]);
	
	mssql_query("UPDATE Character SET Sex = '$gender' WHERE CID = '$sexchar'");
	alertbox("The selected character gender has changed.",$_TITLE[USERCP]);
}

if($_GET['character'] == "recover")
{
	$cid = clean($_POST['recchar']);
	$qcharinfo = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
	
	if( mssql_num_rows($qcharinfo) == 0)
	{
		alertbox("The selected Character does not exist or does not belong to your account.",$_TITLE[USERCP]);
	}
	
	$info = mssql_fetch_assoc($qcharinfo);

	if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
	{
		alertbox("A character with the selected name already exists. Unfortunately, this character can not be recovered.", $_TITLE[USERCP]);
	}
	if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
	{
		mssql_query("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
	}
	elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
	{
		mssql_query("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
	}
	elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
	{
		mssql_query("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
	}
	elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
	{
		mssql_query("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
	}
	else
	{
		alertbox("Your account has 4 active characters, that is the maximum allowed. You have to delete one of your characters to recover the selected one.",$_TITLE[USERCP]);
	}
	alertbox("The selected character has been recovered successfully.",$_TITLE[USERCP]);
}

$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION[AID]."' AND DeleteFlag = '0'");
$qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 1");

echo '<div id="midBlockCon">
		<div class="midBlockContent">
			<span>User Control Panel</span>
			<hr>
			<p>This is your control panel. You are limited to doing certain things only. The control panel only has things that you are allow to do for free.</p>
			<hr>';
			
				if($_MODE[PRESTIGE] == 1)
				{
					$expmin = $_MODE[EXPMIN];
					$preschar = mssql_query("SELECT * FROM Character WHERE PLevel != 15 AND XP >= '$expmin' AND DeleteFlag = 0 AND AID = '".$_SESSION['AID']."'");
					echo $text[prestigechar].'<br>
						<form method="post" action="'.$_TITLE[USERCP].'&action=prestige">
							<div class="formRow">
								<div class="formRowTitle">Character name: </div>
								<div class="formRowFields">';
								if(mssql_num_rows($preschar) == 0)
								{
									echo '<input type="text" value="No characters available" class="login1" disabled>';
								} else 
								{
									echo '<select name="prestigech" class="login2">';
									while($fetch = mssql_fetch_assoc($preschar)) 
									{
										echo '<option value="'.$fetch['CID'].'">'.$fetch['Name'].' - Lv.'.$fetch['Level'].' (Prestige '.$fetch['PLevel'].')</option>';
									}
									echo '</select>
									<input type="submit" name="prestige" class="login" value="Prestige"/>';
								}
							echo '</div>
								<div class="formRowDesc"><span class="descArrow">�</span> Note: You are only allowed to prestige if your character has more than '.$_MODE[EXPMIN].' experience points.</div>
							</div>
						</form>
						<hr>';
				}
				echo '<form action="'.$_TITLE[USERCP].'&action=gift" method="post" name="gift">
					<div class="formRowOne">
						<div class="formRowTitle">
							To:
						</div>
						<div class="formRowFields">
							<input type="text" name="giftuser" class="login2"/>
							
							Amount of coins:
							<input type="text" name="giftcoins" class="login2"/>
							
							<input type="submit" name="gift" class="login" value="Gift"/></p>
						</div>
						<div class="formRowDesc">
							<span class="descArrow">�</span> You can gift coins to other user and member.
						</div>
					</div>
				</form>
				<hr>
				<div class="formRow">
					<div class="formRowTitle">&nbsp;</div>
					<div class="formRowFields ">
						<p>You can upload your clan emblem to your clan if you are the leader of the clan.</p>
						<p><a href="'.$_TITLE[CLANEMB].'">Click here if you want to upload your clan emblem.</a></p>
					</div>
					<div class="formRowDesc">&nbsp;</div>
				</div>
				<hr>
				<form action="'.$_TITLE[USERCP].'&do=character&action=changesex" method="post" name="changesex">
					<div class="formRowOne">
						<div class="formRowTitle">Character name: </div>
						<div class="formRowFields">';
							if(mssql_num_rows($query) == 0)
							{
								echo '<input class="login1" value="No characters available" disabled>';
							} else
							{
								echo '<select name="sexchar" class="login2"/>';
								while($charid = mssql_fetch_assoc($query))
									{
										echo '<option value="'.$charid['CID'].'">'.$charid['Name'].'</option>';
									}
								echo '</select>
								To: 
								<select name="gender" class="login2">
									<option value="0">Male</option>
									<option value="1">Female</option>
								</select>
								<input type="submit" name="changesex" class="login" value="Change" />';
							}
						echo '</div>
						<div class="formRowDesc">
							<span class="descArrow">�</span> You can change your character gender here.
						</div>
					</div>
				</form>
				<hr>
				<form action="'.$_TITLE[USERCP].'&character=recover" method="post">
					<div class="formRow">
						<div class="formRowTitle">Character name: </div>
						<div class="formRowFields">';
							if(mssql_num_rows($qchars) == 0)
							{
								echo '<input type="text" value="No characters available" class="login1" disabled>';
							} else
							{
								echo '<select name="recchar" class="login2">';
								while($data = mssql_fetch_assoc($qchars))
								{
									if($data[DeleteFlag] == "1")
									{
										echo '<option value="'.$data[CID].'">'.$data[DeleteName].'</option>';
									}
								}
								echo '</select>
								<input type="submit" name="recover" class="login" value="Recover" />';
							}
							echo '</div>
						<div class="formRowDesc">
							<span class="descArrow">�</span> Here is where you can recover your character if you have any that you deleted.
						</div>
					</div>
				</form>';
		
		echo '</div>
	</div>';
?>