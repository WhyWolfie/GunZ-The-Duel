<?
SetTitle("Processing your Order");
include_once('paypal/config.inc.php');
include_once('paypal/global_config.inc.php');

if(isset($_POST['paynow']))
{
	$firstname = $_POST['firstname'];
	$address1 = $_POST['address1'];
	$country = $_POST['country'];
	$zipcode = $_POST['zipcode'];
	$email = $_POST['email'];
	$conemail = $_POST['conemail'];
	$amount = $_POST['amount'];
	
	$totamo = $amount * $_MODE[DONATECOINS];
	$itemname = $totamo." coins for ".$_GUNZ[NAME];
	$_POST['item_name'] = $itemname;
	$er = 0;

	if($address1 == "")
	{
		alertbox("Please enter in your address",$_TITLE[BILLING]);
		die();
		$er	= 1;
	}
	
	if($zipcode == "")
	{
		alertbox("Please enter your ZIP code.",$_TITLE[BILLING]);
		die();
		$er	= 1;
	}
	
	if($email == "")
	{
		alertbox("Please enter your e-mail.",$_TITLE[BILLING]);
		die();
		$er	= 1;
	}

	if($conemail == "")
	{
		alertbox("Please re-enter your e-mail.",$_TITLE[BILLING]);
		die();
		$er	= 1;
	}
	
	if($email != $conemail)
	{
		alertbox("Please make sure that your have re-enter your e-mail and are the same e-mail.",$_TITLE[BILLING]);
		die();
		$er	= 1;
	}
	
	if($er == 0)
	{		
		echo '<div id="midBlockCon">
				<div class="midBlockContent minimumHeight">
					<body onLoad="document.paypal_form.submit();">
						<form method="post" name="paypal_form" action="'.$paypal[url].'">';
							showVariables();
						echo '<center><b>Processing data. Please wait while you are being redirected to our Paypal payment...</b></center>
						</form>
					</body>
				</div>
			</div>';
	}
}
?>