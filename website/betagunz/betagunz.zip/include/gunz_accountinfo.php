<?
	SetTitle("");
	include "mode/mod_loginneed.php";
	
	$error = "";
	$er = 0;
	$registered = 0;

	$z = mssql_fetch_assoc(mssql_query("SELECT * FROM Account WHERE AID = {$_SESSION['AID']}"));
	$x = mssql_fetch_assoc(mssql_query("SELECT * FROM Login WHERE AID = {$_SESSION['AID']}"));

	if($_GET['action'] == "save")
	{
		$pass1          = clean($_POST['pass1']);
		$pass2          = clean($_POST['pass2']);
		$email          = clean($_POST['email']);
		$cemail			= clean($_POST['cemail']);
		$name           = clean($_POST['name']);
		$sex            = clean($_POST['sex']);
		$address        = clean($_POST['address']);
		$zipcode        = clean($_POST['zipcode']);
		$country        = clean($_POST['country']);
		$question       = clean($_POST['question']);
		$answer         = clean($_POST['answer']);
		
		if($_POST['imgurl'] != "")
		{
			$_POST['imgurl'] = "'".$_POST['imgurl']."'";
		} elseif($_POST['imgurl'] == "")
		{
			$_POST['imgurl'] = "NULL";
		}
		
		$imgurl			= $_POST['imgurl'];
		
		$birthyear		= $_POST['birthyear'];
		$birthmonth		= $_POST['birthmonth'];
		$birthday		= $_POST['birthday'];
		
		$age = getAge($birthyear, $birthmonth, $birthday);
		
		if($pass1 != $x[Password])
		{
			if($pass1 == "")
			{
				alertbox("Password is empty.",$_TITLE[ACCDET]);
				$era = 1;
			}
			if($pass2 == "")
			{
				alertbox("Re-enter your password.",$_TITLE[ACCDET]);
				$era = 1;
			}
			if($pass1 != $pass2)
			{
				alertbox("Passwords do not match.",$_TITLE[ACCDET]);
				$era = 1;
			}
			if ($era == 0)
			{
				mssql_query("UPDATE Login SET Password = '$pass1' WHERE AID = '". clean($_SESSION['AID'])."'" );
			} else 
			{
				$er = 1;
			};
		}
		if($email == "")
		{
			alertbox("E-mail is empty.",$_TITLE[ACCDET]);
			$er = 1;
		}
		if($email == $z[Email])
		{
			$echeck = 1;
		} else
		{
			$echeck = 0;
		}
		if($echeck == 0)
		{
			if($cemail == "")
			{
				alertbox("Re-enter your e-mail.",$_TITLE[ACCDET]);
				$er = 1;
			} elseif($email != $cemail)
			{
				alertbox("E-mails do not match.",$_TITLE[ACCDET]);
				$er = 1;
			}
			$er = 1;
		}
		if($name == "")
		{
			alertbox("Name area is empty.",$_TITLE[ACCDET]);
			$er = 1;
		}
		if($address == "")
		{
			alertbox("Address is empty.",$_TITLE[ACCDET]);
			$er = 1;
		}
		if($zipcode == "")
		{
			alertbox("ZIP code is empty.",$_TITLE[ACCDET]);
			$er = 1;
		}
		if($answer == "")
		{
			alertbox("Security answer is empty.",$_TITLE[ACCDET]);
			$ert = 1;
		}
		if($z[SQ] != $z[SQ] || $answer != $z[SA])
		{
			if($pass2 == "")
			{
				alertbox("You have changed your security question and/or answer, thus you must re-enter your password.",$_TITLE[ACCDET]);
				$er = 1;
			}
			$er1 = 1;
		}
		if ($ert == 0)
		{
			mssql_query("UPDATE Account SET SA = '$answer', SQ = '$z[SQ]' WHERE AID = '". clean($_SESSION['AID'])."'" );
		} else
		{
			$er =1;
		}

		if($er == 0)
		{			
			$registered = 1;
			mssql_query("UPDATE Account SET 
				Name = '$name', Email = '$email', Age = '$age', Sex = '$sex', 
				Country= '$country', ZipCode= '$zipcode', Address= '$address', 
				BirthYear = '$birthyear', BirthMonth = '$birthmonth', BirthDay = '$birthday',
				ImgURL = $imgurl 
				WHERE AID = '{$_SESSION['AID']}'" );
			alertbox("Your account information has been updated.",$_TITLE[ACCDET]);
		}
	}

	$fr['UserID']        = $z[UserID];
	$fr['Email']         = $z[Email];
	$fr['Password']      = $x[Password];
	$fr['Name']          = $z[Name];
	$fr['Age']           = $z[Age];
	$fr['Sex']           = $z[Sex];
	$fr['address']       = $z[Address];
	$fr['zipcode']       = $z[ZipCode];
	$fr['Country']       = $z[Country];
	$fr['question']      = $z[SQ];
	$fr['answer']        = $z[SA];
	$fr['ImgURL']		 = $z[ImgURL];
	$fr['BirthYear']	 = $z[BirthYear];
	$fr['BirthMonth']	 = $z[BirthMonth];
	$fr['BirthDay']		 = $z[BirthDay];
?>
<script type="text/javascript" src="scripts/checkuser-1.0.0.min.js"></script>
<?
	if($_MODE[CHECKPASS] == 0)
	{
		echo '<script type="text/javascript" src="scripts/checkpass-1.0.0.min.js"></script>';
	} elseif($_MODE[CHECKPASS] == 1)
	{
		echo '<style type"text/css">
				<!--
					@import \'css/checkpass.css\';
				-->
				</style>
				<script type="text/javascript" src="scripts/checkpass-2.0.0.min.js"></script>
				<script type="text/javascript">
				$(document).ready( function() {
					$("#pass1").passStrength({
						userid: "#userid",
						baseStyle: "results"
					});
				});';
	}
?>
</script>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Account Details</span>
		<hr>
			<div class="formRowOne">
				<div class="formRowFields" style="width: 100%;">
					Here is where you can edit your account information if you want. It does require you to re-enter your password if you change your e-mail, password, 
					security question and/or security answer. We are doing this for security authorization.
				</div>
			</div>
		<hr>
		<form name="profile" method="POST" action="<? echo $_TITLE[ACCDET]; ?>&action=save" onsubmit="document.getElementById('birthyear').disabled = false;document.getElementById('birthmonth').disabled = false;document.getElementById('birthday').disabled = false;">
			<div class="formRowOne">
				<div class="formRowTitle">Current account name: </div>
				<div class="formRowFields"><input disabled type="text" name="userid" value="<?=$fr['UserID']?>" id="userid" class="login1"></div>
				<div class="formRowDesc"><span class="descArrow">�</span> Your username cannot be change once you have created it. We are trying to pervent account problems.</div>
			</div>
			<hr>
			<div class="formRow">
				<div class="formRowTitle">Image URL: </div>
				<div class="formRowFields"><input type="text" name="imgurl" value="<?=$fr['ImgURL']?>" class="login1"></div>
				<div class="formRowDesc"><span class="descArrow">�</span> Here is where you can edit your image URL that you can customize yourself, and it will display in the user block.</div>
			</div>
			<hr>
			<div class="formRowTwo">
				<div class="formRowTitle">
					<div>Your current email: </div>
					<div>Re-enter your email: </div>
				</div>
				<div class="formRowFields">
					<div><input name="email" type="text" class="login1" value="<?=$fr['Email']?>"></div>
					<div><input class="login1" type="text" name="cemail"></div>
				</div>
				<div class="formRowDesc"><span class="descArrow">�</span> It is required of you to re-enter your email just for verification if you change your email. This is also a security check for your account.</div>
			</div>
			<hr>
			<div class="formRowTwo">
				<div class="formRowTitle">
					<div>Choose a password:</div>
					<div>Re-enter password:</div>
				</div>
				<div class="formRowFields">
					<div><input name="pass1" id="pass1" type="password" class="login1" value="<?=$fr['Password']?>"></div>
					<div><input name="pass2" id="pass2" type="password" class="login1"></div>
				</div>
				<div class="formRowDesc">
						<div class="passStr"><div id="passStatus"></div></div><br/>
						<span class="descArrow">�</span> Changing password requires you to re-enter your password again for security reasons.
				</div>
			</div>
			<hr>
			<div class="formRow clearfix">
				<div class="formRowTitle">
					<div>Full Name: </div>
					<div>Birthday: </div>
					<div>Gender: </div>
				</div>
				<div class="formRowFields">
					<div><input name="name" type="text" class="login1" value="<?=$fr['Name']?>"></div>
					<div>
						<select name="birthmonth" id="birthmonth" class="login2 minmargin" disabled>
							<option value="1" <? if($fr['BirthMonth'] == 1) { echo 'selected'; } ?>>January</option>
							<option value="2" <? if($fr['BirthMonth'] == 2) { echo 'selected'; } ?>>February</option>
							<option value="3" <? if($fr['BirthMonth'] == 3) { echo 'selected'; } ?>>March</option>
							<option value="4" <? if($fr['BirthMonth'] == 4) { echo 'selected'; } ?>>April</option>
							<option value="5" <? if($fr['BirthMonth'] == 5) { echo 'selected'; } ?>>May</option>
							<option value="6" <? if($fr['BirthMonth'] == 6) { echo 'selected'; } ?>>June</option>
							<option value="7" <? if($fr['BirthMonth'] == 7) { echo 'selected'; } ?>>July</option>
							<option value="8" <? if($fr['BirthMonth'] == 8) { echo 'selected'; } ?>>August</option>
							<option value="9" <? if($fr['BirthMonth'] == 9) { echo 'selected'; } ?>>September</option>
							<option value="10" <? if($fr['BirthMonth'] == 10) { echo 'selected'; } ?>>October</option>
							<option value="11" <? if($fr['BirthMonth'] == 11) { echo 'selected'; } ?>>November</option>
							<option value="12" <? if($fr['BirthMonth'] == 12) { echo 'selected'; } ?>>December</option>
						</select>
						<select name="birthday" id="birthday" class="login2" disabled>
							<option value='1' <? if($fr['BirthDay'] == 1) { echo 'selected'; } ?>>1</option>
							<option value='2' <? if($fr['BirthDay'] == 2) { echo 'selected'; } ?>>2</option>
							<option value='3' <? if($fr['BirthDay'] == 3) { echo 'selected'; } ?>>3</option>
							<option value='4' <? if($fr['BirthDay'] == 4) { echo 'selected'; } ?>>4</option>
							<option value='5' <? if($fr['BirthDay'] == 5) { echo 'selected'; } ?>>5</option>
							<option value='6' <? if($fr['BirthDay'] == 6) { echo 'selected'; } ?>>6</option>
							<option value='7' <? if($fr['BirthDay'] == 7) { echo 'selected'; } ?>>7</option>
							<option value='8' <? if($fr['BirthDay'] == 8) { echo 'selected'; } ?>>8</option>
							<option value='9' <? if($fr['BirthDay'] == 9) { echo 'selected'; } ?>>9</option>
							<option value='10' <? if($fr['BirthDay'] == 10) { echo 'selected'; } ?>>10</option>
							<option value='11' <? if($fr['BirthDay'] == 11) { echo 'selected'; } ?>>11</option>
							<option value='12' <? if($fr['BirthDay'] == 12) { echo 'selected'; } ?>>12</option>
							<option value='13' <? if($fr['BirthDay'] == 13) { echo 'selected'; } ?>>13</option>
							<option value='14' <? if($fr['BirthDay'] == 14) { echo 'selected'; } ?>>14</option>
							<option value='15' <? if($fr['BirthDay'] == 15) { echo 'selected'; } ?>>15</option>
							<option value='16' <? if($fr['BirthDay'] == 16) { echo 'selected'; } ?>>16</option>
							<option value='17' <? if($fr['BirthDay'] == 17) { echo 'selected'; } ?>>17</option>
							<option value='18' <? if($fr['BirthDay'] == 18) { echo 'selected'; } ?>>18</option>
							<option value='19' <? if($fr['BirthDay'] == 19) { echo 'selected'; } ?>>19</option>
							<option value='20' <? if($fr['BirthDay'] == 20) { echo 'selected'; } ?>>20</option>
							<option value='21' <? if($fr['BirthDay'] == 21) { echo 'selected'; } ?>>21</option>
							<option value='22' <? if($fr['BirthDay'] == 22) { echo 'selected'; } ?>>22</option>
							<option value='23' <? if($fr['BirthDay'] == 23) { echo 'selected'; } ?>>23</option>
							<option value='24' <? if($fr['BirthDay'] == 24) { echo 'selected'; } ?>>24</option>
							<option value='25' <? if($fr['BirthDay'] == 25) { echo 'selected'; } ?>>25</option>
							<option value='26' <? if($fr['BirthDay'] == 26) { echo 'selected'; } ?>>26</option>
							<option value='27' <? if($fr['BirthDay'] == 27) { echo 'selected'; } ?>>27</option>
							<option value='28' <? if($fr['BirthDay'] == 28) { echo 'selected'; } ?>>28</option>
							<option value='29' <? if($fr['BirthDay'] == 29) { echo 'selected'; } ?>>29</option>
							<option value='30' <? if($fr['BirthDay'] == 30) { echo 'selected'; } ?>>30</option>
							<option value='31' <? if($fr['BirthDay'] == 31) { echo 'selected'; } ?>>31</option>
						</select>
						<select name="birthyear" id="birthyear" class="login2" disabled>
							<? include "other/con_year.php"; ?>
						</select>
						
						<input type="checkbox" onclick="
						document.profile.birthmonth.disabled = !document.profile.birthmonth.disabled; 
						document.profile.birthday.disabled = !document.profile.birthday.disabled; 
						document.profile.birthyear.disabled = !document.profile.birthyear.disabled;"> Edit?</input>
					</div>
					<div>
						<select size="1" name="sex" class="login1">
							<option value="0" <? if($fr['Sex'] == 0) { echo 'selected'; } ?>>Male</option>
							<option value="1" <? if($fr['Sex'] == 1) { echo 'selected'; } ?>>Female</option>
						</select>
					</div>
				</div>
				<div class="formRowDesc">
					<span class="descArrow">�</span> This is where you will edit your details about yourself. It won't require you to re-enter your password.
				</div>
			</div>
			<hr>
			<div class="formRow clearfix">
				<div class="formRowTitle">
					<div>Current Address: </div>
					<div>ZIP code: </div>
					<div>Country: </div>
				</div>
				<div class="formRowFields">
					<div><input name="address" type="text" class="login1" value="<?=$fr['address']?>"></div>
					<div><input name="zipcode" type="text" class="login1" value="<?=$fr['zipcode']?>"></div>
					<div>
						<select name="country" class="login1">
							<? include "other/country.php";?>
						</select>
					</div>
				</div>
				<div class="formRowDesc">
					<span class="descArrow">�</span> It is required of you to have this filled out. You should use your real information just in case.
				</div>
			</div>
			<hr>
			<div class="formRow clearfix">
				<div class="formRowTitle">
					<div>Security Question: </div>
					<div>Security Answer: </div>
				</div>
				<div class="formRowFields">
					<div>
						<select type="text" class="login1" name="question" class="login1" id="question">
							<option value="What is the name of your school?" <? if($fr['question'] == "What is the name of your school?") { echo 'selected'; } ?>>What is the name of your school?</option>
							<option value="What is your favorite color?" <? if($fr['question'] == "What is your favorite color?") { echo 'selected'; } ?>>What is your favorite color?</option>
							<option value="What is your favorite team?" <? if($fr['question'] == "What is your favorite team?") { echo 'selected'; } ?>>What is your favorite team?</option>
							<option value="What is the name of your pet?" <? if($fr['question'] == "What is the name of your pet?") { echo 'selected'; } ?>>What is the name of your pet?</option>
							<option value="What city were you born in?" <? if($fr['question'] == "What city were you born in?") { echo 'selected'; } ?>>What city were you born in?</option>
						</select>
					</div>
					<div><input name="answer" type="password" class="login1" id="answer" value="<?=$fr['answer']?>"></div>
				</div>
				<div class="formRowDesc">
					<span class="descArrow">�</span> Security question and answer are used to recover your password if you have forgotten your password for your account. <br/>
					Note: if you change your question and/or answer, you must re-enter your password.
				</div>
			</div>
			<hr>
			<div class="formRow">
				<div class="formRowTitle">&nbsp;</div>
				<div class="formRowFields"><input type="submit" name="submit" class="login" value="Save"></div>
				<div class="formRowDesc">&nbsp;</div>
			</div>
		</form>
	</div>
</div>