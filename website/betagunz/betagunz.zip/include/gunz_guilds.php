<?
SetTitle("Guild Rankings");

$res = mssql_query("SELECT TOP 4 * FROM Clan WHERE DeleteFlag=0 ORDER BY Point DESC, CLID ASC, Wins DESC, Losses ASC");
$Count = 0;
while($resa = mssql_fetch_object($res))
{
	$FirstClan[$Count][Name]        = $resa->Name;
	$FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "clan/emblem/no_emblem.png" : $resa->EmblemUrl;

	if($Count == 4)
		break;
	else
		$Count++;
}

$firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[0][EmblemURL];
$firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[1][EmblemURL];
$firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[2][EmblemURL];
$firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "clan/emblem/no_emblem.png" : $FirstClan[3][EmblemURL];

$firstclanname0 = ($FirstClan[0][Name] == "") ? $text[nodatatxt] : $FirstClan[0][Name];
$firstclanname1 = ($FirstClan[1][Name] == "") ? $text[nodatatxt] : $FirstClan[1][Name];
$firstclanname2 = ($FirstClan[2][Name] == "") ? $text[nodatatxt] : $FirstClan[2][Name];
$firstclanname3 = ($FirstClan[3][Name] == "") ? $text[nodatatxt] : $FirstClan[3][Name];
if(isset($_GET['type']) && isset($_GET['name']))
{
	$search = 1;
	$type = clean($_GET['type']);
	$name = clean($_GET['name']);
	
	if($name == "")
	{
		alertbox("No valid input is filled in the search box.", $_TITLE[GUILD]);
	}

	if($type == 1)
	{
		$squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
	} elseif($type == 2) 
	{
		$charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
		if( mssql_num_rows($charq) == 1 )
		{
			$characterdata = mssql_fetch_row($charq);
			$cid = $characterdata[0];
			$squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Point DESC, CLID ASC, Wins DESC, Losses ASC";
		} else 
		{
			echo '<tr><td align="center" colspan="8"><p align="center">No data</td></tr>';
		}
	} else 
	{
		$search = 0;
	}
} else 
{
	$search = 0;
}
 if( $search == 0 )
{
	$res = mssql_query("SELECT * FROM Clan WHERE DeleteFlag=0 ORDER BY Point DESC, CLID ASC, Wins DESC, Losses ASC");
} else
{
	$res = mssql_query($squery);
}

echo '<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Guild Rankings</span>
		<hr>
		<span id="searchZone">
			<form method="GET" name="indsearch" action="'.$_TITLE[GUILD].'" class="float_right">
				<input type="hidden" name="gunz" value="guilds" />
					<select name="type" class="login2">
						<option value="1">Clan name</option>
						<option value="2">Character name</option>
					</select>
				<input type="text" name="name" class="login2"/>
				<input type="submit" value="Search" class="login" />
			</form>
		</span>';
		$toprank = '<table id="topclanTable">
					  <tr>
						<td align="center"><img src="./'.$firstclanemb0.'" /></td>
						<td align="center"><img src="./'.$firstclanemb1.'" /></td>
						<td align="center"><img src="./'.$firstclanemb2.'" /></td>
						<td align="center"><img src="./'.$firstclanemb3.'" /></td>
					  </tr>
					  <tr>
						<td><center><b><font color="#ff7700">1ST '.$firstclanname0.'</font></b></center></td>
						<td><center><b>2ND '.$firstclanname1.'</b></center></td>
						<td><center><b>3RD '.$firstclanname2.'</b></center></td>
						<td><center><b>4TH '.$firstclanname3.'</b></center></td>
					  </tr>
					</table> ';
		echo $toprank;
	echo '<table width="100%" align="center" cellspacing="5" cellpadding="0" id="clantable">
			<tr align="center">
				<td align="center" width="30"><b>Rank</b></td>
				<td align="center" width="50"><b>Mark</b></td>
				<td align="center" width="90"><b>Name</b></td>
				<td align="center" width="70"><b>Leader</b></td>
				<td align="center" width="50"><b>Wins</b></td>
				<td align="center" width="50"><b>Losses</b></td>
				<td align="center" width="50"><b>Ratio</b></td>
				<td align="center" width="50"><b>Points</b></td>
			</tr>
			<tr>
				<td colspan="30"><hr></td>
			</tr>';
				if(mssql_num_rows($res) <> 0)
				{
					$count = 1;
					while($clan = mssql_fetch_assoc($res))
					{
						$clanemburl = ($clan['EmblemUrl'] == "") ? "clan/emblem/no_emblem.png" : $clan['EmblemUrl'];
						echo '<tr align="center" height="30">
							<td align="center">'.$count.'</td>
							<td align="center"><img src="'.$clanemburl.'" width="20" height="20"></td>
							<td align="center"><a href="'.$_TITLE[CLAN].'&id='.$clan['CLID'].'">'.$clan['Name'].'</a></td>
							<td align="center"><a href="'.$_TITLE[CHAR].'&id='.$clan['MasterCID'].'">'.FormatCharName($clan['MasterCID']).'</a></td>
							<td align="center">'.number_format($clan['Wins'], 0, "", ",").'</td>
							<td align="center">'.number_format($clan['Losses'], 0, "", ",").'</td>
							<td align="center">'.GetClanPercent($clan['Wins'], $clan['Losses']).'</td>
							<td align="center">'.number_format($clan['Point'], 0, "", ",").'</td>
						</tr>';
						$count++;
					}
				} else 
				{
					echo '<tr><td align="center" colspan="8"><p align="center">No data</td></tr>';
				}
		echo '</table>
	</div>
</div>';
?>