<?
	SetTitle("V.I.P Central");
	
	$getshop = mssql_query("SELECT * FROM CashShop");

	$getacc = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
	$acc = mssql_fetch_assoc($getacc);
	
	if($_GET['sub'] == "buyitem")
	{
		if($_SESSION['AID'] <> "")
		{
			if(isset($_POST['submit']))
			{
				$itemid = clean($_POST['ItemID']);
				$res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$itemid'");
				$item = mssql_fetch_assoc($res);
				$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
				$acc = mssql_fetch_assoc($res2);
				
				$aid = $_SESSION['AID'];
				$updatCoins = $acc['Coins'] - $item['CashPrice'];
				$zitemid = $item['ItemID'];
				
				mssql_query("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '$zitemid', GETDATE(), 1)");
				mssql_query("UPDATE Account SET Coins = '$updatCoins' WHERE AID = '$aid'");
				alertbox("Item correctly brought. It will now show up in your Central bank.", $_TITLE[VIP]."&sub=listallitems&type=2");
				
			}
		}
	}
	
	if($_GET['sub'] == "giftitem")
	{
		if($_SESSION['AID'] <> "")
		{
			if(isset($_POST['submit']))
			{
				$giftuser = clean($_POST['giftuser']);
				$itemid = clean($_POST['ItemID']);
				$type = clean($_POST['gettype']);
				
				if($giftuser == "")
				{
					alertbox("No a valid input.", $_TITLE[VIP]."&sub=giftitem&itemid=".$itemid);
				}
				
				$res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$itemid'");
				$item = mssql_fetch_assoc($res);
				$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
				$acc = mssql_fetch_assoc($res2);
				
				if($type == 1)
				{
					$quer = mssql_query("SELECT AID FROM Account WHERE UserID = '$giftuser'");
				} elseif($type == 2)
				{
					$quer = mssql_query("SELECT AID FROM Character WHERE Name = '$giftuser'");
				}
				$getgift = mssql_fetch_assoc($quer);
				$giftaid = $getgift['AID'];
				
				if(mssql_num_rows($quer) == 0)
				{
					alertbox("The input you put does not exist in the ddatabase.","{$_SESSION['HTTP_REFERER']}");
				} else
				{
					$aid = $_SESSION['AID'];
					$updatCoins = $acc['Coins'] - $item['CashPrice'];
					$zitemid = $item['ItemID'];
					
					mssql_query("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$giftaid', '$zitemid', GETDATE(), 1)");
					mssql_query("UPDATE Account SET Coins = '$updatCoins' WHERE AID = '$aid'");
					alertbox("Successfully gifted. Please notify the member.", $_TITLE[VIP]."&sub=listallitems&type=2");
				}
			}
		}
	}
	
	if($_GET['sub'] == "namechange")
	{
		if($_SESSION['AID'] <> "")
		{
			if($_GET['action'] == "change")
			{    
				function antisql2($sql)
				{
					$sql = str_replace("'","''",$sql);
					$sql = strip_tags($sql);
					$sql = addslashes($sql);
					return $sql;
				}
			
				$cid = antisql2($_POST['cid']);
				$charname = antisql2($_POST['charname']);
				$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '$aid'");
				$acc = mssql_fetch_assoc($res2);
				$aid = $_SESSION['AID'];
				$changecost = $acc['Coins'] - $_MODE[COINS];

				$query = mssql_query("SELECT Name FROM Character WHERE Name = '$charname'");
				if($charname == "")
				{
					alertbox("You must have a name in the input in order to change your character\'s name.", $_TITLE[VIP]."&sub=namechange");
					
				} else
				{
					if( mssql_num_rows($query) != 0 )
					{
						alertbox("There is a character with this name already. Please choose a different one.", $_TITLE[VIP]."&sub=namechange");
						
					} else 
					{
						mssql_query("UPDATE Character SET Name = '$charname' WHERE CID = '$cid'");
						mssql_query("UPDATE Account SET Coins = '$changecost' WHERE AID = '$aid'");
						alertbox("Character name successfully changed. Enjoy!", $_TITLE[VIP]."&sub=listallitems&type=2");
					}
				}
			}
		}
	}
	if($_GET['sub'] == "account")
	{
		if($_SESSION['AID'] <> "")
		{
			if($_GET['action'] == "unban")
			{    
				$accuser = $_POST['accuser'];
				
				$res2 = mssql_query("SELECT * FROM Account WHERE AID = '$aid'");
				$acc = mssql_fetch_assoc($res2);
				
				$changecost = $acc['Coins'] - $_MODE[UNBANCOST];
				
				mssql_query("UPDATE Account SET Coins = '$changecost', UGradeID = '0' WHERE AID = '$accuser'");
				alertbox("Your account has been unbanned. Enjoy! Please try not to do what you did that got yourself banned.", $_TITLE[VIP]."&sub=listallitems&type=2");
			}
		}
	}
?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>GunZ Store</span>
		<hr>
		<script type="text/javascript" src="scripts/store-1.0.0.min.js"></script>
		<div class="textRight">
			<form name="slot">
				Select your category: 
				<select size="1" name="type" onchange="changeType()" class="login2">
					<option>SELECT YOUR OPTION</option>
					<option value="<? echo $_TITLE[VIP];?>&sub=listallitems&type=1">Melee weapons</option>
					<option value="<? echo $_TITLE[VIP];?>&sub=listallitems&type=2">Range weapons</option>
					<option value="<? echo $_TITLE[VIP];?>&sub=listallitems&type=3">Sets/suits</option>
					<option value="<? echo $_TITLE[VIP];?>&sub=listallitems&type=5">Special items</option>
					<option value="<? echo $_TITLE[VIP];?>&sub=namechange">Character name change</option>
					<? if($acc['AID'] <> "" && $acc['UGradeID'] == 253) { echo '<option value="'.$_TITLE[VIP].'&sub=account">Unban your account</option>'; }?>
				</select>
			</form>
		</div>
		<hr>
		<div id="itemArea" class="clearfix">
			<?
				if(!isset($_GET['type']))
				{
					$type = "";
				} else
				{
					$type = "Slot = '".$_GET['type']."' AND";
				}
				$res = mssql_query("SELECT * FROM CashShop WHERE ".$type." Opened = '1' ORDER BY ItemID ASC");
				if(mssql_num_rows($res) == 0)
				{
					echo '<div class="noData">No data</div>';
				} else
				{
					if(empty($_GET['sub']))
					{
						while($item = mssql_fetch_assoc($res)) 
						{
							echo '
							<table id="itemlist">
								<tr>
									<td align="center" valign="top" width="120" rowspan="6"><div><img border="2" src="'.$item['WebImgName'].'"></div></td>
								</tr>
								<tr>
									<td colspan="3">
										<div><a href="'.$_TITLE[VIP].'&sub=details&id='.$item['CSID'].'"><b>'.$item['Name'].'</b></a></div>
										<div>Type: '.GetTypeByID($item['Slot']).'</div>
										<div>Sex: '.GetSexByID($item['ResSex']).'</div>
										<div>Level: '.$item['ResLevel'].'</div>
										<div>Price: '.$item['CashPrice'].'</div>
								</tr>
								<tr>
									<td></td>
									<td>
										<span><a href="'.$_TITLE[VIP].'&sub=details&id='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_details.gif"/></a></span>';
										if($_SESSION['AID'] <> "")
										{
											echo '<span><a href="'.$_TITLE[VIP].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif"/></a></span>
												<span><a href="'.$_TITLE[VIP].'&sub=giftitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_gift.gif"/></a></span>';
										}
							echo '
									</td>
								</tr>
							</table>';
						}
					} else
					{
						if($_GET['sub'] == "listallitems")
						{
							while($item = mssql_fetch_assoc($res)) 
							{
								echo '
								<table id="itemlist">
									<tr>
										<td align="center" valign="top" width="120" rowspan="6"><div><img border="2" src="'.$item['WebImgName'].'" /></div></td>
									</tr>
									<tr>
										<td colspan="3">
											<div><a href="'.$_TITLE[VIP].'&sub=details&id='.$item['CSID'].'"><b>'.$item['Name'].'</b></a></div>
											<div>Type: '.GetTypeByID($item['Slot']).'</div>
											<div>Sex: '.GetSexByID($item['ResSex']).'</div>
											<div>Level: '.$item['ResLevel'].'</div>
											<div>Price: '.$item['CashPrice'].'</div>
									</tr>
									<tr>
										<td></td>
										<td>
											<span><a href="'.$_TITLE[VIP].'&sub=details&id='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_details.gif"/></a></span>';
											if($_SESSION['AID'] <> "")
											{
												echo '<span><a href="'.$_TITLE[VIP].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif"/></a></span>
													<span><a href="'.$_TITLE[VIP].'&sub=giftitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_gift.gif"/></a></span>';
											}
								echo '
										</td>
									</tr>
								</table>';
							}
						} 
						
						if($_GET['sub'] == "details")
						{
							if($_GET['id'] == "")
							{
								header("Location: ".$_TITLE[VIP]."");
							}
							$itemid = clean($_GET['id']);
							$res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$itemid'");
							$item = mssql_fetch_assoc($res);
							
							echo '<table id="itemdetails" align="center">
									<tr>
										<td align="center" width="120">
											<img border="2" src="'.$item['WebImgName'].'" />';
											if($_SESSION['AID'] <> "")
											{
												echo '<a href="'.$_TITLE[VIP].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif" width="47" height="19" border="0" /></a>
												<a href="'.$_TITLE[VIP].'&sub=giftitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_gift.gif" width="47" height="19" border="0" /></a>';
											}
										echo '</td>
										<td align="center" valign="top">
											<table width="100%" border="0">
												<tr><td colspan="2" align="left"><b>'.$item['Name'].'</b></td></tr>
												<tr><td colspan="2" align="left">'.$item['Description'].'</td></tr>
												<tr>
													<td width="83" align="left">Slot:</td>
													<td width="100%" align="right">'.GetTypeByID($item['Slot']).'</td>
												</tr>
												<tr>
													<td align="left">Sex:</td>
													<td align="right">'.GetSexByID($item['ResSex']).'</td>
												</tr>
												<tr>
													<td align="left">Level:</td>
													<td align="right">'.$item['ResLevel'].'</td>
												</tr>
												<tr>
													<td align="left">Weight:</td>
													<td align="right">'.$item['Weight'].'</td>
												</tr>
												<tr>
													<td align="left">Price:</td>
													<td align="right">'.$item['CashPrice'].'</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td colspan="2" align="center">
											<table width="100%" border="0" align="center">
												<tr>
													<td width="109">Damage : </td>
													<td width="44">'.$item['Damage'].'</td>
													<td width="103">AP :</td>
													<td width="44">'.$item['AP'].'</td>
													<td width="103">FR : </td>
													<td width="50">'.$item['FR'].'</td>
												</tr>
												<tr>
													<td>Delay : </td>
													<td>'.$item['Delay'].'</td>
													<td>HP : </td>
													<td>'.$item['HP'].'</td>
													<td>PR :</td>
													<td>'.$item['PR'].'</td>
												</tr>
												<tr>
													<td>Magazine : </td>
													<td>'.$item['Magazine'].'</td>
													<td>Max WT : </td>
													<td>'.$item['MaxWeight'].'</td>
													<td>CR :</td>
													<td>'.$item['CR'].'</td>
												</tr>
												<tr>
													<td>Max Bullet : </td>
													<td>'.$item['MaxBullet'].'</td>
													<td>Reload : </td>
													<td>'.$item['ReloadTime'].'</td>
													<td>LR : </td>
													<td>'.$item['LR'].'</td>
												</tr>
												<tr>
													<td>Control : </td>
													<td>'.$item['Control'].'</td>
													<td>Duration : </td>
													<td><b>Unlimited</b></td>
													<td height="18"></td>
													<td></td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td colspan="2" align="center"><input type="button" class="login" value="Back" onclick="history.go(-1);return true;"></td>
									</tr>
								</table>';
						}
						
						if($_GET['sub'] == "buyitem")
						{
							if($_SESSION['AID'] <> "")
							{
								$item2 = clean($_GET['itemid']);
								$res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$item2'");
								$item = mssql_fetch_assoc($res);
								$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
								$acc = mssql_fetch_assoc($res2);	
								
								echo '<table id="itembuy" align="center">
										<tr>
											<td colspan="2" align="center" class="imgURL"><img src="'.$item['WebImgName'].'" /></td>
										</tr>
										<tr>
											<td width="175" align="left">Item name: </td>
											<td width="175" align="left">'.$item['Name'].'</td>
										</tr>
										<tr>
											<td align="left">Current bill: </td>
											<td align="left">'.$_SESSION['UserID'].'</td>
										</tr>
										<tr>
											<td align="left">Price:</td>
											<td align="left">'.$item['CashPrice'].'</td>
										</tr>
										<tr>
											<td align="left">Coins: </td>
											<td align="left">'.$acc['Coins'].'</td>
										</tr>
										<tr>
											<td align="left">Results: </td>
											<td align="left"><b>';
													$result = $acc['Coins'] - $item['CashPrice'];
													if($result < 0)
													{
														$getitem = "<b>Insufficient Coins</b>";
													} else
													{
														$getitem = "<input type='submit' value='Buy' name='submit' class='login'>";
													}
														echo $acc['Coins']-$item['CashPrice'];
												echo '</b>
											</td>
										</tr>
										<tr>
											<td colspan="2" align="center"><font color="#FF0000"><b>We are not responsible for your mistakes if you do not want this item</b></font></td>
										</tr>
										<tr>
											<td colspan="2" align="center">
												<form method="POST" action="'.$_TITLE[VIP].'&sub=buyitem">
													'.$getitem.'
													<input type="hidden" value="'.$_GET['itemid'].'" name="ItemID">
												</form>
											</td>
										</tr>
									</table>';
							}
						}
						
						if($_GET['sub'] == "giftitem")
						{
							if($_SESSION['AID'] <> "")
							{
								$item2 = clean($_GET['itemid']);
								$res = mssql_query("SELECT * FROM CashShop WHERE CSID = '$item2'");
								$item = mssql_fetch_assoc($res);
								$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
								$acc = mssql_fetch_assoc($res2);	
								
								echo '<form method="POST" action="'.$_TITLE[VIP].'&sub=giftitem">
									<table id="itemgift" align="center">
										<tr>
											<td colspan="2" align="center"><img src="'.$item['WebImgName'].'" /></td>
										</tr>
										<tr>
											<td width="175" align="left">Item name: </td>
											<td width="175" align="left">'.$item['Name'].'</td>
										</tr>
										<tr>
											<td align="left">Current bill: </td>
											<td align="left">'.$_SESSION['UserID'].'</td>
										</tr>
										<tr>
											<td align="left">Price:</td>
											<td align="left">'.$item['CashPrice'].'</td>
										</tr>
										<tr>
											<td align="left">Coins: </td>
											<td align="left">'.$acc['Coins'].'</td>
										</tr>
										<tr>
											<td align="left">Results: </td>
											<td align="left"><b>';
													$result = $acc['Coins'] - $item['CashPrice'];
													if($result < 0)
													{
														$getitem = "<b>Insufficient Coins</b>";
													} else
													{
														$getitem = "<input type='submit' value='Gift' name='submit' class='login'>";
													}
														echo $acc['Coins'] - $item['CashPrice'];
												echo '</b>
											</td>
										</tr>
										<tr>
											<td align="left" class="noPadding">
												<select name="gettype" class="login2">
													<option value="1">Account name</option>
													<option value="2">Character name</option>
												</select>
											</td>
											<td align="left" class="noPadding"><input class="login2" name="giftuser"></td>
										</tr>
										<tr>
											<td colspan="2" align="center"><font color="#FF0000"><b>We are not responsible if you made a mistake while gifting</b></font></td>
										</tr>
										<tr>
											<td colspan="2" align="center">
													'.$getitem.'
													<input type="hidden" value="'.$_GET['itemid'].'" name="ItemID">
											</td>
										</tr>
									</table>
								</form>';
							}
						}
						
						if($_GET['sub'] == "namechange")
						{
							if($_SESSION['AID'] <> "")
							{
								$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
								$acc = mssql_fetch_assoc($res2);
								$aid = $_SESSION['AID'];

								$result = $acc['Coins'] - $_MODE[COINS];

								$code = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND CharNum != '-1' AND DeleteFlag = 0");
								echo '<form method="post" action="'.$_TITLE[VIP].'&sub=namechange&action=change">
										<style type="text/css">
										<!--
											@import \'css/accountinfo.css\';
										-->
										</style>
										'.$text[usernamechan].'<br>';
										if ($result < 0)
										{
											echo '<div class="formRow">
														<div class="formRowTitle">Results: </div>
														<div class="formRowFields" style="padding: 3px 0;"><font color="red"><b>Insufficient Coins</b></font></div>
														<div class="formRowDesc">&nbsp;</div>
													</div>';
										} else 
										{ 
											echo '<div class="formRowOne">
														<div class="formRowTitle">Results: </div>
														<div class="formRowFields" style="padding: 3px 0;">'.$acc['Coins'].' - '.$_MODE[COINS].' = '.$result.' remaining
														</div>
														<div class="formRowDesc">You can change your name here, but name change cost '.$_MODE[COINS].' coins.</div>
													</div>
													<hr>
													<div class="formRowOne">
															<div class="formRowTitle">Character name: </div>
															<div class="formRowFields">';
																if(mssql_num_rows($code) == 0)
																{
																	echo '<input class="login1" value="No character available" disabled>';
																} else
																{
																	echo '<select size="1" name="cid" class="login2">';
																		while( $char = mssql_fetch_assoc($code))
																		{
																			echo '<option value="'.$char['CID'].'">'.$char['Name'].'</option>';
																		}
																	echo '</select>
																	'.$text[usercto].':
																	<input type="text" class="login2" name="charname" size="40" maxlength="12">
																	<input type="submit" class="login" name="namechange" value="Change">';
																}
															echo '</div>
															<div class="formRowDesc"><span class="descArrow">�</span> <font color="red">Note: 12 characteristics is the maximum that you can enter in.</font></div>
													</div>';
										}
								echo '</form>';
							}
						}
						
						if($_GET['sub'] == "account")
						{
							if($_SESSION['AID'] <> "")
							{
								$res2 = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
								$acc = mssql_fetch_assoc($res2);
								$aid = $_SESSION['AID'];
								$result = $acc['Coins'] - $_MODE[UNBANCOST];

								$code = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."' AND UGradeID = '253'");
								
								echo '<form method="post" action="'.$_TITLE[VIP].'&sub=account&action=unban">
										<style type="text/css">
										<!--
											@import \'css/accountinfo.css\';
										-->
										</style>';
										if ($result < 0)
										{
											echo '<div class="formRowOne">
														<div class="formRowDesc">&nbsp;</div>
														<div class="formRowFields" style="padding: 4px 0;"><font color="red"><b>Insufficient Coins</b></font></div>
														<div class="formRowTitle">Results: </div>
													</div>';
										} else 
										{ 
											echo '<div class="formRowOne">
														<div class="formRowTitle">Results: </div>
														<div class="formRowFields" style="padding: 3px 0;">'.$acc['Coins'].' - '.$_MODE[UNBANCOST].' = '.$result.' remaining</div>
														<div class="formRowDesc"><span class="descArrow">�</span> You can unban your account, but it cost '.$_MODE[UNBANCOST].' coins.</div>
													</div>
													<hr>
													<div class="formRowOne">
															<div class="formRowTitle"></div>
															<div class="formRowDesc">&nbsp;</div>
															<div class="formRowFields noPadding">';
																if(mssql_num_rows($code) == 0)
																{
																	echo '<input class="login1" value="Your account is not currently banned." disabled>';
																} else
																{
																	echo '<input type="hidden" name="accuser" value="'.$_SESSION['AID'].'">
																	<input type="submit" class="login" name="unban" value="Unban your account">';
																}
															echo '</div>
													</div>';
										}
										
								echo '</form>';
							}
						}
					}
				}
			?>
		</div>
	</div>
</div>