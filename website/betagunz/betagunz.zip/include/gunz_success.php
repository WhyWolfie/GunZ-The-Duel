<?
SetTitle("Donation Confirmation");

include "paypal/config.inc.php"; 
include "paypal/global_config.inc.php"; 

if(isset($paypal['business']))
{	
	$payment = $_POST[payment_gross];
	$transcode = $_POST[txn_id];
	$payemail = $_POST[payer_email];
	
	$res = mssql_query("SELECT * FROM PayPal WHERE TransactionID = '$transcode'");
	
	if(mssql_num_rows($res) == 0)
	{
		$chkacc = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
		$acc = mssql_fetch_assoc($chkacc);
		
		$aiduser = $_SESSION['AID'];
		
		mssql_query("INSERT INTO Paypal ([TransactionID],[Amount],[Email],[Date],[AID]) VALUES ('$transcode','$payment','$payemail',GETDATE(), '$aiduser')");
		
		$check = mssql_query("SELECT * FROM Paypal WHERE TransactionID = '$transcode' AND AID = '$aiduser'");
		$get = mssql_fetch_assoc($check);
		
		$amount = $get['Amount'] * $_MODE[DONATECOINS];
		if(!$_SESSON['AID'] == "" || !$amount == "")
		{
			mssql_query("UPDATE Account SET Coins = Coins + '$amount' WHERE AID = '$aiduser'");
		}
	} else
	{
		alertbox("This transaction ID has already been confirmed. Please make a different payment if you are trying to get more coins.",$_TITLE[INDEX]);
	}
}

?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Confirmation Information</span>
		<hr>
		<div class="formRow">
			<div class="formRowTitle">&nbsp;</div>
			<div class="formRowFields">Didn't get your coins? Post it in our forum to get support.</div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<hr>
		<div class="formRow">
			<div class="formRowTitle">Transaction #: </div>
			<div class="formRowFields noPadding"><input class="login1" value="<?=$_POST[txn_id]?>" readonly="readonly" onclick="javascript:select();"></div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<div class="formRow">
			<div class="formRowTitle">Date: </div>
			<div class="formRowFields noPadding"><input class="login1" value="<?=$_POST[payment_date]?>" readonly="readonly" onclick="javascript:select();"></div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<hr>
		<div class="formRow">
			<div class="formRowTitle">First name: </div>
			<div class="formRowFields noPadding"><input class="login1" value="<?=$_POST[first_name]?>" readonly="readonly" onclick="javascript:select();"></div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<div class="formRow">
			<div class="formRowTitle">Last name: </div>
			<div class="formRowFields noPadding"><input class="login1" value="<?=$_POST[last_name]?>" readonly="readonly" onclick="javascript:select();"></div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<div class="formRow">
			<div class="formRowTitle">E-mail: </div>
			<div class="formRowFields noPadding"><input class="login1" value="<?=$_POST[payer_email]?>" readonly="readonly" onclick="javascript:select();"></div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
		<hr>
		<div class="formRow">
			<div class="formRowTitle">&nbsp;</div>
			<div class="formRowFields noPadding">Thank you for your donation. Your order has been completed.</div>
			<div class="formRowDesc">&nbsp;</div>
		</div>
	</div>
</div>