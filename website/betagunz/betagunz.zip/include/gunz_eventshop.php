<?
	SetTitle("V.I.P Central");
	
	$getshop = mssql_query("SELECT * FROM EventCashShop");

	$getacc = mssql_query("SELECT * FROM Account WHERE AID = '".$_SESSION['AID']."'");
	$acc = mssql_fetch_assoc($getacc);
	
	if($_GET['sub'] == "buyitem")
	{
		if($_SESSION['AID'] <> "")
		{
			if(isset($_POST['submit']))
			{
				$itemid = clean($_POST['ItemID']);
				$res = mssql_query("SELECT * FROM EventCashShop WHERE CSID = '$itemid'");
				$item = mssql_fetch_assoc($res);
				$res2 = mssql_query("SELECT ECoins FROM Account WHERE AID = '".$_SESSION['AID']."'");
				$acc = mssql_fetch_assoc($res2);
				
				$aid = $_SESSION['AID'];
				$updatCoins = $acc['ECoins'] - $item['EventPrice'];
				$zitemid = $item['ItemID'];
				
				mssql_query("INSERT INTO AccountItem ([AID], [ItemID], [RentDate], [Cnt])VALUES('$aid', '$zitemid', GETDATE(), 1)");
				mssql_query("UPDATE Account SET ECoins = '$updatCoins' WHERE AID = '$aid'");
				alertbox("Item correctly brought. It will now show up in your Central bank.", $_TITLE[EVENT]."&sub=listallitems&type=2");
				
			}
		}
	}
?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>GunZ Store</span>
		<hr>
		<script type="text/javascript" src="scripts/store-1.0.0.min.js"></script>
		<div class="textRight">
			<form name="slot">
				Select your category: 
				<select size="1" name="type" onchange="changeType()" class="login2">
					<option>SELECT YOUR OPTION</option>
					<option value="<? echo $_TITLE[EVENT];?>&sub=listallitems&type=1">Melee weapons</option>
					<option value="<? echo $_TITLE[EVENT];?>&sub=listallitems&type=2">Range weapons</option>
					<option value="<? echo $_TITLE[EVENT];?>&sub=listallitems&type=3">Sets/suits</option>
					<option value="<? echo $_TITLE[EVENT];?>&sub=listallitems&type=5">Special items</option>
				</select>
			</form>
		</div>
		<hr>
		<div id="itemArea" class="clearfix">
			<?
				if(!isset($_GET['type']))
				{
					$type = "";
				} else
				{
					$type = "Slot = '".$_GET['type']."' AND";
				}
				$res = mssql_query("SELECT * FROM EventCashShop WHERE ".$type." Opened = '1' ORDER BY ItemID ASC");
				
				if(mssql_num_rows($res) == 0)
				{
					echo '<div class="noData">No data</div>';
				} else
				{
					if(empty($_GET['sub']))
					{
						while($item = mssql_fetch_assoc($res)) 
						{
							echo '
							<table id="itemlist">
								<tr>
									<td align="center" valign="top" width="120" rowspan="6"><div><img border="2" src="'.$item['WebImgName'].'"></div></td>
								</tr>
								<tr>
									<td colspan="3">
										<div><a href="'.$_TITLE[EVENT].'&sub=details&id='.$item['CSID'].'"><b>'.$item['Name'].'</b></a></div>
										<div>Type: '.GetTypeByID($item['Slot']).'</div>
										<div>Sex: '.GetSexByID($item['ResSex']).'</div>
										<div>Level: '.$item['ResLevel'].'</div>
										<div>Price: '.$item['EventPrice'].'</div>
								</tr>
								<tr>
									<td></td>
									<td>
										<span><a href="'.$_TITLE[EVENT].'&sub=details&id='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_details.gif"/></a></span>';
										if($_SESSION['AID'] <> "")
										{
											echo '<span><a href="'.$_TITLE[EVENT].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif"/></a></span>';
										}
							echo '
									</td>
								</tr>
							</table>';
						}
					} else
					{
						if($_GET['sub'] == "listallitems")
						{
							while($item = mssql_fetch_assoc($res)) 
							{
								echo '
								<table id="itemlist">
									<tr>
										<td align="center" valign="top" width="120" rowspan="6"><div><img border="2" src="'.$item['WebImgName'].'" /></div></td>
									</tr>
									<tr>
										<td colspan="3">
											<div><a href="'.$_TITLE[EVENT].'&sub=details&id='.$item['CSID'].'"><b>'.$item['Name'].'</b></a></div>
											<div>Type: '.GetTypeByID($item['Slot']).'</div>
											<div>Sex: '.GetSexByID($item['ResSex']).'</div>
											<div>Level: '.$item['ResLevel'].'</div>
											<div>Price: '.$item['EventPrice'].'</div>
									</tr>
									<tr>
										<td></td>
										<td>
											<span><a href="'.$_TITLE[EVENT].'&sub=details&id='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_details.gif"/></a></span>';
											if($_SESSION['AID'] <> "")
											{
												echo '<span><a href="'.$_TITLE[EVENT].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif"/></a></span>';
											}
								echo '
										</td>
									</tr>
								</table>';
							}
						} 
						
						if($_GET['sub'] == "details")
						{
							if($_GET['id'] == "")
							{
								header("Location: ".$_TITLE[EVENT]."");
							}
							$itemid = clean($_GET['id']);
							$res = mssql_query("SELECT * FROM EventCashShop WHERE CSID = '$itemid'");
							$item = mssql_fetch_assoc($res);
							
							echo '<table id="itemdetails" align="center">
									<tr>
										<td align="center" width="120">
											<img border="2" src="'.$item['WebImgName'].'" />';
											if($_SESSION['AID'] <> "")
											{
												echo '<a href="'.$_TITLE[EVENT].'&sub=buyitem&itemid='.$item['CSID'].'"><img src="img/buttons/btn_itmshp_buy.gif" width="47" height="19" border="0" /></a>';
											}
										echo '</td>
										<td align="center" valign="top">
											<table width="100%" border="0">
												<tr><td colspan="2" align="left"><b>'.$item['Name'].'</b></td></tr>
												<tr><td colspan="2" align="left">'.$item['Description'].'</td></tr>
												<tr>
													<td width="83" align="left">Slot:</td>
													<td width="100%" align="right">'.GetTypeByID($item['Slot']).'</td>
												</tr>
												<tr>
													<td align="left">Sex:</td>
													<td align="right">'.GetSexByID($item['ResSex']).'</td>
												</tr>
												<tr>
													<td align="left">Level:</td>
													<td align="right">'.$item['ResLevel'].'</td>
												</tr>
												<tr>
													<td align="left">Weight:</td>
													<td align="right">'.$item['Weight'].'</td>
												</tr>
												<tr>
													<td align="left">Price:</td>
													<td align="right">'.$item['EventPrice'].'</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td colspan="2" align="center">
											<table width="100%" border="0" align="center">
												<tr>
													<td width="109">Damage : </td>
													<td width="44">'.$item['Damage'].'</td>
													<td width="103">AP :</td>
													<td width="44">'.$item['AP'].'</td>
													<td width="103">FR : </td>
													<td width="50">'.$item['FR'].'</td>
												</tr>
												<tr>
													<td>Delay : </td>
													<td>'.$item['Delay'].'</td>
													<td>HP : </td>
													<td>'.$item['HP'].'</td>
													<td>PR :</td>
													<td>'.$item['PR'].'</td>
												</tr>
												<tr>
													<td>Magazine : </td>
													<td>'.$item['Magazine'].'</td>
													<td>Max WT : </td>
													<td>'.$item['MaxWeight'].'</td>
													<td>CR :</td>
													<td>'.$item['CR'].'</td>
												</tr>
												<tr>
													<td>Max Bullet : </td>
													<td>'.$item['MaxBullet'].'</td>
													<td>Reload : </td>
													<td>'.$item['ReloadTime'].'</td>
													<td>LR : </td>
													<td>'.$item['LR'].'</td>
												</tr>
												<tr>
													<td>Control : </td>
													<td>'.$item['Control'].'</td>
													<td>Duration : </td>
													<td><b>Unlimited</b></td>
													<td height="18"></td>
													<td></td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td colspan="2" align="center"><input type="button" class="login" value="Back" onclick="history.go(-1);return true;"></td>
									</tr>
								</table>';
						}
						
						if($_GET['sub'] == "buyitem")
						{
							if($_SESSION['AID'] <> "")
							{
								$item2 = clean($_GET['itemid']);
								$res = mssql_query("SELECT * FROM EventCashShop WHERE CSID = '$item2'");
								$item = mssql_fetch_assoc($res);
								$res2 = mssql_query("SELECT Coins FROM Account WHERE AID = '".$_SESSION['AID']."'");
								$acc = mssql_fetch_assoc($res2);	
								
								echo '<table id="itembuy" align="center">
										<tr>
											<td colspan="2" align="center" class="imgURL"><img src="'.$item['WebImgName'].'" /></td>
										</tr>
										<tr>
											<td width="175" align="left">Item name: </td>
											<td width="175" align="left">'.$item['Name'].'</td>
										</tr>
										<tr>
											<td align="left">Current bill: </td>
											<td align="left">'.$_SESSION['UserID'].'</td>
										</tr>
										<tr>
											<td align="left">Price:</td>
											<td align="left">'.$item['EventPrice'].'</td>
										</tr>
										<tr>
											<td align="left">Tokens: </td>
											<td align="left">'.$acc['ECoins'].'</td>
										</tr>
										<tr>
											<td align="left">Results: </td>
											<td align="left"><b>';
													$result = $acc['ECoins'] - $item['EventPrice'];
													if($result < 0)
													{
														$getitem = "<b>Insufficient Tokens</b>";
													} else
													{
														$getitem = "<input type='submit' value='Buy' name='submit' class='login'>";
													}
														echo $acc['ECoins']-$item['EventPrice'];
												echo '</b>
											</td>
										</tr>
										<tr>
											<td colspan="2" align="center"><font color="#FF0000"><b>We are not responsible for your mistakes if you do not want this item</b></font></td>
										</tr>
										<tr>
											<td colspan="2" align="center">
												<form method="POST" action="'.$_TITLE[EVENT].'&sub=buyitem">
													'.$getitem.'
													<input type="hidden" value="'.$_GET['itemid'].'" name="ItemID">
												</form>
											</td>
										</tr>
									</table>';
							}
						}
					}
				}
			?>
		</div>
	</div>
</div>