<?
SetTitle("Logging Out");

if($_SESSION[AID] <> "")
{
    $u = $_SESSION[UserID];
	$a = $_SESSION[AID];
	
	mssql_query("UPDATE Account SET LastLogoutTime = GETDATE() WHERE AID = '$a'");
	
    session_unset();
	
    if (isset($_COOKIE[session_name()]))
    {
        setcookie(session_name(), '', time()-42000, '/');
    }
	
    session_destroy();
    unset($_SESSION['UserID']);
	
	alertbox("The user, ".clean($u).", has been successfully logged out.",$_TITLE[INDEX]);
} else 
{
	alertbox("You cannot logout because you are not logged in.",$_TITLE[INDEX]);
}
?>