<?
SetTitle("Members' Central");
include "mode/mod_logoutneed.php";

if ($_GET['step'] == "2")
{
	$userid = clean($_POST['userid']);
	
	if($userid == "")
	{
		alertbox("Type your Username.",$_TITLE[RESETP]."&step=1");
	}
	
	$res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");
	$_SESSION['resetpassuser'] = $userid;
	
	if(mssql_num_rows($res) == 0)
	{
		alertbox("The username that you enter does not exist in the database.",$_TITLE[RESETP]."&step=1");
	}
} elseif($_GET['step'] == "3")
{
	$answer = clean($_POST['answer']);
	$email = clean($_POST['email']);
	
	$res = mssql_query("SELECT * FROM Account WHERE Email = '$email' AND SA = '$answer'");
	
	if(mssql_num_rows($res) == 0)
	{
		alertbox("The information that you have provided does not match our records.",$_TITLE[RESETP]."&step=1");
	}
} elseif ($_GET['step'] == "done")
{
	if($_POST['pw1'] == $_POST['pw2'])
	{
		$pw1 = clean($_POST['pw1']);
		mssql_query("UPDATE Login SET Password = '$pw1' WHERE UserID = '".clean($_SESSION['resetpassuser'])."'");
		alertbox("Your account has been updated.",$_TITLE[MEMBER]);
	} else 
	{
		alertbox("Password does not match.",$_TITLE[RESETP]."&step=1");
	}
}
?>
<div class="rightBlock">
	<div class="blockCon textLeft">
		<? include "block/guestblock.php"; ?>
	</div>
</div>
<div id="leftColBlock">
	<div class="leftColBlock clearfix">
		<div class="h3">Reset</div>
		<div class="h2">Your password</div>
		<center>
			<div class="userReset">
			<? 
				if($_GET['step'] == "")
				{
					header("Location: ".$_TITLE[RESETP]."&step=1");
				} elseif($_GET['step'] == "1")
				{ 
					echo '<form method="POST" action="'.$_TITLE[RESETP].'&step=2" name="newpass">
							<table width="100%" border="0" cellpadding="5" cellspacing="10">
								<tr>
									<td colspan="2">It is required of you to fill out all that is followed or else you would have to start all over again.</td>
								</tr>
								<tr>
									<td align="left" width="50%">Account name</td>
									<td align="right" width="50%"><input name="userid" type="text" class="login1"></td>
								</tr>
								<tr>
									<td colspan="2" align="center"><input type="submit" value="Proceed" name="submit" class="login"></td>
								</tr>
							</table>
						</form>';
				} elseif ($_GET['step'] == "2")
				{
					$userid = clean($_POST['userid']);
					$res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid'");
					$_SESSION['resetpassuser'] = $userid;
					$info = mssql_fetch_assoc($res);
					
					echo '<form method="POST" action="'.$_TITLE[RESETP].'&step=3" name="newpass">
							<table width="100%" border="0" cellpadding="5" cellspacing="0">
								<tr>
									<td align="left">Current E-mail</td>
									<td align="right"><input name="email" type="text" class="login1"></td>
								</tr>
								<tr>
									<td align="left">Security Question</td>
									<td align="right"><b>'.$info['SQ'].'</b></td>
								</tr>
								<tr>
									<td align="left">Security Answer</td>
									<td align="right"><input name="answer" type="password" class="login1"></td>
								</tr>
								<tr>
									<td colspan="2" align="center"><input type="submit" value="Proceed" name="submit" class="login"></td>
								</tr>
							</table>
						</form>';
				} elseif ($_GET['step'] == "3")
				{
					$answer = clean($_POST['answer']);
					$email = clean($_POST['email']);
					
					$res = mssql_query("SELECT * FROM Account WHERE Email = '$email' AND SA = '$answer'");
					if(mssql_num_rows($res) == 1)
					{
						echo '<form method="POST" action="'.$_TITLE[RESETP].'&step=done" name="newpass">
								<table width="100%" border="0" cellpadding="5" cellspacing="0">
									<tr>
										<td align="left">New Password</td>
										<td align="right"><input name="pw1" type="password" class="login1"></td>
									</tr>
									<tr>
										<td align="left">Confirm Password</td>
										<td align="right"><input name="pw2" type="password" class="login1"></td>
									</tr>
									<tr>
										<td colspan="2" align="center"><input type="submit" value="Update" name="submit" class="login"></td>
									</tr>
								</table>
							</form>';
					}
				}
			?>
			</div>
		</center>
	</div>
</div>