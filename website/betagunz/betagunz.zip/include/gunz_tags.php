<?
	SetTitle("Gunz Signature");
	include "mode/mod_loginneed.php";
	
	$tagging = mssql_query("SELECT * FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."' AND CharNum != '-1'");

	if(mssql_num_rows($tagging) == 0)
	{
		alertbox("You do not have any characters made. Go and make some in order to use the signature feature.","index.php");
		die();
	} else
	{
		echo '<script type="text/javascript" src="scripts/signature-1.0.0.min.js"></script>
				<input type="hidden" value="'.$_LINK[GUNZ].'" id="url" name="url"/>
				<input type="hidden" value="'.$_TITLE[SIGN].'" id="tagurl" name="tagurl"/>
		<div id="midBlockCon">
			<div class="midBlockContent">
				<span>Gunz Character Tags</span>
				<hr>
				<form name="tags">
					<div class="formRow">
						<div class="formRowFields" style="width: 100%;">
							Here is where you can get your gunz signature image for forums and other sites to show. 
							The tags will show all four or only active character that you have created. 
							Characters will only be displayed if they are not deleted from your account. 
							If you do not see your character, please notify the staff members, so they can fix the problem.
						</div>
					</div>
					<hr>
					<div class="formRowOne">
						<div class="formRowTitle">Select character: </div>
						<div class="formRowFields">
							<select size="1" name="charlist" onchange="UpdateTag()" class="login1" style="width: 228px;">';
								while( $data = mssql_fetch_assoc($tagging))
								{
									echo '<option value="'.$data['CID'].'">'.$data['Name'].'</option>';
								}
							echo '</select><br/><br/>
						</div>
						<div class="formRowDesc">&nbsp;</div>
					</div>
					<hr>
					<div class="formRow clearfix">
						<div class="formRowTitle">Preview: </div>
						<div class="formRowFields">
							<span id="tag"></span>
						</div>
						<div class="formRowDesc">
							<div>
								<div>Forum Code:</div>
								<div><input type="text" name="forumcode" onclick="javascript:select();" readonly="readonly" class="login1" style="width: 220px;"></div>
							</div>
							<hr>
							<div>
								<div>Direct Link Code:</div>
								<div><input type="text" name="directlink" onclick="javascript:select();" readonly="readonly" class="login1" style="width: 220px;"></div>
							</div>
						</div>
					</div>
					<script type="text/javascript">
						UpdateTag();
					</script>
				</form>
			</div>
		</div>
	</div>';
}
?>