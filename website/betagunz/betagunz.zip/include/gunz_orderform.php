<?
SetTitle("Billing Information");

$res = mssql_query("SELECT * FROM Account WHERE AID = '{$_SESSION['AID']}'");
$user = mssql_fetch_assoc($res);
?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>Support us by donating</span>
		<hr>
		<form method="post" action="<? echo $_TITLE[PROCESS]; ?>" onsubmit="document.getElementById('firstname').disabled = false;">
			<table width="100%" cellspacing="5">
				<tr>
					<td align="left" colspan="2" style="padding: 0;">
						It is required of you to fill out all that is followed below. If any is not filled in, there will be a message saying you are required to fill out everything, 
						and you would have to start all over with filling out your information. It helps us get the information correctly while you are paying from your Paypal account.
					</td>
				</tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Current username: </div>
						<div>
							<input style="width:175px" class="login1" type="text" id="firstname" name="firstname" value="<?=$user['UserID']?>" disabled>
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;">
						All information as followed is from your own account details.
					</td>
				<tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Current e-mail: </div>
						<div>
							<input style="width:175px" class="login1" type="text" id="email" name="email" value="<?=$user['Email']?>">
						</div>
						<br/>
						<div>Re-enter e-mail: </div>
						<div>
							<input style="width:175px" class="login1" type="text" id="conemail" name="conemail">
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;">
						All you need to do is re-enter your e-mail or any other empty information to proceed to the Paypal payment.
					</td>
				<tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Current Address: </div>
						<div>
							<input style="width:175px" class="login1" type="text" id="address1" name="address1" value="<?=$user['Address']?>">
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;"></td>
				</tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Postal code: </div>
						<div>
							<input style="width:175px" class="login1" type="text" id="zipcode" name="zipcode" value="<?=$user['ZipCode']?>">
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;"></td>
				</tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Country: </div>
						<div>
							<select id="country" name="country" class="login2 selection">
								<? include "other/country.php"; ?>
							</select>
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;"></td>
				</tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr>
					<td align="left" width="220" style="padding: 0;">
						<div>Amount: </div>
						<div>
							<select name="amount" class="login2 selection">
								<option value="5" selected>5 coins | 5 USD</option>
								<option value="10">10 coins | 10USD</option>
								<option value="20">20 coins | 20USD</option>
								<option value="30">30 coins | 30USD</option>
								<option value="40">40 coins | 40USD</option>
								<option value="50">50 coins | 50USD</option>
								<option value="60">60 coins | 60USD</option>
								<option value="70">70 coins | 70USD</option>
								<option value="80">80 coins | 80USD</option>
								<option value="90">90 coins | 90USD</option>
								<option value="100">100 coins | 100USD</option>
							</select>
						</div>
					</td>
					<td align="left" width="400" style="padding: 0;">
						<div>You are able to change the value of your donation.</div>
						<div>Minimum donation: 5USD</div>
					</td>
				</tr>
				<tr height="10" valign="bottom"><td colspan="2" width="100%"><hr></td></tr>
				<tr align="center">
					<td align="right" colspan="2" height="30">
						<input type="submit" value="Proceed" name="paynow" id="paynow" class="login">
					</td>
				</tr>
			</table>
		</form>
	</div>
</div>