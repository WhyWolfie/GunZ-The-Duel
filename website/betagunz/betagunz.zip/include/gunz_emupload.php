<?
SetTitle("Clan Emblem Upload");
include "mode/mod_loginneed.php";
include "secure/sec.php";
 
if (isset($_GET['step'])) 
{
	$argv = explode('-',$_GET['step']);
	settype($argv,'array'); 
	$_GET['step'] = @$argv[0];
	$_GET['url'] = @$argv[1];
	$_GET['do'] = @$argv[2];
	$_GET['mess'] = @$argv[3];
}

$step = !isset($_GET['step']) ? home : $_GET['step'];
if($step == '2') 
{ 
	$user1 = clean($_POST['user']);
	$pass1 = clean($_POST['pass']);
	
	if (empty($user1))
	{
		alertbox("Account name is empty.",$_TITLE[CLANEMB]."&step=1");
		die();
	}
	if (empty($pass1))
	{
		alertbox("Password is not filled.",$_TITLE[CLANEMB]."&step=1");
		die();
	}
	$l = mssql_query("SELECT * FROM Login WHERE UserID = '$user1'");
	$log = mssql_fetch_assoc($l);
	
	if($log['UserID'] != $user1 || $log['Password'] != $pass1)
	{
		alertbox("Your information you have provided does not match our records.",$_TITLE[CLANEMB]."&step=1");
	}
}

if ($step == 'done') 
{
	$emblem = clean($_POST['uploaded']) ;
	$CLID = clean($_POST['clan']);
	$filename = basename($_FILES['uploaded']['name']);
	$target1 = "./clan/emblem/" . $CLID . "/";
	mkdir($target1);
	$target = $target1 . $filename;
	
	$ok=1;
	if (!($_FILES['uploaded']['size']  < '1'))
	{
		$ok=1;
		if(($_FILES['uploaded']['type'] == "image/jpeg"))
		{ 
			$ok=1;
		}
		if(($_FILES['uploaded']['type'] == "image/jpg"))
		{ 
			$ok=1;
		}
		if(($_FILES['uploaded']['type'] == "image/gif"))
		{ 
			$ok=1;
		}
		if(($_FILES['uploaded']['type'] == "image/png"))
		{ 
			$ok=1;
		}
		if(($_FILES['uploaded']['type'] == "image/bmp"))
		{ 
			$ok=1;
		}
	} else 
	{ 
		$ok=0;
	}
	if ($ok==0) 
	{
		alertbox("The file you were uploading is not allowed. Please check your file.",$_TITLE[CLANEMB]."&step=1");
	} else
	{
		if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) 
		{
			mssql_query ("UPDATE Clan SET EmblemUrl = '$target', EmblemCheckSum = EmblemCheckSum + 1 WHERE CLID = '$CLID'");
			alertbox("The emblem file has been successfully uploaded! Enjoy and have fun!",$_TITLE[USERCP]);
		} else 
		{
			alertbox("Sorry, this account does not exist or dont have access to upload the emblem.",$_TITLE[CLANEMB]."&step=1");
		}
	}
}
?>
<div id="midBlockCon">
	<div class="midBlockContent minimumHeight">
		<span>Emblem Upload</span>
		<hr>
		<? 	
			if(empty($_GET['step']))
			{
				header("Location: ".$_TITLE[CLANEMB]."&step=1");
			}
			if ($step == '1') 
			{ 
				echo'<FORM METHOD="POST" ACTION="'.$_TITLE[CLANEMB].'&step=2">
						<table width="100%" cellspacing="5" id="clanemblem">
							<tr>
								<td align="left" width="220">
									<div>Account name:</div>
									<div><input name="user" type="textfield" class="login2" value="'.$_SESSION['UserID'].'" style="width:175px"/></div>
								</td>
								<td align="left" width="400">
									<div>Log in to upload your clan emblem! (Only Leader)</div>
									<div>This is for security authorization.</div>
								</td>
							</tr>
							<tr><td colspan="2"><hr></td></tr>
							<tr>
								<td align="left" width="220">
									<div>Password</div>
									<div><input name="pass" type="password" class="login2" style="width:175px"/></div>
								</td>
								<td align="left" width="400"></td>
							</tr>
							<tr><td colspan="2"><hr></td></tr>
							<tr>
								<td colspan="2" align="right"><input name="submit" type="submit" value="Sign in" class="login"/></td>
							</tr>
						</table>
					</form>'; 
			}
			if ($step == '2') 
			{ 
				$user1 = clean($_POST['user']);
				$pass1 = clean($_POST['pass']);
					
				if (valida(array($user1,$pass1)) == TRUE)
				{
					$query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");
					
					$query1 = mssql_query("SELECT * From Character Where AID = '".$_SESSION['AID']."'");
					$query2 = mssql_fetch_assoc($query1);
					
					$charID = $query2['CID'];
					
					while($r = mssql_fetch_array($query))
					{
						if (mssql_num_rows($query) == 1)
						{
							$query2 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN
							Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where 
							Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' and (Clan.DeleteFlag = 0 OR Clan.DeleteFlag = NULL)");
							
							if (mssql_num_rows($query2) >= '1')
							{
								echo '<form enctype="multipart/form-data" action="'.$_TITLE[CLANEMB].'&step=done" method="POST">
										<table width="100%" cellspacing="5" id="clanemblem">
											<tr>
												<td align="left" width="220">
													<div>
														Select a file: 
														<input name="uploaded" type="file" class="login2 selection"/>
													</div>
													<div>
														Select a clan: 
														<select name="clan" class="login2 selection">';
														for($i='';$i < @mssql_num_rows($query2);++$i)
														{
															$row = @mssql_fetch_row($query2);
															$ClanName = $row[4];
															echo '<option value="'.$row[5].'">'.$ClanName.'</option>' ;
														}
															echo'
														</select>
													</div>
												</td>
												<td align="left" width="400">
													Only can upload .BMP, .PNG, .GIF, .JPEG and .JPG images for your emblem
												</td>
											</tr>
											<tr><td colspan="2"><hr></td></tr>
											<tr>
												<td colspan="2" align="right">
													<input type="submit" name="done" value="Upload" class="login"/>
												</td>
											</tr>
										</table>
									</form>';
							}
						}
					}
				}
			}
		?>
	</div>
</div>