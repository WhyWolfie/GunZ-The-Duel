<?
SetTitle("User Account Login");
if($_SESSION[AID] != "")
{
    header("Location: ");
    die();
}

if(isset($_POST[submit]))
{
    $user = clean($_POST[userid]);
    $pass = clean($_POST[pass]);

    $ip = $_SERVER['REMOTE_ADDR'];
	
	if($_POST[userid] == "" && $_POST[pass] == "")
	{
		alertbox("Account name and password is empty. Please fill them in.",$_TITLE[MEMBER]);
		die();
	} elseif($_POST[userid] == "")
	{
		alertbox("Account name is empty.",$_TITLE[MEMBER]);
		die();
	} elseif($_POST[pass] == "")
	{
		alertbox("Password is not filled in.",$_TITLE[MEMBER]);
		die();
	} else 
	{
		mssql_query("DELETE FROM LoginFails WHERE Time < " . (time() - 3600) );
		
		$strikeq = mssql_query("SELECT COUNT(*) AS strikes, MAX(Time) as lasttime FROM LoginFails WHERE IP = '$ip'");
		$strikedata = mssql_fetch_object($strikeq);

		if( $strikedata->strikes >= 5 && $strikedata->lasttime > ( time() - 900 ) )
		{
			alertbox($text[logimsg04],"");
			die();
		}
		$loginquery = mssql_query("SELECT l.UserID, l.AID, c.UGradeID, l.Password FROM Login(nolock) l INNER JOIN Account(nolock) c ON l.AID = c.AID WHERE l.UserID = '$user' AND l.Password = '$pass'");
		if(mssql_num_rows($loginquery) == 1)
		{
			$logindata = mssql_fetch_row($loginquery);

			$_SESSION[UserID] = $logindata[0];
			$_SESSION[AID] = $logindata[1];
			$_SESSION[UGradeID] = $logindata[2];
			$_SESSION[Password] = md5(md5($logindata[3]));

			$url = ($_SESSION[URL] == "") ? $_TITLE[INDEX] : $_SESSION[URL];
			$_SESSION[URL] = "";
			
			$loguser = $_SESSION['UserID'];
			
			mssql_query("UPDATE Account SET LastLoginTime = GETDATE() WHERE AID = '{$_SESSION[AID]}'");
			alertbox("Welcome back, {$loguser}! Feel free to explore the website.", $url);
		} else
		{
			mssql_query("INSERT INTO LoginFails (IP, UserID, Time) VALUES ('$ip', '$user', '" . time() . "')");
			alertbox("Information you have provided does not match our records.",$_TITLE[MEMBER]);
			die();
		}
	}
}
?>