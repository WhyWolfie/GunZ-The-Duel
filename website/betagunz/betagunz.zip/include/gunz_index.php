<?
	$ch = 1; $cl = 1;
	$tchar = mssql_query("SELECT TOP 5 * FROM Character ORDER BY XP DESC, Sex ASC");
	$tclan = mssql_query("SELECT TOP 5 * FROM Clan ORDER BY Point DESC, CLID ASC");
?>
<div class="rightBlock">
	<div class="blockCon textLeft">
		<div class="blockPadding">
			<b>Top Individuals</b>
			<hr>
			<ul class="listMember">
			<?
				if(mssql_num_rows($tchar) == 0)
				{
					echo '<li class="noRecords">No character records</li>';
				} else
				{
					while($topchar = mssql_fetch_assoc($tchar))
					{
						echo '<li>
								<div class="rankColumnNum">'.$ch.'</div> 
								<div class="rankColumnNam"><a href="'.$_TITLE[CHAR].'&id='.$topchar['CID'].'">'.$topchar['Name'].'</a></div> 
								<div class="rankColumnGetLv"><font color="orange">Lv</font> '.levelStats($topchar['XP']).'</div>
							</li>';
						$ch++;
					}
					echo '<li class="clearfix">
						<div class="rankColMore"><a href="'.$_TITLE[INDIV].'">More info</a></div>
					</li>';
				}
			?>
			</ul>
		</div>
	</div>
	<div class="blockCon textLeft">
		<div class="blockPadding">
			<b>Top Guilds</b>
			<hr>
			<ul class="listMember">
			<?
				if(mssql_num_rows($tclan) == 0)
				{
					echo '<span class="noRecords">No clan records</span>';
				} else
				{
					while($topclan = mssql_fetch_assoc($tclan))
					{
						echo '<li>
							<div class="rankColumnNum">'.$cl.'</div> 
							<div class="rankColumnNamCL"><a href="'.$_TITLE[CLAN].'&id='.$topclan['CLID'].'">'.$topclan['Name'].'</a></div> 
							<div class="rankColumnGetPts"><font color="lime">Pts</font> '.$topclan['Point'].'</div>
						</li>';
						$cl++;
					}
					echo '<li class="clearfix">
						<div class="rankColMore"><a href="'.$_TITLE[GUILD].'">More info</a></div>
					</li>';
				}
			?>
			</ul>
		</div>
	</div>
	<div class="blockCon textLeft">
		<div class="blockPadding">
			<b>Video Trailor</b>
		</div>
		<iframe src="<? echo $_URL[YOUTUBEVID]; ?>" frameborder="0" width="190" height="150"></iframe>
	</div>
</div>
<div id="leftColBlock">
	<div class="leftColBlock">
		<span>Latest announcements & news</span>
		<hr>
		<?
			$quer = mssql_query("SELECT TOP 3 * FROM IndexContent ORDER BY ICID DESC");
			
			if(mssql_num_rows($quer) == 0)
			{
				echo '<div class="noRecords">No data collected.</div>';
			} else
			{
				while($news = mssql_fetch_assoc($quer))
				{
					$ndate = strtotime($news['Date']);
					echo '<div class="textLeft">'.(date("Y-m-d H:i", $ndate)).' - '.$news['Text'].' <em>Submitted by '.GetUserByAID($news['AID']).'</em></div>';
				}
			}
		?>
	</div>
	<div class="leftColBlock">
		<span>Recent items added to the store <? //<font class="floatRight"><a href="#">more</a></font> ?></span>
		<hr>
		<div>
			<?
				$itemshp = mssql_query("SELECT TOP 7 * FROM CashShop WHERE Opened = 1 ORDER BY RegDate DESC");
				
				if(mssql_num_rows($itemshp) == 0)
				{
					echo 'There are recent items that has been added.';
				} else
				{
					echo '<center>';
					while($shopitem = mssql_fetch_assoc($itemshp))
					{
						echo '<div id="imgItemID">
								<a href="'.$_TITLE[VIP].'&sub=details&id='.$shopitem['CSID'].'">
									<img src="'.$shopitem['WebImgName'].'"/>
								</a>
							</div>';
					}
					echo '</center>';
				}
			?>
		</div>
	</div>
	<div class="leftColBlock">
		<span>Server information</span>
		<hr>
		<div class="clearfix">
			<div class="floatLeft" style="width: 48%;">
			<?
				$lastlvlup = mssql_query("SELECT TOP 1 * FROM LevelUpLog ORDER BY id DESC");
				$lvlup = mssql_fetch_assoc($lastlvlup);
				
				if(mssql_num_rows($lastlvlup) == 0)
				{
					echo 'No latest character leveled up.';
				} else
				{
					echo '<a href="'.$_TITLE[CHAR].'&cid='.$lvlup['CID'].'">'.$lvlup['CID'].'</a> has leveled up to '.$lvlup['Level'];
				}
				
				echo '<br/><br/>';
				
				$lastclan = mssql_query("SELECT TOP 1 * FROM Clan ORDER BY CLID DESC");
				$clancreate = mssql_fetch_assoc($lastclan);
				
				if(mssql_num_rows($lastclan) == 0)
				{
					echo 'No latest clan has been created.';
				} else
				{
					echo '<a href="'.$_TITLE[CLAN].'&clid='.$clancreate['CLID'].'">'.$clancreate['Name'].'</a> is the latest clan created.';
				}
				
				echo '<br/><br/>';
				
				$lastgame = mssql_query("SELECT TOP 1 * FROM GameLog ORDER BY id DESC");
				$gamelog = mssql_fetch_assoc($lastgame);
				
				if(mssql_num_rows($lastgame) == 0)
				{
					echo 'No games has been created in-game.';
				} else
				{
					echo 'The last game to be created was, "'.$gamelog['GameName'].$text[lastgameby].FormatCharName($gamelog['MasterCID']).'.';
				}
				
				echo '<br/><br/>';
				
				$lastclw = mssql_query("SELECT TOP 1 * FROM ClanGameLog ORDER BY id DESC");
				$clanwar = mssql_fetch_assoc($lastclw);
				
				if(mssql_num_rows($lastclw) == 0)
				{
					echo 'There are no clan war games recorded.';
				} else
				{
					echo '<a href="'.$_TITLE[CLAN].'&clid='.$clanwar['WinnerCLID'].'">'.$clanwar['WinnerClanName'].'</a> clan has beaten <a href="'.$_TITLE[CLAN].'&clid='.$clanwar['LoserCLID'].'">'.$clanwar['LoserClanName'].'</a>';
				}
				
				echo '<br/><br/>';
			?>
			</div>
			<div class="floatRight" style="width: 48%; text-align: right;">
			<?
				$killmost = mssql_query("SELECT TOP 1 * FROM Character ORDER BY KillCount DESC, CID ASC");
				$mostkills = mssql_fetch_assoc($killmost);
				
				if($mostkills['KillCount'] == 0)
				{
					echo 'There are no characters with most kills.';
				} else
				{
					echo GetCharNameByCID($mostkills['CID']).' has the most kills with '.$mostkills['KillCount'].'kills';
				}
				
				echo '<br/><br/>';
				
				$lastreg = mssql_query("SELECT TOP 1 * FROM Account ORDER BY AID DESC");
				$lastacc = mssql_fetch_assoc($lastreg);
				
				if(mssql_num_rows($lastreg) == 0)
				{
					echo $text[nolastreg];
				} else
				{
					echo 'The last user that register: '.FormatAccName($lastacc['AID']);
				}
				
				echo '<br/><br/>';
				
				$lstchcreate = mssql_query("SELECT TOP 1 * FROM Character ORDER BY CID DESC");
				$lastchar = mssql_fetch_assoc($lstchcreate);
				
				if(mssql_num_rows($lstchcreate) == 0)
				{
					echo $text[nolastchar];
				} else
				{
					echo 'The last character created: <a href="'.$_TITLE[CHAR].'&cid='.$lastchar['CID'].'">'.FormatCharName($lastchar['CID']).'</a>';
				}
				
				echo '<br/><br/>';
				
				$questlog = mssql_query("SELECT TOP 1 * FROM QuestGameLog ORDER BY id DESC");
				$lastquest = mssql_fetch_assoc($questlog);
				
				if(mssql_num_rows($questlog) == 0)
				{
					echo 'There are no records of quest games.';
				} else
				{
					echo 'Last quest game was \'('.substr($lastquest['GameName'],0,20).'...)\'';
				}
				
				echo '<br/><br/>';
			?>
			</div>
		</span>
	</div>
</div>