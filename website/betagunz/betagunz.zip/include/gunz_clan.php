<?
	if($_GET['id'] == "")
	{
		header("Location: index.php");
	} else 
	{
		$clid = $_GET['id'];
		
		
		
		$clan = mssql_query("SELECT * FROM Clan WHERE CLID = '$clid'");
		$guild = mssql_fetch_assoc($clan);
		
		$clanurl = ($guild['EmblemUrl'] == "") ? "clan/emblem/no_emblem.png" : $guild['EmblemUrl'];
		
		$clm = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) as total FROM ClanMember WHERE CLID = '$clid'"));
		
		echo '<div id="midBlockCon">
			<div class="midBlockContent clearfix">
				<span>'.$guild['Name'].'\'s Clan Details</span>
				<hr>
				<script type="text/javascript">
					function showHide(box,id) 
					{
					 var elm = document.getElementById(id)
					 elm.style.visibility = box.checked? "visible":"hidden"
					}
				</script>
				<div class="formRow">
					<div class="formRowTitle">
						<div>Ranking:</div>
						<div>Points:</div>
						<div>Wins:</div>
						<div>Losses:</div>
						<div>Draw:</div>
						<div>Ratio:</div>
						<div>Members:</div>
						<div>Clan Number:</div>
						<div>Created </div>
						<div>&nbsp;</div>
					</div>
					<div class="formRowFields">
						<div>'.number_format($guild['Ranking'], 0, "", ",").'</div>
						<div>'.number_format($guild['Point'], 0, "", ",").'</div>
						<div>'.number_format($guild['Wins'], 0, "", ",").'</div>
						<div>'.number_format($guild['Losses'], 0, "", ",").'</div>
						<div>'.number_format($guild['Draws'], 0, "", ",").'</div>
						<div>'.GetClanPercent($guild['Wins'], $guild['Losses']).'</div>
						<div>'.$clm['total'].'</div>
						<div>'.number_format($guild['CLID'], 0, "", ",").'</div>
						<div>'.time_elapsed_string(strtotime($guild['RegDate'])).'</div>
						<form action="'.$_TITLE[CLAN].'&id='.$guild['CLID'].'" method="post" name="message"  onsubmit="document.getElementById(\'intro\').disabled = false;">
							<div>';
								$charus = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$clid' AND Grade = 1");
								$chars = mssql_fetch_assoc($charus);
								$chcid = $chars['CID'];
								
								$userchar = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0 AND CID = '$chcid'");
								$charu = mssql_fetch_assoc($userchar);
								echo '<textarea id="intro" name="intro" class="login1" disabled>'.$guild['Introduction'].'</textarea></div>';
								if($chars['CID'] == $charu['CID'] && $_SESSION['AID'] == $charu['AID'])
								{
									echo '<p class="floatLeft">
												<input type="checkbox" onclick="document.message.intro.disabled = !document.message.intro.disabled; showHide(this,\'submit\');"> Edit
											</p>
											<p class="floatRight">	
												<input type="submit" name="submit" id="submit" value="Update" class="login" style="visibility: hidden;"> 
											</p>';
									if(isset($_POST['submit']))
									{
										$text = $_POST['intro'];
										
										if($text == "")
										{
											$text = 'No information posted.';
										}
										
										$intro = str_replace("'", "", $text);
										
										mssql_query("UPDATE Clan SET Introduction = '$intro' WHERE CLID = '$clid'");
										alertbox("Clan introduction has been updated.", $_TITLE[CLAN]."&id=".$clid);
									}
								
								}
						echo '</form>
					</div>
					<div class="formRowDesc">
						<span class="descArrow">�</span> Members Information
						<div>Name: '.$guild['Name'].'</div>
						<div>Since: '.date("F Y",strtotime($guild['RegDate'])).'</div>
						<div><img src="'.$clanurl.'" width="50" height="50" border="0"/></div>
						<div>';
							$clanleaders = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$clid' AND Grade = 1");
							echo '<p><span class="descArrow">�</span> Leader<br>';
							if(mssql_num_rows($clanleaders) == 0)
							{
								echo '<p class="clanMemList">-</p>';
							} else
							{
								while($leader = mssql_fetch_assoc($clanleaders))
								{
									echo '<p class="clanMemList"><a href="'.$_TITLE[CHAR].'&id='.$leader['CID'].'">'.FormatCharName($leader['CID']).'</a></p>';
								}
							}
							echo '</p>';
												
							$clanadm = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$clid' AND Grade = 2");
							echo '<p><span class="descArrow">�</span> Administrators<br>';
							if(mssql_num_rows($clanadm) == 0)
							{
								echo '<p class="clanMemList">-</p>';
							} else
							{
								while($admins = mssql_fetch_assoc($clanadm))
								{
									echo '<p class="clanMemList"><a href="'.$_TITLE[CHAR].'&id='.$admins['CID'].'">'.FormatCharName($admins['CID']).'</a></p>';
								}
							}
							echo '</p>';
							
							$clanmem = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$clid' AND Grade = 9");
							echo '<p><span class="descArrow">�</span> Members<br>';
							if(mssql_num_rows($clanmem) == 0)
							{
								echo '<p class="clanMemList">-</p>';
							} else
							{
								while($members = mssql_fetch_assoc($clanmem))
								{
									echo '<p class="clanMemList"><a href="'.$_TITLE[CHAR].'&id='.$members['CID'].'">'.FormatCharName($members['CID']).'</a></p>';
								}
							}
							echo '</p>
						</div>
					</div>
				</div>
			</div>
		</div>';
	}
?>