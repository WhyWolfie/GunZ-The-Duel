<?
	SetTitle("Mercenary Store");
?>
<div id="midBlockCon">
	<div class="midBlockContent">
		<span>GunZ Store</span>
		<hr>
		<center>
			<script type="text/javascript" src="scripts/store-1.0.0.min.js"></script>
			<div>
				<form name="storechange">
				Select your shop type: 
				<select class="login2" onchange="changeShop()" name="store">
					<option>SELECT YOUR OPTION</option>
					<option value="<? echo $_TITLE[VIP]; ?>">V.I.P Central</option>
					<option value="<? echo $_TITLE[EVENT]; ?>">Event Rewards</option>
					<? if($_SESSION['AID'] <> "" && $_MODE[PRESTIGE] == 1) { echo '<option value="'.$_TITLE[PRESTIGE].'">Prestige Shop</option>'; } ?>
				</select>
				</form>
			</div>
		</center>
	</div>
</div>