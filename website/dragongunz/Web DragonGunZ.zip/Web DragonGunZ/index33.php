﻿
<?php
include "configuracao/config.php";
include "protects/functions.php";
include "Configuracao/_functions.php";
include "Protects/banned.php";
include "Protects/banneduser.php";
include "php/title.php";
include 'php/sqlcheck.php';
include 'php/sql_check.php';
include 'Protects/anti_sql.php';
include 'Protects/antisql.php';
include 'Protects/antisql1.php';
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
include 'Protects/GeovaneSouza.php';
include '1.php';
include '2.php';
eval(base64_decode($protect_criminal_team)); 
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("php/ZoooDprotect_" . $_GET['plus'] . ".php")) {
        include "php/ZoooDprotect_" . $_GET['plus'] . ".php";
	}
} }
// Proteção Extra Sparrow//
$ip_logado = $_SERVER['REMOTE_ADDR'];
$arquivo = fopen("Protects/Sparrow/Sparrow.htm", "a+");
$escrever = fwrite($arquivo, "==========================<br>");
$escrever = fwrite($arquivo, "Login : $login_logado<br>");
$escrever = fwrite($arquivo, "IP : $ip_logado<br>");
$escrever = fwrite($arquivo, "Data : $data_logado<br>");
$escrever = fwrite($arquivo, "Hora : $hora_logado<br>");
$escrever = fwrite($arquivo, "==========================<br>");
fclose($arquivo);//
// Fim de Proteção Extra Sparrow//
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- Website coded by Thyers Nascimento( ZoooD[BR] ) - Designed by Antonio Robles //-->
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>Dragon Gunz - A Evolu&ccedil;&atilde;o est&aacute; aqui!</title>
    
    <!--Meta-->
    <meta name="owner" content="DragonGunz.com" />
    <meta name="classification" content="Online Games" />
    <meta name="distribution" content="Global" />
    <meta name="language" content="en-GB" />
    <meta name="Rating" content="General" />
    <meta name="publisher" content="segagfx@aol.com" />
    <meta name="copyright" content="Copyright Dragon GunZ 2012" />
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.gif" />
    <link rel="icon" type="image/gif" href="favicon.gif" />
    
    <!-- CSS -->    
    <link href="style.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
a:link {
	color: #CCCCCC;
}
a:visited {
	color: #CCCCCC;
}
a:hover {
	color: #CCCCCC;
}
a:active {
	color: #CCCCCC;
}
.style1 {
	color: #FFFEA9;
	font-weight: bold;
	font-style: italic;
}
body {
	background-image: url(background.png);
}
-->
    </style>


<div id="wrapper">
<div id="header">
    	<div id="logo"></div>
  </div>
    
<div id="navibar">
           <ul>
       		<li><a href="index.php" class="active">Início</a></li>                
                <li><a href="index.php?plus=register">Registrar</a></li>
                <li><a href="index.php?plus=download">Download</a></li>
                <li><a href="index.php?plus=donate">Doações</a></li>
                <li><a href="index.php?plus=rankings">Rankings</a></li>
                <li><a href="index.php?plus=itenshop">WebStore</a></li>
                <li><a href="index.php?plus=serverinfo">Server Info</a></li>
		<li><a href="http://dragongunz.com/forum">Forum</a></li>
		<li><a href="index.php?plus=equipe">Equipe</a></li>
           </ul>
  </div>
        <div id="sidebar">
<br>
<div id="status">
       <p></h> <span></span><br /><span><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong>$servercount";
    ?> 
    <td> /300</span> Players</p> </div>

<a href="https://hotfile.com/dl/222394266/e0a43ab/DragonGunz.exe.html"><img src="images/download.png" alt="download" title="Cliente Download"/></a>
<a href="index.php?plus=chat"><img src="images/chat.png" alt="download" title="Chat DragonGunZ"/></a>

        
        <div id="sidecont">
        <div class="side-outline side-top">
          <p>Login </p>
        </div>
        <div class="side-outline side-cont">
          <table width="228" border="0">
  <tr>
    <td width="232"><div align="center">
      <? include "php/ZoooDprotect_ilogin.php";?>
    </div></td>
  </tr>
</table>

        </div>
        <div class="side-outline side-end"></div>
        </div>
        <div id="sidecont">
        <div class="side-outline side-top">
          <p>Player Ranking</p>
        </div>
        <div class="side-outline side-cont"><?
$res = mssql_query_logged("SELECT TOP 5 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<br /><table border="0" style="border-collapse: collapse" width="235" id="table4">
							
								<td>
								<table border="0" style="border-collapse: collapse" width="223" height="100%">
									<tr>
									  <td width="64">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="93">Nome</td>
									  <td width="52">&nbsp;&nbsp;LVL</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="64">&nbsp;</td>
										<td width="93"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									    <tr>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
							      </tr>
								    <tr>
<td width="64">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=++$count ?>    </td>
									  
<td width="93"><a href="?plus=charinfo&amp;id=<?=$clan['CID']?>"><?=$clan['Name']?></a></td>

<td width="52">
		    
	        &nbsp;&nbsp;<?=$clan['Level']?>
	        &nbsp;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="64">&nbsp;</td>
										<td width="93">&nbsp;</td>
										<td width="52">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>

<br>
      
        </div>
		<div class="side-outline side-end"></div>
		<div class="side-outline side-top">
          <p>Clãn Ranking</p>
        </div>
		        <div class="side-outline side-cont"><?
$res = mssql_query_logged("SELECT TOP 5 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
$count = 0;
?>
<br /><table border="0" style="border-collapse: collapse" width="235" id="table4">
							
								<td>
								<table border="0" style="border-collapse: collapse" width="223" height="100%">
									<tr>
									  <td width="64">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
										<td width="93">Nome</td>
									  <td width="52">&nbsp;&nbsp;Pontos</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="64">&nbsp;</td>
										<td width="93"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									    <tr>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
							      </tr>
								    <tr>
<td width="64">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="http://64.237.36.106/dragon/<?=($clan['EmblemUrl'] == "") ? "no_emblem.png" : $clan['EmblemUrl']?>" width="20" height="20"> </td>
									  
<td width="93"><a href="?plus=claninfo&amp;id=<?=$clan['CLID']?>"><?=$clan['Name']?></a></td>

<td width="52">
		    
	        &nbsp;&nbsp;<?=number_format($clan['Point'],0,'','.');?>
	        &nbsp;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="64">&nbsp;</td>
										<td width="93">&nbsp;</td>
										<td width="52">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>

<br>
      
        </div>
        <div class="side-outline side-end"></div>
        </div>
        
        <div id="sidecont">
       



</div>

</div>
        <div id="main-cont">
		
        	<div class="main-top"></div>
            <div class="main-center">
            	<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['plus'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("php/ZoooDprotect_" . $_GET['plus'] . ".php")) {
							    include "php/ZoooDprotect_" . $_GET['plus'] . ".php";
						    }
                        }else{
                            include "php/ZoooDprotect_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
            </div>
            <div class="main-end"></div>

<!-- INICIO CONTADOR ---!>
<br><br>
<?php
$a = 0;
include 'contador.php';
   if (isset($_COOKIE['counte'])) {
      $counte = $_COOKIE['counte'] + 1;
   }else{
    $counte = 1;
    $a++;
}
setcookie('counte', "$counte", time()+3700);
$abre =@fopen("contador.php","w");
$ss ='<?php $a='.$a.'; ?>';
$escreve =fwrite($abre, $ss);
?>
<html>
   <head>Contador de Visitas</head>
<body>

<?php
echo "<br>$a Pessoas visitaram esse site e você já visitou $counte vezes";
?>  

<br><br>

<?php $a=0; ?>
</body>
</html>
<!-- FIM CONTADOR ---!>


        </div>
       <br clear="all" />
        <div id="footer">       	
<br>
<div align="center" class="style1"><br>DragonGunZ© 2013 - Todos os direitos reservados -   Website Editada por Tiago Gomes</div>
<br>            
        </div>
</div>
</body>
</html>

<? include "php/include.php";?>

