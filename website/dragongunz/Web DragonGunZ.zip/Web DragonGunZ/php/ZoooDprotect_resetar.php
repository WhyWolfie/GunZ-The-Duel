<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
<div align="center"><?
if($_SESSION['AID'] == ""){
    msgbox("Por favor Logue Primeiro.","index.php");
exit();
}
//Script resetar clan created by HearT e edit by SayntPark
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
    $caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
    $blank = "";
return str_replace($caracters, $blank, $str);
}


$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
echo "Voc� n�o tem clans";
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?plus=resetar&etapa=1">
Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>
<input type="submit" name="proximo" value="Proximo ->" />
</form>

<?
}

if($etapa == 1)
{

$cid22 = Filtrrar($_POST['cid22']);

$query2 = mssql_query("SELECT CLID FROM ClanMember WHERE CID = '$cid22'");

if( mssql_num_rows($query2) < 1 )
{
echo "Desculpe, este personagem n�o pertence a nenhum clan";
die();
}

$query3 = mssql_fetch_row($query2);

$query4 = mssql_query("SELECT MasterCID FROM Clan WHERE CLID = '$query3[0]'");
$query5 = mssql_fetch_row($query4);

if($cid22 == $query5[0])
{
$query6 = mssql_query("SELECT Name FROM Clan WHERE CLID = '$query3[0]'");
$query7 = mssql_fetch_row($query6);

?>
<form id="site_Login" name="site_Login" method="post" action="?plus=resetar&etapa=2">
Tem certeza que deseja resetar o clan
<select name="CLID55" class="text">
<option value="<?=$query3[0]?>"><?=$query7[0]?></option>
</select>?<br><br>
<input type="submit" name="proximo" value="Sim" />
</form>
<br>
<form id="site_Login" name="site_Login" method="post" action="?do=index">
<input type="submit" name="proximo" value="N�o" />
</form>
<?
}else{
echo "Voc� n�o � lider do seu clan";
}

}

if($etapa == 2)
{

$clid22 = $_POST['CLID55'];

$query8 = mssql_query("UPDATE Clan SET Ranking = 0, Wins=0, Losses=0, Point=1000, RankIncrease=0, LastDayRanking=0 WHERE CLID = '$clid22'");

echo "Clan resetado com sucesso.";

}
?></div>
