<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?

include "protects/authafundadores.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Acesso Negado","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Acesso Negado","index.php");
}

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $reason = clean($_POST['reason']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("Usuario N�o Existente em Nossos Bancos de Dados","index.php?plus=DesbanirusuarioWG");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Account SET UGradeID = '0' WHERE UserID = '$userID'");
            mssql_query_logged("INSERT INTO Banneduser (UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$id', 'Undefined', '$reason', GETDATE(), 'Ban')");
            msgbox("Gradua��o do usuario $id Modificado Com Sucesso","index.php?wanted=DesbanirusuarioWG");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?plus=DesbanirusuarioWG");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Account SET UGradeID = '0' WHERE AID = '$UserAID'");
            mssql_query_logged("INSERT INTO Banneduser (UserID, IP, BanReason, IPBANMUTE)VALUES('$id', 'Undefined', '$reason', GETDATE(), 'Ban')");
            msgbox("The user with the character $id has been desbanned","index.php?plus=DesbanirusuarioWG");
        }
    }

}


?>



	<style type="text/css">
<!--
.style1 {
	color: #666666;
	font-weight: bold;
	font-style: italic;
	font-size: 18px;
}
-->
    </style>
	<body bgcolor="#312F30">

					
						<div class="content-outline content-top">
                  <div class="title">Desbanir Usuarios ( Fundadores )</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table width="456" border="0" bordercolor="#666666" style="border-collapse: collapse">
							
							<tr>
								<td background="">
								<div align="center">
									<form name="ban" method="POST" action="index.php?plus=DesbanirusuarioWG"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149">&nbsp;
											</td>
											<td width="4">&nbsp;
											</td>
											<td width="279">&nbsp;
											</td>
										</tr>

										

										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">Login do usuario
											</option>
											<option value="2">Character do Usuario
											</option>
											</select></td>
											<td width="4">&nbsp;
											</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>

										
										<tr>
									  </tr>

										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Desbanir/Desmutar Usuario" name="submit"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							
					  </table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
	