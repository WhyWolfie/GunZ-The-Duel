<div class="content-outline content-top">
                  <div class="title"><a href="#">Doa��es.</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center><table width="200" border="0">
  
<tr>
<td><a href="index.php?plus=donatee"><img src="images/dooar.png" width="300" height="60" border="0" /></a></td>
</tr>

<tr>
<td><a href="index.php?plus=duvidas"><img src="images/duvidas.png" width="300" height="60" border="0" /></a></td>
</tr>

  <tr><h2>
<br><br> <font color="#B22222">  Sobre Doa��es</font> <br><br><br>
<font color="#FFA500">Por favor, leia os termos abaixo antes de fazer uma doa��o.</font><br><br><br><font color="#D3D3D3">
<div align="left"><font color="#B22222">1)</font> DragonGunZ � um servi�o gratuito. N�s s� temos usu�rios, e n�o clientes.<br> <br>
<font color="#B22222">2)</font> DragonGunz reserva-se os direitos para n�o enviar presentes por qualquer motivo.<br> <br>
<font color="#B22222">3)</font> As doa��es n�o ser�o reembolsadas por qualquer motivo. <br><br>
<font color="#B22222">4)</font> Fingindo uma doa��o voc� poder� ter sua conta banida. <br><br>
<font color="#B22222">5)</font> Todos os pagamentos pelo PagSeguro ou Dep�sito � considerado como uma doa��o. <br><br>
<font color="#B22222">6)</font> N�s n�o somos respons�veis por pagamentos que n�o forem pago por meios de pagamentos estabelecidos em nosso site. <br><br>
<font color="#B22222">7)</font> Se voc� comprar itens errados, n�o iremos recuperar as moedas<br><br>
<font color="#B22222">8)</font> Este � um jogo gratuito e sem fins lucrativos, as doa��es s�o para cobrir os gastos do servidor.<br><br>

Todos os jogadores t�m liberdade total de jogar sem ter que pagar para obter itens especiais ou benef�cios VIP, estas s�o apenas as formas como tratamos os nossos apoiadores e doadores.<br> Voc� tamb�m pode receber tratamentos especiais, vencendo eventos e adquirindo itens da loja Evento.<br><br></font>
<font color="#FFA500">Doando voc� concorda que leu e compreendeu os Termos de Doa��es e Regras<br><br></font></h2>
</div>

  </tr>
</table>

					
					<p>&nbsp;</p>
  </div></div>
 
                <div class="content-outline content-end"></div>
                </div><div>
