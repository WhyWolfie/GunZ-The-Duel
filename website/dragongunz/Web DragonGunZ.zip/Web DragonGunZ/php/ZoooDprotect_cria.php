<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
<?php
if($_SESSION['AID'] == ""){
    msgbox("Por favor Logue Primeiro.","index.php");
exit();
}


?>
<div align="center">
<form action="index.php?plus=cria" method="post"> 
                <h1><span class="fl">C</span>riar Cl�</h1> 
                  
     <br /> 

<h3>Escolha o l�der:</h3> 
                    <?php 
$query = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."' AND DeleteFlag = 0"); 
echo '<select name="nCID">'; 
 if(mssql_num_rows($query)<>0){ 
   while($char = mssql_fetch_assoc($query)){ 
    echo '<option value="'.$char['CID'].'">'; 
     echo $char['Name']; 
    echo '</option>'; 
   } 
 }else{ 
   echo '<option></option>'; 
 } 
echo '</select>'; 
?> 

 <br></br> 
<h3>Nome do cl�:</h3>     

              
<input name="NOME" type="text" class="Login" value="" onkeypress='return soLetras(event)' size="20" maxlength="10"> 


  
<?php 
if (isset($_POST['criaraf'])){ 
$NOME = clean($_POST['NOME']); 
$nCID = clean($_POST['nCID']); 

if( !is_numeric( $nCID ) ){ 
    msgbox( "N�o burle o sistema, Ruby Gunz.", "index.php" ); 
} 

if(strlen($NOME) > 10){ 
            msgbox("Nome muito grande, somente ate 10 letras","index.php"); 
    die();  
        } 
if(strlen($NOME) < 4){ 
            msgbox("Nome muito curto, coloque maior que 4 letras","index.php"); 
    die();  
        } 
$lil = mssql_query("SELECT MasterCID FROM Clan WHERE MasterCID = '$nCID'"); 
$trin = mssql_query("SELECT Name FROM Clan WHERE Name = '$NOME'"); 
$glaizan = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$nCID'"); 

if (mssql_num_rows($trin) >= 1){ 
msgbox("Clan em uso","index.php"); 
    die();  
        } 
if (mssql_num_rows($lil) >= 1){ 
msgbox("Ja possui um clan","index.php"); 
    die();  
        } 
if (mssql_num_rows($glaizan) == 0 ) 
        { 
    msgbox("Esse char pertence a outra conta.","index.php"); 
    die(); 
    } 
$sql = mssql_query("INSERT INTO Clan (Name, MasterCID, RegDate) VALUES ('$NOME', '$nCID', GETDATE())"); 
$res = mssql_query("SELECT * FROM Clan(nolock) WHERE Name = '$NOME' AND MasterCID = '$nCID'"); 
        $usr = mssql_fetch_assoc($res); 
        $clid = $usr['CLID']; 
mssql_query("INSERT INTO ClanMember (CLID, CID, Grade, RegDate) VALUES ('$clid', '$nCID', 1, GETDATE())"); 
if($sql){ 
    msgbox("Cl� criado com sucesso.","index.php"); 
    die();  
}else{ 
    msgbox("Erro!","index.php"); 
    die();  
} 
} 
?> 
    <br> </br> 
         <h3>Confirmar?</h3> 
    
        
<input type="submit" name="criaraf" class="button" value="Sim" /> 

</form></div>