<?
include "protects/authafundadores.php";
if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $reason = clean($_POST['reason']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("Usuario N�o Existente Em Nosso Banco De Dados","index.php?plus=fundadoreswantedtrocar");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Login SET Password = '$password' WHERE UserID = '$userID'");
            msgbox("Senha do Usuario $id Alterada Com Sucesso","index.php?wanted=fundadoreswantedtrocar");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("Personagen $id N�o existente","index.php?plus=fundadoreswantedtrocar");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Login SET Password = '$password' WHERE AID = '$UserAID'");
            msgbox("Senha do Usuario $id Alterada Com Sucesso","index.php?plus=fundadoreswantedtrocar");
        }
    }

}


?>



	<style type="text/css">
<!--
.style1 {
	color: #666666;
	font-weight: bold;
	font-style: italic;
	font-size: 18px;
}
-->
    </style>
	<body bgcolor="#312F30">

					
						<div class="content-outline content-top">
                  <div class="title">Alterar senhas (fundadores)</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table width="456" border="0" bordercolor="#666666" style="border-collapse: collapse">
							
							<tr>
								<td background="">
								<div align="center">
									<form name="ban" method="POST" action="index.php?plus=fundadoreswantedtrocar"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149"><select name="type" size="1">
                                              <option value="1">Nova Senha</option>
											  <option value="1">Login</option>
											  <option value="2">Personagen</option>
                                            </select></td>
											<td width="4">&nbsp;											</td>
											<td width="279">&nbsp;											</td>
										</tr>

										

										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  <td><input name="id" type="text" id="id" size="26"> 
										    &lt;- Usuario </td>
									  </tr>
										<tr>
											<td width="149">
											  <p align="right"></td>
											<td width="4">&nbsp;											</td>
											<td width="279">
											<input name="password" type="text" id="password" size="26"> 
											&lt;- Senha
&nbsp;											</td>
										</tr>

										
										<tr>									  </tr>

										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											<input type="submit" value="Alterar Senha do Usuario Desejado!" name="submit"></td>
										</tr>
										</table>
									</form>
								</div>
								</td>
							</tr>
							
					  </table>
					  <p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>