<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?

include "protects/authadmin.php";
include 'protects/anti_sql.php';
include 'protects/inject.php';

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?plus=wantedmuteplayer");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE UserID = '$userID'");
            mssql_query_logged("INSERT INTO Banneduser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$gmid', '$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the ID $id has been muted","index.php?plus=wantedmuteplayer");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?plus=wantedmuteplayer");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE AID = '$UserAID'");
            mssql_query_logged("INSERT INTO Banneduser (UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the character $id has been muted","index.php?plus=wantedmuteplayer");
        }
    }

}


?>



	<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
	font-style: italic;
	color: #666666;
}
-->
    </style>
	<body bgcolor="#312F30">

					
			    <div class="content-outline content-top">
                  <div class="title">Mudar Players (PG)</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table width="518" border="0" bordercolor="#666666" style="border-collapse: collapse">
							
							<tr>
								<td width="576" background="">
								<div align="center">
									<form name="mute" method="POST" action="index.php?plus=wantedmuteplayer"><table border="0" style="border-collapse: collapse" width="463" height="100%">
										

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td width="151">&nbsp;											</td>
											<td width="4">&nbsp;											</td>
											<td width="340">&nbsp;											</td>
										</tr>

										

										<tr>
											<td width="151">
											  <p align="right">
											    <select size="1" name="type">
                                                  <option selected value="1">Login do Usuario</option>
                                                  <option value="2">Character Do usuario</option>
                                                </select>
										  </td>
											<td width="4">&nbsp;											</td>
											<td width="340">
											<input type="text" name="id" size="26">&nbsp;										  </td>
										</tr>

										<tr>
											<td width="151">
										  <p align="right">Motivo do Chat Block </td>
											<td width="4">&nbsp;											</td>
											<td width="340">
											<input type="text" name="reason" size="26"></td>
										</tr>
										

										<tr>
											<td width="151">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="340">&nbsp;</td>
										</tr>

										<tr>
											<td colspan="3">
											<p align="center">
										  <input type="submit" value="Injetar Chat Block" name="submit"></td>
										</tr>
										</table>
									</form>
								</div>							  </td>
							</tr>
							
    </table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
					
	