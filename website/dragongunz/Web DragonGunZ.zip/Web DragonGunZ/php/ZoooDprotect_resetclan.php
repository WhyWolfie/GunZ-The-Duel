<style type="text/css">
<!--
.style1 {
	font-size: 16px;
	font-style: italic;
}
-->
</style>
<div class="content-outline content-top">
                  <div class="title"><a href="index.php">Resetar Clan</a></div>
</div><div class="content-outline content-cont">
                	<div class="content-inside">
                	  <div align="center" class="style1"><br>Pagina Em andamento!</div>
                	  <p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>