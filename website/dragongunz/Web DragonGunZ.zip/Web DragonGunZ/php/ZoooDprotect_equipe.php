<style type="text/css">
<!--
.Administradores_PG {color: #FF0000}
.Cargo_PG {color: #00FFFF}
.Cargo_DG {color: #FF7F24}
.game__master {color: #006666}
.MODERADORES_PG {color: #FFFFFF}
-->
</style>
<div class="content-outline content-top">
                  <div class="title"><a href="#">Equipe Dragon GunZ</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
<table width="600" border="0">
 
</table>
<table width="600" border="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="98"><img src="images/bolinha.png" width="98" height="70" /></td>
    <td width="492"><table width="496" border="0">
      <tr>
        <td width="490">Nome: Tiago Gomes </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Fundador </span></td>
      </tr>
      <tr>
        <td>Idade: 18 Anos </td>
      </tr>
           <tr>
        <td>Character: P3T3RP4N </td>
      </tr>
    </table></td>
  </tr>

<table width="604" border="0">
  </table>
<table width="600" border="0">
  <tr><br>
    <td width="102"><img src="images/adm.png" alt="a" width="98" height="70" /></td>
    <td width="488"><table width="489" border="0">
      <tr>
        <td>Nome: Diego </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Administradores_PG">Administrador</span> </td>
      </tr>
      <tr>
        <td>Idade: 18 Anos </td>
      </tr>
            <tr>
        <td>Character: DiegoSilva</td>
      </tr>
    </table></td>
  </tr>

  <tr>
    <td><img src="images/adm.png" alt="a" width="98" height="70" /></td>
    <td><table width="496" border="0">
      <tr>
        <td width="490">Nome: Wiltinho </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Administradores_PG">Administrador</span></td>
      </tr>
      <tr>
        <td>Idade: 18 Anos </td>
      </tr>
           <tr>
        <td>Character: Pxdm</td>
      </tr>
    </table></td>
  </tr>

<tr>
    <td><img src="images/adm.png" alt="a" width="98" height="70" /></td>
    <td><table width="496" border="0">
      <tr>
        <td width="490">Nome: Felipe </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Administradores_PG">Administrador</span></td>
      </tr>
      <tr>
        <td>Idade: 18 Anos </td>
      </tr>
           <tr>
        <td>Character: -Xurupita </td>
      </tr>
    </table></td>
  </tr>


  <tr>
    <td><img src="images/gm.jpg" alt="a" width="98" height="70" /></td>
    <td><table width="486" border="0">
      <tr>
        <td>Nome: Guilherme</td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_DG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 21 Anos</td>
      </tr>
           <tr>
        <td>Character: -Ghost </td>
      </tr>
    </table></td>
  </tr>
<tr>
    <td><img src="images/gm.jpg" alt="a" width="98" height="70" /></td>
    <td><table width="486" border="0">
      <tr>
        <td>Nome: Arthur </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_DG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 17 Anos  </td>
      </tr>
           <tr>
        <td>Character: Ziim  </td>
      </tr>
    </table></td>
  </tr>
<tr>
    <td><img src="images/gm.jpg" alt="a" width="98" height="70" /></td>
    <td><table width="486" border="0">
      <tr>
        <td>Nome: Vinicius Fernandes</td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_DG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 18 Anos</td>
      </tr>
           <tr>
        <td>Character: -Coringa </td>
      </tr>
    </table></td>
  </tr>
<tr>
    <td><img src="images/gm.jpg" alt="a" width="98" height="70" /></td>
    <td><table width="486" border="0">
      <tr>
        <td>Nome: Gustavo</td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_DG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 19 Anos  </td>
      </tr>
           <tr>
        <td>Character: -Zeus </td>
      </tr>
    </table></td>
  </tr>
<tr>
    <td><img src="images/gm.jpg" alt="a" width="98" height="70" /></td>
    <td><table width="486" border="0">
      <tr>
 <tr>
        <td>Nome: </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_DG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 16 Anos</td>
      </tr>
           <tr>
        <td>Character:  </td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="600" border="0">
  
</table>
<table width="600" border="0">
  <tr>

      
    </table></td>
  </tr><tr>
    
      
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table></center>
<p>&nbsp;</p>
 </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>