<?
include "protects/authadmin.php";
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>

<style type="text/css">
<!--
.style1 {color: #009999}
a:link {
	color: #666666;
	font-style: italic;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
.style2 {
	color: #666666;
	font-style: italic;
	font-size: 9px;
}
-->
</style>
<div class="content-outline content-top">
                  <div class="title">Painel Do Staff "Dragon GunZ"</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
  <tr>
    <td width="127"><div align="center" class="style1">Painel STAFF</td></div><br>
    
 
    <td><div align="center"><a href="index.php?plus=VentoCoinsSunDisk">Enviar EV. Coins  </a></div></td><br>
<td><div align="center"><a href="index.php?plus=wantedbannedxD">Banir Player's  </a> </div></td><br>
    <td><div align="center"><a href="index.php?plus=wantedmuteplayer">Dar Chat Block </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=banlist&amp;submit">Players Banidos </a></div></td><br>
    
    </tr>
</table>

					</div>
                </div>
                <div class="content-outline content-end"></div><br>
				<? if($_SESSION['AID'] == 651 or $_SESSION['AID'] == 700 or $_SESSION['AID'] == 0){include"php/ZoooDprotect_fundadorpainelxDxD.php";echo "</br>";} ?>