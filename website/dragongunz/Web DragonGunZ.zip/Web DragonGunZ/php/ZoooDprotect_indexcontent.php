<?
if($_GET['sub'] == "announcement"){
    $res = mssql_query("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
     
       <div align="center"><h3><?=$a['Title']?></h3></div>
<br>
<br>
<br>
      <div align="center"><h5>Escrito Por <?=$a['User']?></b> , Data <?=$a['Date']?></h5></div>
<br>
<br>
<br>
     <div align="center"><h8><?=$a['Text']?></h8></div>											
											
    <?
}else{
    $res = mssql_query("SELECT * FROM IndexContent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
       
             <div align="center"><h3><?=$a['Title']?></h3></div>
<br>
<br>
<br>
      <div align="center"><h5>Escrito Por <?=$a['User']?></b> , Data <?=$a['Date']?></h5></div>
<br>
<br>
<br>
     <div align="center"><h8><?=$a['Text']?></h8></div>	
											
<?}?>