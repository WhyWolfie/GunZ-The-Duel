<div class="content-outline content-top">
                  <div class="title"><a href="#">Registro DragonGamerZ</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
-->
</style>

			<div class="contentBox">
              <ul class="rank"><?php

include "Protects/anti_sql.php";
include "Protects/inject.php";
include "Configuracao/config.php";

$ip = $_SERVER['REMOTE_ADDR'];  
$time = date("l dS of F Y h:i:s A");  
$script = $_SERVER[PATH_TRANSLATED];  
$fp = fopen ("[WEB]SQL_Injection.txt", "a+");  
$sql_inject_1 = array(";","'","%",'"'); #Whoth need replace  
$sql_inject_2 = array("", "","","&quot;"); #To wont replace  
$GET_KEY = array_keys($_GET); #array keys from $_GET  
$POST_KEY = array_keys($_POST); #array keys from $_POST  
$COOKIE_KEY = array_keys($_COOKIE); #array keys from $_COOKIE  
/*begin clear $_GET */  
for($i=0;$i<count($GET_KEY);$i++)  
{  
$real_get[$i] = $_GET[$GET_KEY[$i]];  
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]]));  
if($real_get[$i] != $_GET[$GET_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: GET\r\n");  
fwrite ($fp, "Value: $real_get[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_GET */  
/*begin clear $_POST */  
for($i=0;$i<count($POST_KEY);$i++)  
{  
$real_post[$i] = $_POST[$POST_KEY[$i]];  
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]]));  
if($real_post[$i] != $_POST[$POST_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: POST\r\n");  
fwrite ($fp, "Value: $real_post[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_POST */  
/*begin clear $_COOKIE */  
for($i=0;$i<count($COOKIE_KEY);$i++)  
{  
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]];  
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]]));  
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: COOKIE\r\n");  
fwrite ($fp, "Value: $real_cookie[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  

/*end clear $_COOKIE */  
fclose ($fp);  
?>
<?
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
	$name = clean($_POST['name']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $sq = clean($_POST['sq']);
    $sa = clean($_POST['sa']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="e-Mail in use.</br>";
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="UserID in use.</br>";
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            $errorcode.="The passwords do not match</br>";
            $er = 1;
        }

        if($user == ""){
            $errorcode.="Please enter a User ID.</br>";
            $er = 1;
        }

        if($email == ""){
            $errorcode.="Please type an e-mail.</br>";
            $er = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Please enter a password with 6 or more characters.</br>";
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please enter a password.</br>";
            $er = 1;
        }

        if($sq == ""){
            $errorcode.="Please enter a secret question.</br>";
            $er =1;
        }

        if($sa == ""){
            $errorcode.="Please enter a secret answer.</br>";
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
           mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, sa, sq, ZipCode, Address)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$sa', '$sq', '$zip', '$address')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins],[Custom])VALUES('$user','$aid','$pw1',150,120,0)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>

<form name="reg" method="POST" action="index.php?plus=register">


					
						<table border="0" width="615" style="border-collapse: collapse">
							
							<tr>
								<td width="661" background="">
								<div align="light">
								  <table width="563" height="218" border="0" cellspacing="1" bordercolor="#999999">
                                      <tr>
                                        <td><table border="0" style="border-collapse: collapse" width="606" height="100%">
										
										<tr>
										  <td colspan="3"><center>
                    <p class="registertitle">Todas as lacunas abaixo s�o altamente necessaria. N�o deixe de preenche-las corretamente.</p>
                    </center></td>
										  </tr>
										<tr>
										  <td width="41">&nbsp;</td>
											<td width="174">&nbsp;&nbsp; </td>
											<td width="377">&nbsp;</td>
										  </tr>
<? echo @$errorbox ?>
										<tr>
										  <td valign="middle">&nbsp;</td>
										  <td valign="middle">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nome:</td>
										  <td><div class="ar_right">
                        <input type="text" name="name" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1">
                        <label for="name" class="msg error"></label>
                        (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td width="41" valign="middle">&nbsp;</td>
											<td width="174" valign="middle">
											<span lang="es">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Login:</span></td>
										  <td width="377">
											<div class="ar_right">
                        <input type="text" name="userid" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1">
                        <label for="name" class="msg error"></label>
                        (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td width="41">&nbsp;</td>
											<td width="174">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail:</td>
											<td width="377">
										  <div class="ar_right">
                        <input type="text" name="email" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1"> 
                    <label for="name" class="msg error"></label>
                    (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Pergunta Secreta: </td>
										  <td><div class="ar_right">
                        <input type="text" name="sq" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1"> 
                    <label for="name" class="msg error"></label>
                    (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Resposta Secreta </td>
										  <td><div class="ar_right">
                        <input type="text" name="sa" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1"> 
                    <label for="name" class="msg error"></label>
                    (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Senha: </td>
										  <td><div class="ar_right">
                        <input type="password" name="pw1" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1"> 
                    <label for="name" class="msg error"></label>
                    (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Confirme a Senha: </td>
										  <td><div class="ar_right">
                        <input type="password" name="pw2" id="name" size="40" value="" class="inputbox" maxlength="50" tabindex="1"> 
                    <label for="name" class="msg error"></label>
                    (*)</div>
                    
                    <div class="ar_spacer"></div></td>
										  </tr>
										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  </tr>
										

										
										<tr>
											<td colspan="6">
											<div><center>
                        <button class="registerlog" type="submit" name="submit" tabindex="7">Registrar</button>
                        �<button class="clear" type="reset" tabindex="8">Limpar</button>
                    </center></div></td>
										</tr>
								  </table></td>
                                      </tr>
                                  </table>
								</div>
							  </td>
							</tr>
							
</table>
</form>
<?
}else{
?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form name="reg" method="POST" action="index.php?do=register"><body bgcolor="#323232">

  
						<table width="615" border="0" bordercolor="#999999" style="border-collapse: collapse">
							
							<tr>
								<td width="689" background="images/meio.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="612" height="100%">
										<tr>
											
											<td width="606" colspan="2">											</td>
										</tr>
										<tr>
											<td colspan="2"><center><p class="registertitle">Conta Registrada Com Sucesso.</p></center></td>
										</tr>
										<tr>
										  <td colspan="2">&nbsp;</td>
									  </tr>
										<tr>
										  <td colspan="2">���������������Detalhes Da Conta Abaixo: <br /><br /></td>
									  </tr>
										<tr>
										  <td colspan="2">���������������------------------------------------------------------------------------------------------</td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������IP de cadastro: <span class="cor-estatistica"></span><script type="text/javascript" src="http://www.whatsmyip.us/showipsimple.php"></span></script></td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Nome: <?=$name?></td>
									  </tr>
										<tr>
											<td height="24" colspan="2">���������������Login: <?=$user?></td>
										</tr>
										<tr>
										  <td height="24" colspan="2">���������������Senha: (*******) N&atilde;o revelamos sua senha por motivos de seguran&ccedil;a! </td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Pergunta Secreta: <?=$sq?></td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Resposta Secreta: <?=$sa?></td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Gold Coins Adquiridas: 0 ( Ultilizado para comprar itens Custom ) </td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Cash Coins Adquiridas: 120 ( Ultilizado para comprar itens Donator ) </td>
									  </tr>
										<tr>
										  <td height="24" colspan="2">���������������Event Adquiridas: 90 ( Ultilizado para comprar itens de Evento ) </td>
									  </tr>
										<tr>
											<td height="24" colspan="2">
											<center>
										  &nbsp;</center></td>
										</tr>
								  </table>
								
							  </td>
							</tr>
							
  </table>
</form>
<?
}
?>
            	
<p>&nbsp;</p>
  </div></div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>