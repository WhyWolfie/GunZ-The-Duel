<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?php
include "configura��o/authadmin.php";
include "php/title.php";
include 'protects/anti_sql.php';
include 'protects/inject.php';
if($_SESSION['UGradeID'] == 254){
}
if($_SESSION['UGradeID'] == 252){
}

if(isset($_POST['submit'])){
    $name = clean($_POST['name']);
    $zitemid = clean($_POST['zItemID']);
    $desc = clean($_POST['desc']);
    $price = clean($_POST['price']);
    $img = clean($_POST['img']);
    $sex = clean($_POST['sex']);
    $minlvl = clean($_POST['minlvl']);
    $peso = clean($_POST['peso']);
    $slot = clean($_POST['slot']);
    $damage = clean($_POST['damage']);
    $AP = clean($_POST['AP']);
    $FR = clean($_POST['FR']);
    $delay = clean($_POST['delay']);
    $HP = clean($_POST['HP']);
    $PR = clean($_POST['PR']);
    $magazine = clean($_POST['magazine']);
    $maxpeso = clean($_POST['maxpeso']);
    $CR = clean($_POST['CR']);
    $balasmax = clean($_POST['balasmax']);
    $reloadtime = clean($_POST['reloadtime']);
    $LR = clean($_POST['LR']);
    $control = clean($_POST['control']);
    $csid = clean($_POST['zItemID']);
    mssql_query_logged("INSERT INTO [Item] ([ItemID], [Name], [Description], [ResSex], [ResLevel], [Weight], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [CR], [MaxBullet], [ReloadTime], [LR])VALUES('$zitemid', '$name', '$desc', NULL, $minlvl, 1, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $CR, $balasmax, $reloadtime, $LR)");
    mssql_query_logged("INSERT INTO [WGCashShop] ([ItemID], [Name], [CSID], [Description], [CashPrice], [WebImgName], [NewItemOrder], [ResSex], [ResLevel], [Weight], [Opened], [RegDate], [RentType], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [MaxWeight], [CR], [MaxBullet], [ReloadTime], [LR], [Control])VALUES('$zitemid', '$name', '$csid', '$desc', $price, '$img', NULL, $sex, $minlvl, $peso, 1, GETDATE(), NULL, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $maxpeso, $CR, $balasmax, $reloadtime, $LR, $control)");
    msgbox("Iten Adicionado Corretamente Na Loja Donator","index.php");
}else{
    



?><head>
	<meta name="keywords" content="" />
<meta http-equiv="Content-Language" content="pt-BR">

	

	<link rel="stylesheet" type="text/css" href="estilos/reset.css">
	<link rel="stylesheet" type="text/css" href="estilos/estilo.css">




    <script type="text/javascript" src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
	<script type="text/javascript" src="js/imageeffects.min.js"></script>
    
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
	<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
    
    
   

  <link rel="stylesheet" type="text/css" href="javascript/lightbox/themes/default/jquery.lightbox.css">
  <script type="text/javascript" src="javascript/lightbox/jquery.lightbox.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.lightbox').lightbox();
    });
  </script>
<script type=�text/javascript�>
if( window.console && window.console.firebug ){
alert(�Desculpe, este site n�o suporta o Firebug!�);
window.location=�/sem_firebug.html�;
}
</script>
<style type="text/css">
<!--
.style1 {
	color: #666666;
	font-weight: bold;
	font-style: italic;
	font-size: 18px;
}
-->
</style>
</head>

	<body bgcolor="#312F30">

					<div class="content-outline content-top">
                  <div class="title">Adicionar Donator iten</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table width="499" border="0" bordercolor="#666666" style="border-collapse: collapse">
							
							<tr>
								<td background="">
								<div align="center">
									<form method="POST" action="index.php?plus=DonatorSunDisk"><table border="0" style="border-collapse: collapse" width="499" height="100%">
										

										<tr>
											<td colspan="3"></td>
										</tr>

										<tr>
											<td colspan="3">&nbsp;											</td>
										</tr>

										<tr>
											<td width="136" align="right">&nbsp;&nbsp;&nbsp;&nbsp;ID  </td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="zItemID" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Image</td>
											<td width="7">:											</td>
											<td width="297">
										  <input name="img" type="text" value="no_emblem.png" size="14">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136">
										  <p align="right">&nbsp;&nbsp;&nbsp;&nbsp;Name</td>
											<td width="7">:											</td>
											<td width="297">
										  <input name="name" type="text" value="Iten" size="14">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Slot</td>
											<td width="7">:											</td>
											<td width="297">
											<select size="1" name="slot">
											<option Selected value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
											<option value="9">9</option>
											<option value="10">10</option>
										  </select>
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td colspan="3">&nbsp;</td>
									  </tr>
										<tr>
											<td colspan="3"><hr color="#323232" width="96%"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Sex</td>
											<td width="7">:											</td>
											<td width="297">
											<select size="1" name="sex">
											<option selected value="2">Ambos</option>
											<option value="0">Homem</option>
											<option value="1">Mulher</option>
										  </select>
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Level</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="minlvl" size="14" value="1">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Peso</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="peso" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td colspan="3">&nbsp;</td>
									  </tr>
										<tr>
											<td colspan="3"><hr color="#323232" width="96%"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Valor</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="price" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Damage</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="damage" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Delay</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="delay" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td colspan="3">&nbsp;</td>
									  </tr>
										<tr>
											<td colspan="3"><hr color="#323232" width="96%"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;Magazine</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="magazine" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											 &nbsp;&nbsp;&nbsp;&nbsp;Max Weight</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="maxpeso" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;HP</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="HP" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											&nbsp;&nbsp;&nbsp;&nbsp;AP</td>
											<td width="7">:											</td>
											<td width="297">
										  <input type="text" name="AP" size="14" value="0">
										  <img src="images/shape.png" width="25" height="21"></td>
										</tr>
										<tr>
										  <td colspan="3">&nbsp;</td>
									  </tr>
										<tr>
											<td colspan="3"><hr color="#323232" width="96%"></td>
										</tr>

										<tr>
										  <td align="right">&nbsp;</td>
										  <td>&nbsp;</td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="reloadtime" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="balasmax" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="control" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="FR" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="PR" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="CR" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136" align="right">
											###</td>
											<td width="7">:											</td>
										  <td width="297">
										  <input type="text" name="LR" size="14" value="0">
										  <img src="images/deletar.png" width="16" height="16"></td>
										</tr>

										<tr>
											<td width="136">&nbsp;											</td>
											<td width="7">&nbsp;											</td>
											<td width="297">&nbsp;											</td>
										</tr>

										<tr>
											<td colspan="3">
											<p align="center">
										  <input type="submit" value="--> Adicionar Donator Iten <-- " name="submit"></td>
										</tr>

										<tr>
											<td colspan="3"></td>
										</tr>
										</table>
									</form>
								</div>
								</td>
							</tr>
							
					  </table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
					
<?
}
?>