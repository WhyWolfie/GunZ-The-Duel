<div class="inside">
                <table width="200" border="0">
  <tr>
    <td><div id="content">
                <div class="content-outline content-top">
                  <div class="title">Noticias e Atualiza&ccedil;&oacute;es</div>
                </div>
        		<div class="content-outline content-cont">
                                                    <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="525" height="151">
                                                      <tr>
                                                        <td width="261" height="24">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Noticias</td>
                                                        <td width="10" height="24">&nbsp;</td>
                                                        <td width="231" height="24">Atualiza&ccedil;&oacute;es</td>
                                                      </tr>
                                                      <tr>
                                                        <td width="261" valign="top"><table border="0" style="border-collapse: collapse" width="261" height="92%">
                                                            <tr>
                                                              <td width="3">&nbsp;</td>
                                                              <td width="248" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"><font size="1" face="Verdana"></font></span><font face="Verdana" size="1"><font color="#FFFFFF"> <a href="index.php?plus=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$n['Title']?>
                                                                    </a></font></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                        <td width="10">&nbsp;</td>
                                                        <td width="231" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                                            <tr>
                                                              <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"> <font size="1" face="Verdana">&raquo;</font></span> <a href="index.php?plus=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                      <?=$n['Title']?>
                                                                    </font></a></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                      </tr>
                                                    </table>
                </div>
                <div class="content-outline content-end"></div>
                </div></td>
  </tr>
</table>
                <table width="200" border="0">
  <tr>
<link href="http://hostarm.com.br/banner/css/banner1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://hostarm.com.br/banner/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://hostarm.com.br/banner/js/banner1.js"></script>
</head>

<body>



<div aling="center"><a href="http://hostarm.com.br/"><img src="images/hostarm.png" width="655" height="120" border="0" /></a></td>




	
    <td><div id="content">
                <div class="content-outline content-top">
                  <div class="title">Utimos Itens Adicionados</div>
                </div>
        		<div class="content-outline content-cont">
                            
<?
if(!function_exists("ListLatestItens")){
function ListLatestItens(){


    $res = mssql_query("SELECT TOP 6 * FROM ShopDGZ WHERE Opened = '2'");

    ?><div id='boxxing'>
   
    <div align="center">
						<table border="0"  style="border-collapse: collapse">
							
							<tr>
								<td>
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="11">&nbsp;</td>
											<td width="440" colspan="2">
											</td>
											<td width="30">&nbsp;</td>
										</tr>

										<tr>
											
										</tr>

											<td width="12" colspan="2"></td>
										</tr>


										<tr>
											<td width="449" colspan="2">&nbsp;
											</td>
										</tr>

										<tr>
                                                                                <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 2) {
                                                $count = 1;
                                                echo "
                                                    </tr><tr>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
											        </tr><tr>";
                                                ?>
                                                <td width="208">

											<table border="0" style="border-collapse: collapse" width="102%" height="100%">
												<tr>
													<td width="100" rowspan="8" valign="top">
													<p align="center">
													<img border="0" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="106" valign="top">
													<font color="#FF9900"><b><?=$item['Name']?></b></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="106" valign="top">
													<font color="#FFFFFF">Tipo: Donator</font></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													<font color="#FFFFFF">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													<font color="#FFFFFF">N�vel: <?=$item['ResLevel']?></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													<font color="#FFFFFF">Pre�o: <?=$item['CashPrice']?></font></td>
												</tr>
												<tr>
													<td width="106">
													<p align="center">
													<a href="/index.php?plus=WGshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="47" height="19"></a></td>
												</tr>
												<tr>
													<td width="106">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="106">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>
                                                <?
                                            }else{
                                                ?>
                                                <td width="208">
                                                											<table border="0" style="border-collapse: collapse" width="100%" height="100%">
												<tr>
													<td width="100" rowspan="8" valign="top">
													<p align="center">
													<img border="0" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="106" valign="top">
													<font color="#ff9900"><b><?=$item['Name']?></b></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="110" valign="top">
													<font color="#FFFFFF">Tipo: Donator</font> </td>
												</tr>
												<tr>
													<td width="110" valign="top">
													<font color="#FFFFFF">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													<font color="#FFFFFF">N�vel: <?=$item['ResLevel']?></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													<font color="#FFFFFF">Pre�o: <?=$item['CashPrice']?></font></td>
												</tr>
												<tr>
													<td width="110">
													<p align="center">
													<a href="/index.php?plus=WGshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="47" height="19"></a></td>
												</tr>
												<tr>
													<td width="110">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="110">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>                                                <?
                                                 $count++;
                                            }
                                        }   ?>
											<td width="30">
											&nbsp;<p>&nbsp;</p>
											<p>&nbsp;</p>
											<p></td>
										</tr>

										<tr>
											<td width="445" colspan="2">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							
						</table>
					</div>
       <?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "";
        ListLatestItens();
    break;
}
}

?>                       
                </div>
                <div class="content-outline content-end"></div>
                </div></td>
  </tr>
</table>

                <?
                                                                $res = mssql_query_logged("SELECT TOP 4 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
?></td>
      </tr>
      





	<tr>
        <td><table border="0" style="border-collapse: collapse" width="631" height="100%">
	</tr>





                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										
									  <td width="611"><center>
									    <span class="statusdoserver">Nenhuma Notica Foi Adicionada Ate o exato momento Aguarde...									    </span>
									  </center></td>
									</tr>
                                        <?
                                    }else{
                                    while($n = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										
										<td width="611"><right></td>
										
									</tr>
                                    <?}}?>
								</table>

<iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2FDragonGunZ%3Ffref%3Dts&amp;width=645&amp;height=290&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:645px; height:177px;" allowTransparency="true"></iframe>


                <div id="content">
                
        		
                
                </div>
                </div>