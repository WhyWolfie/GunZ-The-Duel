<div class="content-outline content-top">
                  <div class="title"><a href="#">Download Dragon GunZ</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
-->
</style>

			<div class="contentBox">
              <ul class="rank">
            	<h2 class="noMargin style1">Baixar Dragon GunZ</h2><br />

                <table width="612" border="1" align="center" cellpadding="2" cellspacing="5" bgcolor="000" class="hover" style="border: 1px solid #00688B">
	<tr>
	  <th width="186" align="center" bgcolor="#333333">Nome do Arquivo</th>
	  <th width="186" align="center" bgcolor="#333333">Descri&ccedil;&atilde;o do Arquivo</th>
	  <th width="164" align="center" bgcolor="#333333">Tamanho</th>
	  <th width="240" align="center" bgcolor="#333333">Link do Arquivo</th>
	</tr>
  <tr>
	<td align="center" bgcolor="#333333">Dragon GunZ</td>
	<td align="center" bgcolor="#333333">Download 1 </td>
	<td align="center" bgcolor="#333333">290 MB</td>
	<td align="center" bgcolor="#333333"><a class="active" href=" http://www.multiupload.nl/ZD6SA031XB">[MultiUpload]</a></td>
  </tr>  
    <tr>
	<td align="center" bgcolor="#333333">Dragon GunZ</td>
	<td align="center" bgcolor="#333333"> Download 2 </td>
	<td align="center" bgcolor="#333333">290 MB</td>
	<td align="center" bgcolor="#333333"><a class="active" href=" http://www.4shared.com/file/B0VxHyjw/DragonGunZ.html?">[4Shared]</a></td>
  </tr>
  
	<?php for($x=0;$x<sizeof($down1);$x++) {
		if($x %2 == 0)
		{
		 $cor = "#cccccc";
		}
		else
		{
		 $cor = "#cccccc";   
		} ?>
	<tr>
	  <td align="center" bgcolor="<?php echo $cor; ?>" ><?php echo $down1[$x];?></td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><?php echo $down3[$x];?></td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><?php echo $down4[$x];?></td>
	  <td align="center" bgcolor="<?php echo $cor; ?>"><a href="<?php echo $down2[$x]; ?>" target="_blank">[Link 1]</a>
	  <?php echo ($down5[$x][0] == true) ? "<a href=\"".$down5[$x][1]."\" target=\"_blank\">[Link 2]</a>" : "" ?>
	  <?php echo ($down6[$x][0] == true) ? "<a href=\"".$down6[$x][1]."\" target=\"_blank\">[Link 3]</a>" : "" ?></td>
	</tr>
	<?php } ?>
</table>
<p>&nbsp;</p>

            	<h2 class="noMargin style1">Requerimentos Basicos</h2><br />
                <table class="style">
<table width="612" border="1" align="center"  cellpadding="2" cellspacing="5" class="hover"  style="border: 1px solid #00688B">
  <tr>
	<th align="center" bgcolor="#333333" >Tipo</th>
	<th align="center" bgcolor="#333333">M&iacute;nimo Requerido</th>
	<th align="center" bgcolor="#333333" >Recomendado</th>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">CPU</td>
	<td align="center" bgcolor="#333333">Pentium III - 700 MHz</td>
	<td align="center" bgcolor="#333333">Pentium IV - 2.0 GHz ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">RAM</td>
	<td align="center" bgcolor="#333333">256MB</td>
	<td align="center" bgcolor="#333333">512MB ou superior</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">Sistema Operacional</td>
	<td align="center" bgcolor="#333333">Win9x</td>
	<td align="center" bgcolor="#333333">Win2000/XP</td>
  </tr>
  <tr>
	<td align="center" bgcolor="#333333">VGA</td>
	<td align="center" bgcolor="#333333">32MB</td>
	<td align="center" bgcolor="#333333">128MB ou superior</td>
  </tr>
  <tr>
	<td height="19" align="center" bgcolor="#333333">Conex&atilde;o</td>
	<td align="center" bgcolor="#333333">56k</td>
	<td align="center" bgcolor="#333333">Banda larga ou superior</td>
  </tr>
</table>
<p>&nbsp;</p>
  </div></div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>