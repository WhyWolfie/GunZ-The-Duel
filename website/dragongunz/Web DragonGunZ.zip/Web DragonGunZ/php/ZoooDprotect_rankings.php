<div class="content-outline content-top">
                  <div class="title">Ranking's UG</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
<table width="413" height="35" border="1">
  <tr>
    <td width="286"><a href="index.php?plus=players"><img src="images/img1.png" width="286" height="99" border="0" /></a></td>
    <td width="111"><a href="index.php?plus=clans"><img src="images/img2.png" width="286" height="99" border="0" /></a></td>
  </tr>
</table></center><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
