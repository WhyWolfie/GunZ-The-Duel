<?
include "protects/authafundadores.php";
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>

<style type="text/css">
<!--
.style1 {color: #009999}
a:link {
	color: #666666;
	font-style: italic;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
.style2 {
	color: #666666;
	font-style: italic;
	font-size: 9px;
}
-->
</style>
<div class="content-outline content-top">
                  <div class="title">Painel Do Fundador "Plus GunZ"</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center><table width="419" border="0">
  <tr>
    <td width="127"><div align="center" class="style1">Sistema 1 </div></td>
    <td width="127"><div align="center" class="style1">Sistema 2  </div></td>
    <td width="127"><div align="center" class="style1">Sistema 3 </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?plus=EspecialCoinsxDxD">Enviar G.C  </a></div></td>
    <td><div align="center"><a href="index.php?plus=CoinsAndSunDisk">Enviar P.C  </a> </div></td>
    <td><div align="center"><a href="index.php?plus=staff0">Graduacoes PG   </a> </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?plus=indexadmin">Ver Pagamentos </a></div></td>
    <td><div align="center"><a href="index.php?plus=DesbanirusuarioWG">Zerar grades  </a></div></td>
    <td><div align="center"><a href="index.php?plus=fundadoreswantedtrocar">Altera&ccedil;&atilde;o de senhas </a></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><a href="index.php?plus=fundadoreswantedgrade">Altera&ccedil;&atilde;o de Grades   </a> </div></td>
    <td><div align="center" class="style2">[ Sem Funcao ]</div></td>
    <td><div align="center" class="style2">[ Sem Funcao ]</div></td>
  </tr>
</table>

					</div>
                </div>
                <div class="content-outline content-end"></div>
				