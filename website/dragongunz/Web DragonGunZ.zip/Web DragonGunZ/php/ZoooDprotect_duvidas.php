<div class="content-outline content-top">
                  <div class="title"><a href="#">D�vidas Frequentes.</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center><table width="200" border="0">
  
  <tr><h2>
<br><br> <font color="#B22222"> D�vidas Sobre Doa��es</font> <br>
<font color="#FFA500"></font><br><br><br><font color="#D3D3D3">
<div align="left"><font color="#B22222">1)</font> Como confirmar minha doa��o ?<font color="#B22222"><br>R:</font>Adicionando no Skype: <font color="#FFA500">tiago_pdc </font>ou <font color="#FFA500"></font>no MSN: <font color="#FFA500">dragongunz.com@hotmail.com</font><br> <br>
<font color="#B22222">2)</font> Quantos dias demora para eu receber minhas mo�das ?<font color="#B22222"><br>R:</font> De 1 � 3 dias �teis ap�s o pagamento.  <br> <br>
<font color="#B22222">3)</font> Qual as formas de pagamento ?<font color="#B22222"><br>R:</font> Via PagSeguro ou Dep�sito ! <br><br>
<font color="#B22222">4)</font> H� Possibilidades de eu n�o receber minhas mo�das ?<font color="#B22222"><br>R:</font> Tendo o comprovante em m�os, n�o teria como n�o receber. <br><br>
<font color="#B22222">5)</font> Qual as vantagens de ser um doador ?<font color="#B22222"><br>R:</font> Obter itens exclusivos e mais fortes, e ser diferente dos outros.  <br><br>
<font color="#B22222">6)</font> Caso eu pare de jogar poderei receber meu dinheiro de volta ? <font color="#B22222"><br>R:</font>: N�o, n�o ser� reembolsado valor nenhum, nem mesmo se um dia<br> o servidor vier a "FALENCIA".  <br><br>
<font color="#B22222">7)</font> Caso eu compre itens errados, poder� ser devolvido minhas mo�das? <font color="#B22222"><br>R:</font>: N�o, n�o ser� devolvido mo�das nenhuma, por nenhum motivo. ".  <br><br>



</font></h2>
</div>

  </tr>
</table>

					
					<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
