<?php // Por Geovane Souza

// Dados do servidor

$SERVER_['HOST'] = "UNIVERSE-525960\SQL"; // SQL HOST
$SERVER_['USER'] = "sa"; // SQL login padrao sa
$SERVER_['SENHA'] = "wanted#$158"; // SQL senha
$SERVER_['DB'] = "GunzDB"; //SQL Database padrao GunzDB

// Iniciar a conexao
$conexao = @mssql_connect($SERVER_['HOST'], $SERVER_['USER'], $SERVER_['SENHA']) or die ("Falha ao conectar - se com o Servidor");
$selecionar_db = @mssql_select_db($SERVER_['DB']) or die ("Falha ao conectar - se com a Database");

// Fim do script
?>
