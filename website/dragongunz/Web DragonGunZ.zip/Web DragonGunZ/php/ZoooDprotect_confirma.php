<?
include "protects/authafundadores.php";
if($_GET['WG'] == "anuncios"){
    $res = mssql_query("SELECT * FROM confirma WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
<style type="text/css">
<!--
.style1 {color: #FF0000}
.style2 {
	color: #999999;
	font-weight: bold;
	font-size: 18px;
	font-style: italic;
}
-->
</style>

   
						<div class="content-outline content-top">
                  <div class="title">Pagamento Efetuado</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table width="509" height="209" border="0" cellspacing="1" bordercolor="#999999">
							
							<tr>
								<td background="">
								<div align="center">
									<table width="505" height="100%" border="0" bordercolor="#666666" style="border-collapse: collapse">
										<tr>
											<td width="8" rowspan="14">&nbsp;</td>
											<td width="171">
											  <div align="center"></div>
											<td width="477">&nbsp;</td>
											<td width="16">&nbsp;</td>
										</tr>
										<tr>
											<td width="171">
											<b>Enviado [Login]:<span class="style1">
											</span></b></td>
											<td width="477"><?=$a['User']?>&nbsp;</td>
											<td width="16">&nbsp;</td>
										</tr>
										<tr>
											<td width="171">&nbsp;</td>
											<td width="477">&nbsp;</td>
											<td width="16">&nbsp;</td>
										</tr>
										<tr>
										  <td>Nome</td>
										  <td><?=$a['Title']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>E-mail</td>
										  <td><?=$a['mail']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>Provedor</td>
										  <td><?=$a['provedor']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>Data</td>
										  <td><?=$a['Data']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>Hora</td>
										  <td><?=$a['Hora']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>Quantidade</td>
										  <td><?=$a['Quantidade']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
										  <td>Tipo</td>
										  <td><?=$a['Type']?></td>
										  <td>&nbsp;</td>
									  </tr>
										<tr>
											<td width="171">Adicionais:											</td>
											<td width="477"><?=$a['Text']?>&nbsp;</td>
											<td width="16">&nbsp;</td>
										</tr>
										<tr>
											<td width="171">
											<center>
											&nbsp;</center>											</td>
											<td width="477">&nbsp;</td>
											<td width="16">&nbsp;</td>
										</tr>
								  </table>
								</div>
								</td>
							</tr>
							
	  </table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>

    <?
}else{
    $res = mssql_query("SELECT * FROM confirma WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
    <?}?>
