<?
$res = mssql_query_logged("SELECT TOP 1000 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<style type="text/css">
<!--
.style1 {color: #999999}
-->
</style>

<div class="content-outline content-top">
                  <div class="title">Players Ranking UG</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<table border="0" style="border-collapse: collapse" width="569" id="table4">
							
								<td width="461">
								<table border="0" style="border-collapse: collapse" width="645" height="100%">
									<tr>
									  <td width="68"><div align="center" class="style1">Rank</div></td>
										<td width="90"><font color="#FFFFFF">Nome</font></td>
										<td width="117">Tempo Logado (min) </td>
										<td width="83">Experiencia</td>
										<td width="67">Matou</td>
									    <td width="66">Morreu</td>
								      <td width="124"><div align="center" class="style1">Level</div></td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="68">&nbsp;</td>
										<td width="90"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
<td width="68"><div align="center"><b>
  <font color="#FF9900">
    <?=++$count ?>
    </font>
</b></div></td>
									  
<td width="90"><font color="#FFFFFF"><a href="?plus=charinfo&amp;id=<?=$clan['CID']?>"><?=$clan['Name']?></a></font></td>

<td width="117">
  <?=$clan['PlayTime']?></td>
<td width="83"><?=$clan['XP']?></td>
<td width="67"><?=$clan['KillCount']?></td>
<td width="66"><?=$clan['DeathCount']?></td>
<td width="124">
		    <p align="center"><font color="#FFFFFF">
	        </font><font color="#FFFFFF">
	        <?=$clan['Level']?>
	        </font></td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="68">&nbsp;</td>
										<td width="90">&nbsp;</td>
										<td width="117">&nbsp;</td>
										<td width="83">&nbsp;</td>
										<td width="67">&nbsp;</td>
										<td width="66">&nbsp;</td>
										<td width="124">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
