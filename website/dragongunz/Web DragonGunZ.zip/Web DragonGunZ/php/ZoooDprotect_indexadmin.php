<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<style type="text/css">
<!--
.style2 {
	font-size: 18px;
	font-weight: bold;
	color: #000000;
	font-style: italic;
}
-->
</style>

<div class="content-outline content-top">
                  <div class="title">Pagamentos Efetuados ( UnderGamerZ )</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center><table width="353" height="209" border="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td width="500"><table width="370" border="0" cellspacing="1">
      <tr>
        <td>UG Donator:<br /><td height="62"><? include "Protects/inject.php" ?>
<?
include "protects/authafundadores.php";
                                                                $res = mssql_query_logged("SELECT TOP 50 * FROM confirma WHERE Type = '1' ORDER BY ICID DESC");
?><div id="ranking_clans">
  <table border="0" style="border-collapse: collapse" width="180" id="table4">
								<td background="">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>Nenhuma Noticia.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($n = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142"><p><a href="index.php?plus=confirma&WG=anuncios&id=<?=$n['ICID']?>">> <?=$n['Title']?></td>
										<td width="41"></td>
									</tr>
                                    <?}}?>
								</table>								</td>
							</tr>
</table></div></td>
      </td>
      </tr>
    </table></td>
    <td width="262"><table width="383" border="0" cellspacing="1">
      <tr>
        <td>Gold Donator:<br /><td height="62"><? include "Protects/inject.php" ?>
<?
                                                                $res = mssql_query_logged("SELECT TOP 50 * FROM confirma WHERE Type = '2' ORDER BY ICID DESC");
?><div id="ranking_clans">
  <table border="0" style="border-collapse: collapse" width="180" id="table4">
								<td background="">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>Nenhuma Noticia.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($n = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142"><p><a href="index.php?plus=confirma&WG=anuncios&id=<?=$n['ICID']?>">> <?=$n['Title']?></td>
										<td width="41"></td>
									</tr>
                                    <?}}?>
								</table>								</td>
							</tr>
</table></div></td></td>
      </tr>
    </table></td>
  </tr>
</table></center><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
