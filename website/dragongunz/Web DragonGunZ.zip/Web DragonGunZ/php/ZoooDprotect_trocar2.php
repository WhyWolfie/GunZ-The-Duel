<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-style: italic;
	font-weight: bold;
	color: #999999;
}
-->
</style>
<div class="content-outline content-top">
                  <div class="title"><a href="#">Trocar Pontos CW</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">

<table width="771" border="0" cellspacing="1" bordercolor="#999999">
  <tr>
    <td><?php
include "protects/banned.php";
include "protects/banneduser.php";
include "protects/checkcookie.php";
include "protects/title.php";
include 'protects/anti_inject.php';
include 'protects/anti_inject2.php';
include 'protects/inject.php';
include 'protects/inject2.php';
include 'protects/anti_sql.php';
?>
<?
//ZoooD[BR] <<< ProtecteD Script

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

if($etapa22 == 0){
?>
<form id="Trocar" name="Trocar" method="post" action="?plus=Trocar&etapa=1">
Personagem:
<select name="cid" class="text">
<?
$c = mssql_query("SELECT Login, FROM EVCoins WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proxima Etapa" />
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT EVCoins FROM Login WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))


{
die ("Este Personagen nao pertence a um clan.");
}else{

$_SESSION["CID"] = $cid22;
echo '
<font color=red>Inportante: </font>2 (dois) pontos de cw vc tem direito a 1 Event Coins.<br><br>
<form id="trocar" name="trocar" method="post" action="?plus=trocar&etapa=2">';
echo "Login $login22 tem $busca2[0] pontos de cw deseja trocar ?<br><br>";
echo "Quantos pontos deseja trocar?<br><br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="trocar" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 100){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["AID"]);

$busca3 = mssql_query("SELECT EVCosin FROM Losin WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "Voc� tem $busca4[0] pontos e quer trocar por $pontos VipCoins ?";
}else{

if ( !is_numeric($cid23) )
{
echo "ID do personagem editado";
die();
}

if ( !is_numeric($pontos) )
{
echo "Quantidade de Coins deve ser posta em numeros nao em letras.";
die();
}

if ($pontos == 0)
{
echo "N�o h� necessidade de comprar 0 ecoins";
die();		
}

if($pontos < 1)
{
echo "Error 416 >> Web Protected By: ZoooD[BR]";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set Custom=Custom +$divisao where AID='$aid22'");
mssql_query("update Login set EVCoins=EVCoins -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}
?>
</td>
  </tr>
</table>
<p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>
