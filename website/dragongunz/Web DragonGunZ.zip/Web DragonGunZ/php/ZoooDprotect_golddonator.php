<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<div class="content-outline content-top">
                  <div class="title">Compra de creditos (Gold)</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<div align="center"><br>
<table width="355" border="1">
  <tr>
    <td width="169"><div align="center">Pacote 100 Gold Coins </div></td>
    <td width="167"><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="491F39D37D7D1642247A4FBE27167FEE" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 200 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="5CB25BF7F9F976EDD4AEAFB91D4B98A9" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 300 Gold Coins</div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="CDA5C05B3F3FCCD004ABAF83FADC4D7E" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 400 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="20C125D45454617664706FA946D06DE8" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 500 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="04C779F52E2E287224BB4F9996EF960B" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 600 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="572EDA636161B0BCC48B6FB1F6F3670B" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 700 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="A69131CC8181A1844487CFB4D4F1E30A" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 800 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="EDD9375A7F7FBE4334326F9B99AF2B5D" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td><div align="center">Pacote 900 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="4D4CDD7C1A1A86F99424EFB924523A44" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
  <tr>
    <td bgcolor="#333333"><div align="center">Pacote 1000 Gold Coins </div></td>
    <td><center><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
        <!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
    <!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="A74A277A6B6B0A0554EE8F90A897255E" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></center></td>
  </tr>
</table></div>

<p>&nbsp;</p>
<p><strong class="style1">Como Efetuar Sua Compra Com Seguranca:</strong></p>
<p><br>
1&ordm; &nbsp;&nbsp;Escolha o pacote ao seu gosto e que caiba no seu bolso<br>
2&ordm; &nbsp;&nbsp;Preencha os campos necessarios que se pedi no cadastro pag seguro<br>
3&ordm; &nbsp;&nbsp;Efetue a impress&atilde;o do boleto bancario, que sera gerado logo ap&oacute;s o preencher os dados que se pedi no pag seguro<br>
4&ordm; &nbsp;&nbsp;Efetue o pagamento em qualquer casa loteria ou no banco indicado no boleto bancario<br>
5&ordm; &nbsp;&nbsp;Ap&oacute;s efetuar o pagamento ser&aacute; dado um comprovante juntamente a outra parte do boleto<br>
6&ordm; &nbsp;&nbsp;Guarde este comprovante, chegando  no estabelecimento que vc acessa o game ou tenha acesso a internet<br>
7&ordm; &nbsp;&nbsp;Acesse sua conta no aqui no site, v&aacute; at&eacute; a aba painel do usuario/confirma pagamento<br>
8&ordm;&nbsp;&nbsp; Ser&aacute; aberta uma pagina coloque todos os dados do comprovante nele juntamente com seu login.<br>
9&ordm; &nbsp;&nbsp;Aguarde at&eacute; 3 dias uteis para que o pagamento seja confirmado, e os coins entrara automaticamente em sua conta.<br>
10&ordm; Curta muito seus coins e seja o melhor dentro do jogo!
</p>
<p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>