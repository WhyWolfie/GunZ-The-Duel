<?
$res = mssql_query("SELECT TOP 1000 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
$count = 0;
?>
<div class="content-outline content-top">
                  <div class="title">Clan Ranking UG</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<table border="0" style="border-collapse: collapse" width="592" id="table4">
							
								<td>
								<table border="0" style="border-collapse: collapse" width="586" height="100%">
									<tr>
										<td width="59"><div align="center"><font color="#FFFFFF">Rank</font></div></td>
										<td width="81"><font color="#FFFFFF">Nome</font></td>
										<td width="50">Win's</td>
										<td width="47">Loser's</td>
										<td width="78">Pontos Total  </td>
										<td width="110">Pontos Acumulativos </td>
										<td width="110">Iniciado: </td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="59">&nbsp;</td>
										<td width="81"><center>Nemhum Clan.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
<td width="59"><div align="center"><b>
  <font color="#FF9900">
    <?=++$count ?>
    </font>
</b></div></td>
									  
<td width="81"><a href="?plus=claninfo&id=<?=$clan['CLID']?>"><?=$clan['Name']?></a></td>

<td width="50"><font color="#FFFFFF">
  <?=number_format($clan['Wins'],0,'','.');?>
</font></td>
<td width="47"><font color="#FFFFFF">
  <?=number_format($clan['Losses'],0,'','.');?>
</font></td>
<td width="78"><font color="#FFFFFF">
  <?=number_format($clan['TotalPoint'],0,'','.');?>
</font></td>
<td width="110"><font color="#FFFFFF">
  <?=number_format($clan['Point'],0,'','.');?>
</font></td>
<td width="110">
		    <p align="center"><font color="#FFFFFF">
	        </font><font color="#FFFFFF">
<?=$clan['RegDate']?>
	        </font></td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="59">&nbsp;</td>
										<td width="81">&nbsp;</td>
										<td width="50">&nbsp;</td>
										<td width="47">&nbsp;</td>
										<td width="78">&nbsp;</td>
										<td width="110">&nbsp;</td>
										<td width="110">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
