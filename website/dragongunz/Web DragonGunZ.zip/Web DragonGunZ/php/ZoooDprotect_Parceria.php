<div class="content-outline content-top">
                  <div class="title">Parceria</div>
                </div><div class="content-outline content-cont">
                	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Parceria</title>
</head>

<body>
<div align="center">
<div align="center"><h1>Radio vibe insanity</h1><br>
<div align="center"></div><iframe src="http://radiovibeinsanity.com.br/players/preto/" width="100%" height="40" scrolling="no" frameborder="0"></iframe>
</div>
</div>
</body>
</html>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>