<script language="JavaScript">
function tecla() 
{
if (event.keyCode==123)
{
alert("ZoooD[BR]: Proibido usar esta tecla nesta web site");
event.keyCode=0;
event.returnValue=false;
}
} document.onkeydown=tecla;
</script>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> </script>