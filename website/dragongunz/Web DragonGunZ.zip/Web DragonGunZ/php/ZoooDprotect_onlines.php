<div class="content-outline content-top">
                  <div class="title">Players Online</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
					
					<center>
					<table width="571" border="1" style="border-width:medium;"> 
<tr> 
<td width="101" style='text-align:right;'><div align="left">Nome</div></td>
<td width="81" style='text-align:right;'><div align="left">Level</div></td>
<td width="74" style='text-align:right;'><div align="left">Exp</div></td> 
<td width="96" style='text-align:right;'><div align="left">Bount</div></td> 
<td width="91" style='text-align:right;'><div align="left">Matou</div></td>
<td width="82" style='text-align:right;'><div align="left">Morreu</div></td> 
</tr> 
<?php 
include 'php/conectar.php'; //We need to connect to DB eh? 
$_blabla = mssql_query("SELECT * FROM Account WHERE LastLoginTime > LastLogoutTime"); //Check if someone is still online 
while($kurvanagylofasz = mssql_fetch_array($_blabla)){ //Simple fetch shit... 
$aid = $kurvanagylofasz['AID']; 
$getChar = mssql_query("SELECT TOP 1 * FROM Character WHERE AID = \"$aid\" ORDER BY LastTime DESC"); //Get the last char used by the account 
while($faszom = mssql_fetch_array($getChar)){ //A simple fetch again.... 
/*And here we can print out what we want about the character... 
* Feel free to edit this part... 
*/ 
echo "<tr> 
<td style='text-align:left;'>".$faszom['Name']."</td> 
<td style='text-align:right;'>".$faszom['Level']."</td> 
<td style='text-align:right;'>".$faszom['XP']."</td>
<td style='text-align:right;'>".$faszom['BP']."</td>
<td style='text-align:right;'>".$faszom['KillCount']."</td>
<td style='text-align:right;'>".$faszom['DeathCount']."</td>
</tr>"; 
} 
} 
?> 
</table></center>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>