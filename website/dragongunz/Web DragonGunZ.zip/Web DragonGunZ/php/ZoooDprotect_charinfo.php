<?
    $cid = antisql($_GET['id']);
if(!is_numeric($cid)){
msgbox("Nao disponivel","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);

if($num_rows < 1){
msgbox("Esta conta nao existe","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "253" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "254" || $char2['UGradeID'] == "255"){
    msgbox("Voc� n�o pode ver perfil de membros da staff.","index.php");
exit();
	}
	if ( $char2['DeleteFlag'] != "0"){
    msgbox("Voc� n�o pode ver isso..","index.php");
exit();
	}
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = ""; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
<div class="content-outline content-top">
                  <div class="title"><a href="#">Informa��o Sobre o Player ( <?=$char['Name']?> )</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<center><table border="2" style="border-collapse: collapse" width="490" bordercolor="#666666">
								<tr>
									<td background="" height="24" style="background-image: url('images/fundin.png'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Player Information </font></b></td>
								</tr>
                          
                            <td bgcolor="" class="Estilo1" align="center" valign="top"><table width="533" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="266" border="0" align="center">
                                  
                                  
                                  <tr>
                                    <td width="117" align="left" class="estilo1">Nome:</td>
                                    <td width="139" align="left" class="estilo1"><?=$char2['Name']?></td>
                                  </tr>
                                  
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Gradua��o:</td>
                                    <td align="left" class="estilo1"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Membro";
                                                        break;
														 case "2";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "3";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "4";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "5";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "6";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "7";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "8";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "9";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "13";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "14";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "15";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "16";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "17";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "18";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "19";
                                                        $ugradeid = "Name Collor";
                                                        break;
														 case "20";
                                                        $ugradeid = "Name Collor";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Mutado";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "Moderador";
                                                        break;
							case "253";
                                                        $ugradeid = "Banido";
                                                        break;
							case "254";
                                                        $ugradeid = "Game Master";
                                                        break;
							case "255";
                                                        $ugradeid = "Administrador";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Participa do Clan: </td>
                                    <td align="left" class="estilo1"><a href="index.php?plus=claninfo&amp;id=<?=$claninfo['CLID']?>">
                                      <?=$claninfo['Name']?>
                                    </a></td>
                                  </tr>
                                  
                                  
                                </table></td>
                                <td align="center" valign="top"><table width="262" border="0" align="center">
                                  
                                 
                                  <tr>
                                    <td width="90" align="left" class="estilo1">Char:</td>
                                    <td width="162" align="left" class="estilo1"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Level:</td>
                                    <td align="left" class="estilo1"><?=$char['Level']?></td>
                                  </tr>
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Exp:</td>
                                    <td align="left" class="estilo1"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Kill/Death:</td>
                                    <td align="left" class="estilo1"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  
                                  
                                  
                                </table></td>
                              </tr>
                            </table>

                          </tr>
</table></center>
<p>&nbsp;</p>
  </div>
                
                <div class="content-outline content-end"></div>
                </div>