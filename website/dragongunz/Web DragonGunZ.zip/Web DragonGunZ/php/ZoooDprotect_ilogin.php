<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
<?
if ($_SESSION['AID'] == ""){
?>
<style type="text/css">
<!--
a:link {
	color: #666666;
}
.style3 {
	font-size: 16px;
	font-style: italic;
	color: #CCCCCC;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
.style4 {font-size: 12px}
.style5 {font-size: 12px; font-style: italic; color: #CCCCCC; }
-->
</style>

<div align="center">
						<div id="login"><table border="0" style="border-collapse: collapse" width="180" id="table5">
							<tr>
								<td width="180" background="menu_bg.jpg">
								<form method="POST" action="index.php?plus=login&header=1" name="login">
									<table border="0" style="border-collapse: collapse" width="178" height="100%" id="table10" class="iLogin">
										<tr>
											<td colspan="4"><div align="center" class="style3 style4"></div></td>
										</tr>
										
										<tr>
											
											<td width="161">
										      <div align="center">
										        <input class="bar" type="text" id="username" name="userid" onfocus="if(this.value=='Username') this.value='';" onblur="if(this.value=='') this.value='Username';" value="Username">
									      </div></td>
										</tr>
										
										<tr>
											
											<td width="161">
										      <div align="center">
										        <input class="bar" type="password" id="password" name="pasw" onfocus="if(this.value=='Password') this.value='';" value="Password">
								          </div><div class="sep"></div>
										  </td>
										</tr>
										<tr>
											<td width="161" rowspan="2">
  <div id="login">
                    <input name="submit" type="submit" class="submit"><a href="index.php?plus=register" class="register">Register</a><br clear="all"/>
                    <p><a href="index.php?plus=recuperarsenha">Esqueceu sua senha?</a></p>
                    </div></td>
										</tr>
								  </table>
								</form>								</td>
							</tr>
							<tr>
								
							</tr>
</table></div>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
?>

<div align="center">
<div align="center">
						<table border="0" style="border-collapse: collapse" width="178" id="table5">
							<tr>
								
						  </tr>
							<tr>
								<td background="">
																	<table border="0" style="border-collapse: collapse" width="180" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<?=$_SESSION['UserID']?><span class="timeclock" style="margin-left:15px; margin-top:25px; color:#777777; font-size:10px;">
	<script>
 function showTimer() {
  var time=new Date();
  var hour=time.getHours();
  var minute=time.getMinutes();
  var second=time.getSeconds();
  if(hour<10)   hour  ="0"+hour;
  if(minute<10) minute="0"+minute;
  if(second<10) second="0"+second;
  var st=hour+":"+minute+":"+second;
  document.getElementById("timer").innerHTML=st; 
 }
 function initTimer() {
  // O metodo nativo setInterval executa uma determinada funcao em um determinado tempo  
  setInterval(showTimer,1000);
 }
</script>
<body onLoad="initTimer();">
<span id="timer"></span>
</body></font></td>
										</tr>
<tr>

										  <td>&nbsp;</td>
										  </tr>
										<tr>
										<tr>
											<td width="8" rowspan="5">&nbsp;</td>
											<td width="181"><img src="images/ouro.png" width="12" height="11"> VIP Coins:  <?=$d['Custom']?> <br><br>
											<img src="images/prata.png" width="12" height="11"> DG Coins:  <?=$d['RZCoins']?> <br><br> 
											<img src="images/bronze.png" width="12" height="11"> EV Coins:  <?=$d['EVCoins']?> </td></td>									 <tr>

										  <td>&nbsp;</td>
										  </tr><tr>
											
										  <td><a href="index.php?plus=painelplayer"><img src="images/bullet.gif" width="12" height="11"> Painel do Usu�rio DragonGunZ</a></td>
										  </tr>
										  <tr>

										  <td>&nbsp;</td>
										  </tr>
										  
										<tr>
										  <td><center> <a href="index.php?plus=login&amp;action=logout&amp;header=1">Deslogar</a></td>
										  </tr>
										<tr>
										</tr>
<tr>
											<td colspan="2">
											<div align="center">
												
											</div>											</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="center">
												
											</div>											</td>
										</tr>
										</table>
								
								
							</tr>
							<tr>
								
						  </tr>
</table>

<?
}
?>
