<?
$cinfo = ($_GET['id']);
if(!is_numeric($cinfo)){
msgbox("Not Available","index.php");
exit();
}
$query = mssql_query("SELECT * FROM Clan WHERE CLID = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$num_rows = mssql_num_rows($query);

if($num_rows < 1){
msgbox("Clan n�o existe","index.php");
exit();
}

$clid = $clan->CLID;
?>
<div class="content-outline content-top">
                  <div class="title"><a href="#">Informa��o Sobre o Clan ( <?=$clan->Name?> )</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<center>
<table border="1" style="border-collapse: collapse" width="570" bordercolor="#333333">
								

                          <tr>
                            <td width="693" height="35" align="center" bgcolor="" class="Estilo2">
                              <div align="left"><img src="Dragon/<?=($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl?>" width="100" height="100" BORDER=5 ></br></br></br>
                            </div></td>
</tr>
                          <tr>
                            <td bgcolor="" class="Estilo1" align="center" valign="top">
<table width="561" border="0" align="center" cellpadding="0" cellspacing="0">
                              
                                  </center>
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Win:</td>
                                    <td width="435" align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Loser:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
								  <tr>
                                      <td align="left" class="estilo1">Pontos: </td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  
                                  <tr>
                                    <td align="left" class="estilo1">Clan Criado Em:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Total de membros:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                  <center>
                                    <td width="126"><div align="center"></div></td>
                                  </center>
                              </table>                                </td>
      </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="581" border="0" cellpadding="0" cellspacing="0">
&nbsp;
                                  <tr>
                                    <td width="124" align="center" class="estilo1"><u>Char</u></td>
                                    <td width="190" align="center" class="estilo1"><u>Gradua&ccedil;&atilde;o</u></td>
                                    <td width="129" align="center" class="estilo1"><u>Data de Inclus&atilde;o </u></td>
                                    <td width="138" align="center" class="estilo1"><u>Pontos</u></td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Membro";
    break;
    case "2";
       $grade = "Administrador";
    break;
    case "1";
       $grade = "Lider";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><a href="index.php?plus=charinfo&id=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                      </table>
</center>
<p>&nbsp;</p>
  </div>
                
                <div class="content-outline content-end"></div>
                </div>