<?
$show =1;
//Check if is logued
if(!function_exists("ShowResetPwdForm")){
    function ShowResetPwdForm(){
        if(!$_SESSION['AID'] == ""){re_dir("index.php");}
        if($_POST['submit'] == ""){
            ?>
            					<form name="pwd" method="POST" action="index.php?do=login&action=resetpwd"><div align="center">
						
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


            

                <form name="pwd" method="POST" action="index.php?do=login&action=resetpwd"><div align="center">
						
                <?
                   }elseif ($_POST['submit'] == "Paso 3"){
                        $sa = antisql($_POST['sa']);
                        $mail = antisql($_POST['email']);
                        $res = mssql_query("SELECT * FROM Account WHERE Email = '$mail' AND sa = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
                            					<form method="POST" action=""><div align="center">
						

                            <?
                            }else{
                                msgbox("The E-Mail or the secret answer is incorrect.","index.php?do=login&action=resetpwd");
                            }
                    }elseif ($_POST['submit'] == "End"){
                        if($_POST['pw1'] == $_POST['pw2']){
                            $pw1 = antisql($_POST['pw1']);
							//Oops?
                            mssql_query("UPDATE Login SET Password = '$pw1' WHERE UserID = '" . antisql($_SESSION['ResetPwdUser']) . "'");
                            msgbox("Password reset complete!","index.php?do=login");
                        }else{
                            msgbox("Please use the same password in both boxes!","index.php?do=login&action=resetpwd");
                        }
                    }








                     }}

//Logout
switch ($_GET['action']) {
    case "logout";
		//Oops?
        $user = antisql($_SESSION['UserID']);
        $user = ucfirst($user);
		//How about session_destroy next time?.
        unset($_SESSION['AID']);
        unset($_SESSION['UserID']);
        unset($_SESSION['euCoins']);
        unset($_SESSION['UGradeID']);
        unset($_SESSION['Pass']);
        setcookie ("MPOGLogin_usr", "", time() - 3600);
        setcookie ("MPOGLogin_pwd", "", time() - 3600);
        echo "<script language='Javascript'> document.location = 'index.php';alert('o usuario ( $user ) foi disconectado com sucesso!'); </script>";
        break;
    case "resetpwd";
        ShowResetPwdForm();
        $show =0;
    break;
}

if(!$_SESSION['AID']== "index.php"){
    echo "<script language='Javascript'> document.location = 'index.php';alert('Error 407 ( Senha Incorreta ) > ProtecteD By: P3T3RP4N'); </script>";
}


if (isset($_POST['submit']) and $show ==1){
    $user = antisql($_POST['userid']);
    $pwd = antisql($_POST['pasw']);
    $sql = mssql_query("SELECT * FROM Login WHERE UserID = '".$user."' AND Password = '".$pwd."'");
    if (mssql_num_rows($sql) == 1){
        $data = mssql_fetch_assoc($sql);
        $_SESSION['AID'] =  $data['AID'];
        $_SESSION['UserID'] = ucfirst($user);
        $_SESSION['euCoins'] = $data['euCoins'];
        $_SESSION['Pass'] = ucfirst($pwd);
        //---
        $res2 = mssql_query("SELECT * FROM Account WHERE AID = '".$data['AID']."'");
        $aData = mssql_fetch_assoc($res2);
        $_SESSION['UGradeID'] = $aData['UGradeID'];
        if($_POST['cookie'] == "ON"){
            setcookie("Login_usr", $user, time()+60*60*24*100);
            setcookie("Login_pwd", md5("mpogc_".$data['Password']), time()+60*60*24*100);
        }else{
            setcookie ("Login_usr", "", time() - 3600);
            setcookie ("Login_pwd", "", time() - 3600);
        }
        header("Location: index.php");
    }else{
        echo "<body bgcolor='#000000'><script language='Javascript'> alert('');document.location = 'index.php?wanted=login'; </script>";
    }
}
if ($show ==1){
?>
<form name="reg" method="POST" action="index.php?wanted=login&header=1"><body bgcolor="#323232">

					<div align="center">
						
					</div></form>



<?
}













?>