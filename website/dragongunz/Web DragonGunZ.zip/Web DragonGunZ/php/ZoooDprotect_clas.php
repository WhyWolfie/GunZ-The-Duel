<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<form name="reg" method="POST" action="index.php?plus=register">
<div class="content-outline content-top">
                  <div class="title">Meus Clan's</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
	<body bgcolor="#312F30">

	<div align="center">
						<table width="509" border="0" bordercolor="#999999" style="border-collapse: collapse">
							
							<tr>
								<td background="">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="490" height="100%">
										<tr>
											<td width="1" rowspan="6">&nbsp;</td>
											<td width="438">											</td>
											<td width="37">&nbsp;</td>
										</tr>
										<tr>
											<td width="438">											</td>
											<td width="37">&nbsp;</td>
										</tr>
										<tr>
											<td width="438"><table width="479" height="100" border="0" align="center" bordercolor="#999999">

        <td width="476" align="center" valign="top"><table width="478" border="0">
          <tr>
            <td width="422" align="left">
              </td>
          </tr>
          <tr>
            <td align="center"><table width="463" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              
              <tr>
                <td height="25" align="center"><?
echo '  <font class="estilo1"></font>';
        $query = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."' AND DeleteFlag = 0 ORDER BY CharNum ASC");
        if ( mssql_num_rows($query) < 1 ){
        echo '<font face="Arial" color="#ff0000"><br>Voc� n�o tem personagens, Crie um agora mesmo!!</br>';
        }else{

        echo '
        ';
        }
        echo'</br>
     
        <font class="estilo1" align="center"><p><b></b><br>
        <table class="errorbox" width="350" align="center">
	    <tr>
        <td align="center" class="estilo1"><b>Emblema<br></b></td>
        <td align="center" class="estilo1"><b>Nome<br></b></td>
		<td align="center" class="estilo1"><b>Lider<br></b></td>

	    </tr>';
        $query2 = mssql_query_logged("SELECT * FROM Character(nolock) WHERE AID = '".clean($_SESSION['AID'])."' ORDER BY CharNum ASC");
        if (mssql_num_rows($query2) > 0){
        while ($chars2 = mssql_fetch_assoc($query2)){


        $clanq = mssql_query_logged("SELECT * FROM ClanMember WHERE CID = '".clean($chars2['CID'])."'");
            if (mssql_num_rows($clanq) != 0){
            $clanq2 = mssql_fetch_assoc($clanq);
                if($clanq2['Grade'] == 9){
                $rango = "Member  ";
                $admin = "No";
                }elseif($clanq2['Grade'] == 2){
                $rango = "Admin";
                $admin = "No";
                }elseif($clanq2['Grade'] == 1){
                $rango = "Master";
                $clid = $clanq2['CLID'] + 1990;
                $cid = $clanq2['CID'] + 2000;

                }else{
                $rango = "Error";
                }
            $claninfoq = mssql_query_logged("SELECT * FROM Clan WHERE CLID = '".clean($clanq2['CLID'])."'");
            $claninfo = mssql_fetch_assoc($claninfoq);

            $emblemurl = $claninfo['dragon/EmblemUrl'];
            if ($emblemurl == ''){
                $emblemurl = '<IMG SRC="shop/no_emblem.png" WIDTH=50 HEIGHT=50>';
            }else{
                $emblemurl = '<img width="50" height="50" src="'.$emblemurl.'">';
                }

                echo '<tr>
                <td align="center" valign="center"><p>'.$emblemurl.'</td>
                <td align="center" valign="center">'.$claninfo['Name'].'</td>
		        <td align="center" valign="center">'.FormatCharName($chars2['CID']).'</td>
		        <td align="center" valign="center">'.$rango.'</p></td>
             
	           </tr> ';
        }}}
?></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td height="5" align="center"></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table></td>
											<td width="8">&nbsp;</td>
						  </tr>
										<tr>
											<td width="490" height="24">
											<center>
										  &nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
	  </table>
	</div>
								</td>
							</tr>
							
						</table>
					</div></form>
					<center><table width="200" border="1">
  
</table></center><p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                
