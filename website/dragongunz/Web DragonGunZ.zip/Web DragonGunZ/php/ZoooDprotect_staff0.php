<style type="text/css">
<!--
a:link {
	color: #0099FF;
}
a:visited {
	color: #0099FF;
}
a:hover {
	color: #0099FF;
}
a:active {
	color: #0099FF;
}
-->
</style><div class="content-outline content-top">
                  <div class="title">Gradua&ccedil;oes PlusGunz</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
					
					<center><table width="592" border="0">
  <tr>
    <td width="288" bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff1">Administradores</a></p>
      <p>&nbsp;</p>
    </div></td>
    <td width="288" bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff2">Game Master's</a></p>
      <p>&nbsp; </p>
    </div></td>
    <td width="288" bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff3">Moderadores</a></p>
      <p>&nbsp;</p>
    </div></td>
  </tr>
  <tr>
    <td height="21" bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff4">Banidos</a></p>
      <p>&nbsp;</p>
    </div></td>
    <td bordercolor="#CCCCCC" bgcolor="#333333"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff5">Chat Blockiado </a></p>
      <p>&nbsp;</p>
    </div></td>
    <td bordercolor="#333333" bgcolor="#CCCCCC"><div align="center">
      <p>&nbsp;</p>
      <p><a href="index.php?plus=staff6">jjang</a></p>
      <p>&nbsp;</p>
    </div></td>
  </tr>
</table></center>

					<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>