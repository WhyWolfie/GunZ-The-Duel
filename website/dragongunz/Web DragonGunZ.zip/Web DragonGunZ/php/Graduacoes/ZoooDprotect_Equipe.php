<style type="text/css">
<!--
.Administradores_PG {color: #00CCFF}
.Cargo_PG {color: #FF0000}
.game__master {color: #006666}
.MODERADORES_PG {color: #FFFFFF}
-->
</style>
<div class="content-outline content-top">
                  <div class="title"><a href="#">Equipe PG</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
<table width="600" border="0">
  <tr>
    <td bgcolor="#990000"><div align="center"><span class="Administradores_PG">ADMINISTRADORES</span></div></td>
  </tr>
</table>
<table width="600" border="0">
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="98"><img src="images/no_emblem.png" width="98" height="100" /></td>
    <td width="492"><table width="496" border="0">
      <tr>
        <td width="490">Nome: Thyers Nascimento </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Fundador </span></td>
      </tr>
      <tr>
        <td>Idade: 17 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: PHP Coder // SQL Server.</td>
      </tr>
      <tr>
        <td>Character: ZoooD[BR] </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="495" border="0">
      <tr>
        <td width="489">Nome: Danilo Mendes </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Fundador</span> </td>
      </tr>
      <tr>
        <td>Idade: 15 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: Designer // Cliente.</td>
      </tr>
      <tr>
        <td>Character: DarkInside </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="497" border="0">
      <tr>
        <td>Nome: Kaique Oliveira </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Fundador</span> </td>
      </tr>
      <tr>
        <td>Idade: 14 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: N&atilde;o Detectada </td>
      </tr>
      <tr>
        <td>Character: Firewall </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="497" border="0">
      <tr>
        <td>Nome: Cleyton Machado </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Administrador </span></td>
      </tr>
      <tr>
        <td>Idade: 14 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: Divulga&ccedil;&atilde;o // Suporte. </td>
      </tr>
      <tr>
        <td>Character: Cleyton </td>
      </tr>
    </table></td>
  </tr>
  
</table>
<table width="604" border="0">
  <tr>
    <td bgcolor="#FF6600"><div align="center" class="game__master">GAME MASTER'S </div></td>
  </tr>
</table>
<table width="600" border="0">
  <tr>
    <td width="102"><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td width="488"><table width="489" border="0">
      <tr>
        <td>Nome: Kayque Barbieri </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Game Master</span> </td>
      </tr>
      <tr>
        <td>Idade: 15 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: Divulga&ccedil;&atilde;o // Suporte. </td>
      </tr>
      <tr>
        <td>Character: LinuxThyz</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="496" border="0">
      <tr>
        <td width="490">Nome: Vinicius Rocha </td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Game Master  </span></td>
      </tr>
      <tr>
        <td>Idade: 13 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: Divulga&ccedil;&atilde;o // Suporte.</td>
      </tr>
      <tr>
        <td>Character: Thamowoj</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="486" border="0">
      <tr>
        <td>Nome: Wallace</td>
      </tr>
      <tr>
        <td>Cargo: <span class="Cargo_PG">Game Master </span></td>
      </tr>
      <tr>
        <td>Idade: 15 Anos </td>
      </tr>
      <tr>
        <td>Especialidade: Divulga&ccedil;&atilde;o // Suporte. </td>
      </tr>
      <tr>
        <td>Character: Shinpow </td>
      </tr>
    </table></td>
  </tr>
</table>
<table width="600" border="0">
  <tr>
    <td bgcolor="#999999"><div align="center" class="MODERADORES_PG">MODERADORES</div></td>
  </tr>
</table>
<table width="600" border="0">
  <tr>
    <td width="101"><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td width="489"><table width="488" border="0">
      <tr>
        <td>Nome: ------------  </td>
      </tr>
      <tr>
        <td>Cargo: ------------ </td>
      </tr>
      <tr>
        <td>Idade: ------------ </td>
      </tr>
      <tr>
        <td>Especialidade: ---- </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr><tr>
    <td><img src="images/no_emblem.png" alt="a" width="98" height="100" /></td>
    <td><table width="488" border="0">
      <tr>
        <td>Nome: ------------ </td>
      </tr>
      <tr>
        <td>Cargo: ------------ </td>
      </tr>
      <tr>
        <td>Idade: ------------ </td>
      </tr>
      <tr>
        <td>Especialidade: ---- </td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table></center>
<p>&nbsp;</p>
 </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>