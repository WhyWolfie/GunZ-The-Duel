<div class="content-outline content-top">
                  <div class="title">Banidos Plus GunZ</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?
include "protects/authadmin.php";
if($_SESSION['UGradeID'] == 252){
    msgbox("Acesso Negado // Web protect By ZoooD[BR] // ==> Chave de Moderador","index.php");
}
if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Account WHERE UGradeID = 253") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 500; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Account where AID not in (select top $max AID from Account order by AID asc) and UGradeID = 253 order by AID asc");
echo "<p>"; 
echo "";
if ($pagenum == 1) { }
else
{
echo " <a href='index.php?do=banlist&pagenum=1'> <<-First</a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='index.php?do=banlist&pagenum=$previous'> <-Previous</a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=banlist&pagenum=$next'>Next -></a> ";
echo " ";
echo " <a href='index.php?do=banlist&pagenum=$last'>Last ->></a> ";
}

?>
<center><table width="601" border="1">
  <tr>
    <th width="75" scope="row"><span class="style28"><strong>N�</strong></span></th>
     <th width="86" scope="row"><span class="style28"><strong>AID</strong></span></th>
    <td width="169"><span class="style28"><strong>UserID</strong></span></td>
    <td width="112"><span class="style28"><strong>UGradeID</strong></span></td>
    <td width="125"><span class="style28"><strong>E-Mail</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
    <td><span class="style29"><?php echo "$row[6]";?></span></td>

</tr>
  <?
  $i++;
  }
   ?>
  <?
  }
   ?>
</table><center></div>
</body>

</html>
<p>&nbsp;</p>
  </div>
                
                <div class="content-outline content-end"></div>
                </div><div>