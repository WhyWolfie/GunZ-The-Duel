<div class="content-outline content-top">
                  <div class="title"><a href="#">Informacoes do Servidor  &quot;DragonGunZ&quot;</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<table width="416" border="0">
<tr>
    <td width="202">Servidor:</td>
    <td width="204"><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = '';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #228B22'><B>ONLINE</B></font><br />";
        }
        else
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #228B22'><B>ONLINE</B></font><br />";
            fclose($fp);
        }
    }
    ?></td>
  </tr>
 <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Agent error: </td>
    <td> . Conex&atilde;o NAT </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Players Online:</td>
    <td>. <?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong><font style='color: #00FFFF'>$servercount</font>";
    ?></td>
  </tr>

<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Record Online </td>
    <td>. <? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?><?=$b['PlayerCount']?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Total de Contas:</td>
    <td>. <? //Total Accounts
$query = mssql_query("SELECT * FROM login"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>"; 
?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Total de Cl�ns: </td>
    <td>. <?php

//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "".$num_rows."<n>";

?></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Server EXP: </td>
    <td>. 65x </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Jogabilidade:</td>
    <td>. Leve / Boa </td>
  </tr>
</table>
<br />

 </td>
  </tr>
  
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td></td>
    <td></td>
  </tr>
</table>
<br />
--------------------------------------------------------------------------------------------<br><br>Contatos Do Servidor</body><br><br><table width="421" border="0">
  <tr>
    <td width="203">FaceBook:</td>
    <td width="208">http://www.facebook.com/DragonGunZ</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
    <tr>
    <td>Skype:</td>
    <td>Tiago_pdc = P3T3RP4N</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>E-mail:</td>
    <td> dragongunz.com@hotmail.com </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
   
</table><br />
--------------------------------------------------------------------------------------------<br /><br /> 
Comandos Do Servidor
DG<br />
<br />
<table width="575" border="0">
  <tr>
    <td width="203">/texture</td>
    <td width="361">. Coloca textura no jogo deixando-o mais leve </td>
  </tr>
 
    <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>/time</td>
    <td>. Mostra hora atual do computador remoto </td>
  </tr>
  <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
 
  <tr>
    <td>/blur</td>
    <td>. Retira o rastro da espada, melhorando a jogabilidade </td>
  </tr>
 <tr>
    <td></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>/fechar_jogo</td>
    <td>. Fexa o game imediatamente </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>

