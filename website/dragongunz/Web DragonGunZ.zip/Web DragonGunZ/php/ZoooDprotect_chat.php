<style type="text/css">
<!--
.xat_style_xD {color: #FFFF66}
-->
</style>

<div class="content-outline content-top">
                  <div class="title"><a href="#">Suporte Online DragonGunz</a></div>
</div><div class="content-outline content-cont">
                	<div class="content-inside"><center><table width="600" border="0">
  
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td<div align="center"><img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzNTM2OTMxNzk4NTkmcHQ9MTM1MzY5MzIxMTQyMCZwPTUzMTUxJmQ9Jmc9MSZvPTZmYzA1ZDM4N2EyZjQ*NDc4OGE2/NzE1NjMwNjQ4OTVk.gif" /><img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzNjkwODk5NDU*NTUmcHQ9MTM2OTA4OTk*ODA3MCZwPTUzMTUxJmQ9Jmc9MSZvPTRhMjZkMTQxZTY1NTRmMDFhYmI5/M2Q5NGNjMzAzZDVl.gif" /><embed wmode="transparent" src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="630" height="500" name="chat" FlashVars="id=195758516&rl=Portuguese" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.php" /><br><small><a target="_BLANK" href="http://xat.com/web_gear/?cb"></a> <a target="_BLANK" href="http://xat.com/web_gear/chat/go_large.php?id=195758516"></a></small><br>

</div></td>
  </tr>
</table>
                	    <table width="600" border="0">
                          <tr>
                            <td>&nbsp;</td>
                          </tr>
                        </table>
                	    <table width="600" border="1" bordercolor="#999999">
                          
                          <tr>
                            <td width="186">Voc&ecirc; est&aacute; logado na conta: </td>
                            <td width="404"><?=$_SESSION['UserID']?></td>
                          </tr>
                          <tr>
                            <td>Voc&ecirc; est&aacute; logado na data: </td>
                            <td><script language="JavaScript">
hoje = new Date()
dia = hoje.getDate()
dias = hoje.getDay()
mes = hoje.getMonth()
ano = hoje.getYear()
if (dia < 10)
dia = "0" + dia
if (ano < 2000)
ano = 1900 + ano
function NArray (n) 
{
this.length = n
}
NomeDiaWMOnline = new NArray(7)
NomeDiaWMOnline[0] = "Domingo"
NomeDiaWMOnline[1] = "Segunda-feira"
NomeDiaWMOnline[2] = "Ter�a-feira"
NomeDiaWMOnline[3] = "Quarta-feira"
NomeDiaWMOnline[4] = "Quinta-feira"
NomeDiaWMOnline[5] = "Sexta-feira"
NomeDiaWMOnline[6] = "S�bado"
NomeMesWMOnline = new NArray(12)
NomeMesWMOnline[0] = "janeiro"
NomeMesWMOnline[1] = "fevereiro"
NomeMesWMOnline[2] = "mar�o"
NomeMesWMOnline[3] = "abril"
NomeMesWMOnline[4] = "maio"
NomeMesWMOnline[5] = "junho"
NomeMesWMOnline[6] = "julho"
NomeMesWMOnline[7] = "agosto"
NomeMesWMOnline[8] = "setembro"
NomeMesWMOnline[9] = "outubro"
NomeMesWMOnline[10] = "novembro"
NomeMesWMOnline[11] = "dezembro"
document.write (NomeDiaWMOnline[dias] + ", " + dia + " de " + NomeMesWMOnline[mes] + " de " + ano)
</script>&nbsp;</td>
                          </tr>
                          <tr>
                            <td>Sua identifica&ccedil;&atilde;o pessoal &eacute;: </td>
                            <td><script type="text/javascript" src="http://www.whatsmyip.us/showipsimple.php"></span></script>&nbsp;</td>
                          </tr>
                        </table>
                	</center>
<p>&nbsp;</p>
 </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>