<div class="inside">
                <table width="200" border="0">
  <tr>
    <td><div id="content">
                <div class="content-outline content-top">
                  <div class="title">Noticias e Atualiza&ccedil;&oacute;es</div>
                </div>
        		<div class="content-outline content-cont">
                                                    <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="525" height="151">
                                                      <tr>
                                                        <td width="261" height="24">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Noticias</td>
                                                        <td width="10" height="24">&nbsp;</td>
                                                        <td width="231" height="24">Atualiza&ccedil;&oacute;es</td>
                                                      </tr>
                                                      <tr>
                                                        <td width="261" valign="top"><table border="0" style="border-collapse: collapse" width="261" height="92%">
                                                            <tr>
                                                              <td width="3">&nbsp;</td>
                                                              <td width="248" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"><font size="1" face="Verdana"></font></span><font face="Verdana" size="1"><font color="#FFFFFF"> <a href="index.php?plus=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=$n['Title']?>
                                                                    </a></font></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                        <td width="10">&nbsp;</td>
                                                        <td width="231" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                                            <tr>
                                                              <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                  <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                                  <tr>
                                                                    <td height="20"><span class="menu"> <span class="style10"> <font size="1" face="Verdana">&raquo;</font></span> <a href="index.php?plus=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                                      <?=$n['Title']?>
                                                                    </font></a></span></td>
                                                                  </tr>
                                                                  <?}?>
                                                              </table></td>
                                                            </tr>
                                                        </table></td>
                                                      </tr>
                                                    </table>
                </div>
                <div class="content-outline content-end"></div>
                </div></td>
  </tr>
</table>
                <table width="200" border="0">
  <tr>
<link href="http://hostarm.com.br/banner/css/banner1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://hostarm.com.br/banner/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://hostarm.com.br/banner/js/banner1.js"></script>
</head>

<body>
<div aling="center"><a href="http://hostarm.com.br/"><img src="images/hostarm.png" width="655" height="120" border="0" /></a></td>




	
    <div id="content">
               
                  <div class="title">Utimos Itens Adicionados</div>
              
        		

<!--ultimos itens-->

<button class="anterior"><--</button>
<button class="proximo">--></button>

<div id="carrousel">

<ul>

	<li><img src="imagens/fotos/01.png" alt="imagem 01" /></li>
	<li><img src="imagens/fotos/02.png" alt="imagem 02" /></li>
	<li><img src="imagens/fotos/03.png" alt="imagem 03" /></li>
	<li><img src="imagens/fotos/04.png" alt="imagem 04" /></li>
	<li><img src="imagens/fotos/05.png" alt="imagem 05" /></li>
</ul>
</div>


                    
                </div>




                <div class="content-outline content-end"></div>
                </div></td>
  </tr>
</table>

                <?
                                                                $res = mssql_query_logged("SELECT TOP 4 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
?></td>
      </tr>
      





	<tr>
        <td><table border="0" style="border-collapse: collapse" width="631" height="100%">
	</tr>





                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										
									  <td width="611"><center>
									    <span class="statusdoserver">Nenhuma Notica Foi Adicionada Ate o exato momento Aguarde...									    </span>
									  </center></td>
									</tr>
                                        <?
                                    }else{
                                    while($n = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										
										<td width="611"><right></td>
										
									</tr>
                                    <?}}?>
								</table>

<iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2FDragonGunZ%3Ffref%3Dts&amp;width=645&amp;height=290&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:645px; height:177px;" allowTransparency="true"></iframe>


                <div id="content">
                
        		
                
                </div>
                </div>