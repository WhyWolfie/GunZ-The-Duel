<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<div class="content-outline content-top">
                  <div class="title">Administradores PG</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><?
include "protects/authafundadores.php";
if($_SESSION['AID'] == 2){
    msgbox("Acesso Negado // Web protect By ZoooD[BR] // ==> Chave de Administrador","index.php");
}
if($_SESSION['UGradeID'] == 254){
    msgbox("Acesso Negado // Web protect By ZoooD[BR] // ==> Chave de Game Master","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Acesso Negado // Web protect By ZoooD[BR] // ==> Chave de Moderador","index.php");
}
if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Account WHERE UGradeID = 255") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 500; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Account where AID not in (select top $max AID from Account order by AID asc) and UGradeID = 255 order by AID asc");
echo "<p>"; 
echo "";
if ($pagenum == 1) { }
else
{
echo " <a href='index.php?do=listagendosstaffwantedgunz&pagenum=1'></a> ";
echo " ";
$previous = $pagenum-1;
echo " <a href='index.php?do=listagendosstaffwantedgunz&pagenum=$previous'></a> ";
}
echo "";
if ($pagenum == $last)
{
}
else {
$next = $pagenum+1;
echo " <a href='index.php?do=listagendosstaffwantedgunz&pagenum=$next'></a> ";
echo " ";
echo " <a href='index.php?do=listagendosstaffwantedgunz&pagenum=$last'></a> ";
}

?>
<center><table width="573" border="1" bordercolor="#00CCFF">
  
  <tr>
    <th width="47" scope="row"><span class="style28"><strong>N</strong></span></th>
     <th width="58" scope="row"><span class="style28"><strong>AID</strong></span></th>
    <td width="106"><span class="style28"><strong>Login</strong></span></td>
    <td width="142"><span class="style28"><strong>Gradua&ccedil;&atilde;o</strong></span></td>
    <td width="148"><span class="style28"><strong>E-Mail</strong></span></td>
</tr>
  <?
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row[0]";?></span></td>
    <td><span class="style28"><?php echo "$row[1]";?></span></td>
    <td><span class="style28"><?php echo "$row[2]";?></span></td>
    <td><span class="style29"><?php echo "$row[6]";?></span></td>
</tr>
  <?
  $i++;
  }
   ?>
  <?
  }
   ?>
</table></center>
<p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div><div>
</body>

</html>