<div class="content-outline content-top">
                  <div class="title"><a href="#">Cl� Emblema DG</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
<style type="text/css">
<!--
.style1 {color: #CCCCCC}
-->
</style>

			<div class="contentBox">
              <ul class="rank">
            	<h2 class="noMargin style1">Colocar Emblema Dragon GunZ</h2><br />

                <table width="612" border="1" align="center" cellpadding="2" cellspacing="5" bgcolor="000" class="hover" style="border: 1px solid #00688B">
<div id="Paginas_Titulo"></br> <div class="noot"
<center><p><h3>Colocar emblema no Clan<h3></p></center>
</div></div>
    <div id="Paginas_Conteudo">
<? 
include ("config.php");
if ($_SESSION['AID'] == ""){
echo "<script type='text/javascript' language='javascript'>
        alert ('Logue-se Primeiro!');
        window.location.href='index.php?do=login';
     </script>";
die(); 
} 

$aid = clean($_SESSION['AID']); 
$proximo = clean($_GET['proximo']); 

if($proximo == "") 
{ 
?> 
<form id="personagem" name="personagem" method="post" action="index.php?plus=emblema&proximo=1"> 
Selecione seu personagem: 
<br> 
<select name="cid" class="text"> 
<? 
$cu = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid' AND DeleteFlag = 0"); 
if (mssql_num_rows($cu) >= '1') 
{ 

while($cu2 = mssql_fetch_row($cu)) 
{ 
    echo '<option value="'.$cu2[0].'">'.$cu2[1].'</option>'; 
} 
?> 
</select> 
<br><br> 
<input type="submit" name="personagem" value="Proximo ->" /> 
</form> 
<? 
}else{ 
echo "<script type='text/javascript' language='javascript'>
        alert ('Voce nao possui personagens');
        window.location.href='index.php?do=index';
     </script>";
die(); 
} 
} 

if($proximo == "1") 
{ 

$CID = clean($_POST['cid']); 


$zika = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$CID'"); 

if (mssql_num_rows($zika) == 0 ) 
        { 
	echo "<script type='text/javascript' language='javascript'>
        alert ('Esse char pertence a outra conta.');
        window.location.href='index.php?plus=emblema';
     </script>";
    die(); 
    } 

$query1 = mssql_query("SELECT CLID FROM ClanMember WHERE CID ='$CID'"); 
$query2 = mssql_fetch_row($query1); 

$query3 = mssql_query("SELECT Name, MasterCID FROM Clan WHERE CLID = '$query2[0]'"); 
$query4 = mssql_fetch_row($query3); 

if($query4[1] == $CID) 
{ 
?> 

<form enctype="multipart/form-data" action="index.php?plus=emblema&proximo=2" method="POST"> 
Selecione o emblema:<br> 
<input name="uploaded" type="file" /> 
<br><br> 
Selecione o Clan:<br> 
<select name="clan"> 
<option value="<?=$query2[0]?>"><?=$query4[0]?></option> 
</select> 
<br><br> 
<p>Voce pode fazer upload de imagens 64x64 ate 60kb.</p>
<input type="submit" value="Enviar" /> 

<? 
}else{
echo "<script type='text/javascript' language='javascript'>
        alert ('Voce nao e lider do seu clan!');
        window.location.href='index.php?plus=emblema';
     </script>";
die(); 
} 
} 

if($proximo == "2") 
{ 

$emblem = clean($_POST['uploaded']); 
$CLID = clean($_POST['clan']); 
if(!is_numeric($CLID)){ 
echo "<script type='text/javascript' language='javascript'>
        alert ('O CLID � invalido.');
        window.location.href='index.php?plus=emblema';
     </script>";
die(); 
} 
$target = "dragon/"; 
$target = $target . basename( $_FILES['uploaded']['name']) ; 
$targetsaaa = clean($target); 
$diretorio = basename( $_FILES['uploaded']['name']) ; 

$partes = pathinfo( $_FILES['uploaded']['name'] ); 
$extensao = $partes['extension']; 

$extensoes = array('jpg', 'jpeg', 'png');

if($_FILES['uploaded']['size']  > "64001")
if($size[0] < 151 || $size[1] < 151 || $size[0] > 19 || $size[1] > 19)
{
echo "<script type='text/javascript' language='javascript'>
        alert ('A imagem e muito larga.');
        window.location.href='index.php?plus=emblema';
     </script>";
die(); 
} 

if( !in_array(strtolower($extensao), $extensoes) ) 
{ 
echo "<script type='text/javascript' language='javascript'>
        alert ('O formato do arquivo nao foi aceito.');
        window.location.href='index.php?plus=emblema';
     </script>";
die(); 
} 

if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target)) 
{ 
echo "<script type='text/javascript' language='javascript'>
        alert ('Seu emblema foi inserido com sucesso.');
        window.location.href='http://www.dragongunz.com/index.php';
     </script>"; 
mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE CLID = '$CLID'"); 
mssql_query("UPDATE Clan SET EmblemUrl = '".clean($diretorio)."' WHERE CLID = '$CLID'"); 
}else{ 
echo "<script type='text/javascript' language='javascript'>
        alert ('Desculpe, ocorreu um problema, tente novamente mais tarde.');
        window.location.href='index.php?plus=emblema';
     </script>"; 
die(); 
} 

} 
?>
</form>
</table>
<p>&nbsp;</p>
  </div></div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>