<?
if ($_GET['expand'] == 1){
?>
<? }





if(!function_exists("ListAllItems")){
function ListAllItems(){
    if(!isset($_GET['type'])){
        $type = "";
    }else{
        $type = "Slot = '".clean($_GET['type'])."' AND";
    }

    $res = mssql_query_logged("SELECT * FROM ShopDGZ WHERE ".$type." Opened = '1'");

    ?>
    <div align="center">
						<div class="content-outline content-top">
                  <div class="title"><a href="#">Shop Donator Dragon GunZ</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="450" height="100%">
										<tr>
											<td width="30">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>

										<tr>
											<td width="449" colspan="2">&nbsp;
											</td>
										</tr>

										<tr>
                                                                                <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 3) {
                                                $count = 1;
                                                echo "
                                                    </tr><tr>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
											        </tr><tr>";
                                                ?>
                                                <td width="208">

											<table border="0" style="border-collapse: collapse" width="102%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="shop/<?=$item['WebImgName']?>" width="100" height="100"><a href="index.php?plus=WGshop&sub=details&id=<?=$item['CSID']?>"><img src="http://hsbcbrasil.com.br/images/botao_comprar.gif" /></td>
													<td width="106" valign="top">
													<font color="#FF00FF"><?=$item['Name']?></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Tipo: <?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Donator";
                                                        break;
                                                        case "2";
                                                        $slot = "Donator";
                                                        break;
                                                        case "3";
                                                        $slot = "Donator";
                                                        break;
                                                        case "4";
                                                        $slot = "Donator";
                                                        break;
                                                        case "5";
                                                        $slot = "Donator";
                                                        break;
                                                        case "6";
                                                        $slot = "Donator";
                                                        break;                                                        case "5";
                                                        case "7";
                                                        $slot = "Donator";
                                                        break;
                                                        case "8";
                                                        $slot = "Donator";
                                                        break;
                                                        case "9";
                                                        $slot = "Donator";
                                                        break;
                                                        case "10";
                                                        $slot = "Donator";
                                                        break;
                                                        case "11";
                                                        $slot = "Donator";
                                                        break;
                                                        case "12";
                                                        $slot = "Donator";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Level: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Valor: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="106">
													<p align="center">
													</td>
												</tr>
												<tr>
													<td width="106">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="106">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>
                                                <?
                                            }else{
                                                ?>
                                                <td width="208">
                                                											<table border="0" style="border-collapse: collapse" width="100%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="shop/<?=$item['WebImgName']?>" width="100" height="100"><a href="index.php?plus=WGshop&sub=details&id=<?=$item['CSID']?>"><img src="http://hsbcbrasil.com.br/images/botao_comprar.gif" /></td>
													<td width="110" valign="top">
													<font color="#FF00FF"><?=$item['Name']?></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Tipo: <?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Donator";
                                                        break;
                                                        case "2";
                                                        $slot = "Donator";
                                                        break;
                                                        case "3";
                                                        $slot = "Donator";
                                                        break;
                                                        case "4";
                                                        $slot = "Donator";
                                                        break;
                                                        case "5";
                                                        $slot = "Donator";
                                                        break;
                                                        case "6";
                                                        $slot = "Donator";
                                                        break;
                                                        case "7";
                                                        $slot = "Donator";
                                                        break;
                                                        case "8";
                                                        $slot = "Donator";
                                                        break;
                                                        case "9";
                                                        $slot = "Donator";
                                                        break;
                                                        case "10";
                                                        $slot = "Donator";
                                                        break;
                                                        case "11";
                                                        $slot = "Donator";
                                                        break;
                                                        case "12";
                                                        $slot = "Donator";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Level: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Valor: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="110">
													<p align="center">
													</td>
												</tr>
												<tr>
													<td width="110">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="110">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>                                                <?
                                                 $count++;
                                            }
                                        }   ?>
											<td width="30">
											&nbsp;<p>&nbsp;</p>
											<p>&nbsp;</p>
											<p></td>
										</tr>

										<tr>
											<td width="445" colspan="2">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>
										</table>
 <h3>
  <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=1"><font color="#FFFFFF">[1]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=2"><font color="#FFFFFF">[2]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=3"><font color="#FFFFFF">[3]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=4"><font color="#FFFFFF">[4]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=5"><font color="#FFFFFF">[5]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=6"><font color="#FFFFFF">[6]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=7"><font color="#FFFFFF">[7]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=8"><font color="#FFFFFF">[8]</font></a> 
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=9"><font color="#FFFFFF">[9]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=10"><font color="#FFFFFF">[10]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=11"><font color="#FFFFFF">[11]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=12"><font color="#FFFFFF">[12]</font></a><br><br>
  <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=13"><font color="#FFFFFF">[13]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=14"><font color="#FFFFFF">[14]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=15"><font color="#FFFFFF">[15]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=16"><font color="#FFFFFF">[16]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=17"><font color="#FFFFFF">[17]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=18"><font color="#FFFFFF">[18]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=19"><font color="#FFFFFF">[19]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=20"><font color="#FFFFFF">[20]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=21"><font color="#FFFFFF">[21]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=22"><font color="#FFFFFF">[22]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=23"><font color="#FFFFFF">[23]</font></a><br><br>
 <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=24"><font color="#FFFFFF">[24]</font></a>
- <a href="index.php?plus=WGshop&sub=listallitems&expand=1&type=25"><font color="#FFFFFF">[25]</font></a>
</h>



								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div>
    <?
    }  }



//Items details




if(!function_exists("ShowItemsDetails")){
    function ShowItemsDetails(){
    if($_GET['id'] == ""){
        re_dir("index.php");
    }
    $itemid = clean($_GET['id']);
    $res = mssql_query_logged("SELECT * FROM ShopDGZ WHERE CSID = '$itemid'");
    $item = mssql_fetch_assoc($res);
    ?>
    					<div align="center"><div class="content-outline content-top">
                  <div class="title"><a href="#">Aquisicao de iten Donator (stage 1)</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="429">
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>

										<tr>
											<td width="438">
											<table border="0" style="border-collapse: collapse" width="436" height="100%">
												<tr>
													<td width="122" valign="top">
													<table border="0" style="border-collapse: collapse" width="122">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">&nbsp;</td>
															<td width="14">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">
															<img border="2" src="shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
															<td width="14">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">&nbsp;</td>
															<td width="14">&nbsp;</td>
														</tr>
													</table>
													</td>
													<td width="310" valign="top">
													<table border="0" style="border-collapse: collapse" width="310" height="100%">
														<tr>
															<td height="15" width="308" colspan="2">
															</td>
														</tr>
														<tr>
															<td height="15" width="308" colspan="2">
												<!-- //left item picture -->
												<!-- right item info box -->
															<div class="item_name">
																<b>
																<span class="item_name">
																<font color="#FF00FF"><?=$item['Name']?></fonts></span></b>
                                                                                                                                <br><font color="#FFFFFF"><?=$item['Description']?></fonts>
															</td>
														</tr>
														<tr>
															<td width="55" height="15">
															</td>
															<td width="251" height="15">
															</td>
														</tr>
														<tr>
															<td width="55"><b>Tipo:</b></td>
															<td width="251"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Donator";
                                                        break;
                                                        case "2";
                                                        $slot = "Donator";
                                                        break;
                                                        case "3";
                                                        $slot = "Donator";
                                                        break;
                                                        case "4";
                                                        $slot = "Donator";
                                                        break;
                                                        case "5";
                                                        $slot = "Donator";
                                                        break;
                                                        case "6";
                                                        $slot = "Donator";
                                                        break;
                                                        case "7";
                                                        $slot = "Donator";
                                                        break;
                                                        case "8";
                                                        $slot = "Donator";
                                                        break;
                                                        case "9";
                                                        $slot = "Donator";
                                                        break;
                                                        case "10";
                                                        $slot = "Donator";
                                                        break;
                                                        case "11";
                                                        $slot = "Donator";
                                                        break;                                                        case "5";
                                                        case "12";
                                                        $slot = "Donator";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
														</tr>
														<tr>
															<td width="55"><b>Sexo:</b></td>
															<td width="251">
                                                            <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
														</tr>
														<tr>
															<td width="55"><b>Level:</b></td>
															<td width="251"><?=$item['ResLevel']?></td>
														</tr>
														<tr>
															<td width="55">
															<b>Weight:</b></td>
															<td width="251"><?=$item['Weight']?></td>
														</tr>
														<tr>
															<td width="55"><b>Valor:</b></td>
															<td width="251"><?=$item['CashPrice']?></td>
														</tr>
														<tr>
															<td width="55">&nbsp;</td>
															<td width="251">&nbsp;</td>
														</tr>
													</table>
													</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">
													<div align="center">
														<table border="0" style="border-collapse: collapse; background-image: url('images/iteminfo.jpg'); background-repeat: no-repeat; background-position: center top" width="422" height="110">
															<tr>
																<td>
																<table border="0" style="border-collapse: collapse" width="420" height="100%">
																	<tr>
																		<td width="130" height="27" colspan="4">&nbsp;</td>
																		<td width="146" height="27" colspan="3">&nbsp;</td>
																		<td width="128" height="27" colspan="3">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>
																		Damage</b></td>
																		<td width="44" align="right">
																		<?=$item['Damage']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>HP</b></td>
																		<td width="48" align="right">
																		<?=$item['HP']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>FR</b></td>
																		<td width="62" align="right">
																		<?=$item['FR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>Delay</b></td>
																		<td width="44" align="right">
																		<?=$item['Delay']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>AP</b></td>
																		<td width="48" align="right">
																		<?=$item['AP']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>PR</b></td>
																		<td width="62" align="right">
																		<?=$item['PR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>
																		Magazine</b></td>
																		<td width="44" align="right">
																		<?=$item['Magazine']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>Max
																		Weight</b></td>
																		<td width="48" align="right">
																		<?=$item['MaxWeight']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>CR</b></td>
																		<td width="62" align="right">
																		<?=$item['CR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>Reload
																		Time</b></td>
																		<td width="44" align="right">
																		<?=$item['ReloadTime']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>
																		Control</b></td>
																		<td width="48" align="right">
																		<?=$item['Control']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>LR</b></td>
																		<td width="62" align="right">
																		<?=$item['LR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="4">&nbsp;</td>
																		<td width="88">
																		<b>Max
																		Bullet</b></td>
																		<td width="44" align="right">
																		<?=$item['MaxBullet']?></td>
																		<td width="7" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="75">
																		<b>
																		Duration</b></td>
																		<td width="48" align="right">
																		Unlimited</td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">&nbsp;</td>
																		<td width="62">&nbsp;</td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">&nbsp;</td>
																		<td width="51" colspan="2">&nbsp;</td>
																		<td width="88">&nbsp;</td>
																		<td width="54" colspan="2">&nbsp;</td>
																		<td width="67">&nbsp;</td>
																		<td width="68" colspan="2">&nbsp;</td>
																	</tr>
																</table>
																</td>
															</tr>
														</table>
													
													</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">&nbsp;</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">
													<p align="center">
													<a href="index.php?plus=WGshop&sub=buyitem&expand=1&itemid=<?=$item['CSID']?>">
													<img src="http://hsbcbrasil.com.br/images/botao_comprar.gif" />
</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">&nbsp;</td>
												</tr>
											</table>
											</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>
										</table>
								
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table><p>&nbsp;</p>
  </div></div>
                
                <div class="content-outline content-end"></div>
                </div>
					
    <?

}   }


if(!function_exists("ShowBuyItem")){
    function ShowBuyItem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM ShopDGZ WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
       if(isset($_POST['submit'])){
            $itemid = clean($_POST['ItemID']);
            $res = mssql_query_logged("SELECT * FROM ShopDGZ WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['RZCoins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("");
            }
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$aid', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET RZCoins = '$updatecoins' WHERE AID = '$aid'");
            msgbox("Item Enviado para seu banco","index.php?plus=WGshop&sub=listallitems&expand=1&type=1");
       }
       ?>
       					<div align="center"><div class="content-outline content-top">
                  <div class="title"><a href="#">Aquisicao de iten Donator (stage 2)</a></div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">
						<table border="0" width="495" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="490" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="470"><font color="#FF0000"><b>
										  Ultimo Stage:<font color="#2F4F4F"> Clicando em comprar voce concorda que nao ira tentar revogar seus creditos.</b></font>
											<td width="10">&nbsp;</td>
										</tr>

										<tr>
											<td width="470"></td>
										</tr>

										<tr>
											<td width="470">
											<table border="0" style="border-collapse: collapse" width="436" height="100%">
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Nome do 
													item</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['Name']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Login do  
													Usuario</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$_SESSION['UserID']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Valor do Item</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['CashPrice']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">DG Coins 
													que possui</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$acc['RZCoins']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">DG Coins 
													que ira sobrar</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?
                                                    $result = $acc['RZCoins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "<b>DG Coins Insuficiente!</b>";
                                                    }else{
                                                        $boton = "<input type='submit' value='  Adquirir item  ' name='submit'>";
                                                    }

                                                        echo $acc['RZCoins']-$item['CashPrice'];?> </b></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													</td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<form method="POST" action="index.php?plus=WGshop&sub=buyitem">
														<p align="center">    
														<?=$boton?>
														<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
														</p>
													</form>
													</td>
												</tr>
											</table>
										  </td>
										</tr>

										<tr>
											<td width="470"></td>
										</tr>
								  </table>
								
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
					  </table><p>&nbsp;</p>
  </div>
                
                <div class="content-outline content-end"></div>
                </div><div>
					


</div>
</div>



<?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "listallitems";
        ListAllItems();
    break;
    case "details";
        ShowItemsDetails();
    break;
    case "buyitem";
        ShowBuyItem();
    break;
}
}





?>