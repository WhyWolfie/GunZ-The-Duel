<? include 'Protects/anti_sql.php'; ?>
<? include 'Protects/inject.php'; ?>
<? include 'Protects/criminalteam.php'; ?>
<?
if($_SESSION['AID'] == ""){
    msgbox("Por favor Logue Primeiro.","index.php");
exit();
}else{
if(isset($_POST['submit'])){
        $ClanName = antisql($_POST['ClanName']);
        $DelCLan = antisql($_POST['DelCLan']);
    $query1 = mssql_query("SELECT * FROM ClanMember WHERE CLID = '$ClanName'");
        $result1 = mssql_fetch_assoc($query1);
        $query2 = mssql_query("SELECT * FROM Clan WHERE CLID = '$ClanName' AND Name != NULL");
        $result2 = mssql_fetch_assoc($query2);
            if( $result1['Grade'] != 1 ){
            msgbox("Voc� n�o � o dono.","index.php?plus=deletar");
                exit();
                }
                else
                {
    if ($DelCLan != 'SIM') {
msgbox("Wrong Input","index.php?plus=deletar"); 
              }else{
mssql_query("DELETE FROM ClanMember WHERE CLID = '$ClanName'");
mssql_query("DELETE FROM Clan WHERE CLID= '$ClanName'");
msgbox("Clan Deletado.","index.php?plus=deletar");                
            }}}
                }
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="image/style.css">
</head>

        <body bgcolor="#000000">

                                        <div align="center">
                                                <table border="0" width="456" style="border-collapse: collapse">
                                                        <tr>
                                                                <td background="image/cont_up.jpg">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                                <td background="image/cont_bg.jpg">
                                                                <div align="center">
                                                                        <form method="POST" action="index.php?plus=deletar"><table border="0" style="border-collapse: collapse" width="454" height="100%">
                                                                                <tr>
                                                                                        <td width="1" rowspan="10">&nbsp;</td>
                                                                                        <td colspan="3">
                                                                                        </td>
                                                                                        <td width="4">&nbsp;</td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3">&nbsp;                                                                                        </td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204">
                                                                                          <p align="right">
                                              <font color="#FFFFFF">Nome do Clan</font></td>
                                                                                        <td width="5"><font color="#FFFFFF">&nbsp;
                                            </font>                                                                                        </td>
                                                                                        <td width="218">
                                            <font color="#FFFFFF"><select name="ClanName">
    <?php
     $res9 = mssql_query("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
        $a=mssql_fetch_assoc($res9);
        $res = mssql_query("SELECT * FROM Character WHERE AID = '".$_SESSION['AID']."'");
        $d=mssql_fetch_assoc($res);
        $res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$d['CID']."'");
$query5 = mssql_query("SELECT Login.AID, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.AID = '".$_SESSION['AID']."' and ClanMember.Grade = '1' ");
if (mssql_num_rows($query5) >= '1'){
    for($i='';$i < @mssql_num_rows($query5);++$i){
                            $result5 = @mssql_fetch_row($query5);
                            $ClanName = $result5[4];
                            echo '<option value="'.$result5[4].'">'.$result5[3].'</option>' ;
                            }
}else{
                                echo '<option value="">Sem Clans</option>' ;
                            }
    ?>
</select></font></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204" align="right" valign="top">
                                            <font color="#FFFFFF">Escreva SIM para Continuar</font></td>
                                                                                        <td width="5">&nbsp;</td>
                                                                                  <td width="218"><font color="#FFFFFF"><input name="DelCLan" type="text" id="DelCLan" size="20"></font></td>
                                                                                </tr>
                                                                                                                                                                               <tr>
                                                                                                        <td width="200" valign="top">&nbsp;</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">&nbsp;</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td colspan="3"><p align="center"><font color="#FF0000"><b><center></b></center></font></td>
                                                                                                </tr>
                                                                                        <tr>
                                                                                                <td colspan="3">
                                                                                                <p align="center">
                                                                                                <font color="#FFFFFF">
                                                                                                <input type="submit" value="Deletar Clan" name="submit"></font></td>
                                                                                        </tr>
                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>
                                                                                </table>
                                                                        </form>
                                                                </div>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td background="image/cont_top.jpg" height="27">&nbsp;</td>
                                                        </tr>
                                                </table>
                                        </div>