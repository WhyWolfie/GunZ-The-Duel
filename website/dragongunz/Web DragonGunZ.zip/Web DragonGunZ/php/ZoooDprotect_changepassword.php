<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
	font-style: italic;
	color: #999999;
}
-->
</style>
<div align="center">
<br>
<table width="500" border="0" cellspacing="1" bordercolor="#666666">
  <tr>
    <td>
	<div class="content-outline content-top">
                  <div class="title">Altera&ccedil;&atilde;o de Senha DG</a></div>
        </div><div class="content-outline content-cont">
                	<div class="content-inside"><?php
if ($_POST['changepassword']){
echo '<div class="errmessage">';
$oldpassword = sql($_POST['oldpassword']);
$newpassword = sql($_POST['newpassword']);
$repeatnewpassword = sql($_POST['repeatnewpassword']);

$select_pass = mssql_query("SELECT Password FROM Login WHERE UserID='".$_SESSION['UserID']."'");
$row_pass = mssql_fetch_assoc($select_pass);
$old_pass = $row_pass['Password'];

if($oldpassword&&$newpassword&&$repeatnewpassword){
  if($oldpassword==$old_pass){
    if($newpassword==$repeatnewpassword){
	
	  $change_pass = mssql_query("UPDATE Login SET Password='$newpassword' WHERE UserID='".$_SESSION['UserID']."'");
      $msg = "Senha alterada com sucesso."; alert($msg);
	  session_destroy();
      redirect("index.php");
	  
	}else{
     echo "New passwords doesnt match!";
	}
  }else{
    echo "Old password isnt correct!";
  }
}else{
   echo "Please fill all fields!";
}

}
echo '</div>';
?>
<form action="index.php?plus=changepassword" method='post'>
<table width="362" align="center">
 <tr><td><b>  --> Senha atual :</b></td><td>   <input type="password" name="oldpassword" /></td></tr>
 <tr><td><b>  --> Nova senha :</b></td><td>   <input type="password" name="newpassword" /></td></tr>
 <tr><td><b>  --> Repetir nova senha :</b></td><td>   <input type="password" name="repeatnewpassword" /></td></tr>
 <tr><td></td><td><input type="submit" name="changepassword" value="Confirmar Altera&ccedil;&atilde;o" /></td></tr>
</table>
</form></td>
  </tr>
</table>

</div>
                <div class="content-outline content-end"></div>
                </div><div>
