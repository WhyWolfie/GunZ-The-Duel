<?

if( $_SESSION['AID'] == "" )
{
msgBox("Area Restrita apenas para usuarios, se vc ja � um membro DG efetue o login, se n�o �, nao perca tempo e cadastre-se j�!","index.php");
    die();
}

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php");
}
?>
<div class="content-outline content-top">
                  <div class="title">Fazer uma doa��o para o (DRAGONGUNZ)</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside">

<div align="center"><br> 

<table width="355" border="1"><p><strong class="style1">( RECOMENDADO ) COMPRE VIA DEP�SITO CAIXA ELETRONICA ( LOT�RICA )</strong></p><br>

<div align="center"><h3>Banco: Caixa Econ�mica Federal</div></h><br>
<div align="center"><h3>Tipo da Conta: Poupan�a</div></h><br>
<div align="center"><h3>Conta: 10685-0</div></h><br>
<div align="center"><h3>Agencia: 3132<div></h><br>
<div align="center"><h3>OP: 013</div></h><br>
<div align="center"><h3>Favorecido: Tiago Magre Gomes</div></h><br>
<table width="355" border="3">

<br>

<br><br>
<p><strong class="style1">COMPRE VIA PAG SEGURO.</strong></p><br>


<tr>
<td><div align="center">100 DG + 5 VIP + 20 EV </div></td>
<td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="4BB228B40D0D6BAEE417BF90A4D2F47B" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>


<tr>
<td><div align="center">250 DG + 15 VIP + 40 EV </div></td>
<td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="DA3521605E5EF11BB49D4FB3B2D5EF73" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
</tr>


<tr>
<td><div align="center">400 DG + 35 VIP + 60 EV </div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="0EBF4E556F6FEBF66445FF8992B5A911" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
</div></td>
</tr>


<tr>
<td><div align="center">600 DG + 70 VIP + 80 EV </div></td>
<td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="DEDA6910E4E4D04884B8EFB56913E426" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
</div></td>
</tr>


<tr>
<td><div align="center">700 DG + 100 VIP + 100 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="DF5E8B01969651CCC4912FB822D56755" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


<tr>
<td><div align="center">800 DG + 110 VIP + 130 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="A2606C0DE1E12FFBB465AFA565CCCEB2" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


<tr>
<td><div align="center">1000 DG + 120 VIP + 150 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="F8385C6C7C7C980334A24FBA40B4808F" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


<tr>
<td><div align="center">1300 DG + 140 VIP + 200 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="78B0BD4B37379F6334747F9C2E073F11" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


<tr>
<td><div align="center">1400 DG + 170 VIP + 250 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="7B5BC9595C5C095334561F9A13BF9D5F" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


<tr>
<td><div align="center">1500 DG + 200 VIP + 300 EV</div></td>
<td><div align="center"><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/checkout/v2/payment.html" method="post">
<input type="hidden" name="code" value="5522FDF12A2ABD833434EFAB91B5DCA6" />
<input type="image" src="https://p.simg.uol.com.br/out/pagseguro/i/botoes/pagamentos/160x20-comprar-preto.gif" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></div></td>
</tr>


</tr>
</table></div>


</p>
<p>&nbsp;</p>
  </div>
                </div>
                <div class="content-outline content-end"></div>
                </div><div>