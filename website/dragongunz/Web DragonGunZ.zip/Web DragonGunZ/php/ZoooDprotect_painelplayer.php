<style type="text/css">
<!--
.style1 {color: #009999}
a:link {
	color: #666666;
	font-style: italic;
}
a:visited {
	color: #666666;
}
a:hover {
	color: #666666;
}
a:active {
	color: #666666;
}
-->
</style>
<div class="content-outline content-top">
                  <div class="title">Painel Do Player [DragonGunZ]</div>
                </div><div class="content-outline content-cont">
                	<div class="content-inside"><center>
  
  <tr>
    <td width="127"><h2><div align="center" class="style1">Minha Conta </div></td><br> </h3>

    <td><div align="center"><a href="index.php?plus=minhaconta">Status Da Conta </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=changepassword">Alterar Senha </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=Pagamento">Confirmar Pagamento</a> </div></td><br><br>

    

    <td width="127"><h2><div align="center" class="style1">Personagens</div></td><br> </h3>

    <td><div align="center"><a href="index.php?plus=nick">Alterar Nick </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=namecolor">Name Color </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=Trocar">Trocar Pts de CW</a> </div></td><br><br>



    <td width="127"><h2><div align="center" class="style1">Clans</div></td><br> </h3>

    <td><div align="center"><a href="index.php?plus=cria">Cria Cl�n </a></div></td><br>
    <td><div align="center"><a href="index.php?plus=resetar">Resetar Clan</a> </div></td><br>
    <td><div align="center"><a href="index.php?plus=deletar">Deletar Cl�n </a></div></td> <br>
    <td><div align="center"><a href="index.php?plus=emblema">Cl� Emblema</a></div></td><br>    
    <td><div align="center"><a href="index.php?plus=UCW">Ultimas CW </a></div></td><br>
   
  </tr>
 
</table>

					</div>
                </div>
                <div class="content-outline content-end"></div><br>
				<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252 and !$_SESSION['AID'] == ""){include"php/ZoooDprotect_painelstaff_PG.php";echo "</br>";} ?>
                