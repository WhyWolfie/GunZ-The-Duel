<?php
include "configuracao/config.php";
include "protects/functions.php";
include "Configuracao/_functions.php";
include "Protects/banned.php";
include "Protects/banneduser.php";
include "php/title.php";
include 'php/sqlcheck.php';
include 'php/sql_check.php';
include 'Protects/anti_sql.php';
include 'Protects/antisql.php';
include 'Protects/antisql1.php';
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
include 'Protects/GeovaneSouza.php';
include '1.php';
include '2.php';
eval(base64_decode($protect_criminal_team)); 
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("php/ZoooDprotect_" . $_GET['plus'] . ".php")) {
        include "php/ZoooDprotect_" . $_GET['plus'] . ".php";
	}
} }
// Prote��o Extra Sparrow//
$ip_logado = $_SERVER['REMOTE_ADDR'];
$arquivo = fopen("Protects/Sparrow/Sparrow.htm", "a+");
$escrever = fwrite($arquivo, "==========================<br>");
$escrever = fwrite($arquivo, "Login : $login_logado<br>");
$escrever = fwrite($arquivo, "IP : $ip_logado<br>");
$escrever = fwrite($arquivo, "Data : $data_logado<br>");
$escrever = fwrite($arquivo, "Hora : $hora_logado<br>");
$escrever = fwrite($arquivo, "==========================<br>");
fclose($arquivo);//
// Fim de Prote��o Extra Sparrow//
?>


<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>Dragon Gunz - A Evolu&ccedil;&atilde;o est&aacute; aqui!</title>
    
    <!--Meta-->
    <meta name="owner" content="DragonGunz.com" />
    <meta name="classification" content="Online Games" />
    <meta name="distribution" content="Global" />
    <meta name="language" content="en-GB" />
    <meta name="Rating" content="General" />
    <meta name="publisher" content="segagfx@aol.com" />
    <meta name="copyright" content="Copyright Dragon GunZ 2012" />
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.gif" />
    <link rel="icon" type="image/gif" href="favicon.gif" />
    <div style="color:#F00" align="center"><h5><tr>
    <td width="202">Servidor:</td>
    <td width="204"><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = '';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #FF00FF'><B>OFFILINE</B></font><br />";
        }
        else
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'><B></B></font> $name <font style='color: #228B22'><B>ONLINE</B></font><br />";
            fclose($fp);
        }
    }
    ?></td>
  </tr><tr>
    <td>Players Online:</td>
    <td>. <?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong><font style='color: #00FFFF'>$servercount</font>";
    ?></td>
  </tr></h5></div>
    
    <div align="center"><img src="http://3.bp.blogspot.com/-_VWuY905Djs/TrxBD-rR2vI/AAAAAAAAFDg/rpBN9D1aGIU/s1600/manuten%25C3%25A7%25C3%25A3o1.jpg"/></div>