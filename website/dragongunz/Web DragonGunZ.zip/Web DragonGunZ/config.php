<?php
mssql_connect("HOSTARM-106TIA\SQLEXPRESS","sa","Glaizan255");
mssql_select_db("DragonGunz");
$opened = 1;
if($opened == 0){
    $pagetitle = "Dragon Gunz";
}
?>
