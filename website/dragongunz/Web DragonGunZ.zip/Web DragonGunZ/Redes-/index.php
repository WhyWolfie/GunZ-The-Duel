﻿<?php
include "configuracao/config.php";
include "protects/functions.php";
include "Configuracao/_functions.php";
include "Protects/banned.php";
include "Protects/banneduser.php";
include "php/title.php";
include 'php/sqlcheck.php';
include 'php/sql_check.php';
include 'Protects/anti_sql.php';
include 'Protects/antisql.php';
include 'Protects/antisql1.php';
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
include 'Protects/GeovaneSouza.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("php/ZoooDprotect_" . $_GET['plus'] . ".php")) {
        include "php/ZoooDprotect_" . $_GET['plus'] . ".php";
	}
} }
// Proteção Extra Sparrow//
$ip_logado = $_SERVER['REMOTE_ADDR'];
$arquivo = fopen("Protects/Sparrow/Sparrow.htm", "a+");
$escrever = fwrite($arquivo, "==========================<br>");
$escrever = fwrite($arquivo, "Login : $login_logado<br>");
$escrever = fwrite($arquivo, "IP : $ip_logado<br>");
$escrever = fwrite($arquivo, "Data : $data_logado<br>");
$escrever = fwrite($arquivo, "Hora : $hora_logado<br>");
$escrever = fwrite($arquivo, "==========================<br>");
fclose($arquivo);//
// Fim de Proteção Extra Sparrow//
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- Website coded and designed by Antonio Robles //-->
<!-- segagfx@gmail.com //-->
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>PlusGunZ - A Evolu&ccedil;&atilde;o est&aacute; aqui!</title>
    
    <!--Meta-->
    <meta name="owner" content="DarkGunZ.come" />
    <meta name="classification" content="Online Games" />
    <meta name="distribution" content="Global" />
    <meta name="language" content="en-GB" />
    <meta name="Rating" content="General" />
    <meta name="publisher" content="segagfx@aol.com" />
    <meta name="copyright" content="Copyright DarkGunZ.net 2010 " />
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.gif" />
    <link rel="icon" type="image/gif" href="favicon.gif" />
    
    <!-- CSS -->    
    <link href="style.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
a:link {
	color: #CCCCCC;
}
a:visited {
	color: #CCCCCC;
}
a:hover {
	color: #CCCCCC;
}
a:active {
	color: #CCCCCC;
}
.style1 {
	color: #FFFEA9;
	font-weight: bold;
	font-style: italic;
}
-->
    </style>
</head>

<body>
<div id="wrapper">
<div id="header">
    	<div id="logo">          <img src="images/Logoo.png" alt="DarkgunZLogo" width="338" height="54" title="Plus GunZ, in game network" />        </div>
  </div>
    
<div id="navibar">
           <ul>
           		<li><a href="index" class="active">Home</a></li>
                <li><a href="http://www.orkut.com.br/Main#Community?cmm=122033110">Comunidade</a></li>
                <li><a href="index.php?plus=register">Register</a></li>
                <li><a href="index.php?plus=download">Download</a></li>
                <li><a href="index.php?plus=donate">Donate</a></li>
                <li><a href="index.php?plus=rankings">Rankings</a></li>
                <li><a href="index.php?plus=itenshop">Item Shop</a></li>
                <li><a href="index.php?plus=serverinfo">Server Info</a></li>
                <li><a href="index.php?plus=equipe">Equipe</a></li>
           </ul>
  </div>
        <div id="sidebar">
        <a href="index.php?plus=download"><img src="images/download.jpg" alt="download" title="Download Now"/></a>
        <div id="sidecont">
        <div class="side-outline side-top">
          <p>Login Para Usuarios PG </p>
        </div>
        <div class="side-outline side-cont">
          <table width="228" border="0">
  <tr>
    <td width="232"><div align="center">
      <? include "php/ZoooDprotect_ilogin.php";?>
    </div></td>
  </tr>
</table>

        </div>
        <div class="side-outline side-end"></div>
        </div>
        <div id="sidecont">
        <div class="side-outline side-top">
          <p>Player Ranking</p>
        </div>
        <div class="side-outline side-cont"><?
$res = mssql_query_logged("SELECT TOP 10 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<br /><table border="0" style="border-collapse: collapse" width="235" id="table4">
							
								<tr><td>
								<table border="0" style="border-collapse: collapse" width="223" height="100%">
									<tr>
									  <td width="64">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P</td>
										<td width="93">Nome</td>
									  <td width="52">&nbsp;&nbsp;NV</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="64">&nbsp;</td>
										<td width="93"><center>Nemhum Player.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									    <tr>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
									      <td>&nbsp;</td>
							      </tr>
								    <tr>
<td width="64">
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?=++$count ?>    </td>
									  
<td width="93">
  <?=$clan['Name']?>&nbsp;  </td>

<td width="52">
		    
	        &nbsp;&nbsp;<?=$clan['Level']?>
	        &nbsp;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       </td>
 </tr>
                                    <?}}?>
									<tr>
										<td width="64">&nbsp;</td>
										<td width="93">&nbsp;</td>
										<td width="52">&nbsp;</td>
									</tr>                          
								</table>
								<p align="center"></p>
							  </td>
							</tr>


</table>
<br />
      
        </div>
        <div class="side-outline side-end"></div>
        </div>
        <div id="status">
        <p>Server is: <span>online</span><br /><span><?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp;<strong>$servercount";
    ?> / 500</span> Players</p>
        </div>
        <div id="sidecont">
        <div class="side-outline side-top">
          <p>Doa&ccedil;&atilde;o</p>
        </div>
        <div class="side-outline side-cont">
        <div id="donate">
        <a href="index.php?plus=donate"><img src="images/donate.gif"/></a></div>
        </div>
        <div class="side-outline side-end"></div>
        </div>
  </div>
        <div id="main-cont">
        	<div class="main-top"></div>
            <div class="main-center">
            	<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['plus'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("php/ZoooDprotect_" . $_GET['plus'] . ".php")) {
							    include "php/ZoooDprotect_" . $_GET['plus'] . ".php";
						    }
                        }else{
                            include "php/ZoooDprotect_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
            </div>
            <div class="main-end"></div>
        </div>
        <br clear="all" />
        <div id="footer">
        	<div id="footer-inside">
            	<p>Copyright <a href="#">Plus GunZ </a> 2011-2012. Web Site Codada Por ZoooD[BR] Para o Plus GunZ | Todos Direitor Reservados <span class="style1">Infected Games</span>.</p>
            </div>
        </div>
</div>
</body>
</html>
