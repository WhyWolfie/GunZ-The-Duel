<?php
mssql_connect("64.237.36.106,3389","sa","Glaizan255");
mssql_select_db("DragonGunz");
$opened = 1;
if($opened == 0){
    $pagetitle = "Dragon GunZ";
}
?>
