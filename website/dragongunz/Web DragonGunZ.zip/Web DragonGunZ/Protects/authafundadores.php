<?
if($_SESSION['AID'] == 442 or $_SESSION['AID'] == 4956 or $_SESSION['AID'] == 0 and !$_SESSION['AID'] == ""){
    $userid = $_SESSION['UserID'];
    $aid = $_SESSION['AID'];
    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid' AND AID = '$aid'");
    $data = mssql_fetch_assoc($res);
    if(!$data['AID'] == $_SESSION['AID']){
        echo "Se��o Fundador invalida!";
    }
}else{
    die("Sua Chave de acesso ao painel staff n�o tem autoridade suficiente para acessar esta area!");
}
?>