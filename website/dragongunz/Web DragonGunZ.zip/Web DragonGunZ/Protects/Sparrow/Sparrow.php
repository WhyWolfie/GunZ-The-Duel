<?php 
$ip = $_SERVER['REMOTE_ADDR']; 
$time = date("d/m/Y H:i:s");
$script = $_SERVER[PATH_TRANSLATED]; 
$fp = fopen ("Sparrow/Sparrow.htm", "a+"); 
$sql_inject_1 = array(";","'","%",'"');
$sql_inject_2 = array("", "","","&quot;"); 
$GET_KEY = array_keys($_GET); 
$POST_KEY = array_keys($_POST);
$COOKIE_KEY = array_keys($_COOKIE);
for($i=0;$i<count($GET_KEY);$i++) 
{ 
$real_get[$i] = $_GET[$GET_KEY[$i]]; 
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]])); 
if($real_get[$i] != $_GET[$GET_KEY[$i]]) 
{ 
fwrite ($fp, "==================================<br>"); 
fwrite ($fp, "IP: $ip<br>"); 
fwrite ($fp, "Metodo: GET<br>"); 
fwrite ($fp, "Valor: $real_get[$i]<br>"); 
fwrite ($fp, "Script: $script<br>"); 
fwrite ($fp, "Data e Hora: $time<br>"); 
fwrite ($fp, "==================================<br>"); 
} 
}
for($i=0;$i<count($POST_KEY);$i++) 
{ 
$real_post[$i] = $_POST[$POST_KEY[$i]]; 
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]])); 
if($real_post[$i] != $_POST[$POST_KEY[$i]]) 
{ 
fwrite ($fp, "==================================<br>"); 
fwrite ($fp, "IP: $ip<br>"); 
fwrite ($fp, "Metodo: POST<br>"); 
fwrite ($fp, "Valor: $real_post[$i]<br>"); 
fwrite ($fp, "Script: $script<br>"); 
fwrite ($fp, "Data e Hora: $time<br>"); 
fwrite ($fp, "==================================<br>"); 
} 
} 
for($i=0;$i<count($COOKIE_KEY);$i++) 
{ 
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]]; 
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]])); 
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]]) 
{
fwrite ($fp, "==================================<br>"); 
fwrite ($fp, "IP: $ip<br>"); 
fwrite ($fp, "Metodo: COOKIE<br>"); 
fwrite ($fp, "Valor: $real_cookie[$i]<br>"); 
fwrite ($fp, "Script: $script<br>"); 
fwrite ($fp, "Data e Hora: $time<br>"); 
fwrite ($fp, "==================================<br>"); 
} 
} 
fclose ($fp); 
?>