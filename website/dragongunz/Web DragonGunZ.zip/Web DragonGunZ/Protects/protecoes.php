<?php
include 'Protects/inject.php';
include 'Protects/criminalteam.php';
include 'Protects/anti_sql.php';
include 'Protects/antisql.php';
?>