<?php
$gunzname = "Dragon Gunz";  //Your Server Name

$_MSSQL['Host'] = "HOSTARM-106TIA\SQLEXPRESS";
$_MSSQL['User'] = "sa";
$_MSSQL['Pass'] = "Glaizan255";
$_MSSQL['DB'] = "DragonGunz";

$error1 = "Cant connect to database";
$error2 = "Cant find Database";

$con = mssql_connect($_MSSQL['Host'], $_MSSQL['User'], $_MSSQL['Pass']) or die($error1);
mssql_select_db($_MSSQL['DB']) or die($error2);
?>