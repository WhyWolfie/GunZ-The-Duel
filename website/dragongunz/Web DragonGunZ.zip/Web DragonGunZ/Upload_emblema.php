<?php 
include "config.php";
$erro = $config = array(); 

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE; 

$config["tamanho"] = 106883; 

$config["largura"] = 150; 

$config["altura"]  = 150; 

if ($arquivo) {   
    if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $arquivo["type"])) { 
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; 
    } else { 
        if ($arquivo["size"] > $config["tamanho"]) { 
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo"; 
        } 
         
        $tamanhos = getimagesize($arquivo["tmp_name"]); 
         
        if ($tamanhos[0] > $config["largura"]) { 
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels"; 
        } 

        if ($tamanhos[1] > $config["altura"]) { 
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels"; 
        } 
    } 
     
    if (sizeof($erro)) { 
        foreach ($erro as $err) { 
            echo " - " . $err . "<BR>"; 
        } 
        echo 'Error, nao foi possivel fazer o upload do Emblema.'; 
        echo "<script>javascript:history.back(-1)</script>"; 
    } 

    else 
    { 
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext); 

        $imagem_nome = md5(uniqid(time())) . "." . $ext[1]; 

        $imagem_dir = "Dragon/" . $imagem_nome; // IMPORTANTE DEFINIR A PASTA DA IMAGEM 
		 $CLID = $_POST['clan']; 
        move_uploaded_file($arquivo["tmp_name"], $imagem_dir); 
         
        $query = mssql_query("UPDATE Clan Set EmblemURL='$imagem_dir' WHERE CLID = '$CLID'"); 
        if($query){ 
        echo "Seu emblema foi enviado com sucesso!"; 
        } 

    } 
} 
?>