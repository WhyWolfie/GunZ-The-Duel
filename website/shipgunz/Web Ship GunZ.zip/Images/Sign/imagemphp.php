<?php
include "functions.php";
include "config.php";

    $cid = antisql($_GET['cid']);
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
    $res2 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'");
    $clan = mssql_fetch_assoc($res2);
    $res3 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'");
    $claninfo = mssql_fetch_assoc($res3);
    
    $img = "sign.png";

    if($cid == "")
       $cid = 1;

    if($claninfo == "")
       $claninfo = "-";


// Define o header como sendo de imagem
header("Content-type: image/png");

// Cria a imagem a partir de uma imagem png
$i = imagecreatefrompng($img);

// Definitions
$name = $char['Name']; // Finds Character Name
$level = $char['Level']; // Finds Level
$clan = $claninfo['Name']; // Finds Clan Name
$exp = $char['XP'];
 // Finds Exp 
$kills = $char['KillCount'];
 // Finds Kill Count
$deaths = $char['DeathCount'];
 // Finds Death Count
$preto = imagecolorallocate($i, 0,0,0); // Image Allocation
$color = imagecolorallocate($i, 255,69,0);
// Font Color In RBG
$font = "trebuc.ttf";

// Write the data to the image.
imagettftext($i, 14, 0, 95, 35,$color,$font,$name);
imagettftext($i, 14, 0, 250, 35,$color,$font,$kills);
imagettftext($i, 14, 0, 85, 64,$color,$font,$level);
imagettftext($i, 14, 0, 280, 64,$color,$font,$deaths);
imagettftext($i, 14, 0, 76, 96,$color,$font,$clan);
imagettftext($i, 14, 0, 140, 126,$color,$font,$exp);

// Gera a imagem na tela
imagepng($i);

// Destroi a imagem para liberar mem�ria
imagedestroy($i);

?>
