<?
//Anti SQL injection.
function antisql($sql)
{
// Remove words that contain SQL syntax
$sql = preg_replace(sql_regcase("/(from|update|set|character|clan|account|name|opened|serverstatus|indexcontent|account|level|select|insert|delete|where|drop table|show tables|#|\|*|--|\\\\)/"),"",$sql); //Replaces some parts of a SQL query with absolutely nothing.
$sql = trim($sql); //antisqls up spaces
$sql = strip_tags($sql);//Php and html tags strip
$sql = addslashes($sql);//Adds backslashes to one string
$sql = stripcslashes($sql); //Un-quote string quoted with addcslashes
//$sql = stripslashes($sql); //Un-quotes a quoted string
$sql = htmlspecialchars($sql); //Convert special characters to HTML entities
//$sql = quotemeta($sql); //Quote meta characters
return $sql;
}

date_default_timezone_set('America/Sao_Paulo');

?>