<?
mssql_connect("PC_CASA\SQLEXPRESS","sa","913248");
mssql_select_db("GunzDB");
?>
