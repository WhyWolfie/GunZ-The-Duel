<style type="text/css">
@import "final.css";
</style>
					  <table style="border-collapse: collapse;" id="table4" width="195" border="0">
							<tbody><tr>
								<td width="195" background="images/staff.gif" height="30">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg"><br>

��<a href="index.php?do=charinfo&cid=66"><img  src="images/joker.png" width="80" height="80"> </img>��<a href="index.php?do=charinfo&cid=277"><img src="images/fire.png" width="80" height="80"> </img><br>
 �<b><font color="f28902">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�Joker������<b><font color="f28902">&nbsp;&nbsp;��[+] Fire�
<br>
<br>
��<a href=""><img  src="images/guuh.png" width="80" height="80">�</img>� <a href="index.php?do=charinfo&cid=714"><img src="images/sara.png" width="80" height="80"> </img><br>
 <font color="f28902">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Guuh����<font color="00d8ff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��Sara��
<br>
<br>
��<a href=""><img  src="images/doug.png" width="80" height="80">�</img>� <a href=""><img src="images/hunter.png" width="80" height="80"> </img><br>
 <font color="00d8ff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Doug � ����<font color="00d8ff">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br>
<br>
	</b></b></strong></b><table style="border-collapse: collapse;" width="193" border="0" height="100%">
��<div align="center"><b><font color="RED" > <u><font size="5">STAFF FULL</u></font>
  <div align="center"><b><font color="RED" > Por Favor N�o Inssista! </font>
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>								
                                        </tbody></table>
<strong>								</strong></td>

						</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</tbody></table><br>

<style type="text/css">
@import "final.css";
</style>
					  <table style="border-collapse: collapse;" id="table4" width="195" border="0">
							<tbody><tr>
								<td width="195" background="" height="30">&nbsp;</td>
							</tr>
							<tr>
								<td background="">



	</b></strong></b><table style="border-collapse: collapse;" width="193" border="0" height="100%">
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
                                        </tbody></table>

							</tr>
							<tr>
								<td background="images/" height="22">&nbsp;</td>
							</tr>
</tbody></table>

