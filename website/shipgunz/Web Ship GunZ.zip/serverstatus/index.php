<?php
# ------------------------------------- #
# ------ Server Status 4 Gunz --------- #
# ------------------------------------- #
# Made By     : LegacyCode              #
# ------------------------------------- #
# File        : index.php               #
# Last Edited : 14/Nov/09               #
# ------------------------------------- #

//Includes
include('./config/config.php');
include('./includes/odbc_class.php');
include('./includes/srvstat_class.php');

// Create Database Connection
$odbc = new odbc_class;
$odbc->host = $database['host'];
$odbc->name = $database['name'];
$odbc->user = $database['user'];
$odbc->pass = $database['pass'];
$odbc->driver = $database['driver'];
$dbc = $odbc->odbc_conn();

// Server Status
$srvstat = new srvstat_class;
$srvstat->dbc = $GLOBALS['dbc'];
$srvstat->server_status();
?>