<?php
# ------------------------------------- #
# ------ Server Status 4 Gunz --------- #
# ------------------------------------- #
# Made By     : LegacyCode              #
# ------------------------------------- #
# File        : config.php              #
# Last Edited : 14/oct/09               #
# ------------------------------------- #

#-------------------------------------- #
# --- ODBC Configuration (DataBase) --- #
#-------------------------------------- #
$database['host'] = 'JOKER-7655C630C';
$database['name'] = 'GunZDB';
$database['user'] = 'sa';
$datanase['pass'] = '3124589joker';
$database['driver'] = 'SQL Server';
#-------------------------------------- #
?>