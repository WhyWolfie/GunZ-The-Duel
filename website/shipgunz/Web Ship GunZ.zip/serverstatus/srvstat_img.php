<?php
# ------------------------------------- #
# ------ Server Status 4 Gunz --------- #
# ------------------------------------- #
# Made By     : LegacyCode              #
# ------------------------------------- #
# File        : srvstat_img.php         #
# Last Edited : 14/Nov/09               #
# ------------------------------------- #

// Header
header('Content-type: image/png');

// Create image handle
$img = imagecreatefrompng('./images/default.png');

if($_GET['off'] == 1) {

	// Set string
	$str = 'Offline';
}
else {

	// Calculate procentage
	$proccent = (($_GET['c']/$_GET['m'])*100);

	// Select color and create handle
	switch($proccent) {
		case ($proccent >= 75):
			$barcolor = imagecreatefrompng('./images/red.png');
			break;
		case ($proccent >= 50):
			$barcolor = imagecreatefrompng('./images/yellow.png');
			break;
		case ($proccent < 50):
			$barcolor = imagecreatefrompng('./images/green.png');
			break;
	}	
	
	// Merge images
	imagecopyresized($img,$barcolor,1,0,0,0,$proccent,10,imagesx($barcolor),imagesy($barcolor));
	
	// Set string
	$str = $_GET['c'].'/'.$_GET['m'].'('.$proccent.'%)';
}

// Get image size.
$imgw = imagesx($img);
$imgh = imagesy($img);


// Draw string
$color = imagecolorallocate($img,255,255,255);
imagestring($img,2,round(($imgw/2)-((strlen($str)*imagefontwidth(2))/2),1),round(($imgh/2)-(imagefontheight(2)/2)),$str,$color);

// Create image
imagepng($img);
?>