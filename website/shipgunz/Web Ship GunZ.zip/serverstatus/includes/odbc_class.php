<?php
# ------------------------------------- #
# ------ Server Status 4 Gunz --------- #
# ------------------------------------- #
# Made By     : LegacyCode              #
# ------------------------------------- #
# File        : odbc_class.php          #
# Last Edited : 14/Nov/09               #
# ------------------------------------- #

class odbc_class {
	
	// odbc_class Variables
	private $db;
	var $data;
	
	// Database Connection Function
	function odbc_conn() {
		
		// Grab Database Connection Variables
		$db['host'] = $this->host;
		$db['name'] = $this->name;
		$db['user'] = $this->user;
		$db['pass'] = $this->pass;
		$db['driver'] = $this->driver;
		
		// Create Database Connection
		$data['dbc'] = odbc_connect('Driver={'.$db['driver'].'};Server='.$db['host'].';Database='.$db['name'].';',$db['user'],$db['pass']);
		//odbc_connect($db['name'],$db['user'],$db['pass'],SQL_CUR_USE_ODBC);
		
		// Return Database Connection
		return($data['dbc']);
	}
}
?>