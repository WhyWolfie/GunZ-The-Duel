<?php
# ------------------------------------- #
# ------ Server Status 4 Gunz --------- #
# ------------------------------------- #
# Made By     : LegacyCode              #
# ------------------------------------- #
# File        : srvstat_class.php       #
# Last Edited : 14/Nov/09               #
# ------------------------------------- #

class srvstat_class {

	// srvstat_class Variables
	var $data;
	
	function server_status() {
	
		// Database Connection + Query
		$data['dbc'] = $this->dbc;
		$data['query'] = odbc_exec($data['dbc'],'SELECT ServerName,CurrPlayer,MaxPlayer,Opened FROM ServerStatus');
		
		// Loop Though Data
		while($data['row'] = odbc_fetch_array($data['query'])) {
			
			// Check Server Status
			if($data['row']['Opened'] == 1) {
				
				// Output Data
				echo $data['row']['ServerName'].'<br /><img src="./srvstat_img.php?c='.$data['row']['CurrPlayer'].'&m='.$data['row']['MaxPlayer'].'"/><br>';
			}
			else {
			
				// Output Data
				echo $data['row']['ServerName'].'<br /><img src="./srvstat_img.php?off=1"/><br>';
			}
		}
	}
}

?>