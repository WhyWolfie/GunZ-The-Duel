<?
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
include "night_sejaparceiro.php";

$res = mssql_query_logged("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<style type="text/css">
<!--
.style5 {font-size: 16px}
.style7 {color: #004f6b}
.style1 {font-size: 7pt}
-->
</style>
 
				     
					</div>
                    <div align="center"></div>
				  <p></td>
				</tr>
				<tr>
					<td width="0" valign="top">
					<div align="center">
						<table border="0" width="0" style="border-collapse: collapse">
							<tr>
								<td background="transparent">&nbsp;</td>
						  </tr>
							<tr>
								<td background="transparent">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="0" height="0">

											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
											</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
												</tr>

							</tr>										<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">&nbsp;											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="transparent" height="27">&nbsp;</td>
						  </tr>
						</table>
					    <br>
			<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>
					</div></td>
                    </tr>
			</table>