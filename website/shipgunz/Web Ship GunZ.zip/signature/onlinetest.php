<?php
// Includes
include('./includes/config.php');
include('./includes/odbc_class.php');

// Database Connection
$dbc = odbc_connect($database['name'],$database['user'],$database['pass'],SQL_CUR_USE_ODBC);
$query = odbc_exec($dbc,'SELECT Name,LastLoginTime,LastLogoutTime,DATEDIFF(millisecond,LastLoginTime,LastLogoutTime) AS LoginStatus FROM dbo.Account');

// Loop Data
while($row = odbc_fetch_array($query)) {
	if($row['LoginStatus'] < 0) {
		echo $row['Name'].' is online ('.$row['LastLoginTime'].','.$row['LastLogoutTime'].','.$row['LoginStatus'].')<br />';
	}
	else {
		echo $row['Name'].' is Offline ('.$row['LastLoginTime'].','.$row['LastLogoutTime'].','.$row['LoginStatus'].')<br />';
	}
}
?>