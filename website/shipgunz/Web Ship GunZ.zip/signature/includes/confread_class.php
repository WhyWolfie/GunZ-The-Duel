<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# --------- confread_class.php --------- #
# ---------- 17 - Oct - 2009 ----------- #
# -------------------------------------- #

class confread_class {
	
	// Variables
	var $data;
	var $conf;
	
	// Config Reader Function
	function config_read() {
		
		// Store config info
		$data['img'] = substr($this->img,0,-4);
		$data['file'] = file_get_contents('./imgconf/'.$data['img'].'.txt');
		
		// Find Variable Names + Data
		preg_match_all('/((Name|UGradeID|Level|EXP|Bounty|Clan|CMaster|Emblem|Ratio|NameX|NameY|LevelX|LevelY|EXPX|EXPY|BountyX|bountyY|ClanX|ClanY|EmblemX|EmblemY|RatioX|RatioY|EWidth|EHeight|Red|Blue|Green|Font|Size)=([\d]{1,3}|.+\.(ttf|otf)))/i',$data['file'],$data['matches']);
		
		// Clean the data
		foreach($data['matches'][0] as $data['foreach']) {
			$data['split'] = split('=',$data['foreach']);
			$conf[$data['split'][0]] = $data['split'][1];
		}
		
		// Return Config Array
		return($conf);
		
	}
}
?>