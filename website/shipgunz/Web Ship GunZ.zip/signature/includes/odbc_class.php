<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# ---------- odbc_class.php ------------ #
# ---------- 04 - Oct - 2009 ----------- #
# -------------------------------------- #

class odbc_class {
	
	// Variables
	private $db;
	var $data;
	
	// Database Connection Function
	function odbc_conn() {
		
		// Store Database Information
		$db['name'] = $this->name;
		$db['user'] = $this->user;
		$db['pass'] = $this->pass;
		
		// Return Database Connection
		return(odbc_connect($db['name'],$db['user'],$db['pass'],SQL_CUR_USE_ODBC));
	}
	
	// Database Query Function
	function odbc_data() {
		
		// Store Query Information
		$data['query'] = $this->query;
		
		// Return Query Results
		return(odbc_exec(odbc_class::odbc_conn(),$data['query']));
	}
	
	// Database Array Function
	function odbc_array() {
		
		// Fetch Query Data Into Array
		return(odbc_fetch_array(odbc_class::odbc_data()));
	}

	// Database Rows Function
	function odbc_rows() {
	
		// Storing INC and Query Data
		$data['i'] = 0;
		$data['query'] = odbc_class::odbc_data();
		
		// Count Rows
		while($temp = odbc_fetch_into($data['query'],$data['junk'])) {
			$data['i']++;
		}
		
		// Return Rows
		return($data['i']);
	}		
}
?>