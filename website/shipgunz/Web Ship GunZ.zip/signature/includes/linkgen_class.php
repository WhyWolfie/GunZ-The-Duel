<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# --------- linkgen_class.php ---------- #
# ---------- 07 - Oct - 2009 ----------- #
# -------------------------------------- #

class linkgen_class {
	
	// Variables
	var $data;
	
	// Link Generation Function
	function link_gen() {
		
		// Store Data
		$data['name'] = $this->name;
		$data['image'] = $this->image;
		$data['path'] = $this->path;
		
		// Output Image
		echo '<img src="'.$data['path'].'signature.php?nm='.$data['name'].'&bg='.$data['image'].'" /><br /><br />';
		
		// Output Links
		echo '<table>
				<tr>
					<td>
						Forums [1] : 
					</td>
					<td>
						<input type="text" size="75" value="[img]'.$data['path'].'signature.php?nm='.$data['name'].'&bg='.$data['image'].'[/img]" />
					</td>
				</tr>
				<tr>
					<td>
						Forums [2] : 
					</td>
					<td>
						<input type="text" size="75" value="[url='.$data['path'].'signature.php?nm='.$data['name'].'&bg='.$data['image'].'][img]'.$data['path'].'signature.php?nm='.$data['name'].'&bg='.$data['image'].'[/img][/url]" />
					</td>
				</tr>
				<tr>
					<td>
						Direct :
					</td>
					<td>
						<input type="text" size="75" value="'.$data['path'].'signature.php?nm='.$data['name'].'&bg='.$data['image'].'" />
					</td>
				</tr>
			  <table>';
	}
}
?>