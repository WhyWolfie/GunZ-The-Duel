<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# --------- imgdraw_class.php ---------- #
# ---------- 10 - Oct - 2009 ----------- #
# -------------------------------------- #

class imgdraw_class {
	
	// Variables
	var $data;
	var $img;
	
	// Create Image Handle From Image
	function imgdraw_stock() {
		
		// Storing Data
		$data['stock'] = $this->stock;
		
		// Create Image handle
		$img = imagecreatefrompng($data['stock']);
		
		// Return Image Handle
		return($img);
	}
	
	// Draw Text Onto Image
	function imgdraw_text() {
		
		// Store Image Handle
		$img = $this->handle;
	
		// Store String Colors
		$data['color'][0] = $this->C0;
		$data['color'][1] = $this->C1;
		$data['color'][2] = $this->C2;
		
		// Store Font
		$data['font'] = './fonts/'.$this->font;
		
		// Store Size
		$data['size'] = $this->size;
		
		// Store Positions
		$data['pos']['x'] = $this->X;
		$data['pos']['y'] = $this->Y;
		
		// Store String
		$data['text'] = $this->text;	
		
		// Set Color And Draw String
		$data['txtc'] = imagecolorallocate($img,$data['color'][0],$data['color'][1],$data['color'][2]);
		imagettftext($img,$data['size'],0,$data['pos']['x'],$data['pos']['y'],$data['txtc'],$data['font'],$data['text']);
		
		// Return Image Handle
		return($img);
	}
	
	function imgdraw_merge() {
		
		// Store Image Handle
		$img = $this->handle;
		
		// Store Source Image
		$data['src'] = $this->src;
		
		// Get extension
		$data['ext'] = strtolower(pathinfo($data['src'],PATHINFO_EXTENSION));
		
		// Create SRC Image Based On Extension
		switch ($data['ext']) {
			case 'png':
				$data['srch'] = imagecreatefrompng($data['src']);
				break;
			case 'gif':
				$data['srch'] = imagecreatefromgif($data['src']);
				break;
			case 'jpg' || 'jpeg':
				$data['srch'] = imagecreatefromjpeg($data['src']);
				break;
		}
		
		// Store Dimensions + Positions
		$data['pos']['x'] = $this->X;
		$data['pos']['y'] = $this->Y;
		$data['resize']['w'] = $this->resw;
		$data['resize']['h'] = $this->resh;
		$data['size']['w'] = imagesx($data['srch']);
		$data['size']['h'] = imagesy($data['srch']);
		
		imagecopyresized($img,$data['srch'],$data['pos']['x'],$data['pos']['y'],0,0,$data['resize']['w'],$data['resize']['h'],$data['size']['w'],$data['size']['h']);
		
		// Return Image Handle
		return($img);
	}
	
	function imgdraw_center() {
		
		// Store Image Handle
		$img = $this->handle;
		
		// Store Image Dimensions
		$data['imgwidth'] = imagesx($img);
		$data['imgheight'] = imagesy($img);
	
		// Store Font And Text
		$data['font'] = $this->font;
		$data['text'] = $this->text;
		$data['size'] = $this->size;
		
		// Store Text Dimensions
		$data['box'] = imagettfbbox($data['size'],0,$data['font'],$data['text']);
		$data['MinX'] = min($data['box'][0],$data['box'][2],$data['box'][4],$data['box'][6]);
		$data['MaxX'] = max($data['box'][0],$data['box'][2],$data['box'][4],$data['box'][6]);
		$data['MinY'] = min($data['box'][1],$data['box'][3],$data['box'][5],$data['box'][7]);
		$data['MaxY'] = max($data['box'][1],$data['box'][3],$data['box'][5],$data['box'][7]);
		
		// Calculate Positions
		$data['pos']['x'] = (abs($data['MinX']) + ($data['imgwidth'] / 2) - (($data['MaxX'] - $data['MinX']) / 2));
		$data['pos']['y'] = (abs($data['MinY']) + ($data['imgheight'] / 2) - (($data['MaxY'] - $data['MinY']) / 2));
		
		// Return Positions + Handle
		return array('x' => $data['pos']['x'],'y' => $data['pos']['y'],'handle' => $img);
	}
	
	// Create Image From Handle
	function imgdraw_create() {
		
		// Store Handle
		$img = $this->handle;
		
		//Create Image
		imagepng($img);
	}

	// Image Error Function
	function imgdraw_error() {
		
		// Store Image
		$img = $this->handle;
		$data['font'] = $this->font;
		$data['text'] = $this->text;
		$data['size'] = $this->size;
		
		// Get center Positions
		$data['pos'] = imgdraw_class::imgdraw_center();
		
		// Draw Error Text
		$data['txtc'] = imagecolorallocate($img,255,255,255);
		imagettftext($img,10,0,$data['pos']['x'],$data['pos']['y'],$data['txtc'],$data['font'],$data['text']);
		
		// Create Error Image
		imagepng($img);
		
	}
}
?>