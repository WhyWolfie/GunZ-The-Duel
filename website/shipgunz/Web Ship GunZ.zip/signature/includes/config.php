<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# ------------ Config.php -------------- #
# ---------- 16 - Oct - 2009 ----------- #
# -------------------------------------- #

# --------------------------------------- #
# ---- Database Configuration (odbc) ---- #
# --------------------------------------- #
$database['name'] = 'GunZDB';
$database['user'] = 'sa';
$database['pass'] = '3124589joker';
# --------------------------------------- #
# ---- Signature Path Configuration ----- #
# --------------------------------------- #
$path['emblems'] = 'http://night-gamerz.sytes.net/NighT/';
# --------------------------------------- #
# ---- Database Table Configuration ----- #
# --------------------------------------- #
$table['account']    = 'dbo.Account';
$table['character']  = 'dbo.Character';
$table['clanmember'] = 'dbo.ClanMember';
$table['clan']       = 'dbo.Clan';
# --------------------------------------- #
# ------ Name Color Configuration ------- #
# --------------------------------------- #
$color[255] = array(255,153,51); // Administrator
$color[254] = array(255,153,51); // Developer/Gamemaster
$color[253] = array(255,255,255); // Banned
$color[252] = array(255,153,51); // Hidden GM
$color[2]   = array(0,68,255); // User With Jjang
$color[0]   = array(255,255,255); // Normal User
# --------------------------------------- #
# ---------> Made by LegacyCode <-------- #
# --------------------------------------- #
?>