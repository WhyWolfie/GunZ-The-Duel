<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# --------- datachk_class.php ---------- #
# ---------- 06 - Oct - 2009 ----------- #
# -------------------------------------- #

class datachk_class {

	// Variables
	var $data;
	
	// Name Check Function
	function name_check() {
	
		// Store Name
		$data['name'] = $this->name;
		
		// Check Name
		if(preg_match('/^[a-z0-9_-]{4,24}$/i',$data['name'])) {
			return(1);
		}
		else {
			return(0);

		}
	}
	
	// Image Check Function
	function image_check() {
		
		// Store Image
		$data['img'] = $this->image;
		
		// Check Image
		if(file_exists('./images/signatures/'.$data['img'])) {
			return(1);
		} 
		else {
			return(0);
		}
	}
	
}
?>