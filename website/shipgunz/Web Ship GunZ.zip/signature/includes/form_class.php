<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# ----------- form_class.php ----------- #
# ---------- 16 - Oct - 2009 ----------- #
# -------------------------------------- #

class form_class {
	
	// Variables
	var $data;
	
	// Form Start Function
	function form_start() {
	
		// Store Form Parameters
		$data['method'] = $this->method;
		$data['action'] = $this->action;
		
		// Output Form Start
		echo '<form action="'.$data['action'].'" method="'.$data['method'].'">
			 	<div align="center">';
	}
	
	// Form Input Function
	function form_input() {
		
		// Store Input parameters
		$data['name'] = $this->name;
		$data['chars'] = $this->chars;
		$data['size'] = $this->size;
		
		// Output Text Field Data
		echo '<input type="text" name="'.$data['name'].'" id="'.$data['id'].'" size="'.$data['size'].'" maxlength="'.$data['chars'].'" />';
	}
	
	// Form Radio Function
	function form_radio() {
		
		// Store Parametes
		$data['path'] = $this->path;
		$data['name'] = $this->name;
		$data['imgs'] = scandir($data['path']);
		
		// Output Start Of Table
		echo '<table>';
		
		// Output Radiobox Data
		foreach ($data['imgs'] as $data['img']) {
			if(strtolower(pathinfo($data['img'],PATHINFO_EXTENSION) == 'png')) {
				echo '<tr>
						<td>
							<input type="radio" name="'.$data['name'].'" id="'.$data['name'].'" value="'.$data['img'].'" />
						</td>
						<td>
							<img src="'.$data['path'].$data['img'].'" />
						</td>
					 </tr>';
			} 
		}
		
		// Output End Of Table
		echo '</table>';
	}
	
	// Form Button Function
	function form_button() {
		
		// Store Button Parameters
		$data['name'] = $this->name;
		$data['label'] = $this->label;
		
		// Output Button Data
		echo '<input type="submit" name="'.$data['name'].'" id="'.$data['name'].'" value="'.$data['label'].'" /><br />';
	}
	
	// Form End Function
	function form_end() {
		
		// Output Form End 
		echo '</div>
				</form>';
	}
}
?>