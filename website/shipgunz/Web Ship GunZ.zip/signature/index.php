<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# ------------- index.php -------------- #
# ---------- 16 - Oct - 2009 ----------- #
# -------------------------------------- #

// Include Files
include('./includes/config.php');
include('./includes/form_class.php');
include('./includes/datachk_class.php');
include('./includes/linkgen_class.php');
include('./includes/odbc_class.php');

// Output Page Beginning
echo '<html>
		<head>
			<meta content="text/html; charset=UTF-8" http-equiv="content-type"/>
			<title>NighT GamerZ Signature</title>
		</head>
		<body>
			<div align="center">';

// Check If Page Was Submited			
if ($_POST['submit'] != 'Generate Link') {

	// Create And Output Form
	$form = new form_class;
	$form->action = '';
	$form->method = 'post';
	$form->form_start();
	
	// Create And Output Text Field
	$form->name = 'name';
	$form->chars = 24;
	$form->size = 24;
	echo 'Name : '; 
	$form->form_input();
	
	// Output Line
	echo '<br />---------------------------------------------------------------------<br />';
	
	// Create And Output Radiobuttons
	$form->name = 'image';
	$form->path = './images/signatures/';
	$form->form_radio();
	
	// Output Line
	echo '<br />---------------------------------------------------------------------<br />';
	
	// Create And Output Button 
	$form->name = 'submit';
	$form->label = 'Generate Link';
	$form->form_button();
	
	// End The Form
	$form->form_end();
}
else {
	
	// Star Data Check Class
	$datachk = new datachk_class;
	$datachk->name = $_POST['name'];
	$datachk->image = $_POST['image'];
	
	// Check Data
	if(!$datachk->name_check()) {
		$errmsg .= '-> Invalid Name<br />-> User Not Found < br />';
	}
	if(!$datachk->image_check()) {
		$errmsg .= '-> Invalid Image<br />';
	}
	
	if($errmsg == '') {
		
		// Check Username
		$userchk = new odbc_class;
		$userchk->name = $database['name'];
		$userchk->user = $database['user'];
		$userchk->pass = $database['pass'];
		$userchk->query = 'SELECT * FROM '.$table['character'].' WHERE Name = \''.$_POST['name'].'\'';
		if ($userchk->odbc_rows() == 0) {
			$errmsg .= '-> User Not Found<br />';
		}
		
	}
	
	if($errmsg == '') {
		
		// Generate Link Data
		$linkgen = new linkgen_class;
		$linkgen->name = $_POST['name'];
		$linkgen->image = $_POST['image'];
		$linkgen->path = 'http://'.$_SERVER['HTTP_HOST'].str_replace(basename($_SERVER['PHP_SELF']),'',$_SERVER['PHP_SELF']);
		$linkgen->link_gen();
	}
	else {
		echo $errmsg;
	}
}

// End Of Page
echo '		<br />:: Maded By Joker ::</div>
		</body>
	</html>';
?>