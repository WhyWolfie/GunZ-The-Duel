<?php
# -------------------------------------- #
# -- GunZ Signature Statistics V1.2.0 -- #
# --------> Made By LegacyCode <-------- #
# -------------------------------------- #
# ----------- signature.php ------------ #
# ---------- 17 - Oct - 2009 ----------- #
# -------------------------------------- #

// File Type Header
header('Content-type: image/png'); 

// Includes
include('./includes/config.php');
include('./includes/odbc_class.php');
include('./includes/imgdraw_class.php');
include('./includes/datachk_class.php');
include('./includes/confread_class.php');

// Data Check
$datachk = new datachk_class;
$datachk->name = $_GET['nm'];
$datachk->image = $_GET['bg'];
if($datachk->name_check() != 1 || $datachk->image_check() != 1) {
	$error = new imgdraw_class;
	$error->stock = './images/error.png';
	$hndl = $error->imgdraw_stock();
	$error->handle = $hndl;
	$error->font = './fonts/X-SCALE_.TTF';
	$error->size = 10;
	if($datachk->name_check() != 1) {
		$error->text = 'Invalid Character Name';
	}
	else {
		$error->text =  'Invalid Stock Image';
	}
	$error->imgdraw_error();
	die;
}

// Create database connecton
$odbc = new odbc_class;
$odbc->name = $database['name'];
$odbc->user = $database['user'];
$odbc->pass = $database['pass'];

// User Check
$odbc->query = 'SELECT * FROM '.$table['character'].' WHERE Name = \''.$_GET['nm'].'\'';
if ($odbc->odbc_rows() == 0) {
	$error = new imgdraw_class;
	$error->stock = './images/error.png';
	$hndl = $error->imgdraw_stock();
	$error->handle = $hndl;
	$error->font = './fonts/X-SCALE_.TTF';
	$error->size = 10;
	$error->text = 'Character Not Found';
	$error->imgdraw_error();
	die;
}

// Database data retrieval
//$odbc->query = 'SELECT a.Name,a.Level,a.XP,a.BP,a.CID,b.CID,b.CLID,c.CLID,c.EmblemUrl,a.AID,d.AID,d.UGradeID,c.Name AS CName FROM '.$table['character'].' a,'.$table['clanmember'].' b,'.$table['clan'].' c, '.$table['account'].' d WHERE a.CID = b.CID AND b.CLID = c.CLID AND a.AID = d.AID AND a.Name = \''.$_GET['nm'].'\'';
$odbc->query = 'SELECT a.Name,a.Level,a.XP,a.BP,a.CID,a.AID,a.KillCount,a.DeathCount,b.AID,b.UGradeID FROM '.$table['character'].' a,'.$table['account'].' b WHERE  a.AID = b.AID AND a.Name = \''.$_GET['nm'].'\'';
$data['char'] = $odbc->odbc_array();
$odbc->query = 'SELECT a.CID,a.CLID,b.CLID,b.EmblemUrl,b.Name,b.MasterCID FROM '.$table['clanmember'].' a,'.$table['clan'].' b WHERE a.CLID = b.CLID AND a.CID = \''.$data['char']['CID'].'\'';
$data['clan'] = $odbc->odbc_array();

// Read config file and retrieve data
$confread = new confread_class;
$confread->img = $_GET['bg'];
$imgconf = $confread->config_read();

// Creating a new image based on background image
$img = new imgdraw_class;
$img->stock = './images/signatures/'.$_GET['bg'];
$hndl = $img->imgdraw_stock();

// Draw Clan Emblem
if($imgconf['Emblem'] == 1 && $data['clan']['EmblemURL'] != '') {
	$img->src = $path['emblems'].$data['clan']['EmblemUrl'];
	$img->X = $imgconf['EmblemX'];
	$img->Y = $imgconf['EmblemY'];
	$img->resw = $imgconf['EWidth'];
	$img->resh = $imgconf['EHeight'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_merge();
}

// Setting Font + Size
$img->font = $imgconf['Font'];
$img->size = $imgconf['Size'];

// Players Name
if ($imgconf['Name'] == 1) {
	
	// UgradeID Check
	if($imgconf['UGradeID'] == 1) {
		$data['char']['Name'] .= '('.$data['char']['UGradeID'].')';
	}

	// Setting the colors
	$img->C0 = $color[$data['char']['UGradeID']][0];
	$img->C1 = $color[$data['char']['UGradeID']][1];
	$img->C2 = $color[$data['char']['UGradeID']][2];
	
	// Draw the players "name" from the database on the image
	$img->X = $imgconf['NameX'];
	$img->Y = $imgconf['NameY'];
	$img->text = $data['char']['Name'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

// Setting the colors
$img->C0 = $imgconf['Red'];
$img->C1 = $imgconf['Green'];
$img->C2 = $imgconf['Blue'];

// Draw the players "level" from the database on the image
if($imgconf['Level'] == 1) {
	$img->X = $imgconf['LevelX'];
	$img->Y = $imgconf['LevelY'];
	$img->text = $data['char']['Level'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

// Draw the players "EXP" from the database on the image
if($imgconf['EXP'] == 1) {
	$img->X = $imgconf['EXPX'];
	$img->Y = $imgconf['EXPY']; 
	$img->text = $data['char']['XP'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

// Draw the players "Bounty" from the database on the image
if($imgconf['Bounty'] == 1) {
	$img->X = $imgconf['BountyX'];
	$img->Y = $imgconf['BountyY'];
	$img->text = $data['char']['BP'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

// Draw the players "Clan" from the database on the image
if($imgconf['Clan'] == 1) {
	
	if($data['clan']['Name'] == '') {
		$data['clan']['Name'] = '...';
	}
	if($data['clan']['MasterCID'] == $data['char']['CID'] && $imgconf['CMaster'] == 1) {
			$data['clan']['Name'] .= '(M)';
	}
	
	$img->X = $imgconf['ClanX'];
	$img->Y = $imgconf['ClanY'];
	$img->text = $data['clan']['Name'];
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

// Draw the players "Kill/death Ratio" from the database on the image
if($imgconf['Ratio'] == 1) {
	$img->X = $imgconf['RatioX'];
	$img->Y = $imgconf['RatioY'];
	$img->text = $data['char']['KillCount'].'/'.$data['char']['DeathCount'].'('.@round(($data['char']['KillCount'] / ($data['char']['KillCount'] + $data['char']['DeathCount']) * 100),1).'%)';
	$img->handle = $hndl;
	$hndl = $img->imgdraw_text();
}

$img->imgdraw_create();

?>