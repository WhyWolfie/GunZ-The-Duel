<?
$res = mssql_query_logged("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<style type="text/css">
<!--
.style5 {font-size: 16px}
.style7 {color: #004f6b}
.style1 {font-size: 7pt}
-->
</style>

			<table border="0" style="border-collapse: collapse" width="100%" height="100%" id="table2">
				<tr>
				  <td width="481" valign="top" height="127">
					<div align="center">
					  <table border="0" style="border-collapse: collapse" width="443" id="table7" background="images/playframe.png" height="87">
                        <tr>
                          <td height="87" width="269"><table border="0" style="border-collapse: collapse" width="436" height="85%">
                              <tr>
                                <td><p align="center"><b> <font size="5" face="Trebuchet MS" color="#FFFFFF">
                                    <?=$servercount?>
                                  </font></b> <br>
                                    <span class="style5"><b>Players Online</b></span></td>
                              </tr>
                              <tr>
                                <body onload="FP_preloadImgs(/*url*/'images/btn_dlgunz_hover.png')" bgcolor="#323232">
				<td height="32" width="457"> <center><a href="index.php?do=downloads" target="_blank"><img src="images/btn_dlgunz.png" name="img6" border="0" id="img6" onMouseOver="FP_swapImg(1,1,/*id*/'img6',/*url*/'images/btn_dlgunz_hover.png')" onMouseOut="FP_swapImgRestore()"></a></center></td>
                              </tr>
                          </table></td>
                        </tr>
                      </table> 

<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="5">&nbsp;</td>
											<td width="430">
											<img border="0" src="images/inf/homepage2.png" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">
											&nbsp;</td>
										</tr>
	
										<tr>
											<td width="432">
											<form method="POST" action="index.php?do=contact"><table border="0" style="border-collapse: collapse" width="100%" id="table13">
											<tr>
												<td width="16">&nbsp;</td>
												<td width="532" colspan="4">&nbsp;</td>
											</tr>
											<tr>
												<td width="16"><? echo $faq['general_faq'] ?></td>
												<td width="532" colspan="4">
Para ser parceiro de NighT GamerZ adicione nosso banner em uma boa posi��o em seu site.<br><br>

Seu site deve ter no m�nimo 50 visitas por dia.

<div align="center"><br><br><img src="http://img387.imageshack.us/img387/1905/nightgamerz.gif" width="150" height="80"><br><br><textarea onmouseover="this.focus()" onfocus="this.select()" name="textarea" rows="3" cols="15">&lt;a href="http://night-gamerz.sytes.net/" target="_blank"&gt;&lt;br /&gt;&lt;img src="http://img387.imageshack.us/img387/1905/nightgamerz.gif" width="120" height="60" border="0" /&gt;&lt;/a&gt;</textarea><br></div><br><br>

Logo em seguida envie um e-mail para: <b>chaos@kaamail.com</b><br><br>

No Assunto coloque: Parceria - Nome do Seu Site<br><br>

No texto, coloque seu nome, e-mail, link do seu site e o link do banner e aguarde at� que seja confirmada a parceria.<br><br>
													</td>
												</tr>

										</table></form>
											</td>
										</tr>
	
										<tr>
											<td width="432">
											&nbsp;</td>
										</tr>
	
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>