<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicon.ico" type="image/ico"/> 
<title>NighT GamerZ - Maintenance</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
<!--
//Disable right click script
var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg2.jpg);
}
-->
</style></head>

<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>Server are currently under maintenance.</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

                                                                                         Hello to all the players of NighT GamerZ.
                                                                                        <p>NighT GamerZ have 1 dedicated servers, enabling the possibility of having a GunZ server 24 hours without falling, and most importantly, without lag.</p>
											<p>At the moment, we are currently fixing the bug issue, we will be back online as soon as we can.</p>
											<p>Thank you, NighT GamerZ team.</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
<center><FONT COLOR="#00FFFF"><br>Copyright � 2009 NighT GamerZ Team. All rights reserved.<br><br>GunZ is a registered trademark of Maeit Entertainment<br><br><!-- Do not remove this i fixed it for you soo copyright me.--> Website fixed and add-on by Nolife_x.<br><br></FONT></div></center>
