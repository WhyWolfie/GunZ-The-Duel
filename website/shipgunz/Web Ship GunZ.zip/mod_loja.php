
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg"><div align="center"><img border="0" src="images/inf/loja.png" width="413" height="17"></div></td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
								  <p><a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1"><img src="Images/Donator.png" alt="" width="415" height="60" border="0" longdesc="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1"></a>
							        </form>
</p>
								  <p><a href="index.php?do=evitemshop&sub=listallitems&expand=1&type=1"><img src="Images/Evento.png" width="415" height="60" border="0"></a> </p>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>