<?php
//NighT GamerZ Spain Config
$link = mssql_connect("Tu-PC\SQLEXPRESS","sa","2asdsad");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'Tu-PC\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = '2asdas'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZ DB 


?>