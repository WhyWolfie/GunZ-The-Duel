<?php
alertbox("Completed!!! NG Coins Added","http://174.48.46.43/NighT/index.php");
    die();
?>

