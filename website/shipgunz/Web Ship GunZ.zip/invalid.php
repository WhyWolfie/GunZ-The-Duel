<?php
alertbox("Invalid Payment.","http://174.48.46.43/NighT/index.php");
    die();
?>

