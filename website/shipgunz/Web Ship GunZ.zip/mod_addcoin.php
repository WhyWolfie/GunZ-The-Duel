<?
    if( isset($_POST['addcoin2']) )
    {
        $type = antisql($_POST['type']);
        $id = antisql($_POST['id']);
        $coin = antisql($_POST['coin']);

        if( $type == "" || $id == "" || $coin == "" )
        {
            echo "Prencha todos os campos<br>";
            die();
        }

        if( $type == 0 )
        {
            $query02 = mssql_query("SELECT AID FROM Login WHERE UserID = '$id'");
            $part = "UserID";
        }
        elseif( $type == 1 )
        {
            $query02 = mssql_query("SELECT * FROM Character WHERE Name = '$id'");
            $part = "Character Name";
        }
        else
        {
            die();
        }

        if( mssql_num_rows($query02) != 1 )
        {
            echo "Conta nao existe<br>";
            die();
        }
        else
        {
            mssql_query("UPDATE Login SET EVCoins = EVCoins + $coin WHERE $part = '$id'");
            echo "Event Coins Enviadas com sucesso<br>";
            die();
        }
    }

if(!isset($_POST['id'])){
?>

<table border="0" style="border-collapse: collapse" id="addcoin">
<tr><td colspan="2"><b>Adicionar Event Coins</b></td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<form method="post" action="index.php?do=addcoin">
<tr>
<tr><td colspan="2">&nbsp;</td></tr>
</form>
</table>

<br />
<table border="0" style="border-collapse: collapse" id="addcoin2">
<tr><td colspan="2"><b>Event Coins</b></td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
<form method="post" action="index.php?do=addcoin">
<tr>
    <td>
    <select name="type">
        <option value="0">UserID</option>
        <option value="1">Char Nome</option>
    </select>
 &nbsp;&nbsp;<input type="text" name="id" />&nbsp;&nbsp;coin:&nbsp;&nbsp;
 <input type="text" name="coin" />
    &nbsp;&nbsp;<input type="submit" name="addcoin2" value="Add coin" />
    </td>
</tr>
<tr><td colspan="2">&nbsp;</td></tr>
</form>
</table>
<? } ?>