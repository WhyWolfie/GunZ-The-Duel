<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("USER-PC\SQLEXPRESS","sa","123456");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'USER-PC\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = '123456';
$DB = 'GunzDB';
?>