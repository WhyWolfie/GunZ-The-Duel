
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="15">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/downloads.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="3">
											</td>
											<td width="141">&nbsp;
											</td>
											<td width="287">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="3" rowspan="6">
											</td>
											<td width="141" rowspan="6">
											<div align="center">
												<table border="0" style="border-collapse: collapse" width="141" height="100%">
													<tr>
														<td width="7">&nbsp;</td>
														<td width="122" rowspan="3">
														<img border="0" src="images/dl_img.jpg" width="150" height="90"></td>
														<td width="6">&nbsp;</td>
													</tr>
													<tr>
														<td width="7">&nbsp;</td>
														<td width="6">&nbsp;</td>
													</tr>
													<tr>
														<td width="7">&nbsp;</td>
														<td width="6">&nbsp;</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="287">
											NighT GamerZ</td>
										</tr>

										<tr>
											<td width="287">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="287">
										    Tamanho: 290 MB</td>
										</tr>
										<tr>
											<td width="287"> G&ecirc;nero: A&ccedil;&atilde;o </td>
										</tr>


										<tr>
											<td width="287">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="287">
<select onChange="location = options[selectedIndex].value" size="1">
<option selected="selected">Select the download</option>
<option value="http://www.filefront.com/14931543/NighT%20GamerZ%20Version4.exe">FileFront</option>
<option value="http://www.megaupload.com/?d=KK95CA5S">MegaUpLoad</option>
<option value="http://www.megaupload.com/?d=FERF8OJV">Update2</option>
<option value="http://www.filefront.com/14998111/Update3.mrs">Update3</option>
</select>
										</td></tr>
                                                                                <tr>
											<td width="3">
											</td>
											<td width="141">&nbsp;
											</td>
											<td width="287">&nbsp;
											</td>
										</tr>
											<td width="432" colspan="3">
											<div align="center">
												<table border="0"  background="images/req_sys.jpg" style="border-collapse: collapse; background-image: url('images/req_sys.jpg'); background-repeat: no-repeat;" width="421">
													<tr>
														<td width="10" height="25">&nbsp;</td>
														<td width="195">&nbsp;</td>
													</tr>
													<tr>
														<td width="-2">
														<p align="center"></td>
														<td width="195">
													  <p align="center"> <strong>M&iacute;nimo</strong> </td>
														<td width="211">
													  <p align="center"> <strong>Recomendado</strong> </td>

<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>OS</strong>:&nbsp;Windows 2000 </td>
														<td width="211"><strong>OS</strong>:&nbsp;Windows XP -  Vista - 7 </td>
												  </tr>
													</tr>
													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>CPU</strong>:&nbsp;500MHz Pentium III </td>
														<td width="211"><b>CPU</b>:
														<span class="txt_col02_data">
														Pentium III 800MHz or 
														better</span></td>
													</tr>

<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>Mem&oacute;ria RAM</strong>: 256MB </td>
														<td width="211"><strong>CPU</strong>:&nbsp;Pentium III 800 MHz </td>
												  </tr>

													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>GFX Card</strong>: Direct3D 9.0 </td>
														<td width="211"><strong>GFX Card</strong>:&nbsp;GeForce 4 MX ou melhor </td>
													</tr>
													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>DirectX</strong>: 9c ou superior </td>
														<td width="211"><strong>DirectX</strong>: 9c ou superior </td>
													</tr>

<tr>

	<td width="-2">&nbsp;</td>
														<td width="195"><strong>Placa de Som</strong>: Direct3D </td>
														<td width="211"><strong>Placa de Som</strong>: Direct3D </td>

</tr>

<tr>

	<td width="-2">&nbsp;</td>
														<td width="195"><strong>Mouse</strong>: Janela Compat&iacute;vel </td>
														<td width="211"><strong>Mouse</strong>: Mouse Whell </td>

</tr>
													
<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><strong>Joypad</strong>: Janela Compat&iacute;vel </td>
														<td width="211"><strong>Joypad</strong>: Pad Dual Shock Alegria </td>
												  </tr>
													</table>
											</div>
											</td>
										</tr>

										<tr>
											<td width="432" colspan="3" height="18">
											</td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>