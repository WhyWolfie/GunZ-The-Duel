<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>NighT GamerZ V4 - Account Banned</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
<!--
//Disable right click script
var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg2.jpg);
}
-->
</style></head>
										<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>Dear <?=$_SESSION['UserID']?>,</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

                                                                                           Your account got banned by the NighT GamerZ Team.
											<p>I think you already know why you got banned.</p>
                                                                                        <p>You can always make a new account from the register page.</p>
                                                                                        <p>You can always try to get unbanned in the unban section on the <a href="http://forum-nightgamerz.tk">forum</a>.</p>
                                                                                        <p>So this time be sure to read and follow the <a href="http://forum-nightgamerz.tk">rules</a>.</p>
                                                                                        <p>Have a nice day.</p>
											<p>Thank you, NighT GamerZ Team.</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
<center><FONT COLOR="#00FFFF"><br>Copyright � 2009 NighT GamerZ Team. All rights reserved.<br><br></FONT></div></center>

    <?
    die();
}

?>