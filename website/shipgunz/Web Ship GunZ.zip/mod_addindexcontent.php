<?
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $title = clean($_POST['title']);
    $type = clean($_POST['type']);
    $text = clean($_POST['text']);
    $user = $_SESSION['UserID'];
    mssql_query_logged("INSERT INTO IndexContent ([Type], [User], [Date], [Text], [Title])VALUES($type, '$user', GETDATE(), '$text', '$title')");
    msgbox("Added correctly","index.php?do=addindexcontent");
}else{
?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=addindexcontent"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="13">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/addupdatenote.png" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="431" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="3" colspan="3">
											</td>
										</tr>

										<tr>
											<td width="112" align="right">
											Title</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<input type="text" name="title" size="40"></td>
										</tr>

										<tr>
											<td width="112" align="right">
											Type</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<select size="1" name="type">
											<option selected value="1">Anuncio Portugu�s
											</option>
											<option value="2">English announce
											</option>
											</select></td>
										</tr>

										<tr>
											<td width="112" align="right" valign="top">
											Text</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											<textarea rows="8" name="text" cols="35"></textarea></td>
										</tr>

										<tr>
											<td width="112">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="316">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add" name="submit"></td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>