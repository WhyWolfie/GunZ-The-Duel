<?php

  $crlf=chr(13).chr(10);
  $itime=5;
  $imaxvisit=10;
  $ipenalty=($itime * $imaxvisit);
  $iplogdir="./logs/";
  $iplogfile="Shieldlogs.txt";
  

  $today = date("Y-m-j,G");
  $min = date("i");
  $sec = date("s");
  $r = substr(date("i"),0,1);
  $m =  substr(date("i"),1,1);
  $minute = 0;
  
  $to      = 'gm-venom@hotmail.com';  
  $headers = 'From : Someone Tryed To DDoS NighT GamerZ.' . "\r\n";
  $subject = "Warning Of Possible DDoS Attack At $today:$min:$sec";
  
  $message2='Please Try Again Later ... ';
//---------------------- End of Initialization ---------------------------------------  

  $ipfile=substr(md5($_SERVER["REMOTE_ADDR"]),-3);  // -3 means 4096 possible files
  $oldtime=0;
  if (file_exists($iplogdir.$ipfile)) $oldtime=filemtime($iplogdir.$ipfile);

  $time=time();
  if ($oldtime<$time) $oldtime=$time;
  $newtime=$oldtime+$itime;

  if ($newtime>=$time+$itime*$imaxvisit)
  {

    touch($iplogdir.$ipfile,$time+$itime*($imaxvisit-1)+$ipenalty);
    header("HTTP/1.0 503 Service Temporarily Unavailable");
    header("Connection: close");
    header("Content-Type: text/html");
    echo '<html><head><title>NighT GamerZ</title></head><body><p align="center"><strong>'
          .$message1.'</strong>'.$br;
    echo $message2.$message3.$message4.$message6.'</p>
</body></html>';

     {
	@mail($to, $subject, $message5, $headers);	
     }

    $fp=@fopen($iplogdir.$iplogfile,"a");
    if ($fp!==FALSE)
    {
      $useragent='<unknown user agent>';
      if (isset($_SERVER["HTTP_USER_AGENT"])) $useragent=$_SERVER["HTTP_USER_AGENT"];
      @fputs($fp,$_SERVER["REMOTE_ADDR"].' on '.date("D, d M Y, H:i:s").' as '.$useragent.$crlf);
    }
    @fclose($fp);
    exit();
  }

  touch($iplogdir.$ipfile,$newtime);
?>