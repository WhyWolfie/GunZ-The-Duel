<?php
//NighT GamerZ Spain Config
$link = mssql_connect("PATY-C241A658BA","sa","3124589joker");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'PATY-C241A658BA';
$DBUser = 'sa';
$DBPass = '3124589joker';
$DB = 'GunzDB';
?>