<style type="text/css">
@import "final.css";
</style>
					  <table style="border-collapse: collapse;" id="table4" width="195" border="0">
							<tbody><tr>
								<td width="195" background="images/serverstatus.gif" height="30">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
<br>
<b>&nbsp;� Quest/Clan Server:                                                                         <?php
	$ip = '174.48.46.43';
	$port = '6000';
    $fp = @fsockopen($ip, $port, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font style='color: #FF3300'>OffLine</font><br />";
        }
        else
        {
            echo "<font style='color: #93fb7f'>OnLine</font><br />";
            fclose($fp);
        }
	?>


<b>&nbsp;� Player Online:                                                                         <?php 
																	$query = mssql_query_logged("SELECT * FROM ServerStatus WHERE ServerID = 1");
																	for($i=0;$i < mssql_num_rows($query);++$i)
																	{
																	$row = mssql_fetch_row($query);
														            echo "$row[1]";
																	}
																	?>
<br>
<b>&nbsp;� <? //Total Accounts
$query = mssql_query_logged("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "Total Accounts: ".$num_rows."<n>"; 
 
?><br> 

<b>&nbsp;� <?php
 
//Total Characters
$query = mssql_query_logged("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "Total Characters: ".$num_rows."<n>";

?><br>
<b>&nbsp;� <?php
 
//Total Clans
$query = mssql_query_logged("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "Total Clans: ".$num_rows."<n>";

?><br>
<b>&nbsp;� Visits Today: <?php
$file_count = fopen('counter/count.db', 'rb');
	$data = '';
	while (!feof($file_count)) $data .= fread($file_count, 4096);
	fclose($file_count);
	list($today, $yesterday, $total, $date, $days) = split("%", $data);
	echo $today;
?>
<br>
<b>&nbsp;� Total Visits: <?php
	echo $total;
?>
	</b></b></strong></b><table style="border-collapse: collapse;" width="193" border="0" height="100%">
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                        </tbody></table>
<strong>								</strong></td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</tbody></table><br><br>

<style type="text/css">
@import "final.css";
</style>
					  <table style="border-collapse: collapse;" id="table4" width="195" border="0">
							<tbody><tr>
								<td width="195" background="images/team.gif" height="30">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
<div align="center"><a href="http://night-gamerz.sytes.net/NighT/mod_beteam.php"><br><img src="http://img387.imageshack.us/img387/1905/nightgamerz.gif" width="150" height="80">
								<p align="center"><a href="http://night-gamerz.sytes.net/NighT/mod_beteam.php">Seja Parceiro</a>

	</b></strong></b><table style="border-collapse: collapse;" width="193" border="0" height="100%">
									<tbody><tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                        </tbody></table>
<strong>								</strong></td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</tbody></table>

<div align="center"><a href="index.php?do=donate"><br><img src="http://img97.imageshack.us/img97/5066/btnbuynowng.gif" width="122" height="47"><br>

