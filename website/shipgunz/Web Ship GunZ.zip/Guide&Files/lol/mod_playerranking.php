<?
$res = mssql_query("SELECT TOP 10 * FROM TotalRanking ORDER BY Rank ASC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/playerranking.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>There is no data.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">� <?=FormatCharName($user['CID'])?></a></td>
										<td width="41">
										<p align="center"><b><?=$user['Level']?></b></td>
									</tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table><p align="center"><a href="?do=ranking&sub=individual&expand=1">Ver Mais</a></p>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</table>