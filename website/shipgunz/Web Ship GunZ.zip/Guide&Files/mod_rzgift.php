<?

include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $coins1 = clean($_POST['coins1']);
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?do=rzgift");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
$query = mssql_query_logged("SELECT [RZCoins] FROM [Login] WHERE [UserID] = '$userid'");
$item = mssql_fetch_assoc($query);
$coins = $item['RZCoins'];
$amountcoins = $_POST['coins1'];
$coins += $amountcoins;
mssql_query_logged("UPDATE [Login] SET [RZCoins] = $coins WHERE [UserID] = '$userid'");
            msgbox("The user with the ID $id has been gifted","index.php?do=rzgift");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?do=rzgift");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
$query = mssql_query_logged("SELECT [RZCoins] FROM [Login] WHERE [UserID] = '$userid'");
$item = mssql_fetch_assoc($query);
$coins = $item['RZCoins'];
$amountcoins = $_POST['coins1'];
$coins += $amountcoins;
mssql_query_logged("UPDATE [Login] SET [RZCoins] = $coins WHERE [UserID] = '$userid'");
            msgbox("The user with the character $id has been gifted","index.php?do=rzgift");
        }
    }

}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>


	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form name="Gift" method="POST" action="index.php?do=rzgift"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/gift.png" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">User ID
											</option>
											<option value="2">Character Name
											</option>
											</select></td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="coins1">
						      <option value="1" selected>1 NG Coins</option>
						      <option value="2">2 NG Coins</option>
						      <option value="3">3 NG Coins</option>
						      <option value="4">4 NG Coins</option>
						      <option value="5">5 NG Coins</option>
						      <option value="6">6 NG Coins</option>
						      <option value="7">7 NG Coins</option>
						      <option value="8">8 NG Coins</option>
						      <option value="9">9 NG Coins</option>
						      <option value="10">10 NG Coins</option>
						      <option value="11">11 NG Coins</options>
						      <option value="12">12 NG Coins</options>
						      <option value="13">13 NG Coins</options>
						      <option value="14">14 NG Coins</options>
						      <option value="15">15 NG Coins</options>
						      <option value="16">16 NG Coins</options>
						      <option value="17">17 NG Coins</options>
						      <option value="18">18 NG Coins</options>
						      <option value="19">19 NG Coins</options>
                                                      <option value="20">20 NG Coins</options>
                                                      <option value="50">50 NG Coins</options>
                                                      <option value="100">100 NG Coins</options>
                                                      <option value="150">150 NG Coins</options>
                                                      <option value="200">200 NG Coins</options>
                                                      <option value="250">250 NG Coins</options>
                                                      <option value="300">300 NG Coins</options>
                                                      <option value="350">350 NG Coins</options>
                                                      <option value="400">400 NG Coins</options>
                                                      <option value="450">450 NG Coins</options>
                                                      <option value="500">500 NG Coins</options>
											</select></td>
										</tr>

										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Gift Now" name="submit"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>