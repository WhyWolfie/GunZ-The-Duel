<?
$res = mssql_query("SELECT TOP 10 * FROM TotalRanking ORDER BY Rank ASC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/playerranking.gif" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>There is no data.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">� <a href="index.php?do=charinfo&cid=<?=$user['CID']?>"><?=FormatCharName($user['CID'])?></a></td>
										<td width="41">
										<p align="center"><b><?=$user['Level']?></b></td>
									</tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table><p align="center"><a href="?do=ranking&sub=individual&expand=1">Ver Mais</a></p>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</table>

<br><object id="99counters128778" type="application/x-shockwave-flash" data="http://www.99counters.com/counters.swf?id=128778" width="175" height="200" wmode="transparent"><param name="movie" value="http://www.99counters.com/counters.swf?id=128778" /><param name="wmode" value="transparent" /><embed src="http://www.99counters.com/counters.swf?id=128778" type="application/x-shockwave-flash" wmode="transparent" width="175" height="200"></embed><br><br><a href="http://night-gamerz.sytes.net/">casinos</a> <a href="http://night-gamerz.sytes.net/">counter</a></object>