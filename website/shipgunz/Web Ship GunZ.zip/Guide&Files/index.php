<?php
include "config.php";
include "_functions.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }

include "banned.php";
include "banneduser.php";
include "checkcookie.php";
include "title.php";
include 'counter/counter.php';
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/>
<title>NighT GamerZ - <?=$pagetitle?></title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
<!--
//Disable right click script
var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/background.jpg);
}
-->
</style></head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" bgcolor="#000000">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr>
			<td background="images/header.gif" width="921" height="258">&nbsp;</td>
	  </tr>
		<tr>
			<td background="images/nav_bar.gif" height="28" class="menu" valign="middle">
		        <p align="center"><a href="index.php"><b>INDEX</b></a> | 
			<a href="index.php?do=register"><b>REGISTER</b></a> | 
		        <a href="index.php?do=downloads"><b>DOWNLOADS</b></a> | 
			<a href="http://forum-nightgamerz.tk"><b>FORUM</b></a> | 
                        <a href="index.php?do=userpanel"><b>USER PANEL</b></a> |
                        <a href="http://www.orkut.com/Main#Community?rl=cpp&cmm=92095166"><b>ORKUT</b></a> |
			<a href="index.php?do=ranking&sub=individual&expand=1"><b>RANKING</b></a> |
			<a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1"><b>DONATE SHOP</b></a> |
			<a href="index.php?do=evitemshop&sub=listallitems&expand=1&type=1"><b>EVENT SHOP</b></a> |
                        <a href="index.php?do=donate"><b>BUY NG COINS</b></a> |
			<a href="index.php?do=signature"><b>ASSIGNATURE</b></a>
	  </tr>
		<tr>
			<td background="images/main_bg.gif">
			
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
					  <? include "mod_iLogin.php" ?><br><br>
                                          <? include "mod_status.php" ?>
					<br>
					<br>
					</div>				  
					<br>
					<br>
					<div align="center">
                    </div></td>
					<td width="481" valign="top">
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "mod_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>
					<td width="206" valign="top">
					<div align="center"><? include "mod_clanranking.php" ?>
					</div>
					<br>
					<br>
					<div align="center">
					  <? include "mod_playerranking.php" ?>
					</div>
					<p>&nbsp;</p>
				  <p></td>
				  <td width="12">&nbsp;</td>
				</tr>
				</table>
		  </td>
		</tr>
		<tr>
			<td background="images/footer.gif" height="2"><div align="center"><br></tr>
	</table>
</div>
</body>

<center><FONT COLOR="#ffffff"><br>Copyright � 2009 NighT GamerZ. All rights reserved.<br><br><br></FONT></div></center>