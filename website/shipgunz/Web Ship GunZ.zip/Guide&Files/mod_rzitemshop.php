<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<?
if ($_GET['expand'] == 1){
?>
<? }





if(!function_exists("ListAllItems")){
function ListAllItems(){
    if(!isset($_GET['type'])){
        $type = "";
    }else{
        $type = "Slot = '".clean($_GET['type'])."' AND";
    }

    $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE ".$type." Opened = '1'");

    ?>
    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="11">&nbsp;</td>
											<td width="440" colspan="2">
											<img border="0" src="images/inf/shop.png"></td>
											<td width="30">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>

										<tr>
											<td width="449" colspan="2">
											<form name="itemtype"><select size="1" name="type" onchange="SwitchItem()">
											<optgroup label="">
											<option>SELECT A ITEM CATEGORY</option>
											<option value="1">Meele Weapons</option>
											<option value="2">Ranged Weapons</option>
											<option value="3">Head</option>
											<option value="4">Shirt</option>
											<option value="5">Gloves</option>
											<option value="6">Pants</option>
											<option value="7">Shoes</option>
											<option value="8">Special Items</option>
											</optgroup></select></form></td>
										</tr>

										<tr>
											<td width="449" colspan="2">
											&nbsp;</td>
										</tr>

										<tr>
                                                                                <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 2) {
                                                $count = 1;
                                                echo "
                                                    </tr><tr>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
												        <td width='184'>&nbsp;</td>
											        </tr><tr>";
                                                ?>
                                                <td width="208">

											<table border="0" style="border-collapse: collapse" width="102%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="106" valign="top">
													<font color="#FF00FF"><?=$item['Name']?></font></td>
												</tr>
												<tr>
													<td width="106" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Type: <?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Head";
                                                        break;
                                                        case "4";
                                                        $slot = "Shirt";
                                                        break;
                                                        case "5";
                                                        $slot = "Gloves";
                                                        break;
                                                        case "6";
                                                        $slot = "Pants";
                                                        break;
                                                        case "7";
                                                        $slot = "Shoes";
                                                        break;
                                                        case "8";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Sex: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Lv. Min: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="106" valign="top">
													Price: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="106">
													<p align="center">
													<a href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="50" height="20"></a></td>
												</tr>
												<tr>
													<td width="106">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="106">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>
                                                <?
                                            }else{
                                                ?>
                                                <td width="208">
                                                											<table border="0" style="border-collapse: collapse" width="100%" height="100%">
												<tr>
													<td width="105" rowspan="8" valign="top">
													<p align="center">
													<img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
													<td width="110" valign="top">
													<font color="#FF00FF"><?=$item['Name']?></font></td>
												</tr>
												<tr>
													<td width="110" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Type: <?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Head";
                                                        break;
                                                        case "4";
                                                        $slot = "Shirt";
                                                        break;
                                                        case "5";
                                                        $slot = "Gloves";
                                                        break;
                                                        case "6";
                                                        $slot = "Pants";
                                                        break;
                                                        case "7";
                                                        $slot = "Shoes";
                                                        break;
                                                        case "8";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Sex: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Lv. Min: <?=$item['ResLevel']?></td>
												</tr>
												<tr>
													<td width="110" valign="top">
													Price: <?=$item['CashPrice']?></td>
												</tr>
												<tr>
													<td width="110">
													<p align="center">
													<a href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>"><img border="0" src="images/buy_btn.jpg" width="50" height="20"></a></td>
												</tr>
												<tr>
													<td width="110">&nbsp;</td>
												</tr>
												<tr>
													<td width="105">&nbsp;</td>
													<td width="110">&nbsp;</td>
												</tr>
											</table>

</body>

</html>
</td>                                                <?
                                                 $count++;
                                            }
                                        }   ?>
											<td width="30">
											&nbsp;<p>&nbsp;</p>
											<p>&nbsp;</p>
											<p>&nbsp;</td>
										</tr>

										<tr>
											<td width="445" colspan="2">&nbsp;</td>
										</tr>

										<tr>
											<td width="12" colspan="2"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
    }  }



//Items details




if(!function_exists("ShowItemsDetails")){
    function ShowItemsDetails(){
    if($_GET['id'] == ""){
        re_dir("index.php");
    }
    $itemid = clean($_GET['id']);
    $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$itemid'");
    $item = mssql_fetch_assoc($res);
    ?>
    					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="429">
											<img border="0" src="images/inf/itemdetails.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>

										<tr>
											<td width="438">
											<table border="0" style="border-collapse: collapse" width="436" height="100%">
												<tr>
													<td width="122" valign="top">
													<table border="0" style="border-collapse: collapse" width="122">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">&nbsp;</td>
															<td width="14">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">
															<img border="2" src="images/shop/<?=$item['WebImgName']?>" width="100" height="100"></td>
															<td width="14">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="91">&nbsp;</td>
															<td width="14">&nbsp;</td>
														</tr>
													</table>
													</td>
													<td width="310" valign="top">
													<table border="0" style="border-collapse: collapse" width="310" height="100%">
														<tr>
															<td height="15" width="308" colspan="2">
															</td>
														</tr>
														<tr>
															<td height="15" width="308" colspan="2">
												<!-- //left item picture -->
												<!-- right item info box -->
															<div class="item_name">
																<b>
																<span class="item_name">
																<font color="#FF00FF"><?=$item['Name']?></fonts></span></b></div>
                                                                                                                                <br><font color="#FFFFFF"><?=$item['Description']?></fonts>
															</td>
														</tr>
														<tr>
															<td width="55" height="15">
															</td>
															<td width="251" height="15">
															</td>
														</tr>
														<tr>
															<td width="55"><b>Type:</b></td>
															<td width="251"><?
                                                    switch ( $item['Slot'] ){
                                                        case "1";
                                                        $slot = "Melee";
                                                        break;
                                                        case "2";
                                                        $slot = "Ranged";
                                                        break;
                                                        case "3";
                                                        $slot = "Head";
                                                        break;
                                                        case "4";
                                                        $slot = "Shirt";
                                                        break;
                                                        case "5";
                                                        $slot = "Gloves";
                                                        break;
                                                        case "6";
                                                        $slot = "Pants";
                                                        break;
                                                        case "7";
                                                        $slot = "Shoes";
                                                        break;
                                                        case "8";
                                                        $slot = "Special";
                                                        break;
                                                    } echo $slot;

                                                        ?></td>
														</tr>
														<tr>
															<td width="55"><b>Sex:</b></td>
															<td width="251">
                                                            <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Man";
                                                    break;
                                                    case "1";
                                                    $sex = "Woman";
                                                    break;
                                                    case "2";
                                                    $sex = "All";
                                                    break;
                                                    } echo $sex;
                                                    ?></td>
														</tr>
														<tr>
															<td width="55"><b>Level:</b></td>
															<td width="251"><?=$item['ResLevel']?></td>
														</tr>
														<tr>
															<td width="55">
															<b>Weight:</b></td>
															<td width="251"><?=$item['Weight']?></td>
														</tr>
														<tr>
															<td width="55"><b>Price:</b></td>
															<td width="251"><?=$item['CashPrice']?></td>
														</tr>
														<tr>
															<td width="55">&nbsp;</td>
															<td width="251">&nbsp;</td>
														</tr>
													</table>
													</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">
													<div align="center">
														<table border="0" style="border-collapse: collapse; background-image: url('images/iteminfo.jpg'); background-repeat: no-repeat; background-position: center top" width="422" height="110">
															<tr>
																<td>
																<table border="0" style="border-collapse: collapse" width="420" height="100%">
																	<tr>
																		<td width="130" height="27" colspan="4">&nbsp;</td>
																		<td width="146" height="27" colspan="3">&nbsp;</td>
																		<td width="128" height="27" colspan="3">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>
																		Damage</b></td>
																		<td width="44" align="right">
																		<?=$item['Damage']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>HP</b></td>
																		<td width="48" align="right">
																		<?=$item['HP']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>FR</b></td>
																		<td width="62" align="right">
																		<?=$item['FR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>Delay</b></td>
																		<td width="44" align="right">
																		<?=$item['Delay']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>AP</b></td>
																		<td width="48" align="right">
																		<?=$item['AP']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>PR</b></td>
																		<td width="62" align="right">
																		<?=$item['PR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>
																		Magazine</b></td>
																		<td width="44" align="right">
																		<?=$item['Magazine']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>Max
																		Weight</b></td>
																		<td width="48" align="right">
																		<?=$item['MaxWeight']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>CR</b></td>
																		<td width="62" align="right">
																		<?=$item['CR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">
																		<b>Reload
																		Time</b></td>
																		<td width="44" align="right">
																		<?=$item['ReloadTime']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="88">
																		<b>
																		Control</b></td>
																		<td width="48" align="right">
																		<?=$item['Control']?></td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">
																		<b>LR</b></td>
																		<td width="62" align="right">
																		<?=$item['LR']?></td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="4">&nbsp;</td>
																		<td width="88">
																		<b>Max
																		Bullet</b></td>
																		<td width="44" align="right">
																		<?=$item['MaxBullet']?></td>
																		<td width="7" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="75">
																		<b>
																		Duration</b></td>
																		<td width="48" align="right">
																		Unlimited</td>
																		<td width="4" style="background-image: url('images/table_sep.jpg')">&nbsp;</td>
																		<td width="67">&nbsp;</td>
																		<td width="62">&nbsp;</td>
																		<td width="4">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="7">&nbsp;</td>
																		<td width="75">&nbsp;</td>
																		<td width="51" colspan="2">&nbsp;</td>
																		<td width="88">&nbsp;</td>
																		<td width="54" colspan="2">&nbsp;</td>
																		<td width="67">&nbsp;</td>
																		<td width="68" colspan="2">&nbsp;</td>
																	</tr>
																</table>
																</td>
															</tr>
														</table>
													</div>
													</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">&nbsp;</td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">
													<p align="center">
													<a href="index.php?do=rzitemshop&sub=buyitem&expand=1&itemid=<?=$item['CSID']?>">
													<img border="0" src="images/buyitem.jpg" width="50" height="20"></a>&nbsp;
													<a href="index.php?do=rzitemshop&sub=giftitem&expand=1&itemid=<?=$item['CSID']?>">
													<img border="0" src="images/giftitem.jpg" width="50" height="20"></a></td>
												</tr>
												<tr>
													<td width="432" valign="top" colspan="2">&nbsp;</td>
												</tr>
											</table>
											</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?

}   }


if(!function_exists("ShowBuyItem")){
    function ShowBuyItem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php?do=login");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
       if(isset($_POST['submit'])){
            $itemid = clean($_POST['ItemID']);
            $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['RZCoins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By LaMbDa FrOm SpAiN!!! :)");
            }
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$aid', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET RZCoins = '$updatecoins' WHERE AID = '$aid'");
            msgbox("Item purchased correctly, you can get it in NighT GamerZ central bank","index.php?do=rzitemshop&sub=listallitems&expand=1&type=1");
       }
       ?>
       					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="429">
											<img border="0" src="images/inf/buyitem.png" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>

										<tr>
											<td width="438">
											<table border="0" style="border-collapse: collapse" width="436" height="100%">
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Name of 
													item</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['Name']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Bill  
													Current</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$_SESSION['UserID']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Price</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['CashPrice']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">RZ Coins 
													you have</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$acc['RZCoins']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">RZ Coins 
													To you later</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?
                                                    $result = $acc['RZCoins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "<b>RZ Coins insufficient</b>";
                                                    }else{
                                                        $boton = "<input type='submit' value='Buy item' name='submit'>";
                                                    }

                                                        echo $acc['RZCoins']-$item['CashPrice'];?> </b></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<p align="center">
													<font color="#FF0000"><b>
													NOTE: If you buy an item and then do not want, or is mistaken, we are not responsible</b></font></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<form method="POST" action="index.php?do=rzitemshop&sub=buyitem">
														<p align="center">    
														<?=$boton?>
														<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
														</p>
													</form>
													</td>
												</tr>
											</table>
											</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

<?

}   }
if(!function_exists("ShowGiftItem")){
    function ShowgiftItem(){
       if($_SESSION['AID'] == ""){
            re_dir("index.php?do=login");
       }
       $item2 = clean($_GET['itemid']);
       $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    $itemid = clean($_POST['ItemID']);
    $item2 = clean($_GET['itemid']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?do=rzitemshop&sub=listallitems&expand=1&type=1");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['RZCoins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By Joker!!! :)");
            }
            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$UserAID', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET RZCoins = '$updatecoins' WHERE AID = '$aid'");
            msgbox("Item purchased and gifted correctly, your friend can get it in NighT GamerZ central bank","index.php?do=rzitemshop&sub=listallitems&expand=1&type=1");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?do=rzitemshop&sub=listallitems&expand=1&type=1");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
       $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$item2'");
       $item = mssql_fetch_assoc($res);
       $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
       $acc = mssql_fetch_assoc($res2);
            $res = mssql_query_logged("SELECT * FROM RZCashShop WHERE CSID = '$itemid'");
            $item = mssql_fetch_assoc($res);
            $res2 = mssql_query_logged("SELECT RZCoins FROM Login WHERE AID = '".$_SESSION['AID']."'");
            $acc = mssql_fetch_assoc($res2);
            $aid = $_SESSION['AID'];
            $updatecoins = $acc['RZCoins'] - $item['CashPrice'];
            $zitemid = $item['ItemID'];
            if($updatecoins < 0){
                die("No Bug here :) CoDeD By Joker!!! :)");
            }

            mssql_query_logged("INSERT INTO AccountItem ([ShopItemID], [AID], [ItemID], [RentDate], [Cnt])VALUES('$itemid', '$UserAID', '$zitemid', GETDATE(), 0)");
            mssql_query_logged("UPDATE Login SET RZCoins = '$updatecoins' WHERE AID = '$aid'");
            msgbox("Item purchased and gifted correctly, your friend can get it in NighT GamerZ central bank","index.php?do=rzitemshop&sub=listallitems&expand=1&type=1");
        }
    }

}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>


	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="429">
											<img border="0" src="images/inf/gift3.png" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>

										<tr>
											<td width="438">
									<form name="gift" method="POST" action="">											<table border="0" style="border-collapse: collapse" width="436" height="100%">
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Name of 
													item</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['Name']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Bill  
													Current</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$_SESSION['UserID']?></b></td>
												</tr>
										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">Gifting User ID
											</option>
											<option value="2">Gifting Character Name
											</option>
											</select></td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">Price</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$item['CashPrice']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">RZ Coins 
													you have</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?=$acc['RZCoins']?></b></td>
												</tr>
												<tr>
													<td width="200" valign="top">
													<p align="right">RZ Coins 
													To you later</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">
													<b><?
                                                    $result = $acc['RZCoins']-$item['CashPrice'];
                                                    if($result < 0){
                                                        $boton = "<b>RZ Coins insufficient</b>";
                                                    }else{
                                                        $boton = "<input type='submit' value='Gift Item' name='submit'>";
                                                    }

                                                        echo $acc['RZCoins']-$item['CashPrice'];?> </b></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<p align="center">
													<font color="#FF0000"><b>
													NOTE: If you gift an item and then do not want, or is mistaken, we are not responsible</b></font></td>
												</tr>
												<tr>
													<td width="200" valign="top">&nbsp;</td>
													<td width="8" valign="top">&nbsp;</td>
													<td width="222" valign="top">&nbsp;</td>
												</tr>
												<tr>
													<td width="430" valign="top" colspan="3">
													<form method="POST" action="index.php?do=rzitemshop&sub=buyitem">
														<p align="center">    
														<?=$boton?>
														<input type="hidden" value="<?=$_GET['itemid']?>" name="ItemID">
														</p>
													</form>
													</td>
												</tr>
											</table>
											</td>
										</tr>

										<tr>
											<td width="1"></td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>


<?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "listallitems";
        ListAllItems();
    break;
    case "details";
        ShowItemsDetails();
    break;
    case "buyitem";
        ShowBuyItem();
    break;
    case "giftitem";
        ShowGiftItem();
    break;
}
}





?>