<?php
?>
<?
$res = mssql_query("SELECT TOP 6 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/clanranking.gif" height="30" width="195">&nbsp;</td>
  </tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>No data</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4"><img src="http://174.48.46.43/NighT/<?=($clan['EmblemUrl'] == "") ? 'http://174.48.46.43/NighT/Images/no_emblem.png' : $clan['EmblemUrl']?>" width="25" height="25"></td>
										<td width="142"> <?=$clan['Name']?></td>
										<td width="41">
										<p align="center"><b><?=number_format($clan['Point'],0,'','.');?></b></td>
									</tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table><p align="center"><a href="?do=ranking&sub=clan&expand=1&pagina=1">Ver Mais</a></p>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
							</tr>
</table>
