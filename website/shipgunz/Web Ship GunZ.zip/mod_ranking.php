<?
if ( antisql($_GET['expand'] == 1) ){
?>
				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('images/subbar.png'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=ranking&sub=individual&expand=1">
					<img border="0" src="images/subbar/individualranking.jpg" width="99" height="13"></a><a href="index.php?do=ranking&sub=clan&expand=1&pagina=1"><img border="0" src="images/subbar/clanranking.jpg" width="99" height="13"></a></td>
				</tr>

<? }

if ( antisql($_GET['expand'] == 0) ){

switch($_GET['sub']){
    case "individual";
        ShowIndividualRanking();
    break;
    case "clan";
        ShowClanRanking();
    break;
    case "hof";
        ShowHofRanking();
    break;
}
}


if(!function_exists("ShowIndividualRanking")){
function ShowIndividualRanking(){
    
	switch( antisql($_GET['pagina']) )
          {
              case "1":
                  $posicao = "Rank >= 1 AND Rank <= 50";
              break;
              case "2":
                  $posicao = "Rank > 50 AND Rank <= 100";
              break;
              case "3":
                  $posicao = "Rank > 100 AND Rank <= 150";
              break;
              case "4":
                  $posicao = "Rank > 150 AND Rank <= 200";
              break;
              case "5":
                  $posicao = "Rank > 200 AND Rank <= 250";
              break;
              case "6":
                  $posicao = "Rank > 250 AND Rank <= 300";
              break;
              case "7":
                  $posicao = "Rank > 300 AND Rank <= 350";
              break;
              case "8":
                  $posicao = "Rank > 350 AND Rank <= 400";
              break;
              case "9":
                  $posicao = "Rank > 400 AND Rank <= 450";
              break;
              case "10":
                  $posicao = "Rank > 450 AND Rank <= 500";
              break;
              default:
                  $posicao = "Rank <= 50";
              break;
          }
	$chares = mssql_query("SELECT TOP 50 * FROM TotalRanking WHERE $posicao ORDER BY Rank ASC");


?>

<head>
<meta http-equiv="Content-Language" content="BR">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center"></p>
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/individualranking.png"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="590" valign="top"><p>
									<div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="ranking" />
                                    <p align="center">
                                    <select name="sub">
                                    <option value="individual">Character Name</option>                                    
                                    </select>
                                    &nbsp;
                                    <input type="text" name="name" />
                                    <input type="submit" value="Search" />
                                    </p>
					                </form></div></td>
								</tr>
										<tr>
											<td width="434">
											<img border="0" src="images/ranking_legend.jpg" width="437" height="30"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/rankinglist.jpg'); background-repeat: no-repeat; background-position: center top">

														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/rankinlist_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
<?
                                                                    while($char = mssql_fetch_assoc($chares)){
                                                                    $count++;
                                                                    ?>
																	<tr>
																		<td width="45">
																		<p align="center">
																		<?=$char['Rank']?></td>
																		<td width="88">
																		<p align="center">
																		<b>
																		<span class="guild_name">
																		<a href="index.php?do=charinfo&cid=<?=$char['CID']?>"><?=FormatCharName($char['CID'])?></a></span></b>
																		</td>
																		<td width="33">
																		<p align="center">
																		<?=$char['Level']?></td>
																		<td width="127">
																		<p align="center">
																		<?=number_format($char['XP'],0,'','.');?></td>
																		<td width="114">
																		<p align="center">
																		<span style="font-size: 7pt">
																		<?=GetKDRatio($char['KillCount'], $char['DeathCount'])?>
																		</span></td>
																	</tr> <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
<Center><font color='#FFFFFF'><a href="index.php?do=ranking&sub=individual&expand=1">[1-50]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&pagina=2">[51-100]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&pagina=3">[101-150]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&pagina=4">[151-200]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&pagina=5">[201-250]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&pagina=6">[251-300]</a></font></center> 
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }

if(!function_exists("ShowClanRanking")){
function ShowClanRanking(){

	switch( antisql($_GET['pagina']) )
          {
              case "1":
                  $posicao = "Ranking >= 1 AND Ranking <= 20";
              break;
              case "2":
                  $posicao = "Ranking > 21 AND Ranking <= 40";
              break;
              case "3":
                  $posicao = "Ranking > 41 AND Ranking <= 60";
              break;
              case "4":
                  $posicao = "Ranking > 61 AND Ranking <= 80";
              break;
              case "5":
                  $posicao = "Ranking > 81 AND Ranking <= 100";
              break;
              default:
                  $posicao = "Ranking = 0";
              break;
                                                        }

$chares = mssql_query("SELECT TOP 100 * FROM CLAN WHERE $posicao AND DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
    $count = 0;
    ?>
	<?
                                            $res = mssql_query("SELECT TOP 50 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC ");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "http://174.48.46.43/NighT/") ? "no_emblem.jpg" : $resa->EmblemUrl;

                                            if($Count == 4)
                                                break;
                                            else
                                                $Count++;
                                        }

?>
<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/clanranking.png" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="590" valign="top"><p>
									<div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="ranking" />
                                    <p align="center">
                                    <select name="sub">
                                    <option value="clan">Clan Name</option>
                                    </select>
                                    &nbsp;
                                    <input type="text" name="name" />
                                    <input type="submit" value="Search" />
                                    </p>
					                </form></div></td>
								</tr>
										<tr>
											<td width="434">
											  <p>
										<table></table>
<center><table width="400" border="0">
  <tr>
    <td width="100"><center><img src="http://174.48.46.43/NighT/<?=($FirstClan[0][EmblemURL] == "http://174.48.46.43/NighT/") ? "no_emblem.jpg" : $FirstClan[0][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></center></td>
    <td width="100"><center><img src="http://174.48.46.43/NighT/<?=($FirstClan[1][EmblemURL] == "http://174.48.46.43/NighT/") ? "no_emblem.jpg" : $FirstClan[1][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></center></td>
    <td width="100"><center><img src="http://174.48.46.43/NighT/<?=($FirstClan[2][EmblemURL] == "http://174.48.46.43/NighT/") ? "no_emblem.jpg" : $FirstClan[2][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></center></td>
    <td width="100"><center><img src="http://174.48.46.43/NighT/<?=($FirstClan[3][EmblemURL] == "http://174.48.46.43/NighT/") ? "no_emblem.jpg" : $FirstClan[3][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></center></td>
  </tr>
  <tr>
    <td><center><b><font color="#ff0000"><?=($FirstClan[0][Name] == "http://174.48.46.43;NighT/") ? "Sem Clan" : $FirstClan[0][Name];?></font></b></center></td>
    <td><center><b><font color="#ff0000"><?=($FirstClan[1][Name] == "http://174.48.46.43/NighT/") ? "Sem Clan" : $FirstClan[1][Name];?></b></center></td>
    <td><center><b><font color="#ff0000"><?=($FirstClan[2][Name] == "http://174.48.46.43/NighT/") ? "Sem Clan" : $FirstClan[2][Name];?></b></center></td>
    <td><center><b><font color="#ff0000"><?=($FirstClan[3][Name] == "http://174.48.46.43/NighT/") ? "Sem Clan" : $FirstClan[3][Name];?></b></center></td>
  </tr>
</table></center>
</p><br>
										    </td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/clanranking_list.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/clanranking_list_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                                     <? while($char = mssql_fetch_assoc($chares)){   ?>

                                                                    <tr>
																		<td width="45">
																		<p align="center">
																		<?=$char['Ranking']?></td>
																		<td width="90">
																		<p align="center">
																		<b><?=$char['Name']?></b></td>
																		<td width="76">
																		<p align="center">
																		<? $chares2 = mssql_query("SELECT * FROM Character WHERE CID = '" . ($char['MasterCID']) . "'"); 
                                                                            $c = mssql_fetch_assoc($chares2);
                                                                            echo $c['Name'];
                                                                        ?></td>
																		<td width="71">
																		<p align="center">
																		<?=$char['Wins']?>/<?=$char['Losses']?></td>
																		<td width="40">
																		<p align="center">
																		<img src="http://174.48.46.43/NighT/<?=($char['EmblemUrl'] == "") ? "no_emblem.jpg" : $char['EmblemUrl']?>" width="35" height="35">
																		</td>
																		<td width="83">
																		<p align="center">
																		<?=number_format($char['Point'],0,'','.');?></td>
																	</tr>  <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div><br>
<Center><font color='#FFFFFF'><a href="index.php?do=ranking&sub=clan&expand=1&pagina1">[1-20]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&pagina=2">[21-40]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&pagina=3">[41-60]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&pagina=4">[61-80]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&pagina=5">[81-100]</a></a></font></center> 
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }

?>