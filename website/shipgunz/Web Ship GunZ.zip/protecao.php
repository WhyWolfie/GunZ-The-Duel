<?php

$log_name = "log.txt";
$ban_msg = "Banned.";

/* Maximum number of requests allowed per minute */
$req_lim = 30;


$ip_address = $_SERVER["REMOTE_ADDR"];
$time = date("i");

function sanitize($sql)
{
return (htmlentities(str_replace("'", "''", $sql)));
}

foreach ($_POST as $value)
{
$value = sanitize($value);
}

foreach ($_GET as $value)
{
$value = sanitize($value);
}


$data = file_get_contents($log_name);
$line = substr(strstr($data, $ip_address), 0, strpos(strstr($data, $ip_address), ';'));
$ts = substr($line, strpos($line, ':') + 1, 2);
$req = substr(strstr($line, $ts), strpos(strstr($line, $ts), ':') + 1, 2);

$ts_pos = strpos($data, $ip_address) + strlen($ip_address) + 1;
$req_pos = $ts_pos + 3;
if ($line)
{
if ($ts - $time != 0)
{
$data[$req_pos] = 0;
$data[$req_pos + 1] = 0;
$data[$ts_pos] = $time[0];
$data[$ts_pos + 1] = $time[1];
}
else if ($req >= $req_lim)
{
$f = fopen('.htaccess', 'a');
if (fread($f, 16) != "order allow,deny")
{
fwrite($f, "order allow,deny\nallow from all\n");
}
fwrite($f, "deny from $ip_address\n");
fclose($f);
die($ban_msg);
}

if ($data[$req_pos + 1] == 9)
{
$data[$req_pos + 1] = 0;
$data[$req_pos] = $data[$req_pos] + 1;
}
else
{
$data[$req_pos + 1] = $data[$req_pos + 1] + 1;
}

$file = fopen($log_name, 'w');
fwrite($file, $data);
fclose($file);
}
else
{
$date = date("F j, Y");
$file = fopen($log_name, 'a+');
if (fread($file, 3) != "Log")
{
fwrite($file, "Log made on $date\n");
}
fwrite($file, "$ip_address:$time:01;\n");
fclose($file);
}

?> 