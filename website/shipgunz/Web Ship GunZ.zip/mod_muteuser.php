<?

include "authadmin.php";

if (isset($_POST['submit'])){
    $type = clean($_POST['type']);
    $id = clean($_POST['id']);
    $gmid = clean($_POST['gmid']);
    $reason = clean($_POST['reason']);
    $custom = clean($_POST['cstom']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesnt exist","index.php?do=muteuser");
}else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            if($_POST['C1'] == "ON"){
            }
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE UserID = '$userID'");
            mssql_query_logged("INSERT INTO Banneduser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$gmid', '$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the ID $id has been muted","index.php?do=muteuser");
        }
    }else{
        $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesnt exist","index.php?do=muteuser");
        }else{
            $res = mssql_query_logged("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            mssql_query_logged("UPDATE Account SET UGradeID = '104' WHERE AID = '$UserAID'");
            mssql_query_logged("INSERT INTO Banneduser (GMUserID, UserID, IP, BanReason, BanDate, IPBANMUTE)VALUES('$gmid', '$id', 'Undefined', '$reason', GETDATE(), 'Mute')");
            msgbox("The user with the character $id has been muted","index.php?do=muteuser");
        }
    }

}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>


	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form name="mute" method="POST" action="index.php?do=muteuser"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/resuser.png" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">GM User ID</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="gmid" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">User ID
											</option>
											<option value="2">Character Name
											</option>
											</select></td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">Mute Reason</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<select size="1" name="reason" onchange="UpdateCustom()">
											<option selected value="Spamming looby chat">Spamming looby chat
											</option>
											<option value="Spamming gameroom chat">Spamming gameroom chat
											</option>
											<option value="Spamming ingame chat">Spamming ingame chat
											</option>
											<option value="Insulting the staff">Insulting the staff
											</option>
											<option value="Insulting Player">Insulting player
											</option>
											<option value="No reason specified">No reason specified
											</option>
											<option value="1">Other (specify below)</option>
											</select></td>
										</tr>
										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">
											<textarea disabled rows="9" name="cstom" cols="30"></textarea></td>
										</tr>

										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Mute User" name="submit"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>