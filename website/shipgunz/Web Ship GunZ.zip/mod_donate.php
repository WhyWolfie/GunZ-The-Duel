<?

if( $_SESSION['AID'] == "" )
{
msgBox("Voc� n�o Pode Compra SG Coins Logue-se Primeiro!","index.php?do=login");
    die();
}

    $ronaldo1 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");

    if( mssql_num_rows($ronaldo1) < 1 )
    {
	msgBox("Voc� n�o Pode Compra SG Coins Loge-se Primeiro!","index.php?do=login");
    	die();
    }

?>
<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
</head>

	
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><img border="0" src="images/inf/buycoins.png" width="414" height="19"></td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div align="center">
                                              <table width="432" border="0">
                                                <tr>
                                                  <td colspan="3"><em><b>Buy SG Coins by PayPal </b></em></td>
                                                </tr>
                                                <tr>
                                                  <td width="59" rowspan="2"><img src="images/pay_2.gif" width="91" height="89" /></td>
                                                  <td width="357"> <p>O servi&ccedil;o de pagamentos PayPal &eacute; amplamente reconhecida pela sua r&aacute;pida e segura.&nbsp;PayPal oferece-lhe a utiliza&ccedil;&atilde;o das empresas mais populares para suas transa&ccedil;&otilde;es de cart&atilde;o de cr&eacute;dito.</p>
                                                    <p><br />
                                                    <strong>scolha um dos nossos diversos planos de pagamento abaixo:</strong> </p></td>
                                                </tr>
                                                <tr>
                                                  <td>                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <input type="hidden" name="cmd" value="_xclick" />
                                                <input type="hidden" name="business" value="cantiflarosa3@hotmail.com" />
                                                <input type="hidden" name="lc" value="US">
                                                <input type="hidden" name="currency_code" value="USD" />
                                                <input type="hidden" name="no_note" value="1" />
                                                <input type="hidden" name="no_shipping" value="1" />
                                                <input type="hidden" name="tax" value="0.50" />
                                                <input type="hidden" name="bn" value="PP-BuyNowBF" />
                                                <input type="hidden" name="return" value="http://night-gamerz.sytes.net/index.php?rg=ipn" />
                                                <input type="hidden" name="cancel_return" value="http://night-gamerz.sytes.net" />
                                                <input type="hidden" name="notify_url" value="http://night-gamerz.sytes.net/index.php?rg=ipn" />
                                                <input type="hidden" name="rm" value="2" />

                                                Donate:&nbsp;
                                                <select name="amount" onChange="updateForm();" class="Login">
                                                    <option value="1.00">1 Dollars // 2 Reais</option>
                                                    <option value="5.00" selected>5 Dollars // 10 Reais</option>
                                                    <option value="10.00">10 Dollars // 20 Reais</option>
                                                    <option value="15.00">15 Dollars // 30 Reais</option>
                                                    <option value="20.00">20 Dollars // 40 Reais</option>
                                                    <option value="25.00">25 Dollars // 50 Reais</option>
                                                    <option value="30.00">30 Dollars // 60 Reais</option>
                                                    <option value="35.00">35 Dollars // 70 Reais</option>
                                                    <option value="40.00">40 Dollars // 80 Reais</option>
                                                    <option value="45.00">45 Dollars // 90 Reais</option>
                                                    <option value="50.00">50 Dollars // 100 Reais</option>
												    <option value="75.00">75 Dollars // 150 Reais</option>
												    <option value="100.00">100 Dollars // 200 Reais</option>
                                                </select>
                                                <br />
Com essa doa&ccedil;&atilde;o, voc&ecirc; receber&aacute; <span id="coins">25</span> SG Coins

                                                <input type="hidden" name="item_name" value="25 RZCoins">
                                                <input type="hidden" name="item_number" value="25">
                                                <input type="hidden" name="custom" value="<?php echo $_SESSION['AID']; ?>">
                                                <script type="text/javascript">
                                                    updateForm();
                                                </script>
                                                <br /><br />
                                                  <input name="submit" type="submit" id="submit" value="Compra SG Coins">
                                                </form></td>
                                                </tr>
                                              </table>
											  </div>
											  <div align="center"></div>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	