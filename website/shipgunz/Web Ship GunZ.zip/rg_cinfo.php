<?
SetTitle("Final Revolution 2010 - Clan Information");
    ?>
<?
$cinfo = clean($_GET['cinfo']);
$query = mssql_query("SELECT * FROM Clan WHERE Name = '$cinfo' AND DeleteFlag=0");
$clan = mssql_fetch_object($query);
$clid = $clan->CLID;
?> 
<table width="490" border="0" align="center" class="login4">
                          <tr>
                            <td height="5" class="Estilo1" align="center"></td>
                          </tr>
                          <tr>
                            <td height="35" class="Estilo2" align="center">
                               Clan, <?=$clan->Name?> 
                              Information</td>
                          </tr>
                          <tr>
                            <td class="Estilo1" align="center" valign="top"><table width="475" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="450" border="0" align="center">
                                  <tr>
                                    <td height="18" colspan="2" align="center" class="estilo1"><img src="http://night-gamerz.sytes.net/NighT/<?=($clan->EmblemUrl == "") ? "clan/emblem/no_emblem.png" : $clan->EmblemUrl?>" width="64" height="64"></td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                         <tr>
                                    <td align="left" class="estilo1">Rank:</td>
                                    <td align="left" class="estilo1"><?=$clan->Ranking?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Points:</td>
                                    <td align="left" class="estilo1"><?=$clan->Point?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Win:</td>
                                    <td align="left" class="estilo1"><?=$clan->Wins?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Losses:</td>
                                    <td align="left" class="estilo1"><?=$clan->Losses?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Draw:</td>
                                    <td align="left" class="estilo1"><?=$clan->Draws?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ratio:</td>
                                    <td align="left" class="estilo1"><?=Porcentagem($clan->Wins, $clan->Losses)?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Created:</td>
                                    <td align="left" class="estilo1"><?=$clan->RegDate?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Members:</td>
                                    <td align="left" class="estilo1"><?
     $c = mssql_fetch_assoc(mssql_query("SELECT COUNT(*) AS total FROM ClanMember WHERE CLID = '$clid'"));
    echo $c['total']; ?></td>
                                  </tr>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top"><table width="450" border="0" cellpadding="0" cellspacing="0">
                                  <tr>
                                    <td align="center" class="estilo1">Character</td>
                                    <td align="center" class="estilo1">Rank</td>
                                    <td align="center" class="estilo1">Joined</td>
                                    <td align="center" class="estilo1">Points</td>
                                  </tr>
      <?

$query2 = mssql_query("SELECT * FROM ClanMember WHERE CLID = $clid");


while($char = mssql_fetch_object($query2)){

switch ($char->Grade){
    case "9";
       $grade = "Member";
    break;
    case "2";
       $grade = "Administrator";
    break;
    case "1";
       $grade = "Leader";
    break;
}


?>
                                  <tr>
                                    <td align="center" class="estilo1"><a href="index.php?rg=pinfo&cid=<?=($char->CID)?>"><?=FormatCharName($char->CID)?></a></td>
                                    <td align="center" class="estilo1"><? echo $grade; ?></td>
                                    <td align="center" class="estilo1"><?=$char->RegDate?></td>
                                    <td align="center" class="estilo1"><?=$char->ContPoint?></td>
                                  </tr>
								  <? } ?>
                                </table></td>
                              </tr>
                              <tr>
                                <td align="center" valign="top" height="10"></td>
                              </tr>
                            </table></td>
                          </tr>
</table>
<?
    $cid = antisql($_GET['cid']); // Seleciona a CID do Char
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid"); //Seleciona a UGradeID do Char
    $char2 = mssql_fetch_assoc($res2);
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); //Seleciona a CLID do Char na Tabela dos membros do Cla
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); // Seleciona o nome do Cl� do Char.
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; // Caso o personagem n�o tenha clan msotra somente um tra�o

    /*mssql_query("UPDATE Character SET Views = Views + 1 WHERE CID = $cid");*/ // Adiciona uma visualiza��o ao personagem
    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>



<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="348">
											<img border="0" src="images/inf/staff2.png" width="414" height="19"></td>
											<td width="8">&nbsp;</td>
										</tr>
	
										<tr>
											<td width="-14"></td>
										</tr>
	
										<tr>
											<td width="431">&nbsp;
											</td>
										</tr>
	
										<tr>
											<td width="432">
											<table border="0" style="border-collapse: collapse" width="100%" id="table13">
											<tr>
												<td width="1">&nbsp;</td>
												<td width="417"><strong>Informa&ccedil;&otilde;es do Personagem:
												    </strong><?=FormatCharName($char['CID'])?></td>
											</tr>
											<tr>
												<td colspan="4"><table width="100%" border="0">
												  <tr>

												    <td width="49%">&nbsp;</td>
											      </tr>
												  <tr>
												    <td width="49%"><strong>Dados Pessoais</strong></td>
												    <td width="2%">&nbsp;</td>
												    <td width="49%"><strong>Dados do Personagem</strong></td>
											      </tr>
												  <tr>
												    <td width="49%">&nbsp;</td>
											      </tr>
												  <tr>
												    <td><strong>Nome:</strong> <?=$char2['Name']?></td>
												    <td>&nbsp;</td>
												    <td><strong>Nome:</strong> <?=$char['Name']?></td>
											      </tr>
												  <tr>
												    <td><strong>E-mail:</strong> <?=$char2['Email']?></td>
												    <td>&nbsp;</td>
												    <td><strong>Level:</strong> <?=$char['Level']?></td>
											      </tr>
												  <tr>
												    <td><strong>Sexo:</strong> <?=$char2['Sex']?></td>
												    <td>&nbsp;</td>
												    <td><strong>Ranking:</strong> <?=$char['Ranking']?></td>
											      </tr>
												  <tr>
												    <td><strong>Idade:</strong> <?=$char2['Age']?></td>
												    <td>&nbsp;</td>
												    <td><strong>Experiencia:</strong> <?=number_format($char['XP'],0,'','.');?></td>
											      </tr>
												  <tr>
												    <td><strong>Tipo Conta:</strong> <?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "6";
                                                        $ugradeid = "Donate Preto";
                                                        break;
                                                        case "4";
                                                        $ugradeid = "Donate Roza";
                                                        break;
                                                        case "3";
                                                        $ugradeid = "Donate Roxo";
                                                        break;
                                                        case "0";
                                                        $ugradeid = "Normal";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "5";
                                                        $ugradeid = "V.I.P";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Donate Azul";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GameMaster Hide";
                                                        break;
							case "253";
                                                        $ugradeid = "Banido";
                                                        break;
							case "254";
                                                        $ugradeid = "GameMaster";
                                                        break;
							case "255";
                                                        $ugradeid = "Administrador";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
												    <td>&nbsp;</td>
												    <td><strong>Bounty:</strong> <?=number_format($char['BP'],0,'','.');?></td>
											      </tr>
												  <tr>
												    <td><strong>Visualiza&ccedil;&otilde;es:</strong> <?=$char['Views']?></td>
												    <td>&nbsp;</td>
												    <td><strong>Vit&oacute;rias/Derrotas:</strong> <?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
											      </tr>
											      </tr>
												  <tr>
												    <td><strong>Registrado dia:</strong> <? echo $data;?></td>
												    <td>&nbsp;</td>
												    <td><strong>Cl�:</strong> <?=$claninfo['Name']?></td>
											      </tr>
											      </tr>
												  <tr>
												    <td><strong>AID:</strong> <?=$char['AID']?></td>
												    <td>&nbsp;</td>
												    <td><strong>CID:</strong> <?=$char['CID']?></td>
											      </tr>
											      <tr>
												    <td>&nbsp;</td>
												    <td>&nbsp;</td>
												    <td></td>
											      </tr>
											      <tr>
												    <td><a href="index.php?do=ranking&sub=individual&expand=1"><b>Voltar</b></a></td>
												    <td>&nbsp;</td>
												    <td>&nbsp;</td>
											      </tr>
												  </table>												  
												<br>
</td>
											  </tr>

										</table>
											</td>
										</tr>
	
										<tr>
											<td width="432">&nbsp;
											</td>
										</tr>
	
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>