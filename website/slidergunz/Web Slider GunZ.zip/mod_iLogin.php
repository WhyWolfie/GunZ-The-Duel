<?
if ($_SESSION['AID'] == ""){
?>
<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account.jpg" height="30" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<form method="POST" action="index.php?do=login&header=1" name="login">
									<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">

										<tr>
											<td width="191" colspan="4">&nbsp;</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="text" name="userid" size="14" style="background-image: url('images/usernamebg.jpg'); background-position: left center" class="login"></td>
											<td width="62" rowspan="2">
											<p align="center">

											<input type="submit" value="Login" name="submit"></td>
											<td width="8" rowspan="2">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="111">
											<input type="password" name="pasw" size="14" style="background-image: url('images/passwordbg.jpg'); background-position: left center" class="login" id="input"></td>
										</tr>

										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2">
											<input type="checkbox" name="cookie" value="ON" checked>Log me in automatically</td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>

											<td width="4">&nbsp;</td>
											<td width="175" colspan="2" bgcolor="#1A1A1A">&nbsp;
											</td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2" bgcolor="#1A1A1A">

											<span style="font-size: 7pt">&nbsp;�
											<a href="/register.php">
											Register!</a></span></td>
											<td width="8">&nbsp;
											</td>
										</tr>
										<tr>
											<td width="4">&nbsp;</td>
											<td width="175" colspan="2" bgcolor="#1A1A1A">

											<span style="font-size: 7pt">&nbsp;�
											<a href="index.php?do=login&action=resetpwd">
											Reset Password?</a></span></td>
											<td width="8">&nbsp;
											</td>
										</tr>
									</table>
								</form>
								</td>

							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22">&nbsp;</td>
							</tr>
						</table>



<?
}else{
//And again.
$res = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$d = mssql_fetch_assoc($res);

//No shit?
$res2 = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$numitems = mssql_num_rows($res2);
?>

<body bgcolor="#362F31" onLoad="FP_preloadImgs(/*url*/'images/af_viewmyitems_hover.jpg', /*url*/'images/af_editaccountinfo_hover.jpg')">

<div align="center">
<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account.jpg" height="31" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
																	<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											<font size="2" face="Tahoma">
											Welcome, <?=$_SESSION['UserID']?>!</font></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=login&action=logout&header=1">
											Logout?</a></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="center">
												<table border="0" width="171" height="169" style="border-collapse: collapse; background-image: url('images/accountframe.jpg')">
													<tr>
														<td height="29" width="12">&nbsp;</td>
														<td height="29" width="155" colspan="2">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_coin.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['euCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_totalitems.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$numitems?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														<?=$d['GuestPasses']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_viewmyitems.jpg'); background-repeat: no-repeat; background-position-x: left">
														<a href="index.php?do=myaccount&act=viewmyitems">
														<img border="0" src="images/af_viewmyitems.jpg" id="img3" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img3',/*url*/'images/af_viewmyitems_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_editaccountinfo.jpg'); background-repeat: no-repeat; background-position-x: left">
														<a href="index.php?do=myaccount&act=editinfo">
														<img border="0" src="images/af_editaccountinfo.jpg" width="138" height="22" id="img4" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img4',/*url*/'images/af_editaccountinfo_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12">&nbsp;</td>
														<td width="155" colspan="2">
														<p align="center">
														</td>
													</tr>
												</table>
											</div>
											</td>
										</tr>
										</table>
								
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22">&nbsp;</td>
							</tr>
						</table>

<?
}
?>