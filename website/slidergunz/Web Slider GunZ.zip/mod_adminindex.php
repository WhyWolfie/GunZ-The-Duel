
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="clanranking.jpg" height="31" width="195" style="background-image: url('images/adminpanel.jpg')">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="additem" checked name="do">Add Item to Shop<br>
										<input type="radio" name="do" value="banuser">Ban User<br>
										<input type="radio" name="do" value="addindexcontent">Add content to Index<br>
										<input type="radio" name="do" value="accfunctions">Account Functions<br>
										<input type="radio" name="do" value="accountlist">Account List<br>
										<input type="radio" name="do" value="characters">Character Admin<br>
										<input type="radio" name="do" value="stats">View Stats<br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Go" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22"></td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							