<?php
//Server Name
define("Slider Gunz", "Slider Gunz");

//Connect Database
$_MSSQL['Host'] = "Otharan-PC\SQLEXPRESS";   //MSSQL Host
$_MSSQL['User'] = "sa";   //MSSQL Username
$_MSSQL['Pass'] = "42435321";   //MSSQL Password
$_MSSQL['DB']   = "GunzDB";   //MSSQL Database
$Login_Table    = "Login";      //Database Login Table Name
$Account_Table  = "Account";    //Database Account Table Name

$con = odbc_connect("Driver={SQL Server};Server={$_MSSQL['Host']}; Database={$_MSSQL['DB']}", $_MSSQL['User'], $_MSSQL['Pass']) or die("Can't connect the MSSQL server.");
//End Of Database Connection

//Function Validate Email
function is_valid_email($email)
{
  return preg_match('#^[a-z0-9.!\#$%&\'*+-/=?^_`{|}~]+@([0-9.]+|([^\s]+\.+[a-z]{2,6}))$#si', $email);
}

//Anti Injection
function anti_sql($sql)
{
  $sql = preg_replace(sql_regcase("/(from|select|insert|delete|where|'|\"|drop table|show tables|#|\*|--|\\\\)/"),"",$sql);
  $sql = trim($sql);
  $sql = strip_tags($sql);
  $sql = addslashes($sql);
 return $sql;
}

//Alert
function alert($msg)
{
  echo '<script language="javascript">alert("'.$msg.'");</script>';
}

//Body
echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
   <title>'. ServerName .' &bull; Register Page</title>
   <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
   <style>
   <!--
   body {background:#100f0f url(images/bg.png) no-repeat;width:800px;height:400px;background-position:center top;margin:0 auto;font-family:verdana;font-size:11px;color:#FFF;font-weight:bold;text-shadow:3px 2px 3px #000;}
   #register {background:url(images/table.png) no-repeat;width:507px;height:345px;margin:0 auto;margin-top:120px;}
   #regform {width:450px;margin:0 auto;padding-top:30px;}
   #regform input {padding:0 0 8px;}
   .input {background:url(images/input.png) no-repeat;width:212px;height:26px;border:0;color:#7a7979;text-indent:30px;}
   .button {background:url(images/button.png) no-repeat;text-shadow:3px 2px 3px #000;width:152px;height:46px;border:0;color:#FFF;font-weight:bold;font-style:italic;cursor:pointer;margin-top:4px;}
   .button:hover {background:url(images/button_over.png) no-repeat;width:152px;height:46px;color:#d5cfcf;}
   -->
   </style>
   <script type="text/javascript">
   function isNumberKey(evt)
   {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if(!((event.keyCode>=48&&event.keyCode<=57)|| (event.keyCode==46)))
            return false;

         return true;
   }
   </script>
 </head>
<body>
  <div id="register">
   <form action="'. $_SERVER['PHP_SELF'] .'" method="post" id="regform">
      <label for="username">Username :</label> <input type="text" name="username" maxlength="25" style="margin-left:159px;" class="input" />
      <label for="password">Password :</label><input type="password" name="password" maxlength="30" style="margin-left:167px;" class="input" />
      <label for="password2">Repeat PW :</label><input type="password" name="password2" maxlength="30" style="margin-left:160px;" class="input" />
      <label for="name">Name :</label><input type="text" name="name" maxlength="25" style="margin-left:192px;" class="input" />
      <label for="age">Age :</label><input onkeypress="return isNumberKey(event)" type="text" name="age" maxlength="2" style="margin-left:204px;" class="input" />
      <label for="email">Email :</label><input type="text" name="email" maxlength="40" style="margin-left:193px;" class="input" />
      <label for="country">Country :</label><input type="text" name="country" maxlength="25" style="margin-left:178px;" class="input" />
      <input type="submit" name="register" value="Register" class="button" style="margin-left:65px;float:left;" />
      <input type="reset" name="clear" value="Clear" class="button" style="margin-right:65px;float:right;" />
   </form>
   <div style="clear:both;"></div>
   
   <div style="text-align:center;margin-top:40px;font-size:10px;font-weight:bold;">
     Copyright &copy; 2012 '. Slider .' 
   </div>
   
   <!-- Made By Rauno Leinasaar -->
   
  </div>
</body>
</html>
';

//User Registration
if(isset($_POST['register']))
{
$register_username  = htmlspecialchars($_POST["username"]);
$register_password  = htmlspecialchars($_POST["password"]);
$register_password2 = htmlspecialchars($_POST["password2"]);
$register_name      = htmlspecialchars($_POST["name"]);
$register_age       = htmlspecialchars($_POST["age"]);
$register_email     = htmlspecialchars($_POST["email"]);
$register_country   = htmlspecialchars($_POST["country"]);

 //Check If All Fields Are Filled
 if($register_username&&$register_password&&$register_password2&&$register_name&&$register_age&&$register_email&&$register_country)
 {
   //Check If UserID Already Exist
   $checkuserid = odbc_exec($con,"SELECT * FROM ". $Login_Table ." WHERE UserID='". anti_sql($register_username) ."'");
   if(odbc_fetch_row($checkuserid) == 0)
   {
     //Check If Email Already Exist
     $checkemail = odbc_exec($con,"SELECT * FROM ". $Account_Table ." WHERE Email='". anti_sql($register_email) ."'");
	 if(odbc_fetch_row($checkemail) == 0)
	 {
	   //Check If Passwords Match
	   if($register_password == $register_password2)
	   {
	     //Check Username Lenght
		 if(strlen($register_username) < 25)
		 {
		   //Check Password Lenght
		   if(strlen($register_password) < 30)
		   {
		     //Validate Email
		     if(is_valid_email($register_email))
			 {
			   //Insert User Info To Database
			   $date = date("Y-m-d H:i:s");
			   $IP = $_SERVER['REMOTE_ADDR'];
			   
			   $insertintoaccount = odbc_exec($con,"INSERT INTO ". $Account_Table ." (UserID, UGradeID, PGradeID, RegDate, Email, Name, Age, Country)
			                                  VALUES('".anti_sql($register_username)."','0',0,'".anti_sql($date)."','".anti_sql($register_email)."','".anti_sql($register_name)."','".anti_sql($register_age)."','".anti_sql($register_country)."')");
			   $getaid = odbc_exec($con,"SELECT AID FROM ". $Account_Table ." WHERE UserID='". anti_sql($register_username) ."'");
			   if($getaid <> 0)
			   {
			     $i=1;
				 while($ad = odbc_fetch_object($getaid))
				 {
				   $aid = $ad->AID;
				   $i++;
				   $insertintologin = odbc_exec($con,"INSERT INTO ". $Login_Table ." (UserID, AID, Password) VALUES('". anti_sql($register_username) ."', '". anti_sql($aid) . "', '". anti_sql($register_password) ."')");
				   
				   alert('Account created successfully.');
				 }
			   }
			 }
			 else
			 {
			   alert('Invalid Email!');
			 }
		   }
		   else
		   {
		     alert('Password lenght is too long.');
		   }
		 }
		 else
		 {
		   alert('UserID lenght is too long.');
		 }
	   }
	   else
	   {
	     alert("Passwords don't match, please try again.");
	   }
	 }
	 else
	 {
	   alert('Email already exists, please choose another one.');
	 }
   }
   else
   {
     alert('UserID already exists, please choose another one.');
   }
 }
 else
 {
   alert('Please fill in all fields!');
 }
}
//End Of User Registration
?>