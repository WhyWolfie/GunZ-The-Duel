<?php
//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'USER-PC\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = '42435321'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZ DB 


?>




 
       
       
       
       
       
       
       
       
       
      