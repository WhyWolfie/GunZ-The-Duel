<link href="../default.css" rel="stylesheet" type="text/css" />
<div align="center">
<br />
<br />
<hr />
<? 
include ("config.php");
include ("sec.php");
$conn = @mssql_connect($DBHost, $DBUser, $DBPass); 
@mssql_select_db($DB); 



if (isset($_GET['step'])) {
	$argv = explode('-',$_GET['step']);
	settype($argv,'array'); 
	$_GET['step'] = @$argv[0];
	$_GET['url'] = @$argv[1];
	$_GET['do'] = @$argv[2];
	$_GET['mess'] = @$argv[3];
}
$step = !isset($_GET['step']) ? home : $_GET['step'] ;
		if ($step == '1') { echo'

<FORM METHOD=POST ACTION="?emblem=index&step=2">
  <p>Enter your user ID: 
    <input name="user" type="textfield" />	<BR />
	Enter your password:
	<input name="pass" type="textfield" />
  </p>
	<p><br />
    <input type="submit" value="submit" />
  </p>
</form> '; 
 } if ($step == '2') { 
 
$user1 = anti_injection($_POST['user']);
$pass1 = anti_injection($_POST['pass']);
    if (valida(Array($user1,$pass1)) == TRUE)
{

 $query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");
			while($r = mssql_fetch_array($query)){
if (mssql_num_rows($query) == 1){
						
						$query2 = mssql_query("
SELECT     Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID
FROM         ClanMember INNER JOIN
                      Clan ON ClanMember.CLID = Clan.CLID INNER JOIN
                      Login INNER JOIN
                      Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
					  if (mssql_num_rows($query2) >= '1'){
					  echo '<form enctype="multipart/form-data" action="?emblem=index&step=done" method="POST">
  <p>Please choose a file: 
    <input name="uploaded" type="file" />
  </p>
  <p><br />
    <input type="submit" value="Upload" />
    </p><select name="clan">'
;
							for($i='';$i < @mssql_num_rows($query2);++$i){
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
							echo '<option value="'.$row[4].'">';echo $row[4];echo'</option>' ;
							

							}echo'</select></form>';
							}}else { echo " ERROR GEEN CLAN ";} }
							}
			;
		}  
	
	; 
	
	if ($step == 'done') { 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = $_POST['clan'];
$target = "upload/";
$target = $target . basename( $_FILES['uploaded']['name']) ;
$ok=1;
if (!($_FILES['uploaded']['size']  > '9500'))
{
//echo "Your file is too large.<br>";
$ok=1;
if(($_FILES['uploaded']['type'] == "image/jpeg"))
{ 
$ok=1;
//echo "Wrong file type.<br>";
}
if(($_FILES['uploaded']['type'] == "image/GIF"))
{ 
$ok=1;
//echo "Wrong file type.<br>";
}
if(($_FILES['uploaded']['type'] == "image/PNG"))
{ 
$ok=1;
//echo "Wrong file type.<br>";
}
}
else { $ok=0;}

//


if ($ok==0)
{
echo "Sorry your file was not uploaded<br />";
echo "Please check the file size or file type";
}
else
{
if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
{
echo "The file ".basename( $_FILES['uploadedfile']['name']). " has been uploaded<br />";
echo "You may close this window now";
mssql_query ("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
mssql_query ("UPDATE Clan SET EmblemUrl = 'upload/".$target."' WHERE Name = '$CLID'");
}
else
{
echo "Sorry, there was a problem uploading your file.";
}}
};
?>
</div>
<hr />
