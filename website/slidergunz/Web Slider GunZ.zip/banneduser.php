   <?php
//This file has been edited by El Pana. All rights reserved.
//Fixed 2 exploits in this.
//Once again, a SESSION can be spoofed.
if($_SESSION['UGradeID'] == 253){
    $res = mssql_query("SELECT * FROM AccountBan WHERE AID = '" . antisql($_SESSION['AID']) . "' AND Opened = '1'");
    $data = mssql_fetch_assoc($res);
    $hoy = date("dmY");
    if($hoy >= $data['BanFinish']){
        //We remove the ban if it has expired
        mssql_query("UPDATE Account SET UGradeID = '253' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
        mssql_query("UPDATE AccountBan SET Opened = '253' WHERE ABID = '".$data['ABID']."'");
        $_SESSION['UGradeID'] = 0;
        //Redirect to the index
        re_dir("index.php");
    }

if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }
?>

<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>ArcanicMayhem - <?=$pagetitle?></title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" bgcolor="#000000">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr>
			<td background="images/header.jpg" width="921" height="158">&nbsp;</td>
		</tr>
		<tr>
			<td background="images/nav_bar.jpg" height="28" class="menu" valign="middle">
			<p align="center">Index |
			Register
			| Downloads |
			Forum |
			Ranking |
			Clan |
			Item
			Shop | Contact</td>
		</tr>
		<tr>
			<td background="images/main_bg.jpg">

			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?php
				 if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
						</div>
					</td>
					<td width="481" valign="top">
					<div align="center">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/accountbanned.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											Sorry, the account <b>
											<?=$_SESSION['UserID']?></b>
											does not have permission to access ArcanicMayhem<p>Reason:</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<hr color="#3D3A3A" width="95%"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<p style="margin-left: 20px; margin-top: 0">
											<i><?=$data['BanReason']?></i></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<hr color="#3D3A3A" width="95%"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<p align="center">Date that the exclusion will be lifted: <b><?=$data['BanDate']?></b></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<p align="center">The expulsion of users is carried out by 
											failing to meet certain standards, or non-use programs such
											as GunZ Hacks and Cheats.</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
<?php echo @$errorbox ?>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
						<p>&nbsp;</div>
					</td>
					<td width="206" valign="top">
					<p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
				</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td background="images/footer.jpg" height="65">&nbsp;</td>
		</tr>
	</table>
</div>

</body>

</html>
    <?php
    die();
}

?>