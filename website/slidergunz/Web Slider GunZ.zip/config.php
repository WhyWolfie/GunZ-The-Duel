<?php
mssql_connect("Otharan-PC\SQLEXPRESS","sa","42435321");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Server in maintenance";
}
?>