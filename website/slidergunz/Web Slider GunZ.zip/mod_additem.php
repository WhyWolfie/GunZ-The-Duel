<?php
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $name = antisql($_POST['name']);
    $zitemid = antisql($_POST['zItemID']);
    $desc = antisql($_POST['desc']);
    $price = antisql($_POST['price']);
    $img = antisql($_POST['img']);
    $sex = antisql($_POST['sex']);
    $minlvl = antisql($_POST['minlvl']);
    $peso = antisql($_POST['peso']);
    $slot = antisql($_POST['slot']);
    $damage = antisql($_POST['damage']);
    $AP = antisql($_POST['AP']);
    $FR = antisql($_POST['FR']);
    $delay = antisql($_POST['delay']);
    $HP = antisql($_POST['HP']);
    $PR = antisql($_POST['PR']);
    $magazine = antisql($_POST['magazine']);
    $maxpeso = antisql($_POST['maxpeso']);
    $CR = antisql($_POST['CR']);
    $balasmax = antisql($_POST['balasmax']);
    $reloadtime = antisql($_POST['reloadtime']);
    $LR = antisql($_POST['LR']);
    $control = antisql($_POST['control']);
    $duracion = antisql($_POST['duracion']);
    $csid = antisql($_POST['zItemID']);
    mssql_query("INSERT INTO [Item] ([ItemID], [Name], [Description], [ResSex], [ResLevel], [Weight], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [CR], [MaxBullet], [ReloadTime], [LR])VALUES('$zitemid', '$name', '$desc', NULL, $minlvl, 1, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $CR, $balasmax, $reloadtime, $LR)");
    mssql_query("INSERT INTO [CashShop] ([ItemID], [Name], [CSID], [Description], [CashPrice], [WebImgName], [NewItemOrder], [ResSex], [ResLevel], [Weight], [Opened], [RegDate], [RentType], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [MaxWeight], [CR], [MaxBullet], [ReloadTime], [LR], [Control], [Duration])VALUES('$zitemid', '$name', '$csid', '$desc', $price, '$img', NULL, $sex, $minlvl, $peso, 1, GETDATE(), NULL, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $maxpeso, $CR, $balasmax, $reloadtime, $LR, $control, $duracion)");
    msgbox("Item added correctly","index.php?do=additem");
}else{
    



?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=additem"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="32">&nbsp;</td>
											<td width="429" colspan="3">
											<img border="0" src="images/inf/addshopitem.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>

										<tr>
											<td width="438" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="184">
											<p align="right">Name</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="name" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right" valign="top">
											Description</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<textarea rows="4" name="desc" cols="26"></textarea></td>
										</tr>

										<tr>
											<td width="184" align="right">
											ItemID in ZITEM.xml</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="zItemID" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Price</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="price" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Image</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="img" size="34"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Sex</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="sex">
											<option selected value="0">Man
											</option>
											<option value="1">Woman</option>
											<option value="2">Everyone</option>
											</select></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Min. Level</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="minlvl" size="20" value="1"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="peso" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Slot</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="slot">
											<option selected value="1">Item's weight
											</option>
											<option value="2">Melee</option>
											<option value="3">Armor</option>
											<option value="4">Complete Set
											</option>
											<option value="5">Special Item
											</option>
											</select></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Damage</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="damage" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											AP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="AP" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											FR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="FR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Delay</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="delay" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											HP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="HP" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											PR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="PR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Magazine</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="magazine" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Maximum Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="maxpeso" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											CR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="CR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Maximum Ammo</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="balasmax" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Reload Time</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="reloadtime" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											LR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="LR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Control</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="control" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Duration</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="duracion" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184">
											&nbsp;</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add Item" name="submit"></td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>