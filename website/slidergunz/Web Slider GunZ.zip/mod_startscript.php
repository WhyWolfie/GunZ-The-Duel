<?
include "config.php";
include "_functions.php";
if($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
    die();
}

$hash = rand(10000,60000);
$hash = md5($hash);
//Oopsie.
$user = antisql($_SESSION['UserID']);
$ip = $_SERVER['REMOTE_ADDR'];
mssql_query("INSERT INTO SessionHash ([HashString], [User], [IP], [Used])VALUES('$hash','$user', '$ip', '0')");
mssql_query("UPDATE Login Set LaunchCount=LaunchCount+1 WHERE UserID = '$user'");
?>
<HTML>
<HEAD>
  <TITLE>Redirected</TITLE>
  <SCRIPT LANGUAGE="JavaScript">
  function redirect() {
    setTimeout("location.href='eurogunz<?=$hash?>'", 4000);
  }
  </SCRIPT>
</HEAD>
<BODY onLoad="redirect()">
<P>Do you love me?
</BODY>
</HTML>