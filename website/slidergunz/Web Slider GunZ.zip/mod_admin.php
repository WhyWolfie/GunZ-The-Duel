<?php
if (!function_exists("AddShopItem")){
    function AddShopItem(){
    ?>

<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="30">&nbsp;</td>
											<td width="429" colspan="3">
											<img border="0" src="images/inf/addshopitem.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>

										<tr>
											<td width="438" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="184">
											<p align="right">Name</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T1" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right" valign="top">
											Description</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<textarea rows="4" name="S1" cols="26"></textarea></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Price</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T2" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Image</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T3" size="34"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Sex</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="sex">
											<option selected value="0">Man
											</option>
											<option value="1">Woman</option>
											<option value="2">Everyone</option>
											</select></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Min. Level</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T4" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T5" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Slot</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="slot">
											<option selected value="1">Item's Weight
											</option>
											<option value="2">Melee</option>
											<option value="3">Armor</option>
											<option value="4">Complete Set
											</option>
											<option value="5">Special Item
											</option>
											</select></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Damage</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T6" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											AP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T7" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											FR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T8" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Delay</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T9" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											HP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T10" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											PR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T11" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Ammo per clip</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T12" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Maximum Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T13" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											CR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T14" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Max. Ammo</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T15" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Reload Time</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T16" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											LR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T17" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Control</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T18" size="11"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Duration</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="T19" size="11"></td>
										</tr>

										<tr>
											<td width="184">
											&nbsp;</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
    }
}



switch ($_POST['R1']){
    case "1";
        AddShopItem();
    break;
}
?>