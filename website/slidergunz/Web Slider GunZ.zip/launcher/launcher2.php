<html>
<head>
<title>the Duel Launcher</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body scroll="no">
<table border="0" style="border-collapse: collapse; background-image: url('front.jpg')" width="600" height="360">
	<tr>
		<td>&nbsp;</td>
	</tr>
</table>
&nbsp;
</body>
</html>