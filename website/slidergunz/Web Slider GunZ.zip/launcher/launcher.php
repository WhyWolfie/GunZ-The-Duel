<html><head>


<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><title>	
MPOG Spain Closed for Always</title></head><body bgcolor="#161616">
<center>
<script type="text/javascript"><!--
   e9 = new Object();
   e9.size = "728x90";
   e9.noAd = 1;
//--></script>
<script type="text/javascript" src="index_files/tags.js"></script><center><script type="text/javascript" src="index_files/j.js"></script><center><a target="_blank" href="http://a.tribalfusion.com/h.click/aKmxf31EQy3ajj4ErRnqBAYbjfTWfWnArBpVMtpHnJ3T3h3Wmr3AFZbnUYZaYG7TXGFT0sZbMnEvT5U32VbfDUAn4PEUQQsYsQdYr1HvsTmvn3VMUXbZbLU6Xu5mrgRmBJ3WZbE6YZa7WZc/http://a.tribalfusion.com"><img src="index_files/37536.gif" border="0" height="1" width="1"></a></center></center>

</center>
<p align="center"><font color="#f28711" face="Arial" size="6">MPOG Spain Closed for Always</font></p>
<p><font color="#f28711" face="Arial" size="5">We invite all those who want to be in a community of Gunz in Spanish at:</font></p>
<p><font color="#f28711" face="Arial" size="5">
<a href="http://www.gunzspanish.org/">www.gunzspanish.org</a> and our forums
<a href="http://foro.gunzspanish.org/">http://foro.gunzspanish.org</a> </font>
</p>
<p><font face="Arial" size="5" color="#F28711">In GunzSpanish NO server Gunz, is only a Community.</font></p>
<p><b><font color="#f28711" face="Arial">Lambda announcement:</font></b></p>
<i><font color="#f28711" face="Arial">I was talking to emisand and in the end we have taken a decision.
<br>
<br>
We will not mount server Gunz, here I give the reasons.<br>
&nbsp;</font></i><ul>
	<li><i><font color="#f28711" face="Arial">We're going to take us years with donations to buy a server or one day we will know what will happen with the</font></i></li>
	<li><i><font color="#f28711" face="Arial">Are only headaches</font></i></li>
	<li><i><font color="#f28711" face="Arial">I own projects which have a preference Gunz</font></i></li>
	<li><i><font color="#f28711" face="Arial">NO gain nothing by making a server, only problems and headaches</font></i></li>
</ul>
<i><font color="#f28711" face="Arial">to concrete we will refund your 20USD to donate to the donors of SMS we can not do anything to restore the money, but just as we will use in upcoming projects.
<br>
<br>
Nothing more to say.</font></i><p><b><font color="#f28711" face="Arial">Emisand announcement:</font></b></p>
<p><i><font color="#f28711" face="Arial">Besides lacking to say that:
<br>
<br>
Yesterday when he went to make a backup of all files I saw that no one could enter the server.
<br>
I contact the company's server so that it starts, and I see that there is going to a script that makes you switch off the server every time you turn on.
<br>
Once we are rid of that script, I saw that we deleted all our files:
<br>
-Server-Gunz<br>
-Server-Mu<br>
-Server-GTA<br>
-Databases<br>
-Backups-around<br>
-Website<br>
-Etc<br>
<br>
Therefore we should start from 0 and the truth could not do that, Demaci is working.
<br>
Nor could Lambda.
<br>
<br>
I hope they understand the situation, there are no options.</font></i></p>
<p>&nbsp;</p>

<p>&nbsp;</p>

</body></html>