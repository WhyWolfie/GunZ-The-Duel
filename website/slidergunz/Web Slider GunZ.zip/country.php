<?php
$validcountry = array('DE','AT','BG','BE','CY','DK','SK','SI','ES','EE','FI','FR','GR','HU','IE','LV','LT','LU','MT','NL','PL','PT','GB','CZ','RO','SE');

$country = '';
$IP = $_SERVER['REMOTE_ADDR'];

if (!empty($IP)) {
$country = file_get_contents('http://api.hostip.info/country.php?ip=76.26.64.45');
}

if (in_array($country,$validcountry)) {
    echo "Your country is allowed to play in the GunZ server";
}else{
    echo "Your country sux, you should either lie on your country or play another server.";
}
?>