<?php
//This file has been edited by Wizkid. All rights reserved.

include "authadmin.php";

$meses = array( "01" => "January",
                "02" => "Febuary",
                "03" => "March",
                "04" => "April",
                "05" => "May",
                "06" => "June",
                "07" => "July",
                "08" => "August",
                "09" => "September",
                "10" => "October",
                "11" => "November",
                "12" => "December"
                );

if (isset($_POST['submit'])){
    $type = antisql($_POST['type']);
    $id = antisql($_POST['id']);
    $day = antisql($_POST['day']);
    $month = antisql($_POST['month']);
    $year = antisql($_POST['year']);
    $reason = antisql($_POST['reason']);
    $custom = antisql($_POST['cstom']);
    //--
    if($reason == 1){
        $reason = $custom;
        $custom = str_replace("
        ","</br>",$custom);
    }
    //--
    if ($type == 1){
        $res = mssql_query("SELECT * FROM Account WHERE UserID = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("UserID $id doesn't exist","index.php?do=banuser");
        }else{
            $data = mssql_fetch_assoc($res);
            $userID = $data['UserID'];
            $UserAID = $data['AID'];
            $bandate = $day . " ". $months[$month] . " " . $year;
            $banfinish = $day.$month.$year;
            if($_POST['C1'] == "ON"){
                $bandate = "Never";
                $banfinish = "999999999999999999999";
            }
            mssql_query("UPDATE Account SET UGradeID = '253' WHERE UserID = '$userID'");
            mssql_query("INSERT INTO AccountBan (AID, BanDate, BanFinish, BanReason, Opened)VALUES('$UserAID', '$bandate','$banfinish', '$reason',1)");
            msgbox("The user with the ID $id has been banned","index.php?do=banuser");
        }
    }else{
        $res = mssql_query("SELECT * FROM Character WHERE Name = '$id'");
        if(mssql_num_rows($res) == 0){
            msgbox("The character $id doesn't exist","index.php?do=banuser");
        }else{
            $res = mssql_query("SELECT * FROM Character WHERE Name = '$id'");
            $data = mssql_fetch_assoc($res);
            $UserAID = $data['AID'];
            $bandate = $day . " ". $months[$month] . " " . $year;
            $banfinish = $day.$month.$year;
            mssql_query("UPDATE Account SET UGradeID = '253' WHERE AID = '$UserAID'");
            mssql_query("INSERT INTO AccountBan (AID, BanDate, BanFinish, BanReason, Opened)VALUES('$UserAID', '$bandate','$banfinish', '$reason',1)");
            msgbox("The user with the character $id has been banned","index.php?do=banuser");
        }
    }

}


?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>


	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form name="ban" method="POST" action="index.php?do=banuser"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/resuser.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="149">
											&nbsp;</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">
											<select size="1" name="type">
											<option selected value="1">User ID
											</option>
											<option value="2">Character Name
											</option>
											</select></td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<input type="text" name="id" size="26">&nbsp;
											</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">Ban end</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<select size="1" name="day">
											<option value="01" selected>01
											</option>
											<option value="02">02</option>
											<option value="03">03</option>
											<option value="04">04</option>
											<option value="05">05</option>
											<option value="06">06</option>
											<option value="07">07</option>
											<option value="08">08</option>
											<option value="09">09</option>
											<option value="10">10</option>
											<option value="11">11</option>
											<option value="12">12</option>
											<option value="13">13</option>
											<option value="14">14</option>
											<option value="15">15</option>
											<option value="16">16</option>
											<option value="17">17</option>
											<option value="18">18</option>
											<option value="19">19</option>
											<option value="20">20</option>
											<option value="21">21</option>
											<option value="22">22</option>
											<option value="23">23</option>
											<option value="24">24</option>
											<option value="25">25</option>
											<option value="26">26</option>
											<option value="27">27</option>
											<option value="28">28</option>
											<option value="29">29</option>
											<option value="30">30</option>
											<option value="31">31</option>
											</select><select size="1" name="month">
											<option value="01" selected>January
											</option>
											<option value="02">Febuary</option>
											<option value="03">March</option>
											<option value="04">April</option>
											<option value="05">May</option>
											<option value="06">June</option>
											<option value="07">July</option>
											<option value="08">August</option>
											<option value="09">September
											</option>
											<option value="10">October</option>
											<option value="11">November
											</option>
											<option value="12">December
											</option>
											</select><select size="1" name="year">
											<option value="2007">2007</option>
											<option value="2008">2008</option>
											<option value="2009">2009</option>
											<option value="2010">2010</option>
											<option value="2011">2011</option>
											</select>
											<input type="checkbox"  onclick="DisableDate()" name="C1" value="ON">
											Never</td>
										</tr>

										<tr>
											<td width="149">
											<p align="right">Ban Reason</td>
											<td width="4">
											&nbsp;</td>
											<td width="279">
											<select size="1" name="reason" onchange="UpdateCustom()">
											<option selected value="Using programs to modify the client">Using programs to modify the client
											</option>
											<option value="Using hacks or cheats">Using hacks or cheats
											</option>
											<option value="Insulting the staff">Insulting the staff
											</option>
											<option value="Insulting Player">Insulting player
											</option>
											<option value="Swap / etc">Swap / etc.
											</option>
											<option value="No reason specified">No reason specified
											</option>
											<option value="1">Other (specify below)</option>
											</select></td>
										</tr>
										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">
											<textarea disabled rows="9" name="cstom" cols="30"></textarea></td>
										</tr>

										<tr>
											<td width="149">&nbsp;</td>
											<td width="4">&nbsp;</td>
											<td width="279">&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Ban User" name="submit"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>