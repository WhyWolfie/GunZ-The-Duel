<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
</head>
<style type="text/css">
<!--
.style5 {color: #232122}
-->
    </style>
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="412" style="border-collapse: collapse">
							<tr>
								<td width="437" background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="406" height="100%">
										<tr>
											<td width="1" rowspan="6">&nbsp;</td>
										  <td width="390"><h2 align="center">DOA&Ccedil;&Atilde;O</h2>											  </td>
										  <td width="10">&nbsp;</td>
										</tr>
										<tr>
										  <td width="390">&nbsp;</td>
										  <td width="10">&nbsp;</td>
										</tr>
										<tr>
											<td width="390" valign="top"><p>Ainda bem que voc&ecirc; decidiu dar uma olhada nas doa&ccedil;&otilde;es e, eventualmente, apoiar-nos. Nesta se&ccedil;&atilde;o voc&ecirc; vai encontrar algo relacionado a doa&ccedil;&otilde;es, o que &eacute;, por que doar, como fazer uma doa&ccedil;&atilde;o e aquilo que pode ser recompensado ap&oacute;s sua doa&ccedil;&atilde;o.</p>
										      <p><strong>Como fazer a Doa&ccedil;&atilde;o?</strong><br>
										        Usando o PagSeguro voc&ecirc; poder&aacute; fazer pagamentos r&aacute;pidos e de forma f&aacute;cil.<br>
										        O pagamento pode ser feito atrav&eacute;s de Boleto, Transfer&ecirc;ncia Banc&aacute;ria, Cart&atilde;o de Cr&eacute;dito ouTransfer&ecirc;ncia de Saldo, o PagSeguro &eacute; uma &oacute;tima op&ccedil;&atilde;o, e seus cr&eacute;ditos chegaram r&aacute;pido, sem necessidade de confirmar nada, apenas Clique no Banner, selecione o plano, efetue o pagamento e espere sua conta ser creditada.</p>
										      <p><strong>Doa&ccedil;&otilde;es ... O que &eacute;? E por que precisamos delas?</strong><br>
										        As doa&ccedil;&otilde;es s&atilde;o voluntariamente, sem contrapartida de retorno. Elas est&atilde;o aqui para nos ajudar a pagar as contas mensais de nossos servidores. Sem elas e sem seu apoio, n&oacute;s n&atilde;o ser&iacute;amos capazes de ter recursos para pagar as contas, mensalmente, e nosso servidor n&atilde;o estaria aqui, ou pelo menos, n&atilde;o seria t&atilde;o popular e bem sucedido, pois n&oacute;s n&atilde;o poderiamos ter um servidor capaz de suportar muitos jogadores sem quedas e lags.</p>
										      <p><strong>Acordo de Doa&ccedil;&otilde;es<br>
										        </strong>Ao enviar um donativo para o Knight Gunz, voc&ecirc; concorda que n&atilde;o t&ecirc;m direito a receber qualquer coisa de n&oacute;s, por&eacute;m, uma recompensa ser&aacute; dada &agrave; aqueles que doam como um agradecimento por seu apoio cont&iacute;nuo. Esta forma de doa&ccedil;&atilde;o &eacute; completamente volunt&aacute;ria, como explicado anteriormente, e &eacute; usada para melhorar nosso servidor.</p>
										      <p><strong>Ao fazer uma doa&ccedil;&atilde;o voc&ecirc; concorda com os termos apresentados nas declara&ccedil;&otilde;es seguintes:</strong><br>
										          <em><br>
										            1. Voc&ecirc; entende que se trata de uma doa&ccedil;&atilde;o volunt&aacute;ria e n&atilde;o &eacute; reembols&aacute;vel ou discut&iacute;vel, em qualquer momento ou por qualquer motivo.<br>
										            2. Qualquer tentativa de fraude ao sistema de doa&ccedil;&atilde;o vai levar a remo&ccedil;&atilde;o permanente de sua conta de nossa rede.<br>
										            3. Ser um doador n&atilde;o lhe d&aacute; nenhum privil&eacute;gio. Voc&ecirc; ser&aacute; amea&ccedil;a, tal como qualquer outro jogador.<br>
										            4. Se seus itens em resposta a uma doa&ccedil;&atilde;o foi roubado / perdido / extraviado / sumiu /entre outros, n&atilde;o seremos respons&aacute;veis por sua recupera&ccedil;&atilde;o.<br>
										            5. Se voc&ecirc; n&atilde;o concordar com esses termos, n&atilde;o nos envie uma doa&ccedil;&atilde;o. Ao enviar uma doa&ccedil;&atilde;o, voc&ecirc; concorda com este acordo.</em><br>
									          </p>
										      <p>Depois de ter lido, entendido e concordado com o nosso acordo, voc&ecirc; pode enviar a sua doa&ccedil;&atilde;o. Clique no bot&atilde;o abaixo para doar.<br>
										        Selecione a forma de pagamento que mais lhe agrada</p>
										      <p><a href="http://www.knightgunz.com/index.php?do=donate" onClick="ajaxLoader('include.php?do=faturas', 'conteudo'); return false;"><img src="https://pagseguro.uol.com.br/Imagens/Banners/btnPreferenciasBR_415x40.gif" border="0" alt="Pague com PagSeguro - &#65533; r&#65533;pido, gr&#65533;tis e seguro!"></a></p>
										      <p><br>
										          <strong>Prazo de entrega</strong><br>
									            <br>
								              <font color='lime'>O produto &eacute; entregue no exato momento em que a <b><u>transa&ccedil;&atilde;o &eacute; confirmada</u></b>, quaisquer d&uacute;vidas favor reportar no nosso f&oacute;rum.</font></p><br>
										      <p id="obs"><strong>Rela&ccedil;&atilde;o de Planos</strong></p>
										      <div align="center">
										        <table width="389" border="0" cellpadding="2" cellspacing="2">
										          <tbody>

                                              </table>
											  <p>&nbsp;</p>
											  <table width="370" height="190" border="0" cellpadding="1" cellspacing="1">
										            <tr>
										              <td width="85"><strong>Planos</strong></td>
										              <td width="150"><strong>Quantidade</strong></td>
										              <td width="266"><strong>Valor</strong></td>
									                </tr>
                                                <tr>
                                                  <td>Plano 1</td>
                                                  <td>150 KG Coins</td>
                                                  <td>10,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 1" />
<input type="hidden" name="itemDescription" value="150 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="10.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                                </tr>
                                                <tr>
                                                  <td>Plano 2 </td>
                                                  <td>250 KG Coins</td>
                                                  <td>20,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 2" />
<input type="hidden" name="itemDescription" value="250 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="20.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO -->
                                                </tr>
                                                <tr>
                                                  <td>Plano 3 </td>
                                                  <td>400 KG Coins</td>
                                                  <td>30,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 3" />
<input type="hidden" name="itemDescription" value="400 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="30.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td>Plano 4 </td>
                                                  <td>500 KG Coins</td>
                                                  <td>40,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 4" />
<input type="hidden" name="itemDescription" value="500 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="40.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td>Plano 5 </td>
                                                  <td>650 KG Coins</td>
                                                  <td>50,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 5" />
<input type="hidden" name="itemDescription" value="650 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="50.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td>Plano 6 </td>
                                                  <td>850 KG Coins</td>
                                                  <td>60,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 6" />
<input type="hidden" name="itemDescription" value="850 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="60.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td>Plano 7 </td>
                                                  <td>1050 KG Coins</td>
                                                  <td>80,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 7" />
<input type="hidden" name="itemDescription" value="1050 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="80.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td>Plano 8 </td>
                                                  <td>1250 KG Coins</td>
                                                  <td>100,00 R$</td>
                                                  <td><!-- INICIO FORMULARIO BOTAO PAGSEGURO -->
<form target="pagseguro" action="https://pagseguro.uol.com.br/v2/checkout/cart.html?action=add" method="post">
<input type="hidden" name="receiverEmail" value="knightgunz2011@hotmail.com" />
<input type="hidden" name="currency" value="BRL" />
<input type="hidden" name="itemId" value="Plano 8" />
<input type="hidden" name="itemDescription" value="1250 KG Coins" />
<input type="hidden" name="itemQuantity" value="1" />
<input type="hidden" name="itemAmount" value="100.00" />
<input type="hidden" name="itemWeight" value="" />
<input type="hidden" name="itemShippingCost" value="0.00" />
<input type="image" src="http://kgz.zapto.org/WebStore/images/buyitem.jpg" name="submit" alt="Pague com PagSeguro - � r�pido, gr�tis e seguro!" />
</form>
<!-- FINAL FORMULARIO BOTAO PAGSEGURO --></td>
                                                </tr>
                                                <tr>
                                                  <td height="19" colspan="4"><div align="center" class="style6"></div></td>
                                                </tr>
                                              </table>
											  �
											</p>
											<table width="416" height="128" border="0" cellpadding="0" cellspacing="0">
                                              <tr>
                                                <td height="19">&nbsp;</td>
                                              </tr>
                                              <tr>
                                                <td height="19"><div align="center"><strong>Comfirma&ccedil;ao do Pagamento </strong></div></td>
                                              </tr>
                                              <tr>
                                                <td>&nbsp;</td>
                                              </tr>
                                                <td height="64" valign="top">Mande E-mail para knightgz@hotmail.com Assunto: (Donator Knight GunZ ) Dados Pagamentos para Receber seus KG Coins.<br /> 
												<br />
												<strong><font color='#00FF00'>� Login:</strong></font><br />
												<strong><font color='#00FF00'>� E-Mail:</font></strong> Usado Pagseguro<br />
												<strong><font color='#00FF00'>� C�digo da transa��o: </font>
												</strong><br />
												<strong><b><font color='#00FF00'>� KG Coins:</strong></font><br />
												<strong><b><font color='#00FF00'>� Nick:</strong></font><br /></a>
                                              <tr>
                                                <td height="19">&nbsp;</td>
                                              </tr>
                                              <tr>
                                                <td height="64"><div align="center"><strong><font color='red'>Aten��o:</font> � obrgatorio informar todos estes dados, caso n�o sejam informados, seus KG coins n�o ser�o creditados. </strong></div></td>
                                              </tr>
                                              <tr>
                                                <td>&nbsp;</td>
                                              </tr>
                                              <tr>
                                              <tr>
                                                <td height="64"><div align="center"><font color='lime'>Obs:</font> Seu pagamento pode demorar at� 2 dias �teis para cair. </div></td>
                                              </tr>
                                              <tr>
                                                <td>&nbsp;</td>
                                              </tr>
                                                <td height="19">&nbsp;</td>
                                              </tr>
                                              <tr>
                                                <td>&nbsp;</td>
                                              </tr>
                                            </table>
											</center>
											</td>
          </tr>
          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="images/cont_top.png" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
<script src="http://widgets.twimg.com/j/2/widget.js"></script>