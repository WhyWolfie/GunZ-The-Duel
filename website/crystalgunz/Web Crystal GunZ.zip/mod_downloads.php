<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<?
if ($_GET['expand'] == 1){
?>

				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('image/subbar.png'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=downloads&sub=client&expand=1">
					<img border="0" src="image/subbar/down-client.jpg" width="128" height="13"></a><a href="index.php?do=downloads&sub=Screenshots&expand=1"><img border="0" src="image/subbar/screenshots.jpg" width="99" height="13"></a><a href="index.php?do=downloads&sub=WallPapers&expand=1"><img border="0" src="image/subbar/Wallpapers.jpg" width="93" height="13"></a></td>
				</tr>

<? }

if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "client";
        Showclient();
    break;
    case "Screenshots";
        ShowScreenshots();
    break;
    case "WallPapers";
        ShowWallPapers();
    break;
}
}


if(!function_exists("Showclient")){
function Showclient(){

?>

<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="image/content_bar.jpg" height="24" style="background-image: url('image/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Downloads</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#232122">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<p align="center">
												<img border="0" src="image/mis_download.jpg" width="365" height="67"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" ">	
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3"><center>
												&nbsp;Escolha seu link para o download do KnightGunZ&nbsp;<br><br>
												<td width="13" style="background-repeat: no-repeat; background-position: center top"></center>
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="http://www.wupload.com.br/file/2636987552/Knight_GunZ_v3.exe">
															<img border="0" src="image/btn_mirror1_off.jpg" width="120" height="21" id="img1764" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1764',/*url*/'image/btn_mirror1_on.jpg')"></a></td>
															<td>
															<a href="http://depositfiles.com/files/x9nuswxrl">
															<img border="0" src="image/btn_mirror2_off.jpg" width="120" height="21" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'image/btn_mirror2_on.jpg')"></a></td>
															<td>
															<a href="http://www.multiupload.com/2QBXQWVJYW">
															<img border="0" src="image/btn_mirror3_off.jpg" width="120" height="21" id="img1766" onmouseover="FP_swapImg(1,0,/*id*/'img1766',/*url*/'image/btn_mirror3_on.jpg')" onmouseout="FP_swapImgRestore()"></a></td>
														</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" height="180" valign="top">
												<div align="center">
													<table border="0" cellpadding="3" cellspacing="1" width="100%">
														<tr>
															<td bgcolor="#121212" width="80">
															<span style="font-size: 7pt">
															&nbsp;</span></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Minimum Requirements</span></b></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Recommended Requirements</span></b></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															OS</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Windows 2000, Windows XP, Windows Vista</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															DirectX</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															DirectX 9.0c</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															CPU</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Pentium III 500 Mhz</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Pentium III 800 Mhz
															</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Memory</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															256 MB</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															512 MB or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Graphic Card</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Direct3D 9.0
															Compatible</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															GeForce 4 MX or higher</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Net Speed</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															64-128 Kbps
															</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															256 Kbps or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Sound Card</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Direct3DSound
															Compatible</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Mouse</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Windows Compatible (Wheel Mouse recommended)</span></td>
														</tr>
													</table>
												</div>
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
						</div>
						</td>
					</tr>
				</table>

    <?
} }

if(!function_exists("ShowWallPapers")){
function ShowWallPapers(){
    ?>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />

<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="image/content_bar.jpg" height="24" style="background-image: url('image/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Wall-Papers</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#232122">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="Wallpapers/1.jpg" rel="lightbox[wall]">
															<img border="0" src="Wallpapers/thumb_1.jpg" width="175" height="135" id="img1764" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															<a href="Wallpapers/2.jpg" rel="lightbox[wall]">
															<img border="0" src="Wallpapers/thumb_2.jpg" width="175" height="135" id="img1765" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="Wallpapers/3.jpg" rel="lightbox[wall]">
															<img border="0" src="Wallpapers/thumb_3.jpg" width="175" height="135" id="img1764" onmouseout="FP_swapImgRestore()" "></a></td>
															&nbsp;<td>
															<a href="Wallpapers/4.jpg" rel="lightbox[wall]">
															<img border="0" src="Wallpapers/thumb_4.jpg" width="175" height="135" id="img1765" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>

											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
						</div>
						</td>
					</tr>

				</table>

    <?
} }

if(!function_exists("ShowScreenshots")){
function ShowScreenshots(){
    ?>
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects,builder"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="css/lightbox.css" type="text/css" media="screen" />

<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="image/content_bar.jpg" height="24" style="background-image: url('image/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Screenshots</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#232122">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>

											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="Screenshots/1.jpg" rel="lightbox[ss]">
															<img border="0" src="Screenshots/thumb_1.jpg" width="175" height="150" id="img1764" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															<a href="Screenshots/2.jpg" rel="lightbox[ss]">
															<img border="0" src="Screenshots/thumb_2.jpg" width="175" height="150" id="img1765" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%" height="96%">
														<tr>
															<td>
															<a href="Screenshots/3.jpg" rel="lightbox[ss]">
															<img border="0" src="Screenshots/thumb_3.jpg" width="175" height="150" id="img1764" onmouseout="FP_swapImgRestore()" "></a></td>
															&nbsp;<td>
															<a href="Screenshots/4.jpg" rel="lightbox[ss]">
															<img border="0" src="Screenshots/thumb_4.jpg" width="175" height="150" id="img1765" onmouseout="FP_swapImgRestore()" "></a></td>
															<td>
															</tr>
													</table>
												</div>
												</td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>

											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">
												&nbsp;</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">
												&nbsp;</td>
											</tr>
											</table>
									</div>
									</td>
								</tr>
							</table>

						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
						</div>
						</td>
					</tr>
				</table>

    <?
} }


?>

					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td><br>