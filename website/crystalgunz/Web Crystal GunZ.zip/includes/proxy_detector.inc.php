<?
/**
* Proxy Detector v0.1
*	Implementation example.
*
*	Mon Sep 18 23:29:47 CEST 2006
*	by: me@daantje.nl
*
*	Documentation:
*		I use this file as an include at the top of some php files
*		to block proxy users from the scripts that included this file.
*
*		This file is only an example on how to implement the detector class.
*		But it could be usefull as is...
*
*		Check the remarks in the class for more documentation.
*/

//include detector class, assuming it's in the same directory as this file...
include_once(dirname(__FILE__)."/proxy_detector.class.php");

//init class
$proxy = new proxy_detector();

//set optional extra triggers, no need to... I think I've got all of them covered in the class...
// $proxy->setTrigger('HTTP_SOME_HEADER_1');
// $proxy->setTrigger('HTTP_SOME_HEADER_2');

//set optional config
// $proxy->setConfig('MAIL_ALERT_TO','me@daantje.nl');
// $proxy->setConfig('LOG_FILE','/home/daantje/public_html/proxy/proxy_detector.log');

//start detect
if($proxy->detect()){

    //returned true, lets die...
	echo "<h1>Proxy detected</h1>";
	echo "Please disable your proxy server in your browser preferences or internet settings, and try again.<br><br>";

	//parse logged info
	echo nl2br($proxy->getLog());

    //some credits...
	echo "<hr><strong>proxy detector v0.1</strong> - &copy;2006 <a href=\"http://www.daantje.nl\" target=\"_blank\">daantje.nl</a>";

	//and do nothing anymore! (but not in my example)
	//exit();
}

//else, proceed as normal...
?>