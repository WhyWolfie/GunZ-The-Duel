<?
if (!($connection = @ mssql_connect('DEDICADO\SQLEXPRESS','sa','knightv3owned')))
      die("Manuten��o");


mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Server Undergoing maintenance";
}

?>