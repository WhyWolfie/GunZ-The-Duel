// No topo 
forward ZerarAntiFlood(playerid); 
new AntiFlood[MAX_PLAYERS]; 

// Agora na public OnPlayerText: 

public OnPlayerText(playerid,text[]) 
{ 
    AntiFlood[playerid]++; 
    if(AntiFlood[playerid] == 1) SetTimerEx("ZerarAntiFlood",1000,false,"i",playerid); // Inicia timer pra zerar o antiflood 
    if(AntiFlood[playerid] == 2) SendClientMessage(playerid,-1,"N�o fa�a flood no servidor"); // Mensagem caso ele n�o pare 
    if(AntiFlood[playerid] == 3) 
    { 
        Kick(playerid); // Kick o jogador que fez o flood 
        SendClientMessage(playerid,-1,"Voc� foi kickado por fazer FLOOD no servidor"); // Manda mensagem 
    } 
    return false; 
} 

// No fim do GM 
public ZerarAntiFlood(playerid) AntiFlood[playerid] = 0;  