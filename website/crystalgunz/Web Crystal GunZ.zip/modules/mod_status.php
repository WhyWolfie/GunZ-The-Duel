<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>
<?
<table border="0" style="border-collapse: collapse" width="190">
								<tr>
									<td height="141" style="background-image: url('images/status.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
										<table border="0" style="border-collapse: collapse" width="175" height="100%">
											<tr>
												<td width="9" height="39">&nbsp;</td>
												<td width="149" height="39">&nbsp;</td>
												<td width="11" height="39">&nbsp;</td>
											</tr>
											<tr>
												<td width="9">&nbsp;</td>
												<td width="149" valign="top">
													<table border="0" style="border-collapse: collapse" width="149">
<?
function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$accsBan = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT WHERE UGRADEID=253"));
$accs = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT"));
$characters = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Character"));
$clans = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Clan"));
$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>
<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'Game Server';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'></font>$name:<font style='color: #FF0000'><B>Offline</B></font><br />";
        }
        else
        {
            echo "<font style='color: FFFFFFFFF'></font>$name: <font style='color: #00FF00'><B>Online</B></font><br />";
            fclose($fp);
        }
    }
    ?>
Recorde Online: <?
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<font style='color: #1E90FF'><b><?=$b['PlayerCount']?></b></font><br>
Total de Contas: <strong><? echo $accs[0]; ?></strong> <br />
Personagens: <strong><? echo $characters[0]; ?></strong> <br />
Total de Cl�s: <strong><? echo $clans[0]; ?></strong> <br />
Total de Banidos: <strong><? echo $accsBan[0]; ?><br></strong>
<?php
 
//VIPS
$query = mssql_query("SELECT * FROM Account WHERE UgradeID = 104 "); 
$num_rows = mssql_num_rows($query); 
echo "Total de Mudos:<b> ".$num_rows."</b><n>";

?><br>
  
Mais Matou: <strong><font color=lightgreen><?=$matou[0]?><br></font></strong>
Mais Morreu: <strong><font color=red><? echo $morreu[0]; ?></font></strong><br>
													</table>
												</div>
												</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td width="9" height="23">&nbsp;</td>
												<td width="149" height="23">&nbsp;</td>
												<td width="11" height="23">&nbsp;</td>
											</tr>
										</table>
									</div>
									<p>&nbsp;</td>
								</tr><tr>
									<td height="0">&nbsp;</td>
								</tr>
							</table>