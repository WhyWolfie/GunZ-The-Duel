<center>

<b><h3>Crystal GunZ - STAFF</b></h3>

<br><br>

<span style="color:cyan; background: transparent url(http://tinyurl.com/outgum)"><b>Fundadores:</b></span></a><br><br>

<font color="cyan">Batman - </font> Fundador Geral <br><br>
<font color="cyan">Helder - </font> Fundador <br><br>


<span style="color:#FFA500; background: transparent url(http://tinyurl.com/outgum)"><b>Games Masters:</b></span></a><br><br>


<font color="#FFA500">Rodrigo -</font> GM L�der & Evento <br><br>
<font color="#FFA500">Alex -</font> GM Evento & Suporte<br><br>
<font color="#FFA500">Vaga -</font> GM Evento & Suporte<br><br>


<span style="color:lime; background: transparent url(http://tinyurl.com/outgum)"><b>Moderadores:</b></span></a><br><br>


<font color="lime"> -</font> Moderador Chat & Gunz </div></td><br>
<br>
</font>

</center>

					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>