<? include "inject.php" ?>
<? include "pls.php" ?>
<?php


$errmsg = "";
$teamname =antisql($_POST['teamname']);
$teampassword=antisql($_POST['teampassword']);
      


$email = antisql($_POST['email']);
$doit = antisql($_POST['doit']);
if (isset($_POST['submit'])){

	if ( $email == ""){
		msgbox ("enter","index.php?do=lostpass");
	}
	else {
		// go see if they are in the db

		
		$res = mssql_query("
                            SELECT a.AID, a.UserID, a.Email, l.password
                            FROM Account a INNER JOIN Login l ON a.AID = l.AID
                            WHERE a.Email = '$email'
");
		$row = mssql_fetch_row($res);
$userid = $row[1];
$pass = $row[3];
		if (!$row){
			msgbox ("failed","index.php?do=lostpass");
		}
		else {
$Name = "B2O Gaming Network";
$emailfrom = "info@b2ogaming.co.in";
$header = "From: ". $Name . " <" . $emailfrom . ">\r\n";
        $cabeceras = "Content-type: text/html\r\n";
$mailmssg ="Your B2O Gunz Account Details <br>______________<br>Username = ".$userid." <br>password = ".$pass." <br>______________<br>Please Do not give your Userid and password to anyone<br>The Administrators will never ask you for your password<br>______________<br>B2O Staff";
ini_set('sendmail_from', 'info@b2ogaming.co.in');
			mail("$email", "Lost B2O Gunz Password",$mailmssg,$cabeceras,$header);
msgbox ("Sent","index.php?do=lostpass");
			
		}


	}
}
?>
<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php

echo "
<div id='content'>
<h1>Team Log-In</h1>
<p><font color='red'><b>{$errmsg}&nbsp;</b></font></p>
<p>Please enter the email account your team registered with.</p>
<p>&nbsp;</p>

<p><form action='index.php?do=lostpass' method='post'>
<input type='hidden' name='doit' value='yes'>
	email<br><input type='text' name='email' value='email'>


<br><input type='submit' value='Retrieve Password' name='submit'>
</form>
</div>

";

?>

</body>
</html>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			