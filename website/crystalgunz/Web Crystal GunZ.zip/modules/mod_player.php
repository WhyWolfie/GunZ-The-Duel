<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'antiflood.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>

<?
if( $_SESSION[AID] == "" )
{
echo "Para acessar esta p�gina voc� deve estar logado!";
die();
}
?>					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center"><br><br><br>

<center><a href='index.php?do=recuperar'><font color='lime'>Recuperar Char</font></a>  |    
<a href='index.php?do=color'><font color='cyan'>Comprar Name Color</font></a>    |    
<a href='index.php?do=jjang'><font color='4EEE94'>Comprar Jjang</font></a>   </center><br><br>


 Copyright &copy; 2012 Player Painel <span style="color:#FF4500; background: transparent url(http://tinyurl.com/outgum)">KnightGunZ</span></a>
<br>
</center>


</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>



					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td><br>