<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'antiflood.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>
<?
if($_SESSION[AID] == "")
{
?>
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
                        <body onload="FP_preloadImgs(/*url*/'images/btn_login_on.jpg', /*url*/'images/btn_editclan_on.jpg');">

                        <form name="login" method="POST" action="index.php?do=login&header=1">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/md_login.jpg'); background-repeat:no-repeat" width="175" background="images/md_login.jpg">
								<tr>
									<td width="5" height="175">&nbsp;</td>
									<td width="156" valign="top" height="175">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="156">
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="154" colspan="2">&nbsp;</td>
											</tr>
											<tr>
												<td width="83">
												<input name="userid" size="12" class="textLogin" style="float: left" tabindex="1"></td>
												<td width="69" rowspan="3">
												<div align="center">
												<input border="0" src="images/btn_login_off.jpg" id="img812" name="submit" width="57" height="47" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img812',/*url*/'images/btn_login_on.jpg')" type="image"></div></td>
											</tr>
											<tr>
												<td width="83">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="83">
												<input name="pasw" size="12" class="textLogin" style="float: left" type="password" tabindex="2"></td>
											</tr>
											<tr>
												<td width="152" colspan="2">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="152" colspan="2" height="50" valign="middle">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="100%">
														<tr>
															<td width="2"></td>
															<td width="10">
															<img border="0" src="images/mis_arrow.jpg" width="5" height="9" id="img1783"></td>
															<td width="134" align="left">
															
															<span style="font-size: 7pt"><a href="registro/index.php?do=register">Registro</a></span></td>
														</tr>
														<tr>
															<td width="2"></td>
															<td width="10">
															<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
															<td width="134" align="left">
															
															<span style="font-size: 7pt"><a href="index.php?do=donate">Doa��o</a></span></td>
														</tr>
													
</table>
												</div>
												</td>
											</tr>
										</table>
									</div>
									<p>&nbsp;</td>
									<td width="8" height="175">&nbsp;</td>
								</tr>



								</table>
							<input type="hidden" name="submit" value="1">
							</form>

<?
}else{
//And again.
$res = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$d = mssql_fetch_assoc($res);

//No shit?
$res2 = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$numitems = mssql_num_rows($res2);
?>

<div align="center">
<div align="center">
						<table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
								<td background="images/account.jpg" height="36" width="195">&nbsp;</td>
                <td></td>
                <td></td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
																	<table border="0" style="border-collapse: collapse" width="193" height="100%" id="table10" class="iLogin">
										<tr>
											<td width="191" colspan="2">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">
											
											<font size="2" face="Tahoma">Bem Vindo, <?=$_SESSION['UserID']?>!</font></td>
										<tr><br>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											<a href="index.php?do=player"><br>
<font style='color: cyan'><b>� </b></font> <font color="	lime">Player Painel - <img src="http://www.freeiconsweb.com/Icons/16x16_New_icons/New_icons_24.gif" alt="New" /></font></a>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
										
										</tr>
                             
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;&nbsp;
											
											<a href="index.php?do=login&action=logout&header=1">[Sair]</a></td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
											<td width="181">&nbsp;</td>
										</tr>
										<tr>
											<td colspan="2">
											<div align="center">
												<table border="0" width="171" height="169" style="border-collapse: collapse; background-image: url('images/accountframe.jpg')">
													<tr>
														<td height="29" width="12">&nbsp;</td>
														<td height="29" width="155" colspan="2">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
										                                <td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_rzcoinsUU1.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['RZCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
												  </tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_evcoins98Z.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b>
														<span style="font-size: 7pt">
														<?=$d['EVCoins']?></span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url('images/af_guestpasses.jpg'); background-repeat: no-repeat; background-position-x: left">
														<p align="right"><b><span style="font-size: 7pt">
														</span></b><span style="font-size: 7pt">&nbsp;&nbsp;
														</span></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
													<tr>
														<td width="12" height="24">&nbsp;</td>
														<td width="138" height="24" style="background-image: url(''); background-repeat: no-repeat; background-position-x: left">
														<a href="/UserPanel/Index.php">
														<img border="0" src="images/af_editaccountinfo.jpg" width="138" height="22" id="img3" onMouseOut="FP_swapImgRestore()" onMouseOver="FP_swapImg(1,1,/*id*/'img3',/*url*/'images/af_editaccountinfo_hover.jpg')"></a></td>
														<td width="15" height="24" style="background-repeat: no-repeat; background-position-x: left">&nbsp;</td>
													</tr>
												</table>
											</div>
											</td>
										</tr>
										</table>
								
								</td>
                <td></td>
                <td></td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22">&nbsp;</td>
                <td></td>
                <td></td>
							</tr>
								<tr>
									<td width="169" colspan="3" >&nbsp;</td>
								</tr>



						</table>
<div align="center">
<div align="center">

<?
}
?>
