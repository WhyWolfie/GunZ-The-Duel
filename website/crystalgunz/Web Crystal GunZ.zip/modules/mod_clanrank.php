<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>
<style type="text/css">
<!--
.Estilo6 {font-size: 10px; font-weight: bold; font-family: verdana; color: #FFFFFF; }
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('img/play_on.png','img/playerranking.png')">
<table width="647" border="0" style="border-collapse: collapse; background-repeat: no-repeat;">
  <tr>
    <td width="445" height="402" valign="top">
      <div align="center">
        <table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
          <tr>
            <td style="background-image: url('images/content_title_ranking1.jpg'); background-repeat: no-repeat; background-position: center top" height="28" width="603" colspan="3">&nbsp;</td>
          </tr>
          <tr>
            <td style="background-repeat: repeat; background-position: center top" width="7" rowspan="5">&nbsp;
                <p>&nbsp;</p>
                <p></td>
            <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp; </td>
            <td style="background-repeat: repeat; background-position: center top" width="7" rowspan="5">&nbsp;</td>
          </tr>
          <tr>
            <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
              <div align="center">
                <table border="0" style="background-position: center top; border-collapse: collapse; background-image: url('images/content_ranking_clan_top4.jpg'); background-repeat:no-repeat" width="563" height="146">
                  <?
                                            $res = mssql_query("SELECT TOP 100 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC ");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "http://69.162.104.51/images/") ? "images/no_emblem.png" : $resa->EmblemUrl;

                                            if($Count == 4)
                                                break;
                                            else
                                                $Count++;
                                        }


                                        ?>
                  <tr>
                    <td width="144" valign="bottom" height="107">
                      <div  align="center"> <img src="http://kgz.zapto.org<?=($FirstClan[0][EmblemURL] == "") ? "no_emblem.png" : $FirstClan[0][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></div></td>
                    <td width="135" valign="bottom" height="107">
                      <div align="center"> <img src="http://kgz.zapto.org<?=($FirstClan[1][EmblemURL] == "") ? "no_emblem.png" : $FirstClan[1][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></div></td>
                    <td width="126" valign="bottom" height="107">
                      <div align="center"> <img src="http://kgz.zapto.org<?=($FirstClan[2][EmblemURL] == "") ? "no_emblem.png" : $FirstClan[2][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></div></td>
                    <td width="151" valign="bottom" height="107">
                      <div align="center"> <img src="http://kgz.zapto.org<?=($FirstClan[3][EmblemURL] == "") ? "no_emblem.png" : $FirstClan[3][EmblemURL];?>" width="64" height="64" style="border: 1px solid #000000"></div></td>
                  </tr>
                  <tr>
                    <td width="556" colspan="4" height="40">
                      <div align="center">
                        <table border="0" style="border-collapse: collapse" width="556" height="100%">
                          <tr>
                            <td width="5">&nbsp;</td>
                            <td width="128">
                              <div align="center"> <font color="#FF0000"> <b>
                                <?=($FirstClan[0][Name] == "") ? "No Data" : $FirstClan[0][Name];?>
                            </b></font></div></td>
                            <td width="10">&nbsp;</td>
                            <td width="126">
                              <div align="center"> <b>
                                <?=($FirstClan[1][Name] == "") ? "No Data" : $FirstClan[1][Name];?>
                            </b></div></td>
                            <td width="7">&nbsp;</td>
                            <td width="122">
                              <div align="center"> <b>
                                <?=($FirstClan[2][Name] == "") ? "No Data" : $FirstClan[2][Name];?>
                            </b></div></td>
                            <td width="11">&nbsp;</td>
                            <td width="122">
                              <div align="center"> <b>
                                <?=($FirstClan[3][Name] == "") ? "No Data" : $FirstClan[3][Name];?>
                            </b></div></td>
                            <td width="7">&nbsp;</td>
                          </tr>
                          <tr>
                            <td width="5">&nbsp;</td>
                            <td width="128">&nbsp;</td>
                            <td width="10">&nbsp;</td>
                            <td width="126">&nbsp;</td>
                            <td width="7">&nbsp;</td>
                            <td width="122">&nbsp;</td>
                            <td width="11">&nbsp;</td>
                            <td width="122">&nbsp;</td>
                            <td width="7">&nbsp;</td>
                          </tr>
                        </table>
                    </div></td>
                  </tr>
                </table>
            </div></td>
          </tr>
          <tr>
            <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
              <div align="center">
                <table border="0" style="border-collapse: collapse; background-image: url('images/content_ranking_data_bg.jpg'); background-repeat: no-repeat; background-position: center top">
                  <tr>
                    <td width="14" height="21">&nbsp;</td>
                    <td width="60" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b> Ranking</b></font></div></td>
                    <td width="44" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b>Emblem</b></font></div></td>
                    <td width="98" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b>Clan Name</b></font></div></td>
                    <td width="93" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b> Leader</b></font></div></td>
                    <td width="82" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b>Win/Losses</b></font></div></td>
                    <td width="92" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b>Win %</b></font></div></td>
                    <td width="69" height="21" valign="bottom">
                      <div align="center"> <font face="Tahoma"><b> Points</b></font></div></td>
                    <td width="13" height="21">&nbsp;</td>
                  </tr>
                  <tr>
                    <td width="14">&nbsp;
                        <p>&nbsp;</p>
                        <p>&nbsp;</p>
                        <p></td>
                    <td width="538" colspan="7" valign="top">
                      <div align="center">
                        <table border="0" style="border-collapse: collapse" width="102%">
                          <tr>
                            <td width="59">&nbsp;</td>
                            <td width="43">&nbsp;</td>
                            <td width="99">&nbsp;</td>
                            <td width="93">&nbsp;</td>
                            <td width="82">&nbsp;</td>
                            <td width="92">&nbsp;</td>
                            <td width="69">&nbsp;</td>
                          </tr>
                          <?
                                                        $res = mssql_query("SELECT TOP 100 * FROM CLAN WHERE DeleteFlag=0 OR DeleteFlag=NULL ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");
                                                        if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count = 1;
                                                            while($clan = mssql_fetch_object($res))
                                                            {
                                                        ?>
                          <tr>
                            <td width="59" align="center"> <b>
                              <?=$count?>
                            </b></td>
                            <td width="43" align="center">
                              <div align="center"> <img src="http://kgz.zapto.org<?=($clan->EmblemUrl == "") ? "no_emblem.png" : $clan->EmblemUrl;?>" width="34" height="30" style="border: 1px solid #000000"></div></td>
                            <td width="99" align="center">
                              <?=$clan->Name?>
                            <td width="93" align="center">
                              <?=GetCharNameByCID($clan->MasterCID)?></td>
                            <td width="82" align="center">
                              <?=$clan->Wins . "/" . $clan->Losses?></td>
                            <td width="92" align="center">
                              <?=GetClanPercent($clan->Wins, $clan->Losses)?></td>
                            <td width="69" align="center">
                              <?=$clan->Point?></td>
                          </tr>
                          <?
                                                            $count++;
                                                            }
                                                        }else{
                                                        ?>
                          <tr>
                            <td width="537" align="center" colspan="7"> No Data </td>
                          </tr>
                          <?
                                                        }
                                                        ?>
                        </table>
                    </div></td>
                    <td width="13">&nbsp;</td>
                  </tr>
                </table>
              </div>
              <p></td>
          </tr>
          <tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<p>&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
				</table>