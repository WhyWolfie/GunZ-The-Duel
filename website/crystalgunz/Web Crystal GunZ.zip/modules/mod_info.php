<Body>
	<body bgcolor="#312F30">
<span><h3>
<center><font color="lime">K</font>night GunZ - <font color="lime">I</font>nforma��es</center><br><br></h3>
<center><?
function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$accsBan = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT WHERE UGRADEID=253"));
$accs = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM ACCOUNT"));
$characters = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Character"));
$clans = mssql_fetch_row(mssql_query("SELECT COUNT(*) FROM Clan"));
$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>
<?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = '� Game Server';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "&nbsp;<font style='color: FFFFFFFFF'></font>$name:<font style='color: #FF0000'><B>Offline</B></font><br />";
        }
        else
        {
            echo "<font style='color: FFFFFFFFF'></font>$name: <font style='color: #00FF00'><B>Online</B></font><br />";
            fclose($fp);
        }
    }
    ?>
� Recorde Online: <?
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<font style='color: #1E90FF'><b><?=$b['PlayerCount']?></b></font><br>
� Total de Contas: <strong><? echo $accs[0]; ?></strong> <br />
� Personagens: <strong><? echo $characters[0]; ?></strong> <br />
� Total de Cl�s: <strong><? echo $clans[0]; ?></strong> <br />
� Total de Banidos: <strong><? echo $accsBan[0]; ?><br></strong>
<?php
 
//VIPS
$query = mssql_query("SELECT * FROM Account WHERE UgradeID = 104 "); 
$num_rows = mssql_num_rows($query); 
echo "� Total de Mudos:<b> ".$num_rows."</b><n>";

?><br></center>
</span></h3><br><br>

<center>_________________________________________________________________</center><br><br><br>


<b><center><font color="blue">I</font>nforma��es do <font color="blue">S</font>ervidor:<br></b><br><br></center>


� Exp: 30x<br>
� Loja Donator / Loja Evento / Loja Custom<br>
� Quest Server & CW server<br>
� Launcher Auto-Updater<br>
� Emblemas nos Cl�s<br>
� Custom Mapas & Quests<br>
� Control Painel<br><br><br>

<b><center><font color="blue">I</font>nforma��es do <font color="blue">H</font>ardware:<br></b><br><br></center>

� 100% Dedicado<br>
� Dual Xeon E5420 2.5 GHz<br>
� 6 GB Ram<br>
� 24 Horas Online<br>
� 99.8% Uptime<br>
� Conex�o Fibra �pitica 100MB/s<br><br>
<center>_________________________________________________________________</center><br><br><br>
<center>
<span><h3><br>
<font color="orange">F</font>�rum <font color="orange">O</font>nline
</span></h3>
Se voc� tem alguma d�vida, opini�o,<br> sugest�o, cr�tica, utilize nosso f�rum:
<br><a href="http://forum.knightgunz.com"><u>Clique aqui!</u></a><br><br></center>




					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>