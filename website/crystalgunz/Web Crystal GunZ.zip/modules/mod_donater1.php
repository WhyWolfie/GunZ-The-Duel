Promo��o DONATE no servidor, confira abaixo a nossa tabela de promo��o.<br><br><br>


Rela��es e Planos:<br><br><br>

Plano 1 - <font color="#00BFFF">150</font> KG Coins 	<font color="lime">[10,00 R$]</font><br><br>	

Plano 2 - <font color="#00BFFF">250</font> KG Coins	<font color="lime">[20,00 R$]</font><br><br>	

Plano 3 - <font color="#00BFFF">400</font> KG Coins	<font color="lime">[30,00 R$]</font><br><br>	

Plano 4 - <font color="#00BFFF">500</font> KG Coins	<font color="lime">[40,00 R$]</font><br><br>	

Plano 5 - <font color="#00BFFF">650</font> KG Coins	<font color="lime">[50,00 R$]</font><br><br>	

Plano 6 - <font color="#00BFFF">850</font> KG Coins	<font color="lime">[60,00 R$]</font><br><br>	

Plano 7 - <font color="#00BFFF">1050</font> KG Coins	<font color="lime">[80,00 R$]</font><br><br>	

Plano 8 - <font color="#00BFFF">1250</font> KG Coins	<font color="lime">[100,00 R$]</font><br><br><br>


<font color="red">Aten��o:</font> Promo��o v�lida at� dia 31/01/2012<br><br><br>

Atenciosamente,<br>
Equipe Knight Gunz.