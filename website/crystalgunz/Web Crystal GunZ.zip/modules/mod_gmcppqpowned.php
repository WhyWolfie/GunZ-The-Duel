<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form method="GET" action="index.php?do=gmcppqpowned"><table border="0" style="border-collapse: collapse" width="195" id="table5">
							<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="enviar_ecoin_afzz98888J" name="do">Enviar EV Coins<br>
										<input type="radio" value="remover_ecoin_afzz" name="do">Retirar EV Coins<br>
										<input type="radio" value="x_unbanaf11" name="do">Desban/Unmute Usuario<br>
										<input type="radio" value="banirpeter" name="do">Banir Usuario<br>
										<input type="radio" value="muteuser_zz1" name="do">Mutar Usuario<br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Ir" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr></form>
<p>&nbsp;</p>

							