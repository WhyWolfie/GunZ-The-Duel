<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'antiflood.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>
<?php
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

$item_name = $_POST['item_name'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$txn_id = $_POST['txn_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$userid = $_POST['custom'];

if (!$fp) {
} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
$res = fgets ($fp, 1024);
if (strcmp ($res, "VERIFIED") == 0) {
$res = mssql_query_logged("SELECT * FROM PayPal WHERE TransactionID = '$txn_id'");
if (mssql_num_rows($res) >= 1){
include 'completed.php';
}else{
/////////////////////////
$query = mssql_query_logged("SELECT [RZCoins] FROM [Account] WHERE [UserID] = '$userid'");
$item = mssql_fetch_assoc($query);
$coins = $item['RZCoins'];
$amountcoins = $_POST['mc_gross'];
$coins += $amountcoins*10;
mssql_query_logged("UPDATE [Account] SET [RZCoins] = $coins WHERE [UserID] = '$userid'");
/////////////////////////
mssql_query_logged("INSERT INTO PayPal (TransactionID, Amount, Email)Values ('$txn_id', '$payment_amount', '$payer_email')");
include 'completed.php';
}
}
else if (strcmp ($res, "INVALID") == 0) {
include 'invalid.php';
}
}
fclose ($fp);
}
?>