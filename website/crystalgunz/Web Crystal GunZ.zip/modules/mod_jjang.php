<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="images/cont_up.png">&nbsp;</td>
    </tr>
    <tr>
      <td background="images/cont_bg.png"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>
<?
//Comprar Jjang by SayntPark '-' saynt o caralho, by heart

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

$busca57 = mssql_query("SELECT EVCoins FROM Login WHERE AID = '$aid22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<span style="color:#00FF00; background: transparent url(http://tinyurl.com/outgum)"><b>Comprar Jjang</b></span></a></br><br>

<br><font color="#88h154a">Qual utilidade do jjang?</font><br>

Nada, apenas um adere�o para seu personagem.<br><br>

<font color="#00CD00">Qual o valor?</font><br>

Para ter um jjang voc� gastar� 25 Ev coins.<br><br>

<font color="#FF34B3">Qual e a cor do jjang ?</font><br>

O jjang tem a cor : <font color="#4EEE94">Jjang</font><br><br>


<a href="?do=jjang&step=1"><input type="submit" name="proximo" value="Comprar JJang!" /></a><br><br>

Voce tem um total de <?=$busca58[0]?>
Ev Coins , apos fazer essa compra ira sobrar 
<?=$busca58[0]-25
?>
<?
}else{

$buscanome = "SELECT EVCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 25) 
{
	echo "Desculpe, seus ecoins n�o s�o suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE AID = '$aid22'");
mssql_query("update Login set EVCoins=EVCoins-25 where AID='$aid22'");
echo "Compra realizada, relogue.<br>";
}


}
}

$date = date("d-m-y - H:i:s");
$logfile = fopen("Logs Jjang.txt","a+");
$logtext = "$date - IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou Jjang. \r\n";
fputs($logfile, $logtext);
fclose($logfile);


?>


          </tr>
          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="images/cont_top.png" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td><br>