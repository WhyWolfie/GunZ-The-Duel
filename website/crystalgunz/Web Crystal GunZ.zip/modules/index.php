<?
error_reporting(E_ALL);
ini_set('display_errors', '0');
include "config.php";
include "functions.php";
include "banneduser.php";
include "pls.php";
include "inject.php";
include "inject2.php";
include "inject3.php";
include "anti_Sql.php";
include "antiflood.php";
include "anti_inject.php";
include "anti_inject2.php";
include "anti_injectx.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("modules/mod_" . antisql($_GET['do']) . ".php")) {
        include "modules/mod_" . antisql($_GET['do']) . ".php";
	}
} }
include "includes/banneduser.php";
include "includes/checkcookie.php";
include "includes/captcha/securimage.php";
include "checkcookie.php";
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="Pragma" content="no-cache" />
<title>CrystalGunz - Website</title>
<link rel="icon" href="favicons.ico" type="image/ico"/>
<link rel="stylesheet" type="text/css" href="images/style.css">
<link rel="stylesheet" type="text/css" href="frontpage.css" />
<script type="text/javascript">var _siteRoot='index.php',_root='index.php';</script>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js?ver=1.3.2'></script>
<script type='text/javascript' src='js/presentationCycle.js'></script>
<script type="text/javascript" src="js/slider.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/nav.js"></script>
<script language="JavaScript" src="js/functions.js"> </script>
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.ico" type="image/ico"/>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
.style2 {font-size: xx-small}
-->
</style>
<script>
function click() {
if (event.button==2||event.button==3) {
oncontextmenu='return false';
}
}
document.onmousedown=click
document.oncontextmenu = new Function("return false;")
</script> 
<link rel="shortcut icon" href="favico.ico" />
</head>
<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" background="http://walls.free.total-wallpapers.com/free-wallpapers/3470/Black-Floor-1680x1050.jpg"><div align="center">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr><td bgcolor="#000000">
</td>
</tr>
                

</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" bgcolor="0000000####">

                           


			<td width="921" height="200"><img src="images/BannerKnight.jpg" alt="banner" width="921" height="200"></td>
	  </tr>

		<tr>
<td bgcolor="#000000">
<ul class="topnav">  
     <li><a href="index.php">In�cio</a></li>  
     <li>  
         <a href="/Registro/index.php?do=register">Registro</a>  
     </li>  
     <li>  
         <a href="index.php?do=download">Downloads</a>  
         <ul class="subnav">  
             <li><a href="index.php?do=downloads&expand=1&sub=client">Knight GunZ </a></li>  
             <li><a href="index.php?do=downloads&expand=1&sub=WallPapers">Wallpapers</a></li>  
             <li><a href="index.php?do=downloads&expand=1&sub=Screenshots">Sceenshots</a></li>  
         </ul>  
     <li><a href="index.php?do=ranking&sub=individual&expand=1">Ranking</a>
         <ul class="subnav">  
             <li><a href="index.php?do=individualrank">Individual Ranking</a></li>  
             <li><a href="index.php?do=clanrank">Cl� Ranking</a></li>   
         </ul>  
       </li>  

     <li><a href="#">Loja de Itens</a>
         <ul class="subnav">  
             <li><a href="webstore/index.php?do=rzitemshop&sub=listallitems&expand=1&type=1">Loja Donator</a></li>  
             <li><a href="webstore/index.php?do=evitemshop&sub=listallitems&expand=1&type=1">Loja Evento</a></li>
             <li><a href="webstore/index.php?do=customshop&sub=listallitems&expand=1&type=1">Loja Custom</a></li>   
         </ul>

     <li><a href="#">Painel de controle</a>
         <ul class="subnav">  
             <li><a href="/UserPanel">Painel do Usu�rio</a></li>   
             <li><a href="index.php?do=emblemas">Painel de Cl�s</a></li>
         </ul> </li>  
     <li><a href="#">Utilit�rios</a>
         <ul class="subnav">     
             <li><a href="index.php?do=info">Informa��es do Server</a></li> 
             <li><a href="index.php?do=regras">Regras do Servidor</a></li>
         </ul>   
     <li><a href="index.php?do=equipe"><font color="#FFFFFFF">Equipe</font></a></li>
     <li><a href="index.php?do=donate"><font color="#FF0000">Doa��o</font></a></li>
     <li><a href="http://www.knightgunz.com/forum" target="_blank"><font color="#FFFFFF">F�rum</font></a></li>
 </ul></td></tr>
		<tr>
			<td background="images/BGcolor.png">		
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 				<?	
						if ($_GET['expand'] == 1){
   						if (file_exists("modules/mod_" . antisql($_GET['do']) . ".php")) {
        							include "modules/mod_" . antisql($_GET['do']) . ".php";
        							$include = "1";
								}
						}
 						?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
						<? include "modules/mod_clanranking.php" ?>
						</div>
					</td>
					<td width="481" valign="top">
						<? 	if($opened == 0){
                        					include "mod_offline.php";
                    				   	}else{
                    					if (isset($_GET['do'])) 
							{
                            					$_GET['expand'] = 0;
						   			if (file_exists("modules/mod_" . antisql($_GET['do']) . ".php")) {
							    		include "modules/mod_" . antisql($_GET['do']) . ".php";
						    			}
                        				}else{
                            					include "modules/mod_index.php";
					    		}
                        				if(isset($default)){
                            					include $default;
                        				}  
						}
                        ?></td>

				</tr>
				</table><br>
		  
</td>
</tr>
			</td>
		</tr>

	</table>
</div>
</body><center>
<br>
<font color="white"><p>Copyright &copy; 2012 Crystal GunZ @Inc.<br />
  Gunz &eacute; uma marca registrada pela <U><a href="#">Maiet Entertainment</a></U><br />
  Crystal GunZ � um servidor totalmente gratuito e independente, as doa&ccedil;&otilde;es<br />
  s&atilde;o utilizadas para cobrir os gastos do servidor.</br>
<script language=JavaScript>
<!--
var mensagem="";
function clickIE() {if (document.all) {(mensagem);return false;}}
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(mensagem);return false;}}}
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// --> 
</script>
</html>
