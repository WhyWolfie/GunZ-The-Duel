<?
if($_SESSION['AID'] == ""){
    msgbox("Please login first.","index.php?do=login");
exit();
}else{
if(isset($_POST['submit'])){
$OldName = antisql($_POST['OldName']);
$NewName = antisql($_POST['NewName']);
$minleghth_limit = 4;
$maxleghth_limit = 12;
$new_string = eregi_replace("([A-Z0-9���������������������������������������������������������������������������������������������������� �~��]+)","",$NewName);
if (strlen($_POST['NewName']) < $minleghth_limit)
{
msgbox("Minimum 4 Characters","index.php?do=ccn");
}else
if (strlen($_POST['NewName']) > $maxleghth_limit)
{
msgbox("Maximum 12 Characters","index.php?do=ccn");
}else
if($new_string){
msgbox("Invalid Characters","index.php?do=ccn");
}
else
{
$r=mssql_query("SELECT * FROM Character WHERE AID = '" . antisql($_SESSION['AID']) . "' AND Name != '' ");
        if(mssql_num_rows($r) == 0){
                        msgbox("The Character dont exist!!!","index.php?do=ccn");
        }
$r2=mssql_query("SELECT * FROM Character WHERE Name = '$NewName'");
        if(mssql_num_rows($r2) > 0){
                        msgbox("The Character name Already exists!!!","index.php?do=ccn");
}else{
$res2 = mssql_query("SELECT euCoins FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
$acc = mssql_fetch_assoc($res2);
$updatecoins = $acc['euCoins'] - 50 ;
if($updatecoins < 0){
msgbox ("Insufficent B2O Coins","index.php?do=ccn");
exit();
}
$eucoins = $data['euCoins'];
mssql_query("UPDATE Character SET Name = '$NewName' WHERE Name = '$OldName'");
mssql_query("UPDATE Login SET euCoins = '$updatecoins' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
mssql_query("INSERT INTO [charnamelog] ([OldName], [NewName])VALUES('$OldName', '$NewName')");  
msgbox("Char name changed!!!","index.php?do=ccn");
                }
                }}
?>
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="http://forum.ragezone.com/images/style.css">
</head>

        <body bgcolor="#000000">

                                        <div align="center">
                                                <table border="0" width="456" style="border-collapse: collapse">
                                                        <tr>
                                                                <td background="http://forum.ragezone.com/images/cont_up.jpg">&nbsp;</td>
                                                        </tr>
                                                        <tr>
                                                                <td background="http://forum.ragezone.com/images/cont_bg.jpg">
                                                                <div align="center">
                                                                        <form method="POST" action="index.php?do=ccn"><table border="0" style="border-collapse: collapse" width="454" height="100%">
                                                                                <tr>
                                                                                        <td width="1" rowspan="10">&nbsp;</td>
                                                                                        <td colspan="3">
                                                                                        <img border="0" src="http://forum.ragezone.com/images/inf/changename.jpg" width="413" height="17"></td>
                                                                                        <td width="4">&nbsp;</td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td colspan="3">&nbsp;                                                                                        </td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204">
                                                                                          <p align="right">
                                              <font color="#FFFFFF">Old Character Name</font></td>
                                                                                        <td width="5"><font color="#FFFFFF">&nbsp;
                                            </font>                                                                                        </td>
                                                                                        <td width="218">
                                            <font color="#FFFFFF"><select name="OldName">
    <?php
    $query6 = mssql_query("SELECT * FROM Character WHERE AID = '" . antisql($_SESSION['AID']) . "' AND Name != '' ");
    while($row = mssql_fetch_array($query6))
    {
        echo '<option name="'.$row['Name'].'">'.$row['Name'].'</option>';
    }
    ?>
</select></font></td>
                                                                                </tr>

                                                                                <tr>
                                                                                        <td width="204" align="right" valign="top">
                                            <font color="#FFFFFF">New Character Name</font></td>
                                                                                        <td width="5">&nbsp;</td>
                                                                                  <td width="218"><font color="#FFFFFF"><input name="NewName" type="text" id="NewName" size="20"></font></td>
                                                                                </tr>
                                                                                                                                                                               <tr>
                                                                                                        <td width="200" valign="top">&nbsp;</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">&nbsp;</td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td width="200" valign="top">
                                                                                                        <p align="right">Name of
                                                                                                        item</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">
                                                                                                        <b>Character Name Change</b></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td width="200" valign="top">
                                                                                                        <p align="right">Current bill</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">
                                                                                                        <b><?=antisql($_SESSION['UserID'])?></b></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td width="200" valign="top">
                                                                                                        <p align="right">Coins</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">
                                                                                                        <b>50 Coins </b></td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                        <td width="200" valign="top">
                                                                                                        <p align="right">B2O Coins to you later</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">
                                                                                                        <b><?=$data['euCoins']-50;?> Coins </b></td>
                                                                                                </tr>
                                                                                		<tr>
                                                                                        		<td width="1" rowspan="10">&nbsp;</td>
                                                                                        		<td colspan="3">
                                                                                                        <font color="#FF0000"><b>
                                                                                                        <center>NOTE: If you change character name and then do not want, or is mistaken, we are not responsible</b></center></font></td>
                                                                                        	<td width="4">&nbsp;</td>
                                                                                		</tr>
                                                                                                <tr>
                                                                                                        <td width="200" valign="top">&nbsp;</td>
                                                                                                        <td width="8" valign="top">&nbsp;</td>
                                                                                                        <td width="222" valign="top">&nbsp;</td>
                                                                                                </tr>
                                                                                		<tr>
                                                                                        		<td colspan="3">
                                                                                        		<p align="center">
                                                                                        		<font color="#FFFFFF">
                                                                                        		<input type="submit" value="Change Char Name" name="submit"></font></td>
                                                                                		</tr>
                                                                                <tr>
                                                                                        <td colspan="3"></td>
                                                                                </tr>
                                                                                </table>
                                                                        </form>
                                                                </div>
                                                                </td>
                                                        </tr>
                                                        <tr>
                                                                <td background="http://forum.ragezone.com/images/cont_top.jpg" height="27">&nbsp;</td>
                                                        </tr>
                                                </table>
                                        </div>
<?
}
?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>