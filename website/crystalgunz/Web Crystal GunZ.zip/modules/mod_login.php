<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'antiflood.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>
<?
$show =1;
//Check if is logued
if(!function_exists("ShowResetPwdForm")){
    function ShowResetPwdForm(){
        if(!$_SESSION['AID'] == ""){re_dir("index.php");}
$errmsg = "";
$teamname =antisql($_POST['teamname']);
$teampassword=antisql($_POST['teampassword']);
$email = antisql($_POST['email']);
$doit = antisql($_POST['doit']);
if (isset($_POST['submit'])){
	if ( $email == ""){
		
	}
	else {
		$res = mssql_query("
                            SELECT a.AID, a.UserID, a.Email, l.password
                            FROM Account a INNER JOIN Login l ON a.AID = l.AID
                            WHERE a.Email = '$email'
");
$row = mssql_fetch_row($res);
$userid = $row[1];
$pass = $row[3];
		if (!$row){
		
		}
		else {
$Name = "B2O Gaming Network";
$emailfrom = "info@b2ogaming.co.in";
$header = "From: ". $Name . " <" . $emailfrom . ">\r\n";
        $cabeceras = "Content-type: text/html\r\n";
$mailmssg ="Your B2O Gunz Account Details <br>______________<br>Username = ".$userid." <br>password = ".$pass." <br>______________<br>Please Do not give your Userid and password to anyone<br>The Administrators will never ask you for your password<br>______________<br>B2O Staff";
ini_set('sendmail_from', 'info@b2ogaming.co.in');
			mail("$email", "Lost B2O Gunz Password",$mailmssg,$cabeceras,$header);
msgbox ("A mail with the account details has been sent to $email, Please check your junkmail and inbox ","index.php");
			
		}

}
	}

            ?>
            					
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="9">&nbsp;</td>
											<td width="436" colspan="3">
											<img border="0" src="images/inf/resetaccountdata.jpg" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;<?=@$errorbox?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="181">
											<p align="right">&nbsp;Enter your 
											Email ID</td>
											<td width="9">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="email" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<p align="center">
											<input type="submit" value="Retrieve Password" name="submit"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="3">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>

<?
}

//Logout
switch ($_GET['action']) {
    case "logout";
		//Oops?
        $user = antisql($_SESSION['UserID']);
        $user = ucfirst($user);
		//How about session_destroy next time?.
        unset($_SESSION['AID']);
        unset($_SESSION['UserID']);
        unset($_SESSION['euCoins']);
        unset($_SESSION['UGradeID']);  
        setcookie ("MPOGLogin_usr", "", time() - 3600);
        setcookie ("MPOGLogin_pwd", "", time() - 3600);
        echo "<body bgcolor='#000000'><script language='Javascript'> document.location = 'index.php';alert('$user Disconnected.'); </script>";
        break;
    
        ShowResetPwdForm();
        $show =0;
    break;
}

if(!$_SESSION['AID']== ""){
    echo "<script language='Javascript'> document.location = 'index.php';alert('Already logged out'); </script>";
}


if (isset($_POST['submit']) and $show ==1){
    $user = antisql($_POST['userid']);
    $pwd = antisql($_POST['pasw']);
    $sql = mssql_query("SELECT * FROM Login WHERE UserID = '".$user."' AND Password = '".$pwd."'");
    if (mssql_num_rows($sql) == 1){
        $data = mssql_fetch_assoc($sql);
        $_SESSION['AID'] =  $data['AID'];
        $_SESSION['UserID'] = ucfirst($user);
        $_SESSION['euCoins'] = $data['euCoins'];
        //---
        $res2 = mssql_query("SELECT * FROM Account WHERE AID = '".$data['AID']."'");
        $aData = mssql_fetch_assoc($res2);
        $_SESSION['UGradeID'] = $aData['UGradeID'];
        if($_POST['cookie'] == "ON"){
            setcookie("MPOGLogin_usr", $user, time()+60*60*24*100);
            setcookie("MPOGLogin_pwd", md5("mpogc_".$data['Password']), time()+60*60*24*100);
        }else{
            setcookie ("MPOGLogin_usr", "", time() - 3600);
            setcookie ("MPOGLogin_pwd", "", time() - 3600);
        }
        header("Location: index.php");
    }else{
        echo "<body bgcolor='#000000'><script language='Javascript'> alert('ID or password is incorrect');document.location = 'index.php?do=login'; </script>";
    }
}
if ($show ==1){
?>
<form name="reg" method="POST" action="index.php?do=login&header=1"><body bgcolor="#323232">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">

									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="436" colspan="2">
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;

											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<font color="#FF0000" face="Tahoma">
											<b><font size="2">
											</font></font></td>
											<td width="8">&nbsp;</td>

										</tr>
										<tr>
											<td width="208" valign="middle" align="right">
											User ID:</td>
											<td width="226" valign="middle">
											<input type="text" name="userid" size="20" class="login"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="208" align="right">
											Password:</td>
											<td width="226">
											<input type="password" name="pasw" size="20" class="login" style="background-image: url('images/passwordbg.jpg')"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>

											<td width="208">&nbsp;
											</td>
											<td width="226">
											<input type="checkbox" name="cookie" value="ON" checked>Login Automatico</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">

											<p align="center">
											<font color="#BCBCBC">&nbsp;
							  
											<a href="index.php?do=register">
											<br>Registro</a></font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
	
										</tr>

										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<p align="center">
											<input type="submit" value="Login �" name="submit"></td>

											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24" colspan="2">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>

								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>



<?
}





}







?>
					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td>
			
			