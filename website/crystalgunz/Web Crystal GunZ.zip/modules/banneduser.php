<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>Knight GunZ - Voc� se fudeu</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg.png);
}
-->
</style></head>
										<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>� infelizmente voc� se fudeu <?=$_SESSION['UserID']?>,</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

                                                                                           Sua conta foi banida pela equipe KnightGunZ.
											<p>Eu acho que voc� j� sabe como chegou a esse ponto.</p>
                                                                                        <p>Voc� sempre pode fazer uma nova conta a partir da p�gina de cadastro.</p>
                                                                                        <p>Voc� pode sempre tentar obter unbanned na se��o sobre o unban <a href="">forum</a>.</p>
                                                                                        <p>Ent�o, desta vez n�o se esque�a de ler e seguir as <a href="">Regras</a>.</p>
                                                                                        <p>Tenha um pess�mo dia.</p>
											<p>Obrigado, equipe Knight GunZ</td>
										</tr>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
<p><object style="height: 200px; width: 350px"><param name="movie" value="http://www.youtube.com/v/QERWnQXUQa0?version=3"><param name="allowFullScreen" value="true"><param name="allowScriptAccess" value="always"><embed src="http://www.youtube.com/v/QERWnQXUQa0?version=3" type="application/x-shockwave-flash" allowfullscreen="true" allowScriptAccess="always" width="370" height="230"></object></p>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


    <?
    die();
}

?>