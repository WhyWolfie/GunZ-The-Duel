<?php
include "includes/config.php";
include "includes/_functions.php";


$user_name=$_POST['user_name'];
$vusername=validate_username($user_name);

$existing_users = mssql_query("SELECT * FROM Login WHERE UserID='$user_name'");  
$numrows = mssql_num_rows($existing_users);

if($numrows>0 || $vusername<0)  
{
	//user name is not availble
	echo "no";
} 
else
{
	//user name is available
	echo "yes";
}
?>