< IfModule mod_security2.c>
  
  SecRuleEngine On
  
  SecDebugLog /var/log/apache2/modsec_debug.log
  SecDebugLogLevel 0
  
  # Serial audit log
  SecAuditEngine RelevantOnly
  SecAuditLogRelevantStatus ^5
  SecAuditLogParts ABIFHZ
  SecAuditLogType Serial
  SecAuditLog /var/log/apache2/modsec_audit.log
  
  # if there where more than 5 requests per second for this IP
  # set var block to 1 (expires in 5 seconds) and increase var blocks by one (expires in an hour)
  SecRule ip:requests "@eq 5" "phase:1,pass,nolog,setvar:ip.block=1,expirevar:ip.block=5,setvar:ip.blocks=+1,expirevar:ip.blocks=3600"
  
  # if user was blocked more than 5 times (var blocks>5), log and return http 403
  SecRule ip:blocks "@ge 5" "phase:1,deny,nolog,logdata:'req/sec: %{ip.requests}, blocks: %{ip.blocks}',status:403"
  
  # if user is blocked (var block=1), log and return http 403
  SecRule ip:block "@eq 1" "phase:1,deny,nolog,logdata:'req/sec: %{ip.requests}, blocks: %{ip.blocks}',status:403"
  
  SecRule REQUEST_LINE "^GET?\WWW\.ATARDE\.COM\.BR$ HTTP"\
    "nolog,deny,setvar:ip.ddos=+1,deprecatevar:ip.ddos=100/10"
  </IfModule>
  </blockquote>