<? include 'pls.php'; ?>
<? include 'inject.php'; ?>
<? include 'inject2.php'; ?>
<? include 'inject3.php'; ?>
<? include 'anti_sql.php'; ?>
<? include 'antiflood.php'; ?>
<? include 'anti_inject.php'; ?>
<? include 'anti_inject2.php'; ?>
<? include 'anti_injectx.php'; ?>

<?
//Script de recuperar character deletado by Heart ~
include "inject.php";
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

if( $_SESSION[AID] == "" )
{
echo "Para acessar esta p�gina voc� deve estar logado!";
die();
}

$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

$seleciona = mssql_query("SELECT DeleteName, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '1'");

if( mssql_num_rows($seleciona) < 1 )
{
echo "Voc� n�o tem personagens deletados";
die();
}

if($etapa == "")
{
?>

<form id="site_Login" name="site_Login" method="post" action="index.php?do=recuperar&etapa=1">
Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($seleciona))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>
<input type="submit" name="logar" value="Resgatar" />

<?
}

if($etapa == 1)
{

$cid22 = Filtrrar($_POST['cid22']);

$query1 = mssql_query("SELECT DeleteName FROM Character WHERE CID = '$cid22'");
$query2 = mssql_fetch_row($query1);

$query3 = mssql_query("SELECT TOP 1 CharNum FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0' ORDER BY RegDate DESC");
$query4 = mssql_fetch_row($query3);

$Mais = $query4[0] + 1;

if($Mais >= 3){
echo "Caso voc� tenha 3 ou mais personagens voc� n�o pode usar o sistema de resgate.";
}else{

$query5 = mssql_query("UPDATE Character SET Name = '$query2[0]', DeleteFlag = '0', DeleteName = NULL, CharNum = '$Mais' WHERE CID = '$cid22'");

echo "Character Resgatado Com Sucesso. Caso estaja no jogo, relogue.<br>";
}

}
?>

					<td width="206" valign="top">
					<p><? include "modules/mod_iLogin.php" ?></p>
					<p>&nbsp;</p>
					<p>&nbsp;</td>
					<td width="12">&nbsp;</td><br>