<?

if( $_SESSION['AID'] == "" )
{
msgBox("Voc� n�o pode acessar essa ar�a, Logue-se Primeiro!","index.php?do=login");
    die();
}


?>

<?php
session_start();


if($_SESSION['UGradeID'] == 253){
  echo "Your Account is Banned";
  die();
}
$page = sql($_GET['page']);
?>
<Body>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<div align="center">
<center><!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>//Title</title>
<?php
Title("UserPanel");
?>
</head>
<body>
<?php if ($_SESSION['UserID']){ ?>
<br />
<div id="table_header">
 <div class="table_h">
<?php
  echo 'Bem Vindo, <b><a>'.$_SESSION['UserID'].'</a> !</b>';
?><br>
<div id="link_home"><a href="index.php"><b></b></a></div>
 </div>
</div>

<div id="table_body">
 <div class="table_b">
<?php
if($page == ""){
echo "
<div class='ap'>
<table>
<tr><br>
<tr>
<br>   
<a href='index.php?do=recuperar'><font color='lime'>Recuperar Char</font></a>  |    
<a href='index.php?do=nick_name'><font color='orange'>Trocar Nick</font></a>    |
<a href='index.php?do=color'><font color='cyan'>Comprar Name Color</font></a>    |    
<a href='index.php?do=jjang'><font color='4EEE94'>Comprar Jjang</font></a>   
</tr> 
      
</tr> 
</table>
</div>

";
}elseif($do == "changepassword"){
  include("inc/changepassword.php");
  Title("UserPanel &bull; Change Password");
}elseif($do == "stats"){
  include("inc/stats.php");
  Title("UserPanel &bull; User Stats");
}elseif($do == "changesex"){
  include("mod_sex.php");
  Title("UserPanel &bull; Change Sex");
}elseif($do == "clan"){
  include("inc/clan.php");
  Title("UserPanel &bull; Delete Clan");
}elseif($do == "logout"){
  include("inc/logout.php");
  Title("UserPanel &bull; Logout");
}elseif($do == "editinfo"){
  include("inc/editinfo.php");
  Title("UserPanel &bull; Edit Info");
}
?> 
 </div>
</div>

<div id="table_footer"></div>
<div id="footer">
  <!-- Please to not remove credits --><br>
  Copyright &copy; 2012 User Painel <span style="color:#FF4500; background: transparent url(http://tinyurl.com/outgum)">KnightGunZ</span></a>
</div>
<?php
}else{
  include("inc/login.php");
}
?>
</body>
</html></center>


</div>
								</td>
							</tr>
						</table>
					</div>
