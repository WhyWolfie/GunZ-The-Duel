<? include "inject.php" ?>
<? include "pls.php" ?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicon.ico" type="image/ico" /> 
<title>The Best Gunz Maintenance</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
<!--
//Disable right click script
var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg2.jpg);
}
-->
</style>
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
</head>

	<body bgcolor="#312F30">

<form name="reg" method="POST" action="index.php?do=register">
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="4">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>Server 
                                    Em Manuten��o.</font></font></td>


										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

											<p>Ol� 
                                    Players Pendentes Em Ureal Gunz !
                                    <p>Estamos Em Manuten��o ... Resolvendo 
                                    Bugs / Reparos No Server . Ureal Gunz e 
                                    um Server Dedicado , 24 Horas Online . Construindo 
                                    Sua Divers�o . &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O 
                                    Melhor Gunz Online Ja Encontrado .</p>
                                    <p>Voltaremos Breve . ! Aguarde . Chame 
                                    Seus Amigos !</p>
</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
            </tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
