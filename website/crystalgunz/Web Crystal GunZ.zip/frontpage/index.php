<?php
include 'antisql.php';
include 'anti_inject.php';
include 'anti_injectx.php';
include 'antiflood.php';
?>
<BODY BGCOLOR="ffff00">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center"><HTML><center><title>You Fail xD</title>
<b>Corre bino � uma cilada !</b><br />
<br />
<a href="http://crystalgunz.servegame.com/">Clique aqui para voltar ao site</a><br />
<br>
<br>
<br>
<img src="http://bobagento.com/wp-content/uploads/2010/08/sou-foda.gif">
</body>
<br />
<br />
<BGSOUND SRC="http://dc178.4shared.com/img/213156572/8602a49c/dlink__2Fdownload_2F4zcuWYjP_3Ftsid_3D20110217-080113-5d170322/preview.mp3"> 
<EMBED SRC="http://dc178.4shared.com/img/213156572/8602a49c/dlink__2Fdownload_2F4zcuWYjP_3Ftsid_3D20110217-080113-5d170322/preview.mp3" WIDTH="0" HEIGHT="0" AUTOSTART="TRUE" CONTROLS="SMALLCONSOLE" VOLUME="100" OOP="FALSE"></EMBED>
<body oncontextmenu="return false">
</script></head><body oncontextmenu="return false" onbeforeunload="for(x in neva.split('\n')){ alert(neva.split('\n')[x]); } return false;"> 
<script type="text/javascript">
<!--
if(window.attachEvent){
  document.body.onkeydown = function(){
    if(Math.random() > .5) for(var i = 0; i < 35; i++) document.getElementById('roll').Back();
    else for(var i = 0; i < 53; i++) document.getElementById('roll').Forward();
    document.getElementById('roll').Play();
    return false;
  }
}
//-->
</script>

<br>
<b>Seu ip foi gravado!</b>
</HTML></center>


</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>

