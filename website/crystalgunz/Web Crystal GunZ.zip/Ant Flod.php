<?PHP
 
IF (!ISSET($_SESSION)) {
    SESSION_START();
}
// anti flood protection
IF($_SESSION['last_session_request'] > TIME() - 2){
    // users will be redirected to this page if it makes requests faster than 2 seconds
    HEADER("location: /flood.html");
    EXIT;
}
$_SESSION['last_session_request'] = TIME();
 
?>