new Flooder[MAX_PLAYERS],Aviso[MAX_PLAYERS]; 

public OnPlayerText(playerid,text[]) 
{ 
    if(Flooder[playerid] > gettime()) 
    { 
        SendClientMessage(playerid,-1,"Morre flooder do capeta"); 
        Aviso[playerid]++; 
        return 0x0; 
    } 
    if(Aviso[playerid] == 3) return Flooder[playerid] = 0, Kick(playerid); 
    Flooder[playerid] = gettime()+5; 
    return 0x01; 
}  