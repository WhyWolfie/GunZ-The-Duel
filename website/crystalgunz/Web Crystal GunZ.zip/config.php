<?
// Configura��es para conex�o MSSQL
mssql_connect("tu-PC\SQLEXPRESS","sa","2asdasn");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
}
?>