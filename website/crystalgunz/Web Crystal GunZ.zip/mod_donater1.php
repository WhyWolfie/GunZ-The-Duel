Promo��o DONATE no servidor, confira abaixo a nossa tabela de promo��o.


Rela��es e Planos:

Plano 1	150 KG Coins 	<font color="lime">10,00 R$</font>	

Plano 2	250 KG Coins	<font color="lime">20,00 R$</font>	

Plano 3	400 KG Coins	<font color="lime">30,00 R$</font>	

Plano 4	500 KG Coins	<font color="lime">40,00 R$</font>	

Plano 5	650 KG Coins	<font color="lime">50,00 R$</font>	

Plano 6	850 KG Coins	<font color="lime">60,00 R$</font>	

Plano 7	1050 KG Coins	<font color="lime">80,00 R$</font>	

Plano 8	1250 KG Coins	<font color="lime">100,00 R$</font>


<font color="red">Aten��o:</font> Promo��o v�lida at� dia 31/01/2012

Atenciosamente,
Equipe Knight Gunz.