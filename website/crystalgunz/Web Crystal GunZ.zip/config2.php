<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("MAYCON-F2DC1F44\SQLEXPRESS","sa","007248910");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'MAYCON-F2DC1F44\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = '007248910';
$DB = 'GunzDB';
?>
