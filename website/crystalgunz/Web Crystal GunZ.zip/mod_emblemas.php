<?

if( $_SESSION['AID'] == "" )
{
msgBox("P�gina inexistente.","index.php");
    die();
}


?>