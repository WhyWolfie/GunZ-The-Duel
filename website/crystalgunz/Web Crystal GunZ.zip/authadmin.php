<?php
//This file has been edited by Wizkid. All rights reserved.

if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252 and !$_SESSION['AID'] == ""){
    //We validate the user.
	//And, with the best we can do we use the antisql function.
	//A SESSION can be spoofed ya know.
    $userid = antisql($_SESSION['UserID']);
    $aid = antisql($_SESSION['AID']);
    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$userid' AND AID = '$aid'");
    $data = mssql_fetch_assoc($res);
    if(!$data['UGradeID'] == $_SESSION['UGradeID']){
        echo "Admin Session Invalid";
    }
}else{
    die("You do not have permission to execute this action");
}
?>