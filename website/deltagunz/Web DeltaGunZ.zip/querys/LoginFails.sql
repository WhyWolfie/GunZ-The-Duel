USE [GunzDB]
GO
/****** Object:  Table [dbo].[LoginFails]    Script Date: 04/17/2011 03:29:54 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[LoginFails](
	[IP] [varchar](500) COLLATE Latin1_General_CI_AS NULL,
	[UserID] [varchar](500) COLLATE Latin1_General_CI_AS NULL,
	[Time] [varchar](500) COLLATE Latin1_General_CI_AS NULL
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF