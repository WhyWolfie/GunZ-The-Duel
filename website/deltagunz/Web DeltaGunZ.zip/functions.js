// JavaScript Document

$(document).ready(function()
{
	
	$("#youtube").addClass("go");
	
	$("#youtube").tubeplayer({
		width: 520, // the width of the player
		height: 245, // the height of the player
		allowFullScreen: "false", // true by default, allow user to go full screen
		initialVideo: "8mGNePffUxw", // the video that is loaded into the player
		// initalVideo: "HBPRPLUPOc",
		opacity: -8;
		preferredQuality: "default",// preferred quality: default, small, medium, large, hd720
		start: 1,
		autoPlay:false,
		showControls: 0,
		showinfo: false,
		onPlay: function(id){}, // after the play method is called
		onPause: function(){}, // after the pause method is called
		onStop: function(){}, // after the player is stopped
		onSeek: function(time){}, // after the video has been seeked to a defined point
		onMute: function(){}, // after the player is muted
		onUnMute: function(){} // after the player is unmuted
	});
	
	$("#video_frame").click(function()
	{
		if($("#youtube").hasClass("go"))
		{
			$("#youtube").removeClass("go");
			$("#youtube").tubeplayer("stop");
		}
		else
		{
			$("#youtube").addClass("go");
			$("#youtube").tubeplayer("play");
		}
	});
});