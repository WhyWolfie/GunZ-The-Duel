<?
    $cid = ($_GET['user']);
if(!is_numeric($cid)){
msgbox("Not Available","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);


if($num_rows < 1){
msgbox("Nao encontrado","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

$query = mssql_query("SELECT * FROM Account WHERE AID = '".$char2['AID']."'");
$avatar = mssql_fetch_object($query);

?>
	<div id="middle">
    	
	<div id="news_big" style="padding-top: 15px; padding-left: 15px;">
					<table width="30%">
					<tr>
						<td><strong>Username:</strong></td>
						<td><?=utf8_encode($char['Name'])?></td>
					</tr>
				
					<tr>
						<td><strong>Level:</strong></td>
						<td><?=$char['Level']?></td>
					</tr>
					
					<tr>
						<td><strong>XP:</strong></td>
						<td><?=$char['XP']?></td>
					</tr>
					
					<tr>
						<td><strong>Gender:</strong></td>
						<td><?
                                                    switch ( $char['Sex'] ){
                                                    case "0";
                                                    $char['Sex'] = "Male";
                                                    break;
                                                    case "1";
                                                    $char['Sex'] = "Female";
                                                    break;
                                                    } echo $char['Sex'];
                                                    ?></td>
					</tr>
					
					<tr>
						<td><strong>Kills:</strong></td>
						<td><?=$char['KillCount']?></td>
					</tr>
					
					<tr>
						<td><strong>Death:</strong></td>
						<td><?=$char['DeathCount']?></td>
					</tr>
					
					<tr>
						<td><strong>K/D Ratio:</strong></td>
						<td><?=ratio($char['KillCount'], $char['DeathCount'])?></td>
					</tr>
									</table>
				
	</div>	</div>