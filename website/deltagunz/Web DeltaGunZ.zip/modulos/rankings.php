<?php
if ((!isset($_GET['pagenum'])) || (!is_numeric($_GET['pagenum'])) || ($_GET['pagenum'] < 1)) { $pagenum = 1; }
else { $pagenum = $_GET['pagenum']; }
$result = mssql_query ("SELECT * FROM Character") or die(mssql_error());
$rows = mssql_num_rows($result);
$page_rows = 20; 
$last = ceil($rows/$page_rows);
if (($pagenum > $last) && ($last > 0)) { $pagenum = $last; } 
$max = ($pagenum - 1) * $page_rows; 
$query = mssql_query("select top $page_rows * from Character where Level not in (select top $max Level from Character order by Level desc) order by Level desc");
$name = mssql_fetch_row($result);
if(mssql_num_rows($result)){
?>
	<div id="middle">
    <!-- Rankings -->

	   	  
	    <!-- Player Rankings -->
		 <div id="playerrankings">
		 <div id="ranking_panel">
		  <table width="500"  border="0" style="text-align:center;">
		   <tr><br>
		     <td class="rktcol">#</td>
                     <td class="rktcol">Name</td>
                     <td class="rktcol">Level</td>
	             <td class="rktcol">Sex</td>
                     <td class="rktcol">EXP</td>
                     <td class="rktcol">Kills</td>
                     <td class="rktcol">Deaths</td>
		   </tr>
<?
for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_row($query);
$rank = $i+1;
  ?>
		   <tr class="q2" style="font-size:10px;height:18px;">
                     <td><?php echo "$rank";?>.</td>
                     <td class="asas"><a href='index.php?page=users&user=<?php echo "$row[0]";?>'><?=utf8_encode(FormatCharName($row[0]))?></a></td>
                     <td><?php echo "$row[3]";?></td>
                     <td><?
			 switch ( $row[4] ){
			 case "0";
			 $row[4] = "Male";
			 break;
			 case "1";
			 $row[4] = "Female";
			 break;
			 } echo $row[4];
                         ?></td>
                     <td><?php echo "$row[8]";?></td>
                     <td><?php echo "$row[32]";?></td>
                     <td><?php echo "$row[33]";?></td>
                  </tr>
<? $i++;
}?>
                  <tr>
                     <td></td>
                  </tr>
                  <tr><td colspan='7'><br />
               <div class='light_dark_line'></div>
                      </td>
                  </tr>
                  <tr>
                     <td></td>
                  </tr>
                  <tr style='font-size:11px;'>
                     <td colspan='7'>
		   <font color='#FF0019'><b>Administrator</b></font> &bull;
                   <font color='#FF9900'><b>GameMaster</b></font> &bull;
                   <font color='#33FFFF'><b>Developer</b></font> &bull;
                   <font color='#d5d4d4'><b>Member</b></font> &bull;
                   <font color='#000000'><b>Banned</b></font></div>
                      </td>
                  </tr>		<!-- End Of Player Rankings -->
		
				<!-- End Of Clan Rankings -->

		<tr>
                   <td></td>
                </tr>
                <tr>
                   <td colspan='7'>
                       <div class='light_dark_line'></div>
                   </td>
                </tr>
                <tr>
                   <td align='center' colspan='7'></td>
                </tr>
                <tr>
                   <td align='center' colspan='7'>
                       <div class='paginate'>

<?
if ($pagenum == 1) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <span class='disabled'>Prev</span>
                          <span class='current'>1</span><a href='index.php?page=rankings&pagenum=2'>2</a>
                          <a href='index.php?page=rankings&pagenum=3'>3</a>
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 2) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <span class='current'>2</span>
                          <a href='index.php?page=rankings&pagenum=3'>3</a>
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 3) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>
                          <span class='current'>3</span>
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=next?>'>Next</a></div>
<?
}
if ($pagenum == 4) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>
                          <a href='index.php?page=rankings&pagenum=3'>3</a>
                          <span class='current'>4</span>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=next?>'>Next</a></div>
<?
}
if ($pagenum == 5) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>
                          <a href='index.php?page=rankings&pagenum=3'>3</a>
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <span class='current'>5</span>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=next?>'>Next</a></div>
<?
}
if ($pagenum == 6) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>
                          <a href='index.php?page=rankings&pagenum=3'>3</a>
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <span class='current'>6</span>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 7) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=4'>4</a>
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <span class='current'>7</span>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 8) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=5'>5</a>
                          <a href='index.php?page=rankings&pagenum=6'>6</a>
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <span class='current'>8</span>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>...
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 9) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <span class='current'>9</span>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 10) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <span class='current'>10</span>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 11) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <span class='current'>11</span>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 12) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <span class='current'>12</span>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 13) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <span class='current'>13</span>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 14) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <span class='current'>14</span>
                          <a href='index.php?page=rankings&pagenum=15'>15</a>
                          <a href='index.php?page=rankings&pagenum=<?=$next?>'>Next</a></div>
<?
}
if ($pagenum == 15) {
$next = $pagenum+1;
$prev = $pagenum-1;
?>
                          <a href='index.php?page=rankings&pagenum=<?=$prev?>'>Prev</a>
                          <a href='index.php?page=rankings&pagenum=1'>1</a>
                          <a href='index.php?page=rankings&pagenum=2'>2</a>...
                          <a href='index.php?page=rankings&pagenum=7'>7</a>
                          <a href='index.php?page=rankings&pagenum=8'>8</a>
                          <a href='index.php?page=rankings&pagenum=9'>9</a>
                          <a href='index.php?page=rankings&pagenum=10'>10</a>
                          <a href='index.php?page=rankings&pagenum=11'>11</a>
                          <a href='index.php?page=rankings&pagenum=12'>12</a>
                          <a href='index.php?page=rankings&pagenum=13'>13</a>
                          <a href='index.php?page=rankings&pagenum=14'>14</a>
                          <span class='current'>15</span>
                          <span class='disabled'>Next</span></div>
<?}?>



                   </td>
               </tr>		  </table>
		 </div>
		 </div>
		 
<!-- End Of Download -->	</div>
<? 
}else{
?>
<div id="middle">
    		<div id="news_small">
			<div class="inner">
				<div class="title" align="center">No players.</div>
			</div>
		</div>
		</div>
<?}?>