<?
if($_SESSION['AID']) 
{ 
msgbox("Voce ja possui uma conta.","index.php");
} 
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['username']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['password']);
    $pw2 = clean($_POST['password2']);
    $name = clean($_POST['name']);
    $age = clean($_POST['age']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Email em uso.","index.php?page=register");
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            msgbox("Usuario em uso.","index.php?page=register");
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            msgbox("As senhas n�o coincidem.","index.php?page=register");
            $er = 1;
        }


        if($user == ""){
            msgbox("Por favor digite o nome de Usuario.","index.php?page=register");
            $er = 1;
        }

        if($email == ""){
            msgbox("Por favor digite o nome de Email.","index.php?page=register");
            $er = 1;
        }

        if($name == ""){
            msgbox("Por favor digite o seu nome.","index.php?page=register");
            $er = 1;
        }

        if(strlen($pw1) < 6){
            msgbox("Por favor insira uma senha com seis ou mais caracteres.","index.php?page=register");
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            msgbox("Por favor insira uma senha.","index.php?page=register");
            $er = 1;
        }



        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, UGradeID, PGradeID, RegDate, Age)Values ('$user', NULL, '$name','$email', 0, 0, GETDATE(), '$age')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password])VALUES('$user','$aid','$pw1')");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>
	<div id="middle">
    
<!-- Register -->
 <div id="news_big">
  <div class="inner">
   <div class="normal" style="position:relative;top:-14px;">

  
  <div style="width:410px;margin:0 auto;">
   <table border="0" align="center" width="510">
   <form id="RegisterForm" action="index.php?page=register" method="post" onsubmit="return validateRegisterForm();">
    <tr><td width="155"> <label for="username">Username :</label> </td><td> <input type="text" class="input" name="username" maxlength="25" /> </td></tr>
    <tr><td width="155"> <label for="password">Password :</label> </td><td> <input type="password" class="input" name="password" maxlength="30" /> </td></tr>
    <tr><td width="155"> <label for="password2">Repeat :</label> </td><td> <input type="password" class="input" name="password2" maxlength="30" /> </td></tr>
    <tr><td width="155"> <label for="name">Name :</label> </td><td> <input type="text" class="input" name="name" maxlength="25" /> </td></tr>
    <tr><td width="155"> <label for="age">Age :</label> </td><td> <input type="text" class="input" name="age" maxlength="3" /> </td></tr>
    <tr><td width="155"> <label for="email">Email :</label> </td><td> <input type="text" class="input"  name="email" maxlength="40" /> </td></tr>
    
    <tr> <td width="55"><input type="submit"  name="submit" value="Register" /> </td></tr>
   </form>
   </table>
  </div>
  
   </div>
  </div>
 </div>

<!-- End Of Register -->
	</div>
<?
}else{
msgbox ("Account created successfully.","index.php");
}
?>