	<div id="middle">
    <div id="news_big">
<center><br><br>FINALLY DELTAGUNZ [V4] is RELEASED NOW !! Catch us up .. Download Game NOW !!<br><br>

<font color="red"><a href="http://deltagunz.com/DeltaGunzv4.rar">Download Mirror(ONLINE) Click here !</a></font>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<font color="red"><a href="http://www.microsoft.com/en-us/download/details.aspx?id=17718"> Download .net frame work 4.0</a></font>
<br><br>

													<table border="0" cellpadding="3" cellspacing="1" width="80%">
														<tr>
															<td bgcolor="#121212" width="80">
															<span style="font-size: 7pt">
															&nbsp;</span></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Minimum Requirements</span></b></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Recommended Requirements</span></b></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															OS</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Windows 2000, Windows XP, Windows Vista</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															DirectX</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															DirectX 9.0c</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															CPU</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Pentium III 500 Mhz</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Pentium III 800 Mhz
															</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Memory</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															256 MB</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															512 MB or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Graphic Card</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Direct3D 9.0
															Compatible</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															GeForce 4 MX or higher</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Net Speed</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															64-128 Kbps
															</span></td>
															<td align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															256 Kbps or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Sound Card</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Direct3DSound
															Compatible</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Mouse</span></td>
															<td colspan="2" align="center" bgcolor="#333333">
															<span style="font-size: 7pt">
															Windows Compatible (Wheel Mouse recommended)</span></td>
														</tr>
													</table>



</div>	</div>