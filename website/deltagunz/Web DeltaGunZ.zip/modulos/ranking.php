<?php
if(!function_exists("clan")){
    function clan(){
$res = mssql_query("SELECT TOP 20 Name, Point, CLID, Wins, Losses, MasterCID, Draws FROM Clan WHERE Name != '' ORDER BY Wins DESC");
$count = 0;
if(mssql_num_rows($res)){
?>
	<div id="middle">
    <!-- Rankings -->

	   		<!-- End Of Player Rankings -->
		
			    <!-- Clan Rankings -->
		 <div id="playerrankings">
		 <div id="ranking_panel">
		 
		  <table width="500" border="0" style="text-align:center;">
		   <tr><br>
		     <td class="rktcol">#</td>
                     <td class="rktcol">Name</td>
                     <td class="rktcol">Leader</td>
	             <td class="rktcol">Points</td>
                     <td class="rktcol">Wins</td>
                     <td class="rktcol">Losses</td>
                     <td class="rktcol">Draws</td>
		   </tr>
<?
while($r = mssql_fetch_assoc($res)){
$count++;
?>
		   <tr class="q2" style="font-size:10px;height:18px;">
                    <td>1.</td>
                    <td class="asas"><?=utf8_encode($r['Name'])?></td>
<?
$query = mssql_query("SELECT Name, CID From Character WHERE CID='".$r['MasterCID']."'");
while($f = mssql_fetch_assoc($query)){
?>
                    <td class="asas"><a href="index.php?page=users&user=<?=$f['CID']?>"><?=$f['Name']?></a></td>
<?}?>
                    <td><?=$r['Point']?></td>
                    <td><?=$r['Wins']?></td>
                    <td><?=$r['Losses']?></td>
                    <td><?=$r['Draws']?></td>
                  </tr>
<?}?>


	   		<!-- End Of Clan Rankings -->

		<tr><td></td></tr><tr><td colspan='7'><div class='light_dark_line'></div></td></tr><tr><td align='center' colspan='7'></td></tr><tr><td align='center' colspan='7'></td></tr>		  </table>
		 </div>
		 </div>
		 
<!-- End Of Download -->	</div>
<?
}else{
?>
<div id="middle">
    		<div id="news_small">
			<div class="inner">
				<div class="title" align="center">No clans.</div>
			</div>
		</div>
		</div>
<?
}
}}

if($_GET['expand'] == 0){
switch($_GET['do']){
    case "clan";
        clan();
    break;
}}?>