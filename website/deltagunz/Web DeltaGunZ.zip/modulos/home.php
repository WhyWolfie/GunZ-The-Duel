<?
$res = mssql_query_logged("SELECT TOP 5 * FROM Noticias ORDER BY ID DESC");
if(mssql_num_rows($res)){
?>
<div id="middle">
<?
while($n = mssql_fetch_assoc($res)){
?>
    		<div id="news_small">
			<div class="inner">
				<div class="title"><?=utf8_encode($n['Titulo'])?></div>
				<div class="normal">
					<p><?=utf8_encode($n['Noticia'])?></p>
					<div class="date">
						Posted by: <?=utf8_encode($n['Autor'])?>					</div>
				</div>
			</div>
		</div>
<?}?>
</div>
<?
}else{
?>
<div id="middle">
			<div id="news_small">
			<div class="inner">
				<div class="title">Web Site Delta Gunz</div>
				<div class="normal">
					<p>Web Site codada por Pablo e Aprodite para Ragezone.</p>
					<div class="date">
						Posted by: Pablo					</div>
				</div>
			</div>
		</div>
		</div>
<?}?>