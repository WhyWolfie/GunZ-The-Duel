<?
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 253){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 104){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 0){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 1){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 2){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 3){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 4){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 5){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 6){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 7){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 8){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 9){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 10){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 11){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 12){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 13){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 14){
    msgbox("Access Denied","index.php");
}
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $titulo = clean($_POST['titulo']);
    $noticia = clean($_POST['noticia']);
    $user = $_SESSION['login'];


        if($noticia == ""){
            msgbox("Escreva a noticia.","index.php?do=registro");
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Noticias (Titulo, Autor, Noticia)Values ('$titulo','$user','$noticia')");
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>
	<div id="middle">
    
<!-- Register -->
 <div id="news_big">
  <div class="inner">
   <div class="normal" style="position:relative;top:-14px;">

  
  <div style="width:410px;margin:0 auto;">
   <table border="0" align="center" width="510">
   <form id="RegisterForm" action="index.php?page=noticia" method="post" onsubmit="return validateRegisterForm();">
    <tr><td width="155"> <label for="username">Titulo :</label> </td><td> <input type="text" class="input" name="titulo" maxlength="25" /> </td></tr>
    <tr><td width="155"> <label for="password">Noticia :</label> </td><td> <textarea rows="8" name="noticia" cols="35" class="input"></textarea> </td></tr>
    
    <tr> <td width="55"><input type="submit"  name="submit" value="ADD" /> </td></tr>
   </form>
   </table>
  </div>
  
   </div>
  </div>
 </div>

<!-- End Of Register -->
	</div>
<?
}else{
msgbox ("Noticia adicionada corretamente.","index.php");
}
?>