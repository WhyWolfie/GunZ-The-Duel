<?
$query3 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '".$_SESSION['UserID']."' and Login.Password = '".$_SESSION['Pass']."' and ClanMember.Grade = '1' "); 
if (mssql_num_rows($query3) >= '1') 
{  
?>
<div id="middle">
    <div id="news_big">
      <center>
        <!-- Clan Emblem --><br />
            <table border="0" align="center">
            <form action="index.php?page=clanemblem" method="post" enctype="multipart/form-data">
              <tr>
                <td height="40" colspan="2" align="center">
                   <div class="regbordr2"><select class="tbl_colbor2" name="clanname">
<?  
for($i=''; $i < @mssql_num_rows($query3); $i++) 
{ 
$row = @mssql_fetch_row($query3); 
$ClanName = $row[4]; 
?>
                                             <option value='<?=$row[4]?>'><?=$row[4]?></option>
<?}?>
                                          </select>
                   </div>
                </td>
              </tr>
              <tr>
                <td><input type="file" name="foto" id="ufile" style="color:#000;border:1px solid #101010;" /></td>
                <td><input type="submit" name="submit" value="Change" /></td>
              </tr>
              <tr>
<td>
<?  
} 
else  
{  
echo "<span class='ignore'>Voc� n�o � o L�der do Clan</span>"; 
}
$erro = $config = array(); 

$arquivo = isset($_FILES["foto"]) ? $_FILES["foto"] : FALSE; 

$config["tamanho"] = 106883; 

$config["largura"] = 150; 

$config["altura"]  = 150; 

if (isset($_POST['submit'])){
     $clanname = clean($_POST['clanname']);  
    if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $arquivo["type"])) { 
        $erro[] = "Arquivo em formato inv�lido! A imagem deve ser jpg, jpeg, bmp, gif ou png. Envie outro arquivo"; 
    } else { 
        if ($arquivo["size"] > $config["tamanho"]) { 
            $erro[] = "Arquivo em tamanho muito grande! A imagem deve ser de no m�ximo " . $config["tamanho"] . " bytes. Envie outro arquivo"; 
        } 
         
        $tamanhos = getimagesize($arquivo["tmp_name"]); 
         
        if ($tamanhos[0] > $config["largura"]) { 
            $erro[] = "Largura da imagem n�o deve ultrapassar " . $config["largura"] . " pixels"; 
        } 

        if ($tamanhos[1] > $config["altura"]) { 
            $erro[] = "Altura da imagem n�o deve ultrapassar " . $config["altura"] . " pixels"; 
        } 
    } 
     
    if (sizeof($erro)) { 
        foreach ($erro as $err) { 
            echo " - " . $err . "<BR>"; 
        } 
        echo 'Error, nao foi possivel fazer o upload do Emblema.'; 
        echo "$err"; 
    } 

    else 
    { 
        preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $arquivo["name"], $ext); 

        $imagem_nome = md5(uniqid(time())) . "." . $ext[1]; 

        $imagem_dir = "clanemblem/" . $imagem_nome; // IMPORTANTE DEFINIR A PASTA DA IMAGEM 

        move_uploaded_file($arquivo["tmp_name"], $imagem_dir); 

        $query1 = mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$clanname'");
        $query = mssql_query("UPDATE Clan Set EmblemURL='$imagem_dir' WHERE Name='$clanname'"); 
        if($query){ 
        echo "Seu emblema foi enviado com sucesso!"; 
        } 

    } 
} 
?>
</td>
              </tr>
            </form>
            </table><br />
                     <div class="errmess"></div>
    </div>
      </center>
        <!-- End Of Clan Emblem -->
</div>