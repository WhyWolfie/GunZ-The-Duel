<?
if($_SESSION['UGradeID'] == 253){
?>
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>Voc� foi banido desse Gunz.</p>
<hr>
<address>Entre no noss� <a href="#">F�rum</a> e saiba o motivo do seu banimento.</address>
</body></html>

    <?
    die();
}

?>