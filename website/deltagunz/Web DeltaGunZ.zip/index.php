<?php
include "secure/config.php";
include "secure/_functions.php";
include "secure/shield.php";
include "secure/antisql.php";
include "secure/anti_sql.php";
include "secure/sql_check.php";
include "secure/banneduser.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("modulos/" . $_GET['page'] . ".php")) {
        include "modulos/" . $_GET['page'] . ".php";
	}
} }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>DeltaGunZ</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="jquery.js" type="text/javascript"></script>
<script src="youtube.js" type="text/javascript"></script>
<script src="functions.js" type="text/javascript"></script>

</head>

<body>
<div id="topWrapper">
	<div id="navWrapper">
		<div class="inner">
			<div class="navItems">
				<ul>
					<li class="main"><a href="index.php">Home</a></li>
					<li><a href="index.php">Updates</a></li>
					<li><a href="index.php">Notices</a></li>
				</ul>
			</div>
			<div class="navItems">
				<ul>
					<li class="main">Account</li>
					<li> </li>
					<li><a href="index.php?page=register">Register</a></li>
				</ul>
			</div>
			<div class="navItems">
				<ul>
					<li class="main"><a href="index.php?page=rankings&pagenum=1">Ranking</a></li>
					<li><a href="index.php?page=rankings&pagenum=1">Individual</a></li>
					<li><a href="index.php?page=ranking&amp;do=clan">Clan</a></li>
				</ul>
			</div>
			<div class="navItems">
				<ul>
					<li class="main"><a href="index.php?page=itemshop">Shop</a></li>
					<li><a href="index.php?page=itemshop&amp;do=event">Event</a></li>
					<li><a href="index.php?page=itemshop">Donor</a></li>
				</ul>
			</div>
			<div class="navItems">
				<ul>
					<li class="main"><a href="index.php?page=download">Download</a></li>
					<li><a href="index.php?page=download">Client</a></li>
					<li> </li>
				</ul>
			</div>
			<div class="navItems">
				<ul>
					<li class="main">Community</li>
					<li> </li>
					<li><a href="forum">Forums</a></li>
				</ul>
			</div>
		</div>
	</div>
<div class="clean"></div>
	<div id="videoWrapper">
		<img id="video_frame" src="images/video_frame.png" />
		<div id="videoReal">
			<div id="youtube">
				
			</div>
		</div>
	</div>
	<div class="clean"></div>
	<div id="render">
		
	</div>
</div>
<div id="contentWrapper">
	<div id="left">
		<? include "inc/rankp.php"; ?>
		<? include "inc/rankc.php"; ?>
	<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['page'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("modulos/" . $_GET['page'] . ".php")) {
							    include "modulos/" . $_GET['page'] . ".php";
						    }
                        }else{
                            include "modulos/home.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
	<div id="right">
		<? include "inc/painel.php"; ?>
		<? include "inc/status.php"; ?>
<div id="footerWrapper">
	<div class="footer_text">
		<p>Copyright <a href="http://deltagunz.net/">DeltaGunZ</a> &copy; 2011/2012 All Rights Reserved.</p>
		<p>Website designed by <a href="http://synidearts.com/">SynideArts</a> and coded by <a href="#" target="_blank">Pablo & Aprodite!</a> &copy;</p>

	</div>
</div>


</body>
</html>
