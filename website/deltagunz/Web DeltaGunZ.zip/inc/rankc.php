<?php
$res = mssql_query("SELECT TOP 5 Name, Point, CLID FROM Clan WHERE Name != '' ORDER BY Wins DESC");
$count = 0;
?>
		<div id="rank">
			<div class="inner">
				<div class="title">Clan Ranking</div>
				<div class="sub">
					<div>
						<div class="menu_text">
							<div class="first">#</div>
							<div class="center">Name</div>
							<div class="last">Points</div>
						</div>
					</div>
<?
if(mssql_num_rows($res) == 0){
?>
					     <div>
						   <div class="first"></div>
						   <div class="center">No Clans</div>
						   <div class="last"></div>
					     </div>
<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++;
?>
					     <div>
						   <div class="first"><?=$count?>.</div>
						   <div class="center"><?=$r['Name']?></div>
						   <div class="last"><?=$r['Point']?></div>
					     </div>
<?}}?>
					    					<div class="seemore">
						<A href="index.php?page=ranking&do=clan">Show all</a>
					</div>
				</div>
			</div>
		</div>
	</div>