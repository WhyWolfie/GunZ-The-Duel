<?
if($_SESSION[AID] == "")
{
?>
    <div id="rank">
			<div class="inner">
				<div class="title">User Panel</div>
								<form action="index.php?page=logar" method="post">
					<div>
						<input class="input" type="text" maxlength="25" name="userid" />
					</div>
					<div>
						<input class="input" type="password" maxlength="30" name="pass" />
					</div>
					<div><input type="checkbox" class="input check" name="logged" /> Stay logged in</div>
					<input type="submit" name="submit" value="" class="login_btn" />
					<div class="seemore normal">&nbsp;</div>
				</form>
							</div>
		</div>

<?
}else{
?>
<?
$login22 = $_SESSION['login'];

$ugrade1 = mssql_query("SELECT UgradeID FROM Account WHERE UserID = '$login22'");
$ugrade2 = mssql_fetch_row($ugrade1);

$query1 = mssql_query("SELECT * FROM Login WHERE UserID = '$login22'");
$query2 = mssql_fetch_assoc($query1);

$query3 = mssql_query("SELECT * FROM Account WHERE UserID = '$login22'");
$query4 = mssql_fetch_assoc($query3);

$query5 = mssql_query("SELECT * FROM Character WHERE AID = '".$query4['AID']."'");
$query6 = mssql_fetch_assoc($query5);
$character = mssql_num_rows($query5);

$query7 = mssql_query("SELECT * FROM Clan WHERE MasterCID = '".$query6['CID']."'");
$clan = mssql_num_rows($query7);

$busca1 = mssql_query_logged("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$busca2 = mssql_fetch_row($busca1);
?>
		<div id="rank">
			<div class="inner">
				<div class="title">User Panel</div>
				<!-- Logged In -->
               <div id="loggedin">
                  Welcome, <b><?=$login22?></b>
                  <a href="index.php?page=deslogar" id="logout">Logout</a><br /><br />
               <div id="myinfo">
                   <b>My Info :</b>
               <div style="margin-left:5px;">
                   Characters :<?=$character?><br />
                   Clans :<?=$clan?><br />
                   Coins :<?=$query2['RZCoins']?><br />
                   EvCoins :<?=$query2['EVCoins']?><br />

               </div>
               </div><br />
               <div id="upload_clan_emblem">
                   <a href="index.php?page=clanemblem">Change Clan Emblem</a> <p />
               </div>
<?
if($busca2[0] == 255){
?>
               <div id="buy_coins">
               <a href="index.php?page=noticia">ADD Noticia</a> <p />
               </div>
<? } ?>
               <div id="links"></div>
               </div><!-- End Of Logged In -->			</div>
		</div>
<?
}
?>