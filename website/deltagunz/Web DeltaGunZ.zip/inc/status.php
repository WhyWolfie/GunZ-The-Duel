<div id="stats">
			<div class="inner">
				<div class="title">Statistics</div>
				<div class="menu_text">
					<div>
						<div class="onehalf">Server Time</div>
						<div class="otherhalf"><div id="js_clock"><script>js_clock()</script></div></div>
					</div>
					<div>
						<div class="onehalf">Server Status </div>
						<div class="otherhalf">
						 <?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = $data->ServerName;
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
    }
    ?>					</div>
					</div>
					<div>
						<div class="onehalf">Online Players</div>
						<div class="otherhalf">
						<?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "$servercount";
    ?> / 200						</div>
					</div>
						<div class="onehalf">Newest Player</div>
						<div class="otherhalf">
						<?php

$query = mssql_query("SELECT TOP 1 Name FROM Character ORDER BY RegDate DESC"); 
while($r = mssql_fetch_assoc($query)){
?><?=$r['Name']?><?}?>						</div>
               
				
				</div>
			</div>
		</div>
	</div>
</div>