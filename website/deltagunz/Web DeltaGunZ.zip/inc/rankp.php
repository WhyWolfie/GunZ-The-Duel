<?php
$res = mssql_query("SELECT TOP 5 Name, Level, CID FROM Character WHERE Name != '' ORDER BY Level DESC");
$count = 0;
?>
		<div id="rank">
			<div class="inner">
				<div class="title">Individual Ranking</div>
				<div class="sub">
					<div>
						<div class="menu_text">
							<div class="first">#</div>
							<div class="center">Name</div>
							<div class="last">Lvl</div>
						</div>
					</div>
<?
if(mssql_num_rows($res) == 0){
?>
					     <div>
						   <div class="first"></div>
						   <div class="center"><a href="#">No Char</a></div>
						   <div class="last"></div>
					     </div>
<?
}else{
while($r = mssql_fetch_assoc($res)){
$count++;
?>
					     <div>
						   <div class="first"><?=$count?>.</div>
						   <div class="center"><a href="index.php?page=users&user=<?=$r['CID']?>"><?=utf8_encode($r['Name'])?></a></div>
						   <div class="last"><?=$r['Level']?></div>
					     </div>
<?}}?>
					    					<div class="seemore">
						<A href="index.php?page=rankings&pagenum=1">Show all</a>
					</div>
				</div>
			</div>
		</div>