<?php
@session_start();
$AID = $_SESSION['AID'];
$id = $_GET['id'];
 
$link = mssql_connect("USUARIO-PC\SQLEXPRESS","sa","0407573");
mssql_select_db("GunzDB", $link);
 
if(empty($AID) || !is_numeric($AID))
{
        if(isset($_POST['loguearse']))
        {
                $query = mssql_query("SELECT a.AID FROM Account a INNER JOIN [Login] b ON a.AID = b.AID WHERE b.UserID = '".antisql($_POST['userid'])."' AND b.Password = '".antisql($_POST['pass'])."'");
                if(mssql_num_rows($query))
                {
                        $r = mssql_fetch_object($query);
                        $_SESSION['AID'] = $r->AID;                    
                        echo "<script>var url = window.location.href; window.location = url;</script>";
                        die();
                }else{
                        echo "<script>alert('Usuario y/o Contrase�a Incorrectas!');</script>";
                }              
        }
                ?>
                <form method="post">
                <fieldset>
                <legend>Loguearse</legend>
                <label>User: </label><input type="text" name="userid" /><br />
                <label>Password: </label><input type="password" name="pass" /><br />
                <input type="submit" name="loguearse" value="Loguear" />
                </fieldset>
                </form>
                <?
       
        die();
}
 
function antisql($value)
{
        $check = $value;
 
        $value = preg_replace(sql_regcase("/(from|shutdown|select|update|account|login|clan|character|indexcontent|set|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
 
        if( $check != $value )
        {
                        date_default_timezone_set('America/Los_Angeles');
                        if(!is_dir("logs"))
                        {
                                mkdir("logs");
                        }
            $logf = fopen("logs/sqllog.txt", "a+");
            fprintf($logf, "Date: %s - IP: %s - C�digo: %s, - Correto: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
        }
 
        return( $value );
}
 
 
function Msg($texto)
{
        echo '<script type="text/javascript">
                alert("'.$texto.'");
                window.location = "/";
                </script>';
        die();
}
 
function SorteoExiste($id)
{
        $query = mssql_query("SELECT ID FROM Sorteo WHERE ID = ".$id);
        if(mssql_num_rows($query))
        {
                return true;
        }
        return false;
}
 
function SorteoDisponible($id)
{      
        $query = mssql_query("SELECT ID FROM Sorteo WHERE (MaxUsers-1) < CantUsers AND ID = ".$id);
        if(mssql_num_rows($query))
        {
                return false;
        }
        return true;
}
 
function isAdmin($AID)
{
        $r = mssql_fetch_object(mssql_query("SELECT UGradeID FROM Account WHERE AID = ".$AID));
        switch($r->UGradeID)
        {
        //Si es del Staff no pueden acceder al sorteo
                case 255: //Admin
                case 254: //Mod
                case 252: //Dev
                        return true;
                default:
                        return false;
        }
}
 
function yaJugo($id, $AID)
{
        $query = mssql_query("SELECT * FROM SorteoUsers WHERE ID_Sorteo = ".$id." AND AID = ".$AID);
        if(mssql_num_rows($query))
        {
                return true;
        }
        return false;
}
 
if(!is_numeric($id)){
        Msg("El identificador del sorteo debe ser numerico");
}elseif(!SorteoExiste($id)){
        MSg("Al Parecer el sorteo al que intentas acceder no existe!");
}elseif(!SorteoDisponible($id)){
        Msg("El Sorteo a alcanzado la cantidad de Usuarios!");
}else if(isAdmin($AID)){
        Msg("Eres del Staff no puedes entrar al Sorteo! xD");
}elseif(yaJugo($id, $AID)){
        Msg("Usted Ya participo en este sorteo! xD");
}
mssql_query("UPDATE Sorteo SET CantUsers = CantUsers + 1 WHERE ID = ".$id);
mssql_query("INSERT INTO SorteoUsers (ID_Sorteo, AID) VALUES (".$id.", ".$AID.")");
$r = mssql_fetch_object(mssql_query("SELECT Coins, TABLA, COLUMNA FROM Sorteo WHERE ID = ".$id));
$coins = $r->Coins;
$TABLA = $r->TABLA;
$COLUMNA = $r->COLUMNA;
 
$consulta = "UPDATE ".$TABLA." SET ".$COLUMNA." = ".$COLUMNA." + ".$coins." WHERE AID = ".$AID;
if(@mssql_query($consulta))
{
        Msg("Felicitaciones Has Ganado en el Sorteo, Los Coins se te han Agregado Satisfactoriamente!");
}else{
        Msg("Hubo un error al Enviar los Coins, Favor Avisar a alguien del Staff");
}
 
?>