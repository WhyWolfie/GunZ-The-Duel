<?php
@session_start();
$HOST = "TU-PC\SQLEXPRESS";
$USER = "sa";
$PASS = "ssdasn";
$DB   = "GunzDB";
/////////////////////////////////////////////////
//////////Menu/////////////////////
$inicio= "index.php";  	// Inicio
$registro= "?vct=registro";    // Registro
$descargas= "?vct=descargas";  // Descargas
$Rankins= "?vct=individualrank";   // Rankins
$Tienda= "?vct=tiendadonate";  	// Tienda
$Panel= "?vct=UserPanel";  // Users Panel
$donaciones="?vct=donaciones"; //Donaciones seccion
$foro= "foro.prysmaxgunz.com";  	// TU FORO
/////////////////////////////////////////////////
//////////////posapie de la web////////////////
$opcion1= "index.php";
$opcion2= "?vct=tiendadonate";
$opcion3= "?vct=individualrank";
$opcion4= "?vct=descargas";
$opcion5= "https://www.facebook.com/groups/PrysmaxGunzOficial/#";
$siguenos= "Siguenos";
$fb= "facebook de la web";
$tw= "twiter de la web";
$g= "google de la web";
$contac= "contactar de la web";
/////////////////////////////////////////////////
$c = mssql_connect($HOST,$USER,$PASS) or die ("ERROR CONEXION SQL");
mssql_select_db($DB,$c) or die ("NO SE ENCONTRO LA BASE DE DATOS");
date_default_timezone_set("America/Mazatlan");
?>