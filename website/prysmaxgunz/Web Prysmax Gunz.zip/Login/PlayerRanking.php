<?
$query = mssql_query("SELECT TOP 5 * FROM Character WHERE DeleteFlag = 0 ORDER BY Level DESC,XP DESC,KillCount DESC,DeathCount DESC");

while($query2 = mssql_fetch_assoc($query))
{
 
$aid = $query2['AID'];
$cid = $query2['CID'];
 
$dtquery = mssql_query("SELECT PreGrade FROM DtCharacterInfo WHERE CID = '$cid'");
$dtquery2 = mssql_fetch_row($dtquery);
 
switch($dtquery2[0])
{
        case 10:
        $dtquery3 = "Img/class/10.jpg";
        break;
        case 9:
        $dtquery3 = "Img/class/9.jpg";
        break;
        case 8:
        $dtquery3 = "Img/class/8.jpg";
        break;
        case 7:
        $dtquery3 = "Img/class/7.jpg";
        break;
        case 6:
        $dtquery3 = "Img/class/6.jpg";
        break;
        case 5:
        $dtquery3 = "Img/class/5.jpg";
        break;
        case 4:
        $dtquery3 = "Img/class/4.jpg";
        break;
        case 3:
        $dtquery3 = "Img/class/3.jpg";
        break;
        case 2:
        $dtquery3 = "Img/class/2.jpg";
        break;
        case 1:
        $dtquery3 = "Img/class/1.jpg";
        break;
}
 
 
?>          <li>
            <table width="200" border="0">
    		<td width="27" align="center"><img src="<?=$dtquery3?>" height="20" width="20"></td>
			<td width="125" align="center"><a href="index.php?vct=charinfo&id=<?=($query2['CID'])?>"><strong ><?=FormatCharName($query2['CID'])?></a></strong></td>
			<td width="26" align="center"><font color='#FF0040'><span class="Estilo8"><strong >Lv.<?=$query2['Level']?><strong/></td>
            </table>
			</li>
			<?}?>