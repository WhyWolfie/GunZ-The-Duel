<table width="230">
            	<?php
	if($_SESSION['AID'] == ""){
	?>
	<form action="index.php?vct=loguear" method="post">
        <tr>
    		<td align="center"><div style="width:230px;background:#151515; padding:10px;">
            <ul class="input-list style-3 clearfix">
			<input type="text" placeholder="username" name="user" />
			<hr color="151515" size="5" />
            <input type="password" placeholder="password" name="pass" />
			</ul>
			<hr color="151515" size="3" />
            <input type="submit" name="submit" class="Info4" value="Iniciar Sesion" />
            </div></td>
  		</tr>
        </form>
	<? }else{
		$accid = mssql_query("SELECT * From Account WHERE AID='".$_SESSION['AID']."'");
		$acc = mssql_fetch_object($accid);
		?>
        
        
        <tr>	
        	<td align="center"><div style="width:210px;">
				<strong><font color='#FFFFFF'>Bienvenido <font color='#FFFF00'><?=$_SESSION['UserID']?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 255){
				echo "<font color='#FF0040' style=' text-shadow: #FF0040 0px 0px 9px;'>Staff</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 254){
				echo "<font color='#00FF40' style=' text-shadow: #00FF40 0px 0px 9px;'>Staff</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 11){
				echo "<font color='#B73EFF' style=' text-shadow: #B73EFF 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 10){
				echo "<font color='#C80480' style=' text-shadow: #C80480 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 9){
				echo "<font color='#D9FD0D' style=' text-shadow: #D9FD0D 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 8){
				echo "<font color='#0B0B61' style=' text-shadow: #0B0B61 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 7){
				echo "<font color='#2E2EFE' style=' text-shadow: #2E2EFE 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 6){
				echo "<font color='#FF2E9A' style=' text-shadow: #FF2E9A 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 5){
				echo "<font color='#FFD700' style=' text-shadow: #FFD700 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 4){
				echo "<font color='#4169FF' style=' text-shadow: #4169FF 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 3){
				echo "<font color='#DC143C' style=' text-shadow: #DC143C 0px 0px 9px;'>VIP</font>";
				}?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 2){
				echo "<font color='#FFFF00' style=' text-shadow: #FFFF00 0px 0px 9px;'>Event</font>";
				}?>
				<strong/>
                
                <hr color="242424" size="1" />
                 <?
                if(GetClanMemberByCLID($_SESSION[AID]))
                {
                ?>
<script language="javascript">
function UpdateClan()
{
	var Emblem = document.getElementById("imageclan");
	var ClanList = document.getElementById("clanlist");
	var MasterTxt = document.getElementById("clanmaster");
	var ClanLink = document.getElementById("editlink");

	var ClanData = ClanList.value;
	var CData = ClanData.split("-|-");

	MasterTxt.innerHTML = CData[1];
	Emblem.src = "http://i.imgur.com/" + CData[3];
	ClanLink.href = "javascript:ShowPanel(" + CData[2] + ");";
}
</script>
                <table border="0" width="100%" height="100%">
				<tr>
				<img src="cATDNqD.png" name="imageclan" width="65" height="65" id="imageclan" style="border: 2px solid #000000"></td>
				<td width="124">
				<div align="center">
				<select onChange="UpdateClan()" id="clanlist" size="1" name="selclan" style="color: #000000; font-family: Verdana; font-size: 9pt; border: 2px solid #0404B4; background-color: #FFFFFF">
				<?
                $qr = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION[AID]}' AND DeleteFlag = 0");
                if( mssql_num_rows($qr) > 0 )
                {
                while($char = mssql_fetch_assoc($qr))
                {
                $queryc = mssql_query("SELECT * FROM ClanMember(nolock) WHERE CID = '{$char[CID]}'");
                if( mssql_num_rows($queryc) > 0 )
                {
            $a = mssql_fetch_assoc($queryc);
            $b = mssql_fetch_assoc(mssql_query("SELECT * FROM Clan(nolock) WHERE CLID = '{$a[CLID]}' AND DeleteFlag = 0"));
            $_CLAN[Name]       = $b[Name];
            $_CLAN[Master]     = GetClanMasterByCLID($a[CLID]);
            $_CLAN[CLID]       = $a[CLID];
            $_CLAN[Emblem]     = ($b[EmblemUrl] == "") ? "cATDNqD.png" : $b[EmblemUrl];

            $info = implode("-|-", $_CLAN);
            if($_CLAN[Name] <> "")
            echo "<option value = '$info'>{$_CLAN[Name]}</option>";
            }
            }
            }
            ?>
			</select>
			</td>
			</tr>
			<tr>
			<td width="124">
			<div align="center">
			<span style="font-size: 11pt"><span style="color:#FFFF00"><strong>Master: <strong/>
			<span id="clanmaster"></span></td></font></span>
			<tr>
			<td width="1">
			<?
            if(CheckIfExistClan($_SESSION[AID]))
            {
            ?>
			<a href="index.php?vct=emblems"><button type="button" name="insert" class="Info3">Cambiar Emblema</button>
			<?
            }
            ?>
            </tr>
			</tr>
			</table>
            <?
            }else{
            ?>
			<table border="0" width="0" height="100%">
			<tr>
			<p align="center"><strong>No Tienes Clan<strong/>
			<p align="center" style="font-size: 9pt">Hazte miembro de un clan o crea uno</p></td>
			</tr>
			</table>
                                                    <?
                                                    }
                                                    ?>
				<hr color="242424" size="2" />
				<span style="color:#FFFFFF">
				<p align="center">
				Donator Coins: <?=$acc->DonatorCoins?>
				<p align="center">
				Event Coins: <?=$acc->EventCoins?>
				<p align="center">
				Coins: <?=$acc->Coins?>
				<p align="center">
                <span style="color:#FF0000">AID: <?=$_SESSION['AID']?>
				<p align="center">
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 255){
				echo "<a href='link'><strong>Admin Panel<strong/></a><br>";
				}
				?>
				<?
				$ugrade = $acc->UGradeID;
				if($ugrade == 254){
				echo "<a href='link'><strong>Mod Panel<strong/></a><br>";
				}
				?>
				<a href='?vct=recuperarpersonaje'><strong>Recuperar Personajes<strong/></a>
				<a href='?vct=UserPanel'><strong>UserPanel<strong/></a>
				<p align="Center">
				<a href="?vct=desloguear"><button type="button" name="insert" class="Info2">Salir</button>
	</div></td>
	</tr>
    <? }?>
    </table>