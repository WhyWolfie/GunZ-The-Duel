<?php
SetTitle("");
if($_SESSION[AID] == "")
{
	alertbox("Deves estar Logueado para recuperar personajes","index.php");
	die();
}
else
{
    $qchars = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}'");
    if( mssql_num_rows($qchars) == 0 )
    {
	alertbox("No tienes ningun personaje en esta cuenta","index.php");
	die();
    }
    else
    {

    if( isset($_GET['cid']) )
    {
        $cid = clean($_GET['cid']);
        $qcharinfo = mssql_query_logged("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = $cid");
        if( mssql_num_rows($qcharinfo) == 0 )
        {
	alertbox("El personaje seleccionado no existe o no pertenece a tu cuenta","index.php");
	die();
        }

        $info = mssql_fetch_assoc($qcharinfo);

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE Name = '".$info['DeleteName']."'")) == 1 )
        {
	alertbox("Un personaje con este nombre ya existe Desafortunadamente no lo podras recuperar","index.php");
	die();
        }

        if( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 0")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 0, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 1")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 1, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 2")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 2, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        elseif( mssql_num_rows(mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '".$_SESSION[AID]."' AND CharNum = 3")) == 0 )
        {
            mssql_query_logged("UPDATE Character SET CharNum = 3, Name = '".$info['DeleteName']."', DeleteFlag = 0, DeleteName = NULL WHERE AID = '".$_SESSION[AID]."' AND CID = '$cid'");
        }
        else
        {
	alertbox("Su cuenta tiene + de 4 personajes Activos por lo tanto para recuperar deve borrar 1","index.php");
	die();
        }

	alertbox("El personaje Seleccionado se a Recuperado con Exito","index.php");
	die();
    }
    else
    {


    ?>
<style type="text/css">
<!--
.Estilo1 {
	font-size: 10px;
	font-weight: bold;
	color: #666666;
}
.Estilo3 {font-size: 12px}
-->
</style>
<table>
<td bgcolor="#151515">
<table border="0" style="border: 4px solid #242424; float:center" width="600" height="100">
                                <tr>
                                    <td bgcolor="#2C2A2A">
						<div align="center">
        <span style="color:#FFFFFF"><strong>Aqui podras recuperar personajes que has borrado
o te han borrado involuntariamente.
Debes de saber que en una cuenta de Prysmax se permite
un maximo de 4 personajes, por lo tanto
si ya tienes 4 personajes activos y deseas recuperar
uno de los personajes borrados,
deberas borrar un personaje activo
para dar lugar al que recuperaras.<strong/></span></p>

        <span style="color:#FFFF00">Lista de personajes:</span><br />
        <br />
        <table align="center" border="1" width="60%" style="templatemo_footer_wrapper" id="table1">
        	<tr>
        		<td><span class="Estilo3"><b>Nombre</b></span></td>
        		<td><span class="Estilo3"><b>Level</b></span></td>
        		<td><span class="Estilo3"><b>Tipo</b></span></td>
        		<td><span class="Estilo3"><b>Recuperar?</b></span></td>
        	</tr>
            <?

        while( $data = mssql_fetch_assoc($qchars) )
        {
            echo '
            	<tr>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo $data[DeleteName].'</td>';
                    }else{
                        echo $data[Name].'</td>';
                    }

                echo '<td>'.$data[Level].'</td>
            		<td>';
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo 'Borrado</td>
                    <td>';
                    }else{
                        echo 'Activo</td>
                    <td>';
                    }
                    if( $data[DeleteFlag] == "1" )
                    {
                        echo '<a href="index.php?vct=recuperarpersonaje&cid='.$data[CID].'">Recuperar!</a></td>
            	</tr>';
                    }else{
                        echo 'Activo</td>
            	</tr>';
                    }

        }
        ?>
        </table>
        <br /><br /></td></tr></table></div>
	  </td>
						<td width="171" valign="top">
						<div align="center">
						</div>
						</td>
	  </tr>
</table>
        <?
    }
}
}

?>
