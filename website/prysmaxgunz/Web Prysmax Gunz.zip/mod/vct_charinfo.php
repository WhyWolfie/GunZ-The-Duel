<table>
<td>
<table border="0" style="border: 4px solid #; float:center" width="600" height="100">
<?
SetTitle("");
    $cid = ($_GET['id']);
if(!is_numeric($cid)){
msgbox("Not Available","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);

if($num_rows < 1){
msgbox("La Cuenta no Existe","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "997" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "998" || $char2['UGradeID'] == "999"){
    msgbox("Usted no puede ver informacion de este Personaje.","index.php");
exit();
	}
	if ( $char2['DeleteFlag'] != "0"){
    msgbox("Usted no puede Entrar aqui","index.php");
exit();
	}
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "";

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
<td width="380" style="background-repeat: no-repeat; background-position: center top">
                                    <tr>
                                      <td bgcolor="" class="" align="center" valign="top">
                                        <table width="335" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td align="center" valign="top"><table width="190" border="0" align="center">
                                                  <tr>
                                                    <td colspan="2" align="center" class=""><span style="color:#FFFF00"><strong>Informacion Personal</font></td>
                                                  </tr>
                                                  <tr>
                                                    <td width="42" align="left" class="" height="18"></td>
                                                    <td width="168" align="left" class=""></td>
                                                  </tr>
                                                  <tr>
                                                    <td align="left" class="">                                                      <align="justify"><font color="White"><strong>Nombre:</font></div></td>
                                                    <td align="left" class="">                                                      <align="justify">
                                                      <font color="White"><strong>
                                                      <?=$char2['Name']?>
                                                      </font></td>
                                                  </tr>
                                                  <tr>

                                                  </tr>
                                                  <tr>
                                                    <td align="left" class="">                                                      <align="justify"><font color="White"><strong>Edad:</font></td>
                                                    <td align="left" class="">                                                      <align="justify">
                                                      <font color="White"><strong>
                                                      <?=$char2['Age']?>
                                                      </font></td>
                                                  </tr>
                                                  <tr>
                                                    <td align="left" class="">                                                      <align="justify"><font color="White"><strong>Rango:</font></td>
                                                    <td align="left" class="">                                                      <align="justify">
                                                      <font color="White"><strong>
                                                      <?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Miembro";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GM";
                                                        break;
														case "253";
                            							$ugradeid = "Banned";
                                                        break;
														case "254";
                                                        $ugradeid = "Developer";
                                                        break;
														case "255";
                                                        $ugradeid = "Admin";
                                                        break;
														case "3";
                                                        $ugradeid = "Donate";
                                                        break;
                                                        case "4";
                                                        $ugradeid = "Donate";
                                                        break;
                                                        case "5";
                                                        $ugradeid = "Donate";
                                                        break;
                                                        case "6";
                                                        $ugradeid = "Donate";
                                                        break;
														case "7";
                            							$ugradeid = "Donate";
                                                        break;
														case "8";
                                                        $ugradeid = "Donate";
                                                        break;
														case "9";
                                                        $ugradeid = "Donate";
                                                        break;
														case "10";
                                                        $ugradeid = "Donate";
                                                        break;
                                                        case "11";
                                                        $ugradeid = "Donate";
                                                        break;
                                                        } echo $ugradeid;

                                                        ?>
                                                      </font></td>
                                                  </tr>
                                                  <tr>
                                                    <td align="left" class="">                                                      <align="justify"><font color="White"><strong>Pais</font></td>
                                                    <td align="left" class="">                                                      <align="justify">
                                                      <font color="White"><strong>
                                                      <?=$char2['Country']?>
                                                      </font></td>
                                                  </tr>
                                                </table>
                                                  <p>&nbsp;</p>
                                                <table width="220" border="0" align="center">
                                                    <tr>
                                                      <td colspan="2" align="center" class=""><span style="color:#FFFF00"><strong>Informacion del Personaje</font></td>
                                                    </tr>
                                                    <tr>
                                                      <td width="78" align="left" class="" height="18"></td>
                                                      <td width="132" align="left" class=""></td>
                                                    </tr>
                                                    <tr>
                                                      <td align="left" class="">                                                        <align="justify"><font color="White"><strong>Nombre:</font></div></td>
                                                      <td align="left" class="">                                                        <align="justify">
                                                        <strong>
                                                        <span style="color:#FFFFFF"><?=$char['Name']?>
                                                        </font></td>
                                                    </tr>
                                                    <tr>
                                                      <td align="left" class="">                                                        <align="justify"><font color="White"><strong>Nivel:</font></div></td>
                                                      <td align="left" class="">                                                        <align="justify">
                                                        <font color="White"><strong>
                                                        <?=$char['Level']?>
                                                        </font></td>
                                                    </tr>
                                                    <tr>
                                                      <td align="left" class="">                                                        <align="justify"><font color="White"><strong>Exp:</font></div></td>
                                                      <td align="left" class="">                                                        <align="justify">
                                                        <font color="White"><strong>
                                                        <?=number_format($char['XP'],0,'','.');?>
                                                        </font></td>
                                                    </tr>
                                                    <tr>
                                                      <td align="left" class="">                                                        <align="justify"><font color="White"><strong>Kill/Death:</font></div></td>
                                                      <td align="left" class="">                                                        <align="justify">
                                                        <font color="White"><strong>
                                                        <?=GetKDRatio($char['KillCount'], $char['DeathCount'])?>
                                                        </font></td>
                                                    </tr>
                                                    <tr>
                                                      <td align="left" class="">                                                        <align="justify"><font color="White"><strong>Clan:</font></td>
                                                      <td align="left" class="">                                                        <align="justify">
                                                      <a href="index.php?vct=claninfo&id=<?=$claninfo['CLID']?>"><strong><?=$claninfo['Name']?></a>
                                                      </font></td>
                                                    </tr>
                                                </table>
												<span style="color:#FFFF00"><strong>Signature
                                                      <align="center"><br><img src="http://127.0.0.1:8080/Gunz/genericsing.php?cid=<?=$char['CID']?>" width="350" height="150" ></td>
                                                      </font></td>
                                            </tr>
											</table>
												</td>
                                            </tr>
                                                                                </table>
                                                                        </tr>
                                    <tr>
                                      <td width="380" style="background-repeat: no-repeat; background-position: center top">
                                        
                                  </table>
								  </center></td>
					</tr>
				</table></td>
				<br>
                <id="cont-footer">
                <td width="38" style="background-repeat: no-repeat; background-position: center top"><align="center">

					  				  </td>
  </tr>
											<tr>
												<td width="213" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="693" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="38" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											</table>
									<p align="center"></td>
						<td width="171" valign="top">
						
						</td>
					</tr>
				</table>