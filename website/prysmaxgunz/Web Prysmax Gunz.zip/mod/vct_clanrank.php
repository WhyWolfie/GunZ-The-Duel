<?php
SetTitle("EnergyGz - Rank Clan");
?>
<br>
<a href="index.php?vct=individualrank"><button type="button" name="insert" class="Info3">Player Ranking</button></a>
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url(''); background-repeat:repeat-y" width="640">
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
									<br>
										<table border="0" style="background-position: center top; border-collapse: collapse; background-image: url(''); background-repeat:no-repeat" width="563" height="146">
                                        <?
                                            $res = mssql_query_logged("SELECT TOP 4 * FROM Clan(nolock) WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND (Wins != 0 OR Losses != 0) ORDER BY Point DESC, TotalPoint DESC, Wins DESC, Losses ASC");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "cATDNqD.png" : $resa->EmblemUrl;

                                            if($Count == 4)
                                                break;
                                            else
                                                $Count++;
                                            }

                                            $firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "cATDNqD.png" : $FirstClan[0][EmblemURL];
                                            $firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "cATDNqD.png" : $FirstClan[1][EmblemURL];
                                            $firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "cATDNqD.png" : $FirstClan[2][EmblemURL];
                                            $firstclanemb3 = ($FirstClan[3][EmblemURL] == "") ? "cATDNqD.png" : $FirstClan[3][EmblemURL];

                                            $firstclanname0 = ($FirstClan[0][Name] == "") ? "No hay datos" : $FirstClan[0][Name];
                                            $firstclanname1 = ($FirstClan[1][Name] == "") ? "No hay datos" : $FirstClan[1][Name];
                                            $firstclanname2 = ($FirstClan[2][Name] == "") ? "No hay datos" : $FirstClan[2][Name];
                                            $firstclanname3 = ($FirstClan[3][Name] == "") ? "No hay datos" : $FirstClan[3][Name];


                                            $toprank = '
											<tr>
											<td width="59" align="center">
												<td width="144" valign="bottom" height="107">
												<img src="http://i.imgur.com/'.$firstclanemb0.'" width="80" height="80" style="border: 1px solid #000000"></td>
												<td width="135" valign="bottom" height="107">
												<img src="http://i.imgur.com/'.$firstclanemb1.'" width="80" height="80" style="border: 1px solid #000000"></td>
												<td width="126" valign="bottom" height="107">
												<img src="http://i.imgur.com/'.$firstclanemb2.'" width="80" height="80" style="border: 1px solid #000000"></td>
											</td>
											</tr>
											<tr>
												<td width="556" colspan="4" height="40">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="556" height="100%">
														<tr>
															<td width="90">&nbsp;</td>
															<td width="128">
															<font color="#00FF00" style=" text-shadow: #FFFF00 0px 0px 9px;">
															<b>'.$firstclanname0.'</b></font></td>
															<td width="900">&nbsp;</td>
															<td width="126">
															<font color="#4169FF" style=" text-shadow: #4169FF 0px 0px 9px;">
															<b>'.$firstclanname1.'</b></td>
															<td width="700">&nbsp;</td>
															<td width="122">
															<font color="#FF0000" style=" text-shadow: #FF0000 0px 0px 9px;">
															<b>'.$firstclanname2.'</b></td>
															<td width="7">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="128">&nbsp;</td>
															<td width="10">&nbsp;</td>
															<td width="126">&nbsp;</td>
															<td width="7">&nbsp;</td>
															<td width="122">&nbsp;</td>
															<td width="11">&nbsp;</td>
															<td width="122">&nbsp;</td>
															<td width="7">&nbsp;</td>
														</tr>
													</table>
												</div>
												</td>
												</tr>
											</table>
									</div>
									</td>
								</tr>';
                                echo $toprank;
                                ?>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
                                    <div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="vct" value="clanrank" />
									<select name="type">
									<option value="1">Nombre del Clan</option>
                                    <option value="2">Master del Clan</option>
									</select>
									<input type="text" name="name"/>
									<input type="submit" value="Buscar" />
                                    <p align="center">
					                </form>
                                    </td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse; background-image: url(''); background-repeat: no-repeat; background-position: center top">
											<tr>
												<td width="14" height="21">&nbsp;</td>
												<td width="60" height="21" valign="bottom">
												
													<span style="color:#000000;"><b>
													Ranking</b></font></td>
												<td width="44" height="21" valign="bottom">
												
													<span style="color:#000000;"><b></b></font></td>
												<td width="98" height="21" valign="bottom">
												
													<b><span style="color:#000000;">
													Clan Name</font></b></td>
												<td width="93" height="21" valign="bottom">
												
													<b><span style="color:#000000;">Lider</font></b></td>
												<td width="82" height="21" valign="bottom">
												
													<span style="color:#000000;"><b>Win/Losses</b></font></td>
												<td width="92" height="21" valign="bottom">
												
													<span style="color:#000000;"><b>Win %</b></font></td>
												<td width="69" height="21" valign="bottom">
												
													<b><span style="color:#000000;">
													Puntos</font></b></td>
												<td width="13" height="21">&nbsp;</td>
											</tr>
											<tr>
												<td width="14">&nbsp;<p>&nbsp;</p>
												<p>&nbsp;</p>
												<p></td>
												<td width="538" colspan="7" valign="top">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="102%">
														<tr>
															<td width="59">&nbsp;</td>
															<td width="43">&nbsp;</td>
															<td width="99">&nbsp;</td>
															<td width="93">&nbsp;</td>
															<td width="82">&nbsp;</td>
															<td width="92">&nbsp;</td>
															<td width="69">&nbsp;</td>
														</tr>
                                                <?
												$squery = "SELECT TOP 0 * FROM Clan";
                                                        if( isset($_GET['type']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $type = clean($_GET['type']);
                                                            $name = clean($_GET['name']);

                                                            if($type == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name'";
                                                            }
                                                            elseif($type == 2)
                                                            {
                                                                $charq = mssql_query("SELECT CID FROM Character(nolock) WHERE Name = '$name'");
                                                                if( mssql_num_rows($charq) == 1 )
                                                                {
                                                                $characterdata = mssql_fetch_row($charq);
                                                                $cid = $characterdata[0];
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE MasterCID = '$cid' AND DeleteFlag=0 ORDER BY Point DESC";
                                                                }
                                                                else
                                                                {
                                                                    echo '';
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $search = 0;
                                                        }

                                                        if($search == 0 )
                                                        {
														if(isset($_GET['page'])){
														$page = clean($_GET['page']);
														if(!is_numeric($page))
														{
														$page = 1;
														}
														}else{
														$page = 1;
														}
														switch($page){
														case 1:
														$ir = "WHERE Ranking <= '20'";break;
														case 2:
														$ir = "WHERE Ranking >= '21' AND Ranking <='40'";
														break;
														case 3:
														$ir = "WHERE Ranking >= '41' AND Ranking <='60'";
														break;
														case 4:
														$ir = "WHERE Ranking >= '61' AND Ranking <='80'";
														break;
														case 5:
														$ir = "WHERE Ranking >= '81' AND Ranking <='100'";
														break;
														}
                                                           eng_query("UPDATE Clan SET Ranking='0'");
                                                           $q = eng_query("SELECT TOP 100 * From Clan WHERE Name != '' Order By Point DESC");
                                                           $c = 1;
                                                           while($r = eng_object($q)){
                                                           eng_query("UPDATE Clan SET Ranking='".$c."' WHERE CLID='".$r->CLID."'");
                                                           $c++;
                                                           }
                                                           $res = mssql_query("SELECT * From Clan ".$ir." AND Ranking !='0' Order By Ranking ASC");
                                                        }
                                                        else
                                                        {
                                                            $res = mssql_query_logged($squery);
                                                        }
                                                       if(mssql_num_rows($res) <> 0)
                                                        {
                                                            $count=1+$start;
															
                                                            while($clan = mssql_fetch_object($res))
                                                            {

                                                        $clanemburl = ($clan->EmblemUrl == "") ? "cATDNqD.png" : $clan->EmblemUrl;
                                                        $clanrank .= '
                                                        <tr>
                                                        <td width="59" align="center">
                                                        <span style="color:#000000"><strong><strong><b>'.$count.'</b></b></td>
                                                        <td width="70" align="center">
                                                        <img src="http://i.imgur.com/'.$clanemburl.'" width="34" height="30" style="border: 1px solid #000000"></td>
                                                        <td width="43" align="center">
                                                        <font color="#FFFFFF" style=" text-shadow: #000000 0px 0px 9px;">'.$clan->Name.'</font></td>
                                                        <td width="149" align="center">
                                                        <span style="color:#000000"><strong><strong>'.FormatCharName($clan->MasterCID).'</td>
                                                        <td width="145" align="center">
                                                        <span style="color:#000000"><strong>'.$clan->Wins . "/" . $clan->Losses.'</td>
														<td width="145" align="center">
                                                        <span style="color:#000000"><strong>'.GetClanPercent($clan->Wins, $clan->Losses).'</td>
														<td width="145" align="center">
                                                        <span style="color:#000000"><strong>'.$clan->Point.'</td>
                                                        </tr>';
														$count++;
                                                            }
                                                        }else{
		?>
           </tbody>
        <tr align="center">
        <td colspan="8"><center><STRONG><font color="#00FF00">No Existe.</STRONG></center></td></tr>
        
        <? }
                                                echo $clanrank;
                                                     ?>
												</table>
												</div>
                                            <?
                                            if( $search == 0 )
                                            {
                                            ?><p align="center"><a href="#"></a></p>
                                                <p align="center"><a href="index.php?vct=clanrank"></a></p>
                                                <?
                                            }
                                            ?>
                                    </td>
												<td width="13">&nbsp;</td>
											</tr>
											</table>
									</div>
									<br>
									<br>
									<p></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
													  </table>
					</tr>
</table>
<br>