<?SetTitle("EnergyGz - Descargas");?>	
<div class="content">
                	<div align="center" >
                    	<h1 class="blind"><span style="color:#FF0000">DESCARGAR EL JUEGO</h1>
                    </div>
                    <div align="center" class="client mgt25">
                    	<h3 class="blind"><span style="color:#ffffff">Descargar el cliente de GunZ 
						<?php $time = time(); echo date("d-m-Y"); ?>
						</h3>
                        <ul class="client_list mgt10">
                        <a href="#"><img alt="Cliente oficial Descargar" src="img/Descargas/client1_s.PNG"></a>
                        <a href="https://mega.nz/#!9U0TQQDD!9dtUyDn2Ao9Hkn3O8O8TrFlaWKRpwip23Zx0B-7irsg"><img alt="Cliente oficial Descargar" src="img/Descargas/client1.PNG"></a>
                        <a href="http://copiapop.es/Ryuzu/installers-31725/px-gunz,174594,gallery,1,1.exe" alt="Cliente oficial Descargar"><img src="img/Descargas/torrent1.PNG"></a>
                        <a href="https://drive.google.com/file/d/0Bx3F7SBiyBqEZklFQ3RDdGlXUUE/view"><img alt="Cliente oficial Descargar" src="img/Descargas/torrent2.PNG"></a>
                        </ul>
						<td width="1" style="background-repeat: no-repeat; background-position: center top">
												</td>
												<td width="170" style="background-repeat: no-repeat; background-position: center top; " colspan="3" height="170" valign="top">
												<div align="center">
													<table border="0" cellpadding="3" cellspacing="1" width="90%">
														<tr>
															<td bgcolor="#121212" width="80">
															<span style="font-size: 8pt">
															&nbsp;</span></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Minimos</span></b></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Recomendados</span></b></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">OS</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Windows 2000, Windows XP, Windows 7 Windows 8 Windows 10 , & Linux </span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">DirectX</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">DirectX 9.0c</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">CPU</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Pentium III 500 Mhz</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Pentium III 800 Mhz
															</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Memory</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">256 MB</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">512 MB or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Graphic Card</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Direct3D 9.0
															<span style="color:#FFFFFF">Compatible</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">GeForce 4 MX or higher</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212" height="21">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Sound Card</span></td>
															<td colspan="2" align="center" bgcolor="#232323" height="21">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Direct3DSound
															<span style="color:#FFFFFF">Compatible</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Mouse</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 8pt">
															<span style="color:#FFFFFF">Windows Compatible (Mouse De Ruedita Recomendado)</span></td>
														</tr>
													</table>
												</div>
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">&nbsp;
												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;
												</td>
											</tr>
											</table>

</ul>
</div><div class="drive"><ul class="drive_list mgt10"></li>
</ul>
</div>
</div>