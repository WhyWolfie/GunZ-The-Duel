<?

if($_SESSION[AID] <> "")
{
    $u = vct_antisql($_SESSION['UserID']);

    session_unset();

    session_destroy();
	redir("index.php");
}else{
alertbox("No Puedes Desconectarte Ya Que No Estas Conectado","index.php");
    die();
}

?>