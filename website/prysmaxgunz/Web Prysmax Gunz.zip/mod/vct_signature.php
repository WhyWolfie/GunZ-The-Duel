<?php
SetTitle("EnergyGz - Firma");
include "configsing.php";
?><head>
<script type="text/javascript">
    function UpdateSignature()
    {
        var cid = document.signature.charlist.value;
        var firma = document.getElementById("firma");
        firma.innerHTML = '<img src="<?=$url?>/genericsing.php?cid='+ cid + '" />';
        document.signature.forumcode.value = '[URL="<?=$url?>/"][IMG]<?=$url?>/genericsing.php?cid=' + cid + '[/IMG][/URL]';
        document.signature.directlink.value = "<?=$url?>/genericsing.php?cid=" + cid + "";
    }

</script>
</head>
<?

if( $_SESSION['AID'] == "" ){
	alertbox("User Deves estar Logueado para Usar esta funcion","index.php");
	die();
	}
    $qbt01 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");

    if( mssql_num_rows($qbt01) < 1 )
    {
        alertbox("No tienes Personajes para usar esta Funcion","index.php");
        die();
    }

?>
                <form name="signature">
				<table border="0" style="border-collapse: collapse" width="640" height="100%">
                <br>
				<tr>
				<td width="10">&nbsp;</td>
				<td width="181">
				<p align="right"><font color="#0000FF" style=" text-shadow: #000000 0px 0px 9px;"><strong>Selecciona Personaje</strong>
				<td width="13">&nbsp;</td>
				<td width="190">
				<select size="1" name="charlist" onchange="UpdateSignature()">
                 <?
                while( $databt01 = mssql_fetch_row($qbt01) )
                {
                ?>
                <option value="<?=$databt01[0]?>"><?=$databt01[1]?></option><br />';
                 <?
                }
                ?>
				</select></td>
				<td width="11">&nbsp;</td>
				</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td align="center" colspan="5">
												<font color="#000000" style=" text-shadow: #0000FF 0px 0px 9px;"><strong>Tu Firma:</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
											<tr>
												<td align="center" colspan="5"><span id="firma"></span></td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="315" colspan="3">&nbsp;</td>
												<td width="11">&nbsp;</td>
											</tr>
                                            <tr>
            <td width="10">&nbsp;</td>
			<td align="center" width="315" colspan="3">
            <font color="#000000" style=" text-shadow: #FF0000 0px 0px 9px;"><strong> Para copiar el Link Presiona Ctrl + C<br />
<br />
            <font color="#000000" style=" text-shadow: #FF0000 0px 0px 9px;">Codigo para los Foros:<br />
            <input type="text" name="forumcode" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/></td>
			<td width="11">&nbsp;</td>
			</tr>
			<tr>
			<td width="10">&nbsp;</td>
			<td width="315" colspan="3">&nbsp;</td>
			<td width="11">&nbsp;</td>
			</tr>
            <tr>
             <td width="10">&nbsp;</td>
			<td align="center" width="315" colspan="3">
            <font color="#0000FF" style=" text-shadow: #000000 0px 0px 9px;"><strong> Link Directo:<br />
            <input type="text" name="directlink" onclick="javascript:select();" readonly="readonly" style="width: 310px; font-size: 11px;"/></td>
			<td width="11">&nbsp;</td>
			</tr>
            <script type="text/javascript">
             UpdateSignature();
            </script>
										</table></form>
						</td>
					</tr>
				</table>