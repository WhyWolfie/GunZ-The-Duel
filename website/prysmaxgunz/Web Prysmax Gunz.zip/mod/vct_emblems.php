<script language="JavaScript">
<!--
function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } } 
  doc.$imgSwaps=null; }
}
// -->
</script>
<?
SetTitle("EnergyGz - Clan Emblema");
if( $_SESSION['AID'] == "" ){
	alertbox("Deves estar Logueado para Subir emblema a un Clan","index.php");
	die();
	}
?>
<div align="center" >
                    	<h1 class="blind"><span style="color:#FF0000">Subir Emblema</h1>
                    </div>
							<table border="0" style="border-collapse: collapse" width="100%" bordercolor="">
						<div align="center">
							<table border="0" style="border-collapse: collapse" width="100%" bordercolor="">
							<br>
								<tr>
									<td bgcolor="">
									<div align="center">
<span class="Blanco"><?php
include("func.php");

if(!empty($_FILES['image']['tmp_name']))
{
    $imagen = subirimg($_FILES['image']['tmp_name']);
    if(!empty($imagen))
    {
        echo "Link: ".$imagen;
    }else{
        echo "Error al Subir la Imagen :/";
    }
}
?>
<style type="text/css">
.Rojo {	color: #F00;
}
.Blanco {	color: #000000;
}
</style>
<br>
<span class="Rojo"><form method="post" enctype="multipart/form-data">
    <input type="file" name="image">
    <br />
	<br>
    <button type="submit" class="Info2">Subir</button>
</form>
<span class="Rojo"><strong>SOLO IMAGENES 100x100 Formato PNG<strong/></span>
<p><strong><span style="color:#000000">Recuerde que solo nesesitas lo que esta<strong>
<p><strong><span style="color:#000000">despues del /.. http://i.imgur.com/<span class="Rojo">ooZiVRF.png<strong/></span>
<p><strong><span style="color:#000000">Solo Lo que esta en rojo es lo que colocaras abajo!<strong/></p>
<p><strong><span style="color:#000000">Ya tiene Su Link? Dirijase al Paso Siguiente<strong/></p>
<p><a href="index.php?vct=emblems2"><button type="button" name="insert" class="Info">Paso Siguiente</button></td></tr>
<p>&nbsp;</p>
									</div>
									</td>
								</tr>
							</table>
				</table>