﻿<center><style>
.crear {
	background:#edffec;
	width:100px;
	border:1px #cccccc solid;
	 padding:10px;
	}
</style>
<?php
SetTitle(" Registro");
if($_SESSION[UserID] <> "")
{
			alertbox("Deslogueate primero antes de Crear otras cuentas","index.php");
}
if(isset($_POST['reg'])){
	$user = vct_antisql($_POST['username']);
	$name = vct_antisql($_POST['name']);
	$pass1 = vct_antisql($_POST['pass1']);
	$pass2 = vct_antisql($_POST['pass2']);
	$email = vct_antisql($_POST['email']);
	$Country = vct_antisql($_POST['Country']);
	$Age = vct_antisql($_POST['Age']);
	$code = vct_antisql($_POST['clave']);
	$vcode = vct_antisql($_POST['captcha']);
	$pre = vct_antisql($_POST['pre']);
	$res = vct_antisql($_POST['res']);
	$grade = vct_antisql('0');
	$coins1 = vct_antisql('100');
	$coins2 = vct_antisql('0');
	$coins3 = vct_antisql('0');
	if(empty($user) || empty($pass1) || empty($pass2) || empty($email) || empty($Country) || empty($Age) || empty($code) || empty($name) || empty($vcode) || empty($pre) || empty($res)){
		alertbox("No dejar ningun campo vacio.","?vct=registro");
		die();
		} 
	$very = mssql_query("SELECT * From Account WHERE UserID='".vct_antisql($user)."'");
	$very2 = mssql_query("SELECT * From Account WHERE Email='".$email."'");
	if(mssql_num_rows($very) == 1){
		alertbox("El User $user Ya existe.","?vct=registro");
		die();
		}
	if(mssql_num_rows($very2) == 1){
		alertbox("El Email $email Ya existe.","?vct=registro");
		die();
		}
	if($pass1 != $pass2){
		alertbox("Contraseñas no considen.","?vct=registro");
		die();
		}
	if($code != $vcode){ 
	alertbox("codigo de seguridad no considen.","?vct=registro");
	 die(); }
	 
	mssql_query("INSERT INTO Account (UserID, UGradeID, PGradeID, Email, Country, Age, Answer, RegDate, name, sa, sq, Coins, EventCoins, DonatorCoins) VALUES ('$user', '$grade', '$grade', '$email', '$Country', '$Age', '$Answer', GETDATE(), '$name', '$pre', '$res', '$coins1', '$coins2', '$coins3')");
	$xe = 	mssql_query("SELECT * From Account WHERE UserID='".$user."'");
	$acc = mssql_fetch_object($xe);
	$aid = $acc->AID;

mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '895588', GETDATE(), '160', '1')");
mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '895582', GETDATE(), '160', '1')");
mssql_query("INSERT INTO AccountItem([AID], [ItemID], [RentDate], [RentHourPeriod], [Cnt])Values('$aid', '502019', GETDATE(), '160', '1')");

	mssql_query("INSERT INTO Login ([UserID], [AID], [Password])Values ('$user', '$aid', '$pass1')");
	alertbox("Cuenta creada con exito, Bienvenido Usuario: $user ","index.php");
	die();
	}

$random = (rand()%99999);
?>
<div style="background:url(img/div/center/head2.png) no-repeat; width:593px; height:30px;">
		<table width="640" border="0">
  			<tr>
    			<td width="572" height="25" align="center" style="background:; border:0px #cccccc solid; padding:5px;"><span style="color:#FFFFFF; font-size:16px;"><strong>Registro</strong></td>
  			</tr>
		</table>
</div>
      
			<div align="center" class="tit_download_client">
                    	<h1 class="blind"><span style="color:#FF0000">REGISTRO DE USUARIO</h1>
                    </div>
<div style="background:url(img/div/center/center2.png) repeat-y; width:640px; font-weight: bold;">
                <br />
                    <form action="" method="post" class="register">
                        <p class='notify'>Las letras y los n&uacute;meros s&oacute;lo se les permite. a-z A-Z 0-9</p>
                          <table border="0" class="registertbl">
                            <tr><td>User ID</td> <td><input type="text" name="username" maxlength="20" class="field" /></td></tr>
							<tr><td>Nombre de Usuario</td> <td><input type="text" name="name" maxlength="20" class="field" /></td></tr>
                            <tr><td>Contrase&ntilde;a:</td> <td><input type="password" name="pass1" maxlength="20" class="field" /></td></tr>
                            <tr><td>Confirmar Contrase&ntilde;a:</td> <td><input type="password" name="pass2" maxlength="20" class="field" /></td></tr>
                            <tr><td>Direccion E-mail:</td> <td><input type="text" name="email" maxlength="30" class="field" /></td></tr>
							<tr><td>Pais:</td> <td><input type="text" name="Country" maxlength="30" class="field" /></td></tr>
							<tr><td>Edad:</td> <td><input type="text" name="Age" maxlength="30" class="field" /></td></tr>
                            <tr><td colspan="2"><p class="trnotify">Si ningun Usuario te recomendo deja el campo vacio .</p></td></tr>
							<tr>
                              <td>Codigo de seguridad:</td><td style=" font-size:18px; color:#000000;">
                            <input type="hidden" name="clave" class="input" value="<?PHP 
print("$random"); ?>">
<?PHP print("$random"); ?></td></tr>
                            <tr>
                              <td>Copie Codigo:</td>   
                              <td><input type="text" name="captcha" maxlength="8" class="field" /></td></tr>
                                 <td>Pregunta:</td>   
                              <td><input type="text" name="pre" maxlength="12" class="field" id="pre" /></td></tr>
                                 <td>Respuesta:</td>   
                              <td><input type="text" name="res" maxlength="12" class="field" id="res" /></td></tr>
                            <tr><td colspan="2"><p class="trnotify">Al registrarse, usted esta de acuerdo con las Reglas del GunZ .</p></td></tr>
                            <tr class="spacer"></tr>
                            <tr><td align="center">&nbsp;</td>
                            <td><input type="submit" class="crear" name="reg" value="Registrar" class="submit" /></td>
                 </tr>       </table>
                    </form>
               					<br />


</div>
<div style="background:url(img/div/center/footer2.png) no-repeat; width:593px; height:7px;"></div> </center>