<?php
SetTitle("EnergyGz - Info Item");
if($_GET[itemid] <> "" && is_numeric($_GET[itemid]))
{
    $itemid = clean($_GET[itemid]);
}else    {
	alertbox("Incorrecta Informacion del item","index.php");
	die();
	}

$res = mssql_fetch_object(mssql_query_logged("SELECT * FROM ShopEvents(nolock) WHERE CSSID = $itemid"));


switch($res->Slot)
{
    case 3:
        $type = "Armadura";
    break;
    case 2:
        $type = "Melee";
    break;
    case 1:
        $type = "Rango";
    break;
    case 5:
        $type = "Especial";
    break;
    default:
        $type = "Armadura";
    break;
}

$type = Evento

?>
<div style="background:url(img/div/center/head2.png) no-repeat; width:593px; height:30px;">
		<table width="640" border="0">
  			<tr>
    		<td width="572" height="25" align="center" style="background:; border:0px #cccccc solid; padding:5px;"><font color="#FFFFFF" style=" text-shadow: #000000 0px 0px 9px;"><strong>Info Item de Evento : <span style="color:#80BFFF"><?=$res->Name?></strong></td>
  			</tr>
		</table>
</div>
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
							<br>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="0" style="border-collapse: collapse; border: 0px solid #4A4648" width="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<form method="POST" action="index.php?vct=tiendaEvento" name="frmBuy"><input type="hidden" name="SetID" value="<?=$_GET[setid]?>"><table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="11" rowspan="3">&nbsp;</td>
															<td width="104" valign="top">
															<div align="center">
															<img border="0" src="img/shop/<?=$res->ImageURL?>" width="100" height="100" style="border: 2px solid #FFFFFF"></td>
															<td width="443">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="100%" height="100%">
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#FFFFFF">Tipo:<strong/>
																		</td>
																		<td width="372" align="left">
																		<strong><span style="color:#FFFFFF"><?=$type?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#FFFFFF">Sexo:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#FFFFFF"><?=GetSexByID($res->Sex)?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#FFFFFF">Nivel:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#FFFFFF"><?=$res->Level?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		<strong><span style="color:#FFFFFF">Precio:<strong/></td>
																		<td width="372" align="left">
																		<strong><span style="color:#FFFFFF"><?=$res->Price?><strong/></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="435" colspan="2" style="background-repeat: no-repeat; background-position: center">&nbsp;
																		</td>
																	</tr>
																</table>
																<script language="javascript">
																	UpdatePrice();
																</script>
													
															</td>
															<td width="13" rowspan="3">&nbsp;
															</td>
														</tr>
														<tr>
															<td width="544" colspan="2">&nbsp;</td>
														</tr>
														<tr>
															<td width="544" colspan="2" style="background-image: url('images/mis_iteminfo_bg.jpg'); background-repeat: no-repeat; background-position: center" height="144">
													
																<table border="0" style="border-collapse: collapse" width="544" height="100%">
																	<tr>
																		<td width="181">
															
																			<table border="2" style="border-collapse: collapse" width="175" height="98" bordercolor="#000000">
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Weight</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Weight?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Damage</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Damage?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Delay</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Delay?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Controlability</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Control?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Magazine</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Magazine?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																			</table>
														
																		</td>
																		<td width="181">
														
																			<table border="2" style="border-collapse: collapse" width="175" height="98" bordercolor="#000000">
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Max Bullets</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->MaxBullet?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">HP</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->HP?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">AP</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->AP?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Max Weight</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->MaxWeight?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Reload Time Seg</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->ReloadTime?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																			</table>
													
																		</td>
																		<td width="182">
														
																			<table border="2" style="border-collapse: collapse" width="175" height="98" bordercolor="#000000">
																				<tr>
																					<td width="86" bgcolor="" align="left"><span style="font-size: 7pt; font-weight: 700"><span style="color:#2E2EFE">Duration</span></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->Duration?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><b><span style="font-size: 7pt"><span style="color:#2E2EFE">FR</span></b></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->FR?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><b><span style="font-size: 7pt"><span style="color:#2E2EFE">CR</span></b></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->CR?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><b><span style="font-size: 7pt"><span style="color:#2E2EFE">PR</span></b></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->PR?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																				<tr>
																					<td width="86" bgcolor="" align="left"><b><span style="font-size: 7pt"><span style="color:#2E2EFE">LR</span></b></td>
																					<td width="87" align="right"><span style="color:#2E2EFE"><?=$res->LR?>&nbsp;&nbsp;&nbsp; </td>
																				</tr>
																			</table>
														
																		</td>
																	</tr>
																</table>
											
															</td>
															</tr>
														<tr>
															<td width="569" colspan="4">&nbsp;</td>
														</tr>
													</table>

										
												</td>
											</tr>
										</table>
			
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;
									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">
									<div align="center">
									<a href="index.php?vct=comprarEvento&itemid=<?=$_GET[itemid]?>"><button type="button" name="insert" value="Info" class="Info">Comprar</button></a>
									<a href="index.php?vct=regalarEvento&itemid=<?=$_GET[itemid]?>"><button type="button" name="insert" value="Info" class="Info">Regalar</button></a>
									<a href="index.php?vct=tiendaEvento"><button type="button" name="insert" value="Info" class="Info">Cancelar</button></a></td>
								</tr>
							</table>