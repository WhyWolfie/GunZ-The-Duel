<?
$Criador = "Blasper";
//echo "O anti SQL foi codado por $Criador(Blasper), totalmente 100% seguro, n�o necessita de mais anti-sql.
//echo "Este web site foi desenvolvido e MODIFICADO por Charmape e a equipe DCastro.
//echo "N�o remova estes cr�ditos, Obrigado"
?>

<?php
$link = mssql_connect("Tu-PC\SQLEXPRESS","sa","sadsad");
mssql_select_db("HoundDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'Tu-PC\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User
$DBPass = 'asdasdn'; //Your DB Password
$DB = 'HoundDB'; //Your GunZ DB

////////------------------/////////
$titulosite = "Hound Duel :: Website"; // -- Titulo do site
$nomeserver = "Hound Duel"; // -- Nome do server
$ip="69.162.102.14"; // -- IP para verificar status
$portmg = "6000"; // -- Porta do Match Server

//////CONFIGURAR DOWNLOADS/////////
// -- Download 1
$down1 = "Client Completo";  // Descricao
$down1link = "http://www.embreve.com"; // Link
$down1tam = "230 mb"; // Tamanho
// -- Download 2 ( Patch )
$patch = "Patch"; // Descricao
$patchlink = "http://www.embreve.com"; // Link
$patchtam = "15 mb"; // Tamanho


?>
