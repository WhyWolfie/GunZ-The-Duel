<?
//Coded by Charmape ;D
?>
<center><b>Acesso negado.