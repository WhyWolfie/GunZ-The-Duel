﻿<?
$Criador = "Blasper";
//echo "O anti SQL foi codado por $Criador(Blasper), totalmente 100% seguro, não necessita de mais anti-sql.
//echo "Este web site foi desenvolvido e MODIFICADO por Charmape e a equipe DCastro.
//echo "Não remova estes créditos, Obrigado"
?>
<?php
include "config.php";
include "protecao/funcoes.php";
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
include "protecao/ChecaBanido.php";
include "protecao/ChecaCookies.php";
include "protecao/FuncaoTitulo.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("paginas/mod_" . $_GET['do'] . ".php")) {
        include "paginas/mod_" . $_GET['do'] . ".php";
	}
} }
?>
<?	if ($_GET['expand'] == 1){
   						if (file_exists("paginas/mod_" . $_GET['do'] . ".php")) {
        					include "paginas/mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
<meta http-equiv="content-language" content="pt-br">
<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />
<head>
<link rel="shortcut icon" href="favicons.ico" type="image/x-icon" />
<link href="estilo.css" rel="stylesheet" type="text/css" />
<title><?=$titulosite?></title>
<link href="estilo.css" rel="stylesheet" type="text/css" />
</head>

<body OnSelectstart="return false" OnContextMenu="return false">
<!-- DIV PARA CENTRALIZAR TUDO -->
<div id="centro">
<!--topo-->
<div id="topo">
<div class="logo">
</div>
<!--status-->
<div id="status"><img class="status" src="img/icones/sq_br_next.png" /><?php
        $ip = '69.162.102.14';
        $port = '6000';
        $name = 'Servidor';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo " $name: <font style='color: #FF0000'><B>Offline</B></font>";
        }
        else
        {
            echo " $name: <font style='color: #66F212'><B>Online</B></font>";
            fclose($fp);
        }
    ?>
  
<img class="status" src="img/icones/sq_br_next.png" />  <?php
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1' AND ServerID = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
    echo "&nbsp&nbsp&nbsp&nbspJogadores Online: <strong>$servercount";
    ?></div><!--status-->
<!--menu-->
<div id="menu">
<ul>
<li><a href="index.php">Início</a></li>
<?
if($_SESSION[AID] == "")
{
?>
<li><a href="index.php?do=register">Registro</a></li>
<?
}
?>
<?
if($_SESSION[AID] != "")
{
?>
<li><a href="index.php?do=registro2">Registro</a></li>
<?
}
?>
<li><a href="index.php?do=download">Download</a></li>
<li><a href="index.php?do=ranking">Ranking</a></li>
<li><a href="index.php?do=selec">Webstore</a></li>
<li><a href="index.php?do=donator">Doação</a></li>
<li><a href="index.php?do=staff">Equipe</a></li>
<?
if($_SESSION[AID] != "255")
{
?>
<li><a href="index.php?do=info">Informações</a></li>
<?
}
?>
<?
if($_SESSION[AID] == "255")
{
?>
<li><a href="index.php?do=paineldeusuario"><font color="#FF0000">Staff</font></a></li>
<?
}
?>
</ul>
</div><!--menu-->
</div><!--topo-->
<!--conteudo-->
<div id="conteudo">
<!--lateral-->
<div id="lateral">
    <div id="boxesq">
  <h1>login</h1>
  <img src="img/imagens/fita.png" />
  <?php include "paginas/mod_iLogin.php"?> 
      </div>
      <div id="boxesq">
  <h1>RANKING DE USUÁRIO</h1>
  <img src="img/imagens/fita.png" />
  
<?
  include "paginas/top_rank.php"
  ?>
 
      </div>
      <div id="boxesq">
  <h1>RANKING DE CLAN</h1>
  <img src="img/imagens/fita.png" /> 
<? include "paginas/mod_clanranking.php" ?><br>
  <h1>Vídeo do Mês</h1>
  <img src="img/imagens/fita.png" />
  <?php include "paginas/mod_videodomes.php"?> 
      </div>
</div>
<!--lateral-->
<!--conteudodireita-->
<div id="conteudoright">

<!-- INICIO SCRIPT CONTEUDO -->
<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("paginas/mod_" . $_GET['do'] . ".php")) {
							    include "paginas/mod_" . $_GET['do'] . ".php";
						    }
                        }else{
                            include "paginas/mod_index.php";

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?>
<!-- FIM SCRIPT CONTEUDO -->
</div>
<!--conteudodireita-->
</div>
<!--conteudo-->
<div id="clear">
<p class="bottom">Copyright © 2012 <font color="#FFFFFF"><a href="http://houndgames.com">HoundGames.com</a>.</font> Todos os direitos reservados.<br>
Hound Duel é um servidor totalmente gratuito, as doações são utilizadas para cobrir os gastos do servidor.<br>Website feito por <a href="http://facebook.com/diogofilgueira" target="blank"> Diogo Filgueira</a>.<p>
</div>
</div>

<!--div centro fechada-->

</body>
</html>

<div align="center" style="z-index:9;visibility:visible;"></div><style>HTML,BODY{cursor: url("http://i44.tinypic.com/viaah.png"), url("http://i44.tinypic.com/viaah.png"), auto;}</style><a style="display:scroll;position:fixed;bottom:5px;right:5px;" href="index.php?do=donate" title="Fazer uma doação"><img src="http://4.bp.blogspot.com/--n-zS_Eimmk/TwyRTjmGyII/AAAAAAAAANI/vlJgWYKl_lQ/s1600/aaaaaaaaa.png"/></a>