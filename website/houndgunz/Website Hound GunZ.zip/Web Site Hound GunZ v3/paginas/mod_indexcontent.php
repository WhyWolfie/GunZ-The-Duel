<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<?
if($_GET['sub'] == "announcement"){
    $res = mssql_query("SELECT * FROM indexcontent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="436">
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											Escrito pela equipe <b>Hound Duel</b>, <?=$a['Date']?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<?=$a['Text']?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
}else{
    $res = mssql_query("SELECT * FROM indexcontent WHERE ICID = '".clean($_GET['id'])."'");
    $a = mssql_fetch_assoc($res);
    ?>
    <div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="7">&nbsp;</td>
											<td width="436">
											<img border="0" src="img/imagens/updatenotes.png" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											Submitted By <b><?=$a['User']?></b>, <?=$a['Date']?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<?=$a['Text']?></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<center>
											&nbsp;</center>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?}?>
