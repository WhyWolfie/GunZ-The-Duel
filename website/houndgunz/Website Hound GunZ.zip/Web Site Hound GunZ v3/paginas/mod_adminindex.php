<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<?
include "authadmin.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Essa pagina � apenas para membros da equipe.","index.php");
}

?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<center><form method="GET" action="index.php?do=admin"><table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="clanranking.jpg" height="31" width="195" style="background-image: url('images/adminpanel.jpg')">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								<table border="0" style="border-collapse: collapse" width="189" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<input type="radio" value="rzadditem" checked name="do">Item a Loja Donator<br>
									        <input type="radio" name="do" value="evadditem">Item a Loja Ev<br>
									        <input type="radio" name="do" value="addcoin">Doar Coins<br>
                                                                                <input type="radio" name="do" value="addecoin">Doar EvCoins<br>
										<input type="radio" name="do" value="ADD-noticia.shanks">Add Noticia<br>
										<input type="radio" name="do" value="accountlist">Lista de Contas<br>
										<input type="radio" name="do" value="adminlist">Lista Admin<br>
										<input type="radio" name="do" value="banlist">Lista de Banidos<br>
										<input type="radio" name="do" value="normallist">Lista normal<br>
										<input type="radio" name="do" value="Silencelist">Silence List<br>
                                                                                <input type="radio" name="do" value="charnamelog">Charname change List<br>										<input type="radio" name="do" value="ipbanuser">Ban Ip<br>
										<input type="radio" name="do" value="muteuser">Mute User<br>
&nbsp;</td>
										<td width="8">&nbsp;</td>
									</tr>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="171">
										<p align="center">
										<input type="submit" value="Go" name="submit"></td>
										<td width="8">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg" width="189">
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22"></td>
							</tr>
							</table></form>
<p>&nbsp;</p>

							
