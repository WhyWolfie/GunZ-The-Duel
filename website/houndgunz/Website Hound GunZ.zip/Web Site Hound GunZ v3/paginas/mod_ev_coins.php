<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<h1>Trocar Pontos Cw</h1>
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

		</td>									</td>
          <td width="435"><div align="left">
            <p>&nbsp;</p>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>
<span style="color:#ffffffff; background: transparent url(http://tinyurl.com/outgum)"></u></span></a>


<center>
<u>Trocar pontos CW - Hound Gunz</u>
<?
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);
$etapa22 = Filtrrar($_GET["etapa"]);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, para acessar esta pagina voce precisa estar logado!");
}else{

if($etapa22 == 0){
?>
<form id="ev_coins" name="ev_coins" method="post" action="index.php?do=ev_coins&etapa=1"><br>
Personagem:
<select name="cid" class="text">
<?
$c = mssql_query("SELECT CID,NAME FROM CHARACTER WHERE AID = '$aid22' AND DeleteFlag = 0");

while($array = mssql_fetch_row($c))
{
	echo '<option value="'.$array[0].'">'.$array[1].'</option>';
}
?>
</select><br><br>
<input type="submit" name="ev_coins" value="Proximo ->" />
</form>
<?
}

if($etapa22 == 1){

$cid22 = Filtrrar($_POST["cid"]);

$busca1 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid22'");
$busca2 = mssql_fetch_row($busca1);

if (!(isset($busca2[0])))

{
die ("<br> <br> Este personagem nao pertence a nenhum clan.");
}else{

$_SESSION["CID"] = $cid22;
echo '
<br><br><font color=red>Aten&ccedil;&atilde;o:</font> A cada 2 pontos &eacute; o que vale a 1 EV Coins!<br><br>
<form id="ev_coins" name="ev_coins" method="post" action="index.php?do=ev_coins&etapa=2">';
echo "Ol&aacute; $login22 voc&ecirc; tem $busca2[0] pontos com o personagem selecionado para trocar em EV Coins.<br><br>";
echo "Quantos pontos deseja trocar?<br>";
echo '
<input type="text" id="pontos" value="'.$busca2[0].'" class="log_field" size="3" name="pontos" value="" maxlength="3"><br><br>';
echo '
<input type="submit" name="ev_coins" value="Trocar" />';
echo '</form>';
}
}

if($etapa22 == 2){

$pontos = Filtrrar($_POST["pontos"]);
$cid23 = Filtrrar($_SESSION["CID"]);

$busca3 = mssql_query("SELECT ContPoint FROM ClanMember WHERE CID = '$cid23'");
$busca4 = mssql_fetch_row($busca3);

if($busca4[0] < $pontos){
echo "<br><br>Voc&ecirc; n&atilde;o pode trocar, pois voc&ecirc; possui $busca4[0] pontos e quer trocar por $pontos EV Coins.";
}else{

if ( !is_numeric($cid23) )
{
echo "ID do personagem editado";
die();
}

if ( !is_numeric($pontos) )
{
echo "O n&uacute;mero de HG Coins precisa ser um n&uacute;mero";
die();
}

if ($pontos == 0)
{
echo "N&atilde;o ha necessidade de comprar 0 EV Coins";
die();		
}

if($pontos < 1)
{
echo "Quer ficar com Coins negativos?";
die();
}

$divisao = $pontos / 2;

mssql_query("update Login set EvCoins=EvCoins +$divisao where AID='$aid22'");
mssql_query("update ClanMember set ContPoint=ContPoint -$pontos where CID='$cid23'");
echo "Troca realizada com sucesso!";


}

}

}
?>
</center>

       
         
                      </table>
                    </div>


         
         
        </table>
      </div>
    <tr>
      <td background="img/imagens/cont_top.jpg" height="27"></td>
    </tr>
  </table>
</div>
