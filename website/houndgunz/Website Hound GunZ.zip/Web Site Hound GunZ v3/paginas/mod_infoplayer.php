<?
//Coded by Charmape ;D
?>
<?
    $cid = antisql($_GET['id']);
if(!is_numeric($cid)){
msgbox("Nao disponivel","index.php");
exit();
}
    $res = mssql_query("SELECT * FROM Character WHERE CID = $cid");
    $char = mssql_fetch_assoc($res);
	$num_rows = mssql_num_rows($res);

if($num_rows < 1){
msgbox("Esta conta nao existe","index.php");
exit();
}

    $res2 = mssql_query("SELECT * FROM Character a, Account b WHERE a.AID=b.AID AND CID = $cid");
    $char2 = mssql_fetch_assoc($res2);

	if ( $char2['UGradeID'] == "253" || $char2['UGradeID'] == "252" || $char2['UGradeID'] == "254" || $char2['UGradeID'] == "255"){
    msgbox("Voc� n�o pode ver perfil de membros da staff.","index.php");
exit();
	}
	if ( $char2['DeleteFlag'] != "0"){
    msgbox("Voc� n�o pode ver isso..","index.php");
exit();
	}
	
    $res3 = mssql_query("SELECT * FROM ClanMember WHERE CID = '".$char['CID']."'"); 
    $clan = mssql_fetch_assoc($res3);
    $res4 = mssql_query("SELECT * FROM Clan WHERE CLID = '".$clan['CLID']."'"); 
    $claninfo = mssql_fetch_assoc($res4);

    if($claninfo == "")
       $claninfo = "-"; 

    
    $data = explode("/", $char2['RegDate']);
    $mes = $data[1];
    $dia = $data[0];
    $ano = $data[2];
    $data = ( isset($dia) && isset($mes) && isset($ano) ) ? $dia."/".$mes."/".$ano : "";

?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="490" bordercolor="#000000">
								<tr>
									<td background="image/content_bar.jpg" height="24" style="background-image: url('image/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Char Info</font></b></td>
								</tr>
                          <tr>
                            <td  bgcolor="#232129" height="35" width="488" class="Estilo2" align="center">
                                <?=FormatCharName($char['CID'])?></td>
                          </tr>
                          <tr>
                            <td bgcolor="#232122" class="Estilo1" align="center" valign="top"><table width="450" border="0" align="center" cellpadding="0" cellspacing="0">
                              <tr>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Personal Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Nome:</td>
                                    <td align="left" class="estilo1"><?=$char2['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Sexo:</td>
                                    <td align="left" class="estilo1"><?=$char2['Sex']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Idade:</td>
                                    <td align="left" class="estilo1"><?=$char2['Age']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Rank:</td>
                                    <td align="left" class="estilo1"><?
                                                    switch ( $char2['UGradeID'] ){
                                                        case "0";
                                                        $ugradeid = "Membro";
                                                        break;
                                                        case "2";
                                                        $ugradeid = "Event Winner";
                                                        break;
                                                        case "104";
                                                        $ugradeid = "Chat Banned";
                                                        break;
                                                        case "252";
                                                        $ugradeid = "GM";
                                                        break;
							case "253";
                                                        $ugradeid = "Bannido";
                                                        break;
							case "254";
                                                        $ugradeid = "Developer";
                                                        break;
							case "255";
                                                        $ugradeid = "Admin";
                                                        break;
                                                    } echo $ugradeid;

                                                        ?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Pais</td>
                                    <td align="left" class="estilo1"><?=$char2['Country']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Comecou a Jogar: </td>
                                    <td align="left" class="estilo1"><?=$char2['RegDate']?></td>
                                  </tr>
                                </table></td>
                                <td align="center" valign="top"><table width="220" border="0" align="center">
                                  <tr>
                                    <td colspan="2" align="center" class="estilo1">Character Info</td>
                                  </tr>
                                  <tr>
                                    <td width="125" align="left" class="estilo1" height="18"></td>
                                    <td width="135" align="left" class="estilo1"></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Nome:</td>
                                    <td align="left" class="estilo1"><?=$char['Name']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Level:</td>
                                    <td align="left" class="estilo1"><?=$char['Level']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Ranking:</td>
                                    <td align="left" class="estilo1"><?=$char['Ranking']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Exp:</td>
                                    <td align="left" class="estilo1"><?=number_format($char['XP'],0,'','.');?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Kill/Death:</td>
                                    <td align="left" class="estilo1"><?=GetKDRatio($char['KillCount'], $char['DeathCount'])?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1">Clan:</td>
                                    <td align="left" class="estilo1"><a href="index.php?do=claninfo&id=<?=$claninfo['CLID']?>"><?=$claninfo['Name']?></a></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Criado: </td>
                                    <td align="left" class="estilo1"><?=$char['RegDate']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Ultimo Login: </td>
                                    <td align="left" class="estilo1"><?=$char['LastTime']?></td>
                                  </tr>
                                  <tr>
                                    <td align="left" class="estilo1" height="18">Tempo de Jogo: </td>
                                    <td align="left" class="estilo1"><?=$char['PlayTime']?> Segundos</td>
                                  </tr>
                                </table></td>
                              </tr>
                            </table>

                          </tr>
</table>
						</div>
						</td>
					</tr>
				</table>