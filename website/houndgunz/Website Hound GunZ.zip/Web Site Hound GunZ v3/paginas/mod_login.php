﻿<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<?
$show =1;
//Check if is logued
if(!function_exists("ShowResetPwdForm")){
    function ShowResetPwdForm(){
        if(!$_SESSION['AID'] == ""){re_dir("index.php");}
        if($_POST['submit'] == ""){
            ?>
            					<form name="pwd" method="POST" action="?do=login&action=resetpwd"><div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="9">&nbsp;</td>
											<td width="436" colspan="3">
										
	<center>Página desativada!</center>
										</tr>
										</table>							</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


            <?
            }elseif ($_POST['submit'] == "Step 2"){
                $userid = clean($_POST['userid']);
                if($userid == ""){
                    msgbox("Please enter a User ID","?do=login&action=resetpwd");
                }
                $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$userid'");
                if (mssql_num_rows($res) == 0){
                    msgbox("The user ".ucfirst($userid)." does not exist.","?do=login&action=resetpwd");
                }
                $_SESSION['ResetPwdUser'] = $userid;
                $info = mssql_fetch_assoc($res);
                ?>

                <form name="pwd" method="POST" action="?do=login&action=resetpwd"><div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="14">&nbsp;</td>
											<td width="436" colspan="3">
										
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
                <?
                   }elseif ($_POST['submit'] == "Step 3"){
                        $sa = clean($_POST['sa']);
                        $mail = clean($_POST['email']);
                        $res = mssql_query_logged("SELECT * FROM Account WHERE Email = '$mail' AND sa = '$sa'");
                        if(mssql_num_rows($res) == 1){
                            ?>
                            									</tr>
										</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>

                            <?
                            
                        }
                    }








                     }}

//Logout
switch ($_GET['action']) {
    case "logout";
        $user = Clean($_SESSION['UserID']);
        $user = ucfirst($user);
        unset($_SESSION['AID']);
        unset($_SESSION['WarGunZCoins']);
        unset($_SESSION['EventCoins']);
        unset($_SESSION['UGradeID']);  
        setcookie ("Nolife_xLogin_usr", "", time() - 3600);
        setcookie ("Nolife_xLogin_pwd", "", time() - 3600);
        echo "<body bgcolor='#000000'><script language='Javascript'> document.location = 'index.php';alert('$user Você foi deslogado.'); </script>";
        break;
    case "resetpwd";
        ShowResetPwdForm();
        $show =0;
    break;
}

if(!$_SESSION['AID']== ""){
    echo "<script language='Javascript'> document.location = 'index.php';alert('Você ja esta logado!'); </script>";
}


if (isset($_POST['submit']) and $show ==1){
    $user = clean($_POST['userid']);
    $pwd = Clean($_POST['pasw']);
    $sql = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."' AND Password = '".$pwd."'");
    if (mssql_num_rows($sql) == 1){
        $data = mssql_fetch_assoc($sql);
        $_SESSION['AID'] =  $data['AID'];
        $_SESSION['UserID'] = ucfirst($user);
        $_SESSION['WarGunzCoins'] = $data['WarGunzCoins'];
        $_SESSION['EventCoins'] = $data['EventCoins'];
        //---
        $res2 = mssql_query_logged("SELECT * FROM Account WHERE AID = '".$data['AID']."'");
        $aData = mssql_fetch_assoc($res2);
        $_SESSION['UGradeID'] = $aData['UGradeID'];
        if($_POST['cookie'] == "ON"){
            setcookie("Nolife_xLogin_usr", $user, time()+60*60*24*100);
            setcookie("Nolife_xLogin_pwd", md5("Nolife_xc_".$data['Password']), time()+60*60*24*100);
        }else{
            setcookie ("Nolife_xLogin_usr", "", time() - 3600);
            setcookie ("Nolife_xLogin_pwd", "", time() - 3600);
        }
        header("Location: index.php");
    }else{
        echo "<body bgcolor='#000000'><script language='Javascript'> alert('Login ou senha incorretos!');document.location = '?do=login'; </script>";
    }
}
if ($show ==1){
?>
<form name="reg" method="POST" action="?do=login&header=1"><body bgcolor="#323232">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="12">&nbsp;</td>
											<td width="436" colspan="2">
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<font color="#FF0000" face="Tahoma">
											<b><font size="2">
											<?=@$error ?></font></font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208" valign="middle" align="right">
											Login:&nbsp;</td>
											<td width="226" valign="middle">
											<input type="text" name="userid" size="20" class="login"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208" align="right">
											Senha:&nbsp;</td>
											<td width="226">
											<input type="password" name="pasw" size="20" class="login" style="background-image: url('img/imagens/passwordbg.jpg')"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="208">&nbsp;
											</td>
											<td width="226">
											<input type="checkbox" name="cookie" value="ON" checked>&nbsp;Manter-me logado</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<p align="center">
											<font color="#BCBCBC">&nbsp;
											<center>
											<a href="?do=register">
											<center>Registre-se!</a></font> |<a href="?do=donator"> Realize uma Doação</a></font></td>
											<td width="8">&nbsp;</td>
			</center>							</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<p align="center">
		<center>									<input type="submit" value="Logar »" name="submit"></td>
											<td width="8">&nbsp;</td>
			</center>							</tr>
										<tr>
											<td width="434" height="24" colspan="2">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>

<?
}
?>
