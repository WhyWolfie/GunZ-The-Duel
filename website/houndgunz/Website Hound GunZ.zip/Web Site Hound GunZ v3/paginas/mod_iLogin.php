﻿<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<?
if ($_SESSION['AID'] == ""){
?>

<table class="tablelogin" >
  <tbody>
    <tr>
   
    <td>
       	<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>



								<form method="POST" action="?do=login&header=1" name="login"><br>
         						<input class="input" type="text" name="userid" ><br>
           						<input class="input" type="password" name="pasw"  ><br>
           						<input type="submit" class="logar" value="Logar" name="submit"><br>
         						<input type="checkbox" name="cookie" value="ON" checked>&nbsp;Manter-me logado<br>
          		<br>				<a href="?do=register">Registre-se! |<a href="?do=donator"> Realize uma Doação</a></font></a><br>
								</form>

<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);

$busca1 = mssql_query_logged("SELECT UGradeID FROM Account WHERE AID = '".$_SESSION['AID']."'");
$busca2 = mssql_fetch_row($busca1);
?>





									        Seja bem vindo <b><font color="#FFFFFF"><?=$_SESSION['UserID']?>!</font></b><br>
										
                                                                                                                            <?
                                                                                if($busca2[0] == 255 OR $busca2[0] == 254){
                                                                                ?>


                                                                                <?
                                                                                 }
                                                                                 ?>
                                                     
														HG Coins:&nbsp;<font color="#FFFFFF"><?=$d['RZCoins']?></font><br>
														EV Coins:&nbsp;<font color="#FFFFFF"><?=$d['EVCoins']?></font><br>
           <a href="?do=login&action=logout&header=1">Sair »</a><br><br>       
           
<h1>Painel do Usuário</h1>
  <img src="img/imagens/fita.png" /> <br>
<a href="?do=painelclan">• Painel de Clan</a><br>
                                <a href="?do=nick_name">• Trocar Nick</a><br>
                                <a href="?do=ev_coins">• Trocar Pontos Cw</a><br>
                              <a href="?do=jjang">• Comprar JJang</a><br>
                                <a href="?do=color">• Comprar Name Color</a>
                             


    <?
}
?>
      </td>
 
    </tr>
  </tbody>
</table>

