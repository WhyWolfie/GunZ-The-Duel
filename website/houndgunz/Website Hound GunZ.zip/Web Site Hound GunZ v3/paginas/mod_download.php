<?
//Coded by Charmape ;D
?>
<?
include "config.php";
?>
<body>
<h1>Download</h1>
<table style="width: 400px; height: 0px; border:0; text-align: left; margin-left: auto; margin-right: auto;"
 >
  <tbody>
    <tr>
      <td style="border:0;" colspan="4" align="center"></td>
    </tr>
    <tr>
      <td style="border:0;" align="left"
 width="248"><strong>Nome</strong></td>
      <td style="border:0;" align="left"
 width="236"><strong>Tamanho</strong></td>
      <td style="border:0;" align="left"
 width="358"><strong>Descri&ccedil;&atilde;o</strong></td>
      <td style="border:0;" align="left"
 width="250"><strong>Link</strong></td>
    </tr>
    <tr
 onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#ececec', '#ececec', false)">
      <td style="border:0;" align="left" width="248">Jogo Completo</td>
       <td style="border:0;" align='left' width="236" ><?=$down1tam?></td>
        <td style="border:0;" align='left' width="358" ><?=$down1?></td>
        <td style="border:0;" align='left' width="250" ><a href="<?=$down1link?>" target="_blank">
		Baixar agora</a></td>
    </tr>
    <tr
 onmouseover="MM_effectHighlight(this, 700, '#ffffff', '#ececec', '#ececec', false)">
      <td style="border:0;" align="left" width="248">Patch Jogo</td>
      <td style="border:0;" align='left' width="236" ><?=$patchtam?></td>
        <td style="border:0;" align='left' width="358" ><?=$patch?></td>
        <td style="border:0;" align='left' width="250" ><a href="<?=$patchlink?>" target="_blank">
		Baixar agora</a></td>
    </tr>
    
    <tr align="center">
   <center>   <td style="border:0;" colspan="4"><img
 style=" margin-top:10px; width: 500px; height: 230px; border:0;"
 src="img/imagens/controls.gif"></center></td>
    </tr>

  </tbody>
</table>
</body>
