﻿<?
//Coded by Charmape ;D
?>

<action="index.php?do=rzitemshop&sub=buyitem">
<?php ("protecao/protect.php");?>
<html>
<head>
<body>
<h1>Selecione Sua Opção</h1>
<ul>
<li class="selecione"><a href="index.php?do=rzitemshop&sub=listallitems&expand=1&type=1"><img src = "img/imagens/custom.jpg"></a></li>
<li class="selecione"><a href="index.php?do=evitemshop&sub=listallitems&expand=1&type=1"><img src = "img/imagens/evento.jpg"></a></li>
</ul>
</body>
<head>
</html>
