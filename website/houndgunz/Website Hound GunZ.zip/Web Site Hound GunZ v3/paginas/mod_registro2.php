﻿<?
//Coded by Charmape ;D
?>

<h1>Oops!</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
<center>Voc&ecirc; j&aacute; esta registrado e logado.<br> Para criar outra conta voc&ecirc; deve deslogar clicando no botão <a href="index.php?do=login&action=logout&header=1"><font color="#FFFFFF">Sair</font>.</a></center>


    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
