<?
//Coded by Charmape ;D
?>

<style>
.lt_box_users{ 
}
.lt_box_users a{ text-decoration:none;  }
.lt_box_topicthreads{  width:150px; height:5px; list-style:decimal;  float:left; border:none;    }
.lt_box_topicthreads tr{ border:1px solid #FFF;}
 
 .li{ width: 228px; list-style:none; border-bottom:#FFF solid 1px; padding:2px;border-bottom: 1px solid #333333;}
 .lt_box_topicthreads a{text-decoration:none; height:5px;  }

 

</style>

<?
//Script De Ranking Desenvolvido Por Gaspar ;D

$res = mssql_query("SELECT top 10 AID, Name, Level FROM Character where (Level>=1) order by Level desc");

while($item = mssql_fetch_row($res))
{

//Color Nicks By:Gaspar

$buscanome2229 = "select UGradeID from Account WHERE AID = '$item[0]'";
$resultado4449 = mssql_query($buscanome2229);
$result229 = mssql_fetch_array($resultado4449);

if($result229[0] == "0" OR $result229[0] == "2" OR $result229[0] == "3" OR $result229[0] == "4" OR $result229[0] == "5" OR $result229[0] == "6" OR $result229[0] == "7" OR $result229[0] == "8" OR $result229[0] == "9"){

switch($result229[0]) {
	case 255: $color = "<font color=#00FFFF>"; break;
	case 254: $color = "<font color=#00EE00>"; break;
        case 253: $color = "<font color=gray>"; break;
        case 2: $color = "<font color=Yellow>"; break;
        case 4: $color = "<font color=#8A2BE2>"; break;
        case 5: $color = "<font color=#0000FF>"; break;
        case 6: $color = "<font color=#FF4040>"; break;
        case 7: $color = "<font color=#EE1289>"; break;
        case 20: $color = "<font color=#AB82FF>"; break;
	case 104: $color = "<font color =red>(Chat Block)</font>"; break;
}

?>

                            	<li class="li">
   	  <div class="lt_box_topicthreads">
                                   	<a href="?kog=infoplayer&NICK=<?=$item[1]?>"><?=$color?><?=$item[1]?></font></a></div>
<div class="lt_box_users">
                                    	<?=$item[2]?>
                                    </div>
                                  <div class="right_col_box_devider"></div>
                                </li>
                                <p>
                                  <?
}
}
?>
                                </p>
                                <p>&nbsp;</p>
                            	
