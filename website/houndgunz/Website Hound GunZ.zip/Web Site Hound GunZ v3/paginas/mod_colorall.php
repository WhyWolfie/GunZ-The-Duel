<?
//Coded by Charmape ;D
?>
<center>
<script>
function click() {
if (event.button==2||event.button==3) {
oncontextmenu='return false';
}
}
document.onmousedown=click
document.oncontextmenu = new Function("return false;")
</script> 
<?
if ($_SESSION['AID'] == ""){
    re_dir("Index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
</head>

	
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
<font color="#CAFF70"><center>Name Colors</center>
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="4">&nbsp;</td>
										  <td width="8">&nbsp;</td>
                            <td></td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div >
<text align="center">
<a href="index.php?do=color"><font color="#FFFFFF"><center>Name Color Normal</center></a><br> <a href="index.php?do=color3"><font color="#6C7B8B"><center>Name Color Gradiente</center></center></a><br> <a href="index.php?do=color4"><font color="#97FFFF"><center>Name Color </font><font color="#CD7F32"> Muda</font> <font color="#7B68EE">de</font> <font color="#4156C5">Cor</a><br><br> <a href="index.php?do=color5"><font color="#FF4040">Name Color Especial</a></center>
											  </div>
											  <div align="center"></div>
                            </td>
                            <td></td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
                            <td></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	