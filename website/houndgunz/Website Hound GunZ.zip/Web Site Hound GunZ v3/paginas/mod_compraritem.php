<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<table style="text-align: left; width: 450px; height: 60px; border:0;">
  <tbody>
    <tr>
      <td style="border:0; ">&nbsp;</td>
    </tr>
    <tr align="center">
      <td style="border:0;"><span style="font-weight: bold;">Para
comprar item voc&ecirc; precisa esta logado.</span><br
 style="font-weight: bold;">
      <span style="font-weight: bold;">Por favor logue-se.</span></td>
    </tr>
  </tbody>
</table>

