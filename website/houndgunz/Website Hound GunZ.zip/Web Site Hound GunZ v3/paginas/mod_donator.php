﻿<?
//Coded by Charmape ;D
?>
<?php ("protecao/protect.php");?>
<h1>Doação</h1>
<div id="doac">
<p><a href="index.php?do=index1"><b><center>[DADOS PARA DOAÇÃO]</center></b></a></p>
<br></br>
<p>Ainda bem que você decidiu dar uma olhada nas doações e,   eventualmente, apoiar-nos. Nesta seção você vai encontrar algo   relacionado a doações, o que é, por que doar, como fazer uma doação e   aquilo que pode ser recompensado após sua doação.</p>
<p> <strong>Como fazer a Doação?</strong><br />
  Usando o PagSeguro ou PayPal você poderá fazer pagamentos rápidos e de forma fácil.<br />
  O pagamento pode ser feito através de Boleto, Transferência Bancária,   Cartão de Crédito ou  Transferência de Saldo, o PagSeguro é uma ótima opção, e seus créditos   chegaram rápido, sem necessidade de confirmar nada, apenas Clique no   Banner, selecione o plano, efetue o pagamento e espere sua conta ser   créditada. </p>
<p><strong>Doações ... O que é? E por que precisamos delas?</strong><br />
  As doações são voluntariamente, sem contrapartida de retorno. Elas   estão aqui para nos ajudar a pagar as contas mensais de nossos   servidores. Sem elas e sem seu apoio, nós não seríamos capazes de ter   recursos para pagar as contas, mensalmente, e nosso servidor não estaria   aqui, ou pelo menos, não seria tão popular e bem sucedido, pois nós não   poderiamos ter um servidor capaz de suportar muitos jHGadores sem   quedas e lags.</p>
<p><strong>Acordo de Doações<br />
</strong>Ao enviar um donativo para o Hound Gunz, você concorda que não   têm direito a receber qualquer coisa de nós, porém, uma recompensa será   dada à aqueles que doam como um agradecimento por seu apoio contínuo.   Esta forma de doação é completamente voluntária, como explicado   anteriormente, e é usada para melhorar nosso servidor.</p>
<p><strong>Ao fazer uma doação você concorda com os termos apresentados nas declarações seguintes:</strong><br />
  <em>1. Você não vai tentar recuperar o sua doação abrindo disputa.<br />
    2. Você entende que se trata de uma doação voluntária e não é   reembolsável ou discutível, em qualquer momento ou por qualquer motivo.<br />
    3. Qualquer tentativa de fraude ao sistema de doação vai levar a remoção permanente de sua conta de nossa rede.<br />
    4. Ser um doador não lhe dá nenhum privilégio. Você será ameaça, tal como qualquer outro jHGador.<br />
    5. Se seus itens em resposta a uma doação foi roubado / perdido /   extraviado / sumiu /entre outros, não seremos responsáveis por sua   recuperação.<br />
    6. Se você não concordar com esses termos, não nos envie uma doação. Ao enviar uma doação, você concorda com este acordo.</em><br />
</p>
<p>Depois de ter lido, entendido e concordado com o nosso acordo, você pode enviar a sua doação. Clique no botão abaixo para doar.<br />
  Selecione a forma de pagamento que mais lhe agrada </p>

<p><br />
  <strong>Prazo de entrega</strong><br />
  <br />
  No máximo dois dias úteis após a confirmação do pagamento, finais de semana e feriado não são dias úteis.</p>
<p id="obs">Obs.: Planos em Promoção</p>
<p><strong>Relação      de Planos</strong></p>
<table border="0" cellpadding="2" cellspacing="2" width="521">
  <tbody>
    <tr>
      <td width="74"><strong>Planos</strong></td>
      <td width="232"><strong>Quantidade </strong></td>
      <td width="195"><strong>Valor </strong></td>
    </tr>
    <tr>
      <td>Plano 1</td>
      <td>12.500 HG Coins + 10 E Coins</td>
      <td>10,00 R$</td>
    </tr>
    <tr>
      <td>Plano 2</td>
      <td>25.000 HG Coins         + 20 E Coins</td>
      <td>20,00 R$</td>
    </tr>
    <tr>
      <td>Plano 3</td>
      <td>45.000 HG Coins + 30 E Coins</td>
      <td>30,00 R$</td>
    </tr>
    <tr>
      <td>Plano 4</td>
      <td>60.000 HG Coins + 40 E Coins</td>
      <td>40,00 R$</td>
    </tr>
    <tr>
      <td>Plano 5</td>
      <td>75.000 HG Coins + 60 E Coins</td>
      <td>50,00 R$</td>
    </tr>
    <tr>
      <td>Plano 6</td>
      <td>95.000 HG Coins + 75 E Coins</td>
      <td>60,00 R$</td>
    </tr>
    <tr>
      <td>Plano 7</td>
      <td>125.000 HG Coins + 100 E Coins</td>
      <td>80,00 R$</td>
    </tr>
    <tr>
      <td>Plano 8</td>
      <td>160.000 HG Coins + 150 E Coins</td>
      <td>100,00 R$</td>
    </tr>
  </tbody>
</table>
<p> </p>
<p><strong>F.A.Q.</strong><strong><br />
  </strong><br />
  <strong><em>Há alguma chance de não receber-mos os créditos ?</em></strong><em><br />
    * Não, após o pagamento ser confirmado você receberá seus créditos.</em></p>
<p><em><strong>Como saber se o pagamento foi confirmado?</strong><br />
  * Toda ação que ocorre no PagSeguro ou no PayPal o comprador é   informado via e-mail. Você receberá um e-mail informando que seu   pagamento foi confirmado.<br />
  <br />
  <strong>Os itens comprados na WebStore possui algum tempo para expirar ? </strong><br />
  * Os Itens podem ser válidos por 15 dias, 30 dias, ou vitalícios. Antes de comprar, verifique a duração<br />
  <br />
  <strong>Porquê eu devo contribuir ? </strong><br />
  * Além de adquirir um visual todo especial e se destacar entre    os demais,	estará contribuindo para que o servidor permaneça sempre    Online contando	com um ótimo serviço. </em><br />
  <br />
  O Hound Gunz é uma organização sem fins lucrativos, portanto, com   exclusão  de qualquer responsabilidade jurídica, civil ou fiscal, os   serviços  prestados aqui são todos gratuitos, estes são apenas   benefícios para as pessoas que escolhem  nos apoiar, lembrando mais uma   vez que não é um serviço pago, esses são privilégios para quem  faz   doações.<br />
</p>
</div>
