<?
//Coded by Charmape ;D
?>
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="images/cont_up.png">&nbsp;</td>
    </tr>
    <tr>
      <td background="images/cont_bg.png"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											<img border="0" src="images/inf/stafflist.png" width="413" height="18"></td>
 
<br><br>
<?
//Name color By:SayntPark '-'

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, Para acessar esta pagina voce prescisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
Voc� ir� gastar <font color=red>50</font> HG Coins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="5">Gradiente Vermelho</option>
<option value="6">Gradiente Verde</option>
<option value="7">Gradiente Azul</option>
</select>
<br><br>
<font color="#8968CD"> Gradiente Vermelho</font><br><br>
<font color="#FF6347"> Gradiente Verde</font><br><br>
<font color="#FFFF00"> Gradiente Azul</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color2" type="submit" id="login" align="right" value="Comprar">
</form>
<br>
<span style="color:#CD2990; background: transparent url(http://tinyurl.com/outgum)"><b>Name color - HoundGunZ</b></span></a><br><br>

<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Voc� comprou Admin com sucesso!!  Brinks HAHA";
die ();  

}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 50) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voc� n�o tem  HG Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -50 where AID='$aid22'");
echo "Compra realizada com sucesso! Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Acesse site.aulagunz.com.br";
}
}
}


$logfile = fopen("Log NameColor.txt","a+");
$logtext = "IP  :{$_SERVER['REMOTE_ADDR']} Aid :{$aid22} Comprou NameColor. \r\n";
fputs($logfile, $logtext);
fclose($logfile);



?>

          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="images/cont_top.png" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


