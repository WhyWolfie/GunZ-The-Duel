<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<h1>Painel do Usu�rio</h1>
  <img src="img/imagens/fita.png" /> 
<a href="index.php?do=painelclan">� Painel de Clan</a><br>
                                <a href="index.php?do=nick_name">� Trocar Nick</a><br>
                                <a href="index.php?do=cw">� Trocar Pontos Cw</a><br>
                              <a href="index.php?do=jjang">� Comprar JJang</a><br>
                                <a href="index.php?do=color">� Comprar Name Color</a>
                             

