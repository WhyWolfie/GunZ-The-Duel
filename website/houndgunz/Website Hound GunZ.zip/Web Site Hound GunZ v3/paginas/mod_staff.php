﻿<?
//Coded by Charmape ;D
?>

<h1>INTEGRANTES DA EQUIPE</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
          <td width="435"><br><center><u>Fundadores</u></center><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Charmape
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Blasper
<br><br><center><u>Administradores</u></center><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Pablo
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Mathbg
<br><br><center><u>Game Masters</u></center><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Mindsujiny
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• Soft
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• //
<br><br><center><u>Moderadores</u></center><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• // - Moderador Game<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• // - Moderador Fórum<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;• // - Moderador Fórum


    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
