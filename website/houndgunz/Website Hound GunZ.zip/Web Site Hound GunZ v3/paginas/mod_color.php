<?
//Coded by Charmape ;D
?>
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
<h1>Comprar name color</h1>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
 
<br><br>
<?
//Name color by Charmape ;D

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("!", "from", "select", "insert", "where", "show tables", "shutdown", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, para acessar esta p�gina voc� precisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>

<form id="site_Login" name="site_Login" method="post" action="?do=color&step=1">
Voce ira gastar <font color=red>35</font> HG Coins.<br><br>
Selecione a cor de seu nick name:<br><br>
<select name="color222" class="text">
<option value="10">Azul Claro</option>
<option value="11">Lilas</option>
<option value="12">Vermelho</option>
<option value="13">Verde</option>
<option value="14">Azul 50% Opaco</option>
</select>
<br><br>
<font color="#8968CD"> Azul Claro</font><br><br>
<font color="#FF6347"> Lilas</font><br><br>
<font color="#FFFF00"> Vermelho</font><br><br>
<font color="#00CED1"> Verde</font><br><br>
<font color="#00008B"> Azul 50% Opaco</font><br><br>
<input type="hidden" name="color55" value="1">
<input name="color" type="submit" id="login" align="right" value="Comprar">
</form>


<?
}else{
if(isset($_POST[color55]))
{

$color222 = Filtrrar($_POST['color222']);

if($color222 == "255" OR $color222 == "254" OR $color222 == "252"){
    echo "Falhou.";
die ();  

}

$buscanome = "SELECT RZCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 35) 
{
	echo "Desculpe, nao foi possivel realizar sua compra, pois voce nao tem  HG Coins suficientes";
}else{
mssql_query("UPDATE Account SET UGradeID = '$color222' WHERE AID = '$aid22'");
mssql_query("update Login set RZCoins=RZCoins -35 where AID='$aid22'");
echo "Compra realizada com sucesso!<br> Seu nick color ja esta em sua conta basta relogar.<br>";
}
}else{
echo "Acesse www.houndgames.com";
}
}
}





?>

          <tr>
            <td width="435"><div align="left"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>



