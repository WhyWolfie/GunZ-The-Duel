﻿<?
//Coded by Charmape ;D
?>

<?
include "config.php";
include "checkcookie.php";
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
include "protecao/ChecaBanido.php";
include "protecao/ChecaCookies.php";
include "protecao/FuncaoTitulo.php";
?>
<?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<html>
<head>
</head>
<body OnSelectstart="return false" OnContextMenu="return false">
<h1>Bem vindo ao <b><?=$nomeserver?></b>!</h1>
<div align="center">
<object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" name="obj2" width="417" height="76" border="0" id="obj2">
										<param name="movie" value="image/srv_data.swf">
										<param name="quality" value="High">
										<param name="wmode" value="transparent"><param name="BGCOLOR" value="#000000" />
										<embed src="image/srv_data.swf" width="417" height="76" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" name="obj2" quality="High" wmode="transparent" bgcolor="#000000"></object>
									</div></td>
								</tr>
<h1>NOVIDADES</b>!</h1>
<div align="center"><?php include "slide/slide.html"?></div>
<div id="att"">


   
    <h1>Notícias e Novidades</h1>
        <div id="noticias"><h2> &Uacute;ltimas
Not&iacute;cias </h2>


 
     <? $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
      while($n = mssql_fetch_assoc($res)){ ?>
      <a href="index.php?do=indexcontent&sub=announcement&id=<?=$n['ICID']?>">
      <span class="title"><?=$n['Title']?></span></a>
      <?}?>
   
   
   </div>
   
      <div id="noticias" style=" border-left:1px #333 dotted;"><h2>
&Uacute;ltimas Atualiza&ccedil;&otilde;es </h2>
   
      <? $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
      while($n = mssql_fetch_assoc($res)){?>
      <a href="index.php?do=indexcontent&sub=update&id=<?=$n['ICID']?> ">
	  <span class="title"><?=$n['Title']?></span></a>
      <?}?>
   </div></div>
    <div class="bgultimos">
    <h1>Itens novos do Shop</h1>
<div id="inline"><? include "protecao/Anti_Inject.php" ?>
<?
if(!function_exists("ListLatestItens")){
function ListLatestItens(){


    $res = mssql_query("SELECT TOP 4 * FROM RZCashShop WHERE Opened = '1'");

    ?>

      <?
                                        while($item = mssql_fetch_assoc($res)) {
                                            if ($count == 0) {
                                                $count = 1;
                                                echo " ";
                                                ?>

            <span style="z-index:-1;"><img class="borda" id="borda" src="shop/<?=$item['WebImgName']?>"  width="80" height="80"></span>
            <p class="estilo"><?=$item['Name']?></p>
           <p class="estilo">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></p>
            <p class="estilo">Nível: <?=$item['ResLevel']?></p>
            <p class="estilo">Preço: <?=$item['CashPrice']?></p>
            <a class="comprar" href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>">Comprar Item</a>
               <?
                                            }else{
                                                ?></div>
       <!--   Segunda div -->
          
           <div id="inline">
            <img  class="borda" id="borda" src="shop/<?=$item['WebImgName']?>"  width="80" height="80">
            <p class="estilo"><?=$item['Name']?></p>
         <p class="estilo">Sexo: <?
                                                    switch ($item['ResSex']){
                                                    case "0";
                                                    $sex = "Homem";
                                                    break;
                                                    case "1";
                                                    $sex = "Mulher";
                                                    break;
                                                    case "2";
                                                    $sex = "Todos";
                                                    break;
                                                    } echo $sex;
                                                    ?></p>
            <p class="estilo">Nível: <?=$item['ResLevel']?></p>
           <p class="estilo">Preço: <?=$item['CashPrice']?></p>
            <a class="comprar" href="index.php?do=rzitemshop&sub=details&id=<?=$item['CSID']?>">Comprar Item</a>
                    <?
                                                 $count++;
                                            }
                                        }   ?>    </div>   <br><br><br><br> <h1>Facebook</h1>
<div id="inline"><? include "paginas/mod_scriptfb.php" ?>
         
</div>
</body>
</html>
       <?
    }
}


if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "";
        ListLatestItens();
    break;
}
}

?>



