<?
//Coded by Charmape ;D
?>
<h1>Alterar Nick Name</h1>
<script>
function click() {
if (event.button==2||event.button==3) {
oncontextmenu='return false';
}
}
document.onmousedown=click
document.oncontextmenu = new Function("return false;")
</script> 
<?
if ($_SESSION['AID'] == ""){
    re_dir("Index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
</head>

	
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
	<center>									<tr>
											<td width="4" rowspan="4">&nbsp;</td>
										  <td width="8">&nbsp;</td>
                            <td></td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div align="center">
<?
//Mudan�a de NickName by Charmape ;D

$login22 = clean($_SESSION['UserID']);

$etapa = clean($_GET['etapa']);

$aid22 = clean($_SESSION['AID']);

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
	msgbox("Sem personagens.","index.php");
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?do=nick_name&etapa=1">
                                        
</form>

											  </div>
                                <form name="site_Login" method="post" action="?do=nick_name&etapa=1" id="site_Login">
                                    <p align="center"><center>Selecione o Personagem:<br>
<select name="cid22" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>

<input type="text" id="nick_new" value="Novo Nick" class="log_field" size="16" name="nick_new" value="" maxlength="12"><br><br>

<input type="submit" name="mudar" value="Alterar NickName!" /></p>
                                </form>
<div align="center">
<br><br>

<font color=red>Aten&ccedil;&atilde;o ir&aacute; ser cobrado  20 HG Coins pelo servi&ccedil;o.</font>

<?
}

if($etapa == 1)
{

$cid22 = clean($_POST['cid22']);

$nicknew = clean($_POST['nick_new']);

$query22 = mssql_query("SELECT CID FROM Character WHERE Name = '$nicknew'");

if( mssql_num_rows($query22) < 1 )
{

$buscanome = "SELECT RzCoins FROM Login WHERE UserID='$login22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 20) 
{
	echo "Desculpe, n&atilde;o foi poss&iacute;vel realizar sua compra.<br>";
	echo "Voc&ecirc; n&atilde;o tem HG Coins suficiente.<br>";
	echo "Adiquira mais coins e volte novamente!<br>";
        echo "Obrigado.<br>";
?>
<a href="?do=nick_name">Voltar</a>
<?
}else{

$pattern = "[^a-zA-Z0-9]";
if(ereg($pattern,$nicknew) == TRUE)
{
die('Caracteress nao permitidos');
}

$query1 = mssql_query("UPDATE Character SET Name = '$nicknew' WHERE CID = '$cid22'");
$query2 = mssql_query("UPDATE Login SET RzCoins=RzCoins -20 WHERE UserID='$login22'");

echo "Obrigado, seu nick name ja foi atualizado. Caso esteja no jogo, relogue.";

}

}else{
echo "Desculpe, este nickname ja est� em uso. Por favor escolha outro.";
}

}
?>
</center>
											  </div>
											  <div align="center"></div>
                            </td>
                            <td></td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
                            <td></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	