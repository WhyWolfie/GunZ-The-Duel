﻿<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<h1>Rankings</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
﻿<?
if(!isset($_GET['action']))
{
?>
<style>
.text{ 
color:#bfbfbf;
 background:#000000; 
 width:110px;
  padding:3px;
   border:none;
   border:1px solid #595959;
   font:11px Verdana, Geneva, sans-serif;
   
   } 
</style>
<br>
<div class="box">
<form id="ranking" name="ranking" method="post" action="?do=ranking&action=go">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
 <tr>
  <td>
	<select name="quant" class="text">
	<option value="10">Top 10</option>
	<option value="30">Top 30</option>
	<option value="50">Top 50</option>
	<option value="100">Top 100</option>
	</select>
  </td>
  <td>
	<select name="tipo" class="text">
    <option value="Guilds">Cl&atilde;s</option>
    <option value="clevel">Personagens</option>
	</select>
  </td>
  <td>
	<select name="forma" class="text">
	<option value="DESC">Decrescente</option>
	<option value="ASC">Crescente</option>
	</select>
  </td>
  <td>
  <input type="submit" name="ranking" style="margin:5px 0; cursor:pointer;" value="Gerar Rank!" />
  </td>
 </tr>
</table>
</form>
</div>
<br />
<div id="result"></div><center>
<?
}
else
{
	if($_POST['tipo'] == 'Guilds')
	{
		$res = mssql_query("SELECT TOP ".$_POST['quant']." NAME,POINT,WINS,LOSSES,MASTERCID FROM Clan WHERE Name <> '' ORDER BY Point DESC");
		
		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table">';
		echo '<tr class="table_tr">';
		echo '<td class="table_td">#</td>';
		echo '<td class="table_td">Nome</td>';
		echo '<td class="table_td">Pontos</td>';
		echo '<td class="table_td">Dono do cl&atilde;</td>';
		echo '<td class="table_td">Vitorias / derrotas</td>';
		echo '</tr>';
		
		while($array = mssql_fetch_row($res))
		{
			$x++;
			$master = mssql_fetch_row(mssql_query("SELECT CID,NAME,LEVEL FROM Character WHERE CID = '".$array[4]."'"));
			echo '<tr>';
			echo '<td class="table_td"><b>'.$x.'</b></td>';
			echo '<td class="table_td"><a href="?do=infoclan&CLAN='.$array[0].'">'.utf8_encode($array[0]).'</a></td>';
			echo '<td class="table_td">'.$array[1].'</td>';
			echo '<td class="table_td"><a href="?do=infoplayer&NICK='.$master[1].'">'.utf8_encode($master[1]).'</a></td>';
			echo '<td class="table_td">'.$array[2].' / '.$array[3].'</td>';
		}
		
		echo '</table></center>';
	}

        if($_POST['tipo'] == 'clevel')
        {
	
	$q = mssql_query("SELECT TOP ".$_POST['quant']." Name, Level, XP, KillCount, DeathCount, AID FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP ".$_POST['forma']."");


		echo '<table width="100%" cellpadding="0" cellspacing="0" border="0" class="table">';
		echo '<tr class="table_tr">';
		echo '<td class="table_td">#</td>';
		echo '<td class="table_td">Nome</td>';
		echo '<td class="table_td">Level</td>';
		echo '<td class="table_td">EXP</td>';
		echo '<td class="table_td">Matança/Mortes</td>';
		echo '</tr>';

                while($row = mssql_fetch_row($q)){

$colorzin = mssql_query("SELECT UGradeID FROM Account WHERE AID = '$row[5]'");
$colorzin2 = mssql_fetch_row($colorzin);

//Color By:Gaspar =P

switch($colorzin2[0]) {
	case 255: $color = "<font color=#00FFFF>"; break;
	case 254: $color = "<font color=#00EE00>"; break;
        case 253: $color = "<font color=gray>"; break;
        case 0: $color = "<font color=#212121>"; break;
        case 2: $color = "<font color=Yellow>"; break;
        case 4: $color = "<font color=#8A2BE2>"; break;
        case 5: $color = "<font color=#0000FF>"; break;
        case 6: $color = "<font color=#FF4040>"; break;
        case 7: $color = "<font color=#EE1289>"; break;
        case 20: $color = "<font color=#AB82FF>"; break;
        case 252: $color = "<font color=white>"; break;
	case 104: $color = "<font color =red>(Chat Block)</font>"; break;
}
	
		
		        $x++;
			echo '<font color=white>';
			echo '<tr>';
			echo '<td class="table_td"><b>'.$x.'</b></td>';
			echo '<td class="table_td"><a href="?do=infoplayer&NICK='.$row[0].'">'.$color.''.$row[0].'</font></a></td>';
			echo '<td class="table_td">'.$row[1].'</td>';
			echo '<td class="table_td">'.$row[2].'</a></td>';
			echo '<td class="table_td">'.$row[3].'/'.$row[4].'</td>';
			echo '</font>';

               }
	
	echo '</table>'; }} ?>
</font>


    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
