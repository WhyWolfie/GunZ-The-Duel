﻿<?
//Coded by Charmape ;D
?>
<h1>Comprar JJang</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
<?
//Comprar Jjang by Charmape

// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$aid22 = Filtrrar($_SESSION['AID']);

$busca57 = mssql_query("SELECT EVCoins FROM Login WHERE AID = '$aid22'");
$busca58 = mssql_fetch_row($busca57);

if (!(isset($_SESSION['AID'])))
{
die ("Desculpe, para acessar esta página você precisa estar logado!");
}else{

$step = Filtrrar($_GET['step']);

if ($step == ""){
?>
<center>

<font color="#FFFFFF">Qual utilidade do jjang?</font><br>
- Nada, apenas um adereço para seu personagem.<br><br>

<font color="#FFFFFF">Qual valor?</font><br>
- Para ter um jjang você gastará 40 EV Coins.<br><br>

<a href="?do=jjang&step=1">Comprar</a> - <a href="index.php">Não Comprar</a><br><br>

Você tem um total de <?=$busca58[0]?>
 EV Coins, após fazer essa compra irá sobrar 
<?=$busca58[0]-40?></center>
<?
}else{


$buscanome = "SELECT EVCoins FROM Login WHERE AID='$aid22'";
$resultado = mssql_query($buscanome);
$row1 = mssql_fetch_row($resultado);

if ($row1[0] < 40) 
{
	echo "Desculpe, seus EV Coins não são suficientes!";
}else{
mssql_query("UPDATE Account SET UGradeID = '2' WHERE AID = '$aid22'");
mssql_query("update Login set EVCoins=EVCoins-10 where AID='$aid22'");
echo "Compra realizada, relogue.<br>";
}


}
}




?>

    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
