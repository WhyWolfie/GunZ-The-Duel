﻿<?
//Coded by Charmape ;D
?>

<h1>Informações do Servidor</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
          <td width="435"><div align="center">
            <p>&nbsp;</p>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>

• Loja Donator / Loja Evento
<br>
• Launcher Auto-Updater
<br>
• Custom Mapas & Itens
<br>
• Painel do Usuário
<br>
• Exp: 60x
              </tr>
              <tr>
              </tr>
              <tr>

                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                      </table>
                    </div>
            <p align="center">&nbsp;</p></td>
                <td width="10">&nbsp;</td>


          </tr>
          <tr>
            <td width="435"><div align="center"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>

<h1>Informações de Hardware</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
          <td width="435"><div align="center">
            <p>&nbsp;</p>
            <table width="259" border="0" cellspacing="0" cellpadding="0">
              <tr>

• Virtual Private Server
<br>
• Intel Xeon 2.50GHz
<br>
• 6 GB RAM
<br>
• 99.9% Uptime
<br>
• Conexão 1GBPS UpLink
<br>
• Datacenter EUA<br>
              </tr>
              <tr>
              </tr>
              <tr>

                        <tr>
                          <td width="200">&nbsp;</td>
                          <td width="200">&nbsp;</td>
                        </tr>
                        <tr>
                      </table>
                    </div>
            <p align="center">&nbsp;</p></td>
                <td width="10">&nbsp;</td>


          </tr>
          <tr>
            <td width="435"><div align="center"></div></td>
          </tr>
          <tr>
            <td width="435">&nbsp;</td>
          </tr>
        </table>
      </div></td>
    </tr>
    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>
