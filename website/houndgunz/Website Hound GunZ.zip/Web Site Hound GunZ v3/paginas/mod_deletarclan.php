<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<h1>Deletar Clan</h1>
<center>   
<div align="center">
  <table width="456" border="0" style="border-collapse: collapse">
    <tr>
      <td background="img/imagens/cont_up.jpg">&nbsp;</td>
    </tr>
    <tr>
      <td background="img/imagens/cont_bg.jpg"><div align="center">
        <table border="0" style="border-collapse: collapse" width="454" height="100%">
          <tr>
          </tr>

											</td>
<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />
<center>
<?
$aid22 = clean($_SESSION[AID]);
$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
	msgbox("Sem personagens.","index.php");
die();
}
?>
<form method="post" action="index.php?do=deletarclan">
Selecione o dono do cl&atilde; para deseja deletar ou sair:<br><br>
<select name="dj" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>
<center>Atenc&atilde;o: Esta a&ccedil;&atilde;o &eacute; permanente!</center>
<br><div id="log-b2"><input type="submit" name="saddy" value="DELETAR" /></div>
</form>
<?
if (isset($_POST['saddy']))
{

$noob = clean($_POST['dj']);

$zika = mssql_query("SELECT * FROM Character(NOLOCK) WHERE AID = '{$_SESSION[AID]}' AND CID = '$noob'");

if (mssql_num_rows($zika) == 0 )
        {
	msgbox("Esse char pertence a outra conta.","index.php");
    die();
	}


$query2 = mssql_query("SELECT CLID FROM ClanMember WHERE CID = '$noob'");

if( mssql_num_rows($query2) == 0 )
{
echo "Este personagem n&atilde;o pertence a nenhum cl&atilde;";
die();
}

$query3 = mssql_fetch_row($query2);
$query4 = mssql_query("SELECT MasterCID FROM Clan WHERE CLID = '$query3[0]'");
if (mssql_num_rows($query4) == 1 )
        {

$query5 = mssql_query("SELECT Name FROM Clan WHERE CLID = '$query3[0]'");
$query6 = mssql_fetch_row($query5);

$query7 = mssql_query("DELETE FROM ClanMember WHERE CLID = '$query3[0]'");
$query8 = mssql_query("DELETE FROM Clan WHERE CLID = '$query3[0]'");
if($query7){
	msgbox("Clan deletado com sucesso!","index.php");
    die(); 
}
}

if (mssql_num_rows($query4) == 0 )
        {
$query71 = mssql_query("DELETE FROM ClanMember WHERE CID = '$noob'");
if($query71){
	msgbox("Voc� saiu do seu cl�.","index.php");
    die(); 
}
}
if (mssql_num_rows($query7) == 0 )
        {
	msgbox("Erro no comando fale com algum administrador do<b>Hound GunZ</b>!","index.php");
    die();
}
if (mssql_num_rows($query71) == 0 )
        {
	msgbox("Erro no comando fale com algum administrador do<b>Hound GunZ</b>!","index.php");
    die();
}


}
?>
</center>
    <tr>
      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>


      <td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
    </tr>
  </table>
</div>