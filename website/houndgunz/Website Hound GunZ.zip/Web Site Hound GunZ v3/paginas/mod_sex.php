﻿<?
//Coded by Charmape ;D
?>

<?
include "config.php";
// Funcao para filtrar (Anti-SQL-Injection)
Function Filtrrar($str){
	$caracters = array("'", "!", "from", "select", "insert", "delete", "where", "drop table", "show tables", "DROP", "shutdown", "--", "update", "set");
	$blank = "";
return str_replace($caracters, $blank, $str);
}

$etapa = Filtrrar($_GET['etapa']);

$aid22 = $_SESSION[AID];

if($etapa == "")
{

$query1 = mssql_query("SELECT Name, CID FROM Character WHERE AID = '$aid22' AND DeleteFlag = '0'");

if( mssql_num_rows($query1) < 1 )
{
echo "Você não tem personagens";
die();
}
?>
<form id="site_Login" name="site_Login" method="post" action="?do=sex&etapa=1">
Selecione o Personagem:<br>
<select name="cid42" class="text">

<?
while($busca = mssql_fetch_row($query1))
{
echo '<option value="'.$busca[1].'">'.$busca[0].'</option>';
}
?>

</select><br><br>

Selecione o Sexo:<br>
<select name="sex42" class="text">
<option value="0">Masculino</option>
<option value="1">Feminino</option>
</select><br><br>


<input type="submit" name="logar" value="Alterar Sexo" />

<?
}

if($etapa == 1){

$cid42 = Filtrrar($_POST['cid42']);

$sex42 = Filtrrar($_POST['sex42']);

$query2 = mssql_query("UPDATE Character SET Sex = '$sex42' WHERE CID = '$cid42'");

echo "Sexo Alterado Com Sucesso! Caso esteja no jogo, relogue.";

}
?>
