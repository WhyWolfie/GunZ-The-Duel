﻿<?
//Coded by Charmape ;D
?>

<?
include "protecao/Anti_Inject.php";
include "protecao/SQL_Check.php";
?>

<h1>Registrar Conta</h1>
<?php

$ip = $_SERVER['REMOTE_ADDR'];    
$script = $_SERVER[PATH_TRANSLATED];  
$sql_inject_1 = array(";","'","%",'"'); #Whoth need replace  
$sql_inject_2 = array("", "","","&quot;"); #To wont replace  
$GET_KEY = array_keys($_GET); #array keys from $_GET  
$POST_KEY = array_keys($_POST); #array keys from $_POST  
$COOKIE_KEY = array_keys($_COOKIE); #array keys from $_COOKIE  
/*begin clear $_GET */  
for($i=0;$i<count($GET_KEY);$i++)  
{  
$real_get[$i] = $_GET[$GET_KEY[$i]];  
$_GET[$GET_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_GET[$GET_KEY[$i]]));  
if($real_get[$i] != $_GET[$GET_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: GET\r\n");  
fwrite ($fp, "Value: $real_get[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_GET */  
/*begin clear $_POST */  
for($i=0;$i<count($POST_KEY);$i++)  
{  
$real_post[$i] = $_POST[$POST_KEY[$i]];  
$_POST[$POST_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_POST[$POST_KEY[$i]]));  
if($real_post[$i] != $_POST[$POST_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: POST\r\n");  
fwrite ($fp, "Value: $real_post[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  
/*end clear $_POST */  
/*begin clear $_COOKIE */  
for($i=0;$i<count($COOKIE_KEY);$i++)  
{  
$real_cookie[$i] = $_COOKIE[$COOKIE_KEY[$i]];  
$_COOKIE[$COOKIE_KEY[$i]] = str_replace($sql_inject_1, $sql_inject_2, HtmlSpecialChars($_COOKIE[$COOKIE_KEY[$i]]));  
if($real_cookie[$i] != $_COOKIE[$COOKIE_KEY[$i]])  
{  
fwrite ($fp, "IP: $ip\r\n");  
fwrite ($fp, "Method: COOKIE\r\n");  
fwrite ($fp, "Value: $real_cookie[$i]\r\n");  
fwrite ($fp, "Script: $script\r\n");  
fwrite ($fp, "Time: $time\r\n");  
fwrite ($fp, "==================================\r\n");  
}  
}  

/*end clear $_COOKIE */  
?>
<?
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = clean($_POST['userid']);
    $email = clean($_POST['email']);
    $pw1 = clean($_POST['pw1']);
    $pw2 = clean($_POST['pw2']);
    $country = clean($_POST['country']);
    $sq = clean($_POST['sq']);
    $sa = clean($_POST['sa']);
    $name = clean($_POST['name']);
    //$zip = clean($_POST['zip']);
    //$age = clean($_POST['age']);
    $sex = clean($_POST['sex']);
    //$address = clean($_POST['address']);


        $res = mssql_query_logged("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="E-mail em uso.</br>";
            $er = 1;
        }

        $res = mssql_query_logged("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="Login em uso.</br>";
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            $errorcode.="As senhas não são iguais.</br>";
            $er = 1;
        }

        if($user == ""){
            $errorcode.="Por favor, coloque seu login.</br>";
            $er = 1;
        }

        if($email == ""){
            $errorcode.="Por favor, coloque seu e-mail.</br>";
            $er = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Por favor, coloque sua senha no minímo de 6 caractéres.</br>";
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Por favor, coloque sua senha.</br>";
            $er = 1;
        }

        if($sq == ""){
            $errorcode.="Por favor, coloque a pergunta secreta.</br>";
            $er =1;
        }

        if($sa == ""){
            $errorcode.="Por favor, coloque a resposta secreta.</br>";
            $er = 1;
        }


        if($er == 0){
            $registered = 1;
            mssql_query_logged("INSERT INTO Account (UserID, Cert, Name, Email, UGradeID, PGradeID, RegDate, Country, sa, sq)Values ('$user', NULL, '$name','$email', 0, 0, GETDATE(),'$country', '$sa', '$sq')");
	    $res = mssql_query_logged("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query_logged("INSERT INTO Login ([UserID],[AID],[Password],[RZCoins],[EVCoins])VALUES('$user','$aid','$pw1',150,50)");
			//mssql_query_logged("UPDATE LastAccount SET Last = '$user' WHERE ID = 1");
			// start query invitation code
			
			// end query invitation code
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>

<head>
<meta http-equiv="Content-Language" content="es">
<meta name="generator" content="Namo WebEditor v5.0(Trial)">
</head>

<body bgcolor="#323232">

<form name="reg" method="POST" action="index.php?do=register">					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="34">&nbsp;</td>
											<td width="436" colspan="2">
											</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>
											<td width="289">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
<? echo @$errorbox ?>
										<tr>
											<td width="145">&nbsp;
											</td>
											<td width="289">
											<font size="1" color="red">Preencha todos os campos para criar sua conta.</font><br> <font size="1" color="red">Os campos marcados com * são obrigatórios.</font></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>
											<td width="289">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>


										<tr>
											<td width="145" valign="middle">
											<span lang="es">
											· Seu nome completo<font color="#FFFFFF">*</font></span></td>
											<td width="289">
											<input type="text" name="name" size="20"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
                                <td></td>
                                <td></td>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
										<tr>
											<td width="145" valign="middle">
											<span lang="es">
											· Usuário<font color="#FFFFFF">*</font></span></td>
											<td width="289">
											<input type="text" name="userid" size="20"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">
											<span lang="es">
											· E-mail<font color="#FFFFFF">*</font></td>
											<td width="289">
											<input type="text" name="email" size="20"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">
											<span lang="es">
			<br>								· Senha<font color="#FFFFFF">*</font></span></td>
											<td width="289">
	<font size="1" color="#FFFFFF">Minímo de 6 caractéres.</font>										<input type="password" name="pw1" size="20"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">
											
											<font color="gold"><span style="font-size: 7pt"></span></font></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">
											<span lang="es">
											· Confirme a senha<font color="#FFFFFF">*</font></span></td>
											<td width="289">
											<input type="password" name="pw2" size="20"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145" valign="middle">
											<span lang="es">
											· País<font color="#FFFFFF">*</font></span></td>
											<td width="289">
											<select id="dropDownCountrySelector" name="country" class onChange="refreshCountry(this, false);">																	<option value="Brasil">Brasil</option>
						<option value="Portugal">Portugal</option>
											</select></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										</tr>
										
                                <td></td>
										</tr>
<tr>
											<td width="145">
											<span lang="es"> 
											· Pergunta Secreta<font color="#FFFFFF">*</font></td>
											<td width="289">
											<select size="1" name="sq">
											<option value='Qual nome da sua mãe?'>Qual nome da sua mãe?</option>
<option value='Qual seu maior sonho?'>Qual seu maior sonho?</option>
<option value='Qual seu time do coração?'>Qual seu time do coração?</option>
<option value='Qual ocupação do seu avô?'>Qual ocupação do seu avô?</option>
<option value='Qual nome do seu ídolo?'>Qual nome do seu ídolo?</option>
<option value='Qual o nome do seu cachorro?'>Qual o nome do seu cachorro?</option>
											</select></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										
                                <td></td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>
											<td width="145">
											· Resposta secreta<font color="#FFFFFF">*</font></td>
											<td width="289">
											<input type="text" name="sa" size="34"></td>
											<td width="8">&nbsp;</td>
                                <td></td>
                                <td></td>
										</tr>
										<tr>

<tr>
											<td width="145">&nbsp;</td>
											<td width="289">
											
											<font color="red"><span style="font-size: 7pt">A pergunta serve para a recuperação de sua senha.</span></font></td>
											<td width="8">&nbsp;</td>
                                <td></td>
										</tr>
										<tr>
											<td width="434" colspan="4">
											<center><br>
											<input type="submit" value="Registrar" name="submit"></center></td>
											<td width="8">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
<?
}else{
?>
<form name="reg" method="POST" action="index.php?do=register">					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436" colspan="2">
											<img border="0" src="img/imagens/createaccount.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="25" valign="middle">&nbsp;
											</td>
											<td width="409" valign="middle">
											Você criou a conta "<b><font color="#FFFFFFF"><?=$user?></font></b>" com sucesso.</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="25">&nbsp;</td>
											<td width="409">Você pode jogar o <b><font color="#1E90FF">Hound Gunz</font></b> apartir do download: <a href="index.php?do=download">Clique aqui</a></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24" colspan="2">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
<?
}
?>