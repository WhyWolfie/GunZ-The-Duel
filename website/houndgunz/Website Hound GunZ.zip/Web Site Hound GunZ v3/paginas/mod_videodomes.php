<?
//Coded by Charmape ;D
?>

<center><object width="280" height="255"><param name="movie" value="http://www.youtube.com/v/yJotFvBenTo?version=3&feature=player_detailpage"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/yJotFvBenTo?version=3&feature=player_detailpage" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="210" height="200"></embed></object></center>