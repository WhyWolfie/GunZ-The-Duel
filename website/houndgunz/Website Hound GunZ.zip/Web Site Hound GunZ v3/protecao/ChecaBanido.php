<?
//Coded by Charmape ;D
?>
<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<meta http-equiv="content-language" content="pt-br">
<meta http-equiv="Content-Type" content="text/html;charset=iso-8859-1" />
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>Hound GunZ - Voce esta banido!</title>
<link rel="stylesheet" type="text/css" href="img/imagens/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(http://www.imgbase.info/images/safe-wallpapers/miscellaneous/1_other_wallpapers/5509_other_hd_wallpapers_flag.jpg);
}
-->
</style></head>
										<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="img/imagens/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="img/imagens/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color="#FF0000" font face="verdana">Querido <?=$_SESSION['UserID']?>,</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

          <center>  <font color="#FFFFFF" font face="verdana" size="2">                                                                               Sua conta foi banida pela equipe do Hound GunZ.
											<p>Eu acho que voce ja sabe como chegou a esse ponto.</p>
                                                                                        <p>Voce sempre pode fazer uma nova conta a partir da pagina de cadastro.</p>
                                                                                       </p>
                                                                                        <p>Passar bem,</p>
											<p>Equipe Hound GunZ.</center></td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="img/imagens/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


    <?
    die();
}

?>