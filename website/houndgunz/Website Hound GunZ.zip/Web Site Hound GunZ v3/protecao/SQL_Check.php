<?
$Criador = "Blasper";
//echo "O anti SQL foi codado por $Criador(Blasper), totalmente 100% seguro, n�o necessita de mais anti-sql.
//echo "Este web site foi desenvolvido e MODIFICADO por Charmape e a equipe DCastro.
//echo "N�o remova estes cr�ditos, Obrigado"
?>
<?
$bloquiados = array(";","\"","%","'","+","#","$","--","==","webzen"); 
foreach($_POST as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <img src=\"http://www.mundodoshackers.com.br/wp-content/uploads/bloqueado.jpg\" /><br />
    <br />
      <span class=\"textbox style20\">N&atilde;o use caracteres especiais! </span></p>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Voltar</a></p>
</div>");
		}
	}
}
foreach($_GET as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <img src=\"http://www.mundodoshackers.com.br/wp-content/uploads/bloqueado.jpg\" /><br />
    <br />
      <span class=\"textbox style20\">N&atilde;o use Caracteres Especiais! </span></p>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Voltar</a></p>
</div>");
		}
	}
}
foreach($_COOKIE as $valor)
{
	foreach($bloquiados as $bloquiados2)
	{
		if(substr_count(strtolower($valor), strtolower($bloquiados2)) > 0) 
		{
		  die("<div align=\"center\">
  <p><br>
    <p>&nbsp;</p>
  <p>&nbsp;</p>
    <img src=\"http://www.mundodoshackers.com.br/wp-content/uploads/bloqueado.jpg\" /><br />
    <br />
      <span class=\"textbox style20\">N&atilde;o use Caracteres Especiais! </span></p>
  <p><br />
    <a href=\"javascript: history.back(-1);\" class=\"style30\">Voltar</a></p>
</div>");
		}
	}
} ?>