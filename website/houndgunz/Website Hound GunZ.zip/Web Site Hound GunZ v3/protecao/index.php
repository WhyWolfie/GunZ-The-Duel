<?
$Criador = "Blasper";
//echo "O anti SQL foi codado por $Criador(Blasper), totalmente 100% seguro, n�o necessita de mais anti-sql.
//echo "Este web site foi desenvolvido e MODIFICADO por Charmape e a equipe DCastro.
//echo "N�o remova estes cr�ditos, Obrigado"
?>
<center><b>Acesso negado.