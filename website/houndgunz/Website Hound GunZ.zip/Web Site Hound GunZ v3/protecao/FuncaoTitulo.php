<?
//Coded by Charmape ;D
?>
<?
switch ($_GET['do']){
        case "":
            $pagetitle = "Website";
    break;
        case "register":
            $pagetitle = "Registro";
    break;
        case "downloads":
            $pagetitle = "Download";
    break;
        case "equipe":
            $pagetitle = "Equipe";
    break;
        case "ranking":
            $pagetitle = "Ranking";
    break;
        case "rzitemshop":
            $pagetitle = "Loja Donator";
    break;
        case "evitemshop":
            $pagetitle = "Loja Evento";
    break;
	    case "Chat Online":
            $pagetitle = "Chat Online";
    break;
	       case "gift";
            $pagetitle = "Presentear HG coins";
    break;
	       case "rzgift";
            $pagetitle = "Presentear HG coins";
    break;
	       case "evgift";
            $pagetitle = "Presentear EV Coins";
    break;
        case "rzadditem";
            $pagetitle = "Adicionar HG Shop Item";
    break;
        case "evadditem";
            $pagetitle = "Adicionar Ev Shop Item";
    break;
        case "userpanel";
            $pagetitle = "Painel do Usu�rio";
    break;
        case "login";
            $pagetitle = "Login";
    break;
        case "emblemas";
            $pagetitle = "Clam Emblem";
    break;
        case "muteuser";
            $pagetitle = "Mutar usuario";
    break;
        case "ipbanuser";
            $pagetitle = "Banir IP Usu�rio";
    break;
        case "tindex";
            $pagetitle = "User Painel";
    break;
        case "regras";
            $pagetitle = "Player Painel";
    break;
	default:
	    $pagetitle = "WebSite";
}

//

switch ($_GET['sub']){
        case "individual":
            $pagetitle = "Player Ranking";
    break;
        case "clan":
            $pagetitle = "Clan Ranking";
    break;
        case "color":
            $pagetitle = "Name Color";
    break;
        case "ev_coins";
            $pagetitle = "Trocar Pontos";
    break;
        case "details";
            $pagetitle = "Detalis";
    break;
        case "buyitem";
            $pagetitle = "Comprar item";
    break;
        case "announcement";
            $pagetitle = "An�ncios";
    break;
        case "update";
            $pagetitle = "Update";
    break;

}

//

switch ($_GET['action']){
        case "resetpwd":
            $pagetitle = "Reset Password";
    break;

}

//

switch ($_GET['act']){
        case "editinfo";
            $pagetitle = "Editar Conta";
    break;


}
?>