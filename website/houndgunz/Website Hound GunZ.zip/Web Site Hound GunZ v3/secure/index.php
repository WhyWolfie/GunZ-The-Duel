<?
//Coded by Charmape ;D
?>
<b><center>Acesso negado.