<?
switch ($_GET['do']){
        case "":
            $pagetitle = "Index";
    break;
        case "register":
            $pagetitle = "Register";
    break;
        case "downloads":
            $pagetitle = "Downloads";
    break;
        case "userpanel":
            $pagetitle = "User Panel";
    break;
        case "ranking":
            $pagetitle = "Ranking";
    break;
        case "rzitemshop":
            $pagetitle = "RZ Item Shop";
    break;
        case "evitemshop":
            $pagetitle = "EV Item Shop";
    break;
	    case "donate":
            $pagetitle = "Donate";
    break;
	       case "gift";
            $pagetitle = "Gift RZ Coins";
    break;
	       case "rzgift";
            $pagetitle = "Gift RZ Coins";
    break;
	       case "evgift";
            $pagetitle = "Gift EV Coins";
    break;
        case "rzadditem";
            $pagetitle = "Add RZ Shop Item";
    break;
        case "evadditem";
            $pagetitle = "Add EV Shop Item";
    break;
        case "addindexcontent";
            $pagetitle = "Add Annoucements / Updates";
    break;
        case "login";
            $pagetitle = "Login";
    break;
        case "banuser";
            $pagetitle = "Ban user";
    break;
        case "muteuser";
            $pagetitle = "Mute user";
    break;
        case "ipbanuser";
            $pagetitle = "IP ban user";

}

//

switch ($_GET['sub']){
        case "individual":
            $pagetitle = "Player Ranking";
    break;
        case "clan":
            $pagetitle = "Clan Ranking";
    break;
        case "hof":
            $pagetitle = "Hall Of Fame";
    break;
        case "viewmyitems";
            $pagetitle = "View my Items";
    break;
        case "details";
            $pagetitle = "Details";
    break;
        case "buyitem";
            $pagetitle = "Buy item";
    break;
        case "announcement";
            $pagetitle = "Announcement";
    break;
        case "update";
            $pagetitle = "Update";
    break;

}

//

switch ($_GET['action']){
        case "resetpwd":
            $pagetitle = "Reset Password";
    break;

}

//

switch ($_GET['act']){
        case "editinfo";
            $pagetitle = "Edit Account";
    break;


}
?>