
<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="15">&nbsp;</td>
											<td width="348" colspan="3">
											<img border="0" src="images/inf/downloads.png" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="-14" colspan="3"></td>
										</tr>

										<tr>
											<td width="3">
											</td>
											<td width="141">
											&nbsp;</td>
											<td width="287">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="3" rowspan="6">
											</td>
											<td width="141" rowspan="6">
											<div align="center">
												<table border="0" style="border-collapse: collapse" width="141" height="100%">
													<tr>
														<td width="7">&nbsp;</td>
														<td width="122" rowspan="3">
														<img border="0" src="images/dl_img.jpg" width="150" height="90"></td>
														<td width="6">&nbsp;</td>
													</tr>
													<tr>
														<td width="7">&nbsp;</td>
														<td width="6">&nbsp;</td>
													</tr>
													<tr>
														<td width="7">&nbsp;</td>
														<td width="6">&nbsp;</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="287">
											Nolife_x GunZ</td>
										</tr>

										<tr>
											<td width="287">
											&nbsp;</td>
										</tr>
										<tr>
											<td width="287">
											File size: 450-500 MB</td>
										</tr>
										<tr>
											<td width="287">
											Genre: Action</td>
										</tr>


										<tr>
											<td width="287">
											&nbsp;</td>
										</tr>
										<tr>
											<td width="287">
<select onchange="location = options[selectedIndex].value" size="1">
<option selected="selected">Select the download</option>
<option value="http://www.google.ca/">Nolife_x GunZ</option>
<option value="http://www.google.ca/">Direct x10</option>
</select>
										</td></tr>
                                                                                <tr>
											<td width="3">
											</td>
											<td width="141">
											&nbsp;</td>
											<td width="287">
											&nbsp;</td>
										</tr>
											<td width="432" colspan="3">
											<div align="center">
												<table border="0"  background="images/req_sys.jpg" style="border-collapse: collapse; background-image: url('images/req_sys.jpg'); background-repeat: no-repeat;" width="421">
													<tr>
														<td width="10" height="25">&nbsp;</td>
														<td width="195">&nbsp;</td>
													</tr>
													<tr>
														<td width="-2">
														<p align="center">&nbsp;</td>
														<td width="195">
														<p align="center">
														<font face="Tahoma"><b>
														Minimum</b></font></td>
														<td width="211">
														<p align="center"><b>
														<font face="Tahoma">
														Recommended</font></b></td>

<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>OS</b>:
														<span class="txt_col02_data">
														Windows 2000</span></td>
														<td width="211"><b>OS</b>:
														<span class="txt_col02_data">
														Windows XP - Windows Vista</span></td>
													</tr>
													</tr>
													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>CPU</b>:
														<span class="txt_col02_data">
														Pentium III 500MHz</span></td>
														<td width="211"><b>CPU</b>:
														<span class="txt_col02_data">
														Pentium III 800MHz or 
														better</span></td>
													</tr>

<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>
														RAM Memory</b>: 256MB</td>
														<td width="211"><b>
														RAM Memory</b>: 512MB or 
														more</td>
													</tr>

													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>GfX 
														Card</b>: Direct3D 9.0</td>
														<td width="211"><b>Gfx 
														Card</b>:
														<span class="txt_col03_data">
														<strong style="font-weight: 400">
														GeForce 4 MX or better</strong></span></td>
													</tr>
													<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>
														DirectX</b>: 9c or newer</td>
														<td width="211"><b>
														DirectX</b>: 9c or newer</td>
													</tr>

<tr>

	<td width="-2">&nbsp;</td>
														<td width="195"><b>
														Sound Card</b>: Direct3D</td>
														<td width="211"><b>
														Sound Card</b>: Direct3D</td>

</tr>

<tr>

	<td width="-2">&nbsp;</td>
														<td width="195"><b>
														Mouse</b>: Window Compatible</td>
														<td width="211"><b>
														Mouse</b>: Whell Mouse</td>

</tr>
													
<tr>
														<td width="-2">&nbsp;</td>
														<td width="195"><b>
														Joypad</b>: Window Compatible</td>
														<td width="211"><b>
														Joypad</b>: Joy Pad Dual Shock</td>
													</tr>
													</table>
											</div>
											</td>
										</tr>

										<tr>
											<td width="432" colspan="3" height="18">
											</td>
										</tr>

										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>