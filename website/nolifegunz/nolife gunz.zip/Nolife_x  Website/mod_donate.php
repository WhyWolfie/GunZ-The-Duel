<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<script language="JavaScript">
/*
SCRIPT EDITE SUR L'EDITEUR JAVASCRIPT
http://www.editeurjavascript.com
*/
function ChangeUrl(formulaire)
	{
	if (formulaire.ListeUrl.selectedIndex != 0)
		{
		location.href = formulaire.ListeUrl.options[formulaire.ListeUrl.selectedIndex].value;
	 	}
	else 
		{
		alert('Veuillez choisir une destination.');
		}
	}
</script>
<script type="text/javascript">

    function updateForm()
    {
        var donation = document.donation.amount.value;
        var coins = donation*10
        document.getElementById("coins").innerHTML = coins;

        document.donation.item_name.value = coins + " RZCoins";
        document.donation.item_number.value = coins;
    }

</script>
</head>

	
<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
.style4 {color: #FFFFFF; font-weight: bold; }
-->
    </style>
	<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
    </style>
	<body bgcolor="#312F30">

	<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><img border="0" src="images/inf/buycoins.png" width="414" height="19"></td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
										  <td width="434"><div align="center"></div></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434"><div align="center">
                                              <table width="432" border="0">
                                                <tr>
                                                  <td colspan="2"><em><strong>Buy RZCoins by PayPal </strong></em></td>
                                                </tr>
                                                <tr>
                                                  <td width="59" rowspan="2"><img src="images/pay_2.gif" width="91" height="89" /></td>
                                                  <td width="357">The payment service PayPal is widely recognized for its fast and safe. PayPal offers you to use the most popular companies for your credit card transactions.<br />
                                                      <br />
                                                      <strong>Choose one of our various payment plans below:</strong></td>
                                                </tr>
                                                <tr>
                                                  <td>                                                <form name="donation" action="https://www.paypal.com/cgi-bin/webscr" method="post">
                                                <input type="hidden" name="cmd" value="_xclick" />
                                                <input type="hidden" name="business" value="Nolife_x@live.ca" />
                                                <input type="hidden" name="lc" value="US">
                                                <input type="hidden" name="currency_code" value="CAD" />
                                                <input type="hidden" name="no_note" value="1" />
                                                <input type="hidden" name="no_shipping" value="1" />
                                                <input type="hidden" name="tax" value="0.00" />
                                                <input type="hidden" name="bn" value="PP-BuyNowBF" />
                                                <input type="hidden" name="return" value="http://192.168.0.199/index.php?do=ipn" />
                                                <input type="hidden" name="cancel_return" value="http://192.168.0.199/index.php" />
                                                <input type="hidden" name="notify_url" value="http://192.168.0.199/index.php?do=ipn" />
                                                <input type="hidden" name="rm" value="2" />

                                                Donate:&nbsp;
                                                <select name="amount" onchange="updateForm();">
                                                    <option value="1.00">1 CAD</option>
                                                    <option value="5.00" selected>5 CAD</option>
                                                    <option value="10.00">10 CAD</option>
                                                    <option value="15.00">15 CAD</option>
                                                    <option value="20.00">20 CAD</option>
                                                    <option value="25.00">25 CAD</option>
                                                    <option value="30.00">30 CAD</option>
                                                    <option value="35.00">35 CAD</option>
                                                    <option value="40.00">40 CAD</option>
                                                    <option value="45.00">45 CAD</option>
                                                    <option value="50.00">50 CAD</option>
                                                </select>
                                                <br />
                                                With that donation you will receive <span id="coins">50</span> RZ Coins

                                                <input type="hidden" name="item_name" value="50 RZ Coins">
                                                <input type="hidden" name="item_number" value="50">
                                                <input type="hidden" name="custom" value="<?php echo $_SESSION['AID']; ?>">

                                                <script type="text/javascript">
                                                    updateForm();
                                                </script>
                                                <br /><br />
                                                  <input name="submit" type="submit" id="submit" value="Buy Now">
                                                </form></td>
                                                </tr>
                                              </table>
											  </div>
											  <div align="center"></div>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
							</tr>
						</table>
					    <br>
	</div>
	