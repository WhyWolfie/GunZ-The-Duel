<?
if ($_GET['expand'] == 1){
?>
				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('images/subbar.png'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=ranking&sub=individual&expand=1">
					<img border="0" src="images/subbar/individualranking.jpg" width="99" height="13"></a><a href="index.php?do=ranking&sub=clan&expand=1"><img border="0" src="images/subbar/clanranking.jpg" width="99" height="13"></a></td>
				</tr>

<? }

if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "individual";
        ShowIndividualRanking();
    break;
    case "clan";
        ShowClanRanking();
    break;
    case "hof";
        ShowHalloffame();
    break;
}
}


if(!function_exists("ShowIndividualRanking")){
function ShowIndividualRanking(){
    ?>


<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/individualranking.png"></td>
											<td width="8">&nbsp;</td>
										</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="590" valign="top"><p>
									<div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="ranking" />
                                    <p align="center">
                                    <select name="sub">
                                    <option value="individual">Character Name</option>
                                    <select name="expand">
                                    <option value="1">=</option>
                                    </select>
                                    &nbsp;
                                    <input type="text" name="name" />
                                    <input type="submit" value="Search" />
                                    </p>
					                </form></div></td>
								</tr>
										<tr>
											<td width="434">
											<img border="0" src="images/ranking_legend.jpg" width="437" height="30"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/rankinglist.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/rankinlist_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                                <?
                                                        if( isset($_GET['expand']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $name = clean($_GET['name']);
                                                        }
                                                            if($search == 1)
                                                            {
                                                                $squery = "SELECT CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE Name = '$name' AND (DeleteFlag=0 OR DeleteFlag=NULL)";
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }


                                                        if($search == 0 )
                                                        {
                                                        switch( clean($_GET['page']) )
                                                        {
                                                            case "":
                                                                $ranks = "Ranking >= 1 AND Ranking <= 20";
                                                            break;
                                                            case "2":
                                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                                            break;
                                                            case "3":
                                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                                            break;
                                                            case "4":
                                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                                            break;
                                                            case "5":
                                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $ranks = "Ranking <= 20";
                                                            break;
                                                        }
                                                        $res = mssql_query_logged("SELECT TOP 20 CID, Level, XP, Ranking, KillCount, DeathCount FROM Character(nolock) WHERE $ranks AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
                                                           $count0;
                                                            }
                                                            else
                                                            {
                                                                $res = mssql_query_logged($squery);
                                                            }
                                                              if(mssql_num_rows($res) <> 0)
                                                              {
                                                               }
                                                                while($r = mssql_fetch_assoc($res)){
                                                                    $count++;
                                                        ?>								<tr>
																		<td width="45">
																		<p align="center">
																		<?=$count?></td>
																		<td width="88">
																		<p align="center">
																		<b>
																		<span class="guild_name">
																		<?=FormatCharName($r['CID'])?></span></b>
																		</td>
																		<td width="33">
																		<p align="center">
																		<?=$r['Level']?></td>
																		<td width="127">
																		<p align="center">
																		<?=number_format($r['XP'],0,'','.');?></td>
																		<td width="114">
																		<p align="center">
																		<span style="font-size: 7pt">
																		<?=GetKDRatio($r['KillCount'], $r['DeathCount'])?></span></td>
																	</tr> <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
                                    <p align="center"><a href="index.php?do=ranking&sub=individual&expand=1">[1-20]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&page=2">[21-40]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&page=3">[41-60]</a>
									- <a href="index.php?do=ranking&sub=individual&expand=1&page=4">[61-80]</a> - <a href="index.php?do=ranking&sub=individual&expand=1&page=5">[81-100]</a></p>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }

if(!function_exists("ShowClanRanking")){
function ShowClanRanking(){                                                           
    ?>
<body bgcolor="#312F30">		
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
										<table border="0" style="border-collapse: collapse" width="100%">
										<tr>
									                 
											<td width="4" rowspan="6">&nbsp;</td>
											<img border="0" src="images/inf/clanranking.png" width="413" height="17">
										</tr>
                                        <?
                                            $res = mssql_query_logged("SELECT TOP 3 * FROM Clan WHERE (DeleteFlag=0 OR DeleteFlag=NULL) AND Ranking != 0 ORDER BY POINT DESC");

                                            $Count = 0;

                                            while($resa = mssql_fetch_object($res))
                                            {
                                                $FirstClan[$Count][Name]        = $resa->Name;
                                                $FirstClan[$Count][EmblemURL]   = ($resa->EmblemUrl == "") ? "images/no_emblem.png" : $resa->EmblemUrl;

                                            if($Count == 3)
                                                break;
                                            else
                                                $Count++;
                                            }

                                            $firstclanemb0 = ($FirstClan[0][EmblemURL] == "") ? "images/no_emblem.png" : $FirstClan[0][EmblemURL];
                                            $firstclanemb1 = ($FirstClan[1][EmblemURL] == "") ? "images/no_emblem.png" : $FirstClan[1][EmblemURL];
                                            $firstclanemb2 = ($FirstClan[2][EmblemURL] == "") ? "images/no_emblem.png" : $FirstClan[2][EmblemURL];

                                            $firstclanname0 = ($FirstClan[0][Name] == "") ? "No Data" : $FirstClan[0][Name];
                                            $firstclanname1 = ($FirstClan[1][Name] == "") ? "No Data" : $FirstClan[1][Name];
                                            $firstclanname2 = ($FirstClan[2][Name] == "") ? "No Data" : $FirstClan[2][Name];


                                            $toprank = '
											<tr>
												<td width="144" valign="bottom" height="80">
												<div  align="center">
												<img src="http://192.168.0.199/'.$firstclanemb0.'" width="50" height="50"></td>
												<td width="135" valign="bottom" height="80">
												<div align="center">
												<img src="http://192.168.0.199/'.$firstclanemb1.'" width="50" height="50"></td>
												<td width="126" valign="bottom" height="80">
												<div align="center">
												<img src="http://192.168.0.199/'.$firstclanemb2.'" width="50" height="50"></td>
											</tr>
<table border="0" style="border-collapse: collapse" width="100%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="128">
															<div align="center">
															<font color="#FF00FF">
															<b>1ST | '.$firstclanname0.'</b></font></td>
															<td width="10">&nbsp;</td>
															<td width="126">
															<div align="center">
															<b>2ND | '.$firstclanname1.'</b></td>
															<td width="7">&nbsp;</td>
															<td width="122">
															<div align="center">
															<b>3RD | '.$firstclanname2.'</b></td>
															<td width="11">&nbsp;</td>
														</tr>';
                                echo $toprank;                                ?>
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
                                                                                </tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="590" valign="top"><p>
									<div align="center">
                                    <form method="GET" name="indsearch" action="index.php">
                                    <input type="hidden" name="do" value="ranking" />
                                    <p align="center">
                                    <select name="sub">
                                    <option value="clan">Clan Name</option>
                                    <select name="expand">
                                    <option value="1">=</option>
                                    </select>
                                    &nbsp;
                                    <input type="text" name="name" />
                                    <input type="submit" value="Search" />
                                    </p>
					                </form></div></td>
								</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/clanranking_list.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/clanranking_list_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                               <?
                                                        if( isset($_GET['expand']) && isset($_GET['name']) )
                                                        {
                                                            $search = 1;
                                                            $name = clean($_GET['name']);
                                                        }
                                                            if($search == 1)
                                                            {
                                                                $squery = "SELECT * FROM Clan(nolock) WHERE Name = '$name' AND (DeleteFlag=0 OR DeleteFlag=NULL)";
                                                            }
                                                            else
                                                            {
                                                                $search = 0;
                                                            }


                                                        if($search == 0 )
                                                        {
                                                        switch( clean($_GET['page']) )
                                                        {
                                                            case "":
                                                                $ranks = "Ranking >= 1 AND Ranking <= 20";
                                                            break;
                                                            case "2":
                                                                $ranks = "Ranking > 20 AND Ranking <= 40";
                                                            break;
                                                            case "3":
                                                                $ranks = "Ranking > 40 AND Ranking <= 60";
                                                            break;
                                                            case "4":
                                                                $ranks = "Ranking > 60 AND Ranking <= 80";
                                                            break;
                                                            case "5":
                                                                $ranks = "Ranking > 80 AND Ranking <= 100";
                                                            break;
                                                            default:
                                                                $ranks = "Ranking <= 20";
                                                            break;
                                                        }
                                                        $res = mssql_query_logged("SELECT TOP 20 * FROM Clan WHERE $ranks AND (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY POINT DESC");
                                                            }
                                                            else
                                                            {
                                                                $res = mssql_query_logged($squery);
                                                            }
                                                              if(mssql_num_rows($res) <> 0)
                                                              {
                                                               }
                                                                while($r = mssql_fetch_assoc($res)){
                                                        ?>

                                                                    <tr>
																		<td width="45">
																		<p align="center">
																		<?=$r['Ranking']?></td>
																		<td width="40">
																		<p align="center">
																		<img src="http://192.168.0.199/<?=($r['EmblemUrl'] == "") ? "images/no_emblem.png" : $r['EmblemUrl'];?>" width="50" height="50"></td>
																		<td width="90">
																		<p align="center">
																		<b><?=$r['Name']?></b></td>
																		<td width="76">
																		<p align="center">
																		<? $res3 = mssql_query_logged("SELECT * FROM Character WHERE CID = '".$r['MasterCID']."'");
                                                                            $c = mssql_fetch_assoc($res3);
                                                                            echo FormatCharName($c['CID']);
                                                                        ?></td>
																		<td width="71">
																		<p align="center">
																		<?=$r['Wins']?>/<?=$r['Losses']?> (<?=GetClanPercent($r['Wins'], $r['Losses'])?>)</td>
																		<td width="83">
																		<p align="center">
																		<?=$r['Point']?></td>
																	</tr>  <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
                                                <p align="center"><a href="index.php?do=ranking&sub=clan&expand=1">[1-20]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&page=2">[21-40]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&page=3">[41-60]</a>
									- <a href="index.php?do=ranking&sub=clan&expand=1&page=4">[61-80]</a> - <a href="index.php?do=ranking&sub=clan&expand=1&page=5">[81-100]</a></p>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }
if(!function_exists("ShowHalloffame")){
function ShowHalloffame(){                                                           
       ?>
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/Halloffame.png"></td>
											<td width="8">&nbsp;</td>
										</tr>
								<tr>


									<td style="background-repeat: repeat; background-position: center top" width="583" align="left" valign="top">
                                    <form method="GET" name="honorrank" action="index.php">
                                    <input type="hidden" name="do" value="halloffame" />
                                    <table align="center">
                                    <tr>
                                    <td align="left" width="50%">
                                    <option>Viewing ranking from</option>
                                    <?
                                    $listq = mssql_query_logged("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                    while($halldata = mssql_fetch_assoc($listq))
									{
										echo '<option value="'.$halldata[Month].'-'.$halldata[Year].'">'.$halldata[Month].'/'.$halldata[Year].'</option>';
									}
                                $querydate = mssql_query_logged("SELECT TOP 1 Month, Year FROM ClanHonorRanking(nolock) GROUP BY Month, Year ORDER BY Year DESC, Month DESC");
                                $ddata = mssql_fetch_row($querydate);
                                $month = $ddata[0];
                                $year = $ddata[1];
                                $date = ( isset($month) && isset($year) ) ? $month."-".$year : "";
                                    ?>
                                    </select>
									</td>
									</tr>
									</table>
									</form>
                                    
                                    </td>
									<td style="background-repeat: repeat; background-position: center top" width="7" rowspan="5">&nbsp;</td>
								</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/clanranking_list.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/clanranking_list_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
<?
 switch( clean($_GET['page']) )
                                                            {
                                                                case "":
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                                case "2":
                                                                    $ranks = "Ranking > 20 AND Ranking <= 40";
                                                                break;
                                                                case "3":
                                                                    $ranks = "Ranking > 40 AND Ranking <= 60";
                                                                break;
                                                                case "4":
                                                                    $ranks = "Ranking > 60 AND Ranking <= 80";
                                                                break;
                                                                case "5":
                                                                    $ranks = "Ranking > 80 AND Ranking <= 100";
                                                                break;
                                                                default:
                                                                    $ranks = "Ranking <= 20";
                                                                break;
                                                            }
$res2 = mssql_query_logged("SELECT TOP 20 * FROM ClanHonorRanking WHERE Month = '$month' AND Year = '$year' AND $ranks ORDER BY RANKING DESC");
$count = 0;                                                                 
while($r = mssql_fetch_assoc($res2)){
                                                                       $clanemburl = ($clan->EmblemUrl == "") ? "images/no_emblem.png" : $clan->EmblemUrl;?>

                                                                    <tr>
																		<td width="45">
																		<p align="center">
																		<?=$r['Ranking']?></td>
																		<td width="40">
																		<p align="center">
																		<img src="http://192.168.0.199/<?=($r['EmblemUrl'] == "") ? "images/no_emblem.png" : $r['EmblemUrl'];?>" width="50" height="50"></td>
																		<td width="90">
																		<p align="center">
																		<b><?=$r['ClanName']?></b></td>
																		<td width="76">
																		<p align="center">
																		<? $res3 = mssql_query_logged("SELECT * FROM Character WHERE CID = '".$r['MasterCID']."'");
                                                                            $c = mssql_fetch_assoc($res3);
                                                                            echo FormatCharName($c['CID']);
                                                                        ?></td>
																		<td width="71">
																		<p align="center">
																		<?=$r['Wins']?>/<?=$r['Losses']?> (<?=GetClanPercent($r['Wins'], $r['Losses'])?>)</td>
																		<td width="83">
																		<p align="center">
																		<?=$r['Point']?></td>
																	</tr>  <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
                                                <p align="center"><a href="index.php?do=ranking&sub=hof&expand=1">[1-20]</a> - <a href="index.php?do=ranking&sub=hof&expand=1&page=2">[21-40]</a> - <a href="index.php?do=ranking&sub=hof&expand=1&page=3">[41-60]</a>
									- <a href="index.php?do=ranking&sub=hof&expand=1&page=4">[61-80]</a> - <a href="index.php?do=ranking&sub=hof&expand=1&page=5">[81-100]</a></p>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }
?>