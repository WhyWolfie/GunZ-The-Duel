<?
$res = mssql_query_logged("SELECT TOP 10 * FROM Character WHERE (DeleteFlag=0 OR DeleteFlag=NULL) ORDER BY XP DESC");
$count = 0;
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/playerranking.gif" height="30" width="195">&nbsp;</td>
  </tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>No data</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">� <?=$clan['Name']?></td>
										<td width="41">
										<p align="center"><?=$clan['Level']?>Lvl
									  </td>
								  </tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.gif" height="22">&nbsp;</td>
  </tr>
</table>