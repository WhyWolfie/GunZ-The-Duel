<?
include "banned.php";
include "banneduser.php";
include "checkcookie.php";
$res = mssql_query_logged("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
<style type="text/css">
<!--
.style5 {font-size: 16px}
.style7 {color: #004f6b}
.style1 {font-size: 7pt}
-->
</style>

			<table border="0" style="border-collapse: collapse" width="100%" height="100%" id="table2">
				<tr>
				  <td width="481" valign="top" height="127">
					<div align="center">
					  <table border="0" style="border-collapse: collapse" width="443" id="table7" background="images/playframe.png" height="87">
                        <tr>
                          <td height="87" width="269"><table border="0" style="border-collapse: collapse" width="436" height="85%">
                              <tr>
                                <td><p align="center"><b> <font size="5" face="Trebuchet MS" color="#FFFFFF">
                                    <?=$servercount?>
                                  </font></b> <br>
                                    <span class="style5">Players Online</span></td>
                              </tr>
                              <tr>
                                <body onload="FP_preloadImgs(/*url*/'images/btn_dlgunz_hover.png')" bgcolor="#323232">
				<td height="32" width="457"> <center><a href="index.php?do=downloads" target="_blank"><img src="images/btn_dlgunz.png" name="img6" border="0" id="img6" onMouseOver="FP_swapImg(1,1,/*id*/'img6',/*url*/'images/btn_dlgunz_hover.png')" onMouseOut="FP_swapImgRestore()"></a></center></td>
                              </tr>
                          </table></td>
                        </tr>
                      </table> 
				      <br>
					</div>
                    <div align="center"></div>
				  <p></td>
				</tr>
				<tr>
					<td width="481" valign="top">
					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.png">&nbsp;</td>
						  </tr>
							<tr>
								<td background="images/cont_bg.png">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="5">&nbsp;</td>
											<td width="430">
											<img border="0" src="images/inf/homepage.png" width="414" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">
											&nbsp;<div align="center">
												<table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="417" height="151">
													<tr>
														<td width="200" height="24">&nbsp;</td>
														<td width="7" height="24">&nbsp;</td>
														<td width="204" height="24">&nbsp;</td>
													</tr>
													<tr>
														<td width="200" valign="top">
														<table border="0" style="border-collapse: collapse" width="200" height="92%">
															<tr>
																<td width="4">&nbsp;</td>
																<td width="192" valign="top">
																<table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
																	<tr>
																		<td height="20">
																		<span class="menu">
																		<span class="style7"><font size="1" face="Verdana">�</font></span><font face="Verdana" size="1"><font color="#FFFFFF">
																		<a href="index.php?do=indexcontent&sub=announcement&id=<?=$n['ICID']?>">
																		<font size="1" face="Verdana"><?=$n['Title']?></a></font></span></td>
																  </tr>
                                                                    <?}?>
																</table>																</td>
															</tr>
														</table>														</td>
														<td width="7">&nbsp;</td>
														<td width="204" valign="top">
														<table border="0" style="border-collapse: collapse" width="100%" height="92%">
															<tr>
																<td valign="top">
																<table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                                                                                                   <?
                                                                $res = mssql_query_logged("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
																	<tr>
																		<td height="20">
																		<span class="menu">

																		<span class="style7">
																		<font size="1" face="Verdana">�</font></span>
																		<a href="index.php?do=indexcontent&sub=update&id=<?=$n['ICID']?>">
																		<font size="1" face="Verdana"><?=$n['Title']?></font></a></span></td>
																  </tr>
                                                                    <?}?>
																</table>																</td>
															</tr>
														</table>														</td>
													</tr>
												</table>
											</div>											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="430">&nbsp;											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
										<tr>
											<td width="8">&nbsp;</td>
									  </tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.png" height="27">&nbsp;</td>
						  </tr>
						</table>
					    <br>
			<? if($_SESSION['UGradeID'] == 255 or $_SESSION['UGradeID'] == 254 or $_SESSION['UGradeID'] == 252){include"mod_adminindex.php";echo "</br>";} ?>
					</div></td>
                    </tr>
			</table>