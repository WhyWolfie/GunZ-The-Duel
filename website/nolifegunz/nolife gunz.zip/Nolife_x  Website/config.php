<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("TU-PC\SQLEXPRESS","sa","27asdsan");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'TU-PC\SQLEXPRESS';
$DBUser = 'Sa';
$DBPass = 'asdasdn';
$DB = 'GunzDB';
?>