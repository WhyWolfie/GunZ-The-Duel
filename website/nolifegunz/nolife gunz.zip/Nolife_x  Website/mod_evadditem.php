<?php
include "authadmin.php";
include "title.php";
if($_SESSION['UGradeID'] == 254){
    msgbox("Access Denied","index.php");
}
if($_SESSION['UGradeID'] == 252){
    msgbox("Access Denied","index.php");
}

if(isset($_POST['submit'])){
    $name = clean($_POST['name']);
    $zitemid = clean($_POST['zItemID']);
    $desc = clean($_POST['desc']);
    $price = clean($_POST['price']);
    $img = clean($_POST['img']);
    $sex = clean($_POST['sex']);
    $minlvl = clean($_POST['minlvl']);
    $peso = clean($_POST['peso']);
    $slot = clean($_POST['slot']);
    $damage = clean($_POST['damage']);
    $AP = clean($_POST['AP']);
    $FR = clean($_POST['FR']);
    $delay = clean($_POST['delay']);
    $HP = clean($_POST['HP']);
    $PR = clean($_POST['PR']);
    $magazine = clean($_POST['magazine']);
    $maxpeso = clean($_POST['maxpeso']);
    $CR = clean($_POST['CR']);
    $balasmax = clean($_POST['balasmax']);
    $reloadtime = clean($_POST['reloadtime']);
    $LR = clean($_POST['LR']);
    $control = clean($_POST['control']);
    $csid = clean($_POST['zItemID']);
    mssql_query_logged("INSERT INTO [Item] ([ItemID], [Name], [Description], [ResSex], [ResLevel], [Weight], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [CR], [MaxBullet], [ReloadTime], [LR])VALUES('$zitemid', '$name', '$desc', NULL, $minlvl, 1, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $CR, $balasmax, $reloadtime, $LR)");
    mssql_query_logged("INSERT INTO [EVCashShop] ([ItemID], [Name], [CSID], [Description], [CashPrice], [WebImgName], [NewItemOrder], [ResSex], [ResLevel], [Weight], [Opened], [RegDate], [RentType], [Slot], [Damage], [AP], [FR], [Delay], [HP], [PR], [Magazine], [MaxWeight], [CR], [MaxBullet], [ReloadTime], [LR], [Control])VALUES('$zitemid', '$name', '$csid', '$desc', $price, '$img', NULL, $sex, $minlvl, $peso, 1, GETDATE(), NULL, '$slot', $damage, $AP, $FR, $delay, $HP, $PR, $magazine, $maxpeso, $CR, $balasmax, $reloadtime, $LR, $control)");
    msgbox("Item added correctly","index.php?do=evadditem");
}else{
    



?><head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<form method="POST" action="index.php?do=evadditem"><table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="32">&nbsp;</td>
											<td width="429" colspan="3">
											<img border="0" src="images/inf/addshopitem.png" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>

										<tr>
											<td width="438" colspan="3">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="184" align="right">
											ItemID (zitem.xml)</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="zItemID" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right" valign="top">
											Description</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<textarea rows="4" name="desc" cols="26"></textarea></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Image</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="img" size="34"></td>
										</tr>

										<tr>
											<td width="184">
											<p align="right">Name</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="name" size="20"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Slot</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="slot">
											<option selected value="1">Melee Weapons</option>
											<option value="2">Ranged Weapons</option>
											<option value="3">Armor</option>
											<option value="4">Full Set</option>
											<option value="5">Special Item</option>
											</select></td>
										</tr>


										<tr>
											<td width="184" align="right">
											Sex</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<select size="1" name="sex">
											<option selected value="2">Everyone</option>
											<option value="0">Man</option>
											<option value="1">Woman</option>
											</select></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Lv. Min</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="minlvl" size="20" value="1"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="peso" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Price</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="price" size="20" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Damage</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="damage" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Delay</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="delay" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Magazine</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="magazine" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Reload Time</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="reloadtime" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Max Bullet</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="balasmax" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											HP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="HP" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											AP</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="AP" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											 Max Weight</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="maxpeso" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											Control</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="control" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											FR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="FR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											PR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="PR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											CR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="CR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184" align="right">
											LR</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											<input type="text" name="LR" size="11" value="0"></td>
										</tr>

										<tr>
											<td width="184">
											&nbsp;</td>
											<td width="6">
											&nbsp;</td>
											<td width="242">
											&nbsp;</td>
										</tr>

										<tr>
											<td width="432" colspan="3">
											<p align="center">
											<input type="submit" value="Add Item" name="submit"></td>
										</tr>

										<tr>
											<td width="1" colspan="3"></td>
										</tr>
										</table></form>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
<?
}
?>