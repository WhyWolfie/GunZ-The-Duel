<?php
SetTitle("xTreme Gunz - UserCP");
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Panel de Usuario</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="358" border="0">
                                        <tr>
                                          <td width="210">xTremeGunz Foro</td>
                                          <td width="80"><div align="center"><a href="http://foro.xtremegunz.coms.pe">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Recuperar Contrase&ntilde;a</td>
                                          <td><div align="center"><a href="index.php?do=resetpwd">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Registrarse</td>
                                          <td><div align="center"><a href="index.php?do=register">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Donar a xTremeGunz</td>
                                          <td><div align="center"><a href="index.php?do=donate">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          
                                        </tr>
                                        <tr>
                                          <td>Descargas</td>
                                          <td><div align="center"><a href="index.php?do=download">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Individual Ranking</td>
                                          <td><div align="center"><a href="index.php?do=individualrank">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Clan Ranking</td>
                                          <td><div align="center"><a href="index.php?do=clanrank">Click Aqui</a></div></td>
                                        </tr>
                                        <tr>
                                          <td>Hall of Fame</td>
                                          <td><div align="center"><a href="index.php?do=halloffame">Click Aqui</a></div></td>
                                        </tr>
                                      </table>
									</form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>