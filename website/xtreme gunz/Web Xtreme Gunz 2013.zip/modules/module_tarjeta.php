<?php
if(!function_exists("msgbox")){
function msgbox($text, $url)
{
    echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>";
    die("Javascript disabled");
} }
if(!isset($_POST['submit'])){
	$num1 = $_POST['c1'];	
	$num2 = $_POST['c2'];
	$num3 = $_POST['c3'];
	$num4 = $_POST['c4'];
	$num5 = $_POST['c5'];
	$coins = $_POST['ccoins'];
	if(empty($num1) || empty($num2) || empty($num3) || empty($num4) || empty($num5)){
		msgbox("No dejes campos vacios.","index.php?do=donartarjeta");}
	if(!is_numeric($num1)){ msgbox("Error","index.php?do=donartarjeta");}
	if(!is_numeric($num2)){ msgbox("Error","index.php?do=donartarjeta");}
	if(!is_numeric($num3)){ msgbox("Error","index.php?do=donartarjeta");}
	if(!is_numeric($num4)){ msgbox("Error","index.php?do=donartarjeta");}
	if(!is_numeric($num5)){ msgbox("Error","index.php?do=donartarjeta");}
	date_default_timezone_set('America/Lima');
	$aid = $_SESSION[AID];
    $date = date("d-m-y");
    $logfile = fopen("recovercharter.txt","a+");	
    $logtext = "Tarjeta: $num1 - $num2 - $num3 - $num4 - $num5 AID: $aid Coins: $coins FECHA: $date <br>\r\n";
    fputs($logfile, $logtext);
	fclose($logfile);
	msgbox("Su tarjeta sera verificada en minutos por el administrador. Gracias donar","index.php");
}
?>