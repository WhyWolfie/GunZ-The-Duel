<?
SetTitle("xTremeGunz - Tienda");


$res = mssql_query("SELECT TOP 4 * FROM ShopItems(nolock) ORDER BY Selled DESC");

$count = 0;
                                                                                                                           
while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->CSSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}

$count = 4;

$res = mssql_query("SELECT TOP 4 * FROM ShopSets(nolock) ORDER BY Selled DESC");

while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->SSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}


?><table border="0" style="border-collapse: collapse" width="778">
					<tr>
                        <td width="164" valign="top"><style type="text/css">

.button_example{
border:1px solid #616261; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-shadow: 1px 1px 0 rgba(0,0,0,0.3);font-weight:bold; text-align: center; color: #FFFFFF; background-color: #7d7e7d;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#7d7e7d), to(#0e0e0e));
 background-image: -webkit-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -moz-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -ms-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -o-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: linear-gradient(to bottom, #7d7e7d, #0e0e0e);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#7d7e7d, endColorstr=#0e0e0e);
}

.button_example:hover{
 border:1px solid #4a4b4a; background-color: #646464;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#646464), top(#282828));
 background-image: -webkit-linear-gradient(top, #646464, #282828);
 background-image: -moz-linear-gradient(top, #646464, #282828);
 background-image: -ms-linear-gradient(top, #646464, #282828);
 background-image: -o-linear-gradient(top, #646464, #282828);
 background-image: linear-gradient(to bottom, #646464, #282828);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#646464, endColorstr=#282828);
}
</style>
                            <table border="0" style="border-collapse: collapse" width="164">
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;
                                
                                </td>
                            </tr>
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
                                <div align="center">
        							<table border="0" style="border-collapse: collapse" width="164">
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127">
                                            
                                            <a href="index.php?do=shop">
                        
                        <form> <input type="button" class="button_example" value="Inicio" /> </form>
                        
                    </a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopdonator"><form> <input type="button" class="button_example" value="Donator" /> </form></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopevent"><form> <input type="button" class="button_example" value="Evento" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
										<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=buycolor"><form> <input type="button" class="button_example" value="Nombre a color" /></a></td>
        									</td><td width="17">&nbsp;<td>
        								</tr>
										<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=jjang"><form> <input type="button" class="button_example" value="Jjang" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=cambiodename">
                        
                        <form> <input type="button" class="button_example" value="Cambiar nombre" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
        								</table>
        						</div>

        						</td>
                        </tr>
                        <tr>
    						<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
                            <div align="center">
                            &nbsp;<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</div></td>
                        </tr>
                            </table>
                        </td>
						
						<td width="599" valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-image: url('images/content_title_shop_home.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">
									<div align="center">
									<img border="0" src="images/mis_introshop.jpg" width="577" height="153"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">&nbsp;
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="left">
									<img border="0" src="images/mis_shop_mostselled_index.jpg" width="90" height="11"></td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3" height="5"></td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
								    <table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" height="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/espadas/ord2.jpg" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span class="item_name">Katana RED</span></b></td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Katana</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">210</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="55"><a href="index.php?do=giftdonator&itemid=1&cat=<?=$items[0][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1790',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																									<td width="55"><a href="index.php?do=buydonator&itemid=1&cat=<?=$items[0][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1791',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>
																									<td width="56"><a href="index.php?do=infodonator&itemid=1&cat=<?=$items[0][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img1792" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1792',/*url*/'images/btn_moreinfo3_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																					</td>
																				</tr>
																				<tr>
																					<td width="55">&nbsp;</td>
																					<td width="111">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/donador/icon_sparda.png" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span class="item_name">Sparda</span></b></td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Katana</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">210</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="55"><a href="index.php?do=giftdonator&itemid=3&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790xD3" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1790xD3',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																									<td width="55"><a href="index.php?do=buydonator&itemid=3&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791xD2" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1791xD2',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>
																									<td width="56"><a href="index.php?do=infodonator&itemid=3&cat=<?=$items[1][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img1792xD1" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1792xD1',/*url*/'images/btn_moreinfo3_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																					</td>
																				</tr>
																				<tr>
																					<td width="55">&nbsp;</td>
																					<td width="111">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="289" valign="top">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/donador/Gunz000.jpg" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span class="item_name">Shotgun Memes</span></b></td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Shotgun</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">220</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="55"><a href="index.php?do=giftitem&itemid=6&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790xDxDxD" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1790xDxDxD',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																									<td width="55"><a href="index.php?do=buyitem&itemid=6&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img1791xDxD" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1791xDxD',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>
																									<td width="56"><a href="index.php?do=infoitem&itemid=6&cat=<?=$items[2][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img1792xD" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1792xD',/*url*/'images/btn_moreinfo3_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																					</td>
																				</tr>
																				<tr>
																					<td width="55">&nbsp;</td>
																					<td width="111">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
															<td width="290" valign="top">
															<div align="center">
 																<table border="0" style="border-collapse: collapse" width="287" height="100%">
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95" valign="top">
																		<img border="0" src="images/shop/donador/Gunz018.jpg" width="100" height="100" style="border: 2px solid #171516"></td>
																		<td width="178" valign="top">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="170">
																				<tr>
																					<td width="168" colspan="2">
																					<div align="left"><b><span class="item_name">Shotgun RedSize</span></b></td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Shotgun</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">210</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="166" colspan="2">
																					<div align="center">
																						<div align="center">
																							<table border="0" style="border-collapse: collapse" width="166" height="100%">
																								<tr>
																									<td width="55"><a href="index.php?do=giftitem&itemid=9&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_giftitem_off.jpg" width="50" height="23" id="img1790111" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1790111',/*url*/'images/btn_giftitem_on.jpg')"></a></td>
																									<td width="55"><a href="index.php?do=buyitem&itemid=9&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_buyitem3_off.jpg" width="52" height="23" id="img179111" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img179111',/*url*/'images/btn_buyitem3_on.jpg')"></a></td>
																									<td width="56"><a href="index.php?do=infoitem&itemid=9&cat=<?=$items[3][CatID]?>"><img border="0" src="images/btn_moreinfo3_off.jpg" width="56" height="23" id="img17921" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img17921',/*url*/'images/btn_moreinfo3_on.jpg')"></a></td>
																								</tr>
																							</table>
																						</div>
																					</td>
																				</tr>
																				<tr>
																					<td width="55">&nbsp;</td>
																					<td width="111">&nbsp;</td>
																				</tr>
																			</table>
																		</div>
																		</td>
																	</tr>
																	<tr>
																		<td width="8">&nbsp;</td>
																		<td width="95">&nbsp;</td>
																		<td width="178">&nbsp;</td>
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														</table>
												</div>
												</td>
											</tr>
										</table>

									</div>
									</td>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
						</div>
						</td>
					</tr>
				</table>