<?
    $res = mssql_query("SELECT TOP 4 * FROM ShopItems WHERE Opened = 1 ORDER BY CSSID DESC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $i[$count][ID]          = $a->CSSID;
        $i[$count][Name]        = $a->Name;
        $i[$count][ImageURL]    = $a->ImageURL;
        $i[$count][Slot]        = GetTypeByID($a->Slot);
        $i[$count][Sex]         = GetSexByID($a->Sex);
        $i[$count][Level]       = $a->Level;
        $i[$count][Price]       = $a->Price;

        $count++;
    }


    $res = mssql_query("SELECT TOP 4 * FROM ShopItems(nolock) ORDER BY CSSID DESC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $c[$count][ID]          = $a->CSSID;
        $c[$count][ImageURL]    = $a->ImageURL;
        $c[$count][Name]        = $a->Name;
        $c[$count][Slot]        = GetTypeByID($a->Slot);
        $c[$count][Sex]         = GetSexByID($a->Sex);
        $c[$count][Level]       = $a->Level;
        $c[$count][Price]       = $a->Price;

        $count++;
    }
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
						  <div align="center">
						    <? include "blocks/block_rankingu.php" ?>
                          </div>
						  <p>&nbsp; </p>
						  <div align="center">
                            <p>
                              <? include "blocks/block_rankingc.php" ?>
                            </p>
						    <p>&nbsp; </p>
					      </div>
						  </div>
					  </td>
						<td valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-repeat:no-repeat" width="419">
								<tr>
									<style type="text/css">
<!--
.Estilo3 {color: #373737}
.Estilo4 {color: #464646}

.boton{
  background-image:-moz-linear-gradient(top,#F00 0%,#C00 50%,#C00 100%); 
  background-image:-webkit-linear-gradient(top,#F00 0%,#C00 50%,#C00 100%); 
  border:3px #ffffff;
  border-radius:.5em;
  width:130px;
  height:44px;
  color:#B9B9B9;
  font-size:17px;
  -webkit-transition:.5s;
  -moz-transition:.5s;
}
.boton:hover{
  background-image:-moz-linear-gradient(top,#F00 0%,#C00 50%,#C00 100%); 
  background-image:-webkit-linear-gradient(top,#F00 0%,#C00 50%,#C00 100%); 
  color:#000;
}

-->
</style><td background="images/mn_info.png" height="76" style="background-image: url('images/mn_info.png'); background-repeat: no-repeat; background-position: center top" width="417"><center><h1 style="font-family:'Courier New', Courier, monospace">JUGADORES ONLINE <?php
$con = mssql_connect("DS9470\SQLEXPRESS","sa","gigiteamo10032013love#%#");
if (!$con)
{
die('Fallo en la coneccion..!: ' . mssql_error());
}
mssql_select_db("GunzDB");
$getcurp = mssql_query("SELECT CurrPlayer,MaxPlayer FROM ServerStatus");
$getcur = mssql_fetch_array($getcurp);
echo $getcur['CurrPlayer'];
?> <a href="index.php?do=download"><b><input type="button" value="STAR GAME" class="boton"/></b></a></h1>
						</center>												</td>
								</tr>
								
								<tr>
									<td style="background-image: url('images/md_information.jpg'); background-repeat: no-repeat; background-position:  left top; " height="156" width="415" valign="top">
								  <div align="center">
								  <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="417" height="151">
                                    <tr>
                                      <td width="200" height="24">&nbsp;</td>
                                      <td width="7" height="24">&nbsp;</td>
                                      <td width="204" height="24">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td width="200" valign="top"><table border="0" style="border-collapse: collapse" width="200" height="92%">
                                          <tr>
                                            <td width="4">&nbsp;</td>
                                            <td width="192" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><font color="#FFFFFF"> <a href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"><?=$n['Title']?>
                                                  </a></font></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                      <td width="7">&nbsp;</td>
                                      <td width="204" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                          <tr>
                                            <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><a href="index.php?do=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                    <?=$n['Title']?>
                                                  </font></a></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                    </tr>
                                  </table></td>
								<tr>
									<td height="305" width="417">
									<div align="center">
                                         <iframe width="417" height="305" src="http://www.youtube.com/embed/d6v-RR_dkys" frameborder="0" allowfullscreen></iframe>   
									</div>									</td>
								</tr>
								<tr>
									<td width="417">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-image: url('images/md_LI.jpg'); background-repeat: no-repeat; background-position: center top" height="305" width="417">
									<div align="center">
										<table border="0" style="border-collapse: collapse" width="417" height="100%">
											<tr>
												<td width="206" height="23">&nbsp;</td>
												<td width="207" height="23">&nbsp;</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/espadas/ord2.jpg" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		Katana RED</span></td>
																	</tr>
																	<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Katana</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">210</td>
																				</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=1">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1772" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1772'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buydonator&itemid=1">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1773" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1773'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
                                                        <tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/donador/icon_sparda.png" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		Sparda</span></td>
																	</tr>
																	<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Katana</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">220</td>
																				</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infodonator&itemid=3">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1774" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1774'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buydonator&itemid=3">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1775" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1775'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/donador/Gunz000.jpg" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		Shotgun Memes</span></td>
																	</tr>
																	<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Shotgun</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">220</td>
																				</tr>
																				<tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infodonator&itemid=6">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1776" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1776'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buydonator&itemid=6">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1777" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1777'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/donador/Gunz018.jpg" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																					<td width="168" colspan="2">
																					<div align="left"><span class="item_name">Shotgun RedSize</span></td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Tipo:</td>
																					<td width="111">Shotgun</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Sexo:</td>
																					<td width="111">All</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Nivel:</td>
																					<td width="111">25</td>
																				</tr>
																				<tr>
																					<td width="55" align="left"><font color="#FF0000">Precio:</td>
																					<td width="111">210</td>
																				</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoitem&itemid=9">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1778" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1778'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyitem&itemid=9">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1779" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1779'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="16">												</td>
												<td width="207" height="16">												</td>
											</tr>
										</table>
									</div>									</td>
								</tr>
							</table>
						</div>
						</td>
						<td width="171" valign="top">
						<div align="center"><? include "blocks/block_login.php";
                        ?></div></td>
					</tr>
				</table>