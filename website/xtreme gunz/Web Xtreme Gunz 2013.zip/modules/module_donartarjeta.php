<?
if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=donartarjeta");
    SetMessage("Donate", array("Para Donar Necesitas Loguearte"));
    header("Location: index.php?do=login");
    die();
}
?><head>
</head>


<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Donar por Tarjetas</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
									  <table width="408" height="100%" border="0" style="border-collapse: collapse; float:left">
									    <tbody>
									      <tr>
									        <td style="background-repeat: no-repeat; background-position: center top" width="380"><div style="text-align: left;" id="result_box" dir="ltr">
									          <p>Demon les da las Gracias a las 
									            donaciones que hacen 
									            nuestros usuarios. <br />
									            Para mantener los gastos de 
									            xTremeGunz, por lo que 
									            agradecemos su donaci&oacute;n </p>
									          <p> <strong>Donaciones Por Tarjetas Tel&eacute;fonicas&nbsp;<span id="IL_AD1">Movilnet</span>&nbsp;(Solo&nbsp;<span id="IL_AD3">Venezuela</span>)</strong><br />
									            <br />
									            <strong>Instrucciones:&nbsp;</strong><br />
									            <br />
									            1ro. Una vez obtenida la tarjeta debes enviar el c&oacute;digo 
									            que raspaste junto con los 4 ultimos digitos del c&oacute;digo de barras, por 
									            nuestro sistema de recarga que se presenta a continuaci&oacute;n:&nbsp;<br />
									            <br />
									            <strong>Imagenes Explicativas:</strong><br />
									            <br />
								              </p>
									          <div align="center"> <img src="./images/tarjeta_unicaBs_Bf25.jpg" alt="" /><br />
									            <img src="./images/tarjeta.png" alt="" /></div>
									          <p><br />
									            2. Como pueden observar el codigo que raspaste son 
									            16 digitos, el codigo de barras se encuentra abajo y a la derecha, es 
									            aquel que empieza por muchos ceros como ven en la imagen pero solo 
									            enviar&aacute;n los ultimos 4 digitos, en la imagen de ejemplo seria 6789.<br />
									            <br />
									            3. No debes botar tu tarjeta hasta que se haya confirmado el pago, 
									            xTremeGunz no se hace responsable por tarjetas que env&iacute;es y ya hayan 
									            sido usadas, en caso de presentarse este problema se cancelar&aacute;n 
									            las&nbsp;<span id="IL_AD10">transacciones</span>.&nbsp;<br />
									            <br />
									            4. El precio de los DCoins por este medio es el siguiente:<br />
								              </p>
									          <p></p>
									          <div align="center">
									            <form action="index.php?do=tarjeta" method="post" name="formT" id="formT" style="border: 1px solid #CECECE;padding-left: 10px;">
									              <p>
									                <input name="mmonto" value="15" type="hidden" />
								                  </p>
									              <center>
									                <br />
									                Comprar DCoins <br />
									                <br />
									                <select name="ccoins" onchange="updateForm2();">
		<option selected="selected" value="100">100 DCoins - 15bs</option>
		<option value="130">130 DCoins - 20bsf</option>
		<option value="170">170 DCoins - 25bsf</option>
		<option value="210">210 DCoins - 30bsf</option>
		<option value="270">270 DCoins - 40bsf</option>
		<option value="440">440 DCoins - 60bsf</option>
		<option value="850">850 DCoins - 120bsf</option>
								                    </select>
									                
									                <p></p>
									                <table border="0" width="100%">
									                  <tbody>
									                    <tr>
									                      <td align="center">C&oacute;digo que raspaste</td>
									                      <td align="center">4 Ult. C&oacute;digo de Barras</td>
								                        </tr>
									                    <tr>
									                      <td align="center" width="72%"><input name="c1" id="c1" size="4" maxlength="4" style="width:50px;height:20px;color:black;font-size:10pt; font-family:Verdana;text-align:center;" type="text" />
									                        -
									                        <input name="c2" id="c2" size="4" maxlength="4" style="width:50px;height:20px;color:black;font-size:10pt; font-family:Verdana;text-align:center;" type="text" />
									                        -
									                        <input name="c3" id="c3" size="4" maxlength="4" style="width:50px;height:20px;color:black;font-size:10pt; font-family:Verdana;text-align:center;" type="text" />
									                        -
									                        <input name="c4" id="c4" size="4" maxlength="4" style="width:50px;height:20px;color:black;font-size:10pt; font-family:Verdana;text-align:center;" type="text" /></td>
									                      <td align="center" width="28%"><input name="c5" id="c5" size="4" maxlength="4" style="width:50px;height:20px;background-color:yellow;color:black;font-size:10pt; font-family:Verdana;text-align:center;" alt="Es el que se encuentra abajo y a la derecha empieza por muchos ceros, coloca solo los &uacute;ltimos 4 digitos" type="text" /></td>
								                        </tr>
								                      </tbody>
								                    </table>
									                <p><font color="#00FF00"> Por favor verifique digito por 
									                  digito y envie correctamente la tarjeta, evite enviar tarjetas falsas 
									                  esto trae como consecuencia suspensi&oacute;n permanente de su cuenta en 
									                  nuestro servidor.</font></p>
									                <p>
									                  <input src="http://xtgunz.sytes.net/XTG/images/n4uc.png" name="submit" border="0" type="image" />
								                    </p>
									                <p> <font color="#FFFF00" face="Verdana, Geneva, sans-serif" size="4"> Atenci&oacute;n: no env&iacute;e tarjetas falsas o usadas de lo contrario su cuenta ser&aacute; baneada.</font></p>
									                <p></p>
								                  </center>
								                </form>
								              </div>
									          <p></p>
									          <p><br />
									            &nbsp; 15Bsf =&nbsp; &nbsp;100 Coins<br />
									            &nbsp; 20Bsf =&nbsp; &nbsp;130 Coins<br />
									            &nbsp; 25Bsf =&nbsp; &nbsp;170 Coins<br />
									            &nbsp; 30Bsf =&nbsp; &nbsp;210 Coins<br />
									            &nbsp; 40Bsf =&nbsp; &nbsp;270 Coins<br />
									            &nbsp; 60Bsf =&nbsp; &nbsp;440 Coins<br />
									            &nbsp; 120Bsf = 850 Coins <br />
								              </p>
									          <p></p>
									          <font color="#FFFF00"> 5. A los pocos minutos deben ser 
									            recargados tus coins, no envies 2 veces la misma tarjeta solo ten 
									            paciencia a que te recarguen, las tarjetas malas o usadas no proceden.</font></td>
								          </tr>
								        </tbody>
								      </table>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>