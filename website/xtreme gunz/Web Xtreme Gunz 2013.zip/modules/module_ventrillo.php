<?php
SetTitle("xTreme Gunz - Ventrillo");
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Server Status</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="500" border="0">
                                        <tr>
                                          <td><div align="center">Ventrillo</div></td>
                                        </tr>
                                        <tr>
                                          <td><table width="500" border="0">
                                            <tr>
                                              <td>Address:</td>
                                              <td><div align="center">xTreme Gunz (xTGunz)</div></td>
                                            </tr>
                                            <tr>
                                              <td>Puerto:</td>
                                              <td><div align="center">6000</div></td>
                                            </tr>
                                           
                                          </table></td>
                                        </tr>
                                      </table>
									</form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>