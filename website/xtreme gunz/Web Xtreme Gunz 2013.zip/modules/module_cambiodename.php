<?php
include("secure/include.php");
if($_SESSION[AID] == ""){
	SetURL("index.php?do=shop");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
	}
$price = 	200; // precio
$typedecoins = "DonatorCoins"; // Typo de table
$name	= 	"xTremeGunz - Cambiar Nombre"; // Name
/*____________________________________________
*/
$q		=	mssql_query("SELECT * From Account WHERE AID='".$_SESSION[AID]."'");
$acc = mssql_fetch_object($q);
$dcoins = $acc->$typedecoins;
$total	= $dcoins - $price;
$nombre = $_POST['userid'];
if(isset($_POST['comprar'])){
	if($dcoins < $price){
		SetMessage("Mensaje de la Tienda", array("No tienes suficientes DonadorCoins $total."));
        header("Location: index.php?do=shop");
        die();	
	}
		if($_POST['userid'] == ""){
		SetMessage("Mensaje de la Tienda", array("No dejes el campo vacio."));
        header("Location: index.php?do=shop");
        die();
		}
	mssql_query("UPDATE Character SET Name='".$_POST['userid']."' WHERE CID='".$_POST['id']."'");
	mssql_query("UPDATE Account SET Coins='".$total."' WHERE AID='".$_SESSION['AID']."'");
   msgbox("Su nombre fue cambiado a: ".$nombre.". Gracias","index.php?do=shop");
        header("Location: index.php?do=shop");
        die();
	
	}
?>

<table style="border: 0px; padding: 0px; width: 800px">
<tr>
<td width="800">&nbsp;</td>
<td width="778">
<table border="0" style="border-collapse: collapse" width="778">
<tr>
<td width="164" valign="top">
<table border="0" style="border-collapse: collapse" width="164">
<tr>
<td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;</td>
</tr>
<tr>
<td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
<div align="center">
        							<style type="text/css">

.button_example{
border:1px solid #616261; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-shadow: 1px 1px 0 rgba(0,0,0,0.3);font-weight:bold; text-align: center; color: #FFFFFF; background-color: #7d7e7d;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#7d7e7d), to(#0e0e0e));
 background-image: -webkit-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -moz-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -ms-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -o-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: linear-gradient(to bottom, #7d7e7d, #0e0e0e);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#7d7e7d, endColorstr=#0e0e0e);
}

.button_example:hover{
 border:1px solid #4a4b4a; background-color: #646464;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#646464), top(#282828));
 background-image: -webkit-linear-gradient(top, #646464, #282828);
 background-image: -moz-linear-gradient(top, #646464, #282828);
 background-image: -ms-linear-gradient(top, #646464, #282828);
 background-image: -o-linear-gradient(top, #646464, #282828);
 background-image: linear-gradient(to bottom, #646464, #282828);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#646464, endColorstr=#282828);
}
</style>
            <table border="0" style="border-collapse: collapse" width="164">
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shop">
                        
                        <form> <input type="button" class="button_example" value="Inicio" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopdonator">
                        
                        <form> <input type="button" class="button_example" value="Donator" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopevent">
                        
                        <form> <input type="button" class="button_example" value="Evento" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=buycolor">
                        
                        <form> <input type="button" class="button_example" value="Nombre a color" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=jjang">
                        
                        <form> <input type="button" class="button_example" value="Jjang" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=cambiodename">
                        
                        <form> <input type="button" class="button_example" value="Cambiar nombre" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            
            </table>
        						</div>
</td>
</tr>
<tr>
<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
<div align="center"><br><br><br><br><br><br><br><br></div>
</td>
</tr>
</table>
</td>
<td width="599" valign="top">
<div align="center">
<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
<tr>
<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="7">&nbsp;</td>
<td width="583" valign="top">
<div align="center">
<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%">
<tr>
<td>
<div align="center">
<form method="POST" action="index.php?do=cambiodename" name="frmBuy">
<table border="0" style="border-collapse: collapse" width="579">
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="458" colspan="2">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104" valign="top">
<input type="hidden" name="comprar" />
<div align="center">
<img alt="" border="0" src="http://xtgunz.sytes.net/XTG/images/shop/changename.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></div>
</td>
<td width="458" colspan="2">
<div align="center">
<table border="0" style="border-collapse: collapse" width="458" height="100%">
<tr>
<td width="19">&nbsp;</td>
<td width="435" colspan="2">
<div align="left">
<b><font size="2"><?=$name?></font></b>
</div>
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="61" align="left">Tipo:</td>
<td width="372" align="left">Especial</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="61" align="left">Precio:</td>
<td width="372" align="left">
<span id="currentprice"><?=$price?></span> DonadorCoins
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">
<div align="center">
  <table width="317" border="0">
    <tr>
    <th width="158" scope="col">Selecciona tu personaje</th>
    <td width="143" scope="col"><select name="id">
      <?php
$que = mssql_query("SELECT * From Character WHERE AID='".$_SESSION[AID]."'");
while($char = mssql_fetch_object($que)){
?>
      <option value="<?=$char->CID?>">
        <?=$char->Name?>
        </option>
      <? } ?>
    </select></td>
  </tr>
  <tr>
    <td> Nuevo nombre:</td>
    <td><input name="userid" class="textLogin" tabindex="1" size="16" maxlength="12" /></td>
  </tr>
</table>
</div>
<div align="center"></div>
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
<td width="435" align="left" rowspan="4">
<div align="center">
<table border="0" style="border-collapse: collapse" width="435" height="66">
<tr>
<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
<div align="center">
<table border="0" style="border-collapse: collapse" width="419" height="100%">
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Total:</td>
<td width="62" align="left"><?=$price?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Balance Actual</td>
<td width="62" align="left"><?=$dcoins?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Despues:</td>
<td width="62" align="left"><?=$total?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="413" colspan="4" height="1"></td>
</tr>
</table>
</div>
</td>
<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="569" colspan="4">&nbsp;</td>
</tr>
</table>

</form>
</div>
</td>
</tr>
</table>
</div>
</td>
<td width="7">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">
<div align="center">
<a href="javascript:document.frmBuy.submit();">
<img alt="" border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_buyitem2_off.jpg'" onmouseover="this.src='images/btn_buyitem2_on.jpg'">
</a>
<a href="index.php?do=shopitem">
<img alt="" border="0" src="images/btn_cancel_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_cancel_off.jpg'" onmouseover="this.src='images/btn_cancel_on.jpg'">
</a>
</div>
</td>
</tr>
<tr>
<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
</td>
<td width="12">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
</table>