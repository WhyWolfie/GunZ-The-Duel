<?php
SetTitle("Compra Jjang - xTremeGunz");
$precio = 50;			// Aqui el precio es decir el costo que tendra  el Grado.
$coins	= "EventCoins";  // Aqui el tipo de Coins que usas Como DonatorCoins, EventCoins

// SI QUIERES VENDER JJANG es 2 y si quieres vender MOD es 254 y si quieres vender BAN es 253 XDDDDDD
$grado = 2;



///////////////////////////////////////////









/*  NO TOCAR.  */
	if($_SESSION['AID'] == ""){
					msgbox("Logueate antes de entrar aqui.","index.php");
					die();
					}
					$g = (int)$grado;
					$p = (int)$precio;
					$aid = (int)$_SESSION['AID'];
				if(!isset($_POST['submit'])){
					
?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Compra de Jjang</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
                                    <form method="post" name="xd">
								<table align="center">
                                <tr>
                                <td width="266" align="center">
                                Compra de Jjang<br /><b>Precio: </b><?=$precio?><br /><style type="text/css">

.button_example{
border:1px solid #616261; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-shadow: 1px 1px 0 rgba(0,0,0,0.3);font-weight:bold; text-align: center; color: #FFFFFF; background-color: #7d7e7d;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#7d7e7d), to(#0e0e0e));
 background-image: -webkit-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -moz-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -ms-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -o-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: linear-gradient(to bottom, #7d7e7d, #0e0e0e);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#7d7e7d, endColorstr=#0e0e0e);
}

.button_example:hover{
 border:1px solid #4a4b4a; background-color: #646464;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#646464), top(#282828));
 background-image: -webkit-linear-gradient(top, #646464, #282828);
 background-image: -moz-linear-gradient(top, #646464, #282828);
 background-image: -ms-linear-gradient(top, #646464, #282828);
 background-image: -o-linear-gradient(top, #646464, #282828);
 background-image: linear-gradient(to bottom, #646464, #282828);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#646464, endColorstr=#282828);
}
</style>
                                <input class="button_example" type="submit" name="submit" value="Comprar Jjang" /><br><a href="index.php?do=shop" ><form><input class="button_example" type="button" name="submit" value="Volver" /></form></a>
                                </td>
                                
                                </table>
                                </form>   
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>
                
                <?PHP
								
					}else{
						$q = "SELECT $coins From Account WHERE AID='$aid'";
						$r = mssql_fetch_row(mssql_query($q));
						if($r[0] < $precio){
							$asd = $r[0];
							msgbox("No tiene Coins suficientes para hacer la compra.","index.php");
							die();
							}
						$res = "UPDATE Account SET UGradeID='2', $coins=$coins-$precio WHERE AID='$aid'";
						mssql_query($res);
						msgbox("Compra con exito. Gracias por su compra.","index.php");
						die();
						}
				
				?>