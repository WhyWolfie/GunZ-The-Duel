<?php
// Config Siganture
$url	=	"http://xtgunz.sytes.net/XTG";
$img 	=	"images/sing.png";

?>