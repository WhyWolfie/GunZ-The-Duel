<?
/// CONFIG   Color //////////////////////
$costo = 200;

////////////////////////////////////////

SetTitle("Compra name Color");
if($_SESSION['AID'] == "")
{
	SetMessage("Mensaje de Tienda", array("Logeate Primero...!"));
	header("Location: index.php?do=login");
	die();	
}
if(isset($_POST['submit'])){
$color	= $_POST['colorid'];
$aid 	= $_SESSION['AID'];
$q 		= mssql_query("SELECT DonatorCoins From Account WHERE AID='$aid'");
$acc 	= mssql_fetch_object($q);
$dcoins = $acc->DonatorCoins;
$total = $dcoins - $costo ;
if($dcoins < $costo){
SetMessage("Mensaje de Tienda", array("No tiene $dcoins suficiente DonatorCoins para realizar la compra."));
	header("Location: index.php?do=shop");
	die();
}
if(!is_numeric($color)){
SetMessage("Mensaje de Tienda", array("Error al hacer la compra1"));
	header("Location: index.php?do=shop");
	die();
}
if(!is_numeric($aid)){
	SetMessage("Mensaje de Tienda", array("Error al hacer la compra2"));
	header("Location: index.php?do=shop");
	die();
}else{
mssql_query("UPDATE Account SET DonatorCoins='$total' WHERE AID='$aid'");
mssql_query("UPDATE Account SET UGradeID='$color'  WHERE AID='$aid'");
SetMessage("Mensaje de Tienda", array("Compra de name color con exito."));
	header("Location: index.php?do=shop");
	die();
	}
}
?>
<form method="POST">
<html>

<head>
   <link rel="stylesheet" type="text/css" href="style.css">

  </head>

<body style="background: #373737 url('./images/headbg.jpg') no-repeat center top" bgcolor="black">
<div align="center">
    <table style="border: 0px; border-collapse: collapse; width: 90%">
    <tr>
        <td align="center">&nbsp;</td>
    </tr>
    <tr>
        <td>

        <div align="center">
		            
            <table style="border: 0px; padding: 0px; width: 800px">
            
            <tr>
                <td width="10">&nbsp;</td>
                <td width="778">
                    <table border="0" style="border-collapse: collapse" width="778">

<tr>
    <td width="164" valign="top">
    <table border="0" style="border-collapse: collapse" width="164">
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;</td>
    </tr>
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
        <div align="center">
<style type="text/css">

.button_example{
border:1px solid #616261; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-shadow: 1px 1px 0 rgba(0,0,0,0.3);font-weight:bold; text-align: center; color: #FFFFFF; background-color: #7d7e7d;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#7d7e7d), to(#0e0e0e));
 background-image: -webkit-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -moz-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -ms-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -o-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: linear-gradient(to bottom, #7d7e7d, #0e0e0e);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#7d7e7d, endColorstr=#0e0e0e);
}

.button_example:hover{
 border:1px solid #4a4b4a; background-color: #646464;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#646464), top(#282828));
 background-image: -webkit-linear-gradient(top, #646464, #282828);
 background-image: -moz-linear-gradient(top, #646464, #282828);
 background-image: -ms-linear-gradient(top, #646464, #282828);
 background-image: -o-linear-gradient(top, #646464, #282828);
 background-image: linear-gradient(to bottom, #646464, #282828);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#646464, endColorstr=#282828);
}
</style>
            <table border="0" style="border-collapse: collapse" width="164">
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shop">
                        
                        <form> <input type="button" class="button_example" value="Inicio" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopdonator">
                        
                        <form> <input type="button" class="button_example" value="Donator" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=shopevent">
                        
                        <form> <input type="button" class="button_example" value="Evento" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=buycolor">
                        
                        <form> <input type="button" class="button_example" value="Nombre a color" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
			<tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=jjang">
                        
                        <form> <input type="button" class="button_example" value="Jjang" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            <tr>
                <td width="14">&nbsp;</td>
                <td width="127">
                    <a href="index.php?do=cambiodename">
                        
                        <form> <input type="button" class="button_example" value="Cambiar nombre" /> </form>
                        
                    </a>
                </td>
                <td width="17">&nbsp;</td>

            </tr>
            </table>
        </div>
        </td>
    </tr>
    <tr>
        <td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
            <div align="center"><br><br><br><br><br><br><br><br></div>
        </td>

    </tr>
    </table>
    </td>
	<td width="599" valign="top">
	<div align="center">
    <table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
<tr>
	<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
</tr>
<tr>

	<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
	<td width="7">&nbsp;</td>
	<td width="583" valign="top">
	<div align="center">
		<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%">
    	<tr>
    		<td>
    		<div align="center">

    			                <table border="0" style="border-collapse: collapse" width="579">
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="458" colspan="2">&nbsp;</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>

  					<td width="104" valign="top">
                        <STYLE type="text/css">
                        OPTION{background-color: #dff9ff }
                        OPTION.celeste{color:#0095FF; font-weight: bold }
                        OPTION.morado{color:#440269; font-weight: bold }
                        OPTION.rosado{color:#FB00FF; font-weight: bold }
                        OPTION.naranja{color:#FF6600; font-weight: bold }
						OPTION.amarillo{color:#EEFF00; font-weight: bold }
						OPTION.plata{color:#DFDFDF; font-weight: bold }
						OPTION.humo{color:#494949; font-weight: bold }
						OPTION.negro{color:#000000; font-weight: bold }
						OPTION.azul{color:#0015FF; font-weight: bold }
                        </STYLE>
                        <div align="center">
      					    <img alt="" border="0" src="images/shop/changenamecolor.gif" width="100" height="100" style="border: 2px solid #1D1B1C">
                        </div>
                    </td>
  					<td width="458" colspan="2">
  					<div align="center">

  						<table border="0" style="border-collapse: collapse" width="458" height="100%">
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="435" colspan="2">
  								<div align="left">
  								    <b><font size="2">Nombre de Color</font></b>
                                </div>
                                </td>

  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="61" align="left">Tipo:</td>
  								<td width="372" align="left">Especial</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>

  								<td width="61" align="left">Precio:</td>
  								<td width="372" align="left">
  								    <span id="currentprice"><?=$costo?></span>
                                </td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  								<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">

  								<div align="center">
                                    Selecciona el Color para tus Personajes:&nbsp;&nbsp;
                                   
  								    
                                    <select class="rose" name="colorid" color="#FFFFFF">
                                      <option selected class="celeste" value="3">Celeste</option>
                                      <option class="morado" value="4">Morado</option>
                                      <option class="rosado" value="5">Rosado</option>
                                      <option class="naranja" value="6">Naranja</option>
                                      <option class="amarillo" value="10">Amarillo</option>
									  <option class="plata" value="8">Plata</option>
                                      <option class="humo" value="9">Humo</option>
                                      <option class="negro" value="7">Negro</option>
									  <option class="azul" value="11">Azul</option>
                                    </select>
  								</div>
  								</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>

  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>
  							<tr>
  								<td width="19">&nbsp;</td>
  							</tr>

  						</table>
  					</div>
  					</td>
  				</tr>
  				<tr>
  					<td width="11">&nbsp;</td>
  					<td width="104">&nbsp;</td>
  					<td width="19">&nbsp;</td>
  					<td width="435" align="left" rowspan="4">

  					<div align="center">
  						<table border="0" style="border-collapse: collapse" width="435" height="66">
  							<tr>
  								<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
  								<div align="center">
  									<table border="0" style="border-collapse: collapse" width="419" height="16%">
  										<tr>
  											<td width="216">&nbsp;</td>
  											<td width="102" align="left">Precio</td>

  											<td width="67" align="left"><?=$costo?> DCoins</td>
  											<td width="16">&nbsp;</td>
  										</tr>
  										<tr>
                                        <? $wa = mssql_query("SELECT * From Account WHERE AID='$_SESSION[AID]'");
										$cuen = mssql_fetch_object($wa);
										$donatorcoins = $cuen->DonatorCoins?>
  											<td width="216">&nbsp;</td>
  											<td width="102" align="left">Despues</td>
  											<td width="67" align="left"><?=$donatorcoins- $costo?></td>

  											<td width="16">&nbsp;</td>
  										</tr>
  									
  										<tr>
  											<td colspan="4" height="1"></td>
  										</tr>
  									</table>
  								</div>
  								</td>
  								<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
  							</tr>
  						</table>

  					</div>
  					</td>
  				</tr>
  							
  				<tr>
  					<td width="569" colspan="4">&nbsp;</td>
  				</tr>
    			</table>
    			</form>
    		</div>
    		</td>
    	</tr>
		</table>

	</div>
	</td>
	<td width="7">&nbsp;</td>
</tr>

<tr>
	<td width="597" colspan="3">
	<div align="center">
	  <p><style type="text/css">

.button_example{
border:1px solid #616261; -webkit-border-radius: 3px; -moz-border-radius: 3px;border-radius: 3px;font-family:arial, helvetica, sans-serif; padding: 10px 10px 10px 10px; text-shadow: 1px 1px 0 rgba(0,0,0,0.3);font-weight:bold; text-align: center; color: #FFFFFF; background-color: #7d7e7d;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#7d7e7d), to(#0e0e0e));
 background-image: -webkit-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -moz-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -ms-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: -o-linear-gradient(top, #7d7e7d, #0e0e0e);
 background-image: linear-gradient(to bottom, #7d7e7d, #0e0e0e);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#7d7e7d, endColorstr=#0e0e0e);
}

.button_example:hover{
 border:1px solid #4a4b4a; background-color: #646464;
 background-image: -webkit-gradient(linear, left top, left bottom, from(#646464), top(#282828));
 background-image: -webkit-linear-gradient(top, #646464, #282828);
 background-image: -moz-linear-gradient(top, #646464, #282828);
 background-image: -ms-linear-gradient(top, #646464, #282828);
 background-image: -o-linear-gradient(top, #646464, #282828);
 background-image: linear-gradient(to bottom, #646464, #282828);filter:progid:DXImageTransform.Microsoft.gradient(GradientType=0,startColorstr=#646464, endColorstr=#282828);
}
</style>
	    <input class="button_example" name="submit" type="submit" value="Comprar Name Color">
	   <a href="?do=shop"> <input class="button_example" name="salir" type="button" style="background:#999" value="Salir" ></a>
	    
	    </form>
	    </p>
	</div>
    </td>
</tr>
<tr>
	<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>

</tr>
</table>
    </div>
    </td>
</tr>
</table>
                </td>
                <td width="12">&nbsp;</td>
            </tr>
           
            </table>
        </div>
        </td>
    </tr>

    </table>
</div>



</body>

</html>

