<?
// Conex�o & Protect -- N�o mexer 
include "config/config.php";
$cnn=@mssql_connect($iphost,$usersql,$senhasql) or die('Error al conectar con el sql');
$db=@mssql_select_db($dbsql,$cnn) or die('Erro al conectar la database');
include 'secure/sql_check.php';
include 'secure/anti_inject.php';
/////////////////////////////////
?>