﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Error 404</title>
<link type="text/css" rel="stylesheet" href="global.css" />
<script type="text/javascript" src="drag.js"></script>
<style type="text/css">
<!--
.Estilo1 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 16pt;
}
.Estilo2 {
	color: #FFFFFF;
	font-size: 8pt;
}
-->
</style>
</head>

<body>
<div class="Estilo1" id="banner"><p><br>Error 404</div>
		<div id="main_top"></div>
		<div id="main_mid">

		Se ha detectado una Posible amenaza al entrar a esta Direccion Web. 
		<P>Tu IP: <strong><? 
$archivo = "logerror404.txt"; //Esto creará el Archivo donde guarda las ips
$manejador = fopen($archivo,"a") or die("Imposible abrir el archivo\n"); //Esto abre el archivo
$ip = $_SERVER['REMOTE_ADDR']; //Esto muestra la ip
$fecha= ("- "); // Esto Separa las IPs
fwrite($manejador,$ip.' '.$fecha.' '.$url); //Esto muestra la ip 
echo "$ip" //Esto muestra un texto

?></strong> Ha se sido guardada

Recuerda que al entrar a esta direccion web se guarda tu direccion de ip.		
		</div>
		<div id="main_bot"></div>
</body><span class="Estilo2">Todos los Derechos Reservados, <strong>xTremeGunz</strong>. Proteccion Para carpetas Hecho por <strong><span style="color:#FF0000">iShalom</span></strong></span>
</html>