<?

if(!$_SESSION['AID'] == ""){
    msgbox("You already have an account.","index.php");
}

$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = antisql($_POST['userid']);
    $email = antisql($_POST['email']);
    $pw1 = antisql($_POST['pw1']);
    $pw2 = antisql($_POST['pw2']);
    $country = antisql($_POST['country']);
    $sq = antisql($_POST['sq']);
    $sa = antisql($_POST['sa']);
    $name = antisql($_POST['name']);
    $zip = antisql($_POST['zip']);
    $age = antisql($_POST['age']);
    $sex = antisql($_POST['sex']);
    $address = antisql($_POST['address']);


        $res = mssql_query("SELECT * FROM Account WHERE email = '".$email."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="Email already used.</br>";
            $er = 1;
        }

        $res = mssql_query("SELECT * FROM Login WHERE UserID = '".$user."'");
        if (mssql_num_rows($res) >= 1){
            $errorcode.="UserID already used.</br>";
            $er = 1;
        }

        if($pw1 == $pw2){
            $lol = "xDDD";
        }else{
            $errorcode.="Passwords mismatch/br>";
            $er = 1;
        }

        if($user == ""){
            $errorcode.="Enter a User ID.</br>";
            $er = 1;
        }

        if($email == ""){
            $errorcode.="Enter an E-Mail.</br>";
            $er = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Choose a password with al least 6 characters.</br>";
            $er =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please fill both password fields.</br>";
            $er = 1;
        }

        if($sq == ""){
            $errorcode.="Enter a secret question.</br>";
            $er =1;
        }

        if($sa == ""){
            $errorcode.="Enter a secret answer.</br>";
            $er = 1;
        }

        if($er == 0){
            $registered = 1;
            mssql_query("INSERT INTO Account (UserID, Cert, Name, Email, Age, Sex, UGradeID, PGradeID, RegDate, Country, sa, sq)Values ('$user', NULL, '$name','$email','$age', '$sex', 0, 0, GETDATE(),'$country', '$sa', '$sq')");
	    $res = mssql_query("SELECT * FROM Account WHERE UserID = '$user'");
	    $usr = mssql_fetch_assoc($res);
	    $aid = $usr['AID'];
            mssql_query("INSERT INTO Login ([UserID],[AID],[Password],[euCoins])VALUES('$user','$aid','$pw1',0)");
        }else{
            $errorbox = ErrorBox($errorcode);
        }
}



if ($registered == 0){
?>

<form name="reg" method="POST" action="index.php?do=register"><body bgcolor="#323232">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
							  <td background="images/cont_bg.jpg">

								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="36">&nbsp;</td>
											<td width="436" colspan="2">
											<img border="0" src="images/inf/createaccount.jpg" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>

											<td width="145">&nbsp;
											</td>
											<td width="289">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>

											<td width="289">
											<font size="1" color="#4D4D4D">The fields marked with an * are required</font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;
											</td>
											<td width="289">&nbsp;

											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145" valign="middle">
											�<span lang="es">
											User ID<font color="#FF9933">*</font></span></td>

											<td width="289">
											<input type="text" name="userid" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145">
											�<span lang="es">
											E-Mail<font color="#FF9933">*</font></span></td>
											<td width="289">
											<input type="text" name="email" size="20"></td>
											<td width="8">&nbsp;</td>

										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">
											�<span lang="es">

											Password<font color="#FF9933">*</font></span></td>
											<td width="289">
											<input type="password" name="pw1" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">

											<font color="#4D4D4D">
											<span style="font-size: 7pt">Minimum 6 characters in length</span></font></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">
											�<span lang="es">
											Repeat password<font color="#FF9933">*</font></span></td>

											<td width="289">
											<input type="password" name="pw2" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145" valign="middle">
											�<span lang="es">
											Country<font color="#FF9933">*</font></span></td>
											<td width="289">
											<select id="dropDownCountrySelector" name="country" class onChange="refreshCountry(this, false);">
											<option value="US" selected="selected">

											United States</option>
											<option value="AL">Albania</option>
											<option value="DZ">Algeria</option>
											<option value="AD">Andorra</option>
											<option value="AO">Angola</option>
											<option value="AI">Anguilla</option>

											<option value="AG">Antigua and
											Barbuda</option>
											<option value="AR">Argentina
											</option>
											<option value="AM">Armenia</option>
											<option value="AW">Aruba</option>
											<option value="AU">Australia
											</option>
											<option value="AT">Austria</option>

											<option value="AZ">Azerbaijan
											Republic</option>
											<option value="BS">Bahamas</option>
											<option value="BH">Bahrain</option>
											<option value="BB">Barbados</option>
											<option value="BE">Belgium</option>
											<option value="BZ">Belize</option>

											<option value="BJ">Benin</option>
											<option value="BM">Bermuda</option>
											<option value="BT">Bhutan</option>
											<option value="BO">Bolivia</option>
											<option value="BA">Bosnia and
											Herzegovina</option>
											<option value="BW">Botswana</option>

											<option value="BR">Brazil</option>
											<option value="VG">British Virgin
											Islands</option>
											<option value="BN">Brunei</option>
											<option value="BG">Bulgaria</option>
											<option value="BF">Burkina Faso
											</option>
											<option value="BI">Burundi</option>

											<option value="KH">Cambodia</option>
											<option value="CA">Canada</option>
											<option value="CV">Cape Verde
											</option>
											<option value="KY">Cayman Islands
											</option>
											<option value="TD">Chad</option>
											<option value="CL">Chile</option>

											<option value="C2">China Worldwide
											</option>
											<option value="CO">Colombia</option>
											<option value="KM">Comoros</option>
											<option value="CK">Cook Islands
											</option>
											<option value="CR">Costa Rica
											</option>
											<option value="HR">Croatia</option>

											<option value="CY">Cyprus</option>
											<option value="CZ">Czech Republic
											</option>
											<option value="CD">Democratic
											Republic of the Congo</option>
											<option value="DK">Denmark</option>
											<option value="DJ">Djibouti</option>
											<option value="DM">Dominica</option>

											<option value="DO">Dominican
											Republic</option>
											<option value="EC">Ecuador</option>
											<option value="SV">El Salvador
											</option>
											<option value="ER">Eritrea</option>
											<option value="EE">Estonia</option>
											<option value="ET">Ethiopia</option>

											<option value="FK">Falkland Islands
											</option>
											<option value="FO">Faroe Islands
											</option>
											<option value="FM">Federated States
											of Micronesia</option>
											<option value="FJ">Fiji</option>
											<option value="FI">Finland</option>
											<option value="FR">France</option>

											<option value="GF">French Guiana
											</option>
											<option value="PF">French Polynesia
											</option>
											<option value="GA">Gabon Republic
											</option>
											<option value="GM">Gambia</option>
											<option value="DE">Germany</option>
											<option value="GI">Gibraltar
											</option>

											<option value="GR">Greece</option>
											<option value="GL">Greenland
											</option>
											<option value="GD">Grenada</option>
											<option value="GP">Guadeloupe
											</option>
											<option value="GT">Guatemala
											</option>
											<option value="GN">Guinea</option>

											<option value="GW">Guinea Bissau
											</option>
											<option value="GY">Guyana</option>
											<option value="HN">Honduras</option>
											<option value="HK">Hong Kong
											</option>
											<option value="HU">Hungary</option>
											<option value="IS">Iceland</option>

											<option value="IN">India</option>
											<option value="ID">Indonesia
											</option>
											<option value="IE">Ireland</option>
											<option value="IL">Israel</option>
											<option value="IT">Italy</option>
											<option value="JM">Jamaica</option>

											<option value="JP">Japan</option>
											<option value="JO">Jordan</option>
											<option value="KZ">Kazakhstan
											</option>
											<option value="KE">Kenya</option>
											<option value="KI">Kiribati</option>
											<option value="KW">Kuwait</option>

											<option value="KG">Kyrgyzstan
											</option>
											<option value="LA">Laos</option>
											<option value="LV">Latvia</option>
											<option value="LS">Lesotho</option>
											<option value="LI">Liechtenstein
											</option>
											<option value="LT">Lithuania
											</option>

											<option value="LU">Luxembourg
											</option>
											<option value="MG">Madagascar
											</option>
											<option value="MW">Malawi</option>
											<option value="MY">Malaysia</option>
											<option value="MV">Maldives</option>
											<option value="ML">Mali</option>

											<option value="MT">Malta</option>
											<option value="MH">Marshall Islands
											</option>
											<option value="MQ">Martinique
											</option>
											<option value="MR">Mauritania
											</option>
											<option value="MU">Mauritius
											</option>
											<option value="YT">Mayotte</option>

											<option value="MX">Mexico</option>
											<option value="MN">Mongolia</option>
											<option value="MS">Montserrat
											</option>
											<option value="MA">Morocco</option>
											<option value="MZ">Mozambique
											</option>
											<option value="NA">Namibia</option>

											<option value="NR">Nauru</option>
											<option value="NP">Nepal</option>
											<option value="NL">Netherlands
											</option>
											<option value="AN">Netherlands
											Antilles</option>
											<option value="NC">New Caledonia
											</option>
											<option value="NZ">New Zealand
											</option>

											<option value="NI">Nicaragua
											</option>
											<option value="NE">Niger</option>
											<option value="NU">Niue</option>
											<option value="NF">Norfolk Island
											</option>
											<option value="NO">Norway</option>
											<option value="OM">Oman</option>

											<option value="PW">Palau</option>
											<option value="PA">Panama</option>
											<option value="PG">Papua New Guinea
											</option>
											<option value="PE">Peru</option>
											<option value="PH">Philippines
											</option>
											<option value="PN">Pitcairn Islands
											</option>

											<option value="PL">Poland</option>
											<option value="PT">Portugal</option>
											<option value="QA">Qatar</option>
											<option value="CG">Republic of the
											Congo</option>
											<option value="RE">Reunion</option>
											<option value="RO">Romania</option>

											<option value="RU">Russia</option>
											<option value="RW">Rwanda</option>
											<option value="VC">Saint Vincent and
											the Grenadines</option>
											<option value="WS">Samoa</option>
											<option value="SM">San Marino
											</option>
											<option value="ST">S�o Tom� and
											Pr�ncipe</option>

											<option value="SA">Saudi Arabia
											</option>
											<option value="SN">Senegal</option>
											<option value="SC">Seychelles
											</option>
											<option value="SL">Sierra Leone
											</option>
											<option value="SG">Singapore
											</option>
											<option value="SK">Slovakia</option>

											<option value="SI">Slovenia</option>
											<option value="SB">Solomon Islands
											</option>
											<option value="SO">Somalia</option>
											<option value="ZA">South Africa
											</option>
											<option value="KR">South Korea
											</option>
											<option value="ES">Spain</option>

											<option value="LK">Sri Lanka
											</option>
											<option value="SH">St. Helena
											</option>
											<option value="KN">St. Kitts and
											Nevis</option>
											<option value="LC">St. Lucia
											</option>
											<option value="PM">St. Pierre and
											Miquelon</option>
											<option value="SR">Suriname</option>

											<option value="SJ">Svalbard and Jan
											Mayen Islands</option>
											<option value="SZ">Swaziland
											</option>
											<option value="SE">Sweden</option>
											<option value="CH">Switzerland
											</option>
											<option value="TW">Taiwan</option>
											<option value="TJ">Tajikistan
											</option>

											<option value="TZ">Tanzania</option>
											<option value="TH">Thailand</option>
											<option value="TG">Togo</option>
											<option value="TO">Tonga</option>
											<option value="TT">Trinidad and
											Tobago</option>
											<option value="TN">Tunisia</option>

											<option value="TR">Turkey</option>
											<option value="TM">Turkmenistan
											</option>
											<option value="TC">Turks and Caicos
											Islands</option>
											<option value="TV">Tuvalu</option>
											<option value="UG">Uganda</option>
											<option value="UA">Ukraine</option>

											<option value="AE">United Arab
											Emirates</option>
											<option value="GB">United Kingdom
											</option>
											<option value="UY">Uruguay</option>
											<option value="VU">Vanuatu</option>
											<option value="VA">Vatican City
											State</option>
											<option value="VE">Venezuela
											</option>

											<option value="VN">Vietnam</option>
											<option value="WF">Wallis and Futuna
											Islands</option>
											<option value="YE">Yemen</option>
											<option value="ZM">Zambia</option>
											</select></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<hr color="#323232" width="96%"></td>
											<td width="8">&nbsp;</td>

										</tr>
										<tr>
											<td width="145">�<span lang="es">
											Name</span></td>
											<td width="289">
											<input type="text" name="name" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">�<span lang="es"> 
											Age</span></td>

											<td width="289">
											<select size="1" name="age">
											<option value='1'>1</option>
<option value='2'>2</option>
<option value='3'>3</option>
<option value='4'>4</option>
<option value='5'>5</option>
<option value='6'>6</option>

<option value='7'>7</option>
<option value='8'>8</option>
<option value='9'>9</option>

<option value='10'>10</option>
<option value='11'>11</option>
<option value='12'>12</option>
<option value='13'>13</option>
<option value='14'>14</option>

<option value='15'>15</option>
<option value='16'>16</option>
<option value='17'>17</option>
<option value='18'>18</option>

<option value='19'>19</option>
<option value='20'>20</option>
<option value='21'>21</option>
<option value='22'>22</option>

<option value='23'>23</option>
<option value='24'>24</option>
<option value='25'>25</option>
<option value='26'>26</option>
<option value='27'>27</option>

<option value='28'>28</option>
<option value='29'>29</option>
<option value='30'>30</option>

<option value='31'>31</option>
<option value='32'>32</option>
<option value='33'>33</option>
<option value='34'>34</option>
<option value='35'>35</option>
<option value='36'>36</option>

<option value='37'>37</option>
<option value='38'>38</option>

<option value='39'>39</option>
<option value='40'>40</option>
<option value='41'>41</option>
<option value='42'>42</option>
<option value='43'>43</option>
<option value='44'>44</option>
<option value='45'>45</option>

<option value='46'>46</option>

<option value='47'>47</option>
<option value='48'>48</option>
<option value='49'>49</option>
<option value='50'>50</option>
<option value='51'>51</option>
<option value='52'>52</option>
<option value='53'>53</option>
<option value='54'>54</option>

<option value='55'>55</option>
<option value='56'>56</option>
<option value='57'>57</option>
<option value='58'>58</option>
<option value='59'>59</option>
<option value='60'>60</option>
<option value='61'>61</option>
<option value='62'>62</option>
<option value='63'>63</option>

<option value='64'>64</option>
<option value='65'>65</option>
<option value='66'>66</option>
<option value='67'>67</option>
<option value='68'>68</option>
<option value='69'>69</option>
<option value='70'>70</option>
<option value='71'>71</option>

<option value='72'>72</option>

<option value='73'>73</option>
<option value='74'>74</option>
<option value='75'>75</option>
<option value='76'>76</option>
<option value='77'>77</option>
<option value='78'>78</option>
<option value='79'>79</option>

<option value='80'>80</option>
<option value='81'>81</option>

<option value='82'>82</option>
<option value='83'>83</option>
<option value='84'>84</option>
<option value='85'>85</option>
<option value='86'>86</option>
<option value='87'>87</option>

<option value='88'>88</option>
<option value='89'>89</option>
<option value='90'>90</option>

<option value='91'>91</option>
<option value='92'>92</option>
<option value='93'>93</option>
<option value='94'>94</option>
<option value='95'>95</option>

<option value='96'>96</option>
<option value='97'>97</option>
<option value='98'>98</option>
<option value='99'>99</option>

<option value='100'>100</option>
											</select></td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">�<span lang="es">
											Sex</span></td>

											<td width="289">
											<select size="1" name="sex">
											<option selected value="Male">Male
											</option>
											<option value="Female">Female
											</option>
											</select></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>

											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">�<span lang="es">
											</span>ZIP Code / CP</td>
											<td width="289">

											<input type="text" name="zip" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>

											<td width="145">�<span lang="es">
											Address</span></td>
											<td width="289">
											<input type="text" name="address" size="20"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>

											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="436" colspan="2">
											<hr color="#323232" width="96%"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>

											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">� Secret Question<font color="#FF9933">*</font></td>
											<td width="289">
											<input type="text" name="sq" size="34"></td>

											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">
											<font color="#4D4D4D">
											<span style="font-size: 7pt">The Secret question is used to Retrieve your password</span></font></td>
											<td width="8">&nbsp;</td>

										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">� Security Answer<font color="#FF9933">*</font></td>

											<td width="289">
											<input type="text" name="sa" size="34"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="145">&nbsp;</td>
											<td width="289">&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>

										<tr>
											<td width="434" colspan="2">
											<hr color="#323232" width="96%"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">
											<center>
											<input type="submit" value="Register" name="submit"></center></td>

											<td width="8">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>

						</table>
					</div></form>

<?
}else{
?>
<head>
<meta http-equiv="Content-Language" content="es">
</head>

<form name="reg" method="POST" action="index.php?do=register"><body bgcolor="#323232">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="8">&nbsp;</td>
											<td width="436" colspan="2">
											<img border="0" src="images/inf/createaccount.jpg" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="25" valign="middle">&nbsp;
											</td>
											<td width="409" valign="middle">
											The Account '<b><?=$user?></b>' has been created successfully.</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="25">&nbsp;</td>
											<td width="409">To edit your profile, login and click Profile 
											&quot;Edit my account&quot;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" colspan="2">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24" colspan="2">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>
<?
}
?>