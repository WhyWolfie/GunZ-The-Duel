<!-- Coding By Sacker - GodOfWar -->
<?
    if( !ereg("index.php", $_SERVER['PHP_SELF']) )
    {
        header("Location: http://sackerz.blogspot.com/");
        die();
    }
?>
<table border="1" id="table1">
	<tr>
		<td colspan="4">
		<p align="center"><b><font face="Arial"><?php echo $_STR[Ascii1]; ?></font></b></td>
	</tr>
	<tr>
		<td align="center" width="16%"><font face="Arial"><?php echo $_STR[Ascii2]; ?></font></td>
		<td align="center" width="36%"><font face="Arial">ALT + CODE</font></td>
		<td align="center" width="19%"><font face="Arial"><?php echo $_STR[Ascii2]; ?></font></td>
		<td align="center" width="25%"><font face="Arial">ALT + CODE</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%">
		<p align="center"><font face="Arial" size="4">|</font></td>
		<td align="center" width="36%"><font face="Arial">&nbsp;CTRL + ALT + 1</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0189</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%">
		<p align="center"><font face="Arial" size="4">~</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 126</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0190</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0162</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0198</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0163</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0208</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0164</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0216</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0165</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0222</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0166</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0223</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0167</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0230</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0168</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0247</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0169</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0248</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0170</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0140</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0171</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0156</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0174</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0131</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0175</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0128</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0177</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0153</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0181</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0134</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0182</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0135</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%"><font face="Arial" size="4">�</font></td>
		<td align="center" width="36%"><font face="Arial">ALT + 0187</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0149</font></td>
	</tr>
	<tr>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">
		<font face="Arial" size="4">�</font></td>
		<td align="center" width="36%" style="color: #A0A0A4">
		<font face="Arial">ALT + 0188</font></td>
		<td align="center" height="30" width="16%" style="color: #A0A0A4">&nbsp;</td>
		<td align="center" width="36%" style="color: #A0A0A4">&nbsp;</td>
	</tr>
</table>