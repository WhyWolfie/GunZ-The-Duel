<?php
//This file has been edited by Wizkid. All rights reserved.

mssql_connect("ICA-128D73E05DD\SQLEXPRESS","sa","theduel");
mssql_select_db("GunzDB");

//Anti SQL injection by Wizkid. Updated a bit to prevent all sorts of injections.
function antisql($sql)
{
// Remove words that contain SQL syntax
$sql = preg_replace(sql_regcase("/(from|update|set|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql); //Replaces some parts of a SQL query with absolutely nothing.
$sql = trim($sql); //antisqls up spaces
$sql = strip_tags($sql);//Php and html tags strip
$sql = addslashes($sql);//Adds backslashes to one string
return $sql;
}

//==========================================================

$hashid = antisql($_GET['hashid']);
$res = mssql_query("SELECT * FROM SessionHash WHERE HashString = '$hashid' AND Used = '0'");
if(mssql_num_rows($res) >= 1){
    $data = mssql_fetch_assoc($res);
    mssql_query("UPDATE Login SET Allowed = '1' WHERE UserID = '".$data['User']."'");
    mssql_query("UPDATE SessionHash SET Used = '1' WHERE HashString = '$hashid'");
    echo "YES";
}else{
    echo "NO";
}




?>