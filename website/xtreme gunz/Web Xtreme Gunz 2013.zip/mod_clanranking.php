<?
$res = mssql_query("SELECT TOP 5 * FROM Clan ORDER BY Ranking DESC");
?>
<table border="0" style="border-collapse: collapse" width="195" id="table4">
							<tr>
								<td background="images/clanranking.jpg" height="31" width="195">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/menu_bg.jpg">
								<table border="0" style="border-collapse: collapse" width="193" height="100%">
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>

                                    <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
                                    <tr>
										<td width="4">&nbsp;</td>
										<td width="142"><center>There is no data.</center></td>
									</tr>
                                        <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">� <?=$clan['Name']?></td>
										<td width="41">
										<p align="center"><b><?=$clan['Point']?></b></td>
									</tr>
                                    <?}}?>
									<tr>
										<td width="4">&nbsp;</td>
										<td width="142">&nbsp;</td>
										<td width="41">&nbsp;</td>
									</tr>
								</table>
								</td>
							</tr>
							<tr>
								<td background="images/menu_foot.jpg" height="22">&nbsp;</td>
							</tr>
</table>