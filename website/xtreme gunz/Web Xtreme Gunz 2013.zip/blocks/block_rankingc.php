<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<?

function PorcentPlayers($players, $max)
{
    $total = $players + $max;

    return ($total == 0) ? "0%" : round((100 * $players) / $total, 2) . "%";
}

$matou = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY KillCount DESC"));
$morreu = mssql_fetch_row(mssql_query("SELECT TOP 1 Name FROM Character ORDER BY DeathCount DESC"));
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo1 {color: #090912}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
-->

</style>
<table background="images/md_cr.png" style="background-repeat:no-repeat; background-position:center;" width="174" height="141" border="0">
<tr>
    <td><table width="167" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="14" rowspan="6">&nbsp;</td>
        <td height="33" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos &laquo; </div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="7" align="left">
  															<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
  															<td width="104" align="left">
         <?=$user['Name']?></td>
       <td width="27" align="left">
           <?=$user['Point']?></td>
      </td>
      </tr>
      <?}}?>
    </table>    <td height="39"></tr>
</table>
<p>&nbsp;</p>
<p><a href="index.php?do=usercp"><img src="images/user.png" width="160" height="149" /></a></p>
<p><?php
    $query = mssql_query("SELECT * FROM ServerStatus(nolock) WHERE Opened != 0");
    while( $data = mssql_fetch_object($query) )
    {
        $ip = $data->IP;
        $port = $data->Port;
        $name = 'xTremeGunz';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<table border='0' width='173'><tr><td width='110'>$name: </td><td align='left'><B><font style='color: #FF0000'>Offline</B></font></td></tr></table>";
        }
        else
        {
            echo "<table border='0' width='173'><tr><td width='110'>$name: </td><td align='left'><B><font style='color: #0099FF'>En L&iacute;nea</B></font></td></tr></table>";
            fclose($fp);
        }
    }
    ?><?php
        $ip = 'xtgunz.sytes.net';
        $port = '7777';
        $name = 'Match Agent';
        $fp = @fsockopen($ip, $port, $errno, $errstr, 1);

        if (!$fp)
        {
            echo "<table border='0' width='173'><tr><td width='110'>$name: </td><td align='left'><B><font style='color: #FF0000'>Offline</B></font></td></tr></table>";
        }
        else
        {
            echo "<table border='0' width='173'><tr><td width='110'>$name: </td><td align='left'><B><font style='color: #0099FF'>En L&iacute;nea</B></font></td></tr></table>";
            fclose($fp);
        }
    ?><? //Total Accounts
$query = mssql_query("SELECT * FROM Account"); 
$num_rows = mssql_num_rows($query); 
echo "<table border='0' width='173'><tr><td width='110'>Total Cuentas: </td><td align='left'><font style='color: #0099FF'>".$num_rows."</font></td></tr></table><n>"; 
?>
<?php
//Total Characters
$query = mssql_query("SELECT * FROM Character"); 
$num_rows = mssql_num_rows($query); 
echo "<table border='0' width='173'><tr><td width='110'>Total Personajes: </td><td align='left'><font style='color: #0099FF'>".$num_rows."</font></td></tr></table><n>";
?>
<?php
 
//Total Clans
$query = mssql_query("SELECT * FROM Clan"); 
$num_rows = mssql_num_rows($query); 
echo "<table border='0' width='173'><tr><td width='110'>Total Clanes: </td><td align='left'><font style='color: #0099FF'>".$num_rows."</font></td></tr></table><n>";

?>
<table border='0' width='173'><tr><td width='110'>Record en linea: </td><td align='left'><font style='color: #0099FF'>
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<?=$b['PlayerCount']?></font></td></tr></table>
</p>