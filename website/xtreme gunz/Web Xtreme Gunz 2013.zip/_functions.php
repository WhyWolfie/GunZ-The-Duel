<?php
//This file has been edited by Wizkid. All rights reserved.

//Start Session
@session_start();
function makepoststring($string) {
    if (strlen($string) > 17){
        return ucfirst(substr($string,0,17) . "...");
    }else{
        return ucfirst($string);
    }
}

//Anti SQL injection by Wizkid. Updated a bit to prevent all sorts of injections.
function antisql($sql)
{
// Remove words that contain SQL syntax
$sql = preg_replace(sql_regcase("/(from|update|set|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$sql); //Replaces some parts of a SQL query with absolutely nothing.
$sql = trim($sql); //antisqls up spaces
$sql = strip_tags($sql);//Php and html tags strip
$sql = addslashes($sql);//Adds backslashes to one string
return $sql;
}

function ChangeTitle($title) {
    echo "<script language='JavaScript'>
document.title='".$title."';
</script>";
}

function mTrim($cadena){
    return str_replace(" ","",$cadena);
   }

function ErrorBox($data) {
    return "<tr>
<td width='434' colspan='2'>
<div align='center'>
<table border='1' width='95%' height='95%' style='border-collapse: collapse' bordercolor='#FF0000' bgcolor='#FF9191' class='errorbox'>
<tr>
<td>
<table border='0' width='100%' height='100%' style='border-collapse: collapse'>
<tr>
<td valign='bottom' width='1052' colspan='2'>
<img border='0' src='images/icon_error.gif' width='16' height='17'>
<font size='1'><b>An error has occurred!</b></font></td>
</tr>
<tr>
<td width='19'>&nbsp;</td>
<td width='1031' valign='top'><b>$data</b></td>
</tr>
</table>
</td>
</tr>
</table>
</div>
</td>
<td width='8'>&nbsp;</td>
</tr>
<tr>
<td width='145'>
&nbsp;</td>
<td width='289'>
&nbsp;</td>
<td width='8'>&nbsp;</td>
</tr>";
}

function msgbox($text, $url){
echo "<body  bgcolor='#000000'><script>alert('$text');document.location = '$url'</script></body>"; 
}

function re_dir($url){
echo "<body  bgcolor='#000000'><script>document.location = '$url'</script></body>";

}

?>