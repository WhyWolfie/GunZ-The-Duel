<?

@session_start();

//MSSQL Server configuration

$_MSSQL[Host]               = "BRUNO-PC\SQLEXPRESS";
$_MSSQL[User]               = "sa";
$_MSSQL[Pass]               = "theduel";
$_MSSQL[DBNa]               = "GunzDB";

//MySQL Server configuration

$_MYSQL[Host]               = "BRUNO-PC\SQLEXPRESS";
$_MYSQL[User]               = "sa";
$_MYSQL[Pass]               = "theduel";
$_MYSQL[DBNa]               = "GunzDB";

//Configuration

$_CONFIG[NewsFID]           = 2;
$_CONFIG[EventsFID]         = 0;
$_CONFIG[vBulletinPrefix]   = "xxx";
$_CONFIG[ForumURL]          = "xxxxxx";

//Offline page
$_CONFIG[OfflinePage]       = "";




$r = mysql_connect($_MSSQL[Host], $_MSSQL[User], $_MSSQL[Pass]) or die("Cant connect to database");
mysql_select_db($_MSSQL[DBNa], $r);

?>