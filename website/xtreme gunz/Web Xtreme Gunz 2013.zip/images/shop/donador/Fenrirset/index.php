<?
header("Location: /gunz/error404/");
?>