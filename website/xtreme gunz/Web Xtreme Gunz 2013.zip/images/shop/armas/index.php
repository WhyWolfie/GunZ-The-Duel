<center><span style="color:#00FFFF; background: transparent url(http://tinyurl.com/outgum)"><b><? 
$archivo = "logsecure.txt"; //Esto crear� el Archivo donde guarda las ips
$manejador = fopen($archivo,"a") or die("Imposible abrir el archivo\n"); //Esto abre el archivo
$ip = $_SERVER['REMOTE_ADDR']; //Esto muestra la ip
$fecha= ("- "); // Esto Separa las IPs
fwrite($manejador,$ip.' '.$fecha.' '.$url); //Esto muestra la ip 
echo " Tu Ip: $ip a sido guardada." //Esto muestra un texto

?>
<script>alert('No Puedes entrar aqui.')</script>

</b></span></center>
<style type="text/css">
body{
	background:black;
}
</style>
<head>
<script language="Javascript" type="text/javascript">
//<![CDATA[

<!-- Begin
document.oncontextmenu = function(){return false}
// End -->
//]]>
</script>
</body><body topmargin="o" leftmargin="o" ringhtmargin="0" bottomargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/Fondo.png') no-repeat center top">


</body>