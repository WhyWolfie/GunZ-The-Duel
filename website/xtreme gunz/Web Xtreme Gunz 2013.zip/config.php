<?php
mssql_connect("DS9470\SQLEXPRESS","sa","gigiteamo10032013love#%#");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
    $pagetitle = "Server in maintenance";
}
?>