// JavaScript Document Sacker


document.write('<style type="text/css">input.styled { display: none; } select.styled { position: relative; width: ' + selectWidth + 'px; opacity: 0; filter: alpha(opacity=0); z-index: 5; } .disabled { opacity: 0.5; filter: alpha(opacity=50); }</style>');

var Custom = {
	init: function() {
		var inputs = document.getElementsByTagName("input"), span = Array(), textnode, option, active;
		for(a = 0; a < inputs.length; a++) {
			if((inputs[a].type == "checkbox" || inputs[a].type == "radio") && inputs[a].className == "styled") {
				span[a] = document.createElement("span");
				span[a].className = inputs[a].type;

				if(inputs[a].checked == true) {
					if(inputs[a].type == "checkbox") {
						position = "0 -" + (checkboxHeight*2) + "px";
						span[a].style.backgroundPosition = position;
					} else {
						position = "0 -" + (radioHeight*2) + "px";
						span[a].style.backgroundPosition = position;
					}
				}
				inputs[a].parentNode.insertBefore(span[a], inputs[a]);
				inputs[a].onchange = Custom.clear;
				if(!inputs[a].getAttribute("disabled")) {
					span[a].onmousedown = Custom.pushed;
					span[a].onmouseup = Custom.check;
				} else {
					span[a].className = span[a].className += " disabled";
				}
			}
		}
		inputs = document.getElementsByTagName("select");
		for(a = 0; a < inputs.length; a++) {
			if(inputs[a].className == "styled") {
				option = inputs[a].getElementsByTagName("option");
				active = option[0].childNodes[0].nodeValue;
				textnode = document.createTextNode(active);
				for(b = 0; b < option.length; b++) {
					if(option[b].selected == true) {
						textnode = document.createTextNode(option[b].childNodes[0].nodeValue);
					}
				}
				span[a] = document.createElement("span");
				span[a].className = "select";
				span[a].id = "select" + inputs[a].name;
				span[a].appendChild(textnode);
				inputs[a].parentNode.insertBefore(span[a], inputs[a]);
				if(!inputs[a].getAttribute("disabled")) {
					inputs[a].onchange = Custom.choose;
				} else {
					inputs[a].previousSibling.className = inputs[a].previousSibling.className += " disabled";
				}
			}
		}
		document.onmouseup = Custom.clear;
	},
	pushed: function() {
		element = this.nextSibling;
		if(element.checked == true && element.type == "checkbox") {
			this.style.backgroundPosition = "0 -" + checkboxHeight*3 + "px";
		} else if(element.checked == true && element.type == "radio") {
			this.style.backgroundPosition = "0 -" + radioHeight*3 + "px";
		} else if(element.checked != true && element.type == "checkbox") {
			this.style.backgroundPosition = "0 -" + checkboxHeight + "px";
		} else {
			this.style.backgroundPosition = "0 -" + radioHeight + "px";
		}
	},
	check: function() {
		element = this.nextSibling;
		if(element.checked == true && element.type == "checkbox") {
			this.style.backgroundPosition = "0 0";
			element.checked = false;
		} else {
			if(element.type == "checkbox") {
				this.style.backgroundPosition = "0 -" + checkboxHeight*2 + "px";
			} else {
				this.style.backgroundPosition = "0 -" + radioHeight*2 + "px";
				group = this.nextSibling.name;
				inputs = document.getElementsByTagName("input");
				for(a = 0; a < inputs.length; a++) {
					if(inputs[a].name == group && inputs[a] != this.nextSibling) {
						inputs[a].previousSibling.style.backgroundPosition = "0 0";
					}
				}
			}
			element.checked = true;
		}
	},
	clear: function() {
		inputs = document.getElementsByTagName("input");
		for(var b = 0; b < inputs.length; b++) {
			if(inputs[b].type == "checkbox" && inputs[b].checked == true && inputs[b].className == "styled") {
				inputs[b].previousSibling.style.backgroundPosition = "0 -" + checkboxHeight*2 + "px";
			} else if(inputs[b].type == "checkbox" && inputs[b].className == "styled") {
				inputs[b].previousSibling.style.backgroundPosition = "0 0";
			} else if(inputs[b].type == "radio" && inputs[b].checked == true && inputs[b].className == "styled") {
				inputs[b].previousSibling.style.backgroundPosition = "0 -" + radioHeight*2 + "px";
			} else if(inputs[b].type == "radio" && inputs[b].className == "styled") {
				inputs[b].previousSibling.style.backgroundPosition = "0 0";
			}
		}
	},
	choose: function() {
		option = this.getElementsByTagName("option");
		for(d = 0; d < option.length; d++) {
			if(option[d].selected == true) {
				document.getElementById("select" + this.name).childNodes[0].nodeValue = option[d].childNodes[0].nodeValue;
			}
		}
	}
}
window.onload = Custom.init;


loadImage0 = new Image();
loadImage0.src = "images/nav-home_on.png";
staticImage0 = new Image();
staticImage0.src = "images/nav-home.png";

loadImage1 = new Image();
loadImage1.src = "images/nav-reg_on.png";
staticImage1 = new Image();
staticImage1.src = "images/nav-reg.png";

loadImage2 = new Image();
loadImage2.src ="images/nav-down_on.png";
staticImage2 = new Image();
staticImage2.src = "images/nav-down.png";

loadImage3 = new Image();
loadImage3.src = "images/nav-logo_on.png";
staticImage3 = new Image();
staticImage3.src = "images/nav-logo.png";

loadImage4 = new Image();
loadImage4.src = "images/nav-clan_on.png";
staticImage4 = new Image();
staticImage4.src = "images/nav-clan.png";

loadImage5 = new Image();
loadImage5.src = "images/nav-mark_on.png";
staticImage5 = new Image();
staticImage5.src = "images/nav-mark.png";

loadImage6 = new Image();
loadImage6.src = "images/nav-com_on.png";
staticImage6 = new Image();
staticImage6.src = "images/nav-com.png";

loadImage7 = new Image();
loadImage7.src = "images/donate_on.png";
staticImage7 = new Image();
staticImage7.src = "images/donate.png";

loadImage8 = new Image();
loadImage8.src = "images/ranking_on.png";
staticImage8 = new Image();
staticImage8.src = "images/ranking.png";

loadImage9 = new Image();
loadImage9.src = "images/login_btn_on.png";
staticImage9 = new Image();
staticImage9.src = "images/login_btn.png";

loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";
// End -->
loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";

