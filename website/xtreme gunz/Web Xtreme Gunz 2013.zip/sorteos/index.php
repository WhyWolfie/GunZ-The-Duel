<?php
header('Location: http://xtgunz.sytes.net/xtg/error404');
?>