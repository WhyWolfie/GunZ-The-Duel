<?php
@session_start();
$AID = $_SESSION['AID'];
 
 
$link = mssql_connect("JASON-PC\SQLEXPRESS", "sa", "theduel");
mssql_select_db("GunzDB", $link);
 
 
if(empty($AID) || !is_numeric($AID))
{
        if(isset($_POST['loguearse']))
        {
                $query = mssql_query("SELECT a.AID FROM Account a INNER JOIN [Login] b ON a.AID = b.AID WHERE b.UserID = '".antisql($_POST['userid'])."' AND b.Password = '".antisql($_POST['pass'])."'");
                if(mssql_num_rows($query))
                {
                        $r = mssql_fetch_object($query);
                        $_SESSION['AID'] = $r->AID;                    
                        echo "<script>var url = window.location.href; window.location = url;</script>";
                        die();
                }else{
                        echo "<script>alert('Usuario y/o Contrase�a Incorrectas!');</script>";
                }              
        }
                ?>
                <form method="post">
                <fieldset>
                <legend>Loguearse</legend>
                <label>User: </label><input type="text" name="userid" /><br />
                <label>Password: </label><input type="password" name="pass" /><br />
                <input type="submit" name="loguearse" value="Loguear" />
                </fieldset>
                </form>
                <?
       
        die();
}
 
function antisql($value)
{
        $check = $value;
 
        $value = preg_replace(sql_regcase("/(from|shutdown|select|update|clan|character|indexcontent|set|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$value);
        $value = trim($value);
        $value = strip_tags($value);
        $value = addslashes($value);
        $value = str_replace("'", "''", $value);
 
        if( $check != $value )
        {
                        date_default_timezone_set('America/Los_Angeles');
                        if(!is_dir("logs"))
                        {
                                mkdir("logs");
                        }
            $logf = fopen("logs/sqllog.txt", "a+");
            fprintf($logf, "Date: %s - IP: %s - C�digo: %s, - Correto: %s\r\n", date("d-m-Y h:i:s A"), $_SERVER['REMOTE_ADDR'], $check, $value );
            fclose($logf);
        }
 
        return( $value );
}
 
function Msg($texto)
{
        echo '<script type="text/javascript">
                alert("'.$texto.'");
                window.location = "/";
                </script>';
        die();
}
 
function getpath($url) {
$part1 = explode("/", $url);
$count = count($part1);
$count_array = $count - 1;
if ($count >= 4) {
if ($part1[$count_array] != '') {
$path = str_replace($part1[$count_array], '', $url); }
else { $path = $url; }
} else {
if(substr($url,-1) != '/') $url .= '/'; $path = $url; }
return $path;
}
 
function isAdmin($AID)
{
        $query = mssql_query("SELECT UGradeID FROM Account WHERE AID = ".$AID);
        $r = mssql_fetch_object($query);
        switch($r->UGradeID)
        {
        //Estos son los que pueden crear un sorteo!
                case 255: //Admin
                case 254: //Mod
                case 252: //Dev
                        return true;
                default:
                        return false;
        }
}
 
if(!isAdmin($AID)){
        Msg("Usted no pertenece al Staff no puede acceder aqui!");
}
 
if(isset($_POST['sorteo']))
{
        $tabla = $_POST['tabla'];
        $columna = $_POST['columna'];
        $maxusers = $_POST['MaxUsers'];
        $coins = $_POST['coins'];
        if(is_numeric($maxusers) && is_numeric($coins))
        {
                if(mssql_query("INSERT INTO Sorteo (TABLA, COLUMNA, MaxUsers, Coins) VALUES ('".antisql($tabla)."', '".antisql($columna)."', ".$maxusers.", ".$coins.")"))
                {
                        $r = mssql_fetch_object(mssql_query("SELECT ID FROM Sorteo Order By ID DESC"));
                        $url = "http://".$_SERVER['SERVER_NAME'].$_SERVER['PHP_SELF'];
                        $url = getpath($url)."xtgelmejor.php?id=".$r->ID;
                        echo "Sorteo Creado Satisfactoriamente!<br />";
                        echo "Link para los Usuarios: ".$url;                  
                }else{
                        echo "Error al Crear el Sorteo";
                }
               
        }
}else{
?>
 
<form method="post">
<fieldset>
<legend>Crear Nuevo Sorteo!</legend>
        <label>Maximo Usuarios: </label>
    <input type="number" name="MaxUsers" value="50" /><br />
    <label>TABLA: </label>
    <select name="tabla">
        <option value="Account" selected="selected">Account</option>
        <option value="Login">Login</option>
    </select><br />
    <label>COLUMNA: </label>
    <input type="text" name="columna" value="Coins" /><br />
    <label>Cantidad de Coins a Dar: </label>
    <input type="number" name="coins" value="100" /><br /><br />
    <input type="submit" name="sorteo" value="Crear Sorteo" />
</fieldset>
</form>
 
<?
}
?>