<?php
/////Lo editamos con nuestros datos
$DBHost = 'DS9470\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'gigiteamo10032013love#%#';
$DB = 'GunzDB';
?>
