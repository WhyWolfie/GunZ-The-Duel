<?
include "secure/config.php";
include "secure/functions.php";
include "secure/anti_inject.php";
include "secure/sql_check.php";
include "secure/ipban.php";
include "secure/ban.php";
include "secure/shield.php";
if( $_SESSION['AID'] != "" || $_SESSION['UserID'] != "" )
{
    $chkq = mssql_query("SELECT Password FROM Login(nolock) WHERE AID = '" . $_SESSION['AID'] .
                        "' AND UserID = '" . $_SESSION['UserID'] . "'");

    if( mssql_num_rows($chkq) != 1 )
    {
        /*$invaclogf = fopen("../gunzlogs/accesosinvalidos.txt", "a+");
        fprintf($invaclogf, "SUserID: %s - SAID: %s - SPass: %s - IP: %s - Date: %s\r\n", $_SESSION['UserID'], $_SESSION['AID'], $_SESSION['Password'], $_SERVER['REMOTE_ADDR'], date("d/m/Y h:i:s A") );
        fclose($invaclogf);*/

        session_unset();
        session_destroy();
        SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
        header("Location: index.php");
        die();
    }
    else
    {
        $data = mssql_fetch_row($chkq);
        if( md5(md5($data[0])) != $_SESSION['Password'] )
        {
            session_unset();
            session_destroy();
            SetMessage("Acceso Invalido", "Acceso invalido a la cuenta");
            header("Location: index.php");
            die();
        }
    }
}

function ParseTitle($content)
{
    if($_SESSION[PageTitle] <> "")
    {
        $r = str_replace("%TITLE%", $_SESSION[PageTitle], $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        $_SESSION[PageTitle] = "";
        return $r;
    }else{
        $r = str_replace("%TITLE%", "xTreme Gunz - 2013", $content);
        //$r = str_replace("src=\"images/", "src=\"http://localhost/", $r);
        return $r;
    }
}

ob_start("ParseTitle");

?>
<html>

<head>
<link rel="shortcut icon" href="favicon.ico">
<link rel="icon" type="image/gif" href="icono.gif">
<meta name="GENERATOR" content="Namo WebEditor v6.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>xTreme Gunz - 2013</title>

<script type="text/javascript"> 
    var adfly_id = 1715746; 
    var adfly_advert = 'int'; 
    var frequency_cap = 5; 
    var frequency_delay = 5; 
    var init_delay = 3; 
</script> 
<script src="https://cdn.adf.ly/js/entry.js"></script> 
<script language="JavaScript">
<!--

function FP_swapImgRestore() {//v1.0
 var doc=document,i; if(doc.$imgSwaps) { for(i=0;i<doc.$imgSwaps.length;i++) {
  var elm=doc.$imgSwaps[i]; if(elm) { elm.src=elm.$src; elm.$src=null; } }
  doc.$imgSwaps=null; }
}

function FP_swapImg() {//v1.0
 var doc=document,args=arguments,elm,n; doc.$imgSwaps=new Array(); for(n=2; n<args.length;
 n+=2) { elm=FP_getObjectByID(args[n]); if(elm) { doc.$imgSwaps[doc.$imgSwaps.length]=elm;
 elm.$src=elm.src; elm.src=args[n+1]; } }
}

function FP_preloadImgs() {//v1.0
 var d=document,a=arguments; if(!d.FP_imgs) d.FP_imgs=new Array();
 for(var i=0; i<a.length; i++) { d.FP_imgs[i]=new Image; d.FP_imgs[i].src=a[i]; }
}

function FP_getObjectByID(id,o) {//v1.0
 var c,el,els,f,m,n; if(!o)o=document; if(o.getElementById) el=o.getElementById(id);
 else if(o.layers) c=o.layers; else if(o.all) el=o.all[id]; if(el) return el;
 if(o.id==id || o.name==id) return o; if(o.childNodes) c=o.childNodes; if(c)
 for(n=0; n<c.length; n++) { el=FP_getObjectByID(id,c[n]); if(el) return el; }
 f=o.forms; if(f) for(n=0; n<f.length; n++) { els=f[n].elements;
 for(m=0; m<els.length; m++){ el=FP_getObjectByID(id,els[n]); if(el) return el; } }
 return null;
}

function UpdatePrice()
{
	try
	{
	var SelectedDays = document.frmBuy.rentdays.value;
	var PricePerDay = Math.ceil(document.getElementById("currentprice").innerHTML / 10);
	var CurrentFounds = document.getElementById("currbalance").innerHTML;
	document.getElementById("dayprice").innerHTML = PricePerDay;

	document.getElementById("Total").innerHTML = SelectedDays * PricePerDay;

	document.getElementById("afterpur").innerHTML = CurrentFounds - (SelectedDays * PricePerDay);

	if(CurrentFounds < (SelectedDays * PricePerDay)){
		alert("You not have enought euCoins to buy " + SelectedDays + " days");
		document.frmBuy.rentdays.value = "10";
		//UpdatePrice();
	}

	}catch(err){

	}

}
// -->
</script>

<script type="text/javascript" src="ajax/utilities/utilities.js"></script>
<script type="text/javascript" src="ajax/container/container.js"></script>
<script type="text/javascript" src="js/menunewskr.js"></script>
<script>  	
<!-- 
loadImage0 = new Image();
loadImage0.src = "images/nav-home_on.png";
staticImage0 = new Image();
staticImage0.src = "images/nav-home.png";

loadImage1 = new Image();
loadImage1.src = "images/nav-reg_on.png";
staticImage1 = new Image();
staticImage1.src = "images/nav-reg.png";

loadImage2 = new Image();
loadImage2.src ="images/nav-down_on.png";
staticImage2 = new Image();
staticImage2.src = "images/nav-down.png";

loadImage3 = new Image();
loadImage3.src = "images/nav-logo_on.png";
staticImage3 = new Image();
staticImage3.src = "images/nav-logo.png";

loadImage4 = new Image();
loadImage4.src = "images/nav-clan_on.png";
staticImage4 = new Image();
staticImage4.src = "images/nav-clan.png";

loadImage5 = new Image();
loadImage5.src = "images/nav-mark_on.png";
staticImage5 = new Image();
staticImage5.src = "images/nav-mark.png";

loadImage6 = new Image();
loadImage6.src = "images/nav-com_on.png";
staticImage6 = new Image();
staticImage6.src = "images/nav-com.png";

loadImage7 = new Image();
loadImage7.src = "images/donate_on.png";
staticImage7 = new Image();
staticImage7.src = "images/donate.png";

loadImage8 = new Image();
loadImage8.src = "images/ranking_on.png";
staticImage8 = new Image();
staticImage8.src = "images/ranking.png";

loadImage9 = new Image();
loadImage9.src = "images/login_btn_on.png";
staticImage9 = new Image();
staticImage9.src = "images/login_btn.png";

loadImage10 = new Image();
loadImage10.src = "images/register_on.png";
staticImage10 = new Image();
staticImage10.src = "images/register.png";

loadImage11 = new Image();
loadImage11.src = "images/prank_on.jpg";
staticImage11 = new Image();
staticImage11.src = "images/prank.jpg";

loadImage12 = new Image();
loadImage12.src = "images/crank_on.jpg";
staticImage12 = new Image();
staticImage12.src = "images/crank.jpg";


loadImage13 = new Image();
loadImage13.src = "images/ptime_on.jpg";
staticImage13 = new Image();
staticImage13.src = "images/ptime.jpg";

loadImage14 = new Image();
loadImage14.src = "images/TopFB.png";
staticImage14 = new Image();
staticImage14.src = "images/TopFBon.png";
// End -->
    </script>
<link rel="stylesheet" type="text/css" href="e_style.css">
<link href="images/UrbanArtist.css" rel="stylesheet" type="text/css">
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" style="background: #000000 url('images/bg.jpg') no-repeat center top">

<div align="center">
	<table border="0" style="border-collapse: collapse" width="100%" height="100%">
		<tr>
			<td>

			<p align="center"><center>
	<div id="header">			
				
		<h1 id="logo-text"><a href="index.php" title="">xTremeGunz</a></h1>		
		<p id="intro">
		Servidor 0 lager, Anti-Lead 2007 - 100%, Clan war y Quest en un solo server, Antihack, anti UC, antikore y antiDDos 100% Fixeado. Gracias por pertenecer a esta comunidad!
		</p>	
		
		<div  id="nav">
			<ul>
				<li id="current"><a href="index.php">Inicio</a></li>
				<li><a href="index.php?do=register">Registrarse</a></li>
				<li><a href="index.php?do=download">Descargar</a></li>
				<li><a href="index.php?do=ranking">Ranking</a></li>
				<li><a href="index.php?do=shop">Tienda</a></li>
				<li><a href="http://foro.xtremegunz.coms.pe">Foro</a></li>		
			</ul>		
		</div>	
						
	<!--header ends-->					
	</div>
</center>
			
			</td>
		</tr>
		<tr>
			<td><center><br><br><br><br><br><br><br><br>
		</tr>
		<tr>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>
		<div align="center">

		<table border="0" cellpadding="0" cellspacing="0" width="800">
        <tbody><tr>
        	<td width="800" colspan="3">&nbsp;
						</td>
          </tr>
           
          <tr>
            <td width="10">&nbsp;</td>
            <td width="778">
            <?

            if($_CONFIG[OfflinePage] == "")
            {
                if(isset($_GET['do']))
                {
                    $do = $_GET['do'];
                }else{
                    $do = "index";
                }

                if(file_exists("modules/module_$do.php"))
                {
                    include "modules/module_$do.php";
                    //CheckIPBan();
                    CheckIsBanned();

                }else{
                    SetMessage("An error has ocurred", array("Module '$do' not found"));
                    header("Location: index.php");
                }

            }else{
                include "modules/module_offline.php";
            }

            ?>
			</td>
            <td width="12">&nbsp;</td>
          </tr>
        	<tr>
            <td width="800" colspan="3"><center><?
        if(empty($_GET['do'])){
            ?>
            <table width="431" border="0">
  <tr>
    <td height="27" style="background:#1E1E1E; color:#146CCD; border-radius:5px 5px 0px 0px;"><center><strong>Ultimos Clan War</strong></center></td>
  </tr>
</table>
<table style="background:#171717;"><tr><td><table width="420">
  <tr>
    <td><table width="415">
  <tr>
    <td width="35" bgcolor="#1F1F1F" style="border-radius:3px 3px 3px 3px;" align="center"><strong>Win</strong></td>
    <td width="158" bgcolor="#282828" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8">&nbsp;<strong>Clan Ganador</strong></font></td>
    <td width="19"></td>
    <td width="143" bgcolor="#282828" style="border-radius:3px 3px 3px 3px;" align="center"><font size="1,8"><strong>Clan Perdedor</strong></font></td>
    <td width="43" bgcolor="#1F1F1F" style="border-radius:3px 3px 3px 3px;" align="center"><strong>Losse</strong></td>
  </tr>
  
</table>
</td>
  </tr>
</table></td></tr></table>
<?php
$busca999 = mssql_query("SELECT TOP 7 WinnerClanName, LoserClanName, RoundWins, RoundLosses, RegDate FROM ClanGameLog ORDER BY RegDate DESC");
$busca998 = mssql_fetch_row($busca999);

while($item22 = mssql_fetch_row($busca999))
{

?>
<table style="background:#171717"><tr><td><table width="420">
  <tr>
    <td><table width="415">
  <tr>
    <td width="35" bgcolor="#1F1F1F" style="border-radius:3px 0px 0px 3px;" align="center"><font color="#99FF00"><?=$item22[2]?> +</font></td>
    <td width="153" bgcolor="#282828" style="border-radius:0px 3px 3px 0px;" align="center"><font size="1,8"><?=$item22[0]?></font></td>
    <td width="19" align="center">Vs</td>
    <td width="148" bgcolor="#282828" style="border-radius:3px 0px 0px 3px;" align="center"><font size="1,8"><?=$item22[1]?></font></td>
    <td width="36" bgcolor="#1F1F1F" style="border-radius:0px 3px 3px 0px;" align="center"><font color="#FF0000">- <?=$item22[3]?></font></td>
  </tr>
  
</table>
</td>
  </tr>
</table></td></tr></table>

<?
}
?> 
            </div>
                                </li>
<center><?
}
?></center></p>
							  </td>
							</tr>
								
							</tr>
</table>
			</td>
          </tr>
        	<tr>
            <td background="images/top_bg.jpg" height="50" width="100%" colspan="3">
			<center>Web designed by: <a style="color:#F00; a:hover: #06F;" href="http://www.facebook.com/AQuuiLiiNno">iShalom</a>, Copyright &copy; todos los derechos reservados.</td>
          </tr>
        </tbody></table>
          </div>
          	</td>
		</tr>
	</table>
</div>


</div>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>

<script type="text/javascript">
jQuery.noConflict();
jQuery(function (){
jQuery(".s_likebox").hover(function(){
jQuery(".s_likebox").stop(true, false).animate({right:"0"},"medium");
},function(){
jQuery(".s_likebox").stop(true, false).animate({right:"-250"},"medium");
},500);
return false;
});
</script>
<style type="text/css">
.s_likebox {
float:right; /* Indicamos que flotara en la parte derecha*/ 
width:288px; /* Ancho */
height:345px; /* Alto */
background: url(https://lh6.googleusercontent.com/-VW_GzzYnZJ0/TkiZQFcBc2I/AAAAAAAABmg/fa9_qWV8Cu4/fb_bg.png) no-repeat !important; /* El fondo de la pesta�a, en este caso utilizamos una imagen */
display:block;
right:-250px;
padding:0;
position:fixed;
top: 130px;
z-index:1002;
border-radius:10px;
-moz-border-radius:10px; 
-webkit-border-radius:10px; 
}
div.likeboxwrap {
margin-top:2px;
margin-left:-5px;
width:238px; 
height:325px;
background-color:#fff;
overflow:hidden;
border-radius:10px;
-moz-border-radius:10px; 
-webkit-border-radius:10px; 
}
div.likeboxwrap iframe {margin:-1px}
</style>
<div class="s_likebox"><div style="color: rgb(255, 255, 255); padding: 8px 5px 0pt 50px;"><span><div class='likeboxwrap'><iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FXtremeGamersGunz&amp;width=238&amp;height=590&amp;show_faces=true&amp;colorscheme=light&amp;stream=true&amp;show_border=true&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:240px; height:590px;" allowTransparency="true"></iframe></div></span></div></div>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-41024965-1', 'sytes.net');
  ga('send', 'pageview');

</script>
<script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15_giftop.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script><script  type="text/javascript" >
try {Histats.startgif(1,2330182,4,10008,"div#histatsC {position: absolute;top:0px;right:0px;}body>div#histatsC {position: fixed;}");
Histats.track_hits();} catch(err){};
</script><noscript><style type="text/css">div#histatsC {position: absolute;top:0px;right:0px;}body>div#histatsC {position: fixed;}</style><img border="0" src="http://s4is.histats.com/stats/i/2330182.gif?2330182&103"></div></noscript>
</body>
</html>