<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}
?>
<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/launchgunz.jpg" width="413" height="18"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">Available Soon.</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>