<?
if ($_GET['expand'] == 1){
?>
				<tr>
					<td width="917" colspan="5" height="26" style="background-image: url('images/subbar.jpg'); background-repeat: no-repeat; background-position: center top">
					<p align="center">
					<a href="index.php?do=ranking&sub=individual&expand=1">
					<img border="0" src="images/subbar/individualranking.jpg" width="128" height="13"></a><a href="index.php?do=ranking&sub=clan&expand=1"><img border="0" src="images/subbar/clanranking.jpg" width="99" height="13"></a></td>
				</tr>

<? }

if($_GET['expand'] == 0){

switch($_GET['sub']){
    case "individual";
        ShowIndividualRanking();
    break;
    case "clan";
        ShowClanRanking();
    break;
}
}


if(!function_exists("ShowIndividualRanking")){
function ShowIndividualRanking(){
    $res = mssql_query("SELECT TOP 50 * FROM Character ORDER BY XP DESC");
    $count = 0;
    ?>


<head>
<meta http-equiv="Content-Language" content="es">
<link rel="stylesheet" type="text/css" href="images/style.css">
</head>

	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/individualranking.jpg"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/rankinglist.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/rankinlist_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                                <?
                                                                    while($r = mssql_fetch_assoc($res)){
                                                                    $count++;
                                                                    ?>
																	<tr>
																		<td width="45">
																		<p align="center">
																		<?=$count?></td>
																		<td width="88">
																		<p align="center">
																		<b>
																		<span class="guild_name">
																		<?=$r['Name']?></span></b>
																		</td>
																		<td width="33">
																		<p align="center">
																		<?=$r['Level']?></td>
																		<td width="127">
																		<p align="center">
																		<?=number_format($r['XP'],0,'','.');?></td>
																		<td width="114">
																		<p align="center">
																		<span style="font-size: 7pt">
																		<?=$r['KillCount']?>/<?=$r['DeathCount']?>
																		</span></td>
																	</tr> <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }

if(!function_exists("ShowClanRanking")){
function ShowClanRanking(){
    $res = mssql_query("SELECT TOP 50 * FROM Clan ORDER BY Ranking DESC");
    ?>
<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>
							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436">
											<img border="0" src="images/inf/clanraking.jpg" width="413" height="17"></td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											&nbsp;</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">
											<div align="center">
												<table border="0" width="421" style="border-collapse: collapse; background-image: url('images/clanranking_list.jpg'); background-repeat: no-repeat; background-position: center top">
													<tr>
														<td>
														<table border="0" style="border-collapse: collapse" width="100%" height="100%">
															<tr>
																<td height="30">&nbsp;</td>
															</tr>
															<tr>
																<td style="background-image: url('images/clanranking_list_bg.gif'); background-repeat: repeat; background-position: center top">
																<table border="0" style="border-collapse: collapse" width="417" height="100%">
                                                                    <? while($r = mssql_fetch_assoc($res)){   ?>

                                                                    <tr>
																		<td width="45">
																		<p align="center">
																		<?=$r['Ranking']?></td>
																		<td width="90">
																		<p align="center">
																		<b><?=$r['Name']?></b></td>
																		<td width="76">
																		<p align="center">
																		<? $res2 = mssql_query("SELECT * FROM Character WHERE CID = '".$r['MasterCID']."'");
                                                                            $c = mssql_fetch_assoc($res2);
                                                                            echo $c['Name'];
                                                                        ?></td>
																		<td width="71">
																		<p align="center">
																		<?=$r['Wins']?>/<?=$r['Losses']?></td>
																		<td width="40">
																		<p align="center">
																		<img border="0"  width="30" height="30" src="http:(//******/gunz/?=$r['EmblemUrl']?>"</td>
																		<td width="83">
																		<p align="center">
																		<?=$r['TotalPoint']?></td>
																	</tr>  <?}?>
																</table>
																</td>
															</tr>
														</table>
														</td>
													</tr>
												</table>
											</div>
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">
											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							</tr>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div>
    <?
} }





?>