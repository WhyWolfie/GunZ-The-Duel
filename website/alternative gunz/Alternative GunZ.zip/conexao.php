<?php
//Conex�o com o Mssql
$conexao = mssql_connect("TU-PC\SQLEXPRESS", "sa", "asdasdad");
$banco = mssql_select_db("GunzDB");
//Final da Conex�o com o Mssql
?>