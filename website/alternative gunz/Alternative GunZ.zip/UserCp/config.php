<?php
//NighT GamerZ Spain Config
$link = mssql_connect("XXXXX\SQLEXPRESS", "sa", "senha");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}

//Data Base Stuff!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$DBHost = 'RAFINHA\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005)
$DBUser = 'sa'; //Your DB User 
$DBPass = 'ingwbkvf'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZ DB 


?>