﻿<br /><p3>Como virar VIP no Skull GunZ</p3><br />

<p>Os Planos s&atilde;o &uacute;nico meio de manter o servidor <b>Skull GunZ Online</b>,
voc&ecirc; n&atilde;o &eacute; obrigado a fazer a doa&ccedil;&atilde;o mas se gosta de jogar aqui reconhe&ccedil;a o trabalho de nossa equipe
contribuindo, somente assim podemos manter o servidor 
do jeito que voc&ecirc; quer e admira tanto.</p>
<p>Lembramos que o Skull Gunz &eacute; um jogo gratuito, ou seja, voc&ecirc; n&atilde;o paga nada para jogar, contudo, as
doa&ccedil;&otilde;es efetivadas n&atilde;o ser&atilde;o devolvidas, sendo que todo o valor arrecadado &eacute; revertido para manuten&ccedil;&atilde;o do
servidor.</p>
<p>Cada item abaixo possui um valor em dinheiro, assim voc&ecirc; poder&aacute; receber o item desejado se tiver doado o
valor correspondente a ele. </p>

<table align="center">
	<tr>
    	<td colspan="2"><img src="imgs/webstore/Sets/Vermelho.png"  height="260"/></td>
        <td colspan="2"><img src="imgs/webstore/Sets/Verde.png"  height="260"/></td>
    </tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Vermelho</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Verde</font></td>
		</tr>
    	<tr>		
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+50</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+50</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Sets/Azul.png"  height="260"/></td>
        		<td colspan="2"><img src="imgs/webstore/Sets/Nazista.png"  height="260"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Azul</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Nazista</font></td>
		</tr>
    	<tr>		
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+50</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+39</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+97</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">39</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Sets/Baixaki.png"  height="260"/></td>
        		<td colspan="2"><img src="imgs/webstore/Sets/Youtube.png"  height="260"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Baixaki</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Youtube</font></td>
		</tr>
    	<tr>
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+19</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+19</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+87</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+87</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">37</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">37</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Sets/Camuflado.png"  height="260"/></td>
        		<td colspan="2"><img src="imgs/webstore/Sets/Laranja.png"  height="260"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Camuflado</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Laranja</font></td>
		</tr>
    	<tr>
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+48</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+50</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Sets/Lol.png"  height="260"/></td>
        		<td colspan="2"><img src="imgs/webstore/Sets/Skype.png"  height="260"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Roxo e Prata</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Set Skype</font></td>
		</tr>
    	<tr>
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+50</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+19</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+100</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">29</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">37</font></td>
        </tr>
		    <tr>
    			<td colspan="2">
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
					<img src="imgs/webstore/meds/ap.gif"  height="55"/>
				</td>
    			<td colspan="2">
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
					<img src="imgs/webstore/meds/hp.gif"  height="55"/>
				</td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Med HP</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Med AP</font></td>
		</tr>
    	<tr>
    		<td><font color="#999">Pente:</font></td>
            <td><font color="#63C">8</font></td>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">8</font></td>
        </tr> 
    	<tr>
    		<td><font color="#999">Delay:</font></td>
            <td><font color="#63C">600</font></td>
            <td><font color="#999">Delay:</font></td>
            <td><font color="#63C">600</font></td>
        </tr> 		
    	<tr>
    		<td><font color="#999">Peso:</font></td>
            <td><font color="#63C">5</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">5</font></td>
        </tr> 	
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Armas/Nazista.jpg"  height="183"/></td>
        		<td colspan="2"><img src="imgs/webstore/Armas/Azul.jpg"  height="183"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Nazista</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Azul B&ecirc;b&ecirc;</font></td>
		</tr>
    	<tr>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+4</font></td>
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+3</font></td>
        </tr>     
       	<tr>

            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+3</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+5</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">2 x 9</font></td>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">6 x 6</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">12</font></td>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">1300</font></td>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Armas/War.jpg"  height="183"/></td>
        		<td colspan="2"><img src="imgs/webstore/Armas/Justiceira.jpg"  height="183"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker War</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Justiceira</font></td>
		</tr>  
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">990</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">6 x 6</font></td>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">5 x 7</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
        </tr>
       	<tr>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+4</font></td>
            <td><font color="#999">&nbsp;</font></td>
            <td><font color="#63C">&nbsp;</font></td>
        </tr>
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+4</font></td>
            <td><font color="#999">&nbsp;</font></td>
            <td><font color="#63C">&nbsp;</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Armas/Massa.jpg"  height="183"/></td>
        		<td colspan="2"><img src="imgs/webstore/Armas/Roxa.jpg"  height="183"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Massa</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Roxa</font></td>
		</tr>
    	<tr>
    		<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+4</font></td>
            <td><font color="#999">HP:</font></td>
            <td><font color="#63C">+2</font></td>
        </tr>     
       	<tr>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+3</font></td>
            <td><font color="#999">AP:</font></td>
            <td><font color="#63C">+2</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">6 x 6</font></td>
            <td><font color="#999">Pente:</font></td>
            <td><font color="#63C">6 x 6</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Armas/Marrom.jpg"  height="183"/></td>
        		<td colspan="2"><img src="imgs/webstore/Espadas/Katana.jpg"  height="183"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Breaker Marrom</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Espada Katana Azul</font></td>
		</tr>
    	<tr>
			<td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
			<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+5</font></td>
        </tr>     
       	<tr>
			<td><font color="#999">Pente</font></td>
            <td><font color="#63C">6x6</font></td>
			<td><font color="#999">AP:</font></td>
            <td><font color="#63C">+3</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">11</font></td>
            <td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">30</font></td>
        </tr>
       	<tr>
            <td><font color="#999">&nbsp;</font></td>
            <td><font color="#63C">&nbsp;</font></td>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">319</font></td>
        </tr>
    		<tr>
    			<td colspan="2"><img src="imgs/webstore/Armas/Bazuca.jpg"  height="183"/></td>
        		<td colspan="2"><img src="imgs/webstore/Sets/BugFree.jpg"  height="183"/></td>
  			</tr>
		<tr>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Bazuca Tubar&atilde;o</font></td>
			<td><font color="#999">Nome:</font></td>
			<td><font color="#63C">Bug Free Coat</font></td>
		</tr>
    	<tr>
			<td><font color="#999">Peso:</font></td>
            <td><font color="#63C">10</font></td>
			<td><font color="#999">Peso</font></td>
            <td><font color="#63C">-2</font></td>
        </tr>     
       	<tr>
			<td><font color="#999">Pente</font></td>
            <td><font color="#63C">10x4</font></td>
			<td><font color="#999">HP:</font></td>
            <td><font color="#63C">+10</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Dano:</font></td>
            <td><font color="#63C">60</font></td>
            <td><font color="#999">AP</font></td>
            <td><font color="#63C">23</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">900</font></td>
            <td><font color="#999">Peso m&aacute;ximo</font></td>
            <td><font color="#63C">+2</font></td>
        </tr>
       	<tr>
            <td><font color="#999">Velocidade:</font></td>
            <td><font color="#63C">-10%</font></td>
            <td><font color="#999">Atraso:</font></td>
            <td><font color="#63C">990</font></td>
        </tr>
		<tr>
    		<td colspan="4" class="tabeladecores"><img src="imgs/webstore/Color/colors.jpg"  height="150" align="center"/></td>	
		</tr>
			<tr>
				<td><font color="#999">&nbsp;</font></td>
				<td class="lol" border="0"><font color="#999">Tabela de</font></td>
				<td class="lol2"><font color="#999">Cores</font></td>
				<td><font color="#999">&nbsp;</font></td>
			</tr>
</table>
<br />
<table width="500" align="center">
	<tr>
		<td colspan="2" class="tabeladeprecos"><font color="#999">Pre&ccedil;os</font></td>		
	</tr>
	<tr>
		<td><font color="#63C">Set's</font></td>
		<td><font color="#999">R$ 15,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Breakers</font></td>
		<td><font color="#999">R$ 10,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Espadas</font></td>
		<td><font color="#999">R$ 10,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Bug Free Coat</font></td>
		<td><font color="#999">R$ 10,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Bazukas</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>
	<tr>	
		<td><font color="#63C">Med HP</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Med AP</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>
	<tr>
		<td><font color="#63C">Colorir o Nick</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>	
	<tr>
		<td><font color="#63C">Alterar o Nick</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>
		<td><font color="#63C">Alterar o Nome do Clan</font></td>
		<td><font color="#999">R$ 5,00<font></td>
	</tr>
</table>

<br />
<p>Players Vips s&atilde;o reconhecidos pelas cores: Amarelo, Rosa, Verde e Azul.</p>
<br />
<hr />
                          <p><b><font color="#6633CC">Como Realizar o Pagamento?</font></b><br />
                          <p>Para adiquirir Vip no Skull Gunz ter&aacute; que ser via dep&oacute;sito banc&aacute;rio, 
                            deposite na conta abaixo um dos valores correspondentes na tabela.                            </p>
						
				<table width="500" align="center">
					<tr>
						<td><font color="#63C">Banco:</font></td>
						<td><font color="#999">Caixa Econ&ocirc;mica Federal.<font></td>
					</tr>
					<tr>
						<td><font color="#63C">Ag&ecirc;ncia:</font></td>
						<td><font color="#999">0052-9</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Conta poupan&ccedil;a:</font></td>
						<td><font color="#999">00128239-0</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Favorecido:</font></td>
						<td><font color="#999">Simone Patricia B. Lima</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Opera&ccedil;&atilde;o:</font></td>
						<td><font color="#999">013</font></td>
					</tr>
				</table>				
<p><font color="#63C">Recebendo seu sistema Vip </font><br />
Ap&oacute;s realizar o pagamento, envie um e-mail para <b>gunzskull@hotmail.com</b> com os dados da transa&ccedil;&atilde;o,
e o plano Vip a ser adiquirido da seguinte maneira:</p>
				<table width="500" align="center">
					<tr>
						<td><font color="#63C">Assunto:</font></td>
						<td><font color="#999">Vip Skull GunZ<font></td>
					</tr>
					<tr>
						<td><font color="#63C">Us&uacute;ario:</font></td>
						<td><font color="#999">--------</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Quantia depositada:</font></td>
						<td><font color="#999">R$ ----</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Data e hor&aacute;rio do dep&oacute;sito:</font></td>
						<td><font color="#999">dd/mm/aaaa, hh/mm.</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Cor da acc:</font></td>
						<td><font color="#999">Dispon&iacute;veis: Amarelo, Rosa, Verde ou Azul.</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Itens/Sexo a serem enviados:</font></td>
						<td><font color="#999">Exemplos: Set Azul Male, Nick ^ZNome^G123, Altera&ccedil;&atilde;o de Clanzinho para Clan.</font></td>
					</tr>
					<tr>
						<td><font color="#63C">Dados da transa&ccedil;&atilde;o ou Imagem do recibo Scaneada:</font></td>
						<td><font color="#999">--------</font></td>
					</tr>
				</table>
<p><i>Aguarde at&eacute; a verifica&ccedil;&atilde;o do pagamento, caso tenha &ecirc;xito, voc&ecirc; ter&aacute; 2 dias &uacute;teis para receber seus itens. </i></p>
<hr />