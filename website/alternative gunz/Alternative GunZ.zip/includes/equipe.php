﻿<p> STAFF</p>
<img src="imgs/equipe/Rob.jpg" title="Stalion Owner" alt="Rob Skull Owner" class="rob" />
<img src="imgs/equipe/Furfles.jpg" title="Co-owner VAGO" alt="Atsuko Co-Owner" class="equipe" />
<img src="imgs/equipe/Mamute.jpg" title="Programador-VAGO" alt="Mamute Game Master" class="equipe" /><br />
<img src="imgs/equipe/Isa.jpg" title="GM-VAGO - Interface" alt="Isa Designer - Interface" class="rob" />
<img src="imgs/equipe/Mhorfine.jpg" title="GM-VAGO" alt="Mhorfine Designer - Itens" class="equipe" />



<br />

<p> Equipe Full, Favor n&atilde;o insistir. </p>