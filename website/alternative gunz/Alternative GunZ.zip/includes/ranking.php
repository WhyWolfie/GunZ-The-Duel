﻿<p>Selecione o Ranking para ser visualizado:</p>
<br />
<p><a href="ranking_players.php">Players</a>&nbsp;-&nbsp;<a href="ranking_clans.php">Clans</a></p>
