<style type="text/css">
<left>
<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style2 {color: #999999}
body {
	background-color: #FFFFFF;
}
body,td,th {
	color: #000000;
}
-->
</style>
<br>
<p class="playersonline" align="left">
<span class="style1">Match Server: </span>
<?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '6000';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?><br />
<span class="style1">Match Agent: </span>
<?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '7777';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?><br />
<span class="style1">Locator: </span>
<?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '7777';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?><br />
<font color='#999999'>
<span class="style1">Players On-lines: </span>
 <?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
       <?=$servercount?><br />
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?>
<b><span class="style2">Recorde On-lines</span>:</b> <?=$b['PlayerCount']?><br />
<span class="style2"><b>Contas:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account")); ?><br />
<span class="style2"><b>Personagens:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Character")); ?><br />
<span class="style2"><b>Clans:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Clan")); ?><br />
<? 
$grade3 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='3'")); 
$grade4 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='4'")); 
$grade5 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='5'")); 
$grade6 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='6'")); 
$grade7 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='7'")); 
$grade8 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='8'")); 
$grade9 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='9'")); 
?>
<span class="style2"><b>Banidos:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='253'")); ?><br />
<span class="style2"><b>Vips:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='1'"));
$grade2 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='2'"));
$grade3 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='3'")); 
$grade4 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='4'")); 
$grade5 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='5'")); 
$grade6 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='6'")); 
$grade7 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='7'")); 
$grade8 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='8'")); 
$grade9 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='9'"));
 ?><br />
<span class="style2"><b>ADM'S:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='255'")); ?><br />
<span class="style2"><b>GM'S:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='254'")); ?><br />


<span class="style2"><b>Mudos:</b></span> <? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='104'")); ?><br />
<br>
</left>
</font>
</p>
