﻿<!--
.style1 {
	color: #FFFFFF;
	font-weight: bold;
}
.style2 {color: #999999}
body {
	background-color: #FFFFFF;
}
body,td,th {
	color: #000000;
}
-->
</style>
<style type="text/css">
<!--
.style1 {color: #CC9900}
.style2 {color: #0099FF}
-->
</style>

<table width="220" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
	<td width="12"> # </td>
    <td width="4" align="center"><p1>
      <div align="left"></div>
    </p1></td>    
    <td width="135" align="left"><p2>Match Server</p2></td>
    <td width="69" align="center"><p1>
      <div align="left"><?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '6000';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?></div>
    </p1></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Match Agent</td>
    <td align="center"><div align="left"><?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '7777';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Locator</td>
    <td align="center"><div align="left"><?php
	$ipx = 'alternativegunz.sytes.net';
	$porta = '7777';
    $fp = @fsockopen($ipx, $porta, $errno, $errstr, 1);
	if (!$fp)
        {
            echo "<font color='red'>Offline</font>";
        }
        else
        {
            echo "<font color='#00FF00'>Online</font>";
            fclose($fp);
        }
?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left"> Players On-lines </td>
    <td align="center"><div align="left"><?
$res = mssql_query("SELECT * FROM ServerStatus WHERE Opened = '1'");
$servercount = 0;
while($srv = mssql_fetch_assoc($res)){
    $servercount = $servercount + $srv['CurrPlayer'];
}
?>
       <?=$servercount?><br />
<? 
	$b = mssql_fetch_array(mssql_query("SELECT TOP 1 PlayerCount FROM ServerLog ORDER BY PlayerCount DESC")); 
	?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Recorde On-lines </td>
    <td align="center"><div align="left"><?=$b['PlayerCount']?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Contas </td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Personagens</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Character")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Clans</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Clan")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Banidos</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='253'")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Vips</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='1'"));
$grade3 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='3'")); 
$grade4 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='4'")); 
$grade5 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='5'")); 
$grade6 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='6'")); 
$grade7 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='7'")); 
$grade8 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='8'")); 
$grade9 = mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='9'"));
 ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left"><span class="style1">ADM'S</span></td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='255'")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left"><span class="style2">GM'S</span></td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='254'")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">MUTE</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='104'")); ?></div></td>
  </tr>
  <tr>
    <td>#</td>
    <td align="center">&nbsp;</td>
    <td align="left">Event Winner's</td>
    <td align="center"><div align="left"><? echo mssql_num_rows(mssql_query("SELECT * FROM Account WHERE UGradeID='2'")); ?></div></td>
  </tr>
</table>
<br>
<p>
