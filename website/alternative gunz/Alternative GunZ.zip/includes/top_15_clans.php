﻿<?
//Lista os Players do banco de dados MSSQL Scripts By Robert.
$sql = ("SELECT TOP 15 Name, Point, Wins, Losses, EmblemUrl FROM Clan WHERE Name != '' ORDER BY Point DESC");
$executar = mssql_query($sql);
$count = 0;
while($r = mssql_fetch_assoc($executar))
{
?>
<table width="220" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
	<td><img src="http://skullgunz.no-ip.org/<?=($r['EmblemUrl'] == "") ? "gunz/includes/noemblem.png" : $r['EmblemUrl']?>" width="20" height="20"></td>
    <td width="29" align="center"><p1>#<?=++$count?></p1></td>    
    <td width="131" align="left"><p2><?=$r['Name']?></p2></td>
    <td width="70" align="center"><p1><?=$r['Point']?></p1></td>
  </tr>
</table>
<p>
  <? }
?>