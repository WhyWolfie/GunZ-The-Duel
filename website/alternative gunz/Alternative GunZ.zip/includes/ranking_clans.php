﻿<?
//Lista os Players do banco de dados MSSQL Scripts By Robert.
$sql = ("SELECT TOP 200 Name, Point, Wins, Losses, EmblemUrl FROM Clan WHERE Name != '' ORDER BY Point DESC");
$executar = mssql_query($sql);
$count = 0;
while($r = mssql_fetch_assoc($executar))
{
?>
<table width="450" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
	<td><img src="http://skullgunz.no-ip.org/<?=($r['EmblemUrl'] == "") ? "gunz/includes/noemblem.png" : $r['EmblemUrl']?>" width="40" height="40"></td>
    <td width="29" align="center" class="td2"><p1>#<?=++$count?></p1></td>    
    <td width="131" align="left" class="td2"><p2><?=$r['Name']?></p2></td>
    <td width="70" align="center" class="td2"><p1><?=$r['Point']?></p1></td>
    <td width="148" align="center" class="td2"><p2><?=$r['Wins']?>/<?=$r['Losses']?></p2></td>


  </tr>
</table>
<p>
  <? }
?>