﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Skull GunZ</title>
<meta http-equiv="refresh"" content="5;url=http://skullgunz.no-ip.org/" />
</head>

<body>

<p> Mudamos para http://skullgunz.no-ip.org/ Você será redirecionado em 5 segundos!</p>
</body>
</html>
