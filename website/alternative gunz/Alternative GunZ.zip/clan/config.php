<?php

$DBHost = 'TU-PC\SQLEXPRESS'; //The host of your DB (I.E: MACHINE\SQL2005 or IP if remotelly)
$DBUser = 'sa'; //Your DB User 
$DBPass = 'asdadas'; //Your DB Password 
$DB = 'GunzDB'; //Your GunZDB 

$conn = @mssql_connect($DBHost, $DBUser, $DBPass); 
@mssql_select_db($DB); 

?>