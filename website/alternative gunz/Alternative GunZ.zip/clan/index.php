<head>
<?php require "conexao.php"; ?>
</head>
<div align="center">
<br />
<br />
<hr />
<? 
require_once "config.php";
require_once "sec.php";

$step = $_GET['step'];
if($step == "")
{
	$step = 1;
}
if ($step == '1') 
{
?>
<FORM METHOD=POST ACTION="?step=2">
<br />
<input name="user" type="textfield" maxlength="14" value=" Us�ario"/>
<br />
<input name="pass" type="password" maxlength="14" value="Senha"/>
<br />
<br />
<input type="submit" value="submit" />
<br />
</form>

<? }
if ($step == "2") 
{
	$user1 = anti_injection($_POST['user']);
	$pass1 = anti_injection($_POST['pass']);
    if (valida(Array($user1,$pass1)) == TRUE)
	{
		$query = mssql_query("SELECT AID From Login Where UserID = '$user1' AND Password = '$pass1' ");

		if (mssql_num_rows($query) < 1)
		{
			echo "That account does't exists or You entered with an invalid Login information.";
		}
		else
		{
			$query2 = mssql_query("SELECT Login.UserID, Login.Password, ClanMember.Grade, Clan.EmblemUrl, Clan.Name, Clan.CLID FROM ClanMember INNER JOIN Clan ON ClanMember.CLID = Clan.CLID INNER JOIN Login INNER JOIN Character ON Login.AID = Character.AID ON ClanMember.CID = Character.CID Where Login.UserID = '$user1' and Login.Password = '$pass1' and ClanMember.Grade = '1' ");
			if (mssql_num_rows($query2) >= '1')
			{ 
			?>
<form enctype="multipart/form-data" action="?step=done" method="POST">
					<p><br />
					  Please choose a file: 
						<input name="uploaded" type="file" />
    </p>
					<p>
					  <select name="clan">
					    
					    	<? 
						for($i=''; $i < @mssql_num_rows($query2); $i++)
						{
							$row = @mssql_fetch_row($query2);
							$ClanName = $row[4];
						?>
						<option value="<?=$row[4]?>"><?=$row[4]?></option>
                        			<?
						}
						?>
				      </select>
                      <br />
    </p>
					<p>Voc� pode fazer upload de imagens 64x64 at� 30kb.</p><br />
					  <br />
					  <input type="submit" value="Upload" /><br />
					  <br />
    </p>
</form>
			<? 
			}
			else 
			{ 
				echo "Voc� n�o � o L�der do Clan";
			} 
		}
	}
}

if ($step == "done") 
{ 				  
	$emblem = $_POST['uploaded'] ;
	$CLID = anti_injection($_POST['clan']);
	$target = "../../clan/clan/";
	$target = $target . basename( $_FILES['uploaded']['name']) ;
	$ok=1;


	$partes = pathinfo( $_FILES['uploaded']['name'] );
	$extensao = $partes['extension'];

	$extensoes = array('jpg', 'jpeg', 'png', 'gif');

	if($_FILES['uploaded']['size']  > "30720")
	{
		$err .= "Your file is too large.<br>";
		$ok = 0;
	}

	if( !in_array(strtolower($extensao), $extensoes) )
	{
		$err .= "<p>Formato de imagem n�o aceita.</p><br>";
		$ok = 0;
	}

	
	if ($ok == 0)
	{
		echo "<p>Desculpe, sua imagem n�o foi aceita.<br />Verifique os erros.</p><br /><br />";
		echo "$err";
	}
	else
	{
		if(move_uploaded_file($_FILES['uploaded']['tmp_name'], $target))
			{
				echo "<p>Seu emblema foi inserido com sucesso.</p><br />";
				mssql_query("UPDATE Clan SET EmblemChecksum = EmblemChecksum + 1 WHERE Name = '$CLID'");
				mssql_query("UPDATE Clan SET EmblemUrl = 'upload/".$target."' WHERE Name = '$CLID'");
			}
			else
			{
				echo "<p>Desculpe, ocorreu um problema, tente novamente.</p>";
			}
	}
}
?>
</div>
<hr />
			

