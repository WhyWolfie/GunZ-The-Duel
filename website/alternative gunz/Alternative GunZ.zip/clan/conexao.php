<?php
//Conex�o com o Mssql
$conexao = mssql_connect("xxxxx\SQLEXPRESS", "sa", "senha");
$banco = mssql_select_db("GunzDB");
//Final da Conex�o com o Mssql
?>