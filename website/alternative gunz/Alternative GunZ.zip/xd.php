﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Skull GunZ</title>
<meta http-equiv="refresh"" content="5;url=http://skullgunz.no-ip.org/" />
</head>

<body>

<p>Ice GunZ com união ao Skull GunZ para tornar-se o Melhor private já visto xD Você será redirecionado para o site do Skull GunZ em 5 segundos!</p>
</body>
</html>
