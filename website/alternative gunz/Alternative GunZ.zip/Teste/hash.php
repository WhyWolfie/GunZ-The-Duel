<? include "config.php" ?>
<? include "_functions.php" ?>
<?
//==========================================================

$hashid = antisql($_GET['hashid']);
$res = mssql_query("SELECT * FROM SessionHash WHERE HashString = '$hashid' AND Used = '0'");
if(mssql_num_rows($res) >= 1){
    $data = mssql_fetch_assoc($res);
    mssql_query("UPDATE Login SET Allowed = '1' WHERE UserID = '".$data['User']."'");
    mssql_query("UPDATE SessionHash SET Used = '1' WHERE HashString = '$hashid'");
    echo "YES";
}else{
    echo "NO";
}




?>