﻿		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="http://alternativegunz.sytes.net:8090/Teste/index.php">HOME</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="http://alternativegunz.sytes.net:8090/Teste/registro.php">REGISTRO</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="http://alternativegunz.sytes.net:8090/Teste/download.php">DOWNLOADS</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="http://alternativegunz.sytes.net:8090/Teste/ranking.php">RANKING</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        <a href="http://alternativegunz.sytes.net:8090/Teste/equipe.php">EQUIPE</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="http://alternativegunz.sytes.net:8090/Teste/usercp/index.php">USER CP</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
		<a href="http://alternativegunz.sytes.net:8090/Teste/clan/index.php?step=1">CLAN</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="http://alternativegunz.sytes.net:8090/Teste/" target="_blank">F&oacute;RUM</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
