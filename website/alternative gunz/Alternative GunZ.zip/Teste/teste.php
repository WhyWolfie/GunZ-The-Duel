﻿
<table width="220" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
	<td width="35"><?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?></td>
    <td width="104" align="center"><p1>
      <div align="left"></div>
    </p1></td>    
    <td width="69" align="left"><p2></p2></td>
    <td width="12" align="center"><p1></p1></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="left"><div align="left"><script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-9353643-1");
pageTracker._trackPageview();
} catch(err) {}</script>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-8655408-2");
pageTracker._trackPageview();
} catch(err) {}</script></div></td>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center"><div align="left">
      <? include "mod_iLogin.php" ?>
    </div></td>
    <td align="left">&nbsp;</td>
    <td align="center">&nbsp;</td>
  </tr>
</table>
<p>
