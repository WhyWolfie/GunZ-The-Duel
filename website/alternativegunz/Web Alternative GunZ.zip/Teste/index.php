<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php
include "config.php";
include "_functions.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }

?>
<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr>
	  </tr>
	  </tr>
		<tr>
			
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
					  <? include "mod_iLogin.php" ?><br><br>
					<br>
					<br>
					</div>				  
					<br>
					<br>
					<div align="center">
                    </div></td>
					<td width="481" valign="top">
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>

				</table>
		  </td>
		</tr>

	</table>
<body>
</body>
</html>
