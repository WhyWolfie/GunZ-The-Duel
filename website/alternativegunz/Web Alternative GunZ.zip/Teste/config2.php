<?php
//Nolife_x Mpog Spain Config
$link = mssql_connect("xorae\SQLEXPRESS", "sa", "kk");
mssql_select_db("GunzDB");
$opened = 1;
if($opened == 0){
   header("Location: Maintenance.php");
}
?>

<?php
//Emblem Upload Config
$DBHost = 'kopkopkopk\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'kpokopp';
$DB = 'GunzDB';
?>