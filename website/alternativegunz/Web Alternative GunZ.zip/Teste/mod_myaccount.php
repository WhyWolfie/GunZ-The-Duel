<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

switch ($_GET['act']){
    case "viewmyitems";
        ShowViewItems();
    break;
    case "editinfo";
        ShowEditAccountInfo();
    break;
}

//ViewMyItems
function ShowViewItems(){
    $res = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    ?>
	
<body bgcolor="#FFFFFF">
<? while ($item = mssql_fetch_assoc($res)){
    $res2 = mssql_query("SELECT * From ShopCash WHERE ItemID = '" . antisql($item['ItemID']) . "'");
    $item2 = mssql_fetch_assoc($res2);
?>
<table border="0" width="50" height="50">
	<tr>
		<td width="235"><?=$item2['Name']?></td>
		<td width="77"><?=$item2['Slot']?></td>
		<td width="116"><?=$item['RentHourPeriod']?></td>
	</tr>
 <?}?>
</table>
                    <?
    }

//Edit Account Info

function ShowEditAccountInfo(){
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = antisql($_POST['userid']);
    $pw1 = antisql($_POST['pw1']);
    $pw2 = antisql($_POST['pw2']);
    $country = antisql($_POST['country']);
    $sq = antisql($_POST['sq']);
    $sa = antisql($_POST['sa']);
    $name = antisql($_POST['name']);
    $zip = antisql($_POST['zip']);
    $age = antisql($_POST['age']);
    $sex = antisql($_POST['sex']);
    $address = antisql($_POST['address']);

   if($_POST['C1'] == "ON"){

        if($pw1 == $pw2){
            $pw1 = "$pw2";
        }else{
            $errorcode.="The passwords do not match</br>";
            $era = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Please enter a password of 6 or more characters.</br>";
            $era =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please enter a password.</br>";
            $era = 1;
        }

        if ($era == 0){
            mssql_query("UPDATE Login SET Password = '$pw1' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
        }else{
            $er =1;
        }
   }


        if($_POST['C2'] == "ON"){


            if ($ert == 0){
                mssql_query("UPDATE Account SET  WHERE AID = '" . antisql($_SESSION['AID']) . "'");
            }else{
                $er =1;
            }


        }

        if($er == 0){
            $registered = 1;
            mssql_query("UPDATE Account SET Name = '$name', Age = '$age', Sex = '$sex', ZipCode = '$zip', Address = '$address' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
            msgbox("Account information updated","index.php?do=myaccount&act=editinfo");
        }else{
            $errorbox = ErrorBox($errorcode);
        }
    $res1 = mssql_query("SELECT * FROM Account WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $res2 = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $data = mssql_fetch_assoc($res1);
    $data2 = mssql_fetch_assoc($res2);
        ?>
        <form name="reg" method="POST" action="index.php?do=myaccount&act=editinfo"><body bgcolor="#323232">

<? echo @$errorbox ?>
<table width="129" border="0">
	<tr>
		<td width="50"><p>Usuario</p></td>
		<td width="69"><b><?=$_SESSION['UserID']?></b></td>
	</tr>
			<tr>
				<td><input type="checkbox" name="C1" onClick="SwitchPassword()" value="ON"><p1>Editar a Senha?</p1></td>
				<td><font color="#4D4D4D"><span style="font-size: 7pt"><p1>Min 6 Max 10 caracteres.</p1>
				</span></font></td>
			</tr>
				<tr>
					<td><p>Senha</p></td>
					<td><input disabled type="password" name="pw1" size="12" value="<?=$data2['Password']?>" maxlength="10"></td>
				</tr>
						<tr>
							<td>
							<p>Repita</p></td>
							<td><input disabled type="password" name="pw2" size="12" value="<?=$data2['Password']?>" maxlength="10"></td>
						</tr>
							<tr>
								<td colspan="2">
								<input type="submit" value="Editar" name="submit" style="font-size: 8pt; font-family: Verdana; font-weight: bold"></center></td>
							</tr>
</table>
</form>
        <?
}else{
    $res1 = mssql_query("SELECT * FROM Account WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $res2 = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $data = mssql_fetch_assoc($res1);
    $data2 = mssql_fetch_assoc($res2);
?>



<form name="reg" method="POST" action="index.php?do=myaccount&act=editinfo"><body bgcolor="#323232">

<? echo @$errorbox ?>
<table width="50" border="0">
	<tr>
		<td><p>Usuario</p></td>
        <td><b><?=$_SESSION['UserID']?></b></td>
	</tr>
			<tr>
				<td><input type="checkbox" name="C1" onClick="SwitchPassword()" value="ON"><p1>Editar a Senha?</p1></td>
				<td><font color="#4D4D4D"><span style="font-size: 7pt">
				<p1>Min 6 </p1>
				Max10
				<p1>caracteres.</p1>
				</span></font></td>
	</tr>
				<tr>
					<td><p>Senha</p></td>
					<td><input  type="password" name="pw1" size="12" value="<?=$data2['Password']?>" maxlength="10"></td>
				</tr>
					<tr>					</tr>
						<tr>
							<td><p>Repita</p></td>
							<td><input type="password" name="pw2" size="12" value="<?=$data2['Password']?>" maxlength="10"></td>
						</tr>
							<tr>
								<td colspan="2"><center><input type="submit" value="Editar!" name="submit" style="font-size: 8pt; font-family: Verdana; font-weight: bold"></center></td>
							</tr>
</table>
</form>  <? }  }
?>