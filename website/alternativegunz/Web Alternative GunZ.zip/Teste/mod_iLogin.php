<?
if($_SESSION['AID'] == ""){
?><style type="text/css">
<!--
body,td,th {
	font-family: Century Gothic;
	font-size: 10px;
}
-->
</style>
<p>&nbsp;</p>
<form method="POST" action="index.php?do=login&header=1" name="login">
									<table border="0" width="238" height="63%" id="table10" class="iLogin">
<tr>
											<td width="131" height="45"><p>Painel de Usuario
											  </p>
											  <p>
											    <input type="text" name="userid" size="14" class="login" value="Usuario" maxlength="14">
									          </p></td>
									<td width="97">&nbsp;</td>
									  </tr>
										<tr>
											<td height="39"><input type="password" name="pasw" size="14" class="login" id="input" value="*****" maxlength="14" />
										    <img src="key.png" width="16" height="16" /></td>
									  </tr>
										<tr>
										  <td height="26"><input type="submit" value="Login" name="submit" /></td>
									  </tr>
									</table>
</form>
<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
?>

<p3>Bem Vindo, <?=$_SESSION['UserID']?> !</p3><br />
<a href="index.php?do=login&action=logout&header=1">Logout ?</a><br /><br />
<a href="index.php?do=myaccount&act=editinfo">Editar Conta</a></td>


<?
}
?>
