﻿<?php
//Conexão com o Mssql
$conexao = mssql_connect("aff\SQLEXPRESS", "sa", "qkopkop");
$banco = mssql_select_db("GunzDB");
//Final da Conexão com o Mssql
?>