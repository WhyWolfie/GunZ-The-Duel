<?
if ($_SESSION['AID'] == ""){
    re_dir("index.php?do=login");
}

switch ($_GET['act']){
    case "viewmyitems";
        ShowViewItems();
    break;
    case "editinfo";
        ShowEditAccountInfo();
    break;
}

//ViewMyItems
function ShowViewItems(){
    $res = mssql_query("SELECT * FROM AccountItem WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    ?>
	
<body>
	<table border="0" width="60" height="60">
		<tr>
			<td width="236">
			<p align="left">
			Nome</td>
			<td width="75">
			<p align="left">
			Tipo</td>
			<td width="110">
			<p align="left">
			Tempo Restante</td>
		</tr>
	</table>
<? while ($item = mssql_fetch_assoc($res)){
    $res2 = mssql_query("SELECT * From ShopCash WHERE ItemID = '" . antisql($item['ItemID']) . "'");
    $item2 = mssql_fetch_assoc($res2);
?>
<table border="0" width="60" height="60">
	<tr>
		<td width="235"><?=$item2['Name']?></td>
		<td width="77"><?=$item2['Slot']?></td>
		<td width="116"><?=$item['RentHourPeriod']?></td>
	</tr>
 <?}?>
</table>
                    <?
    }

//Edit Account Info

function ShowEditAccountInfo(){
$errorcode = "";
$er = 0;
$registered = 0;
if (isset($_POST['submit'])){
    $user = antisql($_POST['userid']);
    $pw1 = antisql($_POST['pw1']);
    $pw2 = antisql($_POST['pw2']);
    $country = antisql($_POST['country']);
    $sq = antisql($_POST['sq']);
    $sa = antisql($_POST['sa']);
    $name = antisql($_POST['name']);
    $zip = antisql($_POST['zip']);
    $age = antisql($_POST['age']);
    $sex = antisql($_POST['sex']);
    $address = antisql($_POST['address']);

   if($_POST['C1'] == "ON"){

        if($pw1 == $pw2){
            $pw1 = "$pw2";
        }else{
            $errorcode.="The passwords do not match</br>";
            $era = 1;
        }

        if(strlen($pw1) < 6){
            $errorcode.="Please enter a password of 6 or more characters.</br>";
            $era =1;
        }

        if($pw1 == "" Or $pw2 == ""){
            $errorcode.="Please enter a password.</br>";
            $era = 1;
        }

        if ($era == 0){
            mssql_query("UPDATE Login SET Password = '$pw1' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
        }else{
            $er =1;
        }
   }


        if($_POST['C2'] == "ON"){


            if ($ert == 0){
                mssql_query("UPDATE Account SET  WHERE AID = '" . antisql($_SESSION['AID']) . "'");
            }else{
                $er =1;
            }


        }

        if($er == 0){
            $registered = 1;
            mssql_query("UPDATE Account SET Name = '$name', Age = '$age', Sex = '$sex', ZipCode = '$zip', Address = '$address' WHERE AID = '" . antisql($_SESSION['AID']) . "'");
            msgbox("Account information updated","index.php?do=myaccount&act=editinfo");
        }else{
            $errorbox = ErrorBox($errorcode);
        }
    $res1 = mssql_query("SELECT * FROM Account WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $res2 = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $data = mssql_fetch_assoc($res1);
    $data2 = mssql_fetch_assoc($res2);
        ?>
        <form name="reg" method="POST" action="index.php?do=myaccount&act=editinfo"><body bgcolor="#323232">

<? echo @$errorbox ?>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<table border="0" width="60" height="60">
	<tr>
		<td width="145" valign="middle">
		�<span lang="BR">
		<p>Us�ario</p></span></td>
		<td width="289">
		<b><?=$_SESSION['UserID']?></b></td>
		<td width="8">&nbsp;</td>
	</tr>
			<tr>
				<td width="145">&nbsp;</td>
				<td width="289">
				<input type="checkbox" name="C1" onclick="SwitchPassword()" value="ON"><p1>Editar a Senha?</p1></td>
				<td width="8">&nbsp;</td>
			</tr>
				<tr>
					<td width="50">
					.<span lang="BR">
					<p>Senha</p></span></td>
					<td width="50">
					<input disabled type="password" name="pw1" size="20" value="<?=$data2['Password']?>"></td>
					<td width="8">&nbsp;</td>
				</tr>
					<tr>
						<td width="145">&nbsp;</td>
						<td width="289">
						<font color="#4D4D4D">
						<span style="font-size: 7pt"><p1>Minimo 
						6 caracteres.</p1></span></font></td>
						<td width="8">&nbsp;</td>
					</tr>
						<tr>
							<td width="20">
							�<span lang="BR">
							<p>Repita a Senha</p></span></td>
							<td width="20">
							<input disabled type="password" name="pw2" size="20" value="<?=$data2['Password']?>"></td>
							<td width="8">&nbsp;</td>
						</tr>
							<tr>
								<td width="434" colspan="2">
								<center>
								<input type="submit" value="Edit Account" name="submit" style="font-size: 8pt; font-family: Verdana; font-weight: bold"></center></td>
								<td width="8">&nbsp;</td>
							</tr>
</table>
</form>
        <?
}else{
    $res1 = mssql_query("SELECT * FROM Account WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $res2 = mssql_query("SELECT * FROM Login WHERE AID = '" . antisql($_SESSION['AID']) . "'");
    $data = mssql_fetch_assoc($res1);
    $data2 = mssql_fetch_assoc($res2);
?>



<form name="reg" method="POST" action="index.php?do=myaccount&act=editinfo"><body bgcolor="#323232">

<? echo @$errorbox ?>
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<table border="0" width="60" height="60">
	<tr>
		<td width="145" valign="middle">
		�<span lang="BR">
		<p>Us�ario</p></span></td>
		<td width="289">
		<b><?=$_SESSION['UserID']?></b></td>
		<td width="8">&nbsp;</td>
	</tr>
			<tr>
				<td width="145">&nbsp;</td>
				<td width="289">
				<input type="checkbox" name="C1" onclick="SwitchPassword()" value="ON"><p1>Editar a Senha?</p1></td>
				<td width="8">&nbsp;</td>
			</tr>
				<tr>
					<td width="50">
					�<span lang="BR">
					<p>Senha</p></span></td>
					<td width="50">
					<input disabled type="password" name="pw1" size="20" value="<?=$data2['Password']?>"></td>
					<td width="8">&nbsp;</td>
				</tr>
					<tr>
						<td width="145">&nbsp;</td>
						<td width="289">
						<font color="#4D4D4D">
						<span style="font-size: 7pt"><p1>Minimo 
						6 caracteres.</p1></span></font></td>
						<td width="8">&nbsp;</td>
					</tr>
						<tr>
							<td width="20">
							�<span lang="BR">
							<p>Repita a senha</p></span></td>
							<td width="20">
							<input disabled type="password" name="pw2" size="20" value="<?=$data2['Password']?>"></td>
							<td width="8">&nbsp;</td>
						</tr>
										<tr>
											<td width="434" colspan="2">
											<center>
											<input type="submit" value="Edit Account" name="submit" style="font-size: 8pt; font-family: Verdana; font-weight: bold"></center></td>
											<td width="8">&nbsp;</td>
										</tr>
</table>
						</form>  <? }  }
?>