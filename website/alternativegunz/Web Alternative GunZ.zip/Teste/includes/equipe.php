﻿<p> Equipe :D </p>
<img src="imgs/equipe/Rob.jpg" title="Rob Skull Owner" alt="Rob Skull Owner" class="rob" />
<img src="imgs/equipe/Furfles.jpg" title="Atsuko Co-Owner" alt="Atsuko Co-Owner" class="equipe" />
<img src="imgs/equipe/Mamute.jpg" title="Mamute Game Master" alt="Mamute Game Master" class="equipe" /><br />
<img src="imgs/equipe/Isa.jpg" title="Isa Designer - Interface" alt="Isa Designer - Interface" class="rob" />
<img src="imgs/equipe/Mhorfine.jpg" title="Mhorfine Designer - Itens" alt="Mhorfine Designer - Itens" class="equipe" />



<br />

<p> Equipe Full, Favor n&atilde;o insistir. </p>