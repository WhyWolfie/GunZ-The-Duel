<?
if($_SESSION['AID'] == ""){
?>
<p> Painel de Us�ario</p>
<form method="POST" action="index.php?do=login&header=1" name="login">
									<table border="0" width="238" height="63%" id="table10" class="iLogin">
<tr>
											<td width="84" height="54"><input type="text" name="userid" size="14" class="login" value="Us�ario" maxlength="14"></td>
									<td width="144"><input type="password" name="pasw" class="login" id="input" value="*****" maxlength="14"></td>
									  </tr>
										<tr>
											<td height="133"><input type="submit" value="Login" name="submit"></td>
									  </tr>
									</table>
</form>
<?
}else{
$res = mssql_query_logged("SELECT * FROM Login WHERE AID = '".$_SESSION['AID']."'");
$d = mssql_fetch_assoc($res);
?>

<p3>Bem Vindo, <?=$_SESSION['UserID']?> !</p3><br />
<a href="index.php?do=login&action=logout&header=1">Logout ?</a><br /><br />
<a href="index.php?do=myaccount&act=editinfo">Editar Conta</a></td>


<?
}
?>
