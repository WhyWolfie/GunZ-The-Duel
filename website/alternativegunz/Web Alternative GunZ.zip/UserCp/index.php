<?php
include "config.php";
include "_functions.php";
if(!$opened == 0){
if ($_GET['header'] == 1){
    if (file_exists("mod_" . $_GET['do'] . ".php")) {
        include "mod_" . $_GET['do'] . ".php";
	}
} }

?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/>
<title>Skull GunZ- <?=$pagetitle?></title>
<link href="../estilos/estilo.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
<!--
//Disable right click script
var message="";
///////////////////////////////////
function clickIE() {if (document.all) {(message);return false;}}
function clickNS(e) {if
(document.layers||(document.getElementById&&!document.all)) {
if (e.which==2||e.which==3) {(message);return false;}}}
if (document.layers)
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;}
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;}
document.oncontextmenu=new Function("return false")
// -->
                </SCRIPT>
<style type="text/css">
<!--
body {
}
-->
</style></head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" >
 <div id="pai">
  <div id="conteudo">
     <div id="topo">
<embed src="../imgs/flash/sg_4"  wmode="transparent" quality=high width=240 height=240 type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed>
</OBJECT>
    </div>
	   			<div id="menu">
	   			<?php include"menu.php"; ?>
	   			</div>
            <div id="conteudoesquerdo1">
                <div id="conteudo31bgtop">
                <p>TOP 15 CLANS</p>
               	</div>
			<?php include"../includes/top_15_clans.php"; ?>	
			</div>
       			<div id="conteudointerno">            
          			<div id="conteudointernobgtop"> 
                    <marquee>
                    <?php include"../includes/marqueusercp.php"; ?>
                    </marquee>
					</div>
						<div id="conteudointerno2">

<div align="left">
	<table border="0" style="border-collapse: collapse" width="921" id="table1">
		<tr>
	  </tr>
	  </tr>
		<tr>
			
			<table border="0" style="border-collapse: collapse" width="919" height="100%" id="table2">
                 <?	if ($_GET['expand'] == 1){
   						if (file_exists("mod_" . $_GET['do'] . ".php")) {
        					include "mod_" . $_GET['do'] . ".php";
        					$include = "1";
						}
					} ?>
				<tr>
					<td width="917" colspan="5" height="26">&nbsp;</td>
				</tr>
				<tr>
					<td width="10">&nbsp;</td>
					<td width="208" valign="top">
					<div align="center">
					  <? include "mod_iLogin.php" ?><br><br>
					<br>
					<br>
					</div>				  
					<br>
					<br>
					<div align="center">
                    </div></td>
					<td width="481" valign="top">
					<? if($opened == 0){
                        include "maintenance.php";
                    }else{
                    if (isset($_GET['do'])) {
                            $_GET['expand'] = 0;
						   if (file_exists("mod_" . $_GET['do'] . ".php")) {
							    include "mod_" . $_GET['do'] . ".php";
						    }
                        }else{

					    }

                        if(isset($default)){
                            include $default;
                        }  }
                        ?></td>

				</table>
		  </td>
		</tr>

	</table>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-9353643-1");
pageTracker._trackPageview();
} catch(err) {}</script>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-8655408-2");
pageTracker._trackPageview();
} catch(err) {}</script>
					</div>
       			</div>       			
        			<div id="conteudodireito3">
          				<div id="conteudo31bgtop">
                        <p>TOP 15 PLAYERS</p>
                		</div>
					<?php include"../includes/top_15_chars.php"; ?>    
					</div>                    
        			<div id="rodape">
   					  <?php include"../includes/rodape.php"; ?>
       				</div>                      
  </div>
</div>
</body>