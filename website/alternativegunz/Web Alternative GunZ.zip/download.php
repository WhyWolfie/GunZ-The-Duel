<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name = "keywords" content = "skull, skull gunz, gunz, private gunz" />
<meta name = "description" content = "Skull GunZ Servidor 24horas on-line." />
<title>Skull GunZ</title>
<link href="estilos/estilo.css" rel="stylesheet" type="text/css" />
<?php require "conexao.php"; ?>

</head>

<body>
<div id="pai">
  <div id="conteudo">
     <div id="topo">
<embed src="imgs/flash/sg_1"  wmode="transparent" quality=high width=240 height=240 type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"></embed>
</OBJECT>
    </div>
	   			<div id="menu">
	   			<?php include"includes/menu.php"; ?>
	   			</div>
            <div id="conteudoesquerdo1">
                <div id="conteudo31bgtop">
                <p>STATUS</p>
               	</div>
			<?php include"includes/status.php"; ?>	
			</div>
	<div id="conteudointerno">            
	  <div id="conteudointernobgtop"> 
                    <marquee>
					<?php include"includes/marqueindex.php"; ?> 
                    </marquee>        
                    <?php include"includes/downloads.php"; ?>         
	    </div>
</div>       			
        			<div id="conteudodireito3">
          				<div id="conteudo31bgtop">
                        <p>TOP 15 PLAYERS</p>
                		</div>
					<?php include"includes/top_15_chars.php"; ?>    
					</div>
                    <div id="conteudodireito3">
                <div id="conteudo31bgtop">
                <p>TOP 15 CLANS</p>
               	</div>
			<?php include"includes/top_15_clans.php"; ?>	
			</div>
        			<div id="rodape">
                   
   					  <?php include"includes/rodape.php"; ?>
       				</div>           
  </div>
</div>
</body>
</html>