﻿<?php require "conexao.php"; ?>
<?
//Lista os Players do banco de dados MSSQL Scripts By Robert.
$sql = ("SELECT TOP 2000 UserID, UGradeID FROM Account WHERE UserID != '' ORDER BY UGradeID DESC");
$executar = mssql_query($sql);
$count = 0;
while($r = mssql_fetch_assoc($executar))
{
?>
<table width="461" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td width="120" align="center" class="td2"><p2><?=$r['UserID']?></p2></td>
    <td width="48" align="center" class="td2"><p1><?=$r['UGradeID']?></p1></td>
  </tr>
</table>
<? }
?>