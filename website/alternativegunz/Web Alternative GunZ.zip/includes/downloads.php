﻿<p><a href="http://www.megaupload.com/?d=IOCKNDHU" target="_blank">Megaupload</a></p>
<p><a href="http://www.filefront.com/15136955/Skull%20Gunz%206.2.exe" target="_blank">FileFront</a></p>

<h3>FAQ </h3>
<p>Eu n&atilde;o tenho um GunzLauncher.exe, para onde ele pode ter ido?</p>
<p><i>As vezes seu Anti-vir&uacute;s pode acabar excluindo-o automaticamente, basta desativa-lo e fazer a instala&ccedil;&atilde;o novamente.</i></p>
<p>Por que a instala&ccedil;&atilde;o n&atilde;o come&ccedil;a ou da erro?</p>
<p><i>Seu cliente foi corrompido durante o download, por favor baixe novamente.</i></p>
