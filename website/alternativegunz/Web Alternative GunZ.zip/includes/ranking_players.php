﻿<?
//Lista os Players do banco de dados MSSQL Scripts By Robert.
$sql = ("SELECT TOP 500 Name, Level, KillCount, DeathCount, XP FROM Character WHERE Name != '' ORDER BY XP DESC");
$executar = mssql_query($sql);
$count = 0;
while($r = mssql_fetch_assoc($executar))
{
?>
<table width="461" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="44" align="center" class="td2"><p1>#<?=++$count?></p1></td>    
    <td width="120" align="center" class="td2"><p2><?=$r['Name']?></p2></td>
    <td width="48" align="center" class="td2"><p1><?=$r['Level']?></p1></td>
    <td width="80" align="center" class="td2"><p2><?=$r['XP']?></p2></td>
    <td width="164" align="center" class="td2"><p1><?=$r['KillCount']?>/<?=$r['DeathCount']?></p1></td>
  </tr>
</table>
<? }
?>