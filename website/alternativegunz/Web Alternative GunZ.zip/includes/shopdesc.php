﻿<hr>
<p> Descri&ccedil;&atilde;o dos planos de Vip Player.</p>

<font color="#F00">Plano Fogo <br />

<p4>Set Vermelho :</p4> <br />
	PV: +50<br />
	PA: +100<br />
	PS: 29<br />

<p4>Breaker Justiceiro : </p4><br />
	Peso: 10 WT<br />
	Pente: 5x7<br />
	Dmg: 11<br />
	Atraso: 990<br />
	
<p4>Med HP:</p4><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

</table>
<br /><br />
<hr />
<br /><br />

<font color="#0FF">Plano Gelo<br />

<p4>Set Azul :</p4><br />
	PV: +50<br />
	PA: +100<br />
	PS: 29<br />
	
<p4>Breaker Azul B&ecirc;b&ecirc; :</p4> <br />
	Peso: 10 WT<br />
    Pente: 5x7.<br />
    Dano: 11 DMG<br />
    Atraso: 1000<br />
    PA: +3<br />
    PV: +5<br />
	
<p4>Med AP:</p4><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#66CD00">
Plano Mago<br />

<p4>Set Verde :</p4><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p4>Breaker Marrom :</p4> <br />
Peso: 10 WT<br />
                                Pente: 6x6<br />
                                Dano: 11<br />
                                Atraso: 990 <br />
								
<p4>Med AP:</p4><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#FFA500">Plano Fruta  <br />

<p4>Set Laranja :</p4><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p4>Breaker Massa </p4><br />
Peso:10 WT<br />
                              Pente: 6x6<br />
                              Dano: 11<br />
                              Atraso: 990<br />
                              PV: +4<br />
                              PA: +3     <br />
							  
<p4>Med HP:</p4><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#63C">Plano Uva <br />

<p4>Set Roxo :</p4><br />
PV: +50<br />
PA: +100<br />
PS: +29<br />
<p4>Breaker Roxa:</p4><br />

Peso: 10 WT<br />
                            Pente: 6x6.<br />
                            Dano: 11<br />
                            Atraso: 990<br />
                            PV: +2<br />
                            PA: +2<br />
							
<p4>Med HP:</p4><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="gray">Plano Pol&iacute;tico <br />

<p3>Set Nazista :</p3><br />
PV: +27<br />
PA: +95<br />
PS: 41<br />

<p3>Breaker Nazista :</p3><br />
Peso: 10 WT<br />
                                 Pente:2x19<br />
                                 Dano:12.<br />
                                 Atraso:1300<br />
								 
<p3>Med AP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#006400">Plano Ex&eacute;rcito<br />

<p3>Set Camuflado :</p3><br />
PV: +48<br />
PA: +100<br />
PS: 29<br />
<p3>Breaker War : </p3><br />

Peso:10 WT<br />
                           Pente: 6x6<br />
                           Dano: 11<br />
                           Atraso: 990<br />
                           PV: +4<br />
                           PA: +4 <br />
						   
<p3>Med HP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#F0F">Plano Clothing <br />

<p3>Set Vermelho:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Set Azul:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Set Verde:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#800000">Plano Life: <br />

<p3>Breaker Marrom:</p3><br />
           Peso: 10 WT<br />
           Pente: 6x6<br />
           Dano: 11<br />
           Atraso: 990<br />
		   
<p3>Med HP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br />

<p3>Med AP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p4><br /></font>

<br /><br />
<hr />
<br /><br /> 
		   
<font color="#000080">Plano Justice:<br />

<p3>Breaker Justiceiro:</p3><br />
                      Peso: 10 WT<br />
                      Pente: 5x7.<br />
                      Dmg: 11<br />
                      Atraso: 990<br />
					  
<p3>Zuka Shark:</p3><br />
Peso: 10 WT<br />
Pente: 10 x 4<br />
Dano: 60<br />
Atraso: 600<br />
Velocidade: - 10 Escalando Parede<br />

<br /><br />
<hr />
<br /><br />

<font color="#FF0">Plano Bk's:<br />

<p3>Breaker Massa : </p3><br />
                              Peso: 10 WT<br />
                              Pente: 6x6<br />
                              Dano: 11<br />
                              Atraso: 990<br />
                              PV: +4<br />
                              PA: +3    <br /> 

<p3>Breaker War : </p3><br /> 

Peso:10 WT<br /> 
                           Pente: 6x6<br /> 
                           Dano: 11<br /> 
                           Atraso: 990<br /> 
                           PV: +4<br /> 
                           PA: +4<br /> 

<p3>Breaker Azul B&ecirc;b&ecirc; :</p3> <br /> 

Peso: 10 WT<br /> 
                                      Pente: 5x7.<br /> 
                                      Dano: 11 DMG<br /> 
                                      Atraso: 1000.<br /> 
                                      PA: +3<br /> 
                                      PV: +5</font>
							  
<br /><br />
<hr />
<br /><br />

<font color="#0F0">Plano Baixaki <br /> 

<p3>Set Baixaki :</p3> <br /> 
PA: +19<br /> 
PV: +87<br /> 
PS: 37<br /> 

<p3>Breaker Massa : </p3><br /> 

Peso:10 WT<br /> 
                              Pente: 6x6<br /> 
                              Dano: 11<br /> 
                              Atraso: 990<br /> 
                              PV: +4<br /> 
                              PA: +3   <br /> 
							  
<p3>Med AP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p3><br />
<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br /></font>

<br /><br />
<hr />
<br /><br />

<font color="#F00">Plano You Tube<br />
 
<p3>Set You Tube :</p3><br /> 
PA: +19<br /> 
PV: +87<br /> 
PS: 37<br /> 

<p3>Breaker War </p3><br /> 

Peso: 10 WT<br /> 
                           Pente: 6x6<br /> 
                           Dano: 11<br /> 
                           Atraso: 990<br /> 
                           PV: +4<br /> 
                           PA: +4  <br /> 

<p3>Med HP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600</p3><br />

<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br /></font>

<br /><br />
<hr />
<br /><br />


<font color="#ff00ff">Plano Happy<br />

<p3>Set Vermelho:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br />

<p3>Bug Free Coat:</p3><br />
Peso: 2 WT<br />
PV: +10<br />
PA: +29<br />
Peso M&aacute;ximo: +2<br /></font>

<br /><br />
<hr />
<br /><br />


<font color="#ff6600">Plano Sabretoooth<br />

<p3>Set Laranja:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br />

<p3>Bug Free Coat:</p3><br />
Peso: 2 WT<br />
PV: +10<br />
PA: +29<br />
Peso M&aacute;ximo: +2<br /></font>

<br /><br />
<hr />
<br /><br />


<font color="#00ff00">Plano Winter<br />

<p3>Set Verde:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Set Azul:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Set Roxo:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br /></font>

<br /><br />
<hr />
<br /><br />


<font color="#0000cc">Plano Power<br />

<p3>Set Azul:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br />

<p3>Bug Free Coat:</p3><br />
Peso: 2 WT<br />
PV: +10<br />
PA: +29<br />
Peso M&aacute;ximo: +2<br />

<p3>Med HP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600<br />

<p3>Med AP:</p3><br />
Peso: 5 WT<br />
Pente: 8<br />
Atraso: 600<br /></font>

<br /><br />
<hr />
<br /><br />


<font color="#ff0000">Plano Might<br />
<p3>Set Vermelho:</p3><br />
PV: +50<br />
PA: +100<br />
PS: 29<br />

<p3>Katana Azul:</p3><br />
Peso: 10 WT<br />
Dano: 30 DMG<br />
Atraso: 319<br />
PV: +50<br />
PA: +100<br />
Peso M&aacute;ximo: +5<br />

<p3>Bug Free Coat:</p3><br />
Peso: 2 WT<br />
PV: +10<br />
PA: +29<br />
Peso M&aacute;ximo: +2<br />

<p3>Zuka Shark:</p3><br />
Peso: 10 WT<br />
Pente: 10 x 4<br />
Dano: 60<br />
Atraso: 600<br />
Velocidade: - 10 Escalando Parede<br /></font>


<br /><br />
<hr />
<br /><br />