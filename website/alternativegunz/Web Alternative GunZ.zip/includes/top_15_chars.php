﻿<?
//Lista os Players do banco de dados MSSQL Scripts By Robert.
$sql = ("SELECT TOP 5 Name, Level, KillCount, DeathCount, XP FROM Character WHERE Name != '' ORDER BY XP DESC");
$executar = mssql_query($sql);
$count = 0;
while($r = mssql_fetch_assoc($executar))
{
?>
<table width="220" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="44" align="center"><p1>#<?=++$count?></p1></td>    
    <td width="120" align="center"><p2><?=$r['Name']?></p2></td>
    <td width="48" align="center"><p1><?=$r['Level']?></p1></td>
  </tr>
</table>
<? }
?>