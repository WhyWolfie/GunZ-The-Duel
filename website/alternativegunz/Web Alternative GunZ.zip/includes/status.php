﻿
<table width="220" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
	<td width="4">&nbsp;</td>
    <td width="204" align="center"><p1>
      <div align="left"><?php include"includes/teste.php"; ?></div>
    </p1></td>    
    <td width="10" align="left"><p2></p2></td>
    <td width="11" align="center"><p1></p1></td>
  </tr>
</table>
<p>
