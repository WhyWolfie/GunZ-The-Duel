<?php
include ('secure/config.php')
?>
<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<style type="text/css">
<!--
body,td,th {
	font-family: verdana;
	font-size: 10px;
	color: #CCCCCC;
	background-repeat: no-repeat;
}
.Estilo2 {	font-size: 10px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.Estilo3 {color: #414141}
-->

</style>
<table background="images/md_cr.png"  width="174" height="144" border="0">
<tr>
    <td><table width="169" height="100" border="0" style="border-collapse: collapse">
      <tr>
        <td width="11" rowspan="6">&nbsp;</td>
        <td height="15" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos</div></td>
      </tr>
     <?
                                    }else{
                                    while($clan = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="12" align="left"> <img src="http://gunz.galaxiagamers.net/emblem/upload/<?=($clan['EmblemUrl'] == "") ? 'uploadnoemblem.jpg' : $clan['EmblemUrl']?>" width="15" height="15"> 															</td>
  															<td width="93" align="left"><?=$clan['Name']?>
         			      <td width="27"><strong><?=number_format($clan['Point'],0,'','.');?><span class="Estilo3">.</span>Pts.</strong></td>
										<td width="0"></td>
										<td width="0">
										</td>
		</tr>
                                    <?}}?>
									<tr>
    </table>    <td height="39"></tr>
</table>
<br>
<p><a href="index.php?do=shop"><img src="images/litemshop.png" width="175" height="175" border="0" /></a></p>
<p><a href="index.php?do=signature"><img src="images/pu.png" width="175" height="175" border="0" /></a></p>
