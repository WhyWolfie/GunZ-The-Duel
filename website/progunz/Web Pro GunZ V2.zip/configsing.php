<?php
// Config Siganture
$url	=	"http://progunz.net";
$img 	=	"images/sign.png";

?>