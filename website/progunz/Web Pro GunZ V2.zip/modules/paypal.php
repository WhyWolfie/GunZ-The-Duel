<?
if(isset($_POST[submit]))
{

$userid     = $_SESSION['AID'];
$coins		= $_POST['coins']

   //$query1 = mssql_query_logged("SELECT * FROM AccountItem(nolock) WHERE AID = '{$_SESSION[AID]}'");
    $query2 = mssql_query_logged("SELECT DonatorCoins FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");

    if( $coins = 0 )
    {
        msgbox("We do not give away Bounty.","index.php?do=donate");
        
        die();
    }

    if($coins > 0)
    {
        msgbox("You do not have enough DCoins","index.php?do=index");
        
        die();
    }

    mssql_query_logged("UPDATE Account SET DonatorCoins = DonatorCoins + '$coins' WHERE AID = '".$_SESSION['AID']."'");

    msgbox("You have exchanged $coins DCoins for $totalbp Bounty!","index.php?do=changebt");
    
    die();

}
?>