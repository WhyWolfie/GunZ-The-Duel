<?
include("secure/include.php");

    $res = mssql_query("SELECT TOP 4 * FROM ShopItems(nolock) ORDER BY CSSID DESC");

    $count = 1;

    while($a = mssql_fetch_object($res))
    {
        $i[$count][ID]          = $a->CSSID;
        $i[$count][Name]        = $a->Name;
        $i[$count][ImageURL]    = $a->ImageURL;
        $i[$count][Slot]        = GetTypeByID($a->Slot);
        $i[$count][Sex]         = GetSexByID($a->Sex);
        $i[$count][Level]       = $a->Level;
        $i[$count][Price]       = $a->Price;

        $count++;
    }


    $count = 4;

$res = mssql_query("SELECT TOP 4 * FROM ShopSets(nolock) ORDER BY Selled DESC");

while($a = mssql_fetch_object($res))
{
    $items[$count][ID]        = $a->SSID;
    $items[$count][Name]      = $a->Name;
    $items[$count][Type]      = GetTypeByID($a->Slot);
    $items[$count][Sex]       = GetSexByID($a->Sex);
    $items[$count][Level]     = $a->Level;
    $items[$count][Price]     = $a->Price;
    $items[$count][ImageURL]  = $a->ImageURL;
    $items[$count][CatID]     = $a->Slot;

    $count++;
}


?>
<style type="text/css">
<!--
.Estilo3 {color: #373737}
.Estilo4 {color: #464646}

.boton{
  background-image:-moz-linear-gradient(top,#438CE7 0%,#438CE7 50%,#1E76E1 100%); 
  background-image:-webkit-linear-gradient(top,#438CE7 0%,#438CE7 50%,#1E76E1 100%); 
  border:3px #ffffff;
  border-radius:.5em;
  width:130px;
  height:54px;
  color:#B9B9B9;
  font-size:17px;
  -webkit-transition:.5s;
  -moz-transition:.5s;
}
.boton:hover{
  background-image:-moz-linear-gradient(top,#5799EA 0%,#5799EA 50%,#3C88E6 100%); 
  background-image:-webkit-linear-gradient(top,#5799EA 0%,#5799EA 50%,#3C88E6 100%); 
  color:#f1f1f1;
}

-->
</style>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
						  <div align="center">
						    <? include "blocks/block_rankingu.php" ?>
                          </div>
						  <div align="center">
                            <p>
                              <? include "blocks/block_rankingc.php" ?>
                              <center>
						</p>
					      </div>
						  </div>
						</div>					  </td>
						<td valign="top">
						<div align="center">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-repeat:no-repeat" width="419">
								<tr>
									<td background="images/mn_info.jpg" height="76" style="background-image: url(''); background-repeat: no-repeat; background-position: center top" width="417"><table width="417" height="76" style="background-image:-moz-linear-gradient(top,#464646 0%,#464646 50%,#3C3C3C 100%); background-image:-webkit-linear-gradient(top,#464646 0%,#464646 50%,#3C3C3C 100%); border-radius:5px 5px 5px 5px; border:#333333 ">
									
									<tr>
									<td><table width="415" height="74">
                                      <tr>
                                        <td width="250" style="color:#CCCCCC; font-size:16px; text-shadow:0px 0px 0px #ffffff">&nbsp;&nbsp;&nbsp;<strong>USUARIOS ONLINE <?php
$con = mssql_connect("TU-PC\SQLEXPRESS","sa","asd");
if (!$con)
{
die('Fallo en la coneccion..!: ' . mssql_error());
}
mssql_select_db("GunzDB");
$getcurp = mssql_query("SELECT CurrPlayer,MaxPlayer FROM ServerStatus");
$getcur = mssql_fetch_array($getcurp);
echo $getcur['CurrPlayer'];
?>

</strong></td>
                                        <td width="153" align="center"><a href="index.php?do=download" target="_blank"><b><input type="button" value="Descargar" class="boton"/></b></a></td>
                                      </tr>
                                    </table></td>
									</tr>
									
									</table></td>
							  </tr>
								<tr>
									<td height="4" width="417"></td>
								</tr>
								<tr>
									<td style="background-image: url('images/md_information.jpg'); background-repeat: no-repeat; background-position:  left top; " height="156" width="415" valign="top">
								  <div align="center">
								  <table border="0" style="border-collapse: collapse; background-image: url('images/index_panel.jpg'); background-position: center top" width="417" height="151">
                                    <tr>
                                      <td width="200" height="24">&nbsp;</td>
                                      <td width="7" height="24">&nbsp;</td>
                                      <td width="204" height="24">&nbsp;</td>
                                    </tr>
                                    <tr>
                                      <td width="200" valign="top"><table border="0" style="border-collapse: collapse" width="200" height="92%">
                                          <tr>
                                            <td width="4">&nbsp;</td>
                                            <td width="192" valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '1' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><font color="#FFFFFF"> <a href="index.php?do=indexcontent&amp;sub=announcement&amp;id=<?=$n['ICID']?>"><?=$n['Title']?>
                                                  </a></font></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                      <td width="7">&nbsp;</td>
                                      <td width="204" valign="top"><table border="0" style="border-collapse: collapse" width="100%" height="92%">
                                          <tr>
                                            <td valign="top"><table border="0" style="border-collapse: collapse" width="100%" class="IndexC">
                                                <?
                                                                $res = mssql_query("SELECT TOP 5 * FROM IndexContent WHERE Type = '2' ORDER BY ICID DESC");
                                                                while($n = mssql_fetch_assoc($res)){
                                                                ?>
                                                <tr>
                                                  <td height="20"><span class="menu"><img src="images/mis_arrow2.jpg" alt="a" width="5" height="9" border="0" /><a href="index.php?do=indexcontent&amp;sub=update&amp;id=<?=$n['ICID']?>"> <font size="1" face="Verdana">
                                                    <?=$n['Title']?>
                                                  </font></a></span></td>
                                                </tr>
                                                <?}?>
                                            </table></td>
                                          </tr>
                                      </table></td>
                                    </tr>
                                  </table>
								  <p><!--- Ultimas Clan War --><? include ('ultimascw.php');?><!--- Fin Ultimas Clan War--></p>
								  <p>&nbsp;</p></td>
								<tr>
									<td style="background-image: url('images/md_LI.jpg'); background-repeat: no-repeat; background-position: center top" height="305" width="417">
									<div align="center">
                                            <table border="0" style="border-collapse: collapse" width="417" height="100%">
											<tr>
												<td width="206" height="23">&nbsp;</td>
												<td width="207" height="23">&nbsp;</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$i[1][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$i[1][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Tipo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[1][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sexo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[1][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Nivel:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[1][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span color="#0099FF" style="font-size: 7pt" align="center">
																		<span style="color:0099FF">Precio:</span></span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[1][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoevent&itemid=<?=$i[1][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1764" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1764'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyevent&itemid=<?=$i[1][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1765'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
												  <table border="0" style="border-collapse: collapse" width="206" height="91%">
                                                    <tr>
                                                      <td width="5">&nbsp;</td>
                                                      <td width="72">&nbsp;</td>
                                                      <td width="123">&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                      <td width="5">&nbsp;</td>
                                                      <td width="72" valign="top"><img src="images/shop/<?=$i[2][ImageURL]?>" alt="A" width="64" height="64" border="1" /></td>
                                                      <td width="123"><div align="center">
                                                          <table border="0" style="border-collapse: collapse" width="123" height="48%">
                                                            <tr>
                                                              <td width="119" colspan="2"><div align="left">
                                                                  <span style="font-size: 7pt">
                                                                  <?=$i[2][Name]?>
                                                                  </span></td>
                                                            </tr>
                                                            <tr>
                                                              <td width="51" align="left"><span style="font-size: 7pt" align="center"> Tipo:</span></td>
                                                              <td width="68" align="left"><span style="font-size: 7pt" align="center">
                                                                <?=$i[2][Slot]?>
                                                              </span></td>
                                                            </tr>
                                                            <tr>
                                                              <td width="51" align="left"><span style="font-size: 7pt" align="center"> Sexo:</span></td>
                                                              <td width="68" align="left"><span style="font-size: 7pt" align="center">
                                                                <?=$i[2][Sex]?>
                                                              </span></td>
                                                            </tr>
                                                            <tr>
                                                              <td width="51" align="left"><span style="font-size: 7pt" align="center"> Nivel:</span></td>
                                                              <td width="68" align="left"><span style="font-size: 7pt" align="center">
                                                                <?=$i[2][Level]?>
                                                              </span></td>
                                                            </tr>
                                                            <tr>
                                                              <td width="51" align="left"><span color="#0099FF" style="font-size: 7pt" align="center"> <span style="color:0099FF">Precio:</span></span></td>
                                                              <td width="68" align="left"><span style="font-size: 7pt" align="center">
                                                                <?=$i[2][Price]?>
                                                              </span></td>
                                                            </tr>
                                                          </table>
                                                      </div></td>
                                                    </tr>
                                                    <tr>
                                                      <td width="202" height="30" colspan="3"><div align="center"> <a href="index.php?do=infoevent&itemid=<?=$i[2][ID]?>"> <img src="images/btn_moreinfo.jpg" alt="d" width="83" height="21" border="0" id="img1764" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1764'".',/*url*/'."'images/btn_moreinfo_on.jpg></a> <a href="index.php?do=buyevent&itemid=<?=$i[2][ID]?>"> <img src="images/btn_buyitem.jpg" alt="s" width="83" height="21" border="0" id="img1765" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1765'".',/*url*/'."'images/btn_buyitem_on.jpg></a></div></td>
                                                    </tr>
                                                  </table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															 <td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$i[3][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$i[3][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Tipo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[3][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sexo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[3][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Nivel:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[3][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span color="#0099FF" style="font-size: 7pt" align="center">
																		<span style="color:0099FF">Precio:</span></span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[3][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoevent&itemid=<?=$i[3][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1768" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1768'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyevent&itemid=<?=$i[3][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1769" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1769'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															<img border="1" src="images/shop/<?=$i[4][ImageURL]?>" width="64" height="64"></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td width="119" colspan="2">
																		<div align="left">
																		<span style="font-size: 7pt">
																		<?=$i[4][Name]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Tipo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[4][Slot]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sexo:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[4][Sex]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span style="font-size: 7pt" align="center">
																		Nivel:</span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[4][Level]?></span></td>
																	</tr>
																	<tr>
																		<td width="51" align="left">
																		<span color="#0099FF" style="font-size: 7pt" align="center">
																		<span style="color:0099FF">Precio:</span></span></td>
																		<td width="68" align="left">
																		<span style="font-size: 7pt" align="center">
																		<?=$i[4][Price]?></span></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															<div align="center">
															<a href="index.php?do=infoevent&itemid=<?=$i[4][ID]?>">
															<img border="0" src="images/btn_moreinfo.jpg" width="83" height="21" id="img1770" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1770'".',/*url*/'."'images/btn_moreinfo_on.jpg'".')"></a>
															<a href="index.php?do=buyevent&itemid=<?=$i[4][ID]?>">
															<img border="0" src="images/btn_buyitem.jpg" width="83" height="21" id="img1771" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'."'img1771'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="16">												</td>
												<td width="207" height="16">												</td>
											</tr>
										</table>
									</div>									</td>
								</tr>
								<tr>
									<td width="417">&nbsp;</td>
								</tr>
								<tr>
								<td style="background-image: url('images/md_MPI.jpg'); background-repeat: no-repeat; background-position: center top" height="305" width="417">
								  <div align="center">
                                            <table border="0" style="border-collapse: collapse" width="417" height="100%">
											<tr>
												<td width="206" height="23">&nbsp;</td>
												<td width="207" height="23">&nbsp;</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<center><table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top">
															  <div align="center"><img border="0" src="images/shop/<?=$items[4][ImageURL]?>" width="77" height="108" style="border: 1px solid #ffffff" /></div></td>
															<td width="123">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="123" height="48%">
																	<tr>
																		<td colspan="2">
																		<div align="left">
																		<b><span class="item_name">
																		<?=$items[4][Name]?>
																		</span></b></td>
																	</tr>
																	<tr>
																		<td width="36" align="left">
																		<span style="font-size: 7pt" align="center">
																		Tipo:</span></td>
																		<td width="77" align="left">
																		<span style="font-size: 7pt" align="center">
																		Set Completo</span></td>
																	</tr>
																	<tr>
																		<td width="36" align="left">
																		<span style="font-size: 7pt" align="center">
																		Sexo:</span></td>
																		<td width="77" align="left"><?=$items[4][Sex]?></td>
																	</tr>
																	<tr>
																		<td width="36" align="left">
																		<span style="font-size: 7pt" align="center">
																		Nivel:</span></td>
																		<td width="77" align="left"><?=$items[4][Level]?></td>
																	</tr>
																	<tr>
																		<td width="36" align="left">
																		<span color="#0099FF" style="font-size: 7pt" align="center">
																		<span style="color:0099FF">Precio:</span></span></td>
																		<td width="77" align="left"><?=$items[4][Price]?></td>
																	</tr>
																</table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															
															  <div align="left"><a href="index.php?do=infoevent&itemid=<?=$i[1][ID]?>"></a>
															    <a href="index.php?do=buyset&setid=<?=$items[4][ID]?>">
													        <img src="images/btn_buyitem.jpg" name="img1765" width="83" height="21" border="0" id="img1765" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1765'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td>
														</tr>
													</table></center>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
												  <table border="0" style="border-collapse: collapse" width="206" height="91%">
                                                    <tr>
                                                      <td width="5">&nbsp;</td>
                                                      <td width="72">&nbsp;</td>
                                                      <td width="123">&nbsp;</td>
                                                    </tr>
                                                    <tr>
                                                      <td width="5">&nbsp;</td>
                                                      <td width="72" valign="top"><img src="images/shop/<?=$items[5][ImageURL]?>" alt="2" width="77" height="108" border="0" style="border: 1px solid #ffffff" /></td>
                                                      <td width="123"><div align="center">
                                                        <table border="0" style="border-collapse: collapse" width="123" height="48%">
                                                          <tr>
                                                            <td colspan="2"><div align="left">
                                                                <b><span class="item_name">
                                                                <?=$items[5][Name]?>
                                                              </span></b></td>
                                                          </tr>
                                                          <tr>
                                                            <td width="36" align="left"><span style="font-size: 7pt" align="center"> Tipo:</span></td>
                                                            <td width="77" align="left"><span style="font-size: 7pt" align="center"> Set Completo</span></td>
                                                          </tr>
                                                          <tr>
                                                            <td width="36" align="left"><span style="font-size: 7pt" align="center"> Sexo:</span></td>
                                                            <td width="77" align="left"><?=$items[5][Sex]?></td>
                                                          </tr>
                                                          <tr>
                                                            <td width="36" align="left"><span style="font-size: 7pt" align="center"> Nivel:</span></td>
                                                            <td width="77" align="left"><?=$items[5][Level]?></td>
                                                          </tr>
                                                          <tr>
                                                            <td width="36" align="left"><span color="#0099FF" style="font-size: 7pt" align="center"> <span style="color:0099FF">Precio:</span></span></td>
                                                            <td width="77" align="left"><?=$items[5][Price]?></td>
                                                          </tr>
                                                        </table>
                                                      </div></td>
                                                    </tr>
                                                    <tr>
                                                      <td width="202" height="30" colspan="3"> <div align="left"><a href="index.php?do=infoevent&itemid=<?=$i[2][ID]?>"></a> <a href="index.php?do=buyset&setid=<?=$items[5][ID]?>"> <img src="images/btn_buyitem.jpg" alt="s" name="img1765" width="83" height="21" border="0" id="img1765" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1765'".',/*url*/'."'images/btn_buyitem_on.jpg></a></div></td></tr>
                                                  </table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															 <td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top"><img src="images/shop/<?=$items[6][ImageURL]?>" alt="2" width="77" height="108" border="0" style="border: 1px solid #ffffff" /></td>
															<td width="123">
															<div align="center">
															  <table border="0" style="border-collapse: collapse" width="123" height="48%">
                                                                <tr>
                                                                  <td colspan="2"><div align="left">
                                                                    <b><span class="item_name">
                                                                    <?=$items[6][Name]?>
                                                                  </span></b></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Tipo:</span></td>
                                                                  <td width="77" align="left"><span style="font-size: 7pt" align="center"> Set Completo</span></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Sexo:</span></td>
                                                                  <td width="77" align="left"><?=$items[6][Sex]?></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Nivel:</span></td>
                                                                  <td width="77" align="left"><?=$items[6][Level]?></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span color="#0099FF" style="font-size: 7pt" align="center"> <span style="color:0099FF">Precio:</span></span></td>
                                                                  <td width="77" align="left"><?=$items[6][Price]?></td>
                                                                </tr>
                                                              </table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															  <div align="left">															    <a href="index.php?do=buyset&setid=<?=$items[6][ID]?>">
														        <img src="images/btn_buyitem.jpg" name="img1769" width="83" height="21" border="0" id="img1769" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1769'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td></tr>
													</table>
												</div>												</td>
												<td width="207" height="129">
												<div align="center">
													<table border="0" style="border-collapse: collapse" width="206" height="91%">
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72">&nbsp;</td>
															<td width="123">&nbsp;</td>
														</tr>
														<tr>
															<td width="5">&nbsp;</td>
															<td width="72" valign="top"><img src="images/shop/<?=$items[7][ImageURL]?>" alt="2" width="77" height="108" border="0" style="border: 1px solid #ffffff" /></td>
															<td width="123">
															<div align="center">
															  <table border="0" style="border-collapse: collapse" width="123" height="48%">
                                                                <tr>
                                                                  <td colspan="2"><div align="left">
                                                                    <b><span class="item_name">
                                                                    <?=$items[7][Name]?>
                                                                  </span></b></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Tipo:</span></td>
                                                                  <td width="77" align="left"><span style="font-size: 7pt" align="center"> Set Completo</span></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Sexo:</span></td>
                                                                  <td width="77" align="left"><?=$items[7][Sex]?></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span style="font-size: 7pt" align="center"> Nivel:</span></td>
                                                                  <td width="77" align="left"><span style="font-size: 7pt" align="center">
                                                                    <?=$items[7][Level]?>
                                                                  </span></td>
                                                                </tr>
                                                                <tr>
                                                                  <td width="36" align="left"><span color="#0099FF" style="font-size: 7pt" align="center"> <span style="color:0099FF">Precio:</span></span></td>
                                                                  <td width="77" align="left"><span style="font-size: 7pt" align="center">
                                                                    <?=$items[7][Price]?>
                                                                  </span></td>
                                                                </tr>
                                                              </table>
															</div>															</td>
														</tr>
														<tr>
															<td width="202" height="30" colspan="3">
															  <div align="left"><a href="index.php?do=infoevent&itemid=<?=$i[4][ID]?>"></a>
															    <a href="index.php?do=buyset&setid=<?=$items[7][ID]?>">
														        <img src="images/btn_buyitem.jpg" name="img1771" width="83" height="21" border="0" id="img1771" onmouseover="FP_swapImg(1,1,/*id*/'." onmouseout="FP_swapImgRestore()"'img1771'".',/*url*/'."'images/btn_buyitem_on.jpg'".')"></a></div></td></tr>
													</table>
												</div>												</td>
											</tr>
											<tr>
												<td width="206" height="16">												</td>
												<td width="207" height="16">												</td>
											</tr>
										</table>
									</div>									</td>
								</tr>
							</table>
						</div>						</td>
						<td width="171" valign="top">
						<div align="center">
						  <? include "blocks/block_login.php";
                        ?>
						</div></td>
					</tr>
</table>