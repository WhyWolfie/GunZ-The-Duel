﻿<? 
include "skrconfignamecolor.php";
include("secure/include.php");
?>
<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=buycolorname");
    SetMessage("Mensaje Compra name color", array("Usted necesita loguearse para comprar name color."));
    header("Location: index.php?do=login");
    die();
}
$query00 = mssql_query("SELECT CID FROM Character(nolock) WHERE AID = '{$_SESSION['AID']}' AND CharNum != '-1' AND Name != '' ");

  if (mssql_num_rows($query00) < 1) {
    SetMessage("Mensaje Compra name color", array("Usted no tiene ningun PJ."));
    header("Location: index.php?do=$redirec");
    die();
  }
SetTitle("$namegz - Nombre a Color");

 if (isset($_POST['submit'])) {
      $aid = ($_SESSION['AID']);
	  $mygrade = ($_SESSION['UGradeID']);
      $grade = ($_POST['color']);
      $price = intval($price);
	  $cssid = intval(1);
      
	     
      
	  switch($grade){
		case $num_color_1;
		$grade = $num_color_1;
		break;  
		case $num_color_2;
		$grade = $num_color_2;
		break; 		  
		case $num_color_3;
		$grade = $num_color_3;
		break; 	
		case $num_color_4;
		$grade = $num_color_4;
		break; 
		case $num_color_5;
		$grade = $num_color_5;
		break; 
		case $num_color_6;
		$grade = $num_color_6;
		break; 
		case $num_color_7;
		$grade = $num_color_7;
		break; 
		case $num_color_8;
		$grade = $num_color_8;
		break;
		case $num_color_9;
		$grade = $num_color_9;
		break; 
		case $num_color_10;
		$grade = $num_color_10;
		break;
		case $num_color_11;
		$grade = $num_color_11;
		break;
		case $num_color_12;
		$grade = $num_color_12;
		break;
		case $num_color_13;
		$grade = $num_color_13;
		break;
		case $num_color_14;
		$grade = $num_color_14;
		break;
		case $num_color_15;
		$grade = $num_color_15;
		break;
		case $num_color_16;
		$grade = $num_color_16;
		break;
		case $num_color_17;
		$grade = $num_color_17;
		break;		
		default:
        SetMessage("Mensaje Compra name color", array("La Identificación del color no es válido!"));
        header("Location: index.php?do=buycolorname");
        die();	  
	  }
      if (!is_numeric($grade)) {
          SetMessage("Mensaje Compra name color", array("Nombre del color no es válido!"));
          header("Location: index.php?do=buycolorname");
          die();
      }
       
      elseif($mygrade == 254 || $mygrade == 255 || $mygrade == 252 )  {
		  SetMessage("Mensaje Compra name color", array("No puedes comprar name color"));
          header("Location: index.php?do=buycolorname");
          die();  
	  }
	    
	  else
	if (empty($grade)) {
          SetMessage("Mensaje Compra name color", array("No seleccione un color!"));
          header("Location: index.php?do=buycolorname");
          die();
      } else {
         
          $query = mssql_query("SELECT $typecoins FROM Account(nolock) WHERE AID = '$aid'");
		  $skr = mssql_fetch_row($query);
          $info = mssql_fetch_assoc($query);
          $updatecoins = $info['$typecoins'] - $price;
          
          if ($skr[0] < $price) {
          SetMessage("Mensaje Compra name color", array("Usted no tiene $typecoins suficientes para comprar name color"));
          header("Location: index.php");
          die();
          } else {
           
              $addcolor = mssql_query_logged("UPDATE Account SET $typecoins = $typecoins - $price WHERE AID = $aid");
					mssql_query("UPDATE Account SET UGradeID = '$grade' WHERE AID = '$aid'");
			 $by = "";
              if ($addcolor) {
				 
				  $_SESSION[UGradeID] = $grade;
                   msgbox("Su nombre a color fue comprado con gran Exito!.","index.php?do=nicks");
                  header("Location: index.php?do=$redirec");
                  die();
              } else {
                  SetMessage("Mensaje Compra name color", array("Hubo problemas con la compra."));
                  header("Location: index.php?do=$redirec");
                  die();
              }
          }
      }
  } else {
    
     
      $query01 = mssql_query("SELECT $typecoins, UGradeID FROM Account(nolock) WHERE AID = '{$_SESSION[AID]}'");
      $infoacc = mssql_fetch_object($query01);
	  
	  

  }
?>


<table border="0" style="border-collapse: collapse" width="778">
					<tr>
                        <td width="164" valign="top">
                            <table border="0" style="border-collapse: collapse" width="164">
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
                                
                                </td>
                            </tr>
                            <tr>
                                <td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
                                <div align="center">
        							<table border="0" style="border-collapse: collapse" width="164">
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127">
                                            <a href="index.php?do=shop">
                                            <img border="0" src="images/btn_newestitems_off.jpg" id = "76176img" width="132" height="22" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_newestitems_on.jpg')"></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopevent"><img border="0" src="images/btn_eventitems_off.jpg" id="eventitems37" width="132" height="26" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'eventitems37',/*url*/'images/btn_eventitems_on.jpg')" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopsets"><img src="images/btn_completeset_off.jpg" alt="" width="132" height="26" border="0" id="7816imgxD271" onmouseover="FP_swapImg(1,1,/*id*/'7816imgxD271',/*url*/'images/btn_completeset_on.jpg')" onmouseout="FP_swapImgRestore()" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=3"><img border="0" src="<?=($_GET[cat] <> 3) ? "images/btn_armor_off.jpg" : "images/btn_armor_on.jpg"?>" id="7816img272" width="132" height="25" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img272',/*url*/'images/btn_armor_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=2"><img border="0" src="<?=($_GET[cat] <> 2) ? "images/btn_meleeweapons_off.jpg" : "images/btn_meleeweapons_on.jpg"?>" id="7816img273" width="132" height="25" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img273',/*url*/'images/btn_meleeweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=1"><img border="0" src="<?=($_GET[cat] <> 1) ? "images/btn_rangedweapons_off.jpg" : "images/btn_rangedweapons_on.jpg"?>" id="7816img274" width="132" height="27" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img274',/*url*/'images/btn_rangedweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=5"><img border="0" src="<?=($_GET[cat] <> 5) ? "images/btn_specialitems_off.jpg" : "images/btn_specialitems_on.jpg"?>" id="7816img275" width="132" height="23" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img275',/*url*/'images/btn_specialitems_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        								  <td>&nbsp;</td>
        								  <td><a href="index.php?do=nicks" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image11','','../images/btn_nameitems_on.jpg',1)"><img src="../images/btn_nameitems_off.jpg" name="Image11" width="132" height="27" border="0" id="Image11" /></a></td>
        								  <td>&nbsp;</td>
      								  </tr>
   								  </table>
        						</div>

        						</td>
                        </tr>
                        <tr>
    						<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
                            <div align="center">
                            <p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p>
    						<p>&nbsp;</p></div></td>
                        </tr>
                            </table>
                        </td>
						<td width="599" valign="top">
						<div align="center">
                        <form method="POST" action="index.php?do=buycolorname" name="buycolorname">
							<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
								<tr>
									<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
									<td style="background-repeat: repeat; background-position: center top" width="583" valign="top">
									<div align="center">
										<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%" bordercolor="#4A4648">
											<tr>
												<td>
												<div align="center">
													
                                                    <table border="0" style="border-collapse: collapse" width="579" height="100%">
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="458" colspan="2"></td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104" valign="top">
															<div align="center">
															<img border="0" src="images/shop/Especial/buycolorname.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></td>
															<td width="458" colspan="2">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="458" height="100%">
																	<tr>
																		<td width="19">
																		<div align="left">&nbsp;</td>
																		<td width="435" colspan="2">
																		<div align="left">
																		<b>
																		Nombre a Color
																		</b></td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Tipo:																		</td>
																		<td width="372" align="left">Especial</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Duracion:</td>
																		<td width="372" align="left">
																		Permanente</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Nivel:</td>
																		<td width="372" align="left">
																		0</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="61" align="left">
																		Precio:</td>
																		<td width="372" align="left"><? echo $price?> DonadorCoins</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																		<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">
																		<div align="center">Elije: <select name="color" class="cero">
                                <option selected value="">Seleccionar color</option>
                                <option  value="<? echo $num_color_1 ?>"><? echo $name_color_1 ?></option>
                                <option  value="<? echo $num_color_2 ?>"><? echo $name_color_2 ?></option>
                                <option  value="<? echo $num_color_3 ?>"><? echo $name_color_3 ?></option>
                                <option  value="<? echo $num_color_4 ?>"><? echo $name_color_4 ?></option>
                                <option  value="<? echo $num_color_5 ?>"><? echo $name_color_5 ?></option>
                                <option  value="<? echo $num_color_6 ?>"><? echo $name_color_6 ?></option>
                                <option  value="<? echo $num_color_7 ?>"><? echo $name_color_7 ?></option>
                                <option  value="<? echo $num_color_8 ?>"><? echo $name_color_8 ?></option>
                                <option  value="<? echo $num_color_9 ?>"><? echo $name_color_9 ?></option>
                                <option  value="<? echo $num_color_10 ?>"><? echo $name_color_10 ?></option>
								<option  value="<? echo $num_color_11 ?>"><? echo $name_color_11 ?></option>
                                <option  value="<? echo $num_color_12 ?>"><? echo $name_color_12 ?></option>
                                <option  value="<? echo $num_color_13 ?>"><? echo $name_color_13 ?></option>
                                <option  value="<? echo $num_color_14 ?>"><? echo $name_color_14 ?></option>
                                <option  value="<? echo $num_color_15 ?>"><? echo $name_color_15 ?></option>
                                <option  value="<? echo $num_color_16 ?>"><? echo $name_color_16 ?></option>
                                <option  value="<? echo $num_color_17 ?>"><? echo $name_color_17 ?></option>                               </select></div>
																		</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																	<tr>
																		<td width="19">&nbsp;</td>
																	</tr>
																</table>
																
															</div>
															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
															<td width="435" align="left" rowspan="4">
															<div align="center">
																<table border="0" style="border-collapse: collapse" width="435" height="66">
																	<tr>
																		<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
																		<div align="center">
																			<table border="0" style="border-collapse: collapse" width="419" height="100%">
																				<tr><!--  Creditos a Sacker   :  s4cker@hotmail.com -->
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left">Total:</td>
																					<td width="62" align="left"><? echo $price?></td><!--  Creditos a Sacker   :  s4cker@hotmail.com -->
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left">Actual Balance</td>
																					<td width="62" align="left"><?=$infoacc->$typecoins?></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="216">&nbsp;</td>
																					<td width="117" align="left">Despues:</td>
																					<td width="62" align="left"><?=$infoacc->$typecoins-$price?></td>
																					<td width="16">&nbsp;</td>
																				</tr>
																				<tr>
																					<td width="413" colspan="4" height="1"></td>
																				</tr>
																			</table>
																		</div>
																		</td>
																		<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td><!--  Creditos a Sacker   :  s4cker@hotmail.com -->
																	</tr>
																</table>
															</div>
															</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr><!--  Creditos a Sacker   :  s4cker@hotmail.com -->
															<td width="11">&nbsp;</td>
															<td width="104">&nbsp;</td>
															<td width="19">&nbsp;</td>
														</tr>
														<tr>
															<td width="569" colspan="4"></td>
														</tr>
													</table>

												</div>
												</td>
											</tr>
										</table>
									</div>
									</td><!--  Creditos a Sacker   :  s4cker@hotmail.com -->
									<td style="background-repeat: repeat; background-position: center top" width="7">&nbsp;</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">&nbsp;<!--  Creditos a Sacker   :  s4cker@hotmail.com -->
									</td>
								</tr>
								<tr>
									<td style="background-repeat: repeat; background-position: center top" width="597" colspan="3">
									<p align="center">
									<input type="image" id="img1764" src="images/cart.gif" alt="buy color name" width="79" height="23" value="submit" name="submit"/>
									
									<a href="index.php?do=shopitem">
									<img border="0" src="images/btn_cancel_off.jpg" width="79" height="23" id="img1765" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'img1765',/*url*/'images/btn_cancel_on.jpg')"></a></p></td>
								</tr>
								<tr>
									<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
								</tr>
							</table>
                            </form>
						</div>
                     
						</td>
					</tr>
				</table>

<!--  Creditos a Sacker   :  s4cker@hotmail.com -->