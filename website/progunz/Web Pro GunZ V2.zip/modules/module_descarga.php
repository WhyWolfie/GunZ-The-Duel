<?
include("secure/include.php");
header("Location: index.php?do=download");
?>