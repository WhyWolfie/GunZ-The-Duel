<? 
$nombregunz			=		"Pro Gamers Gunz";		
$precio			=		"350";  
$coins		=		"EventCoins";
$redirec		=		"nicks"; 
$numjjang	=	"2";
$namejjang	=	"Jjang";
?>