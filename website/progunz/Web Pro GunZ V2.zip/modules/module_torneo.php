<?
include("secure/include.php");
?><head>

</head>
<?

if( $_SESSION['AID'] == "" )
{
    SetURL("index.php?do=signature");
    SetMessage("Mensaje del sistema", array("Tienes que estar logueado para utilizar esta funcion"));
    header("Location: index.php?do=login");
    die();
}

SetTitle("GalaxiaGamers Gunz - Torneo");

    $qbt01 = mssql_query_logged("SELECT CID, Name FROM Character(nolock) WHERE AID = '".$_SESSION['AID']."'AND CharNum != '-1'");
    if( mssql_num_rows($qbt01) < 1 )
    {
        SetMessage("Mensaje del sistema", array("No tienes personajes"));
        header("Location: index.php");
        die();
    }

?>

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>
						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Inscripcion - Torneo</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center"><form name="clan" method="post" action"">
										<table border="0" style="border-collapse: collapse" width="414" height="100%">
											<tr>
												<td width="10" height="22">&nbsp;</td>
												<td width="315" colspan="3" height="22">&nbsp;</td>
												<td width="11" height="22">&nbsp;</td>
											</tr>
											<tr>
												<td width="10">&nbsp;</td>
												<td width="181">
												<p align="right">Selecciona El Clan a Inscribir</td>
												<td width="13">&nbsp;</td>
												<td width="190">
												<select size="1" name="clanclid">
                                                <?
                                                while( $row1 = mssql_fetch_array($qbt01) )
                                                {

    											$select2 = "SELECT * FROM Clan WHERE MasterCID = '".$row1['CID']."'";
    											$query2 = mssql_query($select2);
    											$rows2 = mssql_num_rows($query2);
    											

    											while($rowc = mssql_fetch_array($query2))
    											{
    												?>
    												<option value="<?=$rowc['CLID']?>"><?=$rowc['Name']?></option>
    												<?
    											}
                                                }
                                            
                                                ?>
												</select>
												<br><br>
											</td>
												<td width="11"><input type="submit" name="enviar" value="Procesar" style="border:none;background:#08f;color:white;text-shadow:1px 1px 4px black;border-radius:.5em;cursor:pointer;padding:5px;"/></td>
											</tr>
											
										</table></form><br><br><br>
										<?
										if(isset($_POST['enviar']))
										{
											?>
											Selecciona Los Personajes a Participar (Maximo 4 Personajes).<br><br>
											<?
											$clanclid = $_POST['clanclid'];
											$selectasd = "SELECT * FROM ClanMember WHERE CLID = '".$clanclid."'";
											$queryasd = mssql_query($selectasd);
											while($rowasd = mssql_fetch_array($queryasd))
											{
												$selectcc = "SELECT * FROM Character WHERE CID = '".$rowasd['CID']."'";
												$querycc = mssql_query($selectcc);
												$rowcc = mssql_fetch_array($querycc);
												?>
												<section style="text-align:left;">
												&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <input type="checkbox" name="<?=$rowasd['CLID']?>"> <?=$rowcc['Name']?><br>
											</section>
												<?
											}
											?>
											<br><br>
											<input type="submit" name="enviar2" value="Finalizar Inscripcion" style="border:none;background:#08f;color:white;text-shadow:1px 1px 4px black;border-radius:.5em;cursor:pointer;padding:5px;"/><br><br>
											<?
										}
										?>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>