<?php
include("secure/include.php");
if($_SESSION[AID] == ""){
	SetURL("index.php?do=shop");
    SetMessage("Mensaje de la Tienda", array("Logueate Primero Por Favor"));
    header("Location: index.php?do=login");
    die();
	}
$price = 	250; // precio
$typedecoins = "Coins"; // Typo de table
$name	= 	"Pro Gamers Gunz - Cambiar Nombre"; // Name
/*____________________________________________
*/
$q		=	mssql_query("SELECT * From Account WHERE AID='".$_SESSION[AID]."'");
$acc = mssql_fetch_object($q);
$dcoins = $acc->$typedecoins;
$total	= $dcoins - $price;
if(isset($_POST['comprar'])){
	if($dcoins < $price){
		SetMessage("Mensaje de la Tienda", array("No tienes suficientes DonadorCoins $total."));
        header("Location: index.php?do=nicks");
        die();	
	}
		if($_POST['userid'] == ""){
		SetMessage("Mensaje de la Tienda", array("No dejes el campo vacio."));
        header("Location: index.php?do=nicks");
        die();
		}
	mssql_query("UPDATE Character SET Name='".$_POST['userid']."' WHERE CID='".$_POST['id']."'");
	mssql_query("UPDATE Account SET Coins='".$total."' WHERE AID='".$_SESSION['AID']."'");
   msgbox("Su nombre fue cambiado con gran Exito!.","index.php?do=nicks");
        header("Location: index.php?do=nicks");
        die();
	
	}
?>

<table style="border: 0px; padding: 0px; width: 800px">
<tr>
<td width="800">&nbsp;</td>
<td width="778">
<table border="0" style="border-collapse: collapse" width="778">
<tr>
<td width="164" valign="top">
<table border="0" style="border-collapse: collapse" width="164">
<tr>
<td width="164" style="background-image: url('images/md_content_menu_t.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">&nbsp;</td>
</tr>
<tr>
<td width="164" style="background-image: url('images/md_content_menu_m.jpg'); background-repeat: repeat-y; background-position: center top" valign="top">
<div align="center">
        							<table border="0" style="border-collapse: collapse" width="164">
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127">
                                            <a href="index.php?do=shop">
                                            <img border="0" src="images/btn_newestitems_off.jpg" id = "76176img" width="132" height="22" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'76176img',/*url*/'images/btn_newestitems_on.jpg')"></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopevent"><img border="0" src="images/btn_eventitems_off.jpg" id="eventitems37" width="132" height="26" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'eventitems37',/*url*/'images/btn_eventitems_on.jpg')" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopsets"><img src="images/btn_completeset_off.jpg" alt="" width="132" height="26" border="0" id="7816imgxD271" onmouseover="FP_swapImg(1,1,/*id*/'7816imgxD271',/*url*/'images/btn_completeset_on.jpg')" onmouseout="FP_swapImgRestore()" /></a></td>
       									  <td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=3"><img border="0" src="<?=($_GET[cat] <> 3) ? "images/btn_armor_off.jpg" : "images/btn_armor_on.jpg"?>" id="7816img272" width="132" height="25" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img272',/*url*/'images/btn_armor_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=2"><img border="0" src="<?=($_GET[cat] <> 2) ? "images/btn_meleeweapons_off.jpg" : "images/btn_meleeweapons_on.jpg"?>" id="7816img273" width="132" height="25" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img273',/*url*/'images/btn_meleeweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=1"><img border="0" src="<?=($_GET[cat] <> 1) ? "images/btn_rangedweapons_off.jpg" : "images/btn_rangedweapons_on.jpg"?>" id="7816img274" width="132" height="27" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img274',/*url*/'images/btn_rangedweapons_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        									<td width="14">&nbsp;</td>
        									<td width="127"><a href="index.php?do=shopitem&cat=5"><img border="0" src="<?=($_GET[cat] <> 5) ? "images/btn_specialitems_off.jpg" : "images/btn_specialitems_on.jpg"?>" id="7816img275" width="132" height="23" onmouseout="FP_swapImgRestore()" onmouseover="FP_swapImg(1,1,/*id*/'7816img275',/*url*/'images/btn_specialitems_on.jpg')" /></a></td>
        									<td width="17">&nbsp;</td>
        								</tr>
        								<tr>
        								  <td>&nbsp;</td>
        								  <td><a href="index.php?do=nicks" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image11','','../images/btn_nameitems_on.jpg',1)"><img src="../images/btn_nameitems_off.jpg" name="Image11" width="132" height="27" border="0" id="Image11" /></a></td>
        								  <td>&nbsp;</td>
      								  </tr>
   								  </table>
        						</div>
</td>
</tr>
<tr>
<td width="164" style="background-image: url('images/md_content_menu_d.jpg'); background-repeat: no-repeat; background-position: center top" valign="top">
<div align="center"><br><br><br><br><br><br><br><br></div>
</td>
</tr>
</table>
</td>
<td width="599" valign="top">
<div align="center">
<table border="0" style="background-position: center top; border-collapse: collapse; background-image:url('images/content_bg.jpg'); background-repeat:repeat-y" width="603">
<tr>
<td style="background-image: url('images/content_title_shop_buyitem.jpg'); background-repeat: no-repeat; background-position: center top" height="25" width="601" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="7">&nbsp;</td>
<td width="583" valign="top">
<div align="center">
<table border="1" style="border-collapse: collapse; border: 1px solid #4A4648" width="100%">
<tr>
<td>
<div align="center">
<form method="POST" action="index.php?do=cambiodename" name="frmBuy">
<table border="0" style="border-collapse: collapse" width="579">
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="458" colspan="2">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104" valign="top">
<input type="hidden" name="comprar" />
<div align="center">
<img alt="" border="0" src="../images/shop/donador/changename.gif" width="100" height="100" style="border: 2px solid #1D1B1C"></div>
</td>
<td width="458" colspan="2">
<div align="center">
<table border="0" style="border-collapse: collapse" width="458" height="100%">
<tr>
<td width="19">&nbsp;</td>
<td width="435" colspan="2">
<div align="left">
<b><font size="2"><?=$name?></font></b>
</div>
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="61" align="left">Tipo:</td>
<td width="372" align="left">Especial</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="61" align="left">Precio:</td>
<td width="372" align="left">
<span id="currentprice"><?=$price?></span> DonadorCoins
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
<td width="435" colspan="2" rowspan="5" style="background-image: url('images/mis_eumember.jpg'); background-repeat: no-repeat; background-position: center" valign="middle">
<div align="center">
  <table width="317" border="0">
    <tr>
    <th width="158" scope="col">Selecciona tu personaje</th>
    <td width="143" scope="col"><select name="id">
      <?php
$que = mssql_query("SELECT * From Character WHERE AID='".$_SESSION[AID]."'");
while($char = mssql_fetch_object($que)){
?>
      <option value="<?=$char->CID?>">
        <?=$char->Name?>
        </option>
      <? } ?>
    </select></td>
  </tr>
  <tr>
    <td> Nuevo nombre:</td>
    <td><input name="userid" class="textLogin" tabindex="1" size="16" maxlength="12" /></td>
  </tr>
</table>
</div>
<div align="center"></div>
</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="19">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
<td width="435" align="left" rowspan="4">
<div align="center">
<table border="0" style="border-collapse: collapse" width="435" height="66">
<tr>
<td style="background-image: url('images/mis_finalbalance.jpg'); background-repeat: no-repeat; background-position: right center" width="419">
<div align="center">
<table border="0" style="border-collapse: collapse" width="419" height="100%">
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Total:</td>
<td width="62" align="left"><?=$price?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Balance Actual</td>
<td width="62" align="left"><?=$dcoins?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="216">&nbsp;</td>
<td width="117" align="left">Despues:</td>
<td width="62" align="left"><?=$total?></td>
<td width="16">&nbsp;</td>
</tr>
<tr>
<td width="413" colspan="4" height="1"></td>
</tr>
</table>
</div>
</td>
<td style="background-repeat: no-repeat; background-position: left center" width="12">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="11">&nbsp;</td>
<td width="104">&nbsp;</td>
<td width="19">&nbsp;</td>
</tr>
<tr>
<td width="569" colspan="4">&nbsp;</td>
</tr>
</table>

</form>
</div>
</td>
</tr>
</table>
</div>
</td>
<td width="7">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="597" colspan="3">
<div align="center">
<a href="javascript:document.frmBuy.submit();">
<img alt="" border="0" src="images/btn_buyitem2_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_buyitem2_off.jpg'" onmouseover="this.src='images/btn_buyitem2_on.jpg'">
</a>
<a href="index.php?do=shopitem">
<img alt="" border="0" src="images/btn_cancel_off.jpg" width="79" height="23" onmouseout="this.src='images/btn_cancel_off.jpg'" onmouseover="this.src='images/btn_cancel_on.jpg'">
</a>
</div>
</td>
</tr>
<tr>
<td height="17" style="background-image: url('images/content_top.jpg'); background-repeat: no-repeat; background-position: center bottom" width="601" colspan="3"></td>
</tr>
</table>
</div>
</td>
</tr>
</table>
</td>
<td width="12">&nbsp;</td>
</tr>
</table>
</div>
</td>
</tr>
</table>