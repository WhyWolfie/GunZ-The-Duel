<?
include("secure/include.php");
header("Location: index.php?do=individualrank");
die();
?>