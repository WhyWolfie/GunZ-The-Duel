<? 
// Configuracion de Price redireccion y type de coins   By sacker.
$namegz			=		"GalaxiaGamers Gunz";		// Name del GunZ Por Default viene con Galaxia Gunz
$price			=		"250";  // PRECIO DEL NAME COLOR
$typecoins		=		"Coins"; // Tabla del tipo de Coins Existe 3, Coins, EventCoins y DonatorCoins
$redirec		=		"nicks"; // Cuando compre o aiga problemas a dnd qieress q vaya del do
//____________________________________________________________
// CONFIGURACION NAME COLOR BY SACKER

$num_color_1	=	"3"; // NumeroUgrade Color 1
$num_color_2	=	"18"; // NumeroUgrade Color 1
$num_color_3	=	"11"; // NumeroUgrade Color 1
$num_color_4	=	"19"; // NumeroUgrade Color 1
$num_color_5	=	"10"; // NumeroUgrade Color 1
$num_color_6	=	"5"; // NumeroUgrade Color 1
$num_color_7	=	"12"; // NumeroUgrade Color 1
$num_color_8	=	"7"; // NumeroUgrade Color 1
$num_color_9	=	"8"; // NumeroUgrade Color 1
$num_color_10	=	"9"; // NumeroUgrade Color 1
$num_color_11	=	"17"; // NumeroUgrade Color 1
$num_color_12	=	"4"; // NumeroUgrade Color 1
$num_color_13	=	"6"; // NumeroUgrade Color 1
$num_color_14	=	"13"; // NumeroUgrade Color 1
$num_color_15	=	"15"; // NumeroUgrade Color 1
$num_color_16	=	"16"; // NumeroUgrade Color 1
$num_color_17	=	"14"; // NumeroUgrade Color 1

//Name del color 

$name_color_1	=	"Rosado,Gris,lila,celeste claro,Verde Foforecente,Rojo"; // Nombre del primer color
$name_color_2	=	"Rojo,Negro,Fuxia,Azul Oscuro"; // Nombre del primer color
$name_color_3	=	"Verde Mata,Anaranjado"; // Nombre del primer color
$name_color_4	=	"Rojo,Amarillo"; // Nombre del primer color
$name_color_5	=	"Rojo,Negro"; // Nombre del primer color
$name_color_6	=	"Anaranjado Oscuro"; // Nombre del primer color
$name_color_7	=	"Amarillo Pollito"; // Nombre del primer color
$name_color_8	=	"Verde Pastel"; // Nombre del primer color
$name_color_9	=	"Gris Oscuro"; // Nombre del primer color
$name_color_10	=	"Azul Oscuro"; // Nombre del primer color
$name_color_11	=	"Azul Claro"; // Nombre del primer color
$name_color_12	=	"Lila Claro"; // Nombre del primer color
$name_color_13	=	"Amarillo"; // Nombre del primer color
$name_color_14	=	"Rosado"; // Nombre del primer color
$name_color_15	=	"Dorado"; // Nombre del primer color
$name_color_16	=	"Morado"; // Nombre del primer color
$name_color_17	=	"Rojo"; // Nombre del primer color

// Todos los creditos a Sacker  :  s4cker@hotmail.com  
?>