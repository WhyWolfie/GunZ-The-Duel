<?
session_start();
include "secure/config.php";
?>
<body style="background:black;">
<title>LOG DE GIFT - Pro Gamers GunZ</title>
<?
if(isset($_SESSION['plog']))
{
	?>

<center><h1><font color="red"><marquee>.:: LOGS DE GIFT - Pro Gamers GunZ::.</marquee></font></h1></center>
	<?
}
?>
<?
if(isset($_POST['logout']))
{
	session_destroy();
	?>
	<meta http-equiv="refresh" content="0;url=log.php"/>
	<?
}
if(isset($_POST['login']))
{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	if($user == "GalaxiaGunz")
	{
		if($pass == "PedroAnyLennyn")
			{
				$_SESSION['plog']="Galaxia00989098911233";
				?>
				<meta http-equiv="refresh" content="0;url=log.php"/>
				<?
			}else{
				?>
				<font color="white">Error Al Logear</font>.
				<?
			}
	}else{
		?>
		<font color="white">Error Al Logear</font>.
		<?
	}
}
if(!isset($_SESSION['plog']) && $_SESSION['plog'] != "Galaxia00989098911233")
{
	echo "<font color='red' size='20'><center>No Tienes Permiso By [__W__]
</center>";
	?>
	<center>
	<font color="white">Porfavor Inicia Sesi&oacute;n Para Poder Acceder.</font>
</center>
	<h6>
	<center>
		<font color="white">
	<form method="post" action=""><br><br>
	User :<input type="text" name="user"/><br>
	Pass :<input type="password" name="pass"/><br>
	<input type="submit" name="login" value="Entrar"/>
</h6>
</font>
</center>
</form>
	<?
}else{
	?>
<?
$any0 = "SELECT * FROM LogItems ORDER BY id DESC";
$query = mssql_query($any0);
while($any = mssql_fetch_array($query))
{
	if($any['tipo'] == '0')
	{
		$tipo = '<font color="black"><b>Item Donador</b></font>';
	}elseif($any['tipo'] == '1')
	{
		$tipo = '<font color="black"><b>Item Evento</b></font>';
	}
	$any2 = "SELECT * FROM Account WHERE AID = '".$any['AID1']."'";
	$query2 = mssql_query($any2);
	if($any01 = mssql_fetch_array($query2))
	{
		$user1 = $any01['UserID'];
		$any3 = "SELECT * FROM Account WHERE AID = '".$any['AID2']."'";
		$query3 = mssql_query($any3);
		if($any02 = mssql_fetch_array($query3))
		{
			$user2 = $any02['UserID'];

	?>
	<center>
<section style="background:#08f;padding:5px;border-top:1px solid black;min-width:900px;display:inline-block;">
	<font color="black"><strong>Fecha:</strong> <i><?=$any['Fecha']?></i></font> <b>|</b> <font color="#FF0000"><strong><?=$user1?> 
	[<?=$any['AID1']?>]</strong></font> <font color="black"><strong>Regalo ItemID:</strong></font> <font color="#000000"><i>[<?=$any['item']?>]
</i></font> <strong>A</strong> <font color="#FFFF00"><strong><?=$user2?>[<?=$any['AID2']?>]</strong></font> <font color="black"><strong>Tipo: 
</strong><i><?=$tipo?></i></strong> <a href="borrarlog.php?id=<?=$any['id']?>"><span style="text-decoration:none;color:red;"><strong>Borrar Registro
</strong></span></a>
</section>


	<?
}
}
}
}
?>
</td>
</tr>
<?
if(isset($_SESSION['plog']))
{
	?>
<style>
#any{
-webkit-transform:rotate(270deg);position:absolute;left:-28px;bottom:31px;font-weight:bold;font-family:arial;font-size:12px;padding-top:4px;
-webkit-transition:.5s;
-moz-transition:.5s;
-moz-transform:rotate(270deg);
cursor:default;s
}
#any:hover{

}
#tot{
position:fixed;padding:0px;color:white;right:-98px;bottom:37%;background:#08f;padding:20px;
-moz-transition:.5s;
-webkit-transition:.5s;
}
#tot:hover{
	right:0px;
}
#boton{
	background:#333;
	border-radius:5px;
	box-shadow:2px 2px 2px black;
	cursor:pointer;
}
#boton:hover{
	background:#555;
}
</style>
<form method="post" action="">		
	<section  id="tot">
<section id="any" style="">
		<font color="#ff0">Salir Del Log</font>
	</section>
	&nbsp;
<input id="boton" style="border:none;color:white;padding:10px;padding-left:20px;padding-right:20px;" type="submit" value="Salir" name="logout"/>
</section>

</form>

	<?
}
?>