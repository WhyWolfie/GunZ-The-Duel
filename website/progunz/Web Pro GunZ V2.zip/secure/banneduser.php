<?
if($_SESSION['UGradeID'] == 253){
?>
<html>
<head>
<meta http-equiv="Content-Language" content="es">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="icon" href="favicons.png" type="image/ico"/> 
<title>Pro Gamers Gunz - Cuenta Banned</title>
<link rel="stylesheet" type="text/css" href="images/style.css">
<script language="JavaScript" src="functions.js"> </script>
 <SCRIPT language="JavaScript">
                </SCRIPT>
<style type="text/css">
<!--
body {
	background-image: url(images/bg2.jpg);
}
-->
</style></head>
										<form name="reg" method="POST" action="index.php?do=register">
	<body bgcolor="#312F30">

					<div align="center">
						<table border="0" width="456" style="border-collapse: collapse">
							<tr>
								<td background="images/cont_up.jpg">&nbsp;</td>

							</tr>
							<tr>
								<td background="images/cont_bg.jpg">
								<div align="center">
									<table border="0" style="border-collapse: collapse" width="454" height="100%">
										<tr>
											<td width="4" rowspan="6">&nbsp;</td>
											<td width="436"><font size="4"><font color=#FF0000>Querido <?=$_SESSION['UserID']?>,</font>

										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">&nbsp;
											</td>
											<td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434">

                                                                                           Su cuenta ha sido prohibido por la Guerra equipo Pro Gamers Gunz
											                                            <p>Creo que ya s� c�mo lleg� a este punto.</p>
                                                                                        <p>Siempre se puede hacer una nueva cuenta desde la p�gina de registro.</p>
                                                                                        <p>Usted siempre puede tratar de obtener readmitido en la secci�n de un ban <a href="http://info.muonlinedarkz.com/forumdisplay.php?30-Gunz-Online">forum</a>.</p>
                                                                                        <p>As� que esta vez, aseg�rese de leer y seguir las Reglas <a href="http://info.muonlinedarkz.com/showthread.php?404-Reglamentos-GalaxiaGamers-Gunz">Reglas</a>.</p>
                                                                                        <p>Have a nice day.</p>
											                                            <p>Gracias, el equipo de GalaxiaGamers Gunz</td>
										  <td width="8">&nbsp;</td>
										</tr>
										<tr>
											<td width="434" height="24">

											<center>
											&nbsp;</center></td>
											<td width="8" height="24">&nbsp;</td>
										</tr>
									</table>
								</div>
								</td>
							<tr>
								<td background="images/cont_top.jpg" height="27">&nbsp;</td>
							</tr>
						</table>
					</div></form>


    <?
    die();
}

?>