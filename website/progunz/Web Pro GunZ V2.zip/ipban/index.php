 
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /gunz/ipban/index.php was not found on this server.</p>
<hr>
<address>Apache/2.2.8 (Win32) PHP/5.2.6 Server at gunzgalaxia.zapto.org Port 80</address>
</body></html>
