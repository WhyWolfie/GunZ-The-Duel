<?
session_start();
include "../secure/config.php";
if(isset($_POST['logout']))
{
	session_destroy();
	?>
	<meta http-equiv="refresh" content="0;url=banip.php"/>
	<?
}
if(isset($_POST['login']))
{
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	if($user == "GalaxiaGunz" && $pass == "PedroAnyLennyn")
	{
				$_SESSION['pban']="Galaxia00989098911233";
				?>
				<meta http-equiv="refresh" content="0;url=banip.php"/>
				<?
		}else{
				?>
				<font color="white">Error Al Logear</font>.
				<?
	}
}
?>
<title>BANEAR IP - GalaxiaEntertainment </title>
<body style="background:black;color:white;">
<?
if(isset($_SESSION['pban']) && $_SESSION['pban']=="Galaxia00989098911233")
{
	if(isset($_POST['enviar']))
	{
		$ip = $_POST['ip'];
		$insert = "INSERT INTO IPBan(ip)";
		$insert.= "VALUES('".$ip."')";
		mssql_query($insert);
	}
	if(isset($_POST['enviar2']))
	{
		$ip2 = $_POST['ip2'];
		$delete  = "DELETE FROM IPBan WHERE ip = '".$ip2."'";
		mssql_query($delete);
	}
	?>
	<center>
	<form method="post" action="">
		<marquee><h1><font color="red">.:: Banear IP - GalaxiaEntertainment ::.</h1></marquee>
		<br><br><br><br><br><br><br><br><br><br><br>
		<table width="350" height="129" align="center" style="display:inline-block;background:#0099FF; color:#white; border-radius:8px 8px 8px 8px;">
		  <tr>
		  	<center><td><center> <section style="background:#222;padding:5px;display:block;">Banear IP</section><br>
		  <input type="text" name="ip" style="background:#666666; padding:5; border:#666666; color:#FFFFFF; border-radius:6px 6px 6px 6px;"/>	 
		  &nbsp; &nbsp; <input type="submit" name="enviar" value="Banear IP" id="boton"/></td>
		</tr></table> &nbsp; &nbsp;
		<table width="350" height="129" align="center" style="display:inline-block;background:#0099FF; color:#CCCCCC; border-radius:8px 8px 8px 8px;">
		  <tr><td><center><font color="white"><section style="background:#222;padding:5px;">Desbanear IP</section></font><br><select name="ip2" style="background:#666666; padding:5; border:#666666; color:#FFFFFF; border-radius:6px 6px 6px 6px;">
			<?
			$select = "SELECT * FROM IPBan ORDER BY id DESC";
			$query = mssql_query($select);
			$rows = mssql_num_rows($query);
			if($rows>0)
			{
				while($row = mssql_fetch_array($query))
				{
					?>
					<option value="<?=$row['ip']?>"><?=$row['ip']?></option>
					<?
				}
				
			}else{
				?>
				<option value="">No Hay Elementos</option>
				<?
			}
			?>
		</select>
		&nbsp; &nbsp; &nbsp; <input type="submit" name="enviar2" id="boton" value="Desbanear IP"/>
	</form></td></tr></table>
	<?
}else{
?>
<center>
<h1>	Porfavor Inicia Sesi&oacute;n para usar este modulo.<br>
		<font color="red">No Tienes Permiso By Faragon.</font><br>
	<br><br>
	<form method="post" action="">

	User: <input type="text" name="user"/><br>
	Pass: <input type="password" name="pass"/><br>
	<input type="submit" name="login" value="Acceder"/>

	</form>
	<?
}
?>
<?
if(isset($_SESSION['pban']))
{
	?>
<style>
#any{
-webkit-transform:rotate(270deg);position:absolute;left:-33px;bottom:40px;font-weight:bold;font-family:arial;font-size:12px;padding-top:4px;
-webkit-transition:.5s;
-moz-transition:.5s;
-moz-transform:rotate(270deg);
cursor:default;
border-radius:7px 7px 0px 0px;
}
#any:hover{

}
#tot{
position:fixed;padding:0px;color:white;right:-98px;bottom:37%;background:#08f;padding:20px;
-moz-transition:.5s;
-webkit-transition:.5s;
height:60px;
}
#tot:hover{
	right:0px;
}
#boton{
	background:#333;
	border-radius:5px;
	box-shadow:2px 2px 2px black;
	cursor:pointer;
	border:none;color:white;padding:10px;padding-left:20px;padding-right:20px;
}
#boton:hover{
	background:#555;
}
</style>
<form method="post" action="">		
	<section  id="tot">
<section id="any" style="border-radius:10px 10px 0px 0px">
		<font color="#ff0">Salir Del IPBan</font>
	</section>
	&nbsp;
<input id="boton" type="submit" value="Salir" name="logout"/>
</section>

</form>

	<?
}
?>