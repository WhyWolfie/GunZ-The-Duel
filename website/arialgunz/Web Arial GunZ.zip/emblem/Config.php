<?php
/////Lo editamos con nuestros datos
$DBHost = 'WIN-7UEPLS2T57L\SQLEXPRESS';
$DBUser = 'sa';
$DBPass = 'Aura_GamersOficial';
$DB = 'GunzDB';
?>
