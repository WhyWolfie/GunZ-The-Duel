<?php
// Config Siganture
$url	=	"http://auragz.zapto.org/";
$img 	=	"images/sign.png";

?>