<?
include("secure/include.php");

</script>
<?
SetTitle("AuraGamers Gunz - Descargas");
?>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

//-->
</script>
<script type="text/JavaScript">
<!--
//-->
</script>
<script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
<body onLoad="MM_preloadImages('../../../ASA/MenuDescarga/btn_dl_fileserve_of.jpg','../../../ASA/MenuDescarga/btn_dl_sendspace_of.jpg','../images/MenuDescarga/btn_dl_sendspace_of.jpg','../../images/MenuDescarga/btn_dl_fileserve_of.jpg','../../images/MenuDescarga/btn_dl_sendspace_of.jpg','../images/MenuDescarga/btn_dl_sendspace_of.jpg')">

<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
						<td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>						</div>						</td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Descargas</font></b></td>
								</tr>
								<tr>
									<td bgcolor="#2C2A2A">
									<div align="center">
											<table border="0" style="border-collapse: collapse; float:left" width="408" height="100%">
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="376" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">
												<p align="center">
												<img border="0" src="../images/mis_download.jpg" width="365" height="67"></td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="380" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="4" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											  <td width="366" style="background-repeat: no-repeat; background-position: center top">
												<div align="center">
												  <table border="0" style="border-collapse: collapse" width="100%" height="96%">
                                                    <tr>
                                                      <td width="98%"><div align="center"><a href="https://mega.co.nz/#!H842kQ6L!dxAq4yvaoFFU_6sSGRzkhq0ud-Z1p2bHc1KLXn976O0" target="_blank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Mega','','../images/btn_mirror1_on.jpg',1)"><img src="../images/btn_mirror1_off.jpg" name="Mega" width="120" height="21" border="0"></a> &nbsp; <a href="http://www.mediafire.com/download/7hntsxjrb3xbrdc/Cliente+AuraGamers.exe" target="_blank" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image3','','../images/btn_mirror2_on.jpg',1)"><img name="Image3" border="0" src="../images/btn_mirror2_off.jpg"></a></div></td>
                                                      <td width="1%"></td>
                                                    </tr>
                                                  </table>
												</div>
												
												<table border="0" style="border-collapse: collapse" width="100%" height="96%">
                                                  <tr>
                                                    <td width="98%">&nbsp;</td>
                                                    <td width="1%"></td>
                                                  </tr>
                                              </table></td>
												<td width="8" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top" colspan="3">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">												</td>
											  <td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" height="180" valign="top">
												<div align="center">
													<table border="0" cellpadding="3" cellspacing="1" width="100%">
														<tr>
															<td bgcolor="#121212" width="80">
															<span style="font-size: 7pt">
															&nbsp;</span></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Minimos</span></b></td>
															<td bgcolor="#121212" width="220">
															<b>
															<span style="font-size: 7pt">
															Recomendados</span></b></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															OS</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Windows 2000, Windows XP, Windows 7, Windows Vista</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															DirectX</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															DirectX 9.0c</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															CPU</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Pentium III 500 Mhz</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Pentium III 800 Mhz															</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Memory</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															256 MB</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															512 MB or above</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Graphic Card</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Direct3D 9.0
															Compatible</span></td>
															<td align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															GeForce 4 MX or higher</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212" height="21">
															<span style="font-size: 7pt">
															Sound Card</span></td>
															<td colspan="2" align="center" bgcolor="#232323" height="21">
															<span style="font-size: 7pt">
															Direct3DSound
															Compatible</span></td>
														</tr>
														<tr>
															<td align="center" bgcolor="#121212">
															<span style="font-size: 7pt">
															Mouse</span></td>
															<td colspan="2" align="center" bgcolor="#232323">
															<span style="font-size: 7pt">
															Windows Compatible (Mouse De Ruedita Recomendado)</span></td>
														</tr>
													</table>
												</div>												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											<tr>
												<td width="9" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
												<td width="379" style="background-repeat: no-repeat; background-position: center top; " colspan="3" valign="top">&nbsp;												</td>
												<td width="13" style="background-repeat: no-repeat; background-position: center top">&nbsp;												</td>
											</tr>
											</table>
									</div>									</td>
								</tr>
							</table>
						</div>
						<p align="center"></td>
						<td width="171" valign="top">
						<div align="center">
						  <? include "blocks/block_login.php" ?>
						</div>						</td>
					</tr>
</table>
<?
$filhodaputa = array(";","'","\"","*","union","x:","x:\#","delete ","///","from|xp_|execute|exec|sp_executesql|sp_|select| insert|delete|where|drop table|show tables|#|\*|","DELETE","insert",","|"x'; U\PDATE Character S\ET level=99;-\-","x';U\PDATE Account S\ET ugradeid=255;-\-","x';U\PDATE Account D\ROP ugradeid=255;-\-","x';U\PDATE Account D\ROP ",",W\\HERE 1=1;-\\-","z'; U\PDATE Account S\ET ugradeid=char","update","drop","sele","memb","set" ,"$","res3t","wareh","%","--",'chr(', 'chr=', 'chr%20', '%20chr', 'wget%20', '%20wget', 'wget(', 'cmd=', '%20cmd', 'cmd%20', 'rush=', '%20rush', 'rush%20', 'union%20', '%20union', 'union(', 'union=', 'echr(', '%20echr', 'echr%20', 'echr=', 'esystem(', 'esystem%20', 'cp%20', '%20cp', 'cp(', 'mdir%20', '%20mdir', 'mdir(', 'mcd%20', 'mrd%20', 'rm%20', '%20mcd', '%20mrd', '%20rm', 'mcd(', 'mrd(', 'rm(', 'mcd=', 'mrd=', 'mv%20', 'rmdir%20', 'mv(', 'rmdir(', 'chmod(', 'chmod%20', '%20chmod', 'chmod(', 'chmod=', 'chown%20', 'chgrp%20', 'chown(', 'chgrp(', 'locate%20', 'grep%20', 'locate(', 'grep(', 'diff%20', 'kill%20', 'kill(', 'killall', 'passwd%20', '%20passwd', 'passwd(', 'telnet%20', 'vi(', 'vi%20', 'insert%20into', 'select%20', 'fopen', 'fwrite', '%20like', 'like%20', '$_request', '$_get', '$request', '$get', '.system', 'HTTP_PHP', '&aim', '%20getenv', 'getenv%20', 'new_password', '&icq','/etc/password','/etc/shadow', '/etc/groups', '/etc/gshadow', 'HTTP_USER_AGENT', 'HTTP_HOST', '/bin/ps', 'wget%20', 'uname\x20-a', '/usr/bin/id', '/bin/echo', '/bin/kill', '/bin/', '/chgrp', '/chown', '/usr/bin', 'g\+\+', 'bin/python', 'bin/tclsh', 'bin/nasm', 'perl%20', 'traceroute%20', 'ping%20', '.pl', 'lsof%20', '/bin/mail', '.conf', 'motd%20', 'HTTP/1.', '.inc.php', 'config.php', 'cgi-', '.eml', 'file\://', 'window.open', '<script>', 'javascript\://','img src', 'img%20src','.jsp','ftp.exe', 'xp_enumdsn', 'xp_availablemedia', 'xp_filelist', 'xp_cmdshell', 'nc.exe', '.htpasswd', 'servlet', '/etc/passwd', 'wwwacl', '~root', '~ftp', '.js', '.jsp', 'admin_', '.history', 'bash_history', '.bash_history', '~nobody', 'server-info', 'server-status', 'reboot%20', 'halt%20', 'powerdown%20', '/home/ftp', '/home/www', 'secure_site, ok', 'chunked', 'org.apache', '/servlet/con', '<script', 'UPDATE', 'SELECT', 'DROP', '/robot.txt' ,'/perl' ,'mod_gzip_status', 'db_mysql.inc', '.inc', 'select%20from', 'select from', 'drop%20', 'getenv', 'http_', '_php', 'php_', 'phpinfo()', '<?php', '?>', 'sql='); 
$word = "";
foreach($_POST as $value) 
foreach($filhodaputa as $word) 
if(substr_count($value, $word) > 0) 
die("<script>alert('Error'); location='javascript:history.back()'</script>");
Function GeovaneSouza($string){
$letras = $filhodaputa;
$arrumar = "";
return str_replace($letras, $arrumar, $string);
die("<script>alert('Error'); location='javascript:history.back()'</script>");
}
?>