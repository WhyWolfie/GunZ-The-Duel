<?php
include("secure/include.php");
if($_SESSION[AID] <> "")
{
    $u = $_SESSION[UserID];

    session_unset();

    if (isset($_COOKIE[session_name()]))
    {
        setcookie(session_name(), '', time()-42000, '/');
    }

    session_destroy();

    SetMessage("Mensaje de Sistema", array("User $u desconectado correctamente"));
    header("Location: index.php");
    die();
}else{
    SetMessage("Mensaje de Sistema", array("No puedes desconectarte ya que no estas conectado!"));
    header("Location: index.php");
    die();
}

?>