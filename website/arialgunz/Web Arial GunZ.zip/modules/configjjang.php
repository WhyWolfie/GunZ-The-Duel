<? 
$nombregunz	="AuraGamers Gunz";		
$precio		="250";  
$coins		="EventCoins";
$redirec	="jjang"; 
$numjjang	="2";
$namejjang	="Jjang";
?>