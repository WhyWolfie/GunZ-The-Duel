<?php
include("secure/include.php");
SetTitle("AuraGamers Gunz - Staff");
if ($_SESSION['AID'] == "")
{
    SetURL("index.php?do=delclan");
    SetMessage("Donate", array("Para ver la lista del Staff debe estar logeado."));
    header("Location: index.php?do=login");
    die();
}
?>
<table border="0" style="border-collapse: collapse" width="100%">
					
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          
						</div>						<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Lista De Staff</font></b></td>
							  </tr>
								<tr>
            <td align="center" class="Estilo1"><table width="450" height="200" border="0" bgcolor="#151515">
              <tr>
                <td width="98" align="left" class="Estilo1"><font color="#D7D21C">&nbsp; </font><font color="#FF8000">Fundadores</font></td>
                <td width="110" align="left" class="Estilo1"><font color="#FF0000"> Administradores</font></td>
                <td width="81" align="left" class="Estilo1"><font color="#00FFFF">GamersMasters</font></td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#FF8000">Jesus1997</font></p>
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#FF8000">Hessen</font></p>
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#FF8000">Edwin</font></p></td>
                <td align="left" class="Estilo1">
                   &nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#FF0000">Morqui</font></p>
                  <p>&nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#FF0000">L�is Torres</font></p>
                  &nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#FF0000">No Data</font></td>
                <td align="left" class="Estilo1">
                  <p>&nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FFFF">Luis Villegas</font></p>
                  <p>&nbsp;<img src="images/mis_arrorr23.jpg" alt="" width="10" height="10" /><font color="#00FFFF">No Data</font></p>
                  <p align="left">&nbsp;<img border="0" src="images/mis_arrorr23.jpg" width="10" height="10"/><font color="#00FFFF">No Data</font></p>
				  
                </td>
              </tr>
              <tr>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
              <tr>
                <td height="33" align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
                <td align="left" class="Estilo1">&nbsp;</td>
              </tr>
            </table>
			</td>          
          </tr>
									
									
								</tr>
							</table>
							</table>
<p align="center">&nbsp;
<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
				</table>