<?php
SetTitle("AuraGamers Gunz - UserCP");
?>
<table border="0" style="border-collapse: collapse" width="100%">
					<tr>
					  <td width="183" valign="top">
						<div align="center">
							<? include "blocks/block_rankingu.php" ?>
						</div>
						<p>
						<div align="center">
                          <p>
                            <? include "blocks/block_rankingc.php" ?>
                          <p>
						</div>						<p>&nbsp;</p></td>
						<td valign="top">
						<div align="center">
							<table border="1" style="border-collapse: collapse" width="100%" bordercolor="#000000">
								<tr>
									<td background="images/content_bar.jpg" height="24" style="background-image: url('images/content_bar.jpg'); background-repeat: no-repeat; background-position: center top">
									<div align="center">
										<b><font face="Tahoma" size="2">Panel de Usuario</font></b></td>
							  </tr>
								<tr>
									<td bgcolor="#373737">
									<div align="center"><form method="POST" action="index.php?do=changebt" name="changebt">
									  <table width="358" border="0">
									  </tr>
                                      <tr></tr>
                                      <tr></tr>
                                      <tr>
                                        <td width="170">&nbsp;</td>
                                        <td width="10">&nbsp;</td>
                                        <td width="170">&nbsp;</td>
                                      </tr>
<td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF"> Lista de Staff</font></span></td>
  <td width="30" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=Staff">Click Here</a></td>
</tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
<td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF"> Recuperar personajes</font></span></td>
  <td width="30" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=recoverchar">Click Here</a></td>
</tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
  <td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF">Comprar Jjang</font></span></td>
  <td width="30" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=jjang">Click Here</a></td>
</tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
<td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF"> Comprar Donator Coins</font></span></td>
  <td width="30" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=donate">Click Here</a></td>
</tr>
<tr></tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
<td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF"> Cambiar name a un Pj</font></span></td>
  <td width="0" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=changename">Click Here</a></td>
</tr>
<tr></tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
<td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF"> Ultimos Clan Wars</font></span></td>
  <td width="0" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=ultimascw">Click Here</a></td>
</tr>
<tr></tr>
<tr></tr>
<tr>
  <td width="170">&nbsp;</td>
  <td width="10">&nbsp;</td>
  <td width="170">&nbsp;</td>
</tr>
  <td align="left" width="170"><span style="font-size: 9pt"><font color="#FFFFFF">Comprar Nombre A Color</font></span></td>
  <td width="0" bgcolor="#373737">&nbsp;</td>
  <td align="right" width="170"><a href="index.php?do=buycolorname">Click Here</a></td>
</tr>
<tr></tr>
<tr></tr>
									  </table>
									</form>
									</div>
									</td>
								</tr>
							</table>
						</div>
						<p align="center">&nbsp;</td>
						<td width="171" valign="top">
						<div align="center">
							<? include "blocks/block_login.php" ?>
						</div>
						</td>
					</tr>
				</table>