<? 
// Configuracion de Price redireccion y type de coins By AuraGamers Gunz.
$namegz			=		"AuraGamers";		// Name del GunZ Por Default viene con AuraGamers Gunz
$price			=		"60";  // PRECIO DEL NAME COLOR
$typecoins		=		"DonatorCoins"; // Tabla del tipo de Coins Existe 3, Coins, EventCoins y DonatorCoins
$redirec		=		"buycolorname"; // Cuando compre o aiga problemas a donde qieress q vaya del donator
//____________________________________________________________
// CONFIGURACION NAME COLOR BY AuraGamers Gunz

$num_color_1	=	"3"; // NumeroUgrade Color
$num_color_2	=	"4"; // NumeroUgrade Color
$num_color_3	=	"5"; // NumeroUgrade Color
$num_color_4	=	"6"; // NumeroUgrade Color
$num_color_5	=	"7"; // NumeroUgrade Color
$num_color_6	=	"8"; // NumeroUgrade Color
$num_color_7	=	"9"; // NumeroUgrade Color
$num_color_8	=	"10"; // NumeroUgrade Color
//Name del color 

$name_color_1	=  "Azul"; // Nombre del Primer color
$name_color_2	=  "Verde"; // Nombre del Primer color
$name_color_3	=  "Rosado"; // Nombre del Primer color
$name_color_4	=  "Morado"; // Nombre del Primer color
$name_color_5	=  "Dorado"; // Nombre del Primer color
$name_color_6	=  "Plomo"; // Nombre del Primer color
$name_color_7	=  "Cyan"; // Nombre del Primer color
$name_color_8	=  "Celeste"; // Nombre del Primer color

// Todos los creditos a AuraTeam :  AuraGamers Gunz 
?>