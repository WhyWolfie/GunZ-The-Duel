<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /secure was not found on this server.</p>
<hr>
<address>Apache/2.2.8 (Win32) PHP/6.0.0-dev Server at auragz.zapto.org Port 80</address>

</body></html>