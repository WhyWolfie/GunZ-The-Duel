<table background="images/md_ir.jpg"  width="174" height="143" border="0">
<tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="4" rowspan="6">&nbsp;</td>
        <td height="4" colspan="2">&nbsp;</td>
      </tr>
     <?
$query = mssql_query("SELECT TOP 5 * FROM Account a, Character b WHERE b.AID=a.AID AND a.UGradeID !=255|253 AND DeleteFlag=0 ORDER BY Level DESC, XP DESC, KillCount DESC, DeathCount ASC");

while($query2 = mssql_fetch_assoc($query))
{
 
$aid = $query2['AID'];
$cid = $query2['CID'];
  
?>
	  <tr>
	  <td width="8" align="left">
  															<img src="../images/mis_arrow.jpg"></img></td>
  															<td width="102" align="left"><span class="Estilo6"><?=FormatCharName($query2['CID'])?></span>
         			      <td width="19"><span class="Estilo6">Lv.<?=$query2['Level']?>&nbsp;</span></td>
						   
										<td width="2"></td>
										<td width="3">	
						</td>		</tr><?}?>
                                   
									<tr>
    </table>    <td height="39"></tr>
</table>
