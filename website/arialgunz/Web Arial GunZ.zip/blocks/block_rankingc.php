<?
$res = mssql_query("SELECT TOP 5 * FROM Clan WHERE Name <> '' ORDER BY Point DESC");
?>
<style type="text/css">
<!--
.Estilo6 {
	font-size: 11px;
	color: #FFFFFF;
}
-->
</style>
<table background="images/md_cr.jpg"  width="174" height="143" border="0">
<tr>
    <td><table width="169" height="87" border="0" style="border-collapse: collapse">
      <tr>
        <td width="4" rowspan="6">&nbsp;</td>
        <td height="4" colspan="2">&nbsp;</td>
      </tr>
      <?
                                    if(mssql_num_rows($res) == 0){
                                        ?>
      <tr>
        <td height="23" colspan="2">
          <div align="left" class="Estilo2">No hay datos &laquo; </div></td>
      </tr>
     <?
                                    }else{
                                    while($user = mssql_fetch_assoc($res)){

                                    ?>
      <tr>
	  <td width="7" align="left">
  															<img border="0" src="images/mis_arrow.jpg" width="5" height="9"></td>
  															<td width="104" align="left">
         <span class="Estilo6"><?=$user['Name']?></td>
       <td width="27" align="left">
           <span class="Estilo6"><?=$user['Point']?></td>
      </td>
      </tr>
      <?}}?>
    </table>    <td height="40"></tr>
</table>
<table>
												  <td width="150" colspan="2">&nbsp;</td>
</table>
<table width="185">
  <tr>
									<td width="500"><a href="index.php?do=signature"><img src="images/signature.png" width="175" height="151" /></a></td>
</table>
