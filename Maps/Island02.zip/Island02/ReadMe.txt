
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

~ Dont steal my work.
~ Train more harder.
~ Like I do.

****************************Some textures are re-made & re-edit by ME!!!



     /)../)
   c(  =_=)
 ...(  (")")


~ By: Zurikawa