ClearView - Modified GreenView
==============================

Version 1.0

By JoeyJWC

Introduction
------------
	ClearView is a very fast modification of GreenView.  It increases accuracy by getting rid of the green (hence _Clear_View), allowing for long-range shots as well as mid- and close-range ones.  The description of GreenView is as follows.
	This is a little more bloated than my first crosshair, but it's based on a different style.  I think this is more suitable for mid-range aiming then anything else.  I designed it very quickly, but I might clean up the style for a future kind of crosshair.  It's nothing fancy, but I sort of like it.

Instructions
------------
1.  Open the "Crosshair" folder.
2.  Press CTRL+A.
3.  Press CTRL+C.
4.  Go to your Gunz folder (usually C:\Program Files\Games\MAIET\Gunz\).
5.  If you don't have a folder in it named CUSTOM, make it.  Then, go to into that folder and make another folder called CROSSHAIR.  Open that folder.
6.  Press CTRL+V.
7.  Start Gunz and under Options -> Misc. -> Crosshair select Custom.
8.  Enjoy.

I'm not responsible for anything that happens to your game.  Although nothing will.

Joey C.
http://joeyjwc.x3fusion.com/
GunZFactor.com Forums: JoeyJWC
Gunz: JoeyJWC