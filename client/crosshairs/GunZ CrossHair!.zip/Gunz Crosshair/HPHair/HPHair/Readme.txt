Gunz High Precision Custom Crosshair
====================================

Version 1.0

By JoeyJWC

Introduction
------------
	This is a very simple custom crosshair that I have entitled high precision.  This is because the crosshair was built pixel-by-pixel.  Overall, I don't think it's very fancy, but I tried to make it a little aesthetically pleasing.  My goal, however, was to create a crosshair that allows one to fire a well-placed shot from far away yet still function as an all-purpose crosshair.  It was made with the GIMP on my laptop.  I have the source files (.xcf) available for anyone who wants them.  They are separated into layers to allow easy editing.  I can't really say that I spent a long time on this one...  Well, I hope you enjoy it.

Instructions
------------
1.  Choose a style from the two preview images.
2.  Open the folder containing that style.  Press CTRL+A.
3.  Press CTRL+C.
4.  Go to your Gunz folder (usually C:\Program Files\Games\MAIET\Gunz\.
5.  If you don't have a folder in it named CUSTOM, make it.  Then, go to into that folder and make another folder called CROSSHAIR.  Open that folder.
6.  Press CTRL+V.
7.  Start Gunz and under Options -> Misc. -> Crosshair select Custom.
8.  Enjoy.

I'm not responsible for anything that happens to your game.  Although nothing will.

Joey C.
http://joeyjwc.x3fusion.com/
GunZFactor.com Forums: JoeyJWC
Gunz: JoeyJWC