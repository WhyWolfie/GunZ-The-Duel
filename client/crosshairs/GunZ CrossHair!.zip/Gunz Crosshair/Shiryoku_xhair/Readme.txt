

Yo. So you like this crosshair, huh? Well you should. 
You downloaded it.

If you don't know how, here is how you install a 
crosshair.

1.In your Gunz folder, you should have a CUSTOM folder.
If you do not, make one now.

2. In that CUSTOM folder, make a folder called CROSSHAIR
if you do not already have one.

3.Take all of the files in this zip, and put them in that 
folder. :P If you REALLY need the space, there is no need
to copy CrosshairSkin.bmp, xhair_Pick.jpeg, xhair_Bright.jpg
or xhair_Dark.jpg.

4. Enjoy.

Note: I'm not responsible for anything. I have internet 
immunity. >:( so there.
