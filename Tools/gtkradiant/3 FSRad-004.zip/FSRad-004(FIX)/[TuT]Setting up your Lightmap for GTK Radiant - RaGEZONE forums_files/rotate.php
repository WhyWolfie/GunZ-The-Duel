
                document.write('<table border="0" cellpadding="0" cellspacing="0">');
 	               document.write('<tr>');
                
			document.write('<td style="padding: 5px;">');
				document.write('<a href="http://rotate.frantech.ca/out.php?id=28&s=3" target="_blank">');
					document.write('<img src="http://rotate.frantech.ca/images/1297021528.gif" border="0" style="border: 2px solid #CCCCCC;">');
				document.write('</a>');
			document.write('</td>');
			
			document.write('<td style="padding: 5px;">');
				document.write('<a href="http://rotate.frantech.ca/out.php?id=14&s=3" target="_blank">');
					document.write('<img src="http://rotate.frantech.ca/images/1284558442.jpg" border="0" style="border: 2px solid #CCCCCC;">');
				document.write('</a>');
			document.write('</td>');
			
			document.write('<td style="padding: 5px;">');
				document.write('<a href="http://rotate.frantech.ca/out.php?id=34&s=3" target="_blank">');
					document.write('<img src="http://rotate.frantech.ca/images/1292130594.gif" border="0" style="border: 2px solid #CCCCCC;">');
				document.write('</a>');
			document.write('</td>');
			document.write('</tr>');
			document.write('<tr>');
				document.write('<td colspan="3" align="right" style="padding-right: 5px;">');
					document.write('<a href="http://frantech.ca/?ref=poweredby;s=3" style="font-size: 10px; color: #CCCCCC;">');
						document.write('<img src="http://rotate.frantech.ca/images/poweredby.gif">');
					document.write('</a>');
				document.write('</td>');
			document.write('</tr>');
		document.write('</table>');