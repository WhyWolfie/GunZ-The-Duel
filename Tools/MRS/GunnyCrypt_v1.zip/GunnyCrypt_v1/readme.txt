This software is provided 'as-is', without any express or implied
warranty. In no event will the authors be held liable for any damages
arising from the use of this software.

You may not edit or sell the provided software.

Usage:
1. Put your executable of your client in the folder
2. Type in the numbers in the range shown
3. Wait


Other information:
The MRS.exe is NOT written by me, neither is zlib.dll!
There is a zlib.dll in the dll folder.
zlib.dll NEEDS to be in the same folder as mrs.exe else it WILL NOT work.