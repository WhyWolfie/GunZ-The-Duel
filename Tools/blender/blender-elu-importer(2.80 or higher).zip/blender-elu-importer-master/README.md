# blender-elu-importer
Blender 2.80+ Importer for MAIET's GunZ: The Duel/The Second Duel, RaiderZ ELU/ANI/XML formats

## Installation
1. Download this repository as a .zip.
2. Extract to `%APPDATA%\Blender Foundation\Blender\2.90\scripts\addons\io_mesh_elu`
