#include "fbxsdk.h"
#include "anim.h"
#include "bone_structure.h"
#include <vector>

template<typename T>
int find(const char *name, T *nodes, int size)
{
	for (int i = 0; i < size; ++i) {
		if (strcmp(name, nodes[i].name) == 0)
			return i;
	}
	return -1;
}

FbxNode * create_armature(FbxObject *scene, std::vector<FbxNode*>& nodes)
{
	int n = sizeof(gunz_bones) / sizeof(Bone);

	Matrix4 r(
	{ 0.f, 1.f, 0.f, 0.f },
	{ 1.f, 0.f, 0.f, 0.f },
	{ 0.f, 0.f, 1.f, 0.f },
	{ 0.f, 0.f, 0.f, 1.f }
	);

	for (int i = 0; i < n; ++i) {
		auto node = FbxNode::Create(scene, gunz_bones[i].name);
		auto skeleton = FbxSkeleton::Create(scene, gunz_bones[i].name);
		node->SetNodeAttribute(skeleton);

		auto lt = gunz_bones[i].lt;
		//if (i == 0) lt = lt * r;
		//else lt = r * lt * r;
		auto t = lt.get_translation();
		auto s = lt.get_scale();
		auto r = lt.get_rotation_euler();

		double r2d = 180. / pi;

		node->LclTranslation = { t.x, t.y, t.z };
		node->LclScaling = { s.x, s.y, s.z };
		node->LclRotation = { r.x * r2d, r.y * r2d, r.z * r2d };

		nodes.push_back(node);
	}

	for (int i = 1; i < n; ++i) {
		auto id = find(gunz_bones[i].parent, gunz_bones, n);
		if (id >= 0) {
			nodes[id]->AddChild(nodes[i]);
		}
	}
	return nodes[0];
}


void set_key(FbxAnimCurve *k, int frame, float value)
{
	FbxTime time;
	time.SetFrame(frame);
	time.SetMilliSeconds(frame);
	int id = k->KeyAdd(time);
	k->KeySetValue(id, value);
	k->KeySetTime(id, time);
	k->KeySetInterpolation(id, FbxAnimCurveDef::eInterpolationCubic);
}

Vector3 quat_to_euler(Vector4 &q)
{
	return{
		atan2f(2.f * (q.x * q.y + q.z * q.w), 1.f - 2.f * (q.y * q.y + q.z * q.z)),
		asinf(2 * (q.x * q.z - q.w * q.y)),
		atan2f(2.f * (q.x * q.w + q.y * q.z), 1.f - 2.f * (q.z * q.z + q.w * q.w))
	};
}


//Fix interpolation angles fo unity (UE4 & blender interpolate correclty)
void fix_angle_for_interpolation(FbxAnimCurve *curve)
{
	curve->KeyModifyBegin();

	float CurrentAngleOffset = 0.f;
	for (int32_t KeyIndex = 1; KeyIndex < curve->KeyGetCount(); ++KeyIndex)
	{
		float PreviousOutVal = curve->KeyGetValue(KeyIndex - 1);
		float CurrentOutVal = curve->KeyGetValue(KeyIndex);

		float DeltaAngle = (CurrentOutVal + CurrentAngleOffset) - PreviousOutVal;

		if (DeltaAngle >= 180)
		{
			CurrentAngleOffset -= 360;
		}
		else if (DeltaAngle <= -180)
		{
			CurrentAngleOffset += 360;
		}

		CurrentOutVal += CurrentAngleOffset;

		curve->KeySetValue(KeyIndex, CurrentOutVal);
	}

	curve->KeyModifyEnd();
}

void copy_data(FbxAnimLayer *layer, FbxNode *node, AniNode *anode, AniNode *parent)
{
	auto tx = node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_X, true);
	auto ty = node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Y, true);
	auto tz = node->LclTranslation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Z, true);

	auto rx = node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_X, true);
	auto ry = node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Y, true);
	auto rz = node->LclRotation.GetCurve(layer, FBXSDK_CURVENODE_COMPONENT_Z, true);

#if 1
	tx->KeyModifyBegin();
	ty->KeyModifyBegin();
	tz->KeyModifyBegin();
	auto data = anode->position;
	for (int i = 0; i < anode->num_position; ++i) {
		auto p = data[i].position;
		set_key(tx, data[i].frame, p.x);
		set_key(ty, data[i].frame, p.y);
		set_key(tz, data[i].frame, p.z);
	}
	tx->KeyModifyEnd();
	ty->KeyModifyEnd();
	tz->KeyModifyEnd();
#endif

#if 1
	rx->KeyModifyBegin();
	ry->KeyModifyBegin();
	rz->KeyModifyBegin();
	auto r = anode->rotation;
	for (int i = 0; i < anode->num_rotation; ++i) {
		auto rot = Matrix4().rot_quat(r[i].quat.normalize()).get_rotation_euler() * (180. / pi);
		set_key(rx, r[i].frame, rot.x);
		set_key(ry, r[i].frame, rot.y);
		set_key(rz, r[i].frame, rot.z);
	}
	rx->KeyModifyEnd();
	ry->KeyModifyEnd();
	rz->KeyModifyEnd();
#endif

	if (anode->num_rotation) {
		fix_angle_for_interpolation(rx);
		fix_angle_for_interpolation(ry);
		fix_angle_for_interpolation(rz);
	}
}


template<typename T>
struct SelfDestruct {
	T *ptr;
	SelfDestruct(T *p) : ptr(p) {}
	~SelfDestruct() { ptr->Destroy(); }
};

bool save(const char *name, Animation &ani)
{
	FbxManager *mgr = FbxManager::Create();
	if (!mgr)
		return false;

	SelfDestruct<FbxManager> sd(mgr);

	//Create an IOSettings object. This object holds all import/export settings.
	FbxIOSettings* ios = FbxIOSettings::Create(mgr, IOSROOT);
	mgr->SetIOSettings(ios);

	//Load plugins from the executable directory (optional)
	FbxString path = FbxGetApplicationDirectory();
	mgr->LoadPluginsDirectory(path.Buffer());



	FbxScene *scene = FbxScene::Create(mgr, name);

	std::vector<FbxNode*> bone_nodes;
	auto root = create_armature(scene, bone_nodes);

	scene->GetRootNode()->AddChild(root);

	auto anim_stack = FbxAnimStack::Create(scene, name);
	auto anim_layer = FbxAnimLayer::Create(scene, "Layer 0");
	scene->SetCurrentAnimationStack(anim_stack);
	anim_stack->AddMember(anim_layer);

	auto id = find(root->GetName(), ani.nodes, ani.hdr.num_nodes);

#if 1
	for (int i = 0; i < ani.hdr.num_nodes; ++i) {
		int id = find(ani.nodes[i].name, gunz_bones, bone_nodes.size());
		if (id >= 0) {
			auto parent = find(gunz_bones[id].parent, ani.nodes, ani.hdr.num_nodes);
			copy_data(anim_layer, bone_nodes[id], &ani.nodes[i], parent < 0 ? nullptr : &ani.nodes[parent]);
		}
	}
#endif

	FbxExporter *exporter = FbxExporter::Create(mgr, name);

	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_MATERIAL, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_TEXTURE, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_EMBEDDED, false);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_SHAPE, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_GOBO, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_ANIMATION, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_GLOBAL_SETTINGS, true);

	if (exporter->Initialize(name, -1, mgr->GetIOSettings()) == false)
		return false;

	if (exporter->Export(scene) == false)
		return false;

	return true;
}
