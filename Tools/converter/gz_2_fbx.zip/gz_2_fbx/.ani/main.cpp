#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <assert.h>

#include "anim.h"
#include "reader.h"


const char * ani_names[] = {
	"RAniType_TransForm",
	"RAniType_Vertex",
	"RAniType_Bone",
	"RAniType_Tm",
};


Vector4 r2q(Vector4 v)
{
	float angle = v.w;
	v.x *= sinf(angle / 2.f);
	v.y *= sinf(angle / 2.f);
	v.z *= sinf(angle / 2.f);
	v.w  = cosf(angle / 2.f);
	return v;
}



bool read(const char *name, Animation &ani)
{
	Reader file(name);
	auto &hdr = ani.hdr;
	auto &nodes = ani.nodes;

	file.read(&hdr, sizeof(hdr));

	nodes = new AniNode[hdr.num_nodes];

	if (hdr.ani_type != RAniType_Bone) {
		printf("Expected bone! got %s\n", ani_names[hdr.ani_type]);
		return false;
	}

	for (int i = 0; i < hdr.num_nodes; ++i) {
		auto& node = nodes[i];

		file.read(node.name, sizeof(node.name));
		file.read(&node.base, sizeof(Matrix4));

		node.num_position = file.read_int32();
		if (node.num_position > 0) {
			node.position = new KeyPosition[node.num_position];
			file.read(node.position, sizeof(KeyPosition) * node.num_position);
		}

		node.num_rotation = file.read_int32();
		if (node.num_rotation > 0) {
			node.rotation = new KeyRotation[node.num_rotation];

			file.read(node.rotation, sizeof(KeyRotation) * node.num_rotation);
			if (hdr.version <= EXPORTER_ANI_VER3) {
				for (int j = 0; j < node.num_rotation; ++j)
					node.rotation[j].quat = r2q(node.rotation[j].quat);
			}
		}

		if (hdr.version > EXPORTER_ANI_VER1) {
			node.num_vis = file.read_int32();
			if (node.num_vis > 0) {
				node.vis = new KeyVis[node.num_vis];
				file.read(node.vis, sizeof(KeyVis) * node.num_vis);
			}
		}
	}

	return true;
}


void print(Animation &ani) {
	auto &hdr = ani.hdr;
	auto &nodes = ani.nodes;
	printf("Version: %d\n", hdr.version);
	printf("Type   : %s\n", ani_names[hdr.ani_type]);
	printf("Nodes  : %d\n", hdr.num_nodes);
	printf("max frames: %d\n", hdr.max_frame);

	if (hdr.ani_type == RAniType_Bone) {
		for (int i = 0; i < hdr.num_nodes; ++i) {
			printf("  Name : %s\n", nodes[i].name);
			printf("  pos: %d, rot: %d, vis: %d\n", nodes[i].num_position, nodes[i].num_rotation, nodes[i].num_vis);
		}
	}
}

//fbx.cpp
bool save(const char *name, Animation &ani);

int main(int argc, char * argv[]) {
	if (argc < 2) {
		printf("No file name!\n");
		return -1;
	}
	auto name = argv[1];

	auto output = argc > 2 ? argv[2] : nullptr;

	Animation ani;

	if (!read(name, ani)) {
		printf("Failed to read animation!\n");
		return -1;
	}

	if (output) {
		save(output, ani);
	} else {
		print(ani);
	}
}
