#pragma once

#include <stdint.h>
#include "matrix.h"

#define EXPORTER_ANI_VER1	0x00000012
#define EXPORTER_ANI_VER3	0x00001002

enum AnimationType {
	RAniType_TransForm = 0,
	RAniType_Vertex,
	RAniType_Bone,
	RAniType_Tm,
};

struct KeyPosition
{
	Vector3 position;
	int32_t frame;
};

struct KeyRotation
{
	Vector4 quat;
	int32_t frame;
};

struct KeyVis
{
	float f;
	int32_t frame;
};


struct AniHeader
{
	uint32_t signature;
	uint32_t version;
	int32_t  max_frame;
	int32_t  num_nodes;
	int32_t  ani_type;
};

struct AniNode
{
	char name[40];
	Matrix4 base;
	int32_t num_position;
	int32_t num_rotation;
	int32_t num_vis;

	KeyPosition *position;
	KeyRotation *rotation;
	KeyVis *vis;

	AniNode() : num_position(0), num_rotation(0), num_vis(0), position(nullptr), rotation(nullptr), vis(nullptr) {}
};

struct Animation
{
	AniHeader hdr;
	AniNode *nodes;
};