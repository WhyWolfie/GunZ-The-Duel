#pragma once
#include <math.h>
#include <stdio.h>


const float pi = 3.14159265359f;

struct Vector3
{
	float x, y, z;

	Vector3() = default;
	Vector3(double x, double y, double z) : x(x), y(y), z(z) {}
	Vector3(float *f) : x(f[0]), y(f[1]), z(f[2]) {}
	void print() { printf("{ %f, %f, %f }", x, y, z); }

	float len() {
		return sqrtf(x*x + y*y + z*z);
	}

	Vector3 & normalize() {
		auto l = len();
		x /= l;
		y /= l;
		z /= l;
		return *this;
	}

	Vector3  operator * (float f) {
		Vector3 v;
		v.x = x * f;
		v.y = y * f;
		v.z = z * f;
		return v;
	}

	Vector3 operator - () {
		return { -x, - y, -z };
	}
};

struct Vector4
{
	float x, y, z, w;
	Vector4() = default;
	Vector4(double x, double y, double z, double w) : x(x), y(y), z(z), w(w) {}
	Vector4(float *f) : x(f[0]), y(f[1]), z(f[2]), w(f[3]) {}

	void print() { printf("{ %f, %f, %f, %f }", x, y, z, w); }

	float len() {
		return sqrtf(x*x + y*y + z*z + w*w);
	}

	Vector4 & normalize() {
		auto l = len();
		x /= l;
		y /= l;
		z /= l;
		w /= l;
		return *this;
	}
};

struct Matrix4
{
	float m[16];

	Matrix4() = default;
	Matrix4(const Vector4& c0, const Vector4& c1, const Vector4& c2, const Vector4& c3) {
		m[0] = c0.x; m[1] = c0.y; m[2] = c0.z; m[3] = c0.w;
		m[4] = c1.x; m[5] = c1.y; m[6] = c1.z; m[7] = c1.w;
		m[8] = c2.x; m[9] = c2.y; m[10] = c2.z; m[11] = c2.w;
		m[12] = c3.x; m[13] = c3.y; m[14] = c3.z; m[15] = c3.w;
	}

	float& operator[](int i) {
		return m[i];
	}

	float & operator ()(int i, int j) {
		return m[j * 4 + i];
	}
	float operator ()(int i, int j) const {
		return m[j * 4 + i];
	}

	Matrix4 & identity() {
		m[0] = 1.f; m[1] = 0.f; m[2] = 0.f; m[3] = 0.f;
		m[4] = 0.f; m[5] = 1.f; m[6] = 0.f; m[7] = 0.f;
		m[8] = 0.f; m[9] = 0.f; m[10] = 1.f; m[11] = 0.f;
		m[12] = 0.f; m[13] = 0.f; m[14] = 0.f; m[15] = 1.f;
		return *this;
	}

	Matrix4 & scale(const Vector3& v) {
		m[0] = v.x; m[1] = 0.f; m[2] = 0.f; m[3] = 0.f;
		m[4] = 0.f; m[5] = v.y; m[6] = 0.f; m[7] = 0.f;
		m[8] = 0.f; m[9] = 0.f; m[10] = v.z; m[11] = 0.f;
		m[12] = 0.f; m[13] = 0.f; m[14] = 0.f; m[15] = 1.f;
		return *this;
	}


	Matrix4 & translation(const Vector3 &v) {
		m[0] = 1.f; m[1] = 0.f; m[2] = 0.f; m[3] = v.x;
		m[4] = 0.f; m[5] = 1.f; m[6] = 0.f; m[7] = v.y;
		m[8] = 0.f; m[9] = 0.f; m[10] = 1.f; m[11] = v.z;
		m[12] = 0.f; m[13] = 0.f; m[14] = 0.f; m[15] = 1.f;
		return *this;
	}

	Matrix4 & rot_quat(Vector4 q) {
		q.normalize();
		Matrix4 m({
			{1.0f - 2.0f*q.y*q.y - 2.0f*q.z*q.z, 2.0f*q.x*q.y + 2.0f*q.z*q.w, 2.0f*q.x*q.z - 2.0f*q.y*q.w, 0.0f},
			{2.0f*q.x*q.y - 2.0f*q.z*q.w, 1.0f - 2.0f*q.x*q.x - 2.0f*q.z*q.z, 2.0f*q.y*q.z + 2.0f*q.x*q.w, 0.0f},
			{2.0f*q.x*q.z + 2.0f*q.y*q.w, 2.0f*q.y*q.z - 2.0f*q.x*q.w, 1.0f - 2.0f*q.x*q.x - 2.0f*q.y*q.y, 0.0f},
			{0.0f, 0.0f, 0.0f, 1.0f} });
		*this = m;
		return *this;
	}

	void print() {
		printf("{ %f, %f, %f, %f,\n", m[0], m[1], m[2], m[3]);
		printf("  %f, %f, %f, %f,\n", m[4], m[5], m[6], m[7]);
		printf("  %f, %f, %f, %f,\n", m[8], m[9], m[10], m[11]);
		printf("  %f, %f, %f, %f }", m[12], m[13], m[14], m[15]);
	}

	Vector3 get_translation() const {
		return{ m[12], m[13], m[14] };
	}

	Vector3 get_scale() const {
		Vector3 ax = { m[0], m[1], m[2] };
		Vector3 ay = { m[4], m[5], m[6] };
		Vector3 az = { m[8], m[9], m[10] };
		return{ ax.len(), ay.len(), az.len() };
	}

	Matrix4 get_rotation() const {
		Vector3 ax = { m[0], m[1], m[2] };
		Vector3 ay = { m[4], m[5], m[6] };
		Vector3 az = { m[8], m[9], m[10] };

		ax.normalize();
		ay.normalize();
		az.normalize();

		return Matrix4( {ax.x, ax.y, ax.z, 0.f}, {ay.x, ay.y, ay.z, 0.f}, {az.x, az.y, az.z, 0.f}, {0.f, 0.f, 0.f, 1.f} );
	}

	Vector3 get_rotation_euler2() const {
		auto mat = get_rotation();

		float ry = asinf(-mat(2, 0));
		float rx = atan2f(mat(2, 1), mat(2, 2));
		float rz = atan2f(mat(1, 0), mat(0, 0));

		if (fabs(mat(3, 1)) == 1.f) {
			ry = pi / 2;
			float dif = atan2f(mat(0, 1), mat(0, 2));
			float sum = atan2f(-mat(0, 1), -mat(0, 2));
			rx = (dif + sum) / 2.f;
			rz = (sum - dif) / 2.f;
		}

		return { rx, ry, rz };
	}

	Vector3 get_rotation_euler() const {
		auto mat = get_rotation();

		float sy = sqrtf(mat(0,0) * mat(0,0) + mat(1,0) * mat(1,0) );
 
		bool singular = sy < 1e-6; // If
 
		float x, y, z;
		if (!singular)
		{
			x = atan2f(mat(2,1) , mat(2,2));
			y = atan2f(-mat(2,0), sy);
			z = atan2f(mat(1,0), mat(0,0));
		}
		else
		{
			x = atan2f(-mat(1,2), mat(1,1));
			y = atan2f(-mat(2,0), sy);
			z = 0.f;
		}
		return{ x, y, z };
	}

	Vector3 operator * (Vector3 &v) const {
		return{
			v.x * m[0] + v.y * m[4] + v.z * m[8] + m[12],
			v.x * m[1] + v.y * m[5] + v.z * m[9] + m[13],
			v.x * m[2] + v.y * m[6] + v.z * m[10] + m[14]
		};
	}

	Vector4 operator * (Vector4 &v) const {
		return{
			v.x * m[0] + v.y * m[4] + v.z * m[8] + v.w * m[12],
			v.x * m[1] + v.y * m[5] + v.z * m[9] + v.w * m[13],
			v.x * m[2] + v.y * m[6] + v.z * m[10] + v.w * m[14],
			v.x * m[3] + v.y * m[7] + v.z * m[11] + v.w * m[15]
		};
	}

	Matrix4 operator * (Matrix4 &mat) const {
		Vector4 c0(&mat.m[0]);
		Vector4 c1(&mat.m[4]);
		Vector4 c2(&mat.m[8]);
		Vector4 c3(&mat.m[12]);

		c0 = this->operator*(c0);
		c1 = this->operator*(c1);
		c2 = this->operator*(c2);
		c3 = this->operator*(c3);

		return Matrix4(c0, c1, c2, c3);
	}

	Matrix4 operator - (Matrix4 &mat) const {
		Matrix4 r;
		for (int i = 0; i < 16; ++i)
			r.m[i] = m[i] - mat.m[i];
		return r;
	}

	Matrix4 transpose() const {
		Vector4 r0(m[0], m[4], m[8], m[12]);
		Vector4 r1(m[1], m[5], m[9], m[13]);
		Vector4 r2(m[2], m[6], m[10], m[14]);
		Vector4 r3(m[3], m[7], m[11], m[15]);

		return Matrix4(r0, r1, r2, r3);
	}

	Matrix4 affine_inverse() const {
		auto rot = get_rotation();
		auto t = get_translation();
		auto s = get_scale();
		// T * R * S
		Matrix4 ri, si;
		// S^-1 R^-1 T^-1
		si.scale({ 1.f / s.x, 1.f / s.y, 1.f / s.z });
		ri = rot.transpose();

		auto mul = si * ri;
		auto ti = -(mul * t);

		mul(0, 3) = ti.x;
		mul(1, 3) = ti.y;
		mul(2, 3) = ti.z;

		return mul;
	}
};

#if 0
Vector4 MatrixToQuaternion(const Matrix4& mat)
{
	auto fourXSquaredMinus1 = mat(0, 0) - mat(1, 1) - mat(2, 2);
	auto fourYSquaredMinus1 = mat(1, 1) - mat(0, 0) - mat(2, 2);
	auto fourZSquaredMinus1 = mat(2, 2) - mat(0, 0) - mat(1, 1);
	auto fourWSquaredMinus1 = mat(0, 0) + mat(1, 1) + mat(2, 2);

	int biggestIndex = 0;
	auto fourBiggestSquaredMinus1 = fourWSquaredMinus1;
	if (fourXSquaredMinus1 > fourBiggestSquaredMinus1)
	{
		fourBiggestSquaredMinus1 = fourXSquaredMinus1;
		biggestIndex = 1;
	}
	if (fourYSquaredMinus1 > fourBiggestSquaredMinus1)
	{
		fourBiggestSquaredMinus1 = fourYSquaredMinus1;
		biggestIndex = 2;
	}
	if (fourZSquaredMinus1 > fourBiggestSquaredMinus1)
	{
		fourBiggestSquaredMinus1 = fourZSquaredMinus1;
		biggestIndex = 3;
	}

	auto biggestVal = sqrt(fourBiggestSquaredMinus1 + 1) * 0.5f;
	auto mult = 0.25f / biggestVal;

	Vector4 Result;
	switch (biggestIndex)
	{
	case 0:
		Result.w = biggestVal;
		Result.x = (mat(1, 2) - mat(2, 1)) * mult;
		Result.y = (mat(2, 0) - mat(0, 2)) * mult;
		Result.z = (mat(0, 1) - mat(1, 0)) * mult;
		break;
	case 1:
		Result.w = (mat(1, 2) - mat(2, 1)) * mult;
		Result.x = biggestVal;
		Result.y = (mat(0, 1) + mat(1, 0)) * mult;
		Result.z = (mat(2, 0) + mat(0, 2)) * mult;
		break;
	case 2:
		Result.w = (mat(2, 0) - mat(0, 2)) * mult;
		Result.x = (mat(0, 1) + mat(1, 0)) * mult;
		Result.y = biggestVal;
		Result.z = (mat(1, 2) + mat(2, 1)) * mult;
		break;
	case 3:
		Result.w = (mat(0, 1) - mat(1, 0)) * mult;
		Result.x = (mat(2, 0) + mat(0, 2)) * mult;
		Result.y = (mat(1, 2) + mat(2, 1)) * mult;
		Result.z = biggestVal;
		break;
	}
	return Result;
}
#endif