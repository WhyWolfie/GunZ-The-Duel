#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <assert.h>

#include "matrix.h"
#include "reader.h"
#include "elu.h"



void transform_v(Vector3 *vertices, Matrix4& t, int size)
{
	for (int i = 0; i < size; ++i)
		vertices[i] = t * vertices[i];
}

bool read_elu(const char *name, EluObject &obj) {
	Reader file(name);

	auto &hdr = obj.hdr;
	auto &mat = obj.mat;
	auto &node = obj.node;

	file.read(&hdr, sizeof(EluHeader));

	mat = new Material[hdr.num_material];

	for (int i = 0; i < hdr.num_material; ++i) {
		auto &m = mat[i];

		m.id = file.read_int32();
		m.sub_id = file.read_int32();

		file.read(&m.ambient, sizeof(Vector4));
		file.read(&m.diffuse, sizeof(Vector4));
		file.read(&m.specular, sizeof(Vector4));

		m.power = file.read_float() * 100.f;
		m.sub_mat_num = file.read_int32();

		const auto len = hdr.version < EXPORTER_MESH_VER7 ? 40 : 256;
		file.read(m.name, len);
		file.read(m.oname, len);

		if (hdr.version > EXPORTER_MESH_VER2)
			m.two_sided = file.read_int32();

		if (hdr.version > EXPORTER_MESH_VER4)
			m.additive = file.read_int32();

		if (hdr.version > EXPORTER_MESH_VER7)
			m.alpha_test = file.read_int32();
	}

	node = new MeshNode[hdr.num_mesh];
	for (int i = 0; i < hdr.num_mesh; ++i) {
		auto &n = node[i];

		file.read(n.name, 40);
		file.read(n.parent, 40);

		file.read(&n.trasnform, sizeof(Matrix4));

		n.scale = { 1.f, 1.f, 1.f };
		if (hdr.version >= EXPORTER_MESH_VER2)
			file.read(&n.scale, sizeof(Vector3));

		n.arot = { 1.f, 0.f, 0.f, 0.f };
		n.ascale = { 1.f, 0.f, 0.f, 0.f };
		if (hdr.version >= EXPORTER_MESH_VER4) {
			file.read(&n.arot, sizeof(Vector4));
			file.read(&n.ascale, sizeof(Vector4));

			file.read(&n.trasnform_etc, sizeof(Matrix4));
			//m_etc = i-as * scale * as
		}

		n.num_vertex = file.read_int32();
		if (n.num_vertex > 0) {
			n.vertices = new Vector3[n.num_vertex];
			file.read(n.vertices, sizeof(Vector3) * n.num_vertex);

			//transform_v(n.vertices, n.trasnform, n.num_vertex);
		}

		n.num_face = file.read_int32();

		if (n.num_face > 0) {
			n.face_data = new MeshNode::FaceData[n.num_face];
			if (hdr.version >= EXPORTER_MESH_VER6) {
				n.normal_data = new MeshNode::NormalData[n.num_face];

				file.read(n.face_data, sizeof(MeshNode::FaceData) * n.num_face);
				file.read(n.normal_data, sizeof(MeshNode::NormalData) * n.num_face);
			} else if (hdr.version > EXPORTER_MESH_VER2) {
				file.read(n.face_data, sizeof(MeshNode::FaceData) * n.num_face);
			} else {
				printf("[ERROR] Ver <= 2!\n");
				return false;
			}
		}

		if (hdr.version >= EXPORTER_MESH_VER6) {
			n.num_color = file.read_int32();
			if (n.num_color > 0) {
				n.color_data = new Vector3[n.num_color];
				file.read(n.color_data, sizeof(Vector3) * n.num_color);
			}
		}

		n.mat_id = file.read_int32();

		n.num_physique = file.read_int32();
		if (n.num_physique > 0) {
			n.physique_data = new MeshNode::PhysiqueData[n.num_physique];
			file.read(n.physique_data, sizeof(MeshNode::PhysiqueData) * n.num_physique);
		}
	}

	return true;
}

#include <map>
#include <string>

void print_bone(MeshNode& node)
{
	int n = node.num_physique;
	auto info = node.physique_data;

	std::map<std::string, int> in;

	int max = 0;

	for (int i = 0; i < n; ++i) {
		auto d = info[i];
		for (int j = 0; j < 4; ++j) {
			if (in.find(d.parent[j]) == in.end())
				in[d.parent[j]] = 0;
			in[d.parent[j]] += 1;
		}

		max = max < d.num ? d.num : max;
	}

	printf("Max w: %d\n", max);
	printf("ids: { ");
	for (auto& id : in)
		printf("%s, ", id.first.c_str());
	printf("}\n");
}

Matrix4 rot_from_euler(Vector3 r) {
	float c1 = cosf(r.x); 
	float s1 = sinf(r.x);

	float c2 = cosf(r.y);
	float s2 = sinf(r.y);

	float c3 = cosf(r.z);
	float s3 = sinf(r.z);

	Matrix4 rx(
	{ 1.f, 0.f, 0.f, 0.f },
	{ 0.f,  c1, -s1, 0.f },
	{ 0.f,  s1,  c1, 0.f },
	{ 0.f, 0.f, 0.f, 1.f }
	);

	Matrix4 ry(
	{  c2, 0.f,  s2, 0.f },
	{ 0.f,  1.f, 0.f, 0.f },
	{ -s2,  0.f,  c2, 0.f },
	{ 0.f, 0.f, 0.f, 1.f }
	);

	Matrix4 rz(
	{  c3, -s3, 0.f, 0.f },
	{  s3,  c3, 0.f, 0.f },
	{ 0.f, 0.f, 1.f, 0.f },
	{ 0.f, 0.f, 0.f, 1.f }
	);


	//return rz * ry * rx;
	return (rx * ry * rz).transpose();
}

float asum(const Matrix4 &mat)
{
	float ret = 0;
	for (int i = 0; i < 16; ++i)
		ret += fabs(mat.m[i]);
	return ret;
}

void print(EluObject &obj) {
	auto &hdr = obj.hdr;
	auto &mat = obj.mat;
	auto &node = obj.node;

	printf("Version : %d\n", hdr.version);
	printf("Material: %d\n", hdr.num_material);
	printf("Mesh    : %d\n", hdr.num_mesh);

	for (int i = 0; i < hdr.num_material; ++i) {
		auto material = mat[i];
		printf("Material\n    id: %d\n    sid: %d\n    name: %s\n    oname: %s\n", material.id, material.sub_id, material.name, material.oname);
	}

	for (int i = 0; i < hdr.num_mesh; ++i) {

		auto n = node[i];
		printf("Node\n");
		printf("    Name: %s\n", n.name);
		printf("    Parent: %s\n", n.parent);
		printf("    vertices: %d\n", n.num_vertex);
		printf("    colors  : %d\n", n.num_color);
		printf("    faces   : %d\n", n.num_face);
		printf("    physique: %d\n", n.num_physique);
		printf("    material: %d\n", n.mat_id);
		printf("    Transform: \n"); n.trasnform.print();
		printf("\n    scale: "); n.scale.print();
		printf("\n    arot: "); n.arot.print();
		printf("\n    ascale: "); n.ascale.print();
		printf("\n");
		print_bone(n);


		float r2d = 180. / pi;

		auto tf = n.trasnform;
		auto trans = tf.get_translation();
		auto scale = tf.get_scale();
		auto rot = tf.get_rotation_euler() * r2d;

		printf("translation: "); trans.print();
		printf("\nscale      : "); scale.print();
		printf("\nrotation   : "); rot.print();
		printf("\n--------------\n");

	}
}


MeshNode * find(const char *name, MeshNode *nodes, int size)
{
	for (int i = 0; i < size; ++i) {
		if (strcmp(name, nodes[i].name) == 0)
			return &nodes[i];
	}
	return nullptr;
}

bool is_identity(Matrix4 &m)
{
	for (int i = 0; i < 4; ++i)
		for (int j = 0; j < 4; ++j) {
			if (i == j) {
				if (fabs(m(i, j) - 1.f) > 1e-6) return false;
			} else {
				if (fabs(m(i, j)) > 1e-6) return false;
			}
		}

	return true;
}

bool is_equal(Matrix4 &a, Matrix4 &b)
{
	for (int i = 0; i < 16; ++i)
		if (fabs(a.m[i] - b.m[i]) > 1e-6) return false;

	return true;
}

void calculate_local_transform(MeshNode *node)
{
	auto inv = node->trasnform.affine_inverse();
	for (auto &child : node->children) {
		child->local_transform = inv * child->trasnform;
		calculate_local_transform(child);

		child->gt = node->gt * child->local_transform;
	}
}
// Elu bone nodes store the global transformation
// Exporter expects local trasformation
// Thus we need to left multiply its transform by its parent inverse transform
void link_armature(MeshNode *nodes, int size) {
	auto root = find("Bip01", nodes, size);

	for (int i = 0; i < size; ++i) {
		auto parent = find(nodes[i].parent, nodes, size);
		if (parent)
			parent->children.push_back(&nodes[i]);
		// local transform == transform for nodes without parent
		nodes[i].local_transform = nodes[i].trasnform;
		nodes[i].gt = nodes[i].trasnform;
	}

	if (root)
		calculate_local_transform(root);
}


void dump_bone_structure(MeshNode *root)
{
	//name, parent, local_trans, global_trans
	printf("\n{\"%s\", \"%s\", ", root->name, root->parent);
	auto &lt = root->local_transform;
	printf("Matrix4({%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f}), ",
		lt[0], lt[1], lt[2], lt[3],
		lt[4], lt[5], lt[6], lt[7],
		lt[8], lt[9], lt[10], lt[11],
		lt[12], lt[13], lt[14], lt[15]);

	auto &gt = root->trasnform;
	printf("Matrix4({%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f}, {%07f, %07f, %07f, %07f})},\n",
		gt[0], gt[1], gt[2], gt[3],
		gt[4], gt[5], gt[6], gt[7],
		gt[8], gt[9], gt[10], gt[11],
		gt[12], gt[13], gt[14], gt[15]);

	for (auto &child : root->children)
		dump_bone_structure(child);
}


#include "fbx.h"

int main(int argc, char * argv[]) {
	if (argc < 2) {
		printf("No file name!\n");
		return -1;
	}
	auto name = argv[1];

	const char *output = nullptr;
	if (argc > 2)
		output = argv[2];

	EluObject obj;
	if (!read_elu(name, obj)) {
		return -1;
	}

	link_armature(obj.node, obj.hdr.num_mesh);

	if (output) {
		if (save(output, obj))
			printf("[INFO] save sucssesful!\n");
	} else
		dump_bone_structure(find("Bip01", obj.node, obj.hdr.num_mesh)); //print(obj);

	return 0;
}