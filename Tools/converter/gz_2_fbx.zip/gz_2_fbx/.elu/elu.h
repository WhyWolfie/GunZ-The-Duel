#pragma once
#include "matrix.h"
#include <stdint.h>
#include <vector>
#include <map>

#define EXPORTER_MESH_VER1	0x00000011
#define EXPORTER_MESH_VER2	0x00005001
#define EXPORTER_MESH_VER3	0x00005002
#define EXPORTER_MESH_VER4	0x00005003
#define EXPORTER_MESH_VER5	0x00005004
#define EXPORTER_MESH_VER6	0x00005005
#define EXPORTER_MESH_VER7	0x00005006
#define EXPORTER_MESH_VER8	0x00005007


struct EluHeader
{
	uint32_t signature;
	uint32_t version;
	int32_t num_material;
	int32_t num_mesh;
};


struct Material
{
	int32_t id;
	int32_t sub_id;

	Vector4 ambient;
	Vector4 diffuse;
	Vector4 specular;

	float power;

	int32_t sub_mat_num;

	char name[256];
	char oname[256];

	int32_t two_sided;
	int32_t additive;
	int32_t alpha_test;
};

struct MeshNode
{
	char name[40];
	char parent[40];
	//global transformation
	Matrix4 trasnform;
	Vector3 scale;

	// (axis, value)
	Vector4 arot;
	Vector4 ascale;
	Matrix4 trasnform_etc;

	int32_t num_vertex;
	Vector3 *vertices;

	struct FaceData {
		int32_t index[3];
		Vector3 uv[3];
		int32_t mat_id;
		int32_t sg_id;
	};

	struct NormalData {
		Vector3 normal;
		Vector3 vertice_normal[3];
	};

	int32_t num_face;
	FaceData *face_data;
	NormalData *normal_data;

	int32_t num_color;
	Vector3 *color_data;

	int32_t mat_id;


	struct PhysiqueData {
		char parent[4][40];
		float weight[4];
		int32_t parent_id[4];
		int32_t num;

		Vector3 offset[4];
	};

	int32_t num_physique;
	PhysiqueData *physique_data;

	//runtime data
	Matrix4 local_transform;
	std::vector<MeshNode*> children;
	Matrix4 gt;
};


struct EluObject
{
	EluHeader hdr;
	Material *mat;
	MeshNode *node;
};


const std::map<std::string, bool> bone_names = {
	{ "Bip01", false },
	{ "Bip01 Footsteps", true },
	{ "Bip01 Pelvis", true },
	{ "Bip01 Spine", true },
	{ "Bip01 Spine1", true },
	{ "Bip01 Spine2", true },
	{ "Bip01 Neck", true },
	{ "Bip01 Head", true },
	{ "Bip01 HeadNub", true },
	{ "Bip01 Ponytail1", true },
	{ "Bip01 Ponytail11", true },
	{ "Bip01 Ponytail12", true },
	{ "Bip01 Ponytail1Nub", true },
	{ "Bip01 L Clavicle", true },
	{ "Bip01 L UpperArm", true },
	{ "Bip01 L ForeArm", true },
	{ "Bip01 L Hand", true },
	{ "Bip01 L Finger0", true },
	{ "Bip01 L Finger0Nub", true },
	{ "Bip01 R Clavicle", true },
	{ "Bip01 R UpperArm", true },
	{ "Bip01 R ForeArm", true },
	{ "Bip01 R Hand", true },
	{ "Bip01 R Finger0", true },
	{ "Bip01 R Finger0Nub", true },
	{ "Bip01 L Thigh", true },
	{ "Bip01 L Calf", true },
	{ "Bip01 L Foot", true },
	{ "Bip01 L Toe0", true },
	{ "Bip01 L Toe0Nub", true },
	{ "Bip01 R Thigh", true },
	{ "Bip01 R Calf", true },
	{ "Bip01 R Foot", true },
	{ "Bip01 R Toe0", true },
	{ "Bip01 R Toe0Nub", true }
};