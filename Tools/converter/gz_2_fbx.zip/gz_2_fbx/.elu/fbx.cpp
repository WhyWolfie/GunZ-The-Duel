#include "fbx.h"
#include "matrix.h"

#include "fbxsdk.h"


bool is_bone(const char *name) {
	if (bone_names.find(name) != bone_names.end())
		return true;
	return false;
}

std::string get_texture_name(const char *name)
{
	std::string ret;
	const char *ext[] = { "", ".dds" };

	for (int i = 0; i < sizeof(ext) / 4; ++i) {
		ret = name;
		ret.append(ext[i]);

		FILE *f = fopen(ret.c_str(), "rb");
		bool exists = f != nullptr;
		if (exists) {
			fclose(f);
			return ret;
		}
	}
	printf("[WARN] Texture %s not found in path!\n", name);
	return name;
}


FbxTexture * create_texture(FbxObject* scene, const char* name)
{
	FbxFileTexture* lTexture = FbxFileTexture::Create(scene, name);
	lTexture->SetFileName(get_texture_name(name).c_str()); // Resource file is in current directory.
	lTexture->SetTextureUse(FbxTexture::eStandard);
	lTexture->SetMappingType(FbxTexture::eUV);
	lTexture->SetMaterialUse(FbxFileTexture::eModelMaterial);
	lTexture->SetSwapUV(false);
	lTexture->SetTranslation(0.0, 0.0);
	lTexture->SetScale(1.0, 1.0);
	lTexture->SetRotation(0.0, 0.0);
	return lTexture;
}


FbxNode * create_node(FbxObject *scene, MeshNode *mnode)
{
	auto node = FbxNode::Create(scene, mnode->name);
	auto mesh = FbxMesh::Create(scene, mnode->name);

	node->SetNodeAttribute(mesh);

	mesh->InitControlPoints(mnode->num_vertex);
	auto vertices = mesh->GetControlPoints();

	for (int i = 0; i < mnode->num_vertex; ++i) {
		auto p = mnode->vertices[i];
		vertices[i] = { p.x, p.y, p.z, 1.0 };
	}


	for (int i = 0; i < mnode->num_face; ++i) {
		auto face = mnode->face_data[i];
		mesh->BeginPolygon();
		for (int j = 0; j < 3; ++j)
			mesh->AddPolygon(face.index[j]);
		mesh->EndPolygon();
	}


	auto normals = mesh->CreateElementNormal();
	normals->SetMappingMode(FbxGeometryElement::eByPolygonVertex);
	normals->SetReferenceMode(FbxGeometryElement::eDirect);
	for (int i = 0; i < mnode->num_face; ++i) {
		auto n = mnode->normal_data[i].vertice_normal;
		for (int j = 0; j < 3; ++j)
			normals->GetDirectArray().Add({ n[j].x, n[j].y, n[j].z });
	}


	auto uvs = mesh->CreateElementUV("base_uv");
	uvs->SetMappingMode(FbxGeometryElement::eByPolygonVertex);
	uvs->SetReferenceMode(FbxGeometryElement::eDirect);
	for (int i = 0; i < mnode->num_face; ++i) {
		auto uv = mnode->face_data[i].uv;
		for (int j = 0; j < 3; ++j)
			uvs->GetDirectArray().Add({ uv[j].x, 1.f - uv[j].y });
	}

	//auto &transform = mnode->trasnform;
	auto &transform = mnode->local_transform;
	auto translation = transform.get_translation();
	auto scale = transform.get_scale();
	auto rot_euler = transform.get_rotation_euler();

#if 1
	node->LclTranslation = {translation.x, translation.y, translation.z};
	node->LclScaling = { scale.x, scale.y, scale.z };
	double r2d = 180. / pi;
	node->LclRotation = { rot_euler.x * r2d, rot_euler.y * r2d, rot_euler.z * r2d };


#endif
#if 1
	// set node as skeleton
	if (is_bone(mnode->name)) {
		/*
		This rotation is necessary to corret the bone orientation in blender
		(x, y, z) -> (y, x, z)
		*/
		Matrix4 r(
		{ 0.f, 1.f, 0.f, 0.f },
		{ 1.f, 0.f, 0.f, 0.f },
		{ 0.f, 0.f, 1.f, 0.f },
		{ 0.f, 0.f, 0.f, 1.f }
		);


		auto skeleton = FbxSkeleton::Create(scene, mnode->name);
		Matrix4 local_tr;
		if (strcmp("Bip01", mnode->name) == 0) {
			skeleton->SetSkeletonType(FbxSkeleton::eRoot);
			local_tr = mnode->local_transform * r;
		} else {
			skeleton->SetSkeletonType(FbxSkeleton::eLimbNode);
			local_tr = r * mnode->local_transform * r;
		}

#if 0
		auto &transform = local_tr;
		auto translation = transform.get_translation();
		auto scale = transform.get_scale();
		auto rot_euler = transform.get_rotation_euler();
		node->LclTranslation = { translation.x, translation.y, translation.z };
		node->LclScaling = { scale.x, scale.y, scale.z };
		double r2d = 180. / pi;
		node->LclRotation = { rot_euler.x * r2d, rot_euler.y * r2d, rot_euler.z * r2d };
#endif
		

		node->SetNodeAttribute(skeleton);
	}
#endif
	return node;
}

int get_parent(MeshNode *node, MeshNode *nodes, int size)
{
	for (int i = 0; i < size; ++i) {
		if (strcmp(node->parent, nodes[i].name) == 0)
			return i;
	}
	return -1;
}

template<typename T1, typename T2>
int get_parent(T1 *node, T2 **nodes, int size)
{
	for (int i = 0; i < size; ++i) {
		if (strcmp(node->GetName(), nodes[i]->GetName()) == 0)
			return i;
	}
	return -1;
}

std::map<std::string, int> bones_list(MeshNode& node)
{
	int n = node.num_physique;
	auto info = node.physique_data;

	std::map<std::string, int> in;

	int idx = 0;
	for (int i = 0; i < n; ++i) {
		auto d = info[i];
		for (int j = 0; j < 4; ++j) {
			if (strlen(d.parent[j]) > 0 && in.find(d.parent[j]) == in.end())
				in[d.parent[j]] = idx++;
		}
	}
	return in;
}

void add_deform_data(FbxObject *scene, FbxNode **nodes, int size, FbxMesh *mesh, MeshNode *node)
{
	auto bn = bones_list(*node);
	int n = bn.size();

	FbxCluster **clusters = new FbxCluster*[n];
	auto it = bn.begin();
	for (int i = 0; i < n; ++i) {
		clusters[it->second] = FbxCluster::Create(scene, it->first.c_str());
		++it;
	}

	auto info = node->physique_data;
	for (int i = 0; i < node->num_physique; ++i) {
		auto& data = info[i];
		for (int j = 0; j < 4; ++j) {
			if (strlen(data.parent[j]) > 0) {
				int id = bn[data.parent[j]];

				clusters[id]->AddControlPointIndex(i, data.weight[j]);
			}
		}
	}

	//link clusters to bones
	for (int i = 0; i < n; ++i) {
		auto id = get_parent(clusters[i], nodes, size);
		if (id >= 0) {
			clusters[i]->SetLink(nodes[id]);
			clusters[i]->SetTransformMatrix(mesh->GetNode()->EvaluateGlobalTransform());
			clusters[i]->SetTransformLinkMatrix(nodes[id]->EvaluateGlobalTransform());
		}
		clusters[i]->SetLinkMode(FbxCluster::eTotalOne);
	}

	FbxSkin* skin = FbxSkin::Create(scene, "skin_data");
	for (int i = 0; i < n; ++i) {
		skin->AddCluster(clusters[i]);
	}
	mesh->AddDeformer(skin);
	delete[] clusters;
}



FbxSurfacePhong * create_material(FbxObject *scene, Material * mat)
{
	auto material = FbxSurfacePhong::Create(scene, mat->name);

	auto c = mat->ambient;
	material->Ambient.Set({ c.x, c.y, c.z });
	c = mat->diffuse;
	material->Diffuse.Set({ c.x, c.y, c.z });
	c = mat->specular;
	material->Specular.Set({ c.x, c.y, c.z });

	material->Emissive.Set({ 0., 0., 0. });

	auto texture = create_texture(scene, mat->name);
	material->Diffuse.ConnectSrcObject(texture);

	return material;
}
template<typename T>
struct SelfDestruct {
	T *ptr;
	SelfDestruct(T *p) : ptr(p) {}
	~SelfDestruct() { ptr->Destroy(); }
};

bool save(const char *name, EluObject& obj)
{
	FbxManager *mgr = FbxManager::Create();
	if (!mgr)
		return false;

	SelfDestruct<FbxManager> sd(mgr);

	//Create an IOSettings object. This object holds all import/export settings.
	FbxIOSettings* ios = FbxIOSettings::Create(mgr, IOSROOT);
	mgr->SetIOSettings(ios);

	//Load plugins from the executable directory (optional)
	FbxString path = FbxGetApplicationDirectory();
	mgr->LoadPluginsDirectory(path.Buffer());



	FbxScene *scene = FbxScene::Create(mgr, name);
	FbxNode ** nodes = new FbxNode*[obj.hdr.num_mesh];

	auto root = scene->GetRootNode();

	//create nodes
	for (int i = 0; i < obj.hdr.num_mesh; ++i) {
		nodes[i] = create_node(scene, &obj.node[i]);
	}

	//link nodes
	for (int i = 0; i < obj.hdr.num_mesh; ++i) {
		auto idx = get_parent(&obj.node[i], obj.node, obj.hdr.num_mesh);

		auto parent = idx == -1 ? root : nodes[idx];
		parent->AddChild(nodes[i]);
	}

	//create materials
	FbxSurfacePhong **materials = new FbxSurfacePhong*[obj.hdr.num_material];
	for (int i = 0; i < obj.hdr.num_material; ++i) {
		materials[i] = create_material(scene, &obj.mat[i]);
	}

	//link materials
	for (int i = 0; i < obj.hdr.num_mesh; ++i) {
		nodes[i]->AddMaterial(materials[obj.node[i].mat_id]);
	}

	// add skinning data
	for (int i = 0; i < obj.hdr.num_mesh; ++i) {
		add_deform_data(scene, nodes, obj.hdr.num_mesh, (FbxMesh*)nodes[i]->GetNodeAttribute(), &obj.node[i]);
	}


	for (int i = 0; i < obj.hdr.num_mesh; ++i) {
		auto lt = obj.node[i].local_transform;
		auto gt = obj.node[i].trasnform;

		auto mt = nodes[i]->EvaluateGlobalTransform();

		Matrix4 gt_fbx = Matrix4(
		{ mt[0][0], mt[0][1], mt[0][2], mt[0][3] },
		{ mt[1][0], mt[1][1], mt[1][2], mt[1][3] },
		{ mt[2][0], mt[2][1], mt[2][2], mt[2][3] },
		{ mt[3][0], mt[3][1], mt[3][2], mt[3][3] }
		);


		mt = nodes[i]->EvaluateLocalTransform();
		Matrix4 lt_fbx = Matrix4(
		{ mt[0][0], mt[0][1], mt[0][2], mt[0][3] },
		{ mt[1][0], mt[1][1], mt[1][2], mt[1][3] },
		{ mt[2][0], mt[2][1], mt[2][2], mt[2][3] },
		{ mt[3][0], mt[3][1], mt[3][2], mt[3][3] }
		);
		printf("Name: %s\n", nodes[i]->GetName());
		printf("local:\n");
		lt.print();
		printf("\nfbx local:\n");
		lt_fbx.print();

		printf("\nglobal:\n");
		gt.print();
		printf("\nfbx global:\n");
		gt_fbx.print();

		printf("\ntest global:\n");
		obj.node[i].gt.print();
		printf("\n\n");
	}

	FbxExporter *exporter = FbxExporter::Create(mgr, name);

	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_MATERIAL, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_TEXTURE, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_EMBEDDED, false);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_SHAPE, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_GOBO, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_ANIMATION, true);
	mgr->GetIOSettings()->SetBoolProp(EXP_FBX_GLOBAL_SETTINGS, true);

	delete[] materials;
	delete[] nodes;

	if (exporter->Initialize(name, -1, mgr->GetIOSettings()) == false)
		return false;

	if (exporter->Export(scene) == false)
		return false;

	return true;
}
