#pragma once
#include <stdio.h>
#include <assert.h>
#include <stdint.h>

class Reader
{
	FILE *f;
public:
	Reader(const char *name) {
		f = fopen(name, "rb");
		assert(f != nullptr);
	}
	void read(void * dst, int size) {
		auto n = fread(dst, 1, size, f);
		assert(size == n);
	}
	int32_t read_int32() {
		int32_t ret;
		auto n = fread(&ret, sizeof(int32_t), 1, f);
		assert(n == 1);
		return ret;
	}
	uint32_t read_uint32() {
		uint32_t ret;
		auto n = fread(&ret, sizeof(uint32_t), 1, f);
		assert(n == 1);
		return ret;
	}

	float read_float() {
		float ret;
		auto n = fread(&ret, sizeof(float), 1, f);
		assert(n == 1);
		return ret;
	}
};