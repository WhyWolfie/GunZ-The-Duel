#pragma once
#include "elu.h"

bool save(const char *name, EluObject &obj);