#include <windows.h>

#define DISPLAYCOMMON			0x004AD870
#define ROCK					0x00476970
#define ROUND					0x00475B60
#define FINALROUND				0x004A1080
#define KILL					0x004766B0
#define EXP						0x00475FD0
#define HIT						0x004A11E0
#define HPAPPLAY				0x004725A0
#define FINISH					0x00402640
#define WIN						0x004A10F0
#define LOSE					0x004A1140

int DisplayCommonAddr = DISPLAYCOMMON, RockAddr = ROCK, 
RoundAddr = ROUND, FinalRoundAddr = FINALROUND, KillAddr = KILL, ExpAddr = EXP, 
HitAddr = HIT, HpApPlayAddr = HPAPPLAY, FinishAddr = FINISH, 
WinAddr = WIN, LoseAddr = LOSE;

int RoundCount = 0, KillCount = 0, ExpCount = 1000;

void main()	{
	while(1)	{
	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('L') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call RockAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('R') & 0x8000)	{
		RoundCount++;
		_asm	{
			push RoundCount
			call DisplayCommonAddr
			mov ecx, eax
			call RoundAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('F') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call FinalRoundAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('I') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call FinishAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('K') & 0x8000)	{
		KillCount = 0;
		do{
			_asm	{
				push KillCount
				call DisplayCommonAddr
				mov ecx, eax
				call KillAddr
			}
			KillCount++;
		}	while(KillCount != 5);
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('E') & 0x8000)	{
		_asm	{
			push ExpCount
			call DisplayCommonAddr
			mov ecx, eax
			call ExpAddr
		}
		ExpCount = ExpCount + 1000;
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('P') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call HpApPlayAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('H') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call HitAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('W') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call WinAddr
		}
		Sleep(450);
	}

	if(GetAsyncKeyState(VK_MENU) & 0x8000 && GetAsyncKeyState('O') & 0x8000)	{
		_asm	{
			call DisplayCommonAddr
			mov ecx, eax
			call LoseAddr
		}
		Sleep(450);
	}

	Sleep(50);
	}
}

extern "C"
{
	__declspec(dllexport) BOOL __stdcall DllMain(HINSTANCE hInst,DWORD reason,LPVOID lpv)
	{
		if (reason == DLL_PROCESS_ATTACH)
		{
			DisableThreadLibraryCalls(hInst);
	CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)&main,NULL,0,NULL);
		}
	return true;
	}
}
