There is not the In-game check.
If you used this in login, character selection, lobby, stage, the client is crashed.

Inject to your july 21 2008 client.
Alt+L :Let's rock.
Alt+R :Round --.
Alt+F :Final round.
Alt+K :All kill ~ Head shot.
Alt+E :Exp +.
Alt+P :Play HP/AP.
Alt+H :Hit.
Alt+I :Finish.
Alt+W :Win.
Alt+O :Lose.